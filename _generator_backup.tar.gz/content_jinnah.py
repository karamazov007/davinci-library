# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Muhammad Ali Jinnah.
The Bombay barrister who became Quaid-e-Azam, founder of Pakistan — presented even-handedly."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#047857'  # Pakistan emerald

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE BARRISTER
PHASE_RISE = [
    E('origins', '1876–1892', 'A Karachi merchant’s son', ['RISE'],
      'Muhammad Ali Jinnah is born in Karachi into a prosperous Gujarati trading family of the Khoja community, the eldest of seven children, and grows up in a bustling port city of the British Raj before being sent to England as a teenager to make his way.',
      svg_row('The making of a modern man', [
          {'n': 1, 'label': 'Born in Karachi, 1876', 'sub': 'a busy port of British India', 'color': '#047857'},
          {'n': 2, 'label': 'A Gujarati Khoja merchant family', 'sub': 'son of the trader Jinnahbhai Poonja', 'color': '#a16207'},
          {'n': 3, 'label': 'Sent to England, 1892', 'sub': 'a teenager bound for London', 'color': '#3730a3'},
      ], edge_labels=['in', 'then'], takeaway='A commercial, cosmopolitan upbringing shaped a man at ease with the modern British world he would enter.', accent=AC),
      bg='<b>Muhammad Ali Jinnah</b> was born on 25 December 1876 in Karachi, in the Sindh province of British India, the eldest child of a well-to-do merchant family of the Khoja community.',
      people='his father <b>Jinnahbhai Poonja</b>, a Gujarati trader; his large family in Karachi; the British Raj into which he was born.',
      what='Jinnah grew up in the thriving port of <b>Karachi</b>, in a mercantile Gujarati-speaking family, before being sent to <b>England around 1892</b> to gain business experience — a passage that redirected him toward the law.',
      crux='His origins were <b>commercial and cosmopolitan</b>, not feudal or clerical — he was formed by trade, cities and the wider world.',
      conseq='In London he abandoned the apprenticeship for a legal career, setting the course of his life.',
      matters='Formative worlds shape their men — the port-city merchant’s son became a modern lawyer-politician, not a man of the old order.'),

    E('london', '1892–1896', 'Reading law at Lincoln’s Inn', ['RISE'],
      'In London the young Jinnah enrols at Lincoln’s Inn, immerses himself in English law and liberal politics, and is called to the bar — one of the youngest Indians ever to qualify — returning home a polished constitutionalist steeped in British parliamentary ideals.',
      svg_stack('An Indian barrister forged in London', [
          {'n': 1, 'label': 'Enrols at Lincoln’s Inn', 'sub': 'studies English law in the capital', 'color': '#3730a3'},
          {'n': 2, 'label': 'Called to the bar, 1896', 'sub': 'among the youngest Indians to qualify', 'color': '#047857'},
          {'n': 3, 'label': 'Absorbs liberal constitutionalism', 'sub': 'parliamentary ideals and the rule of law', 'color': '#166534'},
      ], takeaway='He returned with a lawyer’s faith in constitutions, procedure and argument — the tools he would use all his life.', accent=AC),
      bg='In London Jinnah gave up commerce for the law, entering <b>Lincoln’s Inn</b> and immersing himself in the political life of the late-Victorian capital.',
      people='the barristers and mentors of the London bar; the liberal politicians he admired; the Indian students of the day.',
      what='Jinnah was <b>called to the bar at Lincoln’s Inn in 1896</b>, one of the youngest Indians to do so, absorbing English <b>constitutional and parliamentary ideals</b> that would define his political method.',
      crux='He became a <b>constitutionalist by conviction</b> — a believer in law, procedure and reasoned argument over agitation.',
      conseq='He returned to India to build a legal practice and enter public life as a moderate reformer.',
      matters='A method is a worldview — the barrister’s faith in constitutions shaped how Jinnah would fight every battle to come.'),

    E('bombay', '1896–1906', 'The brilliant Bombay barrister', ['RISE', 'TRIUMPH'],
      'Settling in Bombay, Jinnah builds a dazzling career at the bar — cool, precise, incorruptible and famous for his forensic skill — winning wealth and standing as one of the city’s finest advocates and a rising star of its cosmopolitan elite.',
      svg_stack('A dazzling career at the bar', [
          {'n': 1, 'label': 'Settles in Bombay', 'sub': 'builds a legal practice from scratch', 'color': '#047857'},
          {'n': 2, 'label': 'A forensic advocate', 'sub': 'cool, precise, famed for his skill', 'color': '#3730a3'},
          {'n': 3, 'label': 'Wealth and standing', 'sub': 'one of India’s leading barristers', 'color': '#a16207'},
      ], takeaway='His success at the bar gave him the independence, prestige and self-command that underpinned his politics.', accent=AC),
      bg='Jinnah settled in <b>Bombay</b>, then the commercial and cosmopolitan heart of India, and slowly built one of the most successful practices at the bar.',
      people='the judges and rival advocates of the Bombay bar; the mixed Hindu, Muslim and Parsi elite of the city.',
      what='Over the next decade Jinnah became a <b>celebrated barrister</b> — renowned for his clarity, composure and forensic power — winning wealth and a place among Bombay’s leading public men.',
      crux='He rose entirely on <b>merit and independence</b>, beholden to no patron — a self-made professional, not a hereditary notable.',
      conseq='His standing and financial independence let him enter politics as his own man, free of factional debt.',
      matters='Independence is power — Jinnah’s wealth and reputation at the bar let him take positions others could not afford to hold.'),
]

# ==================================================================  PHASE 2 — AMBASSADOR OF UNITY
PHASE_UNITY = [
    E('congress', '1906–1910', 'Into politics — a Congress moderate', ['POLITICS', 'RISE'],
      'Jinnah enters nationalist politics through the Indian National Congress, aligning with its moderate constitutionalists, serving the veteran Dadabhai Naoroji, and winning election to the Imperial Legislative Council — a secular liberal who sees Indians, not communities, as the nation.',
      svg_row('A secular constitutional nationalist', [
          {'n': 1, 'label': 'Joins the Congress', 'sub': 'aligns with its moderate wing', 'color': '#166534'},
          {'n': 2, 'label': 'Serves Dadabhai Naoroji', 'sub': 'secretary to the “Grand Old Man”', 'color': '#a16207'},
          {'n': 3, 'label': 'Imperial Legislative Council, 1910', 'sub': 'enters the councils of the Raj', 'color': '#047857'},
      ], edge_labels=['under', 'to'], takeaway='He began as a secular Indian nationalist who believed reform would come through constitutional means.', accent=AC),
      bg='In the years after 1906 Jinnah joined the <b>Indian National Congress</b>, the leading nationalist body, aligning with its moderate, constitutional wing.',
      people='<b>Dadabhai Naoroji</b>, the veteran nationalist he assisted; <b>Gopal Krishna Gokhale</b>, the moderate leader he admired; the Congress moderates.',
      what='Jinnah worked within the Congress as a <b>secular constitutionalist</b>, served as secretary to <b>Dadabhai Naoroji</b>, and won election to the <b>Imperial Legislative Council in 1910</b>, pressing for reform through lawful means.',
      crux='At this stage he saw himself as an <b>Indian nationalist first</b>, distrustful of communal politics and confident of Hindu–Muslim partnership.',
      conseq='His stature as a bridge-builder led him, three years later, to join the Muslim League while remaining in the Congress.',
      matters='Leaders are not fixed — the man later called Pakistan’s founder began as a secular champion of a single Indian nation.'),

    E('league', '1913', 'Joining the League — a bridge, not a wall', ['POLITICS'],
      'Jinnah joins the All-India Muslim League in 1913 — but only after insisting it commit to Indian self-government and cooperation with the Congress — casting himself as a bridge between the two bodies rather than a partisan of Muslim separatism.',
      svg_stack('A foot in both camps', [
          {'n': 1, 'label': 'Joins the Muslim League, 1913', 'sub': 'while keeping his Congress membership', 'color': '#047857'},
          {'n': 2, 'label': 'On his own terms', 'sub': 'insists the League back Indian self-rule', 'color': '#166534'},
          {'n': 3, 'label': 'A bridge between the two', 'sub': 'seeks Hindu–Muslim cooperation', 'color': '#3730a3'},
      ], takeaway='He entered the League to unite, not divide — to bind Muslim aspirations to a common Indian cause.', accent=AC),
      bg='The <b>All-India Muslim League</b>, founded in 1906 to voice Muslim interests, was courting national figures. Jinnah, still a Congressman, was persuaded to join.',
      people='the leaders of the Muslim League; his Congress colleagues; the British authorities watching Indian opinion.',
      what='In <b>1913 Jinnah joined the Muslim League</b> without leaving the Congress, and only on the understanding that the League endorse <b>self-government and Hindu–Muslim cooperation</b>.',
      crux='He conceived of the League not as a separatist body but as a <b>partner of the Congress</b> in a shared national movement.',
      conseq='His dual role positioned him to broker the landmark agreement of 1916 between the two organisations.',
      matters='Institutions can be turned to unity or division — Jinnah first bent the League toward cooperation, not separation.'),

    E('lucknow', '1916', 'The Lucknow Pact — ambassador of Hindu–Muslim unity', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'At the height of his bridging role, Jinnah engineers the Lucknow Pact — a historic agreement in which the Congress and the Muslim League jointly demand self-government and accept separate Muslim electorates — earning him the celebrated title “ambassador of Hindu–Muslim unity.”',
      svg_row('A single national demand', [
          {'n': 1, 'label': 'Congress and League together', 'sub': 'Jinnah brokers a joint agreement, 1916', 'color': '#166534'},
          {'n': 2, 'label': 'A shared demand for self-rule', 'sub': 'with safeguards for Muslim representation', 'color': '#047857'},
          {'n': 3, 'label': '“Ambassador of unity”', 'sub': 'hailed as the bridge between communities', 'color': '#a16207'},
      ], edge_labels=['forge', 'earns'], takeaway='At his zenith as a unifier, Jinnah made Hindus and Muslims speak with one political voice.', accent=AC),
      bg='By 1916 Jinnah led figures in both the Congress and the League. He seized the moment to bring the rival bodies into a common front.',
      people='the Congress and League leaders who signed; <b>Sarojini Naidu</b>, who lauded him as the “ambassador of Hindu–Muslim unity”; the British.',
      what='Jinnah engineered the <b>Lucknow Pact of 1916</b>, in which the Congress and the Muslim League jointly demanded greater <b>self-government</b> while agreeing to <b>separate electorates</b> for Muslims — a rare moment of unity.',
      crux='He proved that Muslim political safeguards and a united Indian demand could be <b>reconciled in one settlement</b> — his defining early achievement.',
      conseq='This high point of cooperation would not last; the rise of mass politics soon pulled the two movements apart.',
      matters='Even the architect of Partition once embodied unity — the tragedy is how far, and why, that early promise unravelled.'),
]

# ==================================================================  PHASE 3 — THE PARTING OF WAYS
PHASE_RIFT = [
    E('gandhi', '1920', 'Breaking with Gandhi and the Congress', ['POLITICS', 'TURNING POINT'],
      'The arrival of Gandhi’s mass, religiously-charged politics of non-cooperation dismays the constitutionalist Jinnah — who distrusts agitation and street mobilisation — and, isolated and outvoted, he resigns from the Congress, beginning his long estrangement from the mainstream nationalist movement.',
      svg_stack('The constitutionalist against the mass movement', [
          {'n': 1, 'label': 'Gandhi’s non-cooperation, 1920', 'sub': 'mass agitation replaces council politics', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Jinnah dissents', 'sub': 'distrusts agitation and religious appeals', 'color': '#047857'},
          {'n': 3, 'label': 'Resigns from the Congress', 'sub': 'isolated, he leaves the movement', 'color': '#78350f'},
      ], takeaway='A clash of methods — law versus mass agitation — drove Jinnah out of the movement he had helped to lead.', accent=AC),
      bg='After the First World War, <b>Mohandas Gandhi</b> transformed the Congress into a mass movement of civil disobedience, changing the whole style of Indian politics.',
      people='<b>Gandhi</b>, whose methods he opposed; the Congress radicals who embraced them; Jinnah, the isolated constitutionalist.',
      what='Jinnah opposed <b>Gandhi’s Non-Cooperation Movement (1920)</b> as unconstitutional and dangerously charged with religion, and — outvoted and isolated — he <b>resigned from the Congress</b>.',
      crux='The rupture was as much about <b>method as identity</b> — the lawyer’s constitutionalism against the mass politics of the streets.',
      conseq='Cut off from the Congress mainstream, Jinnah increasingly sought a political base among India’s Muslims.',
      matters='Deep divisions often begin as disputes over means — the break over method set Jinnah on a separate road.'),

    E('fourteenpoints', '1929', 'The Fourteen Points — a rejected compromise', ['POLITICS'],
      'Still seeking a place for Muslims within a united India, Jinnah frames his Fourteen Points — constitutional safeguards for Muslim representation in a federal India — but their rejection by the Congress deepens his conviction that Muslim interests cannot be secured by goodwill alone.',
      svg_row('A last bid for safeguards', [
          {'n': 1, 'label': 'The Fourteen Points, 1929', 'sub': 'Jinnah’s formula for Muslim safeguards', 'color': '#047857'},
          {'n': 2, 'label': 'A federal, united India', 'sub': 'protections within one country', 'color': '#166534'},
          {'n': 3, 'label': 'Rejected', 'sub': 'the Congress declines his terms', 'color': '#b91c1c'},
      ], edge_labels=['seeks', 'but'], takeaway='His constitutional formula for Muslim protection was spurned — hardening his fear that unity would leave Muslims outvoted.', accent=AC),
      bg='As constitutional reform was debated in the late 1920s, Jinnah sought firm guarantees for Muslims within a future self-governing India.',
      people='the Congress leaders who rejected his terms; the Muslim politicians he sought to unite; the British reformers.',
      what='In <b>1929 Jinnah set out his “Fourteen Points”</b> — demands for a federal structure and constitutional <b>safeguards for Muslim representation</b> — which the Congress and other bodies declined to accept.',
      crux='Their rejection convinced him that Muslim political interests could <b>not be secured by trust alone</b> in a Hindu-majority polity.',
      conseq='Disillusioned and marginal, Jinnah withdrew from Indian politics into a self-imposed exile in England.',
      matters='Rejected compromises can radicalise — the failure of his moderate formula pushed Jinnah toward a harder demand.'),

    E('exile', '1931–1934', 'Exile and return — remaking the League', ['POLITICS', 'RISE'],
      'Disheartened, Jinnah withdraws to practise law in London — but is persuaded to return and take command of a demoralised Muslim League, which he sets about rebuilding into a disciplined mass party and the sole recognised voice of India’s Muslims.',
      svg_stack('From despair to a disciplined party', [
          {'n': 1, 'label': 'Self-exile in London', 'sub': 'withdraws to practise at the bar', 'color': '#3730a3'},
          {'n': 2, 'label': 'Returns to lead the League', 'sub': 'called back to Indian politics, 1934', 'color': '#047857'},
          {'n': 3, 'label': 'Rebuilds a mass party', 'sub': 'forges the League into a disciplined force', 'color': '#166534'},
      ], takeaway='He returned from despair to transform a weak League into the organised vehicle of Muslim politics.', accent=AC),
      bg='Frustrated by the failure of Hindu–Muslim cooperation, Jinnah moved to <b>London around 1931</b> to practise before the Privy Council.',
      people='the Muslim leaders who begged him to return; the fractious League he inherited; his followers in India.',
      what='Persuaded to return in the <b>mid-1930s</b>, Jinnah took charge of the ailing <b>All-India Muslim League</b> and set about rebuilding it into a <b>disciplined, mass organisation</b> claiming to speak for all Indian Muslims.',
      crux='He grasped that influence required <b>organisation and numbers</b> — a single united party, not scattered notables.',
      conseq='The reorganised League became the instrument through which he would advance the demand for Pakistan.',
      matters='Movements need machines — Jinnah’s genius now lay in building the disciplined party that made his later demands credible.'),
]

# ==================================================================  PHASE 4 — TWO NATIONS
PHASE_TWONATION = [
    E('twonation', '1930s–1940', 'The Two-Nation Theory', ['POLITICS', 'TURNING POINT'],
      'Jinnah comes to argue that Hindus and Muslims are not two communities of one nation but two distinct nations — with separate religions, cultures and futures — a claim its defenders call a hard truth of self-preservation and its critics call a fateful reinvention of Indian identity.',
      svg_compare('Two nations, or one?',
        {'head': 'The Two-Nation view', 'color': '#047857', 'items': ['Hindus and Muslims are distinct nations', 'separate faiths, cultures and histories', 'Muslims need a state of their own', 'a majority cannot outvote a nation into safety']},
        {'head': 'The united-India view', 'color': '#a16207', 'items': ['Indians are one nation of many faiths', 'religion need not define nationhood', 'safeguards can protect a minority', 'partition would uproot millions']},
        'Defenders saw a realistic shield for a vulnerable minority; critics saw a tragic redefinition of a shared homeland.',
        'The theory reframed Indian Muslims from a minority to be protected into a nation to be given a state.', accent=AC),
      bg='Through the 1930s Jinnah concluded that constitutional safeguards would never secure Muslims in a Hindu-majority India, and reached for a deeper claim.',
      people='the League and its followers; Congress leaders who rejected the idea; the poet-philosopher <b>Muhammad Iqbal</b>, an early advocate of a Muslim homeland.',
      what='Jinnah advanced the <b>Two-Nation Theory</b> — that Hindus and Muslims were <b>separate nations</b> by religion, culture and social order, and that Muslims therefore required a <b>state of their own</b> rather than mere minority protection.',
      crux='It transformed the question from <b>how to protect a minority</b> to <b>how to give a nation its state</b> — the intellectual foundation of Pakistan.',
      conseq='This premise was formalised in the League’s demand for a separate Muslim homeland in 1940.',
      matters='Ideas redraw maps — how a people is defined, minority or nation, can decide whether a country stays whole or splits.'),

    E('lahore', '1940', 'The Lahore Resolution — the demand for Pakistan', ['POLITICS', 'TURNING POINT', 'TRIUMPH'],
      'At the Muslim League’s Lahore session in March 1940, Jinnah presides over the adoption of the historic resolution calling for independent states in the Muslim-majority regions of India — the formal birth of the demand that would become Pakistan.',
      svg_stack('The demand takes formal shape', [
          {'n': 1, 'label': 'The Lahore session, March 1940', 'sub': 'Jinnah presides over the League', 'color': '#047857'},
          {'n': 2, 'label': 'The Lahore Resolution', 'sub': 'calls for independent Muslim-majority states', 'color': '#166534'},
          {'n': 3, 'label': 'The demand for Pakistan', 'sub': 'a separate homeland becomes the goal', 'color': '#a16207'},
      ], takeaway='At Lahore the aspiration became a formal demand — the League now sought a nation, not just a settlement.', accent=AC),
      bg='By 1940, with cooperation exhausted and the Congress dominant, Jinnah brought the League to a decisive statement of purpose at its <b>Lahore session</b>.',
      people='the assembled League delegates; Jinnah, presiding; the Congress and British who now faced a formal demand.',
      what='On <b>23 March 1940</b> the League adopted the <b>Lahore Resolution</b>, demanding that the <b>Muslim-majority regions</b> of India be constituted as <b>independent states</b> — the founding charter of the Pakistan demand.',
      crux='The resolution turned a theory into a <b>concrete political programme</b> — a separate Muslim homeland as the League’s non-negotiable aim.',
      conseq='From this point Jinnah negotiated not for safeguards within India but for a partition of it.',
      matters='A demand once formalised is hard to reverse — Lahore set a course that would end in a new nation and a divided subcontinent.'),

    E('negotiations', '1942–1946', 'Cripps, the Cabinet Mission, and deadlock', ['POLITICS'],
      'As Britain seeks a wartime and post-war settlement, Jinnah negotiates hard through the Cripps and Cabinet Missions — at times accepting a loose united India, at times insisting on Pakistan — but mutual distrust between the League and Congress leaves every plan in ruins.',
      svg_row('Missions that could not bridge the gulf', [
          {'n': 1, 'label': 'The Cripps Mission, 1942', 'sub': 'wartime offer of dominion status fails', 'color': '#3730a3'},
          {'n': 2, 'label': 'The Cabinet Mission, 1946', 'sub': 'proposes a loose Indian federation', 'color': '#047857'},
          {'n': 3, 'label': 'Deadlock', 'sub': 'League and Congress cannot agree', 'color': '#b91c1c'},
      ], edge_labels=['then', 'ends in'], takeaway='Every British formula foundered on the same rock — the League and Congress could not trust a shared future.', accent=AC),
      bg='During and after the Second World War, Britain sent missions to negotiate India’s future, each trying to reconcile the League’s demand with the Congress’s vision of unity.',
      people='<b>Stafford Cripps</b> and the British missions; the <b>Congress</b> leaders under Nehru and Gandhi; Jinnah for the League.',
      what='Jinnah bargained through the <b>Cripps Mission (1942)</b> and the <b>Cabinet Mission (1946)</b>; the League briefly accepted the Cabinet Mission’s plan for a <b>loose federation</b>, then withdrew amid distrust, and the talks <b>collapsed</b>.',
      crux='Each plan failed on the central question of <b>trust and power</b> — whether Muslims would be safe in a united India, or must have their own state.',
      conseq='The breakdown of the Cabinet Mission plan led directly to Jinnah’s call for “Direct Action.”',
      matters='Negotiation cannot succeed without trust — and by 1946 there was too little left between the two movements to build a common home.'),
]

# ==================================================================  PHASE 5 — PARTITION & PAKISTAN
PHASE_PARTITION = [
    E('directaction', '1946', 'Direct Action Day and the descent into violence', ['POLITICS', 'TRAGEDY'],
      'When negotiations collapse, Jinnah calls for a day of “Direct Action” to press the demand for Pakistan — but in Calcutta it ignites appalling communal killings, and the bloodshed that follows across India makes the case that Hindus and Muslims can no longer share one state almost unanswerable.',
      svg_stack('The turn to the streets', [
          {'n': 1, 'label': 'Talks collapse, 1946', 'sub': 'the Cabinet Mission plan breaks down', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Direct Action Day, 16 Aug 1946', 'sub': 'the League calls a day of protest', 'color': '#047857'},
          {'n': 3, 'label': 'The Great Calcutta Killings', 'sub': 'communal violence leaves thousands dead', 'color': '#78350f'},
      ], takeaway='A political demand spilled into communal slaughter — and the violence itself hardened the logic of partition.', accent=AC),
      bg='After the Cabinet Mission failed, Jinnah abandoned constitutional methods and called on Muslims to demonstrate their demand for Pakistan directly.',
      people='the League and its followers; the Congress and Hindu communities; the countless victims of the riots.',
      what='The League declared <b>Direct Action Day on 16 August 1946</b>; in Calcutta it triggered the <b>Great Calcutta Killings</b>, days of communal violence that left <b>thousands dead</b> and spread bloodshed across northern India.',
      crux='Defenders call it a political demonstration that spun tragically out of control; critics hold the call itself <b>helped unleash the killing</b> — a charge that still divides historians.',
      conseq='The horror convinced many, including the British, that partition had become unavoidable.',
      matters='The costs of the split are counted in lives — Direct Action Day is remembered as the moment communal politics turned to mass violence.'),

    E('pakistan', '1947', 'The birth of Pakistan — Quaid-e-Azam', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'In August 1947 British India is partitioned and the new state of Pakistan is born, with Jinnah — hailed as Quaid-e-Azam, the Great Leader — as its first Governor-General; yet independence comes amid mass migration and killing, and he calls, in vain, for a state where faith is a private matter.',
      svg_row('A nation founded amid triumph and tragedy', [
          {'n': 1, 'label': 'Partition, August 1947', 'sub': 'Pakistan is created from British India', 'color': '#047857'},
          {'n': 2, 'label': 'Quaid-e-Azam', 'sub': 'first Governor-General of Pakistan', 'color': '#166534'},
          {'n': 3, 'label': 'Migration and massacre', 'sub': 'millions uprooted; vast communal killing', 'color': '#b91c1c'},
      ], edge_labels=['makes', 'amid'], takeaway='He achieved his nation — but its birth came with a human catastrophe that shadowed the triumph.', accent=AC),
      bg='With partition agreed, British India was divided on <b>14–15 August 1947</b> into the independent dominions of Pakistan and India.',
      people='Jinnah, now <b>Governor-General</b>; the millions of migrants and victims; the leaders of India and Britain overseeing the transfer.',
      what='Jinnah became the first <b>Governor-General of Pakistan</b>, revered as <b>Quaid-e-Azam (“Great Leader”)</b>; in his 11 August 1947 address he envisioned a state where <b>religion was a private matter</b> — even as partition unleashed mass migration and <b>communal massacres</b> of staggering scale.',
      crux='His life’s goal was realised, yet its birth-agony — and the tension between a Muslim homeland and a tolerant state — remains fiercely debated.',
      conseq='Jinnah governed the fragile new state for barely a year before his health gave way.',
      matters='Founding a nation is both triumph and reckoning — Pakistan’s creation fulfilled a vision and exacted a terrible human price.'),

    E('death', '1948', 'Death of the founder — and the argument over his legacy', ['POLITICS', 'DEATH'],
      'Worn out and gravely ill with tuberculosis, Jinnah dies in September 1948, barely a year after founding Pakistan — leaving a nation that reveres him as its father and a subcontinent that still argues, on both sides of the border, over what he built and what it cost.',
      svg_compare('How history judges him',
        {'head': 'As his admirers see him', 'color': '#047857', 'items': ['won a homeland for a vulnerable minority', 'a principled, incorruptible constitutionalist', 'defended Muslims against majority rule', 'founder and father of a nation']},
        {'head': 'As his critics see him', 'color': '#b91c1c', 'items': ['divided a shared subcontinent', 'stoked communal politics for leverage', 'partition brought mass death and migration', 'abandoned his early unifying ideals']},
        'Revered as Quaid-e-Azam by Pakistanis and blamed for Partition by many Indians — a figure history still reads two ways.',
        'A man of one cause and two verdicts — nation-builder to some, divider to others; the debate outlives him.', accent=AC),
      bg='Jinnah had long concealed the tuberculosis that was killing him. Having achieved Pakistan, he had little strength left to shape it.',
      people='the Pakistanis who mourned their founder; the historians and citizens on both sides who still contest his legacy.',
      what='Jinnah <b>died on 11 September 1948</b>, worn out by tuberculosis, barely a year after Pakistan’s creation — revered there as <b>father of the nation</b>, yet blamed by many in India for the <b>partition and its bloodshed</b>.',
      crux='His legacy is genuinely <b>two-sided</b>: a triumphant nation-builder to his admirers, a divider of a common homeland to his critics — a verdict that still splits along the border he helped draw.',
      conseq='Pakistan endures as his monument; the Partition’s wounds endure as its cost — both his inheritance.',
      matters='Great founders leave contested legacies — Jinnah is judged, even-handedly, as both the maker of a nation and a cause of its painful birth.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Muhammad Ali Jinnah was the founder of Pakistan — and one of the most consequential and contested figures of the twentieth century. A brilliant Bombay barrister and, in his youth, a secular Indian nationalist hailed as the “ambassador of Hindu–Muslim unity,” he ended his life as Quaid-e-Azam, the Great Leader who carved a Muslim homeland out of British India. His journey from unifier to partitioner — driven by the conviction that Muslims were a distinct nation who could not be safe as a minority — reshaped a subcontinent, at a terrible human cost. He is the ultimate study in <b>national identity, minority rights, and the tragic arithmetic of partition</b> — a man revered on one side of a border and blamed on the other.</p>
<div class="ov-quote">“You are free; you are free to go to your temples, you are free to go to your mosques… That has nothing to do with the business of the State.”<span>— Jinnah, address to Pakistan’s Constituent Assembly, 11 August 1947</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A Karachi merchant’s son trains as a barrister in London → dazzles the Bombay bar → enters the Congress as a secular nationalist and brokers the Lucknow Pact as “ambassador of Hindu–Muslim unity” → breaks with Gandhi’s mass politics and sees his compromises rejected → embraces the Two-Nation Theory and wins the Lahore Resolution demanding Pakistan → negotiates and deadlocks with the British and Congress → and, through Direct Action Day and Partition, founds Pakistan in 1947 as Quaid-e-Azam, dying a year later.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🌙</div><h4>Founder of a nation</h4><p>Created Pakistan, a homeland for the Muslims of South Asia.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>Minority and nationhood</h4><p>Posed the enduring question of when a minority becomes a nation.</p></div>
  <div class="ov-card"><div class="i">🤝</div><h4>From unity to partition</h4><p>His arc traces how a unifier can become a divider.</p></div>
  <div class="ov-card"><div class="i">🕊️</div><h4>A contested legacy</h4><p>Revered and blamed — a life history still reads two ways.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Barrister</b><small> 1876–1906</small><p>From Karachi to the Bombay bar.</p></div>
  <div><b>2 · Ambassador of Unity</b><small> 1906–1916</small><p>Congress, the League and the Lucknow Pact.</p></div>
  <div><b>3 · The Parting of Ways</b><small> 1920–1934</small><p>Break with Gandhi; rejection and return.</p></div>
  <div><b>4 · Two Nations</b><small> 1930s–1946</small><p>The theory, Lahore, and deadlock.</p></div>
  <div><b>5 · Partition & Pakistan</b><small> 1946–1948</small><p>Direct Action, a new nation, and death.</p></div>
</div>
<div class="ov-lbl">A note on even-handedness</div>
<p class="ov-lead" style="font-size:15px">Jinnah and the Partition remain deeply contested across India and Pakistan. This guide presents his aims and actions <b>as both his defenders and his critics would frame them</b>, without taking sides — laying out the case, the counter-case, and the human cost so readers can weigh them for themselves.</p>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Mohandas Gandhi', 'role': 'rival and counterpoint', 'color': '#b91c1c',
     'bio': 'The leader whose mass, religiously-charged politics of non-cooperation Jinnah opposed, and whose Congress became the great rival of the League.',
     'rel': 'The adversary whose methods drove Jinnah from the Congress.'},
    {'name': 'Jawaharlal Nehru', 'role': 'Congress leader', 'color': '#166534',
     'bio': 'The Congress leader and future first prime minister of India, whose vision of a united, secular India clashed with Jinnah’s demand for Pakistan.',
     'rel': 'The Congress counterpart across the negotiating table.'},
    {'name': 'Muhammad Iqbal', 'role': 'philosopher of the idea', 'color': '#3730a3',
     'bio': 'The poet-philosopher who articulated an early vision of a separate Muslim polity in India and encouraged Jinnah to lead the Muslim cause.',
     'rel': 'The thinker who helped inspire the demand Jinnah realised.'},
    {'name': 'Sarojini Naidu', 'role': 'admirer and colleague', 'color': '#a16207',
     'bio': 'The poet and nationalist who worked with the young Jinnah and famously hailed him as the “ambassador of Hindu–Muslim unity.”',
     'rel': 'Gave him the title that defined his early career.'},
    {'name': 'Lord Mountbatten', 'role': 'last British Viceroy', 'color': '#5b21b6',
     'bio': 'The last Viceroy of India, who oversaw the partition and the transfer of power in 1947 that created Pakistan and independent India.',
     'rel': 'The British authority who presided over Partition.'},
]

KEY_EVENTS = [
    ('1876', 'Jinnah born in Karachi', 'Into a Gujarati Khoja merchant family.'),
    ('1896', 'Called to the bar', 'Qualifies at Lincoln’s Inn in London.'),
    ('1906', 'Enters the Congress', 'A secular constitutional nationalist.'),
    ('1913', 'Joins the Muslim League', 'While remaining in the Congress.'),
    ('1916', 'Lucknow Pact', '“Ambassador of Hindu–Muslim unity.”'),
    ('1920', 'Breaks with Gandhi', 'Resigns from the Congress.'),
    ('1940', 'Lahore Resolution', 'The formal demand for Pakistan.'),
    ('1946', 'Direct Action Day', 'Communal violence engulfs Calcutta.'),
    ('1947', 'Pakistan is created', 'Jinnah becomes Quaid-e-Azam.'),
    ('1948', 'Death of Jinnah', 'Dies barely a year after founding Pakistan.'),
]

MASTER = [
    {'year': '1876', 'age': 'born', 'phase': 'The Barrister', 'title': 'Born in Karachi', 'desc': 'A merchant family of Sindh.'},
    {'year': '1896', 'age': 'age 19', 'phase': 'The Barrister', 'title': 'Called to the bar', 'desc': 'Trained in London.'},
    {'year': '1916', 'age': 'age 39', 'phase': 'Ambassador of Unity', 'title': 'Lucknow Pact', 'desc': 'Bridge between communities.'},
    {'year': '1920', 'age': 'age 43', 'phase': 'Parting of Ways', 'title': 'Breaks with Gandhi', 'desc': 'Leaves the Congress.'},
    {'year': '1940', 'age': 'age 63', 'phase': 'Two Nations', 'title': 'Lahore Resolution', 'desc': 'Demands Pakistan.'},
    {'year': '1947', 'age': 'age 70', 'phase': 'Partition & Pakistan', 'title': 'Pakistan founded', 'desc': 'First Governor-General.'},
    {'year': '1948', 'age': 'age 71', 'phase': 'Partition & Pakistan', 'title': 'Death of the founder', 'desc': 'A contested legacy.'},
]

SOURCES = [
    ('Britannica — Mohammed Ali Jinnah', 'https://www.britannica.com/biography/Mohammed-Ali-Jinnah'),
    ('Britannica — Direct Action Day (1946)', 'https://www.britannica.com/event/Direct-Action-Day-India-1946'),
    ('New World Encyclopedia — Muhammad Jinnah', 'https://www.newworldencyclopedia.org/entry/Muhammad_Jinnah'),
    ('Banglapedia — Jinnah, Mohammed Ali', 'https://en.banglapedia.org/index.php/Jinnah,_Mohammed_Ali'),
    ('Wikipedia — Muhammad Ali Jinnah', 'https://en.wikipedia.org/wiki/Muhammad_Ali_Jinnah'),
]

def build_meta():
    return {
        'pid': 'gm-jinnah.html', 'kind': 'man', 'emoji': '🌙', 'accent': AC,
        'name': 'Muhammad Ali Jinnah', 'years': '1876–1948', 'group': 'Independence & Nation-Building',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Bombay barrister who rose as the “ambassador of Hindu–Muslim unity,” embraced the Two-Nation Theory, and founded Pakistan as its Quaid-e-Azam — a life history reads two ways, from unifier to partitioner.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Barrister', 'type': 'timeline',
             'intro': 'From a Karachi merchant family to a London-trained barrister and one of the finest advocates of the Bombay bar — the making of a modern, constitutional man.', 'events': PHASE_RISE},
            {'id': 'unity', 'label': '2 · Ambassador of Unity', 'type': 'timeline',
             'intro': 'Jinnah enters nationalist politics as a secular Congress moderate, joins the Muslim League as a bridge, and brokers the Lucknow Pact — the “ambassador of Hindu–Muslim unity.”', 'events': PHASE_UNITY},
            {'id': 'rift', 'label': '3 · The Parting of Ways', 'type': 'timeline',
             'intro': 'Gandhi’s mass politics drives the constitutionalist Jinnah from the Congress; his compromises are rejected, and after a spell of exile he returns to remake the Muslim League.', 'events': PHASE_RIFT},
            {'id': 'twonation', 'label': '4 · Two Nations', 'type': 'timeline',
             'intro': 'Jinnah embraces the Two-Nation Theory, wins the Lahore Resolution demanding Pakistan, and negotiates to deadlock with the British and Congress over India’s future.', 'events': PHASE_TWONATION},
            {'id': 'partition', 'label': '5 · Partition & Pakistan', 'type': 'timeline',
             'intro': 'Direct Action Day and communal violence make partition seem unavoidable; Pakistan is born in 1947 with Jinnah as Quaid-e-Azam, and he dies a year later, his legacy still contested.', 'events': PHASE_PARTITION,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources. As Jinnah and the Partition remain contested across India and Pakistan, this guide presents the case as both defenders and critics would frame it, without partisanship.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
