# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Mehmed II, the Conqueror."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#9d174d'  # Ottoman crimson

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_cannon():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">why the walls that stopped everyone for 1,000 years finally fell</text>'
    b += '<rect x="40" y="60" width="300" height="82" rx="12" fill="#fdecec" stroke="#b45309" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#b45309">The problem</text>'
    s1,_=_tspans(54,100,'the Theodosian Walls — triple ramparts and a moat — had repelled every siege since AD 447',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="82" rx="12" fill="#fce7f3" stroke="#9d174d" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#9d174d">The answer: Orban’s bombard</text>'
    s2,_=_tspans(394,100,'a giant bronze cannon ~8m long firing 270kg stone balls — new artillery vs old stone',10,'#9d174d',600,12,44); b+=s2
    b += '<line x1="340" y1="101" x2="378" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="172" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">The Hungarian founder Orban first offered the gun to the emperor, who could not pay. Mehmed could.</text>'
    return _wrap(W, H, 'The great cannon — gunpowder ends the age of walls', _tk(b, W, H, 'He beat a millennium-old fortress by betting on a new technology no besieger had ever massed before.'), '', AC)

def svg_goldenhorn():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1453 · the boom across the Golden Horn — and how he got past it</text>'
    boxes=[(40,'#b45309','A chain seals the harbour','a great boom blocks his fleet from the Golden Horn'),
           (270,'#9d174d','Haul ships overland','greased log roads carry ~70 ships over the hill'),
           (500,'#16a34a','Fleet appears inside','the harbour walls are now under threat too')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He could not break the chain — so he simply went around it, over dry land, and forced the defenders to split.</text>'
    return _wrap(W, H, 'Ships over a mountain — going around the chain', _tk(b, W, H, 'When you cannot break an obstacle, redefine the battlefield so the obstacle no longer matters.'), '', AC)

def svg_assault():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">29 May 1453 · the final assault in three waves</text>'
    rows=[('#94a3b8','Wave 1 · the irregulars','the azabs and Christian levies wear the defenders down'),
          ('#b45309','Wave 2 · the Anatolians','regular troops press the exhausted garrison for hours'),
          ('#9d174d','Wave 3 · the Janissaries','the elite storm in as a small gate (Kerkoporta) is left open and Giustiniani falls wounded')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="42" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+21}" r="9" fill="{c}"/><text x="62" y="{y+25}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+18}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+34,s,9.3,'#5b6472',500,11,78); b+=ss
        y+=50
    return _wrap(W, H, 'The three waves — exhaust, then break', _tk(b, W, H, 'He fed his weakest troops in first to tire the defenders, then unleashed the elite at the breaking point.'), '', AC)

def svg_millet():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">after the conquest: how to rule a city of many faiths</text>'
    b += '<rect x="40" y="60" width="300" height="82" rx="12" fill="#eef2ff" stroke="#4338ca" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#4338ca">The choice</text>'
    s1,_=_tspans(54,100,'a half-empty, ruined city of Greeks, Armenians, Jews, Latins — rule by terror, or by order?',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="82" rx="12" fill="#dcfce7" stroke="#166534" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#166534">The millet system</text>'
    s2,_=_tspans(394,100,'each faith self-governs under its own leader; he appoints a new Orthodox Patriarch and protects them',10,'#166534',600,12,44); b+=s2
    b += '<line x1="340" y1="101" x2="378" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He repopulated Istanbul by inviting people back and guaranteeing their communities — a working, functioning capital.</text>'
    return _wrap(W, H, 'Ruling the conquered — tolerance as statecraft', _tk(b, W, H, 'He conquered the city by cannon, then re-founded it by protecting the very communities he had beaten.'), '', AC)

def svg_fratricide():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the darkest clause of his law-code (Kanunname)</text>'
    left = {'title':'The danger', 'color':'#b45309',
            'lines':['every son of a sultan is a rival throne-claimant','a disputed succession means civil war (fitna)','a divided empire is a weak empire']}
    right = {'title':'The law of fratricide', 'color':'#9d174d',
             'lines':['the sultan who takes the throne may execute his brothers','one clean succession is bought at a family’s cost','“for the order of the world” — codified into law']}
    b += f'<rect x="40" y="58" width="300" height="96" rx="12" fill="#fff7ed" stroke="{left["color"]}" stroke-width="1.7"/>'
    b += f'<text x="56" y="80" font-size="11.5" font-weight="800" fill="{left["color"]}">{left["title"]}</text>'
    yy=98
    for ln in left['lines']:
        b += f'<circle cx="60" cy="{yy-3}" r="2.6" fill="{left["color"]}"/>'
        ss,_=_tspans(72,yy,ln,9.4,'#5b6472',500,12,40); b+=ss; yy+=17
    b += f'<rect x="380" y="58" width="300" height="96" rx="12" fill="#fce7f3" stroke="{right["color"]}" stroke-width="1.9"/>'
    b += f'<text x="396" y="80" font-size="11.5" font-weight="800" fill="{right["color"]}">{right["title"]}</text>'
    yy=98
    for ln in right['lines']:
        b += f'<circle cx="400" cy="{yy-3}" r="2.6" fill="{right["color"]}"/>'
        ss,_=_tspans(412,yy,ln,9.4,'#5b6472',500,12,40); b+=ss; yy+=17
    b += '<line x1="340" y1="106" x2="378" y2="106" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    return _wrap(W, H, 'The law of fratricide — stability at a terrible price', _tk(b, W, H, 'He traded the horror of killing brothers for a century of clean, war-free successions — a chilling political calculation.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE TWICE-CROWNED PRINCE
PHASE_PRINCE = [
    E('birth', '1432–1444', 'The neglected third son', ['RISE'],
      'Born the third son of Sultan Murad II and a slave-concubine, Mehmed is sent away to govern a province as a boy — an overlooked prince who devours history, languages and the lives of Alexander and Caesar.',
      svg_stack('The making of an unlikely conqueror', [
          {'n': 1, 'label': 'Third son of Murad II', 'sub': 'mother a concubine; not the obvious heir', 'color': '#9d174d'},
          {'n': 2, 'label': 'Elder brothers die', 'sub': 'he becomes heir by attrition, not favour', 'color': '#b45309'},
          {'n': 3, 'label': 'A scholar-prince', 'sub': 'reads Greek, Persian, Arabic; idolises Alexander', 'color': '#16a34a'},
      ], takeaway='An overlooked boy turned his isolation into an education — and a burning ambition to out-do Alexander.', accent=AC),
      bg='The <b>Ottoman Empire</b> under <b>Murad II</b> straddled the Balkans and Anatolia, but the Byzantine capital of <b>Constantinople</b> still stood defiantly in its heart.',
      people='His father <b>Murad II</b>; his tutors, including the scholar <b>Akshamsaddin</b> who fired his ambition; the memory of <b>Alexander the Great</b>, his lifelong model.',
      what='Mehmed was born in 1432 and, after his elder brothers died, became heir. Sent to govern <b>Amasya</b> and <b>Manisa</b> as a boy, he grew into a formidably learned, driven and secretive young man fluent in several languages.',
      crux='His unusual, bookish, somewhat neglected upbringing bred a prince of <b>immense ambition and cold self-reliance</b> — who consciously modelled himself on the world-conquerors of the past.',
      conseq='By his teens he was steeped in the idea that <b>he</b> would be the one to take Constantinople, a prize dreamt of for 800 years of Islam.',
      matters='Ambition is often forged in the margins. The overlooked child who reads about conquerors sometimes becomes one.'),

    E('varna', '1444', 'The Crusade of Varna — a boy-sultan’s baptism of fire', ['BATTLE', 'TURNING POINT'],
      'No sooner is the twelve-year-old Mehmed placed on the throne than a Christian crusade pours across the Danube to destroy the Ottomans — a terrifying crisis that forces his abdicated father back to save the state and, humiliatingly, to push the boy aside.',
      svg_stack('The crisis that unmade his first reign', [
          {'n': 1, 'label': 'Murad II abdicates, 1444', 'sub': 'the weary sultan hands the throne to his young son', 'color': '#9d174d'},
          {'n': 2, 'label': 'A crusade invades', 'sub': 'Hunyadi and King Vladislav break a truce and march', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Murad returns, wins Varna', 'sub': 'the father resumes command and crushes the crusade', 'color': '#166534'},
      ], takeaway='His first taste of rule was a near-catastrophe that exposed him — and left him burning to prove himself.', accent=AC),
      bg='In 1444 the aging <b>Murad II</b> abruptly retired, leaving the throne to his boy son. Christian powers, sensing weakness, launched a crusade in violation of a recent truce.',
      people='<b>Murad II</b>, the father recalled from retirement; <b>János Hunyadi</b> and King <b>Vladislav</b>, the crusade’s leaders; the frightened court around young Mehmed.',
      what='The <b>Crusade of Varna</b> (1444) so alarmed the government that Murad was persuaded to return and command the army. He <b>destroyed the crusaders at Varna</b>, and Mehmed was soon eased off the throne.',
      crux='The boy-sultan learned early that <b>a throne unsupported by proven strength is worthless</b> — and that he had yet to earn it.',
      conseq='Deposed and slighted, Mehmed nursed an obsession to legitimise himself by an achievement no one could deny — taking Constantinople.',
      matters='Early humiliation can forge overwhelming ambition — the wound of being found wanting drives the will to prove otherwise.'),

    E('twice', '1444–1451', 'Crowned at twelve, deposed, and crowned again', ['POLITICS', 'TURNING POINT'],
      'His father abdicates and puts the twelve-year-old Mehmed on the throne — but a crusade threatens, the boy cannot hold the state, and Murad is recalled. Only in 1451, on his father’s death, does Mehmed take power for keeps — and immediately shocks everyone.',
      svg_row('A humiliating first reign — and a ruthless second', [
          {'n': 1, 'label': 'Enthroned at 12 (1444)', 'sub': 'Murad II abdicates in his favour', 'color': '#9d174d'},
          {'n': 2, 'label': 'Crisis → father recalled', 'sub': 'the Crusade of Varna forces Murad back', 'color': '#b45309'},
          {'n': 3, 'label': 'Real accession, 1451', 'sub': 'on Murad’s death he returns — and does not stumble', 'color': '#16a34a'},
      ], edge_labels=['then', 'then'], takeaway='His first reign failed publicly at twelve — and he never forgot the humiliation of being thought too young.', accent=AC),
      bg='In <b>1444</b> the exhausted Murad II abdicated in favour of the boy Mehmed — just as a Christian <b>crusade</b> (Varna) marched east. The child-sultan’s government wobbled and the grandees demanded Murad’s return.',
      people='His father <b>Murad II</b> (recalled to save the state); the powerful Grand Vizier <b>Çandarlı Halil Pasha</b>, who distrusted the young Mehmed and favoured caution.',
      what='Mehmed’s first reign (1444–46) collapsed under crisis and was ended by his father’s recall. When Murad died in <b>1451</b>, Mehmed — now around 19 — took the throne again, this time with total resolve, ordering the ritual drowning of his infant half-brother to secure the succession.',
      crux='The <b>humiliation of his failed boy-reign</b> hardened into a determination to prove himself beyond doubt — and the fastest way to silence every doubter was to take the city no one had taken.',
      conseq='At 19, secure and underestimated, Mehmed set his entire will on one target that would either make him immortal or destroy him: <b>Constantinople</b>.',
      matters='Early humiliation can be rocket fuel. Mehmed turned the shame of being deposed as a child into an obsession to achieve the impossible.'),
]

# ==================================================================  PHASE 2 — THE CONQUEST OF CONSTANTINOPLE
PHASE_CONQUEST = [
    E('hisari', '1452', 'Building the Throat-Cutter', ['POLITICS', 'RISE'],
      'Before a single shot, he strangles the city: in a few months he throws up a massive fortress on the European shore of the Bosphorus, closing the strait so no help can reach Constantinople by sea.',
      svg_stack('Cutting the city’s lifeline first', [
          {'n': 1, 'label': 'Build Rumeli Hisarı', 'sub': 'a huge fortress on the Bosphorus’ narrowest point', 'color': '#9d174d'},
          {'n': 2, 'label': 'Command the strait', 'sub': 'cannon there can sink any passing ship', 'color': '#b45309'},
          {'n': 3, 'label': 'Isolate the city', 'sub': 'no relief or grain can come down from the Black Sea', 'color': '#16a34a'},
      ], takeaway='He won the siege’s logistics before it began — sealing the city off so no rescue could ever arrive.', accent=AC),
      bg='Constantinople depended on the sea. The <b>Bosphorus</b> was its lifeline to the Black Sea grain and to any relief from Christian Europe.',
      people='Emperor <b>Constantine XI Palaiologos</b>, watching helplessly; the Grand Vizier <b>Çandarlı Halil</b>, who still counselled against war with the Byzantines.',
      what='In 1452 Mehmed built <b>Rumeli Hisarı</b> (“Throat-Cutter”) opposite an older fortress, closing the Bosphorus in months. Its guns soon sank a Venetian ship that refused to stop — a blunt warning.',
      crux='He understood that a siege is won by <b>logistics</b>: by controlling the strait he cut every route by which the city could be relieved or resupplied, isolating it before the first assault.',
      conseq='Constantinople was now sealed off from the north. Mehmed spent the winter massing troops and the greatest artillery train yet assembled.',
      matters='Great sieges are won before they start. Mehmed strangled the city’s supply lines first, so that time itself became his weapon.'),

    E('cannon', '1452–1453', 'The gun that ended the age of walls', ['TURNING POINT'],
      'A Hungarian cannon-founder named Orban offers to build a monster bombard — first to the emperor, who cannot pay, then to Mehmed, who can. The result is a gun so vast it takes sixty oxen to move and can crack the walls that stopped the world for a thousand years.',
      svg_cannon(),
      bg='The <b>Theodosian Walls</b> — a triple line of ramparts and a moat — had repelled every attacker since the 5th century. No army had ever stormed them.',
      people='<b>Orban</b> (Urban), the Hungarian/Transylvanian gun-founder who built the great bombard after the Byzantines could not afford him; the crews and oxen-teams that served the guns.',
      what='Mehmed commissioned an <b>enormous bronze bombard</b> — some accounts give it a barrel over 8 metres long firing stone balls of ~270 kg — plus dozens of smaller guns, and used them to batter the ancient walls into rubble over weeks.',
      crux='He grasped that <b>gunpowder artillery had made stone walls obsolete</b>. Where earlier armies broke against the Theodosian Walls, Mehmed simply demolished them, betting the war on a new technology.',
      conseq='Section by section the great walls were breached and hastily repaired; the defenders, far too few, were worn down by the relentless bombardment.',
      matters='New technology quietly rewrites the old rules of the impossible. The walls that had saved the city for 1,000 years fell to a weapon their builders never imagined.'),

    E('overland', 'April 1453', 'Ships hauled over a mountain', ['BATTLE', 'TURNING POINT'],
      'A great chain seals the Golden Horn against his fleet. So Mehmed does the unthinkable: he greases a road of logs and drags some seventy ships overland, over a hill, and launches them inside the harbour — behind the chain.',
      svg_goldenhorn(),
      bg='The <b>Golden Horn</b>, the city’s harbour, was protected by a massive <b>chain (boom)</b> stretched across its mouth, keeping the Ottoman fleet out and letting the defenders concentrate on the land walls.',
      people='The <b>Genoese</b> and <b>Venetian</b> sailors defending the harbour; Mehmed’s engineers and labourers who built the log-road overnight.',
      what='Unable to break the chain, Mehmed had a <b>greased slipway of timber</b> built and, in a single astonishing operation, <b>hauled around 70 ships overland</b> from the Bosphorus into the Golden Horn, appearing inside the harbour behind the boom.',
      crux='He <b>changed the geometry of the siege</b>: with warships now inside the Horn, the defenders had to man the harbour walls too, stretching an already desperately thin garrison to the breaking point.',
      conseq='The defenders’ morale sank and their lines thinned. The city was now pressed on every side, and the final assault could be prepared.',
      matters='When you cannot force an obstacle, make it irrelevant. Mehmed’s ships-over-land remains one of history’s boldest strokes of military improvisation.'),

    E('lastemperor', 'May 1453', 'Constantine XI — the last Roman’s doomed stand', ['BATTLE', 'TRAGEDY'],
      'Against Mehmed’s vast army, the last Roman emperor defends his dying city with barely 7,000 men, refuses every offer to flee or surrender, and dies sword in hand in the final breach — ending a Roman line that stretched back fifteen centuries to Augustus.',
      svg_stack('A civilisation’s last defenders', [
          {'n': 1, 'label': '~7,000 against ~80,000', 'sub': 'a skeleton garrison holds 20 km of ancient walls', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Constantine refuses to flee', 'sub': 'rejects surrender terms; will not abandon the city', 'color': '#9d174d'},
          {'n': 3, 'label': 'Dies in the breach', 'sub': 'the last emperor falls fighting; the Roman line ends', 'color': '#78350f'},
      ], takeaway='The city fell to overwhelming force — but its last emperor chose to die as a Roman rather than surrender.', accent=AC),
      bg='By 1453 the <b>Roman (Byzantine) Empire</b> had shrunk to little more than the city itself. Emperor <b>Constantine XI Palaiologos</b> could muster only a few thousand defenders, aided by a handful of Italians.',
      people='<b>Constantine XI</b>, the last emperor; the Genoese captain <b>Giovanni Giustiniani</b>, who led the defence until wounded; the citizens and monks who manned the walls.',
      what='Constantine <b>rejected Mehmed’s surrender offers</b>, fought through the 53-day siege, and when the walls were finally breached on 29 May <b>died fighting</b> among his men — his body never certainly identified.',
      crux='He embodied the choice to <b>fall with honour rather than live in submission</b> — a defiance that ennobled the empire’s end.',
      conseq='His death closed the Roman Empire after ~1,500 years and made him a lasting symbol; legend held he would one day return as the “marble emperor.”',
      matters='How something ends shapes how it is remembered — a defiant last stand can outshine centuries of decline.'),

    E('fall', '29 May 1453', 'The fall of Constantinople', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'Before dawn on 29 May 1453 he launches the final assault in three waves. The last emperor dies sword in hand, the city falls after 1,100 years, and the twenty-one-year-old sultan rides to Hagia Sophia — now Kayser-i Rum, Caesar of Rome.',
      svg_assault(),
      bg='By late May 1453 the walls were breached in places and the ~7,000 defenders were exhausted. Mehmed offered terms; <b>Constantine XI</b> refused to surrender the city.',
      people='Emperor <b>Constantine XI</b>, who died fighting in the breach; the Genoese commander <b>Giovanni Giustiniani</b>, whose wounding broke the defence; Mehmed’s elite <b>Janissaries</b>.',
      what='In the pre-dawn assault of <b>29 May 1453</b>, Mehmed threw in three successive waves. When Giustiniani was wounded and a small gate (the <b>Kerkoporta</b>) was found open, the Janissaries poured in. The city fell; Constantine died; after three days’ sack, Mehmed entered and rode to <b>Hagia Sophia</b>.',
      crux='He combined <b>overwhelming numbers, relentless bombardment, and a layered assault</b> that exhausted the defenders before committing his elite — and exploited a moment of chaos ruthlessly.',
      conseq='The <b>Byzantine (Eastern Roman) Empire ended</b> after over a thousand years. Mehmed made the city his capital, styled himself <b>Kayser-i Rum</b> (“Caesar of Rome”), and had the Grand Vizier Çandarlı — who had opposed him — executed.',
      matters='One date closes an age: 1453 ends the medieval Roman world and opens the era of Ottoman greatness. Mehmed, at 21, had done what 800 years of would-be conquerors could not.'),
]

# ==================================================================  PHASE 3 — KAYSER-I RUM
PHASE_KAYSER = [
    E('istanbul', '1453–1460s', 'Second founder of the city', ['REFORM', 'TRIUMPH'],
      'He refuses to leave the great prize a ruin. He repopulates the half-empty city, rebuilds it, raises Topkapı Palace and the Grand Bazaar, converts Hagia Sophia to a mosque — and rules its Christians and Jews by protecting their communities.',
      svg_millet(),
      bg='The conquered city was <b>half-ruined and depopulated</b>. A great capital is worthless empty; Mehmed set out to make Istanbul the thriving heart of a world empire.',
      people='The <b>Greek Orthodox</b>, <b>Armenian</b> and <b>Jewish</b> communities he protected; the scholar-patriarch <b>Gennadios Scholarios</b>, whom Mehmed personally appointed as Orthodox Patriarch.',
      what='Mehmed <b>repopulated Istanbul</b> (inviting and resettling people of all faiths), rebuilt its infrastructure, founded the <b>Topkapı Palace</b> and the <b>Grand Bazaar</b>, converted <b>Hagia Sophia</b> into a mosque, and formalised the <b>millet system</b> — letting each religious community govern itself under its own leader.',
      crux='He understood that <b>conquest is the easy half of empire</b>: to keep the city he had to make it prosperous and stable, which meant protecting rather than persecuting its diverse peoples.',
      conseq='Istanbul rapidly grew into one of the world’s greatest cities and the capital of an empire that would last until 1922 — a cosmopolitan hub of trade, faith and culture.',
      matters='Taking a city and building a civilisation are different arts. Mehmed mastered both — the destroyer of Byzantium was also the maker of Ottoman Istanbul.'),

    E('candarli', '1453', 'Executing the old guard — breaking the Turkish aristocracy', ['POLITICS', 'TURNING POINT'],
      'His first act after the conquest is to destroy the man who had twice thwarted him: the powerful grand vizier Çandarlı Halil Pasha, head of the old Turkish noble families — executed on a charge of taking Byzantine bribes, shattering the aristocracy’s grip on the state.',
      svg_row('Replacing an aristocracy with the sultan’s slaves', [
          {'n': 1, 'label': 'Çandarlı Halil, the old-guard vizier', 'sub': 'leader of the great Turkish families; had opposed the siege', 'color': '#78350f'},
          {'n': 2, 'label': 'Charged and executed, 1453', 'sub': 'accused of Byzantine bribery; the first vizier ever put to death', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Power to the devshirme men', 'sub': 'the sultan’s slave-officials replace the noble houses', 'color': '#9d174d'},
      ], edge_labels=['then', 'so'], takeaway='Victory abroad let him win the fight at home — snapping the aristocracy’s check on his power.', accent=AC),
      bg='The old <b>Turkish noble families</b>, led by the Çandarlı dynasty of grand viziers, had long constrained the sultans and had opposed Mehmed’s reckless assault on Constantinople.',
      people='<b>Çandarlı Halil Pasha</b>, the veteran grand vizier who had doubted the siege; the rising <b>devshirme</b> statesmen who replaced the old families.',
      what='Within days of the conquest Mehmed had <b>Çandarlı Halil executed</b> — the first Ottoman grand vizier ever put to death — and thereafter filled the top offices with his own <b>slave-elite</b> rather than the hereditary nobility.',
      crux='He used the prestige of victory to <b>destroy the internal check</b> on his authority, centralising power absolutely in the throne.',
      conseq='For centuries afterward, grand viziers were the sultan’s creatures, drawn from the devshirme and dismissable at will — an absolutism Mehmed founded.',
      matters='External triumph is often spent on internal power struggles — a great victory can be the moment a ruler breaks his own rivals.'),

    E('law', '1450s–1470s', 'The Conqueror’s law — and the law of fratricide', ['REFORM', 'POLITICS'],
      'He codifies the state into a written law-code that fixes ranks, taxes and the machinery of empire — and includes its most chilling clause: the sultan who takes the throne may lawfully execute his brothers, to spare the empire from civil war.',
      svg_fratricide(),
      bg='A sprawling empire needs a settled machinery of rule and a clear rule of succession. Disputed Ottoman successions had repeatedly threatened <b>civil war (fitna)</b>.',
      people='The Ottoman <b>ulema</b> (jurists) who sanctioned the code; the future sultans whose successions the fratricide law would govern; the executed brothers of later reigns.',
      what='Mehmed issued the <b>Kanunname</b>, a comprehensive law-code organising the ranks, duties and taxes of the state — and famously codified the <b>law of fratricide</b>: “whichever of my sons inherits the throne, it is acceptable for him to kill his brothers for the order of the world.”',
      crux='He made a cold trade: <b>the horror of killing brothers</b> in exchange for <b>ending the ruinous civil wars</b> that a disputed succession would cause — stability purchased at a monstrous moral price.',
      conseq='For over a century, Ottoman successions were relatively clean and the empire avoided fracturing — until the practice was replaced by confining princes in the “cage.”',
      matters='States sometimes institutionalise terrible things in the name of order. The fratricide law is a stark case study in the ruthless logic of dynastic power.'),

    E('kayser', '1453–1481', 'Caesar of Rome — heir to an empire', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'Mehmed does not merely conquer the Roman capital — he claims to inherit Rome itself, styling himself Kayser-i Rûm, “Caesar of the Romans,” and even reinstating the Orthodox Patriarch, positioning the Ottoman sultan as the true successor of the Caesars and protector of Eastern Christianity.',
      svg_stack('Conquest reframed as inheritance', [
          {'n': 1, 'label': 'Takes the title Kayser-i Rûm', 'sub': '“Caesar of the Romans” — heir to the empire, not its destroyer', 'color': '#9d174d'},
          {'n': 2, 'label': 'Reinstates the Patriarch, 1454', 'sub': 'appoints Gennadios; protects the Orthodox Church', 'color': '#166534'},
          {'n': 3, 'label': 'Sultan and Roman emperor at once', 'sub': 'legitimacy over both Muslim and Christian subjects', 'color': '#78350f'},
      ], takeaway='He claimed to continue Rome rather than end it — turning conquest into rightful succession.', accent=AC),
      bg='Constantinople had been the Roman capital for over a thousand years. Mehmed, steeped in histories of Alexander and Caesar, saw himself as inheriting that imperial mantle.',
      people='the Orthodox scholar <b>Gennadios Scholarios</b>, whom Mehmed made Patriarch; the Greek subjects now under his protection; the wider Islamic and Christian worlds watching his claims.',
      what='Mehmed adopted the title <b>Kayser-i Rûm</b> (“Caesar of Rome”), <b>re-established the Orthodox Patriarchate</b> under Gennadios, and presented himself as the legitimate heir of the Roman emperors as well as a Muslim sultan.',
      crux='He grasped that <b>legitimacy is a story</b> — by claiming Rome’s succession he ruled Greeks and Christians as their emperor, not just their conqueror.',
      conseq='The dual identity — Islamic sultan and Roman Caesar — underpinned Ottoman claims for centuries and eased rule over a vast Christian population.',
      matters='The conqueror who claims to inherit rather than destroy can turn the vanquished into subjects who accept his right to rule.'),

    E('devshirme', '1450s–1470s', 'The slave-elite — a meritocracy of the sultan’s men', ['REFORM', 'POLITICS'],
      'He builds his state on an extraordinary institution: boys levied from Christian villages, converted, educated, and raised — as legal slaves of the sultan — into the empire’s crack Janissary infantry and its top administrators, creating a loyal governing elite that owes everything to him and nothing to birth.',
      svg_stack('Power built on the sultan’s own men', [
          {'n': 1, 'label': 'The devshirme levy', 'sub': 'Christian boys taken, converted and trained', 'color': '#9d174d'},
          {'n': 2, 'label': 'Janissaries and bureaucrats', 'sub': 'elite infantry and the empire’s administrators', 'color': '#b45309'},
          {'n': 3, 'label': 'Loyal only to the sultan', 'sub': 'a slave-elite that owes power to him alone', 'color': '#166534'},
      ], takeaway='He governed through a meritocratic slave-elite loyal to the throne alone — bypassing the old hereditary nobility entirely.', accent=AC),
      bg='To avoid dependence on a fractious hereditary aristocracy, the Ottomans developed the <b>devshirme</b> — a levy of boys raised as the sultan’s own servants.',
      people='The <b>Janissary</b> corps; the slave-administrators who rose to be grand viziers; the Christian villages from which the boys were taken.',
      what='Under Mehmed the <b>devshirme</b> system matured: <b>Christian boys were levied, converted to Islam, and trained</b> as either elite <b>Janissary</b> soldiers or high <b>administrators</b> — legally the sultan’s slaves, but able to rise to the very top on <b>merit</b> and loyalty.',
      crux='He based his power on a <b>meritocratic elite bound solely to him</b>, sidelining the hereditary nobility and giving the state exceptional cohesion and talent.',
      conseq='This slave-elite gave the Ottoman state its formidable army and administration for generations — a key to its rise and stability.',
      matters='Loyalty engineered through merit and dependence can outperform hereditary aristocracy. The devshirme is one of history’s most striking governing institutions.'),

    E('millet', '1453–1481', 'The millet system — ruling a mosaic of faiths', ['REFORM', 'POLITICS', 'TURNING POINT'],
      'To govern a city and empire of Muslims, Orthodox Greeks, Armenians and Jews, Mehmed organises each religious community as a self-governing “millet” under its own leader — granting internal autonomy in exchange for loyalty, a durable formula for ruling diversity.',
      svg_row('Self-rule for each community, loyalty to the sultan', [
          {'n': 1, 'label': 'Communities by faith', 'sub': 'Orthodox, Armenian, Jewish millets recognised', 'color': '#9d174d'},
          {'n': 2, 'label': 'Led by their own clergy', 'sub': 'patriarchs and chief rabbis govern their people’s affairs', 'color': '#166534'},
          {'n': 3, 'label': 'Autonomy for loyalty', 'sub': 'internal self-rule in return for taxes and obedience', 'color': '#78350f'},
      ], edge_labels=['each', 'gets'], takeaway='He ruled difference by devolving it — each faith governed itself, all answered to him.', accent=AC),
      bg='The empire contained many religions and peoples. Rather than force uniformity, Mehmed institutionalised diversity through the <b>millet</b> (community) system.',
      people='the <b>Orthodox Patriarch</b>, the <b>Armenian Patriarch</b>, the <b>Chief Rabbi</b>; the diverse populations of Istanbul that Mehmed actively repopulated.',
      what='Each recognised religious community was allowed to <b>run its own internal affairs</b> — law, worship, education — under a leader responsible to the sultan, in return for loyalty and taxes.',
      crux='He turned potential fault-lines into <b>manageable, self-governing units</b> — devolving religious authority while monopolising political power.',
      conseq='The millet system endured for centuries as the Ottoman answer to governing a multi-faith empire, and shaped the region’s communal structure.',
      matters='Diverse empires often survive by granting internal autonomy — ruling difference is easier than erasing it.'),

    E('learning', '1463–1470s', 'A capital of learning — the Fatih complex', ['REFORM', 'TRIUMPH'],
      'He crowns his rebuilt city with a vast religious and educational complex around his own great mosque — including eight elite madrasas, the "Sahn-ı Seman" — turning Istanbul not just into a seat of power but into a leading centre of Islamic scholarship and science.',
      svg_row('Building a centre of scholarship', [
          {'n': 1, 'label': 'The Fatih Mosque complex', 'sub': 'a grand mosque on the site of the Holy Apostles', 'color': '#9d174d'},
          {'n': 2, 'label': 'Eight elite madrasas', 'sub': 'the Sahn-ı Seman — top schools of the empire', 'color': '#b45309'},
          {'n': 3, 'label': 'A hub of learning', 'sub': 'Istanbul becomes a centre of scholarship', 'color': '#166534'},
      ], edge_labels=['plus', 'so'], takeaway='He built not just mosques but a university-city — power married to learning.', accent=AC),
      bg='A great capital needed institutions of learning as well as trade and government. Mehmed, himself highly educated, invested heavily in scholarship.',
      people='The scholars and teachers of the empire; the students of the elite madrasas; the architects of the Fatih complex.',
      what='Mehmed built the enormous <b>Fatih Mosque complex</b> (on the site of the church of the Holy Apostles), including the <b>Sahn-ı Seman — eight top madrasas</b> — making Istanbul a premier centre of <b>Islamic higher learning and science</b>.',
      crux='He understood that a true imperial capital must be a <b>centre of knowledge</b>, not just of arms and trade — and endowed it accordingly.',
      conseq='Istanbul became a magnet for scholars and a leading seat of learning in the Muslim world for centuries.',
      matters='Great capitals are built of ideas as well as stone. Mehmed’s madrasas made Istanbul a mind of the Muslim world, not just its heart of power.'),

    E('topkapi', '1459–1478', 'Topkapı — building the theatre of power', ['REFORM', 'POLITICS'],
      'Mehmed builds a new palace, Topkapı, and around it a whole ceremonial of majesty — the sultan withdrawn behind veils of protocol, ruling through a rigid court and a Divan of viziers, turning distance and silence themselves into instruments of awe and authority.',
      svg_stack('Majesty engineered in stone and ceremony', [
          {'n': 1, 'label': 'Topkapı Palace begun, 1459', 'sub': 'a new imperial seat overlooking the two seas', 'color': '#9d174d'},
          {'n': 2, 'label': 'The sultan withdrawn', 'sub': 'seclusion and elaborate protocol heighten his mystique', 'color': '#78350f'},
          {'n': 3, 'label': 'Rule through the Divan', 'sub': 'viziers govern; the silent sultan watches from behind a screen', 'color': '#166534'},
      ], takeaway='He staged his power as much as he wielded it — remoteness and ritual made the sultan seem more than human.', accent=AC),
      bg='A world empire needed a seat and a style to match. Mehmed created both, replacing the informal accessibility of earlier sultans with imperial grandeur.',
      people='the architects and craftsmen of <b>Topkapı</b>; the pages, eunuchs and viziers of the court; the ambassadors awed by its ceremony.',
      what='He built the <b>Topkapı Palace</b> and codified an elaborate court ceremonial, increasingly <b>secluding the sultan</b> behind protocol and ruling through the imperial council (Divan) — power expressed through distance.',
      crux='He understood that <b>authority is partly performance</b> — visible majesty and calculated remoteness magnify a ruler’s aura.',
      conseq='Topkapı remained the Ottoman seat of power for nearly four centuries, and the ceremonial Mehmed devised shaped the image of the sultanate.',
      matters='Power is projected as well as held — the settings and rituals of rule are themselves tools of command.'),

    E('renaissance', '1453–1481', 'A Renaissance sultan — Bellini and the wider world', ['REFORM', 'POLITICS'],
      'Uniquely among Ottoman sultans, he embraces the Renaissance world he has helped shape: fluent in several languages, fascinated by history, geography and philosophy, he collects Greek and Latin manuscripts and even summons the Venetian master Gentile Bellini to paint his portrait in the Western style.',
      svg_stack('The most cosmopolitan of sultans', [
          {'n': 1, 'label': 'A learned polyglot', 'sub': 'reads Greek, Latin, Persian, Arabic; loves history', 'color': '#9d174d'},
          {'n': 2, 'label': 'Gentile Bellini’s portrait', 'sub': 'summons a Venetian master to paint him', 'color': '#b45309'},
          {'n': 3, 'label': 'A cosmopolitan court', 'sub': 'Greek, Italian and Muslim scholars alike', 'color': '#166534'},
      ], takeaway='He was a Renaissance prince as much as a Muslim conqueror — curious about the whole world he was reshaping.', accent=AC),
      bg='Mehmed came of age as the European Renaissance flowered, and — having ended the Roman Empire — took a keen interest in the classical and Western worlds.',
      people='The Venetian painter <b>Gentile Bellini</b>, whom Mehmed hosted; the Greek and Italian scholars at his court; the geographers whose maps he studied.',
      what='Mehmed read several languages, avidly studied <b>history, geography and philosophy</b>, collected <b>Greek and Latin manuscripts</b>, and famously invited <b>Gentile Bellini</b> to Istanbul to paint his portrait in the Western manner — an unusually cosmopolitan, Renaissance-minded ruler.',
      crux='He embodied a rare <b>cultural openness</b> for a conqueror, treating the knowledge of the world he was mastering as something to absorb, not just to plunder.',
      conseq='His court became a meeting point of Islamic and European culture; his portrait by Bellini remains an iconic image.',
      matters='Curiosity can coexist with conquest. Mehmed’s Renaissance interests make him one of history’s most intellectually cosmopolitan warlords.'),

    E('character', '1432–1481', 'The scholar-conqueror — a mind steeped in Caesar', ['POLITICS', 'REFORM'],
      'The Conqueror was no mere warlord: he read and spoke several languages, pored over histories of Alexander and Caesar, questioned Italian scholars, and modelled himself consciously on the world-conquerors of antiquity — a Renaissance intellect harnessed to ruthless ambition.',
      svg_stack('A learned intellect behind the sword', [
          {'n': 1, 'label': 'A multilingual reader', 'sub': 'Turkish, Arabic, Persian, Greek, some Latin and Italian', 'color': '#9d174d'},
          {'n': 2, 'label': 'Obsessed with the ancients', 'sub': 'reads Arrian on Alexander; models himself on Caesar', 'color': '#78350f'},
          {'n': 3, 'label': 'Curious about the wider world', 'sub': 'questions Italian humanists; collects maps and books', 'color': '#166534'},
      ], takeaway='His conquests were driven by a learned imagination — he saw himself as the heir of Alexander and Caesar.', accent=AC),
      bg='Mehmed was educated by leading scholars and developed a genuine, wide-ranging intellect unusual among conquerors — one that shaped his imperial vision.',
      people='his tutor the Sufi <b>Akshamsaddin</b>; the Greek and Italian scholars he consulted; the historians of antiquity whose works he read and re-read.',
      what='He was <b>fluent in several languages</b>, studied the campaigns of <b>Alexander and Caesar</b> (reportedly having Arrian read to him), collected maps and manuscripts, and consciously cast himself as a <b>world-conqueror in the classical mould</b>.',
      crux='His ambition was fed by <b>historical imagination</b> — he measured himself against antiquity’s greatest and set out to match them.',
      conseq='This self-conception drove his relentless campaigns toward a universal empire and his patronage of learning and art.',
      matters='The most dangerous ambition is an educated one — a conqueror who has studied the greatest aims to surpass them.'),

    E('economy', '1453–1481', 'Refilling the city — trade, guilds, and the bazaar', ['REFORM', 'TRIUMPH'],
      'A capital is only as strong as its economy, so he engineers Istanbul’s revival: resettling merchants and craftsmen from across the empire, granting trading privileges to Genoese and Venetian merchants, and building the covered markets — above all the Grand Bazaar — that make the city a commercial powerhouse.',
      svg_row('Rebuilding a great commercial capital', [
          {'n': 1, 'label': 'Resettle merchants & craftsmen', 'sub': 'population and skills brought from across the empire', 'color': '#9d174d'},
          {'n': 2, 'label': 'Trading privileges granted', 'sub': 'capitulations draw Genoese and Venetian trade', 'color': '#b45309'},
          {'n': 3, 'label': 'The Grand Bazaar rises', 'sub': 'covered markets make Istanbul a commercial hub', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He deliberately rebuilt Istanbul’s economy — people, trade and markets — into a commercial powerhouse.', accent=AC),
      bg='The conquered city was depopulated and its economy shattered; Mehmed set out to make it rich as well as grand.',
      people='The resettled merchants and artisans; the Genoese and Venetian traders granted privileges; the guilds of the bazaar.',
      what='Mehmed <b>resettled traders and craftsmen</b> in Istanbul, granted <b>commercial privileges (capitulations)</b> to Italian merchants to revive trade, and built the great <b>covered markets</b> — the nucleus of the <b>Grand Bazaar</b> — turning the city into a thriving commercial centre.',
      crux='He grasped that <b>a capital must be an economic engine</b>, and used resettlement, trade privileges and infrastructure to rebuild Istanbul’s prosperity by design.',
      conseq='Istanbul grew rapidly into one of the world’s greatest commercial cities, its wealth underwriting Ottoman power.',
      matters='Grandeur without commerce is hollow. Mehmed rebuilt Istanbul’s economy as deliberately as its walls and mosques.'),

    E('army', '1451–1481', 'The war machine — a standing gunpowder army', ['REFORM', 'BATTLE'],
      'Behind every conquest lies an institution he perfects: a permanent, salaried, gunpowder-armed standing army centred on the Janissaries and a formidable artillery corps — one of the first truly modern standing armies in the world, and the engine of his relentless expansion.',
      svg_row('The institution behind the conquests', [
          {'n': 1, 'label': 'A permanent standing army', 'sub': 'salaried Janissary infantry, always ready', 'color': '#9d174d'},
          {'n': 2, 'label': 'A powerful artillery corps', 'sub': 'cannon and gunsmiths as a permanent arm', 'color': '#b45309'},
          {'n': 3, 'label': 'The engine of empire', 'sub': 'a modern army that outclasses feudal levies', 'color': '#166534'},
      ], edge_labels=['plus', 'so'], takeaway='He institutionalised gunpowder warfare into a permanent professional army — the machine that made the conquests possible.', accent=AC),
      bg='Mehmed’s conquests rested on a military system far ahead of the feudal levies of his rivals — a permanent, professional, gunpowder-based force.',
      people='The <b>Janissary</b> corps; the artillery and gunsmiths (like Orban’s successors); the disciplined household troops.',
      what='Mehmed developed a <b>permanent, salaried standing army</b> — elite <b>Janissary infantry</b> plus a strong <b>artillery corps</b> — one of the earliest modern standing armies, giving him a decisive, always-ready force his feudal enemies could not match.',
      crux='He turned military power into a <b>permanent institution</b> rather than a seasonal feudal muster — professional, disciplined and gunpowder-armed.',
      conseq='This standing army was the reliable engine of Ottoman expansion for generations after him.',
      matters='Institutions win wars over the long run. Mehmed’s standing army was as decisive as any single victory — the machine beneath the conquests.'),
]

# ==================================================================  PHASE 4 — THE CONQUEROR'S WARS
PHASE_WARS = [
    E('navy', '1453–1481', 'Building a navy — the Ottomans go to sea', ['REFORM', 'BATTLE', 'TURNING POINT'],
      'A land power by tradition, the Ottomans under Mehmed become a naval force, building fleets that seize the Aegean islands, contest the Black Sea and challenge Venice — turning the empire into a Mediterranean sea-power for the first time.',
      svg_row('From steppe cavalry to sea power', [
          {'n': 1, 'label': 'A traditionally land army', 'sub': 'Ottoman strength had been horse and gun, not ships', 'color': '#78350f'},
          {'n': 2, 'label': 'Fleets built and expanded', 'sub': 'shipyards at the Golden Horn arm a growing navy', 'color': '#9d174d'},
          {'n': 3, 'label': 'Seas contested', 'sub': 'Aegean islands taken; Black Sea closed; Venice challenged', 'color': '#0891b2'},
      ], edge_labels=['becomes', 'gains'], takeaway='He added a new dimension to Ottoman power — the empire learned to fight and rule at sea.', accent=AC),
      bg='Controlling Constantinople and a long coastline demanded sea power. Venice and Genoa dominated the eastern Mediterranean trade Mehmed meant to master.',
      people='the Ottoman admirals and shipwrights; the Genoese and Venetian fleets they contested; the islanders of the Aegean brought under Ottoman rule.',
      what='Mehmed invested heavily in a <b>navy</b>, taking Aegean islands, tightening control of the <b>Black Sea</b> (including Genoese Caffa in 1475), and waging naval war against <b>Venice</b> — establishing the Ottomans as a maritime power.',
      crux='He recognised that a Mediterranean empire needed <b>command of the sea</b>, and built the capacity his predecessors had lacked.',
      conseq='Ottoman naval power grew until, in the next century, it dominated the eastern Mediterranean — a trajectory Mehmed launched.',
      matters='Expanding powers must master new domains — a land empire that means to rule coasts must first learn to rule the sea.'),

    E('venice', '1463–1479', 'The long war with Venice', ['BATTLE', 'TRIUMPH'],
      'His expansion collides with the great maritime republic of Venice in a sixteen-year war for the eastern Mediterranean — he seizes the rich island of Negroponte, builds a real Ottoman navy, and finally forces proud Venice to buy peace, confirming the Ottomans as a sea power as well as a land empire.',
      svg_row('Breaking into the maritime world', [
          {'n': 1, 'label': 'War with Venice', 'sub': 'a 16-year struggle for the eastern seas', 'color': '#9d174d'},
          {'n': 2, 'label': 'Negroponte taken, 1470', 'sub': 'Venice’s key Aegean island stormed', 'color': '#b45309'},
          {'n': 3, 'label': 'Venice sues for peace, 1479', 'sub': 'the republic pays tribute; Ottomans a sea power', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He forced the Mediterranean’s greatest naval republic to accept the Ottomans as its equal at sea.', accent=AC),
      bg='<b>Venice</b> dominated eastern Mediterranean trade and held island colonies athwart Ottoman expansion; conflict was inevitable.',
      people='The Venetian Republic and its fleet; the defenders of <b>Negroponte (Euboea)</b>; the Ottoman shipwrights building a new navy.',
      what='The <b>Ottoman–Venetian War (1463–79)</b> saw Mehmed seize <b>Negroponte (1470)</b> and other holdings and build up a serious <b>navy</b>. After years of raiding and stalemate, <b>Venice made peace in 1479</b>, ceding territory and paying tribute for trading rights.',
      crux='He recognised that a Mediterranean empire needed <b>sea power</b>, and invested in a navy that turned the Ottomans from a land force into a maritime one.',
      conseq='The Ottomans emerged as a major naval power; the war’s end freed Mehmed to strike even at Italy itself.',
      matters='Great land empires must eventually master the sea. Mehmed’s long war with Venice began the Ottoman rise to Mediterranean dominance.'),

    E('mopup', '1454–1461', 'Erasing what was left of the Roman world', ['BATTLE', 'TRIUMPH'],
      'Constantinople was only the beginning. He mops up the last Byzantine splinters — the Despotate of the Morea, and the mountain empire of Trebizond — and swallows Serbia and Bosnia, pushing the frontier deep into the Balkans.',
      svg_row('Extinguishing the last Roman remnants', [
          {'n': 1, 'label': 'Serbia and the Morea', 'sub': 'annexes Serbia; conquers the Peloponnese', 'color': '#9d174d'},
          {'n': 2, 'label': 'Trebizond, 1461', 'sub': 'the last Byzantine successor state falls', 'color': '#b45309'},
          {'n': 3, 'label': 'Bosnia, 1463', 'sub': 'the Balkan frontier pushed deep west', 'color': '#16a34a'},
      ], edge_labels=['then', 'then'], takeaway='He hunted down every surviving fragment of the Roman world until none was left to rally around.', accent=AC),
      bg='After 1453, scattered <b>Byzantine successor states</b> survived: the <b>Despotate of the Morea</b> (Peloponnese) and the <b>Empire of Trebizond</b> on the Black Sea, plus the Balkan Christian kingdoms.',
      people='The rival Palaiologos despots of the Morea; the last emperor of <b>Trebizond</b>, David Komnenos; the Serbian and Bosnian rulers he deposed.',
      what='Through the late 1450s Mehmed annexed <b>Serbia</b>, conquered the <b>Morea</b> (1460), and in <b>1461</b> took <b>Trebizond</b> — the very last Byzantine remnant — then absorbed <b>Bosnia</b> (1463).',
      crux='He was determined to leave <b>no surviving Roman polity</b> that could ever serve as a rallying point for a restoration, methodically extinguishing each fragment.',
      conseq='The Eastern Roman world was wholly gone; the Ottoman Balkans stretched from the Danube toward the Adriatic.',
      matters='A conqueror thinks past the great victory to the loose ends. Mehmed made sure the empire he ended could never be pieced back together.'),

    E('rivals', '1462–1475', 'Vlad the Impaler, Uzun Hasan, and the Crimea', ['BATTLE', 'TRIUMPH', 'DEFEAT'],
      'His wars sprawl across three continents’ worth of enemies: the horror of Vlad the Impaler’s forest of stakes in Wallachia, the great eastern rival Uzun Hasan crushed at Otlukbeli, and the Crimean Khanate turned into a vassal that guards the Black Sea.',
      svg_row('Enemies on every frontier', [
          {'n': 1, 'label': 'Vlad III, 1462', 'sub': 'Wallachia’s “Impaler” and his forest of stakes', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Uzun Hasan, 1473', 'sub': 'the eastern rival smashed at Otlukbeli by cannon', 'color': '#9d174d'},
          {'n': 3, 'label': 'Crimea, 1475', 'sub': 'the Khanate made a vassal; Black Sea an Ottoman lake', 'color': '#16a34a'},
      ], edge_labels=['also', 'also'], takeaway='He fought on every frontier at once — and turned the Black Sea into an Ottoman lake.', accent=AC),
      bg='Mehmed’s empire now bordered many powers: <b>Wallachia</b> (Vlad III Dracula), the <b>Aq Qoyunlu</b> confederation of <b>Uzun Hasan</b> in the east, Venice, Hungary, and the <b>Crimean Khanate</b>.',
      people='<b>Vlad III “the Impaler”</b>, whose brutal resistance shook even Mehmed; <b>Uzun Hasan</b>, the powerful Aq Qoyunlu ruler backed by Venice; the <b>Giray</b> khans of Crimea.',
      what='Mehmed invaded <b>Wallachia</b> in 1462 (recoiling at Vlad’s field of impaled prisoners but installing a client), destroyed <b>Uzun Hasan’s</b> army at <b>Otlukbeli (1473)</b> with his firearms and artillery, and in <b>1475</b> seized the Genoese colony of <b>Caffa</b> and made the <b>Crimean Khanate</b> an Ottoman vassal.',
      crux='His decisive edge repeatedly proved to be <b>gunpowder and disciplined Janissaries</b> against traditional cavalry — as at Otlukbeli — while diplomacy turned the Crimea into a client guarding his northern flank.',
      conseq='The Ottomans dominated the Black Sea and eastern Anatolia; the empire was now the paramount power of the eastern Mediterranean world.',
      matters='Empire is endless war on many fronts at once. Mehmed’s reign shows the relentless, all-directional pressure that expansion demands.'),

    E('anatolia', '1468–1474', 'Uniting Anatolia — swallowing Karaman', ['BATTLE', 'TRIUMPH'],
      'Even as he conquers in Europe, he completes the work of unifying Turkish Anatolia at home — annexing the last great rival Turkish emirate, the Karamanids, and absorbing the smaller principalities, so that for the first time almost all of Asia Minor answers to a single Ottoman sultan.',
      svg_row('Ending the age of the Anatolian emirates', [
          {'n': 1, 'label': 'The Karamanid rival', 'sub': 'the last major Turkish emirate in Anatolia', 'color': '#9d174d'},
          {'n': 2, 'label': 'Annexed, 1468–74', 'sub': 'Karaman absorbed after hard campaigns', 'color': '#b45309'},
          {'n': 3, 'label': 'Anatolia unified', 'sub': 'almost all Asia Minor under one sultan', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He finished uniting the Turkish heartland — the essential base beneath all his European glory.', accent=AC),
      bg='Anatolia was long divided among rival Turkish <b>beyliks</b> (emirates); the strongest, the <b>Karamanids</b>, contested Ottoman supremacy.',
      people='The <b>Karamanid</b> rulers; the smaller Anatolian principalities absorbed into the empire.',
      what='Through campaigns in <b>1468–74</b>, Mehmed <b>annexed the Karamanid emirate</b> and mopped up lesser beyliks, bringing nearly all of <b>Anatolia</b> under direct Ottoman rule for the first time.',
      crux='He secured the <b>Turkish heartland</b> that underpinned his empire — European conquests meant little without a united Asian base and manpower.',
      conseq='A unified Anatolia gave the empire depth, manpower and security behind its European front.',
      matters='Glory abroad rests on a secure home. Mehmed’s unification of Anatolia was the quiet foundation of his more famous conquests.'),

    E('skanderbeg', '1466–1478', 'The Albanian thorn — Skanderbeg’s long defiance', ['BATTLE', 'DEFEAT'],
      'One small enemy defies him for years: the brilliant Albanian captain Skanderbeg, who repeatedly throws back Ottoman armies from his mountain strongholds. Only after Skanderbeg’s death does Mehmed finally break Albanian resistance and storm the fortress of Krujë.',
      svg_row('The one foe who kept beating him', [
          {'n': 1, 'label': 'Skanderbeg resists', 'sub': 'Albania’s captain repels Ottoman armies for years', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Krujë holds out', 'sub': 'repeated sieges of the mountain fortress fail', 'color': '#b45309'},
          {'n': 3, 'label': 'Broken after his death', 'sub': 'Albania finally falls once Skanderbeg dies', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='A single gifted mountain captain frustrated the Conqueror for years — proof that terrain and genius can offset numbers.', accent=AC),
      bg='In the mountains of <b>Albania</b>, the warrior <b>Skanderbeg (George Kastrioti)</b> led a stubborn, skilful resistance to Ottoman expansion.',
      people='<b>Skanderbeg</b>, the celebrated Albanian commander; the defenders of the fortress of <b>Krujë</b>; Venice, which backed the resistance.',
      what='Skanderbeg <b>repeatedly repelled Ottoman armies</b> from Albania’s mountains, and <b>Krujë withstood several sieges</b>. Only after Skanderbeg’s death (1468) did Mehmed’s forces gradually break the resistance and take <b>Krujë (1478)</b>.',
      crux='He learned the hard way that <b>terrain and a brilliant defender</b> could blunt even Ottoman power — a rare, prolonged check on his conquests.',
      conseq='Albania was eventually subdued, but Skanderbeg became an enduring symbol of resistance in the Balkans and beyond.',
      matters='Numbers are not everything. Skanderbeg’s defiance is a classic study in how skill and mountains can hold off a great empire for years.'),

    E('bosnia', '1463', 'Bosnia — conquest and conversion', ['BATTLE', 'REFORM'],
      'He swiftly conquers the kingdom of Bosnia and executes its last king — but the deeper legacy is religious: over the following generations, unusually, much of the Bosnian population converts to Islam, leaving a Muslim community in the heart of Europe that endures to this day.',
      svg_row('A conquest with a lasting religious legacy', [
          {'n': 1, 'label': 'Bosnia conquered, 1463', 'sub': 'the kingdom overrun; its last king executed', 'color': '#9d174d'},
          {'n': 2, 'label': 'Ottoman rule settles in', 'sub': 'the land integrated into the empire', 'color': '#b45309'},
          {'n': 3, 'label': 'Widespread conversion', 'sub': 'much of the population becomes Muslim over time', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='His Bosnian conquest left a rare, lasting Muslim community in the European heartland.', accent=AC),
      bg='The Christian kingdom of <b>Bosnia</b> lay in Mehmed’s path of Balkan expansion.',
      people='The last Bosnian king, executed after surrender; the Bosnian population, much of which later converted to Islam.',
      what='Mehmed <b>conquered Bosnia in 1463</b> and executed its last king. Unusually among Ottoman conquests, a large share of the <b>Bosnian population converted to Islam</b> over the following generations, creating a durable European Muslim community.',
      crux='Beyond the military conquest, Bosnia shows the <b>lasting cultural and religious transformation</b> Ottoman rule could bring to a conquered land.',
      conseq='Bosnia became a distinctive Muslim-majority region of Europe, a legacy visible to the present day.',
      matters='Conquest can reshape identity for centuries. Mehmed’s Bosnia is the clearest case of the Ottomans’ lasting religious imprint on Europe.'),

    E('moldavia', '1475–1476', 'Checked in the north — Stephen the Great', ['BATTLE', 'DEFEAT', 'TRIUMPH'],
      'His northern expansion meets another formidable foe: Stephen the Great of Moldavia, who annihilates an Ottoman army at Vaslui in one of the worst defeats of Mehmed’s reign — forcing the Conqueror himself to march north the next year to salvage the situation.',
      svg_row('A humiliating defeat, then a counter-march', [
          {'n': 1, 'label': 'Vaslui, 1475', 'sub': 'Stephen destroys a large Ottoman army', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Mehmed marches north', 'sub': 'leads the army himself in 1476 to recover', 'color': '#9d174d'},
          {'n': 3, 'label': 'A costly, partial win', 'sub': 'beats Stephen in the field but cannot hold Moldavia', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='Even the Conqueror suffered disasters — Stephen the Great’s Vaslui was among the worst defeats of his reign.', accent=AC),
      bg='<b>Moldavia</b>, under <b>Stephen the Great</b>, resisted Ottoman domination on the empire’s northern frontier.',
      people='<b>Stephen the Great</b> of Moldavia, a brilliant defensive commander; the Ottoman army destroyed at Vaslui.',
      what='At <b>Vaslui (1475)</b>, Stephen <b>annihilated a large Ottoman army</b> — a stunning defeat. Mehmed personally led a punitive campaign in <b>1476</b>, beating Stephen at Valea Albă, but <b>could not subdue Moldavia</b>, which remained defiant.',
      crux='It was a reminder that his run of conquest had <b>real limits</b>, and that gifted regional defenders could inflict serious defeats.',
      conseq='Moldavia survived as an autonomous, tribute-paying principality rather than a conquered province.',
      matters='No conqueror is invincible. Stephen the Great’s Vaslui stands with Rhodes and Belgrade among the checks on Mehmed’s power.'),
]

# ==================================================================  PHASE 5 — ITALY AND DEATH
PHASE_END = [
    E('rhodes', '1480', 'Rhodes — the fortress that held', ['BATTLE', 'DEFEAT'],
      'In the same year his troops land in Italy, Mehmed hurls an army at Rhodes, stronghold of the Knights of St John — but the Knights’ formidable fortifications and desperate defence repel every assault, handing the Conqueror one of his rare, stinging failures.',
      svg_stack('The limits of the Conqueror', [
          {'n': 1, 'label': 'The Knights of St John', 'sub': 'a crusading order fortifies the island of Rhodes', 'color': '#166534'},
          {'n': 2, 'label': 'Ottoman siege, 1480', 'sub': 'artillery and assaults batter the walls for months', 'color': '#9d174d'},
          {'n': 3, 'label': 'The assault is thrown back', 'sub': 'the Knights hold; the siege is abandoned', 'color': '#b91c1c'},
      ], takeaway='Even the taker of Constantinople could be stopped — a well-led fortress defied all his firepower.', accent=AC),
      bg='The Knights Hospitaller of <b>St John</b>, based on Rhodes, harried Ottoman shipping and stood as a crusader outpost. Mehmed resolved to remove them.',
      people='Grand Master <b>Pierre d’Aubusson</b>, who led the defence; the Knights and Rhodian townsfolk; the Ottoman besiegers under Mesih Pasha.',
      what='In 1480 a large Ottoman force besieged <b>Rhodes</b>, but the Knights’ powerful fortifications and stubborn resistance <b>repulsed the final assault</b>, and the Ottomans withdrew — a notable defeat.',
      crux='He learned that <b>determined defenders behind modern fortifications</b> could blunt even his siege power — walls had adapted to cannon.',
      conseq='Rhodes held until 1522 (when Suleiman finally took it); the 1480 failure showed the limits of Mehmed’s reach even at his peak.',
      matters='No conqueror is invincible — a well-defended strongpoint can defy the greatest army and puncture the myth of unstoppability.'),

    E('italy', '1480', 'Otranto and the reach for Rome', ['BATTLE', 'TRIUMPH'],
      'At the height of his power he strikes at Italy itself — his troops storm Otranto and massacre its defenders, and all Christendom fears he means to march on Rome — while his failure to take Rhodes shows even the Conqueror had limits.',
      svg_compare('The last campaigns — triumph and check',
          {'head': 'Otranto (1480)', 'color': '#16a34a',
           'items': ['Ottoman troops land in southern Italy', 'storm Otranto; the defenders massacred', 'the Pope contemplates fleeing Rome']},
          {'head': 'Rhodes (1480)', 'color': '#b45309',
           'items': ['besieges the Knights Hospitaller’s fortress', 'the Knights hold; the siege fails', 'a rare check on his run of conquest']},
          verdict='One foot in Italy, one bloody repulse at Rhodes — reach and first limits in a single year.',
          takeaway='He carried the war into Italy itself — and Christendom braced for a march on Rome that his death would cancel.', accent=AC),
      bg='By 1480 Mehmed dominated the eastern Mediterranean and turned toward the west — the <b>Knights of Rhodes</b> and the Italian mainland itself.',
      people='The <b>Knights Hospitaller</b> who held Rhodes; the people of <b>Otranto</b>; a terrified <b>Pope Sixtus IV</b>, who considered abandoning Rome.',
      what='In 1480 Ottoman forces <b>besieged Rhodes</b> (and failed) but <b>captured Otranto</b> in southern Italy, massacring much of the population — raising real fear that Mehmed intended to conquer <b>Rome</b> and “reunite” the Roman Empire.',
      crux='He was reaching for the ultimate prize implicit in his title <b>Kayser-i Rum</b>: the old <b>Rome</b> itself — an ambition of Alexandrian scale.',
      conseq='The Italian bridgehead terrified Europe — but it would not outlive its author.',
      matters='Even the greatest conqueror meets the edge of his reach and his lifespan. Mehmed’s dream of taking Rome died with him.'),

    E('cem', '1481–1495', 'The sons’ war foreshadowed — Bayezid and Cem', ['POLITICS', 'TRAGEDY'],
      'Mehmed’s absolutism leaves the succession to a violent lottery between his sons — the cautious Bayezid and the brilliant, cultured Cem — and his death touches off a civil war whose loser ends up a prized hostage of Europe, a pawn against the very empire his father built.',
      svg_stack('The unresolved cost of fratricidal succession', [
          {'n': 1, 'label': 'Two rival sons', 'sub': 'Bayezid, the elder and steadier; Cem, gifted and popular', 'color': '#9d174d'},
          {'n': 2, 'label': 'Civil war on Mehmed’s death', 'sub': 'the brothers fight; Bayezid prevails', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Cem, hostage of Europe', 'sub': 'the loser held by the Pope and others as a bargaining chip', 'color': '#78350f'},
      ], takeaway='The law that made the sultan absolute also made every succession a war — and this one nearly armed Europe against the empire.', accent=AC),
      bg='Mehmed had legalised fratricide to prevent divided rule, but left no orderly succession. His two capable sons, <b>Bayezid</b> and <b>Cem</b>, were natural rivals.',
      people='<b>Bayezid II</b>, the victor; <b>Cem Sultan</b>, the cultured loser; the Knights of Rhodes and the <b>Pope</b>, who later held Cem as a hostage against the Ottomans.',
      what='Mehmed’s death in 1481 triggered a <b>civil war</b> between his sons. Bayezid won; <b>Cem</b> fled and became a long-held <b>hostage in Europe</b>, used as leverage to deter Ottoman attacks for years.',
      crux='The absolutism Mehmed built had a fatal seam: <b>no peaceful succession</b>, so each transfer of power risked civil war and foreign meddling.',
      conseq='The Cem affair constrained Bayezid’s early reign; the succession problem shadowed the dynasty until later reforms.',
      matters='Concentrating all power in one person postpones the question of what happens when that person dies — often violently.'),

    E('death', '3 May 1481', 'Death of the Conqueror', ['DEATH', 'TRAGEDY'],
      'At forty-nine, setting out on yet another secret campaign — perhaps against the Mamluks, perhaps Italy — he dies suddenly in camp, so abruptly that many whisper of poison. Otranto is abandoned; his sons fight for the throne.',
      svg_row('The sudden end of a relentless reign', [
          {'n': 1, 'label': 'A final secret campaign', 'sub': 'marches east in 1481; the target undisclosed', 'color': '#9d174d'},
          {'n': 2, 'label': 'Dies in camp', 'sub': 'suddenly, aged 49 — rumours of poison', 'color': '#111827'},
          {'n': 3, 'label': 'Succession war', 'sub': 'sons Bayezid and Cem fight; Otranto lost', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='The tireless Conqueror died mid-march, his final target a secret he took to the grave.', accent=AC),
      bg='Mehmed never stopped campaigning. In 1481 he set out from Istanbul on another great expedition, its target kept secret even from his commanders.',
      people='His sons <b>Bayezid II</b> and <b>Cem</b>, who fought a civil war for the throne; the physicians whose treatment (or, some claimed, poison) failed to save him.',
      what='On <b>3 May 1481</b>, only a short march from the capital, Mehmed fell gravely ill and died, aged 49. The suddenness — and his long list of enemies — fed persistent rumours that he was <b>poisoned</b>.',
      crux='His empire, vastly expanded and reorganised, was <b>strong enough to survive his death intact</b> — unlike Alexander’s or Timur’s — precisely because he had built durable institutions, not just conquered land.',
      conseq='After a succession struggle, <b>Bayezid II</b> took the throne; the Otranto foothold was given up, but the empire Mehmed built endured and grew for centuries.',
      matters='The measure of a conqueror is what survives him. Mehmed left not a body of conquests that dissolved, but a lasting empire and a world capital.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Mehmed II — <b>el-Fātiḥ</b>, “the Conqueror” — took Constantinople at twenty-one, ending the thousand-year Roman Empire and turning the Ottoman state into a world empire with a world capital. He is a study in <b>ambition forged from humiliation, technology beating tradition, and the double art of conquering a city and then building a civilisation on its ruins.</b></p>
<div class="ov-quote">“There should be only one empire, one faith, and one sovereignty in the world.”<span>— sentiment attributed to Mehmed II</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A neglected scholar-prince is crowned at twelve and deposed → returns at nineteen obsessed with one prize → seals off Constantinople and batters its ancient walls with a giant cannon → drags his fleet overland past the harbour chain → storms the city in 1453 and becomes “Caesar of Rome” → rebuilds Istanbul and rules its faiths by the millet system → erases the last Byzantine remnants and fights on every frontier → reaches into Italy itself → dies suddenly at 49, leaving a durable empire.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🔥</div><h4>1453 ends an age</h4><p>The fall of Constantinople closed the medieval Roman world and is a hinge of world history.</p></div>
  <div class="ov-card"><div class="i">⚙️</div><h4>Technology beats tradition</h4><p>His great cannon proved gunpowder had made even the mightiest walls obsolete.</p></div>
  <div class="ov-card"><div class="i">🕌</div><h4>Conqueror and builder</h4><p>He didn’t just take the city — he re-founded it as a cosmopolitan capital that lasted 450 years.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>Order at a price</h4><p>His law-code, and its chilling fratricide clause, show the ruthless logic of dynastic stability.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Twice-Crowned Prince</b><small> 1432–51</small><p>Neglected boy, crowned at 12, deposed, and back for keeps.</p></div>
  <div><b>2 · The Conquest</b><small> 1452–53</small><p>The fortress, the cannon, the ships overland, the fall.</p></div>
  <div><b>3 · Kayser-i Rum</b><small> 1453–70s</small><p>Rebuilding Istanbul; the millet system and the law-code.</p></div>
  <div><b>4 · The Conqueror’s Wars</b><small> 1454–75</small><p>Trebizond, Vlad, Uzun Hasan, the Black Sea.</p></div>
  <div><b>5 · Italy and Death</b><small> 1480–81</small><p>Otranto, Rhodes, and a sudden end at 49.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Murad II', 'role': 'father / sultan', 'color': '#7c2d12',
     'bio': 'Mehmed’s father, a capable and war-weary sultan who twice ruled — abdicating in Mehmed’s favour in 1444 and returning to save the state when the boy could not hold it.',
     'rel': 'The father whose recall humiliated the boy-sultan and steeled his ambition.'},
    {'name': 'Constantine XI', 'role': 'last Roman emperor', 'color': '#b45309',
     'bio': 'The last Byzantine emperor, who refused Mehmed’s terms and died fighting in the breach on 29 May 1453 — the final Caesar of a thousand-year line.',
     'rel': 'The defender whose death marked the end of the Roman Empire.'},
    {'name': 'Çandarlı Halil Pasha', 'role': 'grand vizier / rival', 'color': '#6b7280',
     'bio': 'The powerful, cautious Grand Vizier who distrusted the young Mehmed and opposed the siege. After the conquest, Mehmed had him executed — breaking the old vizier dynasty’s grip.',
     'rel': 'The establishment rival whom victory allowed Mehmed to destroy.'},
    {'name': 'Orban', 'role': 'gun-founder', 'color': '#9d174d',
     'bio': 'A Hungarian/Transylvanian cannon-founder who first offered his services to the Byzantines and, when they could not pay, built Mehmed’s giant bombards — the guns that broke the walls.',
     'rel': 'The engineer whose technology decided the siege.'},
    {'name': 'Giovanni Giustiniani', 'role': 'defence commander', 'color': '#0e7490',
     'bio': 'The Genoese soldier who led the city’s defence with great skill. His wounding during the final assault broke the defenders’ morale at the decisive moment.',
     'rel': 'The defender whose fall opened the door to the Janissaries.'},
    {'name': 'Gennadios Scholarios', 'role': 'Orthodox Patriarch', 'color': '#166534',
     'bio': 'A leading Byzantine scholar whom Mehmed personally installed as Orthodox Patriarch after the conquest — the human face of the millet system that protected the city’s Christians.',
     'rel': 'The churchman through whom Mehmed ruled his Orthodox subjects.'},
]

KEY_EVENTS = [
    ('1432', 'Born, third son of Murad II', 'A neglected prince who idolised Alexander.'),
    ('1444', 'Enthroned at twelve', 'His first reign collapses; his father is recalled.'),
    ('1451', 'Accession for keeps', 'Returns at ~19 with total resolve.'),
    ('1452', 'Rumeli Hisarı built', 'The Bosphorus sealed; the city cut off.'),
    ('1453', 'The great cannon batters the walls', 'Orban’s bombard makes stone walls obsolete.'),
    ('Apr 1453', 'Ships hauled overland', '~70 ships dragged into the Golden Horn.'),
    ('29 May 1453', 'Fall of Constantinople', 'The Roman Empire ends; Mehmed is “Caesar of Rome.”'),
    ('1453+', 'Re-founding Istanbul', 'Repopulation, Topkapı, the millet system.'),
    ('1461', 'Trebizond falls', 'The last Byzantine successor state is erased.'),
    ('1462', 'Vlad the Impaler campaign', 'Wallachia’s forest of stakes.'),
    ('1473', 'Otlukbeli', 'Uzun Hasan crushed by Ottoman firearms.'),
    ('1475', 'Crimea vassalised', 'The Black Sea becomes an Ottoman lake.'),
    ('1480', 'Otranto and Rhodes', 'A foothold in Italy; a failed siege of Rhodes.'),
    ('3 May 1481', 'Death of the Conqueror', 'Dies suddenly at 49 on a secret campaign.'),
]

MASTER = [
    {'year': '1432', 'age': 'born', 'phase': 'The Prince', 'title': 'Born to Murad II', 'desc': 'A neglected third son.'},
    {'year': '1444', 'age': 'age 12', 'phase': 'The Prince', 'title': 'Crowned and deposed', 'desc': 'His father is recalled.'},
    {'year': '1451', 'age': 'age ~19', 'phase': 'The Prince', 'title': 'Accession for keeps', 'desc': 'Returns with total resolve.'},
    {'year': '1452', 'age': 'age ~20', 'phase': 'Conquest', 'title': 'Rumeli Hisarı', 'desc': 'The Bosphorus is sealed.'},
    {'year': '1453', 'age': 'age 21', 'phase': 'Conquest', 'title': 'Fall of Constantinople', 'desc': 'The Roman Empire ends.'},
    {'year': '1461', 'age': 'age ~29', 'phase': 'The Wars', 'title': 'Trebizond falls', 'desc': 'The last Byzantine remnant.'},
    {'year': '1473', 'age': 'age ~41', 'phase': 'The Wars', 'title': 'Otlukbeli', 'desc': 'Uzun Hasan crushed.'},
    {'year': '1480', 'age': 'age ~48', 'phase': 'The End', 'title': 'Otranto', 'desc': 'A foothold in Italy.'},
    {'year': '1481', 'age': 'age 49', 'phase': 'The End', 'title': 'Death of the Conqueror', 'desc': 'Dies on a secret campaign.'},
]

SOURCES = [
    ('Britannica — Mehmed II', 'https://www.britannica.com/biography/Mehmed-II-Ottoman-sultan'),
    ('World History Encyclopedia — Mehmed II', 'https://www.worldhistory.org/Mehmed_II/'),
    ('Britannica — Fall of Constantinople (1453)', 'https://www.britannica.com/event/Fall-of-Constantinople-1453'),
    ('Wikipedia — Mehmed the Conqueror', 'https://en.wikipedia.org/wiki/Mehmed_the_Conqueror'),
]

def build_meta():
    return {
        'pid': 'gm-mehmed2.html', 'kind': 'man', 'emoji': '\U0001f54c', 'accent': AC,
        'name': 'Mehmed II', 'years': '1432–1481', 'group': 'Ottoman Sultans',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The scholar-prince who took Constantinople at twenty-one, ended the Roman Empire, and re-founded Istanbul as the capital of a world empire.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'prince', 'label': '1 · The Twice-Crowned Prince', 'type': 'timeline',
             'intro': 'A neglected scholar-prince is crowned at twelve, fails, is deposed by his own father’s recall — and returns at nineteen with an obsession to prove himself by taking the city no one could take.', 'events': PHASE_PRINCE},
            {'id': 'conquest', 'label': '2 · The Conquest', 'type': 'timeline',
             'intro': 'He seals off Constantinople, batters its ancient walls with the greatest cannon yet built, drags his fleet overland past the harbour chain — and on 29 May 1453 ends the thousand-year Roman Empire.', 'events': PHASE_CONQUEST},
            {'id': 'kayser', 'label': '3 · Kayser-i Rum', 'type': 'timeline',
             'intro': 'He refuses to leave his prize a ruin: repopulating and rebuilding Istanbul, ruling its many faiths by the millet system, and codifying the state — including the chilling law of fratricide.', 'events': PHASE_KAYSER},
            {'id': 'wars', 'label': '4 · The Conqueror’s Wars', 'type': 'timeline',
             'intro': 'Constantinople was only the beginning: he erases the last Byzantine remnants, faces Vlad the Impaler and Uzun Hasan, and turns the Black Sea into an Ottoman lake.', 'events': PHASE_WARS},
            {'id': 'end', 'label': '5 · Italy and Death', 'type': 'timeline',
             'intro': 'At the height of his power he reaches into Italy itself — and dies suddenly at forty-nine on a secret campaign, leaving behind not a dissolving heap of conquests but a durable empire.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Casualty and cannon figures for 1453 vary between contemporary chronicles; this guide follows the mainstream scholarly consensus.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
