# -*- coding: utf-8 -*-
"""Full birth-to-death guide content for Vladimir Lenin."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b91c1c'  # revolutionary red

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_vanguard2():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1903 · the split that created the Bolsheviks</text>'
    def col(x, head, c, items):
        h = 40 + len(items)*22 + 10
        s = f'<rect x="{x}" y="58" width="300" height="{h}" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        s += f'<rect x="{x}" y="58" width="300" height="28" rx="12" fill="{c}"/><rect x="{x}" y="72" width="300" height="14" fill="{c}"/>'
        s += f'<text x="{x+14}" y="77" font-size="12" font-weight="800" fill="#fff">{esc(head)}</text>'
        yy=104
        for it in items:
            s += f'<circle cx="{x+16}" cy="{yy-4}" r="3" fill="{c}"/>'
            ln,_=_tspans(x+26,yy,it,10.4,'#334155',500,12,46); s+=ln; yy+=22
        return s
    b += col(40,'Mensheviks — broad & patient','#64748b',['open mass party','wait for capitalism to ripen','democratic, loose'])
    b += col(380,'Bolsheviks — Lenin’s vanguard','#b91c1c',['small core of pros','seize the moment, force history','centralised & disciplined'])
    b += '<text x="360" y="70" font-size="15" font-weight="800" fill="#94a3b8" text-anchor="middle">vs</text>'
    return _wrap(W, H, 'The vanguard party — Lenin’s real invention', _tk(b, W, H, 'A small, disciplined, professional core can seize power a big loose movement never could.'), '', AC)

def svg_october():
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1917 · why the Bolsheviks won when they were a minority</text>'
    boxes=[(40,'#b45309','WWI shatters Russia','millions dead; hunger; army mutinies'),
           (270,'#64748b','Weak Provisional Govt','keeps fighting the war → loses all support'),
           (500,'#b91c1c','Bolsheviks seize key points','“Peace, Land, Bread”; take Petrograd')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="76" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="82" font-size="11" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,100,s,9.6,'#5b6472',500,11,30); b+=ss
    b += '<line x1="220" y1="98" x2="268" y2="98" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="98" x2="498" y2="98" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Not a mass uprising — a disciplined minority grabbing power in a vacuum with the right slogans.</text>'
    return _wrap(W, H, 'October 1917 — seizing the vacuum', _tk(b, W, H, 'Revolutions are won by the organised few in the chaos, not the many — if you offer what people desperately want.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1
PHASE_RADICAL = [
    E('brother', '1887', 'A hanged brother — the making of a revolutionary', ['RISE', 'TRAGEDY', 'TURNING POINT'],
      'When the Tsar executes his beloved older brother for plotting assassination, the studious teenage Lenin turns cold, systematic, and utterly committed to destroying the entire system — not just the Tsar.',
      svg_stack('How personal tragedy became ideological fuel', [
          {'n': 1, 'label': 'Brother Alexander executed (1887)', 'sub': 'hanged for a plot to kill Tsar Alexander III', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Lenin rejects individual terror', 'sub': '“We will not go that way” — not assassination', 'color': '#b45309'},
          {'n': 3, 'label': 'He embraces Marxism', 'sub': 'destroy the whole system, scientifically', 'color': '#b91c1c'},
      ], takeaway='He turned grief into a cold, systematic project — not revenge on a man, but the overthrow of an entire order.', accent=AC),
      bg='Vladimir Ulyanov (later “Lenin”) was born in 1870 into an educated, respectable provincial family in Tsarist Russia — an autocracy with no democracy and brutal repression of dissent.',
      people='His brother <b>Alexander Ulyanov</b>, executed in 1887; the works of <b>Karl Marx</b>, which Lenin adopted as a total worldview; the Tsarist state he vowed to destroy.',
      what='The execution of his brother radicalised the young Lenin. Rejecting the older tradition of individual assassination, he became a committed <b>Marxist</b>, was expelled from university, and dedicated his life to organised revolution.',
      crux='He converted a personal wound into an <b>impersonal, systematic ideology</b>: the enemy was not a person but a system, and the answer was not revenge but a scientific plan to overthrow it.',
      conseq='He became a professional revolutionary — arrested, exiled to Siberia, then living abroad — building the intellectual and organisational tools to topple the Russian state.',
      matters='The most dangerous opponents convert emotion into cold strategy. Lenin’s power came from turning private grief into a disciplined, patient, systematic mission.'),

    E('siberia', '1895–1900', 'Prison, Siberian exile, and a revolutionary marriage', ['RISE'],
      'Arrested for organising Marxist workers, the young Vladimir Ulyanov is jailed then exiled to Siberia — where, far from breaking him, three years of enforced quiet let him read, write and marry his lifelong comrade Krupskaya.',
      svg_stack('Exile as a revolutionary apprenticeship', [
          {'n': 1, 'label': 'Arrested organising workers, 1895', 'sub': 'leads the Union of Struggle in St Petersburg', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Exiled to Shushenskoye, 1897', 'sub': 'three years in Siberia — reading, writing, hunting', 'color': '#7c2d12'},
          {'n': 3, 'label': 'Marries Krupskaya, 1898', 'sub': 'his partner and secretary for the rest of his life', 'color': '#a16207'},
      ], takeaway='The regime’s mild exile gave him exactly what a theorist needs — time, books and a collaborator.', accent=AC),
      bg='In the 1890s Ulyanov turned from law to full-time revolution, organising the illegal <b>Union of Struggle for the Emancipation of the Working Class</b> among St Petersburg workers.',
      people='<b>Nadezhda Krupskaya</b>, fellow revolutionary, whom he married in exile; the Marxist study circles he built; the Tsarist police who treated exile as a manageable inconvenience.',
      what='Arrested in 1895 and exiled to <b>Shushenskoye</b> in Siberia (1897–1900), he wrote <b>The Development of Capitalism in Russia</b>, corresponded widely, and married Krupskaya — emerging hardened and ready to leave for Europe.',
      crux='Tsarist exile was <b>too lenient to deter and long enough to train</b> — it produced disciplined theorists instead of broken men.',
      conseq='On release he went abroad to found a national newspaper and build the party — the plan that led straight to Iskra and the Bolsheviks.',
      matters='Repression that is harsh enough to radicalise but soft enough to survive manufactures its own most dangerous enemies.'),

    E('vanguard', '1902–1912', 'The vanguard party — his real invention', ['POLITICS', 'REFORM'],
      'His true innovation isn’t an idea but an organisation: a small, disciplined party of full-time professional revolutionaries who will seize and hold power, rather than wait for history.',
      svg_vanguard2(),
      bg='Most Marxists believed revolution would come slowly, after capitalism fully developed. Russia was mostly peasant and backward — so how could a Marxist revolution happen there?',
      people='The <b>Mensheviks</b> (led by figures like Martov), who wanted a broad, democratic party; Lenin’s <b>Bolsheviks</b>; the exiled Russian Marxist movement across Europe.',
      what='In <b>What Is to Be Done? (1902)</b> and the party split of <b>1903</b>, Lenin argued for a <b>tight, centralised “vanguard” party</b> of disciplined professionals who would lead the workers rather than wait for them — creating the <b>Bolsheviks</b>.',
      crux='His innovation was <b>organisational</b>: a small, obedient, professional core could act decisively and seize power in a crisis, where a large, loose, democratic movement would dither.',
      conseq='This model — the disciplined vanguard party — became the template for communist parties worldwide, and the machine that would seize Russia in 1917.',
      matters='Ideas need a machine to win. Lenin’s lasting contribution was the organisational form — the disciplined party — that could actually take and keep power.'),

    E('iskra', '1900–1903', 'Iskra and the great split — Bolsheviks are born', ['POLITICS', 'TURNING POINT'],
      'Lenin founds an underground newspaper to unify Russian Marxism — then, at the 1903 congress meant to unite the party, forces a fight over membership rules that splits it forever into his hard “Bolsheviks” and the softer “Mensheviks.”',
      svg_row('A newspaper that became a schism', [
          {'n': 1, 'label': 'Iskra (“The Spark”), 1900', 'sub': 'smuggled paper to knit scattered Marxists into one party', 'color': '#b91c1c'},
          {'n': 2, 'label': '2nd Congress, 1903', 'sub': 'a clash over who counts as a party member', 'color': '#7c2d12'},
          {'n': 3, 'label': 'Bolsheviks vs Mensheviks', 'sub': 'Lenin’s “majority” faction breaks from the “minority”', 'color': '#a16207'},
      ], edge_labels=['leads to', 'produces'], takeaway='He would rather split the movement than dilute it — purity of the core over breadth of the whole.', accent=AC),
      bg='Russian Marxism was fragmented. Lenin’s answer was <b>Iskra</b>, a paper produced abroad and smuggled in, whose network of agents would form the skeleton of a national party.',
      people='Co-editors including <b>Martov</b> (his friend, soon his rival) and the veteran <b>Plekhanov</b>; the delegates at the 1903 congress in Brussels and London.',
      what='At the <b>Second Party Congress (1903)</b>, Lenin insisted party membership require active work in an organisation; Martov wanted a looser definition. Lenin won a key vote and named his faction <b>Bolsheviks</b> (“majority”); Martov’s became the <b>Mensheviks</b>.',
      crux='He deliberately chose a <b>small, disciplined vanguard</b> over a broad, loose party — the split was a feature, not an accident.',
      conseq='The Bolshevik–Menshevik divide shaped Russian socialism for two decades and gave Lenin the tight instrument he used in 1917.',
      matters='Movements often gain force by narrowing: a committed core can outmanoeuvre a larger, looser rival.'),

    E('1905', '1905–1914', 'The 1905 dress rehearsal — and the long wait', ['BATTLE', 'DEFEAT'],
      'A wave of revolution nearly topples the Tsar in 1905, and Lenin watches, learns, and is disappointed as it fails. He spends the next decade in exile, refining his theory and keeping his tiny faction disciplined while revolution seems impossibly far off.',
      svg_row('A failed rehearsal, then years of waiting', [
          {'n': 1, 'label': '1905 Revolution', 'sub': 'strikes and a workers’ soviet shake the Tsar', 'color': '#b45309'},
          {'n': 2, 'label': 'It is crushed', 'sub': 'the autocracy survives; Lenin studies the lessons', 'color': '#64748b'},
          {'n': 3, 'label': 'A decade in exile', 'sub': 'he keeps the Bolshevik core intact and doctrinaire', 'color': '#b91c1c'},
      ], edge_labels=['then', 'then'], takeaway='The 1905 “dress rehearsal” taught him what a real revolution would need — above all, the soviets and armed force.', accent=AC),
      bg='In <b>1905</b>, defeat in the Russo-Japanese War and “Bloody Sunday” triggered a wave of strikes, mutinies and the first workers’ <b>soviets</b>, forcing limited reforms from the Tsar.',
      people='The workers and sailors of 1905; the rival socialist factions; the Tsarist state that regrouped and repressed.',
      what='The <b>1905 Revolution</b> shook but did not topple the autocracy. Lenin drew lessons — especially the power of the <b>soviets</b> and the necessity of armed insurrection — then spent years in <b>exile</b> keeping his faction disciplined through a bleak period.',
      crux='He treated failure as <b>study</b>: 1905 became a rehearsal from which he extracted the tactical lessons he would apply, decisively, in 1917.',
      conseq='When war shattered Russia in 1917, Lenin — unlike more hopeful revolutionaries — had a tested theory and a hardened organisation ready.',
      matters='Patience and learning from defeat separate the serious revolutionary from the dreamer. Lenin spent twelve lean years preparing for a moment he might never see.'),

    E('imperialism', '1916', 'Imperialism — a theory to explain the war', ['REFORM', 'POLITICS'],
      'Stuck in wartime Zurich, Lenin writes the book that reframes the World War not as madness but as the inevitable death-struggle of monopoly capitalism — a theory that tells his followers the revolution is not premature but overdue.',
      svg_stack('The idea that justified acting now', [
          {'n': 1, 'label': 'Capitalism becomes monopoly', 'sub': 'banks and cartels dominate; competition gives way to empire', 'color': '#7c2d12'},
          {'n': 2, 'label': 'Empires must fight for markets', 'sub': 'the World War is capitalism’s built-in outcome', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The “highest stage” → collapse', 'sub': 'the system is ripe; revolution is not early but late', 'color': '#a16207'},
      ], takeaway='He gave the coming seizure of power a theory that made it feel not reckless but historically ordained.', accent=AC),
      bg='Marxists were split and demoralised by 1916: the great socialist parties had backed their nations’ war efforts. Lenin needed to explain the catastrophe and justify revolution in a “backward” country.',
      people='The Second International socialists he denounced as traitors; theorists like <b>Hobson</b> and <b>Hilferding</b> he drew on; the small band of internationalists at Zimmerwald.',
      what='In <b>Imperialism, the Highest Stage of Capitalism</b> he argued capitalism had matured into monopoly and empire, making world war inevitable and the system ripe for overthrow — even in agrarian Russia.',
      crux='The theory converted an apparent objection (“Russia is too backward for socialism”) into an argument that the <b>whole imperial system</b> was ready to fall.',
      conseq='It armed the Bolsheviks with a confident worldview and became a founding text of anti-colonial and communist thought for the century.',
      matters='A powerful theory does not just explain the world — it licenses action, telling its believers that the moment is now.'),

    E('ww1', '1914–1916', 'Turning the world war into revolution', ['POLITICS', 'TURNING POINT'],
      'When the Great War erupts and most socialists rally to their own nations, Lenin does the opposite — denouncing the war as an imperialist bloodbath, calling on workers to “turn the imperialist war into civil war,” and writing the theory of imperialism that recasts the whole conflict as capitalism’s death agony.',
      svg_row('Against the tide of wartime patriotism', [
          {'n': 1, 'label': 'Socialists back the war', 'sub': 'most European parties support their governments', 'color': '#64748b'},
          {'n': 2, 'label': 'Lenin refuses', 'sub': '“turn the imperialist war into civil war”', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Theory of imperialism', 'sub': 'war as the death-agony of capitalism', 'color': '#b45309'},
      ], edge_labels=['then', 'plus'], takeaway='He alone read the war as revolution’s opportunity — and built the theory to justify it.', accent=AC),
      bg='The <b>First World War</b> split the socialist movement, as most parties supported their own nations’ war efforts — a betrayal, in Lenin’s eyes, of internationalism.',
      people='The <b>Second International</b> socialists who backed the war; the small anti-war left at the <b>Zimmerwald</b> conference; Lenin, isolated in exile.',
      what='Lenin denounced the war as an <b>imperialist slaughter</b>, urged workers to <b>“turn the imperialist war into a civil war”</b> against their own rulers, and wrote <i>Imperialism, the Highest Stage of Capitalism</i>, framing the war as capitalism’s final crisis.',
      crux='He alone saw the catastrophe as <b>revolution’s great opportunity</b>, refusing patriotism and building the theoretical case that made 1917 thinkable.',
      conseq='When the war shattered Russia, Lenin had both a theory and a stance — total opposition to the war — perfectly suited to the moment.',
      matters='Great strategists read catastrophe as opportunity. Lenin’s wartime stance, isolated and unpopular, positioned him to seize 1917.'),
]

# ==================================================================  PHASE 2
PHASE_REVOLUTION = [
    E('sealedtrain', 'Apr 1917', 'The sealed train and the April Theses', ['POLITICS', 'TURNING POINT'],
      'When the Tsar falls, Lenin is stuck in exile in Switzerland. Germany, wanting Russia out of the war, ships him home in a sealed train — and he arrives demanding all power to the Soviets and immediate peace.',
      svg_row('An enemy speeds him to power', [
          {'n': 1, 'label': 'Tsar falls (Feb 1917)', 'sub': 'a weak Provisional Government takes over, keeps fighting WWI', 'color': '#64748b'},
          {'n': 2, 'label': 'Germany sends Lenin home', 'sub': 'a “sealed train” — to sow chaos in Russia', 'color': '#b45309'},
          {'n': 3, 'label': 'April Theses', 'sub': '“Peace, Land, Bread”; “All power to the Soviets”', 'color': '#b91c1c'},
      ], edge_labels=['then', 'then'], takeaway='He offered the exact three things a war-shattered nation craved — peace, land, and bread — while rivals offered more war.', accent=AC),
      bg='In February 1917 the Tsar was overthrown, but the new <b>Provisional Government</b> kept Russia in the catastrophic First World War, alienating exhausted soldiers and starving cities.',
      people='The German high command, which transported Lenin to destabilise Russia; <b>Kerensky</b>, the Provisional Government leader; the <b>Soviets</b> (workers’ and soldiers’ councils).',
      what='Germany moved Lenin from Switzerland across the front in a <b>sealed train</b>. Arriving in Petrograd, his <b>April Theses</b> broke with other socialists: no support for the war or the Provisional Government — instead “<b>All power to the Soviets</b>” and the slogan “<b>Peace, Land, Bread</b>.”',
      crux='He read the moment perfectly: a war-weary, hungry, land-hungry population wanted <b>out of the war and bread now</b>. By promising exactly that while rivals prevaricated, he captured the mood.',
      conseq='The Bolsheviks surged in popularity through 1917 on these simple, radical promises, positioning Lenin to make his move for power.',
      matters='In a crisis, the leader who offers the concrete things people desperately want — clearly and without hedging — beats those offering complexity and delay.'),

    E('staterevolution', 'Aug 1917', 'State and Revolution — the blueprint and the paradox', ['POLITICS', 'REFORM'],
      'In hiding between the July disaster and the October seizure, he writes his most utopian book — a vision of a stateless future where the people themselves govern and the state “withers away” — even as he prepares to build one of the most centralised states in history, a contradiction at the heart of his revolution.',
      svg_compare('The dream on paper vs the state in practice',
          {'head': 'State and Revolution (the vision)', 'color': '#16a34a',
           'items': ['the state will “wither away”', 'ordinary workers will run society', 'a free, self-governing commune']},
          {'head': 'What he actually built', 'color': '#b91c1c',
           'items': ['a one-party dictatorship', 'a secret police and central control', 'the state hugely strengthened']},
          verdict='The most libertarian Marxist text was written by the founder of the most centralised Marxist state.',
          takeaway='He preached a withering-away state while building an all-powerful one — the founding paradox of Soviet communism.', accent=AC),
      bg='While hunted after the July Days, Lenin wrote <i>State and Revolution</i>, his fullest statement of Marxist theory on the state and the future society.',
      people='The Marxist tradition he drew on (Marx and Engels on the Paris Commune); the future Soviet state that would contradict the book.',
      what='In <b>State and Revolution (1917)</b> Lenin envisioned the <b>“withering away” of the state</b> after the revolution, with workers directly administering society — a strikingly libertarian vision utterly at odds with the <b>centralised one-party dictatorship</b> he then built.',
      crux='The gap between the <b>utopian theory and the coercive practice</b> is the central paradox of Leninism: the promise of freedom delivered as an all-powerful state.',
      conseq='The book became a touchstone for revolutionaries, even as the Soviet reality moved in the opposite direction.',
      matters='Ideals and outcomes can diverge starkly. State and Revolution is the poignant measure of the distance between what Lenin promised and what he built.'),

    E('julydays', 'Jul–Sep 1917', 'The July Days and the Kornilov gift', ['POLITICS', 'DEFEAT', 'TURNING POINT'],
      'A premature rising in July collapses, Lenin is branded a German agent and flees into hiding, and the Bolsheviks look finished — until a botched right-wing coup by General Kornilov hands them the chance to arm themselves and roar back stronger than ever.',
      svg_row('From near-ruin to rearmed comeback', [
          {'n': 1, 'label': 'The July Days fail', 'sub': 'a premature rising is crushed; Lenin flees', 'color': '#dc2626'},
          {'n': 2, 'label': 'Branded and hunted', 'sub': 'accused as a German agent; in hiding in Finland', 'color': '#64748b'},
          {'n': 3, 'label': 'The Kornilov coup backfires', 'sub': 'Bolsheviks arm to stop it — and keep the guns', 'color': '#b91c1c'},
      ], edge_labels=['then', 'then'], takeaway='His enemies rescued him twice: a botched coup let the Bolsheviks arm the workers who would seize power weeks later.', accent=AC),
      bg='Through mid-1917 the Bolsheviks pushed hard against the Provisional Government, suffering a serious setback before a right-wing threat transformed their fortunes.',
      people='<b>Kerensky</b>; the general <b>Kornilov</b>, whose attempted coup misfired; the armed workers’ militias (Red Guards).',
      what='After the failed <b>July Days</b> rising, Lenin was branded a German agent and <b>fled into hiding</b>. Then General <b>Kornilov’s</b> attempted coup against Kerensky in September let the Bolsheviks pose as defenders of the revolution and <b>arm the Red Guards</b> — keeping those weapons.',
      crux='He turned his enemies’ blunders into advantage: the <b>Kornilov affair rearmed and re-legitimised the Bolsheviks</b> at the crucial moment, undoing the July disaster.',
      conseq='By autumn the Bolsheviks were armed, popular and controlled the Petrograd Soviet — the platform for the October seizure.',
      matters='Fortune favours the prepared opportunist. Lenin was down and hunted, then his rivals’ mistakes handed him exactly the weapons he needed.'),

    E('october', 'Oct 1917', 'The October Revolution — seizing the state', ['POLITICS', 'TURNING POINT', 'TRIUMPH'],
      'With the government paralysed, Lenin’s Bolsheviks — a disciplined minority — seize the key points of the capital in a near-bloodless coup and simply declare themselves the new government.',
      svg_october(),
      bg='By autumn 1917 the Provisional Government had lost authority; the war ground on; the Bolsheviks controlled the Petrograd Soviet. Lenin pushed his hesitant colleagues to seize power now.',
      people='<b>Leon Trotsky</b>, who organised the insurrection through the Military Revolutionary Committee; <b>Kerensky</b>, whose government collapsed; the reluctant Bolshevik leaders Lenin overrode.',
      what='On <b>25 October 1917</b> (old calendar), the Bolsheviks seized bridges, telegraphs, and the Winter Palace in Petrograd — a swift, largely bloodless <b>coup</b> — and declared a new Soviet government with Lenin at its head.',
      crux='It was <b>not</b> a mass uprising but a <b>disciplined seizure of key points</b> by an organised minority exploiting a power vacuum — the vanguard-party theory in action.',
      conseq='The Bolsheviks held power, but only controlled the cities; a brutal civil war for the whole country was about to begin. The world’s first communist state was born.',
      matters='Power is often seized, not won by majority: control the critical nodes at the decisive moment, and a determined minority can take a state.'),
]

# ==================================================================  PHASE 3
PHASE_POWER = [
    E('decrees', 'Oct–Nov 1917', 'Peace, Land and Bread — governing by decree', ['POLITICS', 'REFORM', 'TRIUMPH'],
      'Within days of seizing power the Bolsheviks issue sweeping decrees — ending the war, handing landlords’ estates to the peasants, and putting workers over the factories — cashing the promises that carried them to power before anyone can stop them.',
      svg_row('Turning slogans into instant law', [
          {'n': 1, 'label': 'Decree on Peace', 'sub': 'calls for immediate armistice — “Peace”', 'color': '#16a34a'},
          {'n': 2, 'label': 'Decree on Land', 'sub': 'abolishes landlord estates; peasants take the land — “Land”', 'color': '#a16207'},
          {'n': 3, 'label': 'Workers’ control', 'sub': 'factory committees over management — grip on the economy', 'color': '#b91c1c'},
      ], edge_labels=['then', 'then'], takeaway='He legitimised the coup by instantly delivering the three things people actually wanted.', accent=AC),
      bg='The slogan “<b>Peace, Land, Bread</b>” had won the Bolsheviks their support. To hold power they had to deliver visibly and at once, before rivals could rally.',
      people='<b>Lenin</b>, driving the decrees through the Congress of Soviets; the war-weary soldiers and land-hungry peasants who were the immediate beneficiaries.',
      what='The very night of the seizure and the days after, the government issued the <b>Decree on Peace</b>, the <b>Decree on Land</b> (adopting the peasants’ own programme), and measures for <b>workers’ control</b> of industry.',
      crux='He <b>front-loaded the popular gains</b> — giving millions a personal stake in the new regime’s survival before the costs arrived.',
      conseq='Peasant land seizures and the rush to end the war bound key groups to the Bolsheviks — even as the same government soon crushed the democracy it claimed to embody.',
      matters='New regimes secure themselves by delivering fast and tangibly — early gifts buy the time to consolidate.'),

    E('constituent', 'Jan 1918', 'Dissolving democracy at gunpoint', ['POLITICS', 'TURNING POINT'],
      'Russia’s first freely elected parliament meets — and, because the Bolsheviks lose the vote, Lenin simply shuts it down after a single day, making brutally clear that “all power to the Soviets” meant all power to his party, not to the ballot box.',
      svg_row('The one-day parliament', [
          {'n': 1, 'label': 'Free elections held', 'sub': 'the Constituent Assembly is elected', 'color': '#64748b'},
          {'n': 2, 'label': 'Bolsheviks lose', 'sub': 'they win only a minority of seats', 'color': '#b45309'},
          {'n': 3, 'label': 'Lenin dissolves it', 'sub': 'shut down by armed guards after one day', 'color': '#b91c1c'},
      ], edge_labels=['then', 'so'], takeaway='When the voters rejected him, he abolished the vote — democracy lasted exactly one day.', accent=AC),
      bg='After October, elections went ahead for a <b>Constituent Assembly</b> meant to write Russia’s constitution — the country’s first and only free national election for generations.',
      people='The rival <b>Socialist Revolutionaries</b>, who won the most seats; the sailors and guards who enforced the closure.',
      what='When the <b>Constituent Assembly</b> met in January 1918 with the Bolsheviks in the minority, Lenin had it <b>dissolved by armed force after a single sitting</b>, ending Russia’s brief experiment with parliamentary democracy.',
      crux='He revealed the true meaning of his slogans: power belonged to <b>his party</b>, exercised through the Soviets it controlled — not to any elected majority.',
      conseq='Russia’s democratic path was closed off; the one-party dictatorship was now explicit, and armed opposition hardened into civil war.',
      matters='“All power to the Soviets” really meant all power to the party. Lenin’s dissolution of the Assembly is the moment Soviet democracy was strangled at birth.'),

    E('brest', '1918', 'Brest-Litovsk — a ruinous peace to survive', ['POLITICS', 'DEFEAT'],
      'To keep his promise of peace and save the revolution, Lenin signs a humiliating treaty with Germany, surrendering vast territory. Colleagues are appalled — but he grasps that survival comes first.',
      svg_row('Trading land for survival', [
          {'n': 1, 'label': 'Must exit WWI', 'sub': 'the army has collapsed; peace was the promise', 'color': '#64748b'},
          {'n': 2, 'label': 'Brutal German terms', 'sub': 'give up Ukraine, the Baltics, huge land & people', 'color': '#b45309'},
          {'n': 3, 'label': 'Lenin signs anyway', 'sub': 'a “breathing space” to save the regime', 'color': '#b91c1c'},
      ], edge_labels=['so', 'and'], takeaway='He sacrificed territory ruthlessly to buy time — survival of the revolution outranked pride or land.', accent=AC),
      bg='The Bolsheviks had promised peace, but Germany demanded enormous concessions. Many Bolsheviks wanted a “revolutionary war” instead of surrender.',
      people='<b>Trotsky</b>, who first tried “neither war nor peace”; the German negotiators; the Left Bolsheviks who opposed the treaty.',
      what='In <b>March 1918</b> Lenin forced through the <b>Treaty of Brest-Litovsk</b>, ceding Ukraine, the Baltic lands, Finland and more — roughly a third of Russia’s population and industry — to Germany.',
      crux='He understood that <b>keeping power now</b> mattered more than territory or honour: a humiliating peace that preserved the revolution beat a heroic war that destroyed it. (Germany’s own defeat months later voided much of it anyway.)',
      conseq='The regime survived the immediate threat and could turn to fight the civil war — though at the cost of enormous territory and fierce internal criticism.',
      matters='Ruthless prioritisation: when survival is at stake, give up everything non-essential without sentiment. Lenin always knew which fight was the one that mattered.'),

    E('cheka', 'Dec 1917', 'The Cheka — building the secret police', ['POLITICS', 'REFORM', 'TRAGEDY'],
      'Weeks after taking power Lenin creates a political police answerable to no court — the Cheka — giving the new state a weapon of arrest, terror and execution that will outlast him as the KGB’s ancestor.',
      svg_stack('An instrument of terror, built early', [
          {'n': 1, 'label': 'Cheka founded, Dec 1917', 'sub': 'commission “to combat counter-revolution and sabotage”', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Dzerzhinsky in charge', 'sub': 'a fanatic incorruptible; power outside the law', 'color': '#7c2d12'},
          {'n': 3, 'label': 'Arrest, terror, execution', 'sub': 'the template for every Soviet secret service to come', 'color': '#a16207'},
      ], takeaway='He armed the revolution with a permanent secret police before it even had a constitution.', accent=AC),
      bg='The Bolsheviks were a minority seizing a vast, hostile country. Lenin believed survival required organised, extra-legal coercion from the very start.',
      people='<b>Felix Dzerzhinsky</b>, “Iron Felix,” its ascetic first chief; the “class enemies” it targeted; the future NKVD and KGB that descended from it.',
      what='On <b>7 December 1917</b> Lenin established the <b>Cheka</b> — the All-Russian Extraordinary Commission — with sweeping powers to arrest, imprison and shoot outside any judicial process. It became the engine of the Red Terror.',
      crux='He institutionalised <b>terror as a permanent organ of the state</b>, not a temporary emergency measure — a decisive, fateful choice.',
      conseq='The Cheka’s culture of secret, unaccountable violence became a defining feature of the Soviet system through the KGB and beyond.',
      matters='The tools a revolution builds to defend itself often become the permanent architecture of the tyranny that follows.'),

    E('assassination', 'Aug 1918', 'Shot and wounded — the pretext for mass terror', ['TRAGEDY', 'TURNING POINT', 'DEATH'],
      'A near-fatal assassination attempt leaves Lenin with bullets lodged in his body — and hands the regime the excuse it wanted to unleash the Red Terror in earnest, with mass hostage-taking and summary shootings.',
      svg_stack('An attempt on his life, weaponised', [
          {'n': 1, 'label': 'Fanny Kaplan shoots Lenin, 30 Aug 1918', 'sub': 'two bullets; he survives but is gravely hurt', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Same day: Petrograd Cheka chief killed', 'sub': 'the regime declares itself under mortal siege', 'color': '#7c2d12'},
          {'n': 3, 'label': 'The Red Terror decreed', 'sub': 'hostages, class enemies and “suspects” shot en masse', 'color': '#a16207'},
      ], takeaway='The attempt on one life became the licence to take thousands — terror justified as self-defence.', accent=AC),
      bg='By August 1918 the Bolsheviks were fighting for survival; assassinations of their leaders were mounting. On 30 August a would-be assassin shot Lenin as he left a factory meeting.',
      people='<b>Fanny Kaplan</b>, the Socialist-Revolutionary who fired the shots and was quickly executed; <b>Dzerzhinsky</b>’s Cheka; the hostages seized in reprisal.',
      what='Kaplan’s bullets left Lenin seriously wounded (and, some argue, hastened his later strokes). The regime responded with a formal <b>Red Terror</b> — mass arrests, hostage-taking and executions of “class enemies.”',
      crux='The shooting let the leadership recast <b>pre-planned terror as righteous retaliation</b>, dissolving any restraint on killing.',
      conseq='The Red Terror became systematic; the cult of the wounded, near-martyred Lenin also began to grow around him.',
      matters='An attack on a ruler is often the moment repression it already wanted becomes politically unstoppable.'),

    E('civilwar', '1918–1921', 'Civil war and the Red Terror', ['BATTLE', 'TRAGEDY'],
      'To win a savage civil war, Lenin builds a secret police, unleashes mass terror against “class enemies,” and seizes the peasants’ grain — winning power at the cost of famine and repression.',
      svg_stack('How the regime survived — and what it became', [
          {'n': 1, 'label': 'Reds vs Whites civil war', 'sub': 'Trotsky builds the Red Army; foreign intervention', 'color': '#b45309'},
          {'n': 2, 'label': 'The Cheka & Red Terror', 'sub': 'secret police; mass arrests and executions', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'War Communism', 'sub': 'grain seized from peasants → famine', 'color': '#dc2626'},
          {'n': 4, 'label': 'The Reds win (1921)', 'sub': 'a centralised one-party state emerges', 'color': '#b91c1c'},
      ], takeaway='He won — but built a machine of secret police and terror that would outlive him and be inherited by Stalin.', accent=AC),
      bg='After October, anti-Bolshevik “White” armies, aided by foreign powers, fought to destroy the new regime in a brutal, sprawling civil war.',
      people='<b>Trotsky</b>, architect of the Red Army; <b>Felix Dzerzhinsky</b>, founder of the <b>Cheka</b> secret police; the peasants whose grain was seized; the Romanov family, executed in 1918.',
      what='Lenin’s regime built the <b>Red Army</b>, created the <b>Cheka</b>, and waged the <b>Red Terror</b> — mass executions of perceived enemies — alongside <b>War Communism</b> (forced grain requisitioning), which helped cause devastating famine. By 1921 the Reds had won.',
      crux='Lenin justified extreme <b>coercion and terror</b> as necessary to defend the revolution. The instruments he built — one-party rule, secret police, state control — became permanent features of the Soviet state.',
      conseq='The Bolsheviks survived and consolidated a centralised dictatorship, but at the cost of enormous death and the creation of a repressive apparatus.',
      matters='The tools you build to win a crisis tend to outlast the crisis. Lenin’s machinery of terror became the foundation of the totalitarian state Stalin would perfect.'),

    E('warcommunism', '1918–1921', 'War Communism — the economy as a barracks', ['REFORM', 'TRAGEDY'],
      'To feed the Red Army and cities in the civil war, Lenin abolishes the market: grain is seized from peasants by force, industry is nationalised, money withers — a system that wins the war but wrecks the economy and starves the countryside.',
      svg_row('Running an economy by requisition', [
          {'n': 1, 'label': 'Grain requisitioning', 'sub': 'armed detachments seize peasants’ “surplus” — often their seed', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Total nationalisation', 'sub': 'industry, trade and labour placed under state command', 'color': '#7c2d12'},
          {'n': 3, 'label': 'Collapse and revolt', 'sub': 'production craters; peasants stop sowing; risings spread', 'color': '#a16207'},
      ], edge_labels=['plus', 'yields'], takeaway='Command by force fed the army but broke the economy — and forced the retreat to the NEP.', accent=AC),
      bg='Blockaded and fighting on many fronts, the Bolshevik state improvised an emergency command economy to extract food and matériel at any cost.',
      people='The <b>requisition detachments</b> sent into the villages; the peasants who resisted, hid grain, or rose in revolt; the workers fleeing hungry cities.',
      what='<b>War Communism</b> (1918–21) meant <b>forced grain requisitioning</b>, sweeping nationalisation, banned private trade, and near-collapse of money. It sustained the Red war effort but sent industrial output plunging and helped trigger famine.',
      crux='Coercion could <b>extract resources but not create them</b> — squeezing the peasantry destroyed the incentive to produce.',
      conseq='Economic ruin, the Tambov peasant rising and the Kronstadt revolt forced Lenin into the market-tolerating retreat of the New Economic Policy in 1921.',
      matters='You can command an economy to give in the short run, but not to grow — force eventually collides with the need to produce.'),

    E('comintern', '1919–1921', 'World revolution — and its limit at Warsaw', ['POLITICS', 'DEFEAT'],
      'Convinced the Russian revolution can only survive if it spreads, he founds the Communist International to ignite revolt worldwide — and gambles by sending the Red Army west toward Germany, only to be stopped dead at the gates of Warsaw.',
      svg_row('The dream of spreading the revolution', [
          {'n': 1, 'label': 'Founds the Comintern', 'sub': 'to lead and export world revolution, 1919', 'color': '#b91c1c'},
          {'n': 2, 'label': 'March on Warsaw, 1920', 'sub': 'the Red Army drives west toward Germany', 'color': '#b45309'},
          {'n': 3, 'label': 'Halted at Warsaw', 'sub': 'Poland throws the invasion back; the dream stalls', 'color': '#64748b'},
      ], edge_labels=['then', 'then'], takeaway='He bet the revolution would go global — and Poland’s defence of Warsaw showed it would not, not yet.', accent=AC),
      bg='Lenin believed a socialist Russia could not survive alone in a capitalist world; the revolution had to <b>spread</b>, above all to industrial <b>Germany</b>.',
      people='The foreign communist parties of the <b>Comintern</b>; the Polish forces under <b>Piłsudski</b>; the Red Army commanders (including Tukhachevsky).',
      what='Lenin founded the <b>Communist International (Comintern)</b> in 1919 to coordinate world revolution, and in <b>1920</b> sent the <b>Red Army toward Warsaw</b> hoping to link up with revolution in Germany — but the Poles decisively <b>repelled the invasion</b>.',
      crux='His strategy of <b>exporting revolution</b> hit a hard limit: national resistance (Polish patriotism) proved stronger than international class solidarity.',
      conseq='The failure at Warsaw ended hopes of imminent world revolution and pushed the regime toward consolidating "socialism in one country" — the doctrine Stalin would later claim.',
      matters='Ideology meets nationalism and often loses. The check at Warsaw forced the revolution to turn inward, with vast consequences.'),

    E('church', '1918–1922', 'War on the Church — and looting its treasures', ['POLITICS', 'TRAGEDY'],
      'Lenin separates church from state and then, using the famine as cover, orders the seizure of the Orthodox Church’s gold and silver — welcoming the chance, in a secret letter, to shoot resisting clergy and break religion’s hold for good.',
      svg_stack('Breaking a rival source of authority', [
          {'n': 1, 'label': 'Church separated from state, 1918', 'sub': 'property nationalised; religious teaching curbed', 'color': '#7c2d12'},
          {'n': 2, 'label': 'Confiscate valuables, 1922', 'sub': 'famine used as pretext to strip churches of gold', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Crush the clergy', 'sub': 'Lenin’s secret letter urges shooting resisters “the more the better”', 'color': '#a16207'},
      ], takeaway='He saw the Church as a competing authority to be looted and shattered, not merely disestablished.', accent=AC),
      bg='The Orthodox Church was woven into Russian identity and loyal to the old order. To the Bolsheviks it was a rival ideology and a store of wealth.',
      people='Patriarch <b>Tikhon</b>, who resisted; the priests arrested or shot; the starving whom the seizures were officially meant to feed.',
      what='After separating church and state in 1918, the regime in 1922 ordered the <b>confiscation of church valuables</b> under famine-relief pretext. In a <b>secret letter</b> Lenin urged exploiting the crisis to crush the clergy with maximum ruthlessness.',
      crux='He treated the Church as a <b>competing centre of belief and loyalty</b> — to be materially plundered and politically decapitated at once.',
      conseq='Thousands of clergy were killed or imprisoned; the assault on religion became a permanent feature of the Soviet state.',
      matters='Total states cannot tolerate rival sources of meaning — faith, like independent politics, becomes a target.'),

    E('kronstadt', 'Mar 1921', 'Kronstadt — the revolution turns on its own sailors', ['BATTLE', 'TRAGEDY', 'TURNING POINT'],
      'The sailors of Kronstadt — once the proudest heroes of 1917 — rise up demanding freedom and “soviets without the Bolsheviks,” and Lenin crushes them without mercy, a bloody suppression of the revolution’s own vanguard that lays bare how far the regime has hardened into dictatorship.',
      svg_row('The vanguard of 1917 crushed', [
          {'n': 1, 'label': 'Kronstadt rises', 'sub': 'the revolution’s own sailors demand freedom', 'color': '#7f1d1d'},
          {'n': 2, 'label': '“Soviets without Bolsheviks”', 'sub': 'they reject one-party rule, not socialism', 'color': '#b45309'},
          {'n': 3, 'label': 'Crushed by force', 'sub': 'the Red Army storms the base; rebels shot or flee', 'color': '#b91c1c'},
      ], edge_labels=['then', 'then'], takeaway='He suppressed the very sailors who had made the revolution — proof of how far it had hardened into dictatorship.', accent=AC),
      bg='By early 1921, War Communism had brought famine and revolt. The <b>Kronstadt</b> naval base, a bastion of 1917, rose in protest against Bolshevik dictatorship.',
      people='The <b>Kronstadt sailors</b>, once revolutionary heroes; <b>Trotsky</b> and <b>Tukhachevsky</b>, who directed the assault.',
      what='In March <b>1921</b>, the <b>Kronstadt sailors</b> demanded political freedoms and “soviets without the Bolsheviks.” Lenin’s regime <b>crushed the rebellion by force</b>, storming the base across the ice; the rebels were killed, imprisoned or driven into exile.',
      crux='It exposed the regime’s transformation: it would use <b>lethal force even against its own revolutionary base</b> rather than share power — a decisive hardening into dictatorship.',
      conseq='The revolt helped push Lenin toward the economic retreat of the NEP even as he tightened the political monopoly.',
      matters='Revolutions often devour their own. Kronstadt is the stark moment Lenin’s state turned its guns on the very sailors who had raised it to power.'),

    E('partyunity', 'Mar 1921', 'Banning factions — the party turns on itself', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'At the same congress that launches the NEP, Lenin rams through a ban on organised factions inside the party — silencing internal dissent to enforce unity in crisis, and unknowingly handing Stalin the perfect weapon.',
      svg_row('The rule that closed the last door', [
          {'n': 1, 'label': 'Crisis: Kronstadt, revolts, retreat', 'sub': 'the party is arguing bitterly as it changes course', 'color': '#a16207'},
          {'n': 2, 'label': '“On Party Unity”, 1921', 'sub': 'organised factions banned; dissent = disloyalty', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A weapon for the future', 'sub': 'whoever runs the party can now brand rivals “factionalists”', 'color': '#7c2d12'},
      ], edge_labels=['produces', 'becomes'], takeaway='He closed off internal opposition to hold the line — and armed the man who would use it against everyone.', accent=AC),
      bg='By 1921 the party was torn between factions (like the Workers’ Opposition) even as it faced revolt and economic collapse. Lenin demanded discipline above debate.',
      people='The <b>Workers’ Opposition</b> and other groups he suppressed; the party apparatus; <b>Stalin</b>, soon General Secretary, who would wield the rule ruthlessly.',
      what='The <b>Tenth Congress</b> (1921) passed the resolution “<b>On Party Unity</b>,” banning organised factions on pain of expulsion — passed as an emergency measure but never lifted.',
      crux='He subordinated <b>inner-party democracy to unity</b>, making disagreement itself a punishable offence within the ruling body.',
      conseq='The ban became the mechanism by which Stalin later destroyed every rival as an illegal “faction” — a self-inflicted trap.',
      matters='Rules made to end today’s quarrel can become tomorrow’s instrument of tyranny in the wrong hands.'),

    E('famine', '1921–1922', 'The great famine — catastrophe and the limits of control', ['TRAGEDY', 'REFORM'],
      'His policy of seizing peasants’ grain, plus drought, produces a catastrophic famine across the Volga that kills millions — forcing the regime to accept foreign aid (even from its capitalist enemies) and helping drive Lenin’s hard pivot to the market-friendly New Economic Policy.',
      svg_row('When the policy of coercion collapsed', [
          {'n': 1, 'label': 'Grain seizures + drought', 'sub': 'War Communism strips the countryside bare', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Millions starve', 'sub': 'a catastrophic famine across the Volga region', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Foreign aid accepted', 'sub': 'even American relief is let in to save lives', 'color': '#16a34a'},
      ], edge_labels=['then', 'then'], takeaway='His own coercive economics helped starve millions — and forced the pragmatic retreat of the NEP.', accent=AC),
      bg='<b>War Communism’s</b> forced grain requisitioning, combined with war devastation and drought, produced a massive <b>famine in 1921–22</b>, especially in the <b>Volga</b> region.',
      people='The starving peasants of the Volga; the American Relief Administration (under Herbert Hoover) that fed millions; the regime forced to accept help.',
      what='The <b>1921–22 famine</b> killed <b>millions</b>. The regime was compelled to <b>accept foreign aid</b>, including large-scale American relief, and the catastrophe reinforced Lenin’s decision to abandon War Communism for the <b>NEP</b>.',
      crux='It demonstrated the <b>catastrophic failure of coercive economics</b> and forced even Lenin to bend ideology to survival — accepting help from the capitalist enemy.',
      conseq='The famine, and the revolts it fed, made the NEP’s market retreat unavoidable.',
      matters='Ideological economics can kill on a vast scale. The famine is the human cost that finally forced Lenin’s great tactical retreat.'),

    E('goelro', '1920–1922', 'Electrification — “Communism is Soviet power plus electrification”', ['REFORM', 'TURNING POINT'],
      'Amid ruin he fixes on a strangely modern vision of the future: a vast plan to electrify the whole country, declaring that socialism itself means “Soviet power plus the electrification of the entire land” — an early statement of the technocratic, industrialising ambition that would define the Soviet project.',
      svg_row('A technocratic vision of the future', [
          {'n': 1, 'label': 'The GOELRO plan', 'sub': 'a national scheme to electrify Russia', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A famous formula', 'sub': '“Communism = Soviet power + electrification”', 'color': '#b45309'},
          {'n': 3, 'label': 'Industrial modernity', 'sub': 'the seed of the later Soviet drive to industrialise', 'color': '#166534'},
      ], edge_labels=['plus', 'so'], takeaway='He fused socialism with technological modernisation — a vision the whole Soviet future would pursue.', accent=AC),
      bg='Even amid civil war and famine, Lenin looked to <b>modernising and industrialising</b> a backward Russia through technology.',
      people='The engineers and planners of the <b>GOELRO</b> electrification commission.',
      what='Lenin championed the <b>GOELRO plan (1920)</b> to <b>electrify the entire country</b> and coined the famous formula <b>“Communism is Soviet power plus the electrification of the whole country,”</b> tying socialism to technological modernisation.',
      crux='He defined the Soviet project as not just political but <b>technological and industrial</b> — an early statement of the modernising ambition Stalin would pursue with brutal force.',
      conseq='Electrification and industrialisation became central Soviet goals, culminating in Stalin’s Five-Year Plans.',
      matters='Lenin’s vision was technocratic as well as political: modernity through state-directed technology, a defining idea of the 20th century.'),
]

# ==================================================================  PHASE 4
PHASE_END = [
    E('nep', '1921', 'The NEP — a tactical retreat to markets', ['REFORM', 'POLITICS'],
      'With the economy in ruins and peasants revolting, the arch-radical does the unthinkable: he allows small private trade and farming again — a pragmatic retreat to keep the regime alive.',
      svg_row('Ideology bends to reality', [
          {'n': 1, 'label': 'Economy collapsed', 'sub': 'famine, revolts (Kronstadt 1921)', 'color': '#b45309'},
          {'n': 2, 'label': 'New Economic Policy', 'sub': 'allow small markets & private farming', 'color': '#16a34a'},
          {'n': 3, 'label': 'Recovery — but temporary', 'sub': '“one step back”; Stalin will reverse it', 'color': '#b91c1c'},
      ], edge_labels=['so', 'gives'], takeaway='Even a fanatic retreated to reality when survival demanded it — principle bent, but power was kept.', accent=AC),
      bg='By 1921, War Communism had wrecked the economy and provoked famine and uprisings (notably the <b>Kronstadt</b> sailors’ revolt). The regime faced collapse from within.',
      people='The rebelling <b>Kronstadt sailors</b> and starving peasants; party hardliners who hated the retreat; the traders (“Nepmen”) who briefly flourished.',
      what='Lenin introduced the <b>New Economic Policy (NEP)</b> in 1921, permitting <b>small-scale private trade and farming</b> while the state kept the “commanding heights.” The economy began to recover.',
      crux='The supreme ideologue proved a supreme <b>pragmatist</b>: when doctrine threatened the regime’s survival, he retreated “one step back to take two steps forward,” keeping power above purity.',
      conseq='The economy recovered, but the NEP was always meant as temporary; after Lenin’s death, Stalin abolished it with brutal collectivisation.',
      matters='Flexibility on means, iron on ends. Lenin would compromise on almost any tactic — even capitalism — so long as his party kept its grip on power.'),

    E('genoa', '1922', 'Genoa and Rapallo — breaking the isolation', ['POLITICS', 'TRIUMPH'],
      'Bankrupt and shunned, Soviet Russia sends a delegation to a great European conference — and pulls off a coup, secretly signing a treaty with the other pariah, Germany, that ends its diplomatic isolation and pairs the two outcasts.',
      svg_row('Two outcasts find each other', [
          {'n': 1, 'label': 'Genoa Conference, 1922', 'sub': 'the USSR invited to talk debts and recognition', 'color': '#a16207'},
          {'n': 2, 'label': 'Treaty of Rapallo', 'sub': 'a surprise deal with Germany — mutual recognition, cancelled claims', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Isolation broken', 'sub': 'trade and secret military cooperation follow', 'color': '#7c2d12'},
      ], edge_labels=['produces', 'yields'], takeaway='He turned shared pariah status into a partnership — the weak ally the weak to escape isolation.', accent=AC),
      bg='After the civil war the Soviet state was diplomatically isolated and economically desperate, needing trade, recognition and a way out of encirclement.',
      people='Foreign commissar <b>Chicherin</b>, who negotiated; a defeated <b>Germany</b>, itself an outcast under Versailles; the Western powers the deal blindsided.',
      what='At the <b>Genoa Conference (1922)</b> the Soviet and German delegations slipped away to nearby <b>Rapallo</b> and signed a treaty renouncing mutual claims and restoring relations — opening trade and later covert military cooperation.',
      crux='He grasped that <b>two isolated states can rescue each other</b> — pariah plus pariah equals leverage against the rest.',
      conseq='Rapallo ended the worst of Soviet isolation and set a pattern of Soviet–German dealings that echoed, darkly, all the way to 1939.',
      matters='Diplomacy is not only for friends — the excluded can gain the most by allying with the equally excluded.'),

    E('ussr', '1922', 'Founding the USSR — and the last fight with Stalin', ['REFORM', 'POLITICS'],
      'He presides over the creation of the Soviet Union itself — but in his final active months is horrified to discover the brutal, Great-Russian bullying with which Stalin is forcing Georgia into line, and turns, too late and too weak, against the man he had raised.',
      svg_row('The union — and a belated alarm', [
          {'n': 1, 'label': 'The USSR is formed, 1922', 'sub': 'a federal union of Soviet republics', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The Georgian affair', 'sub': 'Stalin bullies Georgia with brutal centralism', 'color': '#b45309'},
          {'n': 3, 'label': 'Lenin recoils', 'sub': 'attacks Stalin’s “Great-Russian chauvinism”', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='At the very moment he built the union, he glimpsed the brutal centralism — embodied in Stalin — that would define it.', accent=AC),
      bg='In <b>1922</b> the Soviet republics were formally united into the <b>USSR</b>. The terms of that union — how much autonomy the non-Russian republics would keep — became a bitter fight.',
      people='<b>Stalin</b>, Commissar for Nationalities, who pushed a harsh, centralising line; the Georgian communists he strong-armed; a fading Lenin.',
      what='Lenin oversaw the founding of the <b>Soviet Union</b>, but was appalled by Stalin’s <b>heavy-handed coercion of Georgia</b> and his “Great-Russian chauvinism.” In his last writings Lenin <b>attacked Stalin’s methods</b> and character — the beginning of his belated turn against him.',
      crux='He saw, at the end, that the <b>machine and the man he had empowered were becoming brutal beyond even his intentions</b> — but he was already too ill to stop it.',
      conseq='The confrontation fed directly into his Testament’s warning about Stalin — a warning that would come too late.',
      matters='Even the architect can be alarmed by what his creation becomes. Lenin’s last fight was against the ruthless centralism he had himself made possible.'),

    E('death', '1922–1924', 'Strokes, the Testament, and Stalin', ['DEATH', 'TURNING POINT'],
      'Struck down by strokes, Lenin watches in alarm as Stalin accumulates power, and warns in a secret “Testament” that Stalin is too dangerous to lead. He dies before he can stop him — and Stalin buries the warning.',
      svg_stack('The succession he tried, and failed, to control', [
          {'n': 1, 'label': 'Strokes disable Lenin (1922–23)', 'sub': 'he loses the ability to govern', 'color': '#64748b'},
          {'n': 2, 'label': 'Sees Stalin amassing power', 'sub': 'as General Secretary, Stalin controls appointments', 'color': '#b45309'},
          {'n': 3, 'label': 'The “Testament”', 'sub': 'warns Stalin is “too rude”; urges his removal', 'color': '#7f1d1d'},
          {'n': 4, 'label': 'Lenin dies (1924); Stalin wins', 'sub': 'the warning is suppressed; Stalin takes over', 'color': '#b91c1c'},
      ], takeaway='He built a machine with no rules for succession — so the most ruthless bureaucrat, not the ablest heir, inherited it.', accent=AC),
      bg='From 1922 Lenin suffered a series of strokes. The question of who would succeed him consumed the party leadership.',
      people='<b>Joseph Stalin</b>, whose control of the party bureaucracy Lenin belatedly feared; <b>Trotsky</b>, the brilliant rival Stalin outmanoeuvred; Lenin’s wife <b>Krupskaya</b>.',
      what='In his final <b>“Testament,”</b> Lenin criticised the leadership and warned that <b>Stalin</b> had “concentrated enormous power” and should be removed as General Secretary. Lenin <b>died in January 1924</b>; the Testament was suppressed, and Stalin consolidated control.',
      crux='Lenin had built a dictatorship of the party with <b>no mechanism for peaceful succession</b>. Power flowed to whoever controlled the bureaucracy — and that was Stalin, not the more famous Trotsky.',
      conseq='Stalin inherited Lenin’s machine of one-party rule, secret police and central control — and turned it into one of history’s deadliest dictatorships. Lenin’s body was embalmed and displayed as a near-religious icon.',
      matters='If you build power around a person and a machine but no rules, you cannot choose your heir. The system’s logic — here, control of the bureaucracy — picks the successor for you.'),
]

OVERVIEW_HTML = """
<p class="ov-lead">Vladimir Lenin took a fringe German philosophy and, through iron organisation and ruthless timing, turned it into the world’s first communist state — reshaping the 20th century. His life is the definitive study in <b>how a disciplined, determined minority can seize a state in chaos, and how the tools built to win become a machine of permanent control.</b></p>
<div class="ov-quote">“A lie told often enough becomes the truth.”<span>— widely attributed to Lenin; a chilling summary of his approach to power and propaganda</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A brother’s execution radicalises him → he invents the disciplined “vanguard party” → WWI shatters Russia and Germany ships him home → he promises “Peace, Land, Bread” and seizes power in October 1917 → survives a brutal civil war through terror → retreats tactically to markets (NEP) → dies warning about Stalin, who inherits the machine.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⚙️</div><h4>The vanguard party</h4><p>His organisational model — a small, disciplined professional core — became the template for communist and revolutionary movements worldwide.</p></div>
  <div class="ov-card"><div class="i">⏱️</div><h4>Timing & slogans</h4><p>He read a desperate moment perfectly and offered exactly what people wanted, when rivals hedged.</p></div>
  <div class="ov-card"><div class="i">🧊</div><h4>Ruthless pragmatism</h4><p>Iron on ends, flexible on means — he’d compromise on anything except his party’s grip on power.</p></div>
  <div class="ov-card"><div class="i">⚠️</div><h4>The machine outlives the man</h4><p>The apparatus of terror and one-party rule he built was inherited and perfected by Stalin.</p></div>
</div>
<div class="ov-lbl">The four chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Radicalisation</b><small> 1887–1912</small><p>A hanged brother; Marxism; the vanguard party.</p></div>
  <div><b>2 · Revolution</b><small> 1917</small><p>The sealed train, “Peace, Land, Bread,” October.</p></div>
  <div><b>3 · Power</b><small> 1918–1921</small><p>Brest-Litovsk, civil war, and the Red Terror.</p></div>
  <div><b>4 · The End</b><small> 1921–1924</small><p>The NEP retreat, strokes, and the rise of Stalin.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Leon Trotsky', 'role': 'co-leader / rival', 'color': '#b45309',
     'bio': 'The brilliant orator who organised the October seizure and built the Red Army. Lenin’s natural heir in talent — but outmanoeuvred by Stalin after Lenin’s death, exiled, and later murdered.',
     'rel': 'His indispensable partner in revolution — and the man Stalin beat to the succession.'},
    {'name': 'Joseph Stalin', 'role': 'the successor', 'color': '#7f1d1d',
     'bio': 'The dull-seeming bureaucrat who, as General Secretary, quietly amassed control of the party machine. Lenin came to fear him and urged his removal — too late.',
     'rel': 'The heir Lenin tried and failed to stop.'},
    {'name': 'Alexander Ulyanov', 'role': 'brother', 'color': '#57534e',
     'bio': 'Lenin’s older brother, hanged in 1887 for a plot to assassinate the Tsar — the personal tragedy that set Lenin on the revolutionary path.',
     'rel': 'His death lit the fuse of Lenin’s lifelong revolt.'},
    {'name': 'Felix Dzerzhinsky', 'role': 'secret police chief', 'color': '#334155',
     'bio': 'Founder and head of the Cheka, Lenin’s secret police and the instrument of the Red Terror — the ancestor of the KGB.',
     'rel': 'Built the machinery of terror that defended (and defined) the regime.'},
    {'name': 'Kerensky', 'role': 'the man he overthrew', 'color': '#64748b',
     'bio': 'Leader of the Provisional Government whose fatal decision to keep fighting WWI destroyed its support and opened the door to the Bolsheviks.',
     'rel': 'The weak government Lenin swept aside in October.'},
    {'name': 'Krupskaya', 'role': 'wife & comrade', 'color': '#db2777',
     'bio': 'Nadezhda Krupskaya, Lenin’s wife and fellow revolutionary, his organiser and support through decades of exile and struggle.',
     'rel': 'His lifelong partner in the revolutionary movement.'},
    {'name': 'Karl Marx', 'role': 'ideological father', 'color': '#0891b2',
     'bio': 'The 19th-century philosopher whose theory of history and class struggle Lenin adapted — controversially — into a blueprint for seizing power in backward Russia.',
     'rel': 'The theorist whose ideas Lenin turned into a state.'},
]

KEY_EVENTS = [
    ('1870', 'Born in Simbirsk', 'An educated provincial family in Tsarist Russia.'),
    ('1887', 'Brother executed', 'The tragedy that radicalises him.'),
    ('1895–1900', 'Arrest and Siberian exile', 'Becomes a hardened professional revolutionary.'),
    ('1902', '“What Is to Be Done?”', 'Argues for a disciplined vanguard party.'),
    ('1903', 'Bolshevik–Menshevik split', 'The Bolsheviks are born.'),
    ('1905', 'The 1905 Revolution', 'A failed dress rehearsal for 1917.'),
    ('Apr 1917', 'The sealed train; April Theses', '“Peace, Land, Bread”; “All power to the Soviets.”'),
    ('Oct 1917', 'The October Revolution', 'The Bolsheviks seize power.'),
    ('Mar 1918', 'Treaty of Brest-Litovsk', 'A ruinous peace to exit WWI and survive.'),
    ('1918–21', 'Civil war & Red Terror', 'The regime survives through mass coercion.'),
    ('1921', 'The New Economic Policy', 'A pragmatic retreat to markets.'),
    ('1922', 'Founding of the USSR', 'The Soviet Union is formally created.'),
    ('1922–23', 'Strokes; the Testament', 'Warns that Stalin must be removed.'),
    ('Jan 1924', 'Death', 'Stalin suppresses the Testament and takes over.'),
]

MASTER = [
    {'year': '1870', 'age': 'born', 'phase': 'Radicalisation', 'title': 'Born in Simbirsk', 'desc': 'A respectable Tsarist-era family.'},
    {'year': '1887', 'age': 'age 17', 'phase': 'Radicalisation', 'title': 'Brother executed', 'desc': 'Turns to systematic revolution.'},
    {'year': '1903', 'age': 'age 33', 'phase': 'Radicalisation', 'title': 'Bolsheviks born', 'desc': 'The vanguard-party split.'},
    {'year': '1917', 'age': 'age 47', 'phase': 'Revolution', 'title': 'April Theses', 'desc': '“Peace, Land, Bread.”'},
    {'year': '1917', 'age': 'age 47', 'phase': 'Revolution', 'title': 'October Revolution', 'desc': 'The Bolsheviks seize the state.'},
    {'year': '1918', 'age': 'age 47', 'phase': 'Power', 'title': 'Brest-Litovsk', 'desc': 'A humiliating peace to survive.'},
    {'year': '1918', 'age': 'age 48', 'phase': 'Power', 'title': 'Civil war & terror', 'desc': 'The Cheka and the Red Terror.'},
    {'year': '1921', 'age': 'age 50', 'phase': 'The End', 'title': 'The NEP', 'desc': 'A tactical retreat to markets.'},
    {'year': '1922', 'age': 'age 52', 'phase': 'The End', 'title': 'USSR founded; first stroke', 'desc': 'The Soviet Union is created.'},
    {'year': '1924', 'age': 'age 53', 'phase': 'The End', 'title': 'Death', 'desc': 'Stalin inherits the machine.'},
]

SOURCES = [
    ('Britannica — Vladimir Lenin', 'https://www.britannica.com/biography/Vladimir-Lenin'),
    ('World History Encyclopedia — Lenin', 'https://www.worldhistory.org/Vladimir_Lenin/'),
    ('Britannica — October Revolution', 'https://www.britannica.com/event/October-Revolution'),
    ('Wikipedia — Vladimir Lenin', 'https://en.wikipedia.org/wiki/Vladimir_Lenin'),
]

def build_meta():
    return {
        'pid': 'gm-lenin.html', 'kind': 'man', 'emoji': '🚩', 'accent': AC,
        'name': 'Vladimir Lenin', 'years': '1870–1924', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The man who turned a fringe doctrine into a state — architect of the first communist revolution, and of the machine of one-party terror Stalin would inherit.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'radical', 'label': '1 · Radicalisation', 'type': 'timeline',
             'intro': 'A brother’s execution turns a studious boy into a cold, systematic revolutionary — who invents the disciplined party that will one day seize a state.', 'events': PHASE_RADICAL},
            {'id': 'revolution', 'label': '2 · Revolution', 'type': 'timeline',
             'intro': 'War shatters Russia; an enemy ships him home; and with three words — Peace, Land, Bread — he rides the chaos to power.', 'events': PHASE_REVOLUTION},
            {'id': 'power', 'label': '3 · Power', 'type': 'timeline',
             'intro': 'To keep the revolution alive he signs a ruinous peace, wins a savage civil war through terror, and builds the apparatus of the one-party state.', 'events': PHASE_POWER},
            {'id': 'end', 'label': '4 · The End', 'type': 'timeline',
             'intro': 'The arch-radical retreats to markets to survive, then — dying — tries and fails to stop the ruthless bureaucrat who will inherit everything he built.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Lenin is deeply contested: seen by some as a liberator, by others as the founder of a murderous totalitarian system. This guide presents his methods and their consequences plainly.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
