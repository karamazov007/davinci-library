# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Nagarjuna.
The founder of Madhyamaka whose doctrine of emptiness (śūnyatā) reshaped Mahayana Buddhist thought across Asia."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b45309'  # monastic saffron / ochre

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — A LIFE HALF IN LEGEND
PHASE_LIFE = [
    E('origins', 'c. 150 CE', 'A shadowy life in the South', ['RISE', 'ORIGINS'],
      'Nagarjuna is traditionally placed in the 2nd century CE in South India — Stanford dates him roughly 150–250 CE — but almost nothing about his life can be established with certainty; the accounts we have were written centuries later in Chinese and Tibetan and are frankly hagiographical, so the man behind the philosophy remains a figure half in shadow.',
      svg_row('The historical Nagarjuna behind the legend', [
          {'n': 1, 'label': 'South India, c. 150–250 CE', 'sub': 'a Buddhist monk of the far south', 'color': '#b45309'},
          {'n': 2, 'label': 'Sources are late and legendary', 'sub': 'Chinese and Tibetan lives written centuries after', 'color': '#7c3aed'},
          {'n': 3, 'label': 'The thought outlives the man', 'sub': 'we read the philosopher through his verses', 'color': '#166534'},
      ], edge_labels=['but', 'so'], takeaway='The biography is thin and semi-legendary — Nagarjuna survives above all in the arguments he left behind.', accent=AC),
      bg='<b>Nagarjuna</b> is conventionally dated to about the 2nd century CE (the Stanford Encyclopedia gives <b>c. 150–250 CE</b>) and located in <b>southern India</b>; tradition makes him a brahmin by birth who took Buddhist ordination.',
      people='the later biographers — the Chinese pilgrim-translators and Tibetan historians (Buton, Taranatha) — whose <b>hagiographies</b> are our main narrative sources.',
      what='Modern scholars stress that <b>very little can be said with confidence</b> about his life: the surviving lives were composed long after his death and mix history with pious legend, so his dates, birthplace and career are all uncertain.',
      crux='He is one of history’s cases where <b>the ideas are far better attested than the person</b> — the texts are the evidence, not a documented biography.',
      conseq='Scholars reconstruct him cautiously from his writings and from datable references, treating the traditional life stories as devotional literature.',
      matters='It is a reminder that intellectual influence can dwarf biographical record — a thinker known worldwide whose own life is nearly a blank.'),

    E('satavahana', 'late 2nd c. CE', 'The Satavahana connection', ['POLITICS', 'ORIGINS'],
      'One of the few footholds for dating Nagarjuna is his tie to the Satavahana dynasty of the Deccan: the scholar Joseph Walser argues he was a monastic advisor to a Satavahana king — likely Yajña Śrī Śātakarṇi — and wrote the Ratnāvalī, a book of counsel, for that ruler near Amaravati in the Andhra country.',
      svg_stack('Anchoring a floating life to a dynasty', [
          {'n': 1, 'label': 'Tied to the Satavahana kings', 'sub': 'a dynasty ruling the Deccan plateau', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Advisor to Yajña Śrī Śātakarṇi', 'sub': 'late 2nd-century ruler (Walser’s reading)', 'color': '#b45309'},
          {'n': 3, 'label': 'The Ratnāvalī as royal counsel', 'sub': 'written near Amaravati in Andhra country', 'color': '#166534'},
      ], takeaway='A royal patron gives historians a rare anchor — placing Nagarjuna in the Deccan at the end of the 2nd century.', accent=AC),
      bg='Tradition and modern scholarship both link Nagarjuna to the <b>Satavahana</b> rulers of the Deccan; the epistle <b>Suhṛllekha</b> and the <b>Ratnāvalī</b> are addressed to a friendly king.',
      people='the scholar <b>Joseph Walser</b>, who built the argument; the <b>Satavahana</b> monarch, probably <b>Yajña Śrī Śātakarṇi</b>; the great stupa complex at <b>Amaravati</b>.',
      what='Walser argues Nagarjuna served as a <b>monastic counsellor to a Satavahana king</b> and composed the <b>Ratnāvalī (Precious Garland)</b> as advice to that ruler, writing in the <b>Andhra region near Amaravati</b> around the close of the 2nd century.',
      crux='The royal link is valuable because it is <b>datable</b> — a dynasty and a named king give an otherwise floating figure a place in real time.',
      conseq='It grounds him in the <b>southern, Andhra Buddhist world</b> rather than the northern Nalanda of later legend (which was not a major centre until the 5th century).',
      matters='Patronage and place matter — the Deccan setting shaped both the audience for his works and the tradition that carried them.'),

    E('nagas', 'legend', 'Retrieving the sutras from the nagas', ['TRIUMPH', 'IDEAS'],
      'The most famous legend gives Nagarjuna his very name: that he descended to the undersea realm of the nāgas — serpent-spirits who had guarded them since the Buddha’s day — and brought back the Prajñāpāramitā (Perfection of Wisdom) sutras, the scriptures of emptiness that his own philosophy would systematise.',
      svg_row('A myth that explains a canon', [
          {'n': 1, 'label': 'Prajñāpāramitā hidden with the nāgas', 'sub': 'kept safe until the world was ready', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Nagarjuna descends to retrieve them', 'sub': '“Nāga” + “Arjuna” — the serpent-sage', 'color': '#b45309'},
          {'n': 3, 'label': 'The wisdom of emptiness returns', 'sub': 'he becomes its great expositor', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='The naga legend is tradition, not history — a mythic charter that names Nagarjuna as the herald of the Perfection of Wisdom.', accent=AC),
      bg='Mahayana held that the <b>Prajñāpāramitā sutras</b>, teaching the emptiness of all things, had been entrusted to the <b>nāgas</b> — powerful serpent beings of Indian myth — until humanity was ripe to receive them.',
      people='the <b>nāgas</b>, guardians of the hidden scriptures; Nagarjuna, whose name tradition parses as <b>nāga + Arjuna</b>; the Mahayana lineage that revered the tale.',
      what='Legend holds that Nagarjuna <b>journeyed to the nāga realm</b> (variously beneath the ocean or in the Himalayas) and <b>recovered the Perfection of Wisdom sutras</b>, then expounded them — a story often flagged by his part-human, part-serpent iconography.',
      crux='The tale is a <b>foundation myth</b>: it explains why texts unknown in the Buddha’s lifetime could still be authentically his, and casts Nagarjuna as their destined revealer.',
      conseq='It cemented his standing as the <b>philosopher of Prajñāpāramitā</b> and gave Mahayana a narrative for the origin of its central scriptures.',
      matters='Read as tradition rather than fact, the legend shows how a school authorises its canon — and how doctrine and myth grew together around one name.'),

    E('alchemy', 'legend', 'The alchemist and the elixir of long life', ['IDEAS', 'DRAMA'],
      'A parallel legend paints Nagarjuna as a master of rasāyana — Indian alchemy — credited with an elixir of longevity, potions of invisibility, and the power to turn rock into gold; later a possibly distinct "tantric Nagarjuna" absorbed these tales, and scholars suspect more than one figure hides behind the single revered name.',
      svg_stack('One name, perhaps many men', [
          {'n': 1, 'label': 'Nagarjuna the alchemist', 'sub': 'rasāyana: elixirs, gold-making, long life', 'color': '#7c3aed'},
          {'n': 2, 'label': 'A later “tantric Nagarjuna”', 'sub': 'siddha traditions borrow the prestige', 'color': '#b45309'},
          {'n': 3, 'label': 'Scholars posit a “Nagarjuna II”', 'sub': 'over 140 works bear the one name', 'color': '#9f1239'},
      ], takeaway='The alchemy legends belong to tradition — and to the tangle of later authors who wrote under a name too famous to leave alone.', accent=AC),
      bg='Indian and Tibetan sources credit Nagarjuna with mastery of <b>rasāyana (alchemy)</b>; historians such as <b>Xuanzang, Buton and Taranatha</b> report he could transmute stone into gold and had prolonged his life.',
      people='the <b>siddha</b> and tantric traditions that claimed him; scholar <b>Christian Lindtner</b>, who sorted the attributed works into genuine, dubious and false.',
      what='Beyond philosophy, legend made him an <b>alchemist and long-lived adept</b>; because over <b>140 works</b> in the Tibetan canon bear his name, many scholars posit a later <b>tantric “Nagarjuna II”</b> to whom such texts and tales attached.',
      crux='The alchemy stories mark the point where the philosopher shades into <b>myth and pan-Indian folklore</b> — and where authorship becomes genuinely uncertain.',
      conseq='Modern scholarship carefully <b>separates the Madhyamaka author</b> of the core treatises from the legendary and tantric figures grafted onto him.',
      matters='Fame breeds accretion — a name so revered that centuries of alchemists, tantrikas and storytellers all claimed it as their own.'),
]

# ==================================================================  PHASE 2 — THE PHILOSOPHY OF EMPTINESS
PHASE_EMPTINESS = [
    E('mmk', 'c. 2nd c. CE', 'The Mūlamadhyamakakārikā', ['IDEAS', 'TRIUMPH', 'TURNING POINT'],
      'His masterwork, the Mūlamadhyamakakārikā ("Root Verses on the Middle Way") — some 450 terse kārikās in 27 chapters — opens with eight negations (no cessation, no arising, no annihilation, no permanence…) and proceeds, topic by topic, to dismantle the notion that anything possesses svabhāva, an intrinsic, self-standing nature.',
      svg_stack('The founding text of the Middle Way', [
          {'n': 1, 'label': '450 verses, 27 chapters', 'sub': 'aphoristic kārikās made for memorisation', 'color': '#b45309'},
          {'n': 2, 'label': 'The eight negations open it', 'sub': 'no arising, no ceasing, no coming, no going', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Chapter by chapter, svabhāva falls', 'sub': 'causation, motion, self, time, nirvana', 'color': '#166534'},
      ], takeaway='The MMK is Madhyamaka’s charter — a systematic demolition of intrinsic existence, one topic at a time.', accent=AC),
      bg='Drawing on the <b>Prajñāpāramitā</b> theme of emptiness, Nagarjuna set out to give it <b>rigorous philosophical form</b> against the substance-metaphysics of rival Buddhist and Brahmanical schools.',
      people='the <b>Abhidharma</b> scholastics who posited real <b>dharmas</b> with own-nature; later commentators (Buddhapālita, Bhāviveka, Candrakīrti) who unpacked the compressed verses.',
      what='The <b>Mūlamadhyamakakārikā</b> — roughly <b>450 verses in 27 chapters</b> — begins with the <b>eight negations</b> and analyses causation, motion, the aggregates, time, the self, action and nirvana, showing each to be <b>empty of svabhāva</b>.',
      crux='Its method is <b>reductio</b>: assume a thing has intrinsic nature, then show the assumption collapses into contradiction — so nothing bears own-being.',
      conseq='It founded the <b>Madhyamaka (Middle Way) school</b> and became the single most commented-upon philosophical text in Buddhist Asia.',
      matters='A book of bare verses reset Buddhist metaphysics — proof that a tightly argued core text can anchor a whole tradition.'),

    E('sunyata', 'core doctrine', 'Śūnyatā — emptiness of intrinsic nature', ['IDEAS'],
      'At the centre stands śūnyatā, emptiness: the claim that no thing — not a chariot, not a self, not even nirvana — has svabhāva, an independent, intrinsic essence. Everything is "empty" in that it exists only relationally, and emptiness is always the emptiness of some particular thing, never a cosmic void or a hidden substance.',
      svg_row('What "emptiness" does and does not mean', [
          {'n': 1, 'label': 'No thing has svabhāva', 'sub': 'no intrinsic, self-standing essence', 'color': '#b45309'},
          {'n': 2, 'label': 'To exist is to depend', 'sub': 'things are real only relationally', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Not nihilism, not a void', 'sub': 'emptiness is always emptiness OF something', 'color': '#166534'},
      ], edge_labels=['so', 'yet'], takeaway='Emptiness denies essence, not existence — things are real as dependent, not as self-contained substances.', accent=AC),
      bg='Rival schools held that ultimate reality bottoms out in things with <b>svabhāva</b> — own-nature — whether the self, God, atoms or Abhidharma dharmas. Nagarjuna denied any such foundation.',
      people='the <b>Sarvāstivāda</b> and other Abhidharma realists he targeted; Brahmanical thinkers positing a substantial ātman; the Prajñāpāramitā tradition behind him.',
      what='<b>Śūnyatā</b> holds that <b>all phenomena are empty of svabhāva</b> — they have no intrinsic nature and exist only in dependence on conditions, parts and concepts; even <b>nirvana and buddhahood</b> are empty.',
      crux='The point is precise: emptiness is <b>the absence of independent essence</b>, not the absence of things — “emptiness is always the emptiness of something.”',
      conseq='It steers between <b>eternalism</b> (things have fixed essences) and <b>nihilism</b> (nothing exists at all) — the genuine Middle Way.',
      matters='It is a radically relational metaphysics: to be is to be interdependent — a view that still speaks to modern anti-foundationalist thought.'),

    E('pratitya', 'core doctrine', 'Emptiness = dependent origination', ['IDEAS', 'TURNING POINT'],
      'Nagarjuna’s decisive move is to identify emptiness with pratītyasamutpāda, dependent origination. In the pivotal verse (MMK 24.18) he declares that whatever is dependently arisen is what he calls emptiness — and that this itself, being a dependent designation, is precisely the Middle Way.',
      svg_stack('The identity that defines Madhyamaka', [
          {'n': 1, 'label': 'Whatever arises dependently…', 'sub': 'pratītyasamutpāda — the old Buddhist law', 'color': '#7c3aed'},
          {'n': 2, 'label': '…is what we call emptiness', 'sub': 'to depend is to lack own-nature (MMK 24.18)', 'color': '#b45309'},
          {'n': 3, 'label': '…which is itself the Middle Way', 'sub': 'a merely dependent designation', 'color': '#166534'},
      ], takeaway='Dependent arising and emptiness are two names for one fact — the equation at the heart of the Middle Way.', accent=AC),
      bg='The Buddha had taught <b>dependent origination</b> — things arise in dependence on conditions. Nagarjuna read this as directly <b>entailing</b> emptiness.',
      people='the <b>historical Buddha</b>, whose teaching he claimed to be systematising; opponents who charged that emptiness made Buddhist practice meaningless.',
      what='In <b>MMK 24.18</b> he states that <b>what is dependently arisen, that we call emptiness</b>; being a <b>dependent designation</b>, it is itself <b>the Middle Way</b> — welding three key terms into one identity.',
      crux='The logic is tight: if a thing <b>depends</b> on causes and parts, it cannot have <b>independent essence</b> — so dependence and emptiness are the same insight seen twice.',
      conseq='This let him answer the nihilism charge: far from destroying the world, <b>only because things are empty can they arise and function</b> at all.',
      matters='It reframes the Buddha’s oldest teaching as a metaphysics of interdependence — arguably the most consequential move in Mahayana philosophy.'),

    E('twotruths', 'core doctrine', 'The two truths', ['IDEAS'],
      'To hold everyday life and radical emptiness together, Nagarjuna deploys the two truths: saṃvṛti-satya, conventional or concealing truth — the world of tables, persons and practice — and paramārtha-satya, ultimate truth, that all of it is empty. Chapter 24 warns that without grasping this distinction one cannot grasp the Buddha’s teaching at all.',
      svg_compare('Two levels of truth, one reality', {
          'head': 'Conventional — saṃvṛti-satya', 'color': '#7c3aed',
          'items': ['The everyday world of things and selves', 'Language, causation, karma, practice', 'True “for practical purposes”', 'Where the Buddha teaches and we live'],
      }, {
          'head': 'Ultimate — paramārtha-satya', 'color': '#b45309',
          'items': ['All phenomena are empty of svabhāva', 'No independent essences anywhere', 'Even “emptiness” is not a final thing', 'What analysis finally discloses'],
      }, verdict='The two truths are not two worlds but two ways of speaking about one — and both are needed.',
         takeaway='Convention lets life and practice go on; the ultimate reveals its emptiness. Lose either and you miss the Middle Way.', accent=AC),
      bg='If everything is empty, opponents asked, how can there be morality, causation or a path? Nagarjuna answered with a <b>doctrine of two truths</b>.',
      people='the <b>Abhidharma</b> critics who feared emptiness dissolved the Dharma; later interpreters (esp. <b>Candrakīrti</b>) who refined the two-truths reading.',
      what='He distinguishes <b>saṃvṛti-satya</b> (conventional/concealing truth — the functioning everyday world) from <b>paramārtha-satya</b> (ultimate truth — universal emptiness); <b>MMK ch. 24</b> insists the Buddha’s teaching rests on both.',
      crux='The ultimate truth is subtle: it is <b>not another thing behind appearances</b> but the very emptiness of appearances — “the ultimate truth is that there is no ultimate, foundational reality.”',
      conseq='It preserves <b>conventional reality</b> — ethics, karma, the path all hold at the everyday level — while denying it any intrinsic ground.',
      matters='It is a template for reconciling a radical metaphysics with ordinary life, endlessly debated across Tibetan and East Asian Buddhism.'),

    E('catuskoti', 'method', 'The catuṣkoṭi — the four-cornered negation', ['IDEAS'],
      'His signature logical tool is the catuṣkoṭi, the tetralemma: for any thesis he lays out four exhaustive options — it is; it is not; it both is and is not; it neither is nor is not — and negates all four, leaving the mind with no position to cling to. Even emptiness itself, he warns, must not be reified into a view.',
      svg_stack('Refuting all four corners', [
          {'n': 1, 'label': 'It IS  /  It is NOT', 'sub': 'existence and non-existence both fail', 'color': '#b45309'},
          {'n': 2, 'label': 'BOTH  /  NEITHER', 'sub': 'the remaining two corners fall as well', 'color': '#7c3aed'},
          {'n': 3, 'label': 'No view left to grasp', 'sub': '“the empty” too must not be asserted', 'color': '#166534'},
      ], takeaway='By negating every possible position, the tetralemma cures the grasping mind — including any grasping at emptiness.', accent=AC),
      bg='Indian logic framed a claim in <b>four exhaustive alternatives</b>. Nagarjuna turned this <b>catuṣkoṭi</b> into an instrument of therapeutic negation.',
      people='the <b>Nyāya</b> logicians whose framework he borrowed and subverted; later readers who debate whether he rejects classical logic or uses it against essentialism.',
      what='For a given essentialist thesis he refutes all four corners — <b>is, is-not, both, neither</b> — so no position survives; and he cautions that <b>“empty” should not be asserted, nor “non-empty”</b>, lest emptiness become a new fixed view.',
      crux='The aim is <b>diagnostic, not doctrinal</b>: to dissolve the craving for a settled metaphysical position, not to install one more.',
      conseq='It made Madhyamaka famous for a <b>“no-thesis” stance</b> — Nagarjuna claimed to advance no proposition of his own, only to refute others’.',
      matters='It anticipates later anti-foundationalism and still fascinates logicians studying paraconsistent and four-valued systems.'),

    E('nirvana', 'MMK ch. 25', 'Nirvāṇa is not other than saṃsāra', ['IDEAS', 'TURNING POINT'],
      'The boldest consequence comes in chapter 25: since both nirvana and the round of rebirth (saṃsāra) are empty of intrinsic nature, there is not the slightest difference between them. Liberation is not escape to another realm but a transformed seeing of this one — the end of grasping, not a change of place.',
      svg_row('Freedom found here, not elsewhere', [
          {'n': 1, 'label': 'Saṃsāra is empty', 'sub': 'the round of rebirth has no own-nature', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Nirvana is empty too', 'sub': 'so is the goal of the path', 'color': '#b45309'},
          {'n': 3, 'label': 'No gap between them', 'sub': 'liberation is seeing this world rightly', 'color': '#166534'},
      ], edge_labels=['and', 'so'], takeaway='If both are empty, nirvana is not a place to reach but a way of seeing — awakening within saṃsāra itself.', accent=AC),
      bg='Earlier Buddhism could suggest nirvana as an <b>escape</b> from saṃsāra. Nagarjuna pressed emptiness to its limit and applied it to <b>the goal itself</b>.',
      people='the <b>Abhidharma</b> schools that treated nirvana as an unconditioned real entity; Mahayana teachers who drew the bodhisattva’s worldly engagement from this identity.',
      what='<b>MMK chapter 25 (Nirvāṇaparīkṣā)</b> argues that <b>“there is not the slightest difference between saṃsāra and nirvana”</b> — both being empty of svabhāva, they cannot be two ontologically separate states.',
      crux='Nirvana is <b>not a thing to be attained</b> but the cessation of reifying and grasping — the same world, no longer clung to.',
      conseq='It underpins the <b>bodhisattva ideal</b>: the awakened need not flee the world, and compassion can operate fully within it.',
      matters='It relocates liberation from a metaphysical elsewhere to a transformed relationship with ordinary reality — a lasting theme of Zen and Tibetan practice.'),
]

# ==================================================================  PHASE 3 — THE WIDER CORPUS
PHASE_CORPUS = [
    E('vigraha', 'c. 2nd c. CE', 'Vigrahavyāvartanī — the Dispeller of Disputes', ['IDEAS', 'BATTLE'],
      'When critics objected that his own thesis of universal emptiness must itself be empty — and so self-refuting — Nagarjuna answered in the Vigrahavyāvartanī ("Dispeller of Disputes"), a verse-and-commentary work turning the tables on the Nyāya theory of valid cognition and insisting that he asserts no thesis with svabhāva to refute.',
      svg_stack('Turning the self-refutation charge back', [
          {'n': 1, 'label': 'Objection: your emptiness is empty', 'sub': 'so it cannot negate anything — self-defeating', 'color': '#9f1239'},
          {'n': 2, 'label': 'Reply: I make no thesis with svabhāva', 'sub': 'my words are empty, yet still function', 'color': '#b45309'},
          {'n': 3, 'label': 'The pramāṇas are attacked', 'sub': 'Nyāya’s “means of knowledge” have no ground', 'color': '#7c3aed'},
      ], takeaway='Emptiness applies to itself without collapse — empty words still do their work, like an illusion undoing an illusion.', accent=AC),
      bg='The <b>Nyāya</b> school held that knowledge rests on self-established <b>pramāṇas</b> (perception, inference, etc.). Critics used this to charge that emptiness undermines itself.',
      people='the <b>Naiyāyika</b> logicians whose epistemology he critiqued; later Madhyamaka epistemologists who continued the pramāṇa debate.',
      what='The <b>Vigrahavyāvartanī</b> (with its auto-commentary) answers the self-refutation objection by arguing Nagarjuna <b>advances no essentialist thesis</b>, and by showing the <b>pramāṇas cannot ground themselves</b> without vicious regress.',
      crux='His words, like everything else, are <b>empty yet effective</b> — a conjured figure can defeat another conjured figure without either being real.',
      conseq='It secured the <b>coherence of the emptiness thesis</b> and opened a long Buddhist–Nyāya battle over the foundations of knowledge.',
      matters='It is a classic of self-reference in philosophy — how a universal claim can include itself without imploding.'),

    E('yukti', 'c. 2nd c. CE', 'The reasoning corpus — Yuktiṣaṣṭikā and beyond', ['IDEAS'],
      'Around the MMK cluster a set of shorter argumentative works — the Yuktiṣaṣṭikā ("Sixty Stanzas on Reasoning"), the Śūnyatāsaptati ("Seventy Stanzas on Emptiness"), and the Vaidalyaprakaraṇa ("Treatise on Pulverisation") — that extend and defend the doctrine, often reconciling emptiness with dependent origination and pulverising the Nyāya categories.',
      svg_row('Sharpening the argument for emptiness', [
          {'n': 1, 'label': 'Yuktiṣaṣṭikā — 60 stanzas', 'sub': 'reasoning that reconciles emptiness & arising', 'color': '#b45309'},
          {'n': 2, 'label': 'Śūnyatāsaptati — 70 stanzas', 'sub': 'a focused defence of emptiness', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Vaidalyaprakaraṇa', 'sub': '“pulverising” Nyāya’s 16 categories', 'color': '#166534'},
      ], edge_labels=['plus', 'plus'], takeaway='A whole toolkit of short treatises builds out the case — the “Yukti corpus” of reasoned defences of emptiness.', accent=AC),
      bg='The MMK’s bare verses invited both attack and misreading, so Nagarjuna (and the tradition under his name) produced <b>supporting treatises</b> that argue the case from new angles.',
      people='the <b>Abhidharma and Nyāya</b> opponents answered in these works; scholar <b>Christian Lindtner</b>, who identified the core genuinely-attributed set.',
      what='The <b>Yuktiṣaṣṭikā</b> shows reasoning itself points to emptiness; the <b>Śūnyatāsaptati</b> defends emptiness in seventy verses; the <b>Vaidalyaprakaraṇa</b> dismantles the <b>sixteen categories of Nyāya logic</b>.',
      crux='Together they form the <b>“Yukti corpus”</b> — the analytical wing of his output, where emptiness is argued rather than simply asserted.',
      conseq='They gave Madhyamaka a <b>battery of arguments</b> that later commentators mined for centuries.',
      matters='They show a philosopher building a research programme, not a lone tract — argument reinforced from every side.'),

    E('ratnavali', 'late 2nd c. CE', 'Ratnāvalī — a garland of counsel for a king', ['POLITICS', 'REFORM'],
      'Not all of Nagarjuna is dialectic. The Ratnāvalī ("Precious Garland"), addressed to a Satavahana king, weds the philosophy of emptiness to practical ethics and statecraft — urging just governance, generosity to the poor, hospitals and rest-houses, and the bodhisattva path of wisdom joined to compassion.',
      svg_stack('Emptiness turned toward good government', [
          {'n': 1, 'label': 'Advice to a reigning king', 'sub': 'the Precious Garland (Ratnāvalī)', 'color': '#b45309'},
          {'n': 2, 'label': 'Wisdom joined to compassion', 'sub': 'emptiness plus the bodhisattva path', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Just rule and public welfare', 'sub': 'generosity, hospitals, rest-houses, mercy', 'color': '#166534'},
      ], takeaway='The Precious Garland shows emptiness is not quietist — it grounds an ethic of compassionate, generous rule.', accent=AC),
      bg='As royal counsellor, Nagarjuna wrote for a <b>ruler’s guidance</b>, blending metaphysics with the duties of a Buddhist king.',
      people='the <b>Satavahana monarch</b> addressed; the wider <b>Mahayana</b> tradition that took the Ratnāvalī as a manual of the bodhisattva path.',
      what='The <b>Ratnāvalī</b> teaches <b>emptiness and the bodhisattva ideal</b> alongside concrete policy — <b>generosity, care for the sick and destitute, public works, and compassionate justice</b> — as expressions of wisdom in action.',
      crux='It shows the two wings of Mahayana in one text: <b>prajñā (wisdom/emptiness) and karuṇā (compassion)</b> must be practised together.',
      conseq='It became a <b>touchstone for Buddhist ethics and social thought</b>, quoted by later masters across the Mahayana world.',
      matters='It refutes the caricature of emptiness as world-denial — here it fuels an active programme of compassionate governance.'),

    E('suhrllekha', 'late 2nd c. CE', 'Suhṛllekha — the Letter to a Friend', ['IDEAS', 'LEGACY'],
      'The Suhṛllekha ("Letter to a Good Friend"), a verse epistle likewise sent to a friendly king, distils Buddhist practice into memorable counsel on ethics, mindfulness, impermanence and the sufferings of saṃsāra — a work so beloved it became a staple of monastic education in Tibet, learned by generations of monks.',
      svg_row('Philosophy made portable', [
          {'n': 1, 'label': 'A verse letter to a king', 'sub': 'friendly, practical Dharma advice', 'color': '#b45309'},
          {'n': 2, 'label': 'Ethics, mindfulness, impermanence', 'sub': 'the whole path in a few verses', 'color': '#7c3aed'},
          {'n': 3, 'label': 'A classroom staple in Tibet', 'sub': 'memorised for centuries by monks', 'color': '#166534'},
      ], edge_labels=['on', 'and'], takeaway='The Letter to a Friend carried Nagarjuna’s practical wisdom into everyday monastic training for over a thousand years.', accent=AC),
      bg='Alongside his technical treatises, Nagarjuna wrote <b>accessible works of guidance</b> for lay and royal followers who needed the path, not the dialectic.',
      people='the <b>royal correspondent</b> it addresses; the <b>Tibetan monastic colleges</b> that later made it a set text.',
      what='The <b>Suhṛllekha</b> is a friendly verse <b>letter on Buddhist practice</b> — right conduct, mindfulness of death and impermanence, the perils of saṃsāra and the way beyond — condensed for memorisation.',
      crux='It proves Nagarjuna could teach <b>at the level of lived practice</b>, not only high metaphysics — the same mind, a different register.',
      conseq='It entered the <b>core curriculum of Tibetan Buddhism</b> and remains among the most widely studied of his works.',
      matters='Enduring influence often runs through the simple text, not the difficult one — the Letter reached far more people than the MMK ever could.'),
]

# ==================================================================  PHASE 4 — SCHOOL, COMMENTATORS & LEGACY
PHASE_LEGACY = [
    E('aryadeva', 'c. 3rd c. CE', 'Āryadeva and the birth of a school', ['LEGACY', 'RISE'],
      'Nagarjuna’s ideas became a lineage through his disciple Āryadeva, whose Catuḥśataka ("Four Hundred Verses") extended the master’s method — turning the MMK from one brilliant book into the Madhyamaka, a self-conscious school with a defended body of doctrine.',
      svg_stack('From a text to a tradition', [
          {'n': 1, 'label': 'Āryadeva, chief disciple', 'sub': 'carries the argument forward', 'color': '#7c3aed'},
          {'n': 2, 'label': 'The Catuḥśataka — 400 verses', 'sub': 'extends the refutation of svabhāva', 'color': '#b45309'},
          {'n': 3, 'label': 'Madhyamaka becomes a school', 'sub': 'a lineage, not a lone treatise', 'color': '#166534'},
      ], takeaway='A disciple turned a masterpiece into a movement — Āryadeva made the MMK the seed of a lasting school.', accent=AC),
      bg='A single text, however brilliant, needs <b>heirs</b> to become a tradition. Nagarjuna found his in <b>Āryadeva</b>.',
      people='<b>Āryadeva</b>, his direct pupil; later <b>Candrakīrti</b>, who commented on Āryadeva’s work and linked the lineage together.',
      what='<b>Āryadeva</b> composed the <b>Catuḥśataka (Four Hundred Verses)</b>, developing and defending Nagarjuna’s arguments and applying them to fresh opponents, so the teaching hardened into the <b>Madhyamaka school</b>.',
      crux='Doctrine survives by <b>transmission</b> — a named successor who both preserves and advances the founder’s method.',
      conseq='The Nagarjuna–Āryadeva pair became the <b>root of the Madhyamaka lineage</b> revered across later Buddhism.',
      matters='Movements need a second figure as much as a first — the disciple who proves the master was not a one-off.'),

    E('commentators', '5th–7th c. CE', 'Buddhapālita, Bhāviveka, Candrakīrti', ['IDEAS', 'BATTLE'],
      'Centuries later, great commentators fought over how to read the MMK. Buddhapālita argued purely by drawing absurd consequences from opponents’ views; Bhāviveka insisted Madhyamaka must advance formal syllogisms; and Candrakīrti’s Prasannapadā defended Buddhapālita — a clash that split the school into Prāsaṅgika and Svātantrika wings.',
      svg_compare('How should a Madhyamika argue?', {
          'head': 'Prāsaṅgika (Buddhapālita, Candrakīrti)', 'color': '#b45309',
          'items': ['Only reduce opponents to absurdity', 'Advance no positive thesis of one’s own', 'Candrakīrti’s Prasannapadā its classic', 'Later the “official” Tibetan reading'],
      }, {
          'head': 'Svātantrika (Bhāviveka)', 'color': '#7c3aed',
          'items': ['Use independent formal syllogisms', 'Assert autonomous probative arguments', 'Bhāviveka’s Prajñāpradīpa its manifesto', 'Charged with conceding too much'],
      }, verdict='One founder, two methods — a dispute over logic that shaped a millennium of commentary.',
         takeaway='Reading Nagarjuna became its own discipline: does the Middle Way prove nothing, or must it argue formally?', accent=AC),
      bg='The MMK’s <b>compressed, thesis-free style</b> left room for rival interpretations of how emptiness should actually be argued.',
      people='<b>Buddhapālita</b> (c. 470–550), <b>Bhāviveka</b> (c. 500–578) and <b>Candrakīrti</b> (7th c.), whose <b>Prasannapadā</b> became the most influential commentary.',
      what='<b>Buddhapālita</b> argued by pure <b>reductio (prasaṅga)</b>; <b>Bhāviveka</b> demanded <b>independent syllogisms (svatantra)</b>; <b>Candrakīrti</b> sided with Buddhapālita, and the school divided into <b>Prāsaṅgika</b> and <b>Svātantrika</b>.',
      crux='The quarrel was <b>methodological</b>: may a Madhyamika assert a positive argument, or only dismantle the opponent’s?',
      conseq='<b>Candrakīrti’s Prāsaṅgika reading</b> eventually became the orthodox interpretation in <b>Tibetan Buddhism</b>.',
      matters='A founding text can generate centuries of second-order debate — how to read Nagarjuna became a philosophy in its own right.'),

    E('transmission', '5th c. CE onward', 'The "second Buddha" across Asia', ['LEGACY', 'TRIUMPH'],
      'Nagarjuna’s reach became pan-Asian. Tibetans call him a "second Buddha" and made Prāsaṅgika Madhyamaka their official view; in China his thought founded the Sanlun (Three-Treatise) school; and, as author of the Daśabhūmika-vibhāṣā, he was honoured as a patriarch of Pure Land Buddhism — one of the few figures revered from Lhasa to Kyoto.',
      svg_row('One thinker, a continent of schools', [
          {'n': 1, 'label': 'Tibet: the “second Buddha”', 'sub': 'Prāsaṅgika Madhyamaka the official view', 'color': '#b45309'},
          {'n': 2, 'label': 'China: the Sanlun school', 'sub': '“Three Treatises” built on the MMK', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Pure Land & Zen patriarch', 'sub': 'honoured from India to Japan', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='From India his emptiness spread to Tibet, China, Korea and Japan — few thinkers are patriarchs of so many traditions.', accent=AC),
      bg='As Buddhism migrated north and east, Nagarjuna’s writings travelled with it and became a <b>shared point of reference</b> for otherwise divergent schools.',
      people='the <b>Tibetan</b> tradition that named him a second Buddha; <b>Kumārajīva</b>, whose translations founded Chinese <b>Sanlun</b>; the <b>Pure Land</b> lineage that claimed him as a patriarch.',
      what='In <b>Tibet</b> he is a <b>“second Buddha”</b> and Prāsaṅgika Madhyamaka the state doctrine; in <b>East Asia</b> his verses founded the <b>Sanlun (Three-Treatise) school</b>, and via the <b>Daśabhūmika-vibhāṣā</b> he became a <b>Pure Land patriarch</b>, revered too in Chan/Zen and esoteric lineages.',
      crux='His appeal is his <b>generality</b>: emptiness is a framework adaptable to devotional, meditative and philosophical Buddhism alike.',
      conseq='He is counted among the tradition’s supreme masters — “the most important Buddhist philosopher after the Buddha himself.”',
      matters='Few individuals are foundational to so many living traditions at once — his influence is the whole northern Buddhist world.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Nagarjuna was the 2nd-century Indian monk-philosopher who gave Mahayana Buddhism its intellectual backbone. Founder of the <b>Madhyamaka (Middle Way)</b> school and author of the <b>Mūlamadhyamakakārikā</b>, he argued that nothing whatsoever possesses <b>svabhāva</b> — intrinsic, independent nature — because everything arises dependently. His doctrine of <b>śūnyatā (emptiness)</b>, his equation of emptiness with <b>dependent origination</b>, his <b>two truths</b> and his <b>tetralemma</b> reset Buddhist metaphysics and rippled out to Tibet, China, Korea and Japan. His life is thin and half-legendary; his ideas are among the most consequential in Asian thought. He is the ultimate study in <b>rigorous negation, radical interdependence, and the Middle Way between eternalism and nihilism.</b></p>
<div class="ov-quote">“Whatever is dependently arisen, that we declare to be emptiness; that is a dependent designation, and is itself the Middle Way.”<span>— Mūlamadhyamakakārikā 24.18</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A monk of South India tied to Satavahana kings and wrapped in legend (the nagas, the elixir) → writes the Mūlamadhyamakakārikā and founds Madhyamaka → argues that all things are empty of intrinsic nature, identifying emptiness with dependent origination → holds it together with the two truths and the four-cornered negation, and equates nirvana with saṃsāra → extends the case in the Vigrahavyāvartanī and reasoning treatises, and teaches ethics to a king in the Ratnāvalī → and, through Āryadeva and the great commentators, becomes a “second Buddha” revered across Buddhist Asia.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">☸️</div><h4>The Middle Way</h4><p>A path between “things have fixed essences” and “nothing exists.”</p></div>
  <div class="ov-card"><div class="i">🕸️</div><h4>Radical interdependence</h4><p>To exist is to depend — emptiness as a relational metaphysics.</p></div>
  <div class="ov-card"><div class="i">🌀</div><h4>The tetralemma</h4><p>Negating all four corners to free the mind of every fixed view.</p></div>
  <div class="ov-card"><div class="i">🌏</div><h4>A pan-Asian legacy</h4><p>Foundational to Tibetan, Chan/Zen and Pure Land Buddhism alike.</p></div>
</div>
<div class="ov-lbl">The four chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Life &amp; Legend</b><small> c. 150 CE</small><p>A shadowy South Indian monk, the Satavahana tie, the nagas and the elixir.</p></div>
  <div><b>2 · Emptiness</b><small> the doctrine</small><p>The MMK, śūnyatā, dependent origination, two truths, tetralemma, nirvana.</p></div>
  <div><b>3 · The Corpus</b><small> the works</small><p>Dispeller of Disputes, the reasoning treatises, Ratnāvalī, the Letter.</p></div>
  <div><b>4 · Legacy</b><small> after him</small><p>Āryadeva, the great commentators, and the reach across Asia.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the idea, then six branches (background, key people, what it says, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references. Because his biography is thin, legendary episodes (the nagas, the alchemy) are marked as tradition, and the guide leans on his ideas and works.</p>
"""

WHO = [
    {'name': 'The Buddha', 'role': 'source', 'color': '#166534',
     'bio': 'The historical founder of Buddhism, whose teaching of dependent origination Nagarjuna claimed to be systematising through the doctrine of emptiness.',
     'rel': 'The authority he read as already implying śūnyatā.'},
    {'name': 'Āryadeva', 'role': 'chief disciple', 'color': '#7c3aed',
     'bio': 'Nagarjuna’s direct pupil, author of the Catuḥśataka (Four Hundred Verses), who extended the master’s arguments and turned a text into a school.',
     'rel': 'The successor who founded the Madhyamaka lineage with him.'},
    {'name': 'Candrakīrti', 'role': 'great commentator', 'color': '#b45309',
     'bio': 'Seventh-century master whose Prasannapadā defended the Prāsaṅgika reading of Nagarjuna and became the interpretation later adopted as orthodox in Tibet.',
     'rel': 'His most influential later interpreter.'},
    {'name': 'Bhāviveka', 'role': 'rival reading', 'color': '#4f46e5',
     'bio': 'Sixth-century commentator who insisted Madhyamaka must advance independent formal syllogisms, founding the Svātantrika wing against Buddhapālita.',
     'rel': 'The commentator whose method split the school.'},
    {'name': 'Yajña Śrī Śātakarṇi', 'role': 'royal patron', 'color': '#9f1239',
     'bio': 'Satavahana king of the Deccan (later 2nd century) whom scholarship links to Nagarjuna as patron and as the addressee of the Ratnāvalī and the Suhṛllekha.',
     'rel': 'The king who gives his floating life a datable anchor.'},
]

KEY_EVENTS = [
    ('c. 150 CE', 'Born in South India', 'A monk-philosopher whose life is largely legendary.'),
    ('late 2nd c.', 'Satavahana patronage', 'Advisor to a Deccan king; writes the Ratnāvalī.'),
    ('c. 2nd c.', 'Mūlamadhyamakakārikā', 'Founds Madhyamaka; 450 verses on emptiness.'),
    ('doctrine', 'Śūnyatā of svabhāva', 'Nothing has intrinsic, independent nature.'),
    ('MMK 24.18', 'Emptiness = dependent arising', 'The identity at the heart of the Middle Way.'),
    ('MMK 24', 'The two truths', 'Conventional and ultimate, needed together.'),
    ('MMK 25', 'Nirvāṇa = saṃsāra', 'Both empty; no gap between them.'),
    ('c. 2nd c.', 'Vigrahavyāvartanī', 'Answers the self-refutation charge.'),
    ('c. 3rd c.', 'Āryadeva', 'The disciple who makes it a school.'),
    ('5th–7th c.', 'Prāsaṅgika vs Svātantrika', 'Commentators split over method.'),
]

MASTER = [
    {'year': 'c. 150 CE', 'age': 'birth', 'phase': 'Life & Legend', 'title': 'Born in South India', 'desc': 'A monk of the far south; a life half in legend.'},
    {'year': 'late 2nd c.', 'age': 'maturity', 'phase': 'Life & Legend', 'title': 'Satavahana patron', 'desc': 'Counsellor to a Deccan king near Amaravati.'},
    {'year': 'c. 2nd c.', 'age': 'prime', 'phase': 'Emptiness', 'title': 'Writes the MMK', 'desc': 'Founds Madhyamaka; the doctrine of śūnyatā.'},
    {'year': 'c. 2nd c.', 'age': 'prime', 'phase': 'The Corpus', 'title': 'The wider works', 'desc': 'Vigrahavyāvartanī, Ratnāvalī, the Letter to a Friend.'},
    {'year': 'c. 3rd c.', 'age': 'after', 'phase': 'Legacy', 'title': 'Āryadeva', 'desc': 'A disciple turns the text into a school.'},
    {'year': '5th c. on', 'age': 'legacy', 'phase': 'Legacy', 'title': 'A “second Buddha”', 'desc': 'Revered across Tibet, China, Korea and Japan.'},
]

SOURCES = [
    ('Stanford Encyclopedia of Philosophy — Nāgārjuna', 'https://plato.stanford.edu/entries/nagarjuna/'),
    ('Wikipedia — Nāgārjuna', 'https://en.wikipedia.org/wiki/Nagarjuna'),
    ('Wikipedia — Mūlamadhyamakakārikā', 'https://en.wikipedia.org/wiki/M%C5%ABlamadhyamakak%C4%81rik%C4%81'),
    ('Britannica — Nagarjuna', 'https://www.britannica.com/biography/Nagarjuna'),
    ('Internet Encyclopedia of Philosophy — Nāgārjuna', 'https://iep.utm.edu/nagarjun/'),
    ('Internet Encyclopedia of Philosophy — Madhyamaka', 'https://iep.utm.edu/madhyamaka-buddhist-philosophy/'),
]

def build_meta():
    return {
        'pid': 'gm-nagarjuna.html', 'kind': 'man', 'emoji': '☸️', 'accent': AC,
        'name': 'Nagarjuna', 'years': 'c. 150–250 CE', 'group': 'Sages, Poets & Philosophers',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The 2nd-century Indian monk-philosopher who founded the Madhyamaka school and, through the doctrine of śūnyatā (emptiness), reshaped Mahayana Buddhist thought from India to Tibet, China and Japan.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'life', 'label': '1 · Life & Legend', 'type': 'timeline',
             'intro': 'A shadowy South Indian monk of the 2nd century, anchored to the Satavahana kings and wrapped in legend — the nagas who kept the sutras and the alchemist’s elixir of long life.', 'events': PHASE_LIFE},
            {'id': 'emptiness', 'label': '2 · Emptiness', 'type': 'timeline',
             'intro': 'In the Mūlamadhyamakakārikā he founds Madhyamaka and unfolds the doctrine of śūnyatā — emptiness as dependent origination, the two truths, the tetralemma, and the identity of nirvana with saṃsāra.', 'events': PHASE_EMPTINESS},
            {'id': 'corpus', 'label': '3 · The Corpus', 'type': 'timeline',
             'intro': 'Beyond the MMK he defends emptiness against the charge of self-refutation, sharpens it in the reasoning treatises, and turns it toward ethics and statecraft for a king.', 'events': PHASE_CORPUS},
            {'id': 'legacy', 'label': '4 · Legacy', 'type': 'timeline',
             'intro': 'Through his disciple Āryadeva and the great commentators, a single book becomes a school — and Nagarjuna a “second Buddha” revered across the whole northern Buddhist world.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard reference and scholarly sources; much of the biography (the nagas, the alchemy, the Nalanda association) survives only as later hagiography and is read here as tradition, with the emphasis placed on the securely attributed works and ideas.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
