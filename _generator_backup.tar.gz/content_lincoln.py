# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Abraham Lincoln."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#1d4ed8'  # Union blue

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_selfmade():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">roughly one year of formal schooling — and a self-made mind</text>'
    boxes=[(40,'#78350f','A dirt-poor log cabin','frontier Kentucky; hard labour from boyhood'),
           (270,'#1d4ed8','Reads everything he can','borrows books; teaches himself by firelight'),
           (500,'#166534','Self-taught lawyer','passes the bar in 1836 with almost no schooling')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">From a floorless cabin to the bar to the White House — the archetypal American self-made rise.</text>'
    return _wrap(W, H, 'Log cabin to lawyer — the self-made man', _tk(b, W, H, 'With almost no schooling he taught himself law, logic and language — proof that character can outrun circumstance.'), '', AC)

def svg_housedivided():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">why a settled country tore itself in two</text>'
    b += '<rect x="40" y="60" width="300" height="82" rx="12" fill="#eff6ff" stroke="#1d4ed8" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#1d4ed8">The free North</text>'
    s1,_=_tspans(54,100,'slavery must not spread to the new western territories',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="82" rx="12" fill="#fef2f2" stroke="#7f1d1d" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#7f1d1d">The slave South</text>'
    s2,_=_tspans(394,100,'slavery is our right and our economy — and must be allowed to expand',10,'#7f1d1d',600,12,44); b+=s2
    b += '<line x1="352" y1="90" x2="368" y2="90" stroke="#94a3b8" stroke-width="1.6"/>'
    b += '<line x1="360" y1="76" x2="360" y2="126" stroke="#94a3b8" stroke-width="2.2" stroke-dasharray="4 3"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">“A house divided against itself cannot stand” — Lincoln saw the nation could not stay half-slave, half-free.</text>'
    return _wrap(W, H, 'A house divided — the coming storm', _tk(b, W, H, 'He named the truth others dodged: the Union could not endure permanently half slave and half free.'), '', AC)

def svg_emancipation():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1863 · turning a war for the Union into a war for freedom</text>'
    boxes=[(40,'#1d4ed8','A war measure','frees slaves in the rebel states as a military act'),
           (270,'#166534','A moral turning point','the war is now openly about ending slavery'),
           (500,'#b45309','Black soldiers enlist','~200,000 join the Union armies and navy')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">It freed few slaves the day it was signed — but it changed forever what the war was for.</text>'
    return _wrap(W, H, 'The Emancipation Proclamation', _tk(b, W, H, 'He timed a moral revolution as a war measure — making the Union’s survival and freedom the same cause.'), '', AC)

def svg_martyr():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">April 1865 · victory, then murder — five days apart</text>'
    boxes=[(40,'#166534','Appomattox, Apr 9','Lee surrenders; the war is effectively won'),
           (270,'#1d4ed8','“With malice toward none”','he plans a generous, healing peace'),
           (500,'#7f1d1d','Assassinated, Apr 14','shot by Booth at Ford’s Theatre; dies next morning')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Struck down at the very moment of victory, he passed from president into national martyr and legend.</text>'
    return _wrap(W, H, 'Victory and martyrdom', _tk(b, W, H, 'He won the war and died in the hour of triumph — sealing his place as America’s secular saint.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — LOG CABIN TO LAWYER
PHASE_RISE = [
    E('cabin', '1809–1830', 'A log-cabin boyhood', ['RISE'],
      'He is born in a one-room Kentucky log cabin to a barely literate farmer, loses his mother at nine, and grows up doing brutal frontier labour — with, all told, about a single year of formal schooling.',
      svg_stack('Born with nothing but a mind', [
          {'n': 1, 'label': 'A dirt-poor cabin', 'sub': 'frontier Kentucky, 1809; grinding poverty', 'color': '#78350f'},
          {'n': 2, 'label': 'Hard labour, little school', 'sub': 'roughly a year of schooling in total', 'color': '#b45309'},
          {'n': 3, 'label': 'A hunger to read', 'sub': 'borrows and devours every book he can find', 'color': '#1d4ed8'},
      ], takeaway='He began at the very bottom of American life — and educated himself almost entirely alone.', accent=AC),
      bg='Lincoln was born in <b>1809</b> in a log cabin on the Kentucky frontier, into deep poverty; the family later moved to <b>Indiana</b> and then <b>Illinois</b>.',
      people='His father <b>Thomas Lincoln</b>, a poor farmer; his mother <b>Nancy</b>, who died when he was nine; his stepmother <b>Sarah</b>, who encouraged his reading.',
      what='Lincoln grew up doing hard farm and manual labour — famously splitting rails — with almost <b>no formal education</b> (about a year total), but taught himself relentlessly from borrowed books by firelight.',
      crux='His rise was powered by <b>self-education and sheer will</b>: lacking every advantage, he built his mind by reading, memorising and reasoning things out for himself.',
      conseq='As a young man he struck out on his own, working as a flatboatman, store clerk and surveyor while continuing to study.',
      matters='The American ideal of the self-made man has no purer example. Lincoln rose from a floorless cabin by the power of his own mind.'),

    E('lawyer', '1831–1849', 'Rail-splitter to prairie lawyer', ['RISE', 'POLITICS'],
      'Settling in Illinois, he teaches himself law from borrowed books, is admitted to the bar, wins a seat in the state legislature, and becomes a respected prairie lawyer and a rising Whig politician — with one frustrating term in Congress.',
      svg_selfmade(),
      bg='In the 1830s Lincoln settled at <b>New Salem</b> and then <b>Springfield, Illinois</b>, entering law and Whig politics.',
      people='His law partner <b>William Herndon</b>; his wife <b>Mary Todd Lincoln</b>; rival Illinois politicians, above all <b>Stephen Douglas</b>.',
      what='Lincoln <b>taught himself law</b>, was admitted to the bar in <b>1836</b>, served in the <b>Illinois legislature</b> as a Whig, built a successful law practice, and served a single term in the <b>U.S. House (1847–49)</b>, where his opposition to the Mexican-American War hurt him politically.',
      crux='He mastered a demanding profession <b>without schooling or mentors of rank</b>, combining relentless self-study with a gift for plain reasoning and storytelling that made him formidable in court and on the stump.',
      conseq='By 1850 he was a prosperous, well-known Illinois lawyer — but his political career seemed to have stalled.',
      matters='Talent plus persistence beats pedigree. Lincoln built a distinguished career from nothing, the foundation for everything that followed.'),

    E('newsalem', '1831–1837', 'New Salem — failure, and the making of a man', ['RISE', 'TRAGEDY'],
      'Striking out on his own in the tiny village of New Salem, he fails at almost everything a young man can — a store that goes bust and leaves him deep in debt, a militia stint in the Black Hawk War, odd jobs as postmaster and surveyor — yet he is so trusted and well-liked that he wins a seat in the legislature and reads his way into the law.',
      svg_row('Failing his way upward', [
          {'n': 1, 'label': 'A failed storekeeper', 'sub': 'his business collapses; years of debt follow', 'color': '#78350f'},
          {'n': 2, 'label': 'Odd jobs and militia', 'sub': 'postmaster, surveyor, the Black Hawk War', 'color': '#b45309'},
          {'n': 3, 'label': 'Trusted into office', 'sub': 'wins a legislature seat; teaches himself law', 'color': '#1d4ed8'},
      ], edge_labels=['then', 'then'], takeaway='He failed at business but won people’s trust — the real capital that carried him into law and politics.', accent=AC),
      bg='As a young man Lincoln settled in the frontier village of <b>New Salem, Illinois</b>, trying his hand at many trades.',
      people='The people of New Salem, who liked and trusted him; his creditors, whom he insisted on repaying (“Honest Abe”).',
      what='At New Salem Lincoln <b>failed as a storekeeper</b> (running up debts he took years to repay), served briefly in the <b>Black Hawk War</b>, worked as <b>postmaster and surveyor</b>, and — trusted by his neighbours — won election to the <b>Illinois legislature</b> while teaching himself law.',
      crux='His early <b>business failures were offset by the trust he earned</b>: honesty and likeability, not success, opened his path into public life.',
      conseq='From this shaky start he built a respected legal and political career in Springfield.',
      matters='Character can outrun failure. Lincoln’s New Salem years show reputation and integrity mattering more than early success.'),

    E('congress', '1846–1849', 'One term in Congress — and a costly stand', ['POLITICS', 'DEFEAT'],
      'He wins a single term in Congress and promptly risks his career on principle: challenging the popular Mexican-American War with his "Spot Resolutions," demanding to know the exact spot where American blood was supposedly shed on American soil. The stand is honest but unpopular, and he leaves Washington with his prospects dimmed.',
      svg_row('Principle over popularity', [
          {'n': 1, 'label': 'Elected to Congress', 'sub': 'a single term as an Illinois Whig, 1847', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'The Spot Resolutions', 'sub': 'challenges the popular Mexican-American War', 'color': '#b45309'},
          {'n': 3, 'label': 'Politically costly', 'sub': 'the stand hurts him; he does not seek re-election', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'so'], takeaway='He risked his career to question an unjust war — honest, unpopular, and revealing of his moral seriousness.', accent=AC),
      bg='Lincoln served one term in the <b>U.S. House (1847–49)</b> during the <b>Mexican-American War</b>, which he considered unjustly provoked.',
      people='President <b>Polk</b>, whose war Lincoln challenged; the voters who disliked his stand.',
      what='In Congress Lincoln introduced the <b>“Spot Resolutions,”</b> demanding proof that American blood had been shed on American soil to justify the <b>Mexican-American War</b> — a principled but <b>unpopular</b> challenge that damaged him politically; he did not seek re-election.',
      crux='He showed early a willingness to <b>take an honest, costly stand</b> against a popular cause — moral seriousness over easy popularity.',
      conseq='His congressional term ended with his career apparently stalled, and he returned to law in Springfield.',
      matters='Moral courage often costs. Lincoln’s lonely stand on the Mexican War prefigured the principled leader he would become.'),

    E('railroadlawyer', '1849–1860', 'The prairie lawyer at his peak', ['RISE', 'POLITICS'],
      'Back from Washington, he becomes one of Illinois’ ablest and most successful attorneys, riding the circuit from town to town and handling everything from murder trials to the great railroad cases — in one famous trial using an almanac to prove a witness lied about the moonlight — building the reputation, income and network that make a presidential run possible.',
      svg_row('Mastering the law across the prairie', [
          {'n': 1, 'label': 'Rides the circuit', 'sub': 'travels town to town trying cases', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'The big railroad cases', 'sub': 'represents the era’s most powerful industry', 'color': '#0e7490'},
          {'n': 3, 'label': 'The Almanac Trial', 'sub': 'uses an almanac to expose a lying witness', 'color': '#166534'},
      ], edge_labels=['plus', 'plus'], takeaway='He became a top-tier lawyer — the income, skill and network that a presidential campaign would need.', accent=AC),
      bg='Through the 1850s Lincoln built a leading law practice in Illinois, riding the <b>circuit</b> and handling major cases, including for the booming <b>railroads</b>.',
      people='His law partner <b>William Herndon</b>; the railroad clients; the juries he swayed with plain reasoning and storytelling.',
      what='Lincoln became one of Illinois’ <b>most respected and successful lawyers</b>, trying a huge range of cases — including major <b>railroad litigation</b> and the famous <b>“Almanac Trial,”</b> where he used an almanac to disprove a witness’s claim of bright moonlight.',
      crux='He honed the <b>plain-spoken reasoning, integrity and network</b> that would define his politics — and earned the standing to aim at national office.',
      conseq='By the late 1850s he was prosperous, widely respected, and ready to return to the national stage over slavery.',
      matters='Mastery in one arena builds the platform for another. Lincoln’s legal eminence gave him the credibility and means for his political rise.'),

    E('reawaken', '1854', 'Slavery pulls him back into politics', ['POLITICS', 'TURNING POINT'],
      'He has half-left politics — until the Kansas-Nebraska Act threatens to spread slavery into the western territories. Outraged, he throws himself back into public life and helps build the new anti-slavery Republican Party.',
      svg_row('The issue that remade his career', [
          {'n': 1, 'label': 'Kansas-Nebraska Act, 1854', 'sub': 'lets new territories choose slavery', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Lincoln is galvanised', 'sub': 'returns to politics against slavery’s spread', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'Joins the Republicans', 'sub': 'helps build the new anti-slavery party', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='A single law dragged him back into politics — and gave him the cause of his life.', accent=AC),
      bg='The <b>Kansas-Nebraska Act (1854)</b>, pushed by Stephen Douglas, allowed settlers in new territories to decide on slavery, reopening the question and inflaming the nation.',
      people='Senator <b>Stephen Douglas</b>, author of the Act; the founders of the new <b>Republican Party</b>.',
      what='The Act reignited Lincoln’s political passion. He re-entered public life with powerful speeches against the <b>expansion of slavery</b> and became a leader of the emerging <b>Republican Party</b> in Illinois.',
      crux='He found his defining cause — <b>stopping the spread of slavery</b> — and a moral clarity that lifted his rhetoric and his ambition to a new level.',
      conseq='Lincoln rose to national attention as the West’s most articulate opponent of slavery’s expansion, setting up his clash with Douglas.',
      matters='A great cause can transform a career. The slavery crisis turned a capable local lawyer into a figure of national moral force.'),
]

# ==================================================================  PHASE 2 — THE SLAVERY CRISIS
PHASE_CRISIS = [
    E('peoria', '1854', 'Peoria — finding his moral voice', ['POLITICS', 'TURNING POINT'],
      'His return to politics finds its full voice in a single great speech at Peoria, where for three hours he lays out the moral case against slavery’s spread with a clarity that startles the country — condemning slavery as a “monstrous injustice” while carefully staying within the Constitution, the argument that would define the rest of his life.',
      svg_row('The speech that set his course', [
          {'n': 1, 'label': 'The Peoria speech, 1854', 'sub': 'a three-hour moral case against slavery’s spread', 'color': '#1d4ed8'},
          {'n': 2, 'label': '“A monstrous injustice”', 'sub': 'names slavery a moral wrong, plainly', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Yet within the law', 'sub': 'opposes spread, not immediate abolition', 'color': '#166534'},
      ], edge_labels=['then', 'yet'], takeaway='At Peoria he fused moral clarity with constitutional caution — the exact balance that would define his career.', accent=AC),
      bg='Responding to the Kansas-Nebraska Act, Lincoln delivered a landmark address at <b>Peoria, Illinois (1854)</b>, his fullest early statement on slavery.',
      people='Stephen Douglas, whose Act Lincoln answered; the audiences moved by the speech.',
      what='In the <b>Peoria speech</b>, Lincoln argued for three hours that slavery was a <b>“monstrous injustice,”</b> that it must not spread to new territories, yet that the Constitution had to be respected — striking the <b>moral-but-constitutional balance</b> that would guide him to the presidency.',
      crux='He found the <b>voice that combined moral conviction with legal restraint</b> — condemning slavery’s expansion without lawless radicalism.',
      conseq='Peoria marked Lincoln’s full emergence as a moral leader on slavery, setting up the debates and his rise.',
      matters='A single speech can define a career. At Peoria, Lincoln fixed the moral and constitutional stance he would hold to the end.'),

    E('debates', '1858', 'The Lincoln–Douglas debates', ['POLITICS', 'TURNING POINT'],
      'Running for the Senate against Douglas, he loses the seat but wins the nation: their seven great debates over slavery, freedom and union make Lincoln a household name across the country.',
      svg_compare('Two visions of America, on one stage',
          {'head': 'Lincoln', 'color': '#1d4ed8',
           'items': ['slavery is a moral wrong', 'it must not spread to new territories', 'the nation cannot stay half slave, half free']},
          {'head': 'Douglas', 'color': '#7f1d1d',
           'items': ['let each territory decide for itself', '“popular sovereignty” over morality', 'the Union can endure divided']},
          verdict='Lincoln lost the Senate seat but emerged a national figure and the conscience of the anti-slavery cause.',
          takeaway='He turned a losing Senate race into a national platform — losing the office but winning the argument.', accent=AC),
      bg='In <b>1858</b> Lincoln challenged <b>Stephen Douglas</b> for his U.S. Senate seat in Illinois, and the two held seven famous public debates on slavery and union.',
      people='<b>Stephen Douglas</b>, the powerful incumbent senator; the national press that carried the debates.',
      what='The <b>Lincoln–Douglas debates</b> drew huge crowds and national coverage. Lincoln lost the Senate election (chosen then by the legislature) but his clear moral case against slavery made him <b>nationally famous</b>.',
      crux='He grasped that the debates were a <b>national stage, not just a state race</b> — using them to define the moral stakes of slavery for the whole country.',
      conseq='Defeat in the Senate race positioned Lincoln as a leading national Republican and a serious presidential prospect.',
      matters='Sometimes losing the office wins the future. The debates made Lincoln the moral voice of a movement and a president-in-waiting.'),

    E('housedivided', '1858–1860', '“A house divided” and Cooper Union', ['POLITICS'],
      'He crystallises the crisis in unforgettable words — "a house divided against itself cannot stand" — and, in a masterful address at Cooper Union in New York, proves to the eastern establishment that this prairie lawyer is presidential timber.',
      svg_housedivided(),
      bg='Lincoln honed a message that the nation could not permanently endure <b>half slave and half free</b>, and sought to win over eastern Republicans.',
      people='Eastern Republican leaders and editors; the New York audience at <b>Cooper Union</b>.',
      what='In his <b>“House Divided” speech (1858)</b> Lincoln framed the irrepressible conflict; his carefully argued <b>Cooper Union address (1860)</b> in New York established his intellectual credibility with eastern elites.',
      crux='He combined <b>moral clarity with rigorous argument</b>, proving he was not merely a folksy westerner but a formidable thinker fit for the presidency.',
      conseq='These speeches propelled Lincoln to the front rank of Republicans just as the 1860 nomination approached.',
      matters='Words can make a leader. Lincoln’s gift for expressing a moral truth memorably was central to his rise and his greatness.'),

    E('election', '1860–1861', 'Elected — and the Union breaks', ['POLITICS', 'TURNING POINT', 'TRAGEDY'],
      'He wins the presidency in a four-way race without a single Southern electoral vote — and before he can even take office, Southern states begin to secede, determined to leave rather than accept his election.',
      svg_row('Elected president, and the country splits', [
          {'n': 1, 'label': 'Wins in 1860', 'sub': 'a four-way race; no Southern support', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'The South secedes', 'sub': 'states leave rather than accept the result', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'The Confederacy forms', 'sub': 'a rival government before he is even inaugurated', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='His lawful election was itself the trigger the South chose for disunion.', accent=AC),
      bg='In the <b>1860 election</b>, a divided Democratic Party and a four-candidate race let Lincoln win the presidency on a purely Northern vote.',
      people='His rivals in 1860; the Southern leaders who chose secession; his cabinet, assembled from former rivals (the "team of rivals").',
      what='Lincoln won the <b>1860 election</b> without carrying any Southern state. In response, <b>Southern states began to secede</b>, forming the <b>Confederacy</b> before his March 1861 inauguration.',
      crux='He faced the gravest crisis any incoming president had known: a <b>country dissolving</b> over his lawful election, forcing an immediate choice between disunion and war.',
      conseq='Lincoln took office committed to preserving the Union; within weeks the firing on Fort Sumter began the Civil War.',
      matters='Democracy’s hardest test is accepting an election you lose. The South’s refusal to do so plunged America into its bloodiest war.'),
]

# ==================================================================  PHASE 3 — THE WAR PRESIDENT
PHASE_WAR = [
    E('firstinaugural', 'Mar 1861', 'The First Inaugural — a last appeal for peace', ['POLITICS', 'TURNING POINT'],
      'Taking office with seven states already gone, he makes a final, careful plea to hold the country together: he pledges not to interfere with slavery where it exists but insists the Union is perpetual and secession void, closing with an appeal to the “better angels of our nature” — a last reach for peace before the guns.',
      svg_row('Reaching for peace on the brink', [
          {'n': 1, 'label': 'Seven states already gone', 'sub': 'takes office with the Union splitting', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'The Union is perpetual', 'sub': 'secession is void; but no war unless forced', 'color': '#1d4ed8'},
          {'n': 3, 'label': '“The better angels”', 'sub': 'a final appeal to shared bonds of affection', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He offered the South peace and the Union both — a last, eloquent attempt to avoid the war he saw coming.', accent=AC),
      bg='Lincoln was inaugurated in <b>March 1861</b> with seven Southern states already seceded and the nation on the edge of war.',
      people='The seceding states he addressed; the anxious nation North and South.',
      what='In his <b>First Inaugural Address</b>, Lincoln <b>pledged not to interfere with slavery where it existed</b>, but declared <b>secession illegal and the Union perpetual</b>, ending with a plea to the <b>“better angels of our nature”</b> to preserve the bonds of union.',
      crux='He tried to <b>hold the Union without war</b> — reassuring the South on slavery while refusing to concede secession — a last effort at peace.',
      conseq='The appeal failed; weeks later the firing on Fort Sumter began the Civil War.',
      matters='Even as war loomed, Lincoln reached for peace and union together. The First Inaugural shows the reluctant, principled statesman before the storm.'),

    E('sumter', '1861', 'Fort Sumter and total commitment', ['BATTLE', 'TURNING POINT'],
      'When Confederates fire on Fort Sumter, Lincoln makes the defining choice of his presidency: the Union is perpetual, secession is illegal, and he will fight a war to keep the country whole.',
      svg_row('The decision to fight for the Union', [
          {'n': 1, 'label': 'Sumter is fired on', 'sub': 'April 1861; the war begins', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Lincoln calls up troops', 'sub': 'declares secession unlawful; will preserve the Union', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'Border states held', 'sub': 'keeps Kentucky, Maryland, Missouri in the Union', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='He staked everything on one principle: the Union is perpetual and worth a war to save.', accent=AC),
      bg='In April <b>1861</b>, Confederate forces bombarded <b>Fort Sumter</b> in Charleston harbour, opening the Civil War.',
      people='His cabinet; the Union and Confederate governments; the wavering <b>border states</b>.',
      what='Lincoln responded by <b>calling up troops</b>, declaring secession illegal, and committing the nation to war to preserve the Union — while carefully keeping the crucial <b>border states</b> from joining the Confederacy.',
      crux='He defined the war’s purpose, at first, as <b>preserving the Union</b> — a cause that could unite Northerners who disagreed about slavery — and prioritised holding the border states.',
      conseq='The Civil War began in earnest; it would last four years and cost more American lives than any other conflict.',
      matters='Leaders are defined by the principle they will fight for. Lincoln’s was the survival of democratic self-government itself.'),

    E('generals', '1861–1863', 'The struggle to win the war', ['BATTLE', 'POLITICS'],
      'He endures years of frustration — cycling through cautious, failing generals, absorbing bloody defeats, and taking extraordinary wartime powers — as he searches for commanders who can actually win and holds a divided North together.',
      svg_stack('The grinding middle of the war', [
          {'n': 1, 'label': 'Cautious generals', 'sub': 'McClellan and others will not press the fight', 'color': '#b45309'},
          {'n': 2, 'label': 'Extraordinary powers', 'sub': 'suspends habeas corpus; expands the war effort', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'Holds the North together', 'sub': 'manages politics, morale and dissent', 'color': '#166534'},
      ], takeaway='He absorbed defeat after defeat without losing his nerve or his grip on the Union’s will to fight.', accent=AC),
      bg='The early war went badly for the Union: talented Confederate generals and cautious Union commanders produced costly stalemates and defeats.',
      people='General <b>George McClellan</b>, brilliant at organising but reluctant to fight; the future war-winner <b>Ulysses S. Grant</b>, rising in the West.',
      what='Lincoln <b>replaced general after general</b>, took controversial wartime measures (including suspending <b>habeas corpus</b>), and worked ceaselessly to sustain Northern morale and political support through years of setbacks.',
      crux='He showed extraordinary <b>resilience and political skill</b>, keeping a fractious North committed to a long, bloody war while learning military strategy on the job.',
      conseq='His persistence eventually brought forward the aggressive commanders — above all Grant and Sherman — who could win.',
      matters='Perseverance under repeated failure is a rare form of leadership. Lincoln’s refusal to quit held the Union together in its darkest years.'),
]

# ==================================================================  PHASE 4 — A NEW BIRTH OF FREEDOM
PHASE_FREEDOM = [
    E('emancipation', '1862–1863', 'The Emancipation Proclamation', ['REFORM', 'TURNING POINT', 'TRIUMPH'],
      'After the bloody check at Antietam, he issues the Emancipation Proclamation, declaring the slaves in the rebel states free. It frees few people the day it is signed — but it transforms the war from a fight for union into a fight for freedom.',
      svg_emancipation(),
      bg='By 1862 Lincoln concluded that the Union could not be saved without striking at <b>slavery</b> itself. He waited for a battlefield success — <b>Antietam</b> (Sept 1862) — before acting.',
      people='His cabinet; the enslaved people of the South; the roughly <b>200,000 Black soldiers and sailors</b> who would serve the Union.',
      what='Lincoln issued the <b>Emancipation Proclamation</b> (preliminary Sept 1862; final <b>1 January 1863</b>), declaring enslaved people in the rebel states <b>free</b> and opening Union forces to Black enlistment.',
      crux='He framed emancipation as a <b>war measure</b> within his powers, while knowing it was a <b>moral revolution</b>: it made the destruction of slavery an explicit Union war aim.',
      conseq='It discouraged European support for the Confederacy, brought ~200,000 Black troops into Union service, and set the nation on the road to abolishing slavery entirely.',
      matters='Timing and framing can make a moral leap politically possible. Lincoln made freedom and the Union’s survival the same cause.'),

    E('gettysburg', '1863', 'Gettysburg — the tide turns, and the words that endure', ['BATTLE', 'TRIUMPH'],
      'The Union wins the war’s greatest battle at Gettysburg, and months later, in just 272 words, Lincoln redefines the entire meaning of the war and of America itself — a "new birth of freedom" and "government of the people, by the people, for the people."',
      svg_row('A battle won and a nation redefined', [
          {'n': 1, 'label': 'Gettysburg, July 1863', 'sub': 'Lee’s invasion of the North is broken', 'color': '#166534'},
          {'n': 2, 'label': 'The turning tide', 'sub': 'with Vicksburg, the war swings to the Union', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'The Gettysburg Address', 'sub': '272 words redefine the war and democracy', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='He turned a cemetery dedication into the most famous statement of democratic purpose ever made.', accent=AC),
      bg='In July <b>1863</b> the Union won the pivotal <b>Battle of Gettysburg</b> (with <b>Vicksburg</b> falling the same days in the West), turning the war’s momentum decisively.',
      people='General <b>George Meade</b>, who won the battle; General <b>Robert E. Lee</b>, whose Northern invasion failed; the crowd at the cemetery dedication.',
      what='At the dedication of the Gettysburg cemetery in November 1863, Lincoln delivered the <b>Gettysburg Address</b> — a mere <b>272 words</b> recasting the war as a test of whether a nation "conceived in liberty" and dedicated to equality could endure.',
      crux='He fused a <b>military turning point</b> with a <b>rhetorical one</b>, giving the appalling sacrifice a transcendent purpose: "a new birth of freedom."',
      conseq='Gettysburg marked the strategic turn toward Union victory; the Address became the defining statement of American democratic ideals.',
      matters='Great leaders give suffering meaning. In 272 words Lincoln explained why the war — and democracy itself — mattered.'),

    E('amendment', '1864–1865', 'Winning the war and abolishing slavery forever', ['REFORM', 'TRIUMPH', 'POLITICS'],
      'He gives Grant command and backs total war to victory, wins re-election in the middle of the bloodshed, and pushes the Thirteenth Amendment through Congress — writing the end of slavery permanently into the Constitution.',
      svg_stack('Total victory and permanent freedom', [
          {'n': 1, 'label': 'Grant takes command', 'sub': 'relentless total war grinds the South down', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Re-elected, 1864', 'sub': 'the North endorses finishing the war', 'color': '#166534'},
          {'n': 3, 'label': '13th Amendment, 1865', 'sub': 'slavery abolished in the Constitution itself', 'color': '#b45309'},
      ], takeaway='He made abolition permanent — not a wartime order, but the supreme law of the land.', accent=AC),
      bg='In 1864 Lincoln elevated <b>Ulysses S. Grant</b> to overall command; Grant and <b>Sherman</b> waged relentless <b>total war</b>. Lincoln also faced a hard re-election.',
      people='General <b>Grant</b> and General <b>Sherman</b>; his 1864 opponent, the ex-general <b>McClellan</b>; the congressmen he pressed to pass the amendment.',
      what='Lincoln backed Grant’s crushing strategy, <b>won re-election in 1864</b> despite the war’s cost, and drove the <b>Thirteenth Amendment</b> — abolishing slavery throughout the United States — through Congress in early <b>1865</b>.',
      crux='He recognised the Emancipation Proclamation might not survive the war legally, so he made abolition <b>permanent and constitutional</b>, beyond the reach of any court or future president.',
      conseq='The Union closed in on total victory, and slavery was abolished forever in American law.',
      matters='Securing a victory means making it permanent. Lincoln turned a wartime measure into the enduring, constitutional end of slavery.'),

    E('blacksoldiers', '1863–1865', 'Men of color under arms', ['REFORM', 'BATTLE', 'TRIUMPH'],
      'Emancipation opens the ranks, and some two hundred thousand Black soldiers and sailors — many of them formerly enslaved — take up arms for the Union, proving their valor at places like Fort Wagner, transforming the war’s manpower and its meaning, and, as Lincoln himself argued, earning a claim to the freedom and nation they fought for.',
      svg_row('Freedom fighting for itself', [
          {'n': 1, 'label': '~200,000 Black troops', 'sub': 'the USCT; many formerly enslaved men', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Valor under fire', 'sub': 'Fort Wagner and countless other fields', 'color': '#166534'},
          {'n': 3, 'label': 'A claim to the nation', 'sub': 'their service strengthens the case for full freedom', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='Black soldiers turned emancipation into a fighting force — and earned, in Lincoln’s own words, a claim to the republic.', accent=AC),
      bg='The Emancipation Proclamation opened Union service to Black men, and the <b>United States Colored Troops (USCT)</b> became a major part of the war effort.',
      people='The roughly <b>200,000 Black soldiers and sailors</b>; the abolitionist <b>Frederick Douglass</b>, who recruited them and pressed Lincoln on equal treatment.',
      what='Some <b>200,000 Black men</b> served the Union in the <b>USCT</b>, fighting with distinction at battles like <b>Fort Wagner</b>. Their service reshaped the war’s manpower and meaning; Lincoln argued it gave them a rightful claim to freedom and the nation.',
      crux='He came to see Black military service as both a <b>decisive military asset and a moral argument</b> — men fighting for the Union had earned its full promise.',
      conseq='Black soldiers helped win the war and strengthened the case for citizenship and rights after it.',
      matters='Freedom fought for itself. The service of Black soldiers is central to the war’s meaning — and to Lincoln’s evolving vision of the nation.'),

    E('homefront', '1861–1865', 'Building the future amid the war', ['REFORM', 'TRIUMPH'],
      'Even as he fights to save the Union, he signs a wave of laws that reshape America’s future: the Homestead Act opening the West to settlers, land-grant colleges, a transcontinental railroad, a national banking system and currency, and the first national Thanksgiving — laying the foundations of the modern United States while the guns still fire.',
      svg_stack('A nation remade while at war', [
          {'n': 1, 'label': 'Homestead Act & the West', 'sub': 'free land opens the frontier to settlers', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Railroads & colleges', 'sub': 'the transcontinental railroad; land-grant universities', 'color': '#0e7490'},
          {'n': 3, 'label': 'Banks, money, Thanksgiving', 'sub': 'a national currency; the first national Thanksgiving', 'color': '#166534'},
      ], takeaway='While winning the war he also legislated the modern America — land, railroads, colleges, and a national economy.', accent=AC),
      bg='With Southern members gone from Congress, Lincoln’s Republicans passed a sweeping program of <b>national development</b> even as the war raged.',
      people='The settlers of the West; the builders of the transcontinental railroad; the students of the new land-grant colleges.',
      what='Lincoln signed the <b>Homestead Act (1862)</b>, the <b>Morrill Land-Grant College Act</b>, the acts building the <b>transcontinental railroad</b>, a <b>national banking system and currency</b>, and proclaimed the first national <b>Thanksgiving</b> — foundations of the modern American economy and state.',
      crux='He used the war’s political opening to <b>build the nation’s future</b>, not just preserve its present — nation-building alongside war-fighting.',
      conseq='These laws shaped the settlement, education, economy and infrastructure of the United States for generations.',
      matters='Lincoln did not merely save the Union; he helped lay the groundwork of the modern nation, even in its darkest hour.'),

    E('copperheads', '1863–1864', 'The dark summer — dissent, and the near-loss of 1864', ['POLITICS', 'DEFEAT', 'TURNING POINT'],
      'The war’s staggering cost breeds fierce opposition: anti-war "Copperhead" Democrats demand a negotiated peace, draft riots convulse New York, and by mid-1864, with the armies stalled and casualties appalling, Lincoln himself privately expects to lose re-election — until Sherman takes Atlanta and turns the tide of opinion just in time.',
      svg_row('When the war — and Lincoln — nearly lost the North', [
          {'n': 1, 'label': 'Copperhead opposition', 'sub': 'anti-war Democrats demand a negotiated peace', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Draft riots and war-weariness', 'sub': 'appalling casualties sap Northern will', 'color': '#b45309'},
          {'n': 3, 'label': 'Atlanta saves 1864', 'sub': 'Sherman takes Atlanta; opinion turns; Lincoln re-elected', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He came within sight of electoral defeat — and the fall of Atlanta rescued both his presidency and the war effort.', accent=AC),
      bg='By mid-1864 the war’s enormous cost had produced deep war-weariness and a powerful anti-war movement in the North.',
      people='The <b>Copperhead</b> anti-war Democrats; his opponent <b>McClellan</b>; General <b>Sherman</b>, whose capture of Atlanta transformed the mood.',
      what='Anti-war <b>Copperheads</b> demanded a negotiated peace, <b>draft riots</b> shook cities, and by the summer of <b>1864</b> Lincoln privately <b>expected to lose re-election</b> — until <b>Sherman captured Atlanta</b>, reviving Northern confidence and securing Lincoln’s victory.',
      crux='He held firm through the war’s <b>political nadir</b>, refusing a compromise peace that would have left slavery and disunion intact — and was saved by a battlefield turn.',
      conseq='Lincoln’s re-election ensured the war would be fought to full victory and slavery abolished; a negotiated peace was averted.',
      matters='The war’s outcome hung on Northern will and one election. Lincoln’s steadiness through 1864’s despair was as decisive as any battle.'),
]

# ==================================================================  PHASE 5 — VICTORY AND MARTYRDOM
PHASE_END = [
    E('willie', '1862', 'Private grief in the White House', ['TRAGEDY'],
      'Amid the carnage of war he suffers a devastating personal blow: his beloved eleven-year-old son Willie dies of typhoid in the White House, plunging Lincoln into deep grief and his wife Mary into an anguish from which she never fully recovers — a reminder that the man carrying a nation’s sorrow bore his own as well.',
      svg_row('The nation’s sorrow, and his own', [
          {'n': 1, 'label': 'Willie dies, 1862', 'sub': 'his cherished young son, of typhoid fever', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Lincoln’s deep grief', 'sub': 'the loss shadows him through the war', 'color': '#475569'},
          {'n': 3, 'label': 'Mary’s lasting anguish', 'sub': 'his wife never fully recovers', 'color': '#b45309'},
      ], edge_labels=['then', 'and'], takeaway='The man bearing a nation’s grief was also a father who buried a beloved son mid-war.', accent=AC),
      bg='In February <b>1862</b>, as the war raged, Lincoln’s third son <b>Willie</b> died in the White House of typhoid fever.',
      people='His son <b>Willie</b>; his wife <b>Mary Todd Lincoln</b>, devastated by the loss; the Lincoln family.',
      what='The death of eleven-year-old <b>Willie Lincoln</b> plunged the President into <b>profound grief</b> and his wife Mary into an <b>anguish and instability</b> from which she never fully recovered, even as Lincoln carried the burdens of the war.',
      crux='It revealed the <b>private human cost</b> beneath the public burden: the leader consoling a grieving nation was himself a grieving father.',
      conseq='Personal sorrow deepened the melancholy and the profound seriousness with which Lincoln bore the war.',
      matters='Great leaders carry private griefs alongside public ones. Willie’s death is a reminder of the human being beneath the historic figure.'),

    E('character', '1809–1865', 'The melancholy humorist — the man himself', ['POLITICS'],
      'The inner Lincoln is a study in contrasts: a famously funny storyteller who used humor to disarm and to cope, and a man of deep, lifelong melancholy; a self-taught intellect steeped in Shakespeare and the Bible; and a leader whose sense of humility, fatalism and moral seriousness deepened into something close to prophecy by the end.',
      svg_stack('The paradoxical inner man', [
          {'n': 1, 'label': 'Humorist and storyteller', 'sub': 'uses jokes and tales to disarm and to cope', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Lifelong melancholy', 'sub': 'a deep, sometimes crushing sadness', 'color': '#475569'},
          {'n': 3, 'label': 'Moral and providential depth', 'sub': 'Shakespeare, the Bible, a deepening fatalism', 'color': '#166534'},
      ], takeaway='Funny and sorrowful, humble and profound — the inner Lincoln was as remarkable as the public one.', accent=AC),
      bg='Those who knew Lincoln described a man of striking psychological complexity — humorous yet melancholy, humble yet profound.',
      people='His law partner <b>Herndon</b> and secretaries, who recorded his character; the writers (Shakespeare, the Bible) who shaped his mind and prose.',
      what='Lincoln was a celebrated <b>humorist and storyteller</b> who used wit to disarm opponents and cope with strain, while carrying a deep <b>lifelong melancholy</b>; a <b>self-taught intellect</b> steeped in Shakespeare and the Bible; and a leader of growing <b>humility, fatalism and moral seriousness</b>.',
      crux='His <b>inner complexity</b> — humor over sorrow, humility with greatness, a deepening sense of providence — underlay the wisdom and language of his leadership.',
      conseq='This character gave his speeches their depth and his leadership its rare blend of resolve, mercy and moral vision.',
      matters='The measure of Lincoln is as much inner as outer. His melancholy, humor and moral depth are inseparable from his greatness.'),
    E('secondinaugural', '1865', '“With malice toward none”', ['POLITICS', 'TURNING POINT'],
      'With victory in sight, his Second Inaugural Address rejects vengeance and calls for a generous peace — "with malice toward none, with charity for all" — a vision of binding up the nation’s wounds and reuniting North and South.',
      svg_row('The peace he meant to make', [
          {'n': 1, 'label': 'Victory in sight', 'sub': 'the Confederacy is collapsing by early 1865', 'color': '#166534'},
          {'n': 2, 'label': '“Malice toward none”', 'sub': 'the Second Inaugural rejects vengeance', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'A healing reunion', 'sub': 'he plans a magnanimous reconstruction', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='At the moment of triumph he chose mercy over revenge — a peace meant to heal, not punish.', accent=AC),
      bg='By March <b>1865</b> Union victory was near. Lincoln turned to the problem of <b>reconciliation</b> — how to bring the defeated South back into the nation.',
      people='The defeated South; the "Radical Republicans" who wanted a harsher peace; the reunited nation he envisioned.',
      what='In his <b>Second Inaugural Address</b> (March 1865), Lincoln called for a merciful peace — <b>"with malice toward none, with charity for all"</b> — and to "bind up the nation’s wounds," rather than punish the South.',
      crux='He understood that <b>winning the war and winning the peace were different tasks</b>, and that a vengeful settlement would poison the reunited nation.',
      conseq='His vision of a generous reconstruction was cut short by his assassination weeks later, and a harsher, more chaotic Reconstruction followed.',
      matters='Magnanimity in victory is the hardest and highest statesmanship. Lincoln’s call for mercy is among the noblest words in American history.'),

    E('assassination', '1865', 'Appomattox and Ford’s Theatre', ['DEATH', 'TRIUMPH', 'TRAGEDY'],
      'Days after Lee surrenders at Appomattox and the war is effectively won, Lincoln is shot by John Wilkes Booth at Ford’s Theatre and dies the next morning — struck down at the very hour of his triumph, and passing instantly into legend.',
      svg_martyr(),
      bg='On <b>9 April 1865</b>, <b>Robert E. Lee surrendered to Grant at Appomattox</b>, effectively ending the Civil War. The nation began to celebrate.',
      people='General <b>Lee</b>, who surrendered; the assassin <b>John Wilkes Booth</b>, a Confederate sympathiser; Lincoln’s grieving nation.',
      what='Just five days after Appomattox, on <b>14 April 1865</b>, Lincoln was shot by <b>John Wilkes Booth</b> at <b>Ford’s Theatre</b> in Washington and died the next morning — the first U.S. president to be assassinated.',
      crux='He died at the <b>precise moment of victory</b>, having saved the Union and ended slavery — a martyrdom that fixed his memory as America’s secular saint.',
      conseq='His death robbed the nation of his moderating vision for Reconstruction and transformed him into an enduring symbol of union, freedom and sacrifice.',
      matters='Some deaths reshape a nation’s soul. Lincoln’s martyrdom sealed the Union’s cause and made him the central figure of the American story.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Abraham Lincoln rose from a one-room log cabin and a single year of schooling to the presidency — and then held the United States together through its bloodiest war, ended slavery, and redefined the meaning of American democracy before being murdered at the hour of victory. He is a study in <b>the self-made mind, moral clarity married to political skill, perseverance through catastrophe, and the power of words to give suffering meaning.</b></p>
<div class="ov-quote">“Government of the people, by the people, for the people, shall not perish from the earth.”<span>— the Gettysburg Address, 1863</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A dirt-poor frontier boy teaches himself law and enters politics → the slavery crisis gives him his cause → the Lincoln–Douglas debates make him famous → he wins the presidency and the South secedes → he fights a four-year war to save the Union, cycling through failing generals → issues the Emancipation Proclamation and redefines the war at Gettysburg → wins total victory under Grant and abolishes slavery by the Thirteenth Amendment → calls for a merciful peace → and is assassinated days after the war is won.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🪵</div><h4>The self-made mind</h4><p>From a floorless cabin to the White House, educated almost entirely by himself.</p></div>
  <div class="ov-card"><div class="i">⛓️</div><h4>He ended slavery</h4><p>The Emancipation Proclamation and the Thirteenth Amendment.</p></div>
  <div class="ov-card"><div class="i">🇺🇸</div><h4>He saved democracy</h4><p>Proved that government "of the people" could survive its gravest test.</p></div>
  <div class="ov-card"><div class="i">🕊️</div><h4>Malice toward none</h4><p>Chose mercy over vengeance at the moment of victory.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Log Cabin to Lawyer</b><small> 1809–54</small><p>Self-made rise from poverty to the bar and politics.</p></div>
  <div><b>2 · The Slavery Crisis</b><small> 1858–61</small><p>The debates, the election, and secession.</p></div>
  <div><b>3 · The War President</b><small> 1861–63</small><p>Fort Sumter and the struggle to win.</p></div>
  <div><b>4 · A New Birth of Freedom</b><small> 1862–65</small><p>Emancipation, Gettysburg, the 13th Amendment.</p></div>
  <div><b>5 · Victory and Martyrdom</b><small> 1865</small><p>A merciful peace, Appomattox, and assassination.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Stephen A. Douglas', 'role': 'great rival', 'color': '#7f1d1d',
     'bio': 'The powerful Illinois senator and Democrat whose Kansas-Nebraska Act reignited Lincoln’s career and who faced him in the famous 1858 debates and the 1860 election.',
     'rel': 'The rival whose challenge made Lincoln a national figure.'},
    {'name': 'Ulysses S. Grant', 'role': 'winning general', 'color': '#1d4ed8',
     'bio': 'The relentless Union general Lincoln finally elevated to overall command in 1864; his total-war strategy ground down the Confederacy and won the war.',
     'rel': 'The commander who at last delivered the victory Lincoln needed.'},
    {'name': 'Robert E. Lee', 'role': 'Confederate general', 'color': '#b45309',
     'bio': 'The Confederacy’s greatest general, whose invasion of the North failed at Gettysburg and who surrendered to Grant at Appomattox in April 1865.',
     'rel': 'The brilliant adversary whose surrender ended the war.'},
    {'name': 'Mary Todd Lincoln', 'role': 'wife', 'color': '#6d28d9',
     'bio': 'Lincoln’s wife, from a prominent Kentucky family, who endured the deaths of their sons and the strains of the White House during the war.',
     'rel': 'His wife through poverty, power and tragedy.'},
    {'name': 'Frederick Douglass', 'role': 'abolitionist', 'color': '#166534',
     'bio': 'The formerly enslaved orator and abolitionist who pressed Lincoln toward emancipation and Black enlistment, and came to see him as a genuine friend of freedom.',
     'rel': 'The abolitionist conscience who pushed and praised him.'},
    {'name': 'John Wilkes Booth', 'role': 'assassin', 'color': '#111827',
     'bio': 'A famous actor and Confederate sympathiser who assassinated Lincoln at Ford’s Theatre on 14 April 1865, days after the war was effectively won.',
     'rel': 'The assassin who made Lincoln a martyr.'},
]

KEY_EVENTS = [
    ('1809', 'Born in a Kentucky log cabin', 'Deep frontier poverty; almost no schooling.'),
    ('1836', 'Admitted to the bar', 'A self-taught prairie lawyer.'),
    ('1854', 'Kansas-Nebraska Act', 'Slavery pulls him back into politics.'),
    ('1858', 'Lincoln–Douglas debates', 'Loses the Senate race, wins national fame.'),
    ('1860', 'Elected president', 'A four-way race; the South begins to secede.'),
    ('1861', 'Fort Sumter', 'The Civil War begins; he fights for the Union.'),
    ('1863', 'Emancipation Proclamation', 'The war becomes a fight for freedom.'),
    ('1863', 'Gettysburg and the Address', 'The tide turns; democracy redefined.'),
    ('1864', 'Grant takes command; re-elected', 'Total war and a second term.'),
    ('1865', 'Thirteenth Amendment', 'Slavery abolished in the Constitution.'),
    ('Apr 1865', 'Appomattox', 'Lee surrenders; the war is won.'),
    ('Apr 1865', 'Assassinated at Ford’s Theatre', 'Shot by Booth; dies the next morning.'),
]

MASTER = [
    {'year': '1809', 'age': 'born', 'phase': 'The Rise', 'title': 'Born in a log cabin', 'desc': 'Frontier poverty.'},
    {'year': '1836', 'age': 'age 27', 'phase': 'The Rise', 'title': 'Becomes a lawyer', 'desc': 'Self-taught; enters politics.'},
    {'year': '1858', 'age': 'age 49', 'phase': 'The Crisis', 'title': 'Lincoln–Douglas debates', 'desc': 'National fame.'},
    {'year': '1860', 'age': 'age 51', 'phase': 'The Crisis', 'title': 'Elected president', 'desc': 'The South secedes.'},
    {'year': '1861', 'age': 'age 52', 'phase': 'The War', 'title': 'Fort Sumter', 'desc': 'The Civil War begins.'},
    {'year': '1863', 'age': 'age 54', 'phase': 'Freedom', 'title': 'Emancipation; Gettysburg', 'desc': 'The war for freedom.'},
    {'year': '1865', 'age': 'age 56', 'phase': 'Freedom', 'title': '13th Amendment', 'desc': 'Slavery abolished.'},
    {'year': '1865', 'age': 'age 56', 'phase': 'The End', 'title': 'Appomattox; assassination', 'desc': 'Victory, then martyrdom.'},
]

SOURCES = [
    ('Britannica — Abraham Lincoln', 'https://www.britannica.com/biography/Abraham-Lincoln'),
    ('U.S. National Park Service — Lincoln', 'https://www.nps.gov/liho/learn/historyculture/index.htm'),
    ('Britannica — Emancipation Proclamation', 'https://www.britannica.com/event/Emancipation-Proclamation'),
    ('Wikipedia — Abraham Lincoln', 'https://en.wikipedia.org/wiki/Abraham_Lincoln'),
]

def build_meta():
    return {
        'pid': 'gm-lincoln.html', 'kind': 'man', 'emoji': '🎩', 'accent': AC,
        'name': 'Abraham Lincoln', 'years': '1809–1865', 'group': 'Statesmen & Politicians',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'From a log cabin and a year of schooling to the presidency — he held the Union together through its bloodiest war, ended slavery, and redefined democracy before dying at the hour of victory.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · Log Cabin to Lawyer', 'type': 'timeline',
             'intro': 'Born into frontier poverty with almost no schooling, he teaches himself law and rises in Illinois politics — until the slavery crisis gives him the cause of his life.', 'events': PHASE_RISE},
            {'id': 'crisis', 'label': '2 · The Slavery Crisis', 'type': 'timeline',
             'intro': 'The debates with Douglas make him famous, his words crystallise the crisis, and his election to the presidency triggers the secession of the South.', 'events': PHASE_CRISIS},
            {'id': 'war', 'label': '3 · The War President', 'type': 'timeline',
             'intro': 'When Sumter is fired on he commits the nation to a war for the Union — and endures years of frustration and defeat as he searches for generals who can win.', 'events': PHASE_WAR},
            {'id': 'freedom', 'label': '4 · A New Birth of Freedom', 'type': 'timeline',
             'intro': 'He transforms the war with the Emancipation Proclamation, redefines the nation at Gettysburg, and makes the end of slavery permanent in the Constitution.', 'events': PHASE_FREEDOM},
            {'id': 'end', 'label': '5 · Victory and Martyrdom', 'type': 'timeline',
             'intro': 'With victory in sight he calls for a merciful peace — then, days after Appomattox, is assassinated at Ford’s Theatre and passes into legend.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Lincoln’s life is exceptionally well documented; this guide follows the mainstream historical consensus.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
