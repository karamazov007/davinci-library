# -*- coding: utf-8 -*-
"""Full, DEEP birth-to-death guide content for Alexander the Great.
Covers every major battle, siege and pivotal decision of the campaign."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#a16207'  # Macedonian gold

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_fleet():
    """The decision after Miletus to disband the navy and beat the Persian fleet from the land."""
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">334 BC · after Miletus · the Persian navy is far stronger — so he gets rid of his own</text>'
    b += '<rect x="40" y="60" width="300" height="70" rx="12" fill="#fdecec" stroke="#dc2626" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#dc2626">THE PROBLEM</text>'
    s1,_=_tspans(54,100,'Persia rules the sea (~400 ships); his ~160 can’t win a battle & are costly',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="70" rx="12" fill="#fef9c3" stroke="#a16207" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#a16207">THE GAMBLE</text>'
    s2,_=_tspans(394,100,'disband the fleet; take every PORT by land → the enemy ships have nowhere to refit',10,'#6b5310',600,12,44); b+=s2
    b += '<line x1="340" y1="95" x2="378" y2="95" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="164" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">No bases → no water, no crews, no repairs. Within two years the Persian navy simply dissolves.</text>'
    return _wrap(W, H, 'Beating a navy without ships — the coastal strategy', _tk(b, W, H, 'If you can’t beat a strength head-on, attack what it depends on — deny the enemy fleet its ports and it dies.'), '', AC)

def svg_tyre():
    """The 7-month siege: build a causeway to join the island to the mainland."""
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">332 BC · Tyre · an island fortress that says no — so he makes it not an island</text>'
    # mainland
    b += '<rect x="30" y="70" width="150" height="120" rx="10" fill="#e7e5e4" stroke="#a16207" stroke-width="1.6"/>'
    b += '<text x="105" y="120" font-size="10.5" font-weight="800" fill="#78350f" text-anchor="middle">MAINLAND</text>'
    b += '<text x="105" y="136" font-size="9" fill="#6b7280" text-anchor="middle">(old Tyre, quarried for stone)</text>'
    # sea
    b += '<rect x="180" y="70" width="360" height="120" fill="#e0f2fe"/>'
    # the mole
    b += '<rect x="180" y="120" width="360" height="22" fill="#a16207"/>'
    b += '<text x="360" y="135" font-size="9.5" font-weight="800" fill="#fff" text-anchor="middle">the MOLE (causeway) — built ~1 km out to the island</text>'
    # island
    b += '<rect x="540" y="70" width="150" height="120" rx="10" fill="#fee2e2" stroke="#dc2626" stroke-width="1.8"/>'
    b += '<text x="615" y="118" font-size="10.5" font-weight="800" fill="#b91c1c" text-anchor="middle">TYRE (island)</text>'
    b += '<text x="615" y="134" font-size="9" fill="#6b7280" text-anchor="middle">high walls; a strong navy</text>'
    b += '<line x1="200" y1="108" x2="520" y2="108" stroke="#a16207" stroke-width="1.4" stroke-dasharray="5 4" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10" fill="#334155" font-weight="700" text-anchor="middle">7 months; fireships and sorties; he borrows allied ships to blockade — then storms it.</text>'
    return _wrap(W, H, 'The Siege of Tyre — turning an island into a peninsula', _tk(b, W, H, 'When the obstacle is the terrain itself, change the terrain — he refused to leave a hostile port at his back.'), '', AC)

def svg_gates():
    """The Persian Gates — frontal pin + mountain flanking march."""
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">330 BC · the Persian Gates · a narrow pass blocks the road to Persepolis</text>'
    boxes=[(40,'#dc2626','Ariobarzanes blocks the pass','a walled defile; first Macedonian assault is bloodily repulsed'),
           (270,'#a16207','A prisoner reveals a path','Alexander leads a night march over the mountains'),
           (500,'#16a34a','Hit them front and rear','trapped defenders destroyed; road to Persepolis open')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="100" x2="268" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="100" x2="498" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10" fill="#334155" font-weight="700" text-anchor="middle">A “Thermopylae in reverse” — the same outflanking trick that once doomed the Greeks.</text>'
    return _wrap(W, H, 'The Persian Gates — pin the front, climb the mountain', _tk(b, W, H, 'A wall across a valley is only as strong as the ridge above it — find the goat-path and the wall falls.'), '', AC)

def svg_hydaspes():
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">326 BC · the Hydaspes · a flooded river and a wall of war elephants</text>'
    # river
    b += '<rect x="40" y="150" width="640" height="24" fill="#bae6fd"/>'
    b += '<text x="360" y="167" font-size="9.5" fill="#0369a1" font-weight="700" text-anchor="middle">the monsoon-swollen Hydaspes river</text>'
    # Porus far bank
    b += '<rect x="250" y="60" width="230" height="34" rx="8" fill="#fee2e2" stroke="#dc2626" stroke-width="1.6"/>'
    b += '<text x="365" y="82" font-size="10.5" font-weight="800" fill="#b91c1c" text-anchor="middle">PORUS — elephants line the far bank</text>'
    # feints + real crossing
    b += '<rect x="40" y="188" width="180" height="44" rx="10" fill="#fff" stroke="#a16207" stroke-width="1.6"/>'
    b += '<text x="52" y="206" font-size="9.5" font-weight="800" fill="#a16207">1 · nightly feints</text>'
    b += '<text x="52" y="220" font-size="8.6" fill="#5b6472">tire &amp; confuse Porus for weeks</text>'
    b += '<rect x="500" y="188" width="180" height="44" rx="10" fill="#fef9c3" stroke="#a16207" stroke-width="1.9"/>'
    b += '<text x="512" y="206" font-size="9.5" font-weight="800" fill="#a16207">2 · cross upstream, in a storm</text>'
    b += '<text x="512" y="220" font-size="8.6" fill="#5b6472">17 miles up; surprise at dawn</text>'
    b += '<path d="M600,186 C610,150 560,120 480,96" fill="none" stroke="#a16207" stroke-width="2.2" marker-end="url(#ah)"/>'
    b += '<text x="360" y="126" font-size="9.6" fill="#334155" font-weight="700" text-anchor="middle">3 · handle the elephants: open lanes, hamstring them, shower them with arrows until they trample their own side</text>'
    return _wrap(W, H, 'The Hydaspes — beating elephants by not fighting them head-on', _tk(b, W, H, 'Deceive to cross, then refuse the enemy’s strong game — make his elephants a liability, not a wall.'), '', AC)

def svg_fracture():
    W, H = 720, 262
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">JUNE 323 BC · he dies at 32 with no adult heir and no plan — “to the strongest”</text>'
    b += '<rect x="270" y="56" width="180" height="46" rx="12" fill="#fef9c3" stroke="#a16207" stroke-width="1.9"/>'
    b += '<text x="360" y="76" font-size="11.5" font-weight="800" fill="#a16207" text-anchor="middle">One empire, one man</text>'
    b += '<text x="360" y="92" font-size="9.5" fill="#6b7280" text-anchor="middle">Greece → Egypt → India, held by his person alone</text>'
    kingdoms = [(40,'Antigonids','Macedon & Greece'),(210,'Ptolemies','Egypt'),(380,'Seleucids','Persia & the East'),(560,'others','Pergamon, etc.')]
    for x,name,area in kingdoms:
        b += f'<rect x="{x}" y="150" width="140" height="52" rx="10" fill="#fff" stroke="#7c3aed" stroke-width="1.6"/>'
        b += f'<text x="{x+12}" y="170" font-size="10.5" font-weight="800" fill="#7c3aed">{esc(name)}</text>'
        ss,_=_tspans(x+12,186,area,9.5,'#5b6472',500,11,22); b+=ss
        b += f'<line x1="360" y1="102" x2="{x+70}" y2="148" stroke="#dc2626" stroke-width="1.5" marker-end="url(#ah)"/>'
    b += '<text x="360" y="128" font-size="10" fill="#dc2626" font-weight="800" text-anchor="middle">40 years of wars between his generals (the Diadochi)</text>'
    return _wrap(W, H, 'What his death unleashed — the empire fractures, the culture spreads', _tk(b, W, H, 'The empire died with him; the Greek-speaking world it created (the Hellenistic age) lasted 300 years.'), '', AC)

def svg_gaugamela():
    W, H = 720, 300
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1 OCT 331 BC · outnumbered maybe 5-to-1 on open ground chosen by Darius</text>'
    b += '<rect x="40" y="58" width="640" height="30" rx="8" fill="#fdecec" stroke="#dc2626" stroke-width="1.6"/>'
    b += '<text x="360" y="78" font-size="11" font-weight="800" fill="#dc2626" text-anchor="middle">PERSIAN LINE — Darius III, huge; scythed chariots &amp; elephants (Darius at centre)</text>'
    b += '<rect x="60" y="150" width="180" height="54" rx="10" fill="#fff" stroke="#a16207" stroke-width="1.7"/>'
    b += '<text x="72" y="170" font-size="10.5" font-weight="800" fill="#a16207">1 · march RIGHT, oblique</text>'
    s1,_=_tspans(72,186,'drags the Persian left out to match him',9.5,'#5b6472',500,11,32); b+=s1
    b += '<rect x="270" y="150" width="180" height="54" rx="10" fill="#fff" stroke="#b45309" stroke-width="1.7"/>'
    b += '<text x="282" y="170" font-size="10.5" font-weight="800" fill="#b45309">2 · a GAP opens</text>'
    s2,_=_tspans(282,186,'Persian centre-left splits as they chase',9.5,'#5b6472',500,11,32); b+=s2
    b += '<rect x="480" y="150" width="200" height="54" rx="10" fill="#fef9c3" stroke="#a16207" stroke-width="1.9"/>'
    b += '<text x="492" y="170" font-size="10.5" font-weight="800" fill="#a16207">3 · WEDGE at Darius</text>'
    s3,_=_tspans(492,186,'Companion cavalry charge straight at the king',9.5,'#5b6472',500,11,34); b+=s3
    b += '<line x1="240" y1="177" x2="268" y2="177" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="177" x2="478" y2="177" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="580" y1="150" x2="470" y2="90" stroke="#a16207" stroke-width="2.4" marker-end="url(#ah)"/>'
    b += '<text x="360" y="238" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">4 · Darius panics and flees → the whole huge army collapses with its king.</text>'
    return _wrap(W, H, 'Gaugamela — beat the army by breaking the man', _tk(b, W, H, 'Don’t fight the whole army — make one gap and aim at the one man whose flight ends it.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — ORIGINS
PHASE_ORIGINS = [
    E('prince', '356–340 BC', 'The making of a prince', ['RISE'],
      'Son of a conquering king and a fierce, mystical mother, tutored by Aristotle and raised on Homer to believe he descended from Achilles and Heracles — engineered from birth to conquer.',
      svg_stack('The three forces that formed him', [
          {'n': 1, 'label': 'Philip II — the model & the machine', 'sub': 'a conquering father who built a professional army', 'color': '#a16207'},
          {'n': 2, 'label': 'Olympias — myth & ambition', 'sub': 'a mother who told him he was born of gods', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Aristotle — the mind', 'sub': 'tutored in Homer, philosophy, science, glory', 'color': '#0891b2'},
      ], takeaway='He was raised at the intersection of a war machine, a myth of divine destiny, and the finest mind of the age.', accent=AC),
      bg='Macedon under <b>Philip II</b> had risen from a backward kingdom to the master of Greece. Alexander was born in <b>356 BC</b> at Pella.',
      people='<b>Philip II</b>, his father; <b>Olympias</b>, his intense mother who claimed descent from Achilles; <b>Aristotle</b>, his tutor; <b>Bucephalus</b>, the great horse he tamed as a boy by turning it from its own shadow.',
      what='Tutored by <b>Aristotle</b> at Mieza, he was steeped in Homer’s <b>Iliad</b> (he kept a copy under his pillow) and modelled himself on <b>Achilles</b> and his claimed ancestor <b>Heracles</b>.',
      crux='Nature and nurture aligned: a ready-made army and throne, a myth of divine destiny, and a world-class education in ambition. Few humans have been so completely engineered for greatness.',
      conseq='He grew up supremely confident, classically educated, and convinced he was fated for something superhuman — with the tools to attempt it.',
      matters='Extraordinary outcomes often need extraordinary inputs stacked together: opportunity, belief, and preparation. Alexander had all three from birth.'),

    E('bucephalus', 'c. 344 BC', 'Taming Bucephalus — the boy who saw what men missed', ['RISE', 'TURNING POINT'],
      'A magnificent, unridable horse is about to be sent away when the twelve-year-old prince notices what grown men have missed — the animal is terrified of its own shadow — turns it toward the sun, and rides it, prompting his father to weep that Macedon will be too small for him. It is the founding legend of his life: seeing what others cannot, and daring where they will not.',
      svg_row('The insight that announced a genius', [
          {'n': 1, 'label': 'An "unridable" horse', 'sub': 'grown men fail to tame Bucephalus', 'color': '#a16207'},
          {'n': 2, 'label': 'The boy sees the cause', 'sub': 'it fears its own shadow — turn it to the sun', 'color': '#166534'},
          {'n': 3, 'label': 'He rides it', 'sub': 'Philip: "Macedon is too small for you"', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='At twelve he saw what seasoned men missed and dared what they wouldn’t — the pattern of his whole life.', accent=AC),
      bg='A superb horse, <b>Bucephalus</b>, was offered to Philip’s court but seemed impossible to ride; the young Alexander observed it closely.',
      people='<b>Bucephalus</b>, who would carry Alexander across Asia; his father <b>Philip</b>, moved by the feat.',
      what='The twelve-year-old Alexander noticed <b>Bucephalus was frightened of its own shadow</b>, turned it to face the sun, calmed and mounted it — a feat that reportedly moved <b>Philip to tears</b> and to declare that Macedon would be too small for his son.',
      crux='It revealed his defining gift: <b>observing what others overlooked and acting with fearless decisiveness</b> where grown men hesitated.',
      conseq='Bucephalus became his lifelong warhorse, carried across Asia and mourned like a companion at its death in India.',
      matters='The Bucephalus story is the founding parable of Alexander: perception plus daring, the twin traits that would conquer a world.'),

    E('aristotle', '343–340 BC', 'Aristotle’s pupil — a mind armed for the world', ['RISE', 'REFORM'],
      'For three formative years he is tutored by the greatest mind of the age, Aristotle, who fills him with a love of Homer, medicine, science, philosophy and the Greek ideal — an education that gives his boundless ambition a cultural mission, and a curiosity about the wider world that never leaves him even amid conquest.',
      svg_row('The greatest teacher for the greatest pupil', [
          {'n': 1, 'label': 'Tutored by Aristotle', 'sub': 'three years of study at Mieza', 'color': '#a16207'},
          {'n': 2, 'label': 'Homer, science, philosophy', 'sub': 'the Iliad, medicine, botany, statecraft', 'color': '#166534'},
          {'n': 3, 'label': 'A cultural mission', 'sub': 'ambition fused with the Greek ideal and curiosity', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='The age’s greatest philosopher armed the age’s greatest conqueror with curiosity, learning, and a mission.', accent=AC),
      bg='Philip engaged the philosopher <b>Aristotle</b> to tutor the teenage Alexander at <b>Mieza</b>.',
      people='<b>Aristotle</b>, the philosopher; the companions educated alongside Alexander, his future generals.',
      what='For about three years <b>Aristotle</b> tutored Alexander in <b>Homer, philosophy, medicine, biology and statecraft</b>, instilling a love of the <b>Iliad</b>, a scientific curiosity, and a devotion to the Greek cultural ideal.',
      crux='He gained not just knowledge but a <b>sense of cultural mission and lifelong curiosity</b> — conquest as the spread of Greek civilisation, and a hunger to understand the lands he took.',
      conseq='On campaign he brought scientists and surveyors, sent specimens back to Aristotle, and founded Greek cities — conquest as cultural project.',
      matters='Education shapes how ambition is used. Aristotle gave Alexander’s drive a cultural purpose and a curiosity that outlasted every battle.'),

    E('philipmurder', '336 BC', 'The murder of Philip — a throne soaked in suspicion', ['POLITICS', 'DEATH', 'TURNING POINT'],
      'At the height of his power, his father Philip is suddenly assassinated by a bodyguard — and though Alexander inherits the throne and the army instantly, dark suspicions swirl that he and his mother Olympias were involved, a shadow of ruthless ambition over the very start of his reign.',
      svg_row('A sudden death that hands him everything', [
          {'n': 1, 'label': 'Philip assassinated', 'sub': 'struck down by a bodyguard at a wedding, 336 BC', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Alexander takes power', 'sub': 'inherits the throne and army at 20', 'color': '#a16207'},
          {'n': 3, 'label': 'Suspicion lingers', 'sub': 'rumours implicate Alexander and Olympias', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='His father’s murder handed him a superpower at twenty — under a shadow of suspicion he never fully escaped.', accent=AC),
      bg='<b>Philip II</b> had made Macedon supreme in Greece and was about to invade Persia when he was killed.',
      people='<b>Philip II</b>; the assassin <b>Pausanias</b>; <b>Olympias</b>, Alexander’s mother, suspected of complicity.',
      what='In <b>336 BC</b> Philip was <b>assassinated</b> by his bodyguard <b>Pausanias</b> at a wedding festival; Alexander, aged 20, immediately secured the throne and the loyalty of the army — amid persistent <b>rumours</b> that he and Olympias had a hand in the murder.',
      crux='He inherited a <b>ready-made superpower</b> at the perfect moment — but the suspicious circumstances hint at the ruthless ambition that ran beneath his heroic image.',
      conseq='Alexander swiftly eliminated rivals, secured Greece, and took up his father’s planned invasion of Persia.',
      matters='Great inheritances can come by dark means. Philip’s murder gave Alexander everything — and cast an early shadow of ruthlessness over his glory.'),

    E('machine', '359–338 BC', 'The war machine he inherited', ['REFORM', 'RISE'],
      'Philip left him the most advanced army in the world: the long-pike phalanx and heavy Companion cavalry working as one — a finished weapon Alexander would wield more boldly than its maker ever dared.',
      svg_row('Philip’s combined-arms system', [
          {'n': 1, 'label': 'The sarissa phalanx', 'sub': '5–6m pikes; a wall that pins the enemy', 'color': '#a16207'},
          {'n': 2, 'label': 'Companion cavalry', 'sub': 'heavy shock horse — the hammer', 'color': '#b45309'},
          {'n': 3, 'label': 'Hammer & anvil', 'sub': 'phalanx holds; cavalry smashes the flank', 'color': '#16a34a'},
      ], edge_labels=['+', '='], takeaway='He didn’t invent his army — he inherited a perfect tool and used it more boldly than its maker.', accent=AC),
      bg='Before Alexander could conquer, someone had to build the instrument. <b>Philip II</b> spent 20 years professionalising the Macedonian army with pay, drill, engineers and a siege train.',
      people='<b>Philip II</b>, the reformer-king; the <b>Companions</b> (hetairoi), his elite cavalry; veteran generals like <b>Parmenion</b> whom Alexander inherited.',
      what='Philip created the <b>sarissa</b> pike phalanx, disciplined professional infantry, shock <b>Companion cavalry</b>, and a corps of engineers — combined into a <b>hammer-and-anvil</b> system able to force and exploit a breakthrough.',
      crux='The phalanx <b>fixed</b> the enemy while heavy cavalry <b>struck the decisive point</b>. It was a system for making and then exploiting a breach — exactly what Alexander would do again and again.',
      conseq='He began his conquests with a battle-tested professional army, a siege train, and experienced generals — a head start almost no conqueror enjoys.',
      matters='Great achievers often stand on an inherited system. The genius is in how boldly you use the tool — Alexander pushed Philip’s machine to the ends of the earth.'),

    E('chaeronea', '338 BC', 'Chaeronea — first blood at eighteen', ['BATTLE', 'RISE'],
      'At eighteen he commands the cavalry wing that shatters the elite Theban Sacred Band and wins the battle that makes Philip master of Greece — his first proof that he can deliver the decisive blow.',
      svg_row('His combat debut', [
          {'n': 1, 'label': 'Greece resists Philip', 'sub': 'Athens & Thebes ally against Macedon', 'color': '#64748b'},
          {'n': 2, 'label': 'Alexander leads the left', 'sub': 'at 18, commands the Companion cavalry', 'color': '#a16207'},
          {'n': 3, 'label': 'Breaks the Sacred Band', 'sub': 'destroys Thebes’ elite; Greece falls to Philip', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He proved young that he could find and strike the decisive point in the chaos of battle.', accent=AC),
      bg='By 338 BC Philip’s expansion had frightened the Greek city-states into a last coalition led by <b>Athens</b> and <b>Thebes</b>.',
      people='<b>Philip II</b>, commanding overall; the <b>Theban Sacred Band</b>, an elite corps of 300 that died almost to a man; the orator <b>Demosthenes</b>, Athens’ voice against Macedon.',
      what='At <b>Chaeronea</b>, the 18-year-old Alexander led the cavalry charge that broke through and annihilated the <b>Sacred Band</b>, deciding the battle. Philip became master of Greece and formed the <b>League of Corinth</b>.',
      crux='Even at eighteen he showed the signature skill: timing a heavy-cavalry charge to hit the point where the enemy line would break, then exploiting it ruthlessly.',
      conseq='Greece was subdued under Macedonian hegemony, and the pan-Hellenic invasion of Persia — Philip’s plan — became possible. Alexander was marked as a soldier of the first rank.',
      matters='Talent shows early when given a real stage. Chaeronea was the rehearsal for a decade of decisive charges to come.'),

    E('throne', '336–335 BC', 'The throne, the Balkans, and the ruin of Thebes', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'Philip is murdered; at twenty Alexander seizes the throne, eliminates rivals, storms north to crush rebellious Balkan tribes in a lightning campaign — then destroys Thebes utterly to freeze Greece into obedience.',
      svg_stack('Securing the base before staking everything on Asia', [
          {'n': 1, 'label': 'Philip assassinated (336 BC)', 'sub': 'Alexander, 20, seizes the throne & purges rivals', 'color': '#475569'},
          {'n': 2, 'label': 'Lightning Balkan campaign (335)', 'sub': 'Thracians, Triballi, then Illyria — crushed at speed', 'color': '#b45309'},
          {'n': 3, 'label': 'Thebes revolts on a false rumour', 'sub': 'hearing Alexander is “dead” in the north', 'color': '#64748b'},
          {'n': 4, 'label': 'Thebes razed (335)', 'sub': 'city destroyed, people enslaved — a warning to Greece', 'color': '#dc2626'},
      ], takeaway='You cannot conquer abroad on a rebellious home base — he secured the rear with speed and one act of exemplary terror.', accent=AC),
      bg='When Philip was murdered in <b>336 BC</b>, Macedonian control over Greece and the Balkans was new and fragile. Enemies everywhere saw a chance to break free from an untested youth.',
      people='<b>Philip II</b> (assassinated by Pausanias); rival claimants Alexander eliminated; the northern tribes (<b>Triballi</b>, <b>Getae</b>, Illyrians under <b>Cleitus</b> and Glaucias); the city of <b>Thebes</b>.',
      what='Alexander secured the throne, then in <b>335 BC</b> marched north in a stunning campaign — crossing the Danube, scattering the Triballi and Getae, and beating the Illyrians. When <b>Thebes</b> revolted on a rumour of his death, he stormed back, took the city and <b>razed it</b>, sparing only temples and the poet Pindar’s house.',
      crux='Two tools: <b>speed</b> (appearing where no one thought he could be, fast) and <b>calculated terror</b> (one overwhelming example bought years of obedience more cheaply than many wars).',
      conseq='The Balkans were pacified and Greece was cowed into silence, freeing Alexander to take his army east in 334 BC without fear of revolt behind him.',
      matters='Before a bold outward move, secure the base — with a mix of speed and, when needed, one decisive, exemplary blow.'),
]

# ==================================================================  PHASE 2 — ASIA MINOR
PHASE_ASIAMINOR = [
    E('hellespont', 'Spring 334 BC', 'Crossing to Asia — “spear-won land” and Achilles’ shield', ['RISE', 'POLITICS'],
      'He crosses into Asia, hurls his spear into the soil to claim it from the gods, and makes a pilgrimage to Troy to honour Achilles — framing the whole invasion as a heroic, Homeric quest.',
      svg_row('Turning a war into a myth', [
          {'n': 1, 'label': 'Cross the Hellespont', 'sub': '~40,000 men; hurls his spear ashore', 'color': '#a16207'},
          {'n': 2, 'label': 'Pilgrimage to Troy', 'sub': 'honours Achilles; takes a sacred shield from Athena’s temple', 'color': '#7c3aed'},
          {'n': 3, 'label': 'A Homeric crusade', 'sub': 'he is the new Achilles; the men believe it', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He wrapped a war of conquest in a heroic myth — meaning and belief are force multipliers.', accent=AC),
      bg='In <b>334 BC</b> Alexander crossed the Hellespont to invade the Persian Empire — nominally to “avenge” Persia’s old invasion of Greece and liberate the Greek cities of Asia.',
      people='<b>Hephaestion</b>, his closest companion (who honoured Patroclus at Troy as Alexander honoured Achilles); the priests of <b>Athena at Ilium</b>, who gave him a shield said to date from the Trojan War.',
      what='He threw his spear into Asian soil to claim it as <b>“spear-won land,”</b> then visited <b>Troy</b>, laid a wreath at Achilles’ tomb, and took a sacred shield he would carry into battle.',
      crux='He understood war as <b>story</b> as well as logistics: casting himself as the new Achilles gave his men a heroic identity and himself an unshakeable sense of destiny.',
      conseq='The campaign began with soaring morale and a mythic framing that would carry the army through eight brutal years — and shape Alexander’s self-image to the end.',
      matters='People fight harder for a story than for a paycheck. Alexander made his soldiers believe they were living an epic — and so they did.'),

    E('granicus', 'May 334 BC', 'The Granicus — the first gamble', ['BATTLE', 'RISE'],
      'Ignoring cautious advice, he attacks a Persian army waiting on the far bank of a river, charges across at the head of his cavalry, is nearly killed in the melee — and wins, throwing open Asia Minor.',
      svg_row('The pattern he sets at his first Asian battle', [
          {'n': 1, 'label': 'Persians hold the far bank', 'sub': 'satraps + Greek mercenaries under Memnon', 'color': '#dc2626'},
          {'n': 2, 'label': 'He charges across anyway', 'sub': 'leads the cavalry into the river; nearly dies', 'color': '#a16207'},
          {'n': 3, 'label': 'Asia Minor opens', 'sub': 'the satraps’ army breaks', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He led from the very front — inspiring, and nearly fatal. Personal courage was his first tactic.', accent=AC),
      bg='The local <b>Persian satraps</b> gathered to stop Alexander at the <b>Granicus</b> river, rejecting the advice of the able Greek mercenary <b>Memnon of Rhodes</b> to retreat and scorch the land.',
      people='<b>Memnon of Rhodes</b>, Persia’s best commander, overruled here; <b>Cleitus the Black</b>, who saved Alexander’s life by cutting off an attacker’s arm mid-blow.',
      what='Alexander charged across the river at the head of the Companions. In the melee he was nearly killed — an axe split his helmet — before <b>Cleitus</b> saved him. The Persian line broke; the Greek mercenaries were massacred or enslaved.',
      crux='He fought from the front, accepting huge personal risk to inspire his men and be where the decision lay. It won battles — and would eventually kill him by degrees.',
      conseq='The victory freed the Greek cities of Asia Minor (he installed democracies), gave him plunder and momentum, and made Persia take him seriously.',
      matters='Leading from the front inspires ferocious loyalty and wins the moment — but it stakes everything on one irreplaceable life.'),

    E('fleet', 'Summer 334 BC', 'Disbanding the fleet — beating a navy from the land', ['POLITICS', 'TURNING POINT'],
      'Persia’s navy is far stronger than his own, so he does something audacious: he sends most of his ships home and resolves to defeat the enemy fleet by capturing every port it depends on — winning at sea by marching on land.',
      svg_fleet(),
      bg='After taking <b>Miletus</b> (334), Alexander faced the huge <b>Persian navy</b> (~400 ships), which could cut his supply lines, raise Greece against him, and outmatch his ~160 ships in any battle.',
      people='<b>Parmenion</b>, who reportedly urged a naval fight; <b>Memnon</b>, whose fleet-based counter-offensive in the Aegean was the real threat — cut short by his death in 333 BC.',
      what='Rather than risk a battle he might lose (and could not afford), Alexander <b>disbanded most of his fleet</b> and committed to <b>seizing every Persian naval base along the coast</b> — Halicarnassus, then the whole Levant — so the enemy ships would have nowhere to water, resupply or refit.',
      crux='He refused to fight a superior force on its own terms. Instead he attacked <b>what that force depended on</b> — its shore bases. Deny a navy its ports and it withers without a single sea battle.',
      conseq='Within about two years the once-dominant Persian fleet had largely dissolved for want of bases, its Greek crews and ports lost — a strategic masterstroke that also committed him irrevocably inland.',
      matters='When you can’t beat a strength head-on, attack its dependencies. The indirect approach — striking the supports rather than the thing itself — often wins where a frontal fight would fail.'),

    E('halicarnassus', 'Autumn 334 BC', 'Halicarnassus — siegecraft and a friendly queen', ['BATTLE', 'POLITICS'],
      'He takes the great fortified port of Halicarnassus after a hard siege, denying it to the Persian fleet, and installs the deposed local queen Ada — who adopts him as her son, turning conquest into legitimacy.',
      svg_row('Conquest by force and by adoption', [
          {'n': 1, 'label': 'Siege of Halicarnassus', 'sub': 'Memnon defends hard; Alexander storms the walls', 'color': '#a16207'},
          {'n': 2, 'label': 'Deny the port to Persia', 'sub': 'another naval base captured', 'color': '#b45309'},
          {'n': 3, 'label': 'Ada adopts him', 'sub': 'restores the local queen → she names him heir', 'color': '#16a34a'},
      ], edge_labels=['then', 'then'], takeaway='He paired hard siegecraft with smart politics — winning walls by force and hearts by legitimacy.', accent=AC),
      bg='<b>Halicarnassus</b> in Caria was a major fortified port and a key link in the Persian naval chain, defended by <b>Memnon</b> and the satrap Orontobates.',
      people='<b>Memnon of Rhodes</b>, conducting a skilful defence; <b>Ada of Caria</b>, the rightful local ruler deposed by the Persians, whom Alexander reinstated and who <b>adopted him as her son</b>.',
      what='After a tough siege with rams and towers, Alexander took the city (the defenders burned part of it and withdrew to citadels). He then <b>restored Ada</b> as satrap; she adopted him, giving his rule in Caria a legitimacy beyond conquest.',
      crux='He grasped that <b>holding</b> territory is political, not just military: by restoring a popular local ruler who then endorsed him, he turned occupiers into liberators and bought lasting loyalty.',
      conseq='Another Persian naval base fell, tightening the coastal strategy, and Caria became a secure, friendly province — a template for ruling through co-opted locals.',
      matters='Winning the war and holding the peace are different skills. Force takes a city; legitimacy — often via a respected local — is what keeps it.'),

    E('gordium', '333 BC', 'The Gordian Knot — cutting through', ['POLITICS', 'RISE'],
      'At Gordium, told that whoever unties an impossibly tangled knot will rule Asia, Alexander simply slices it apart with his sword — a piece of theatre that hardens his men’s belief that he is destined to win.',
      svg_row('Manufacturing an omen', [
          {'n': 1, 'label': 'The prophecy', 'sub': 'untie the knot → rule all Asia', 'color': '#64748b'},
          {'n': 2, 'label': 'He cuts it', 'sub': 'refuses the puzzle; solves it his own way', 'color': '#a16207'},
          {'n': 3, 'label': 'Destiny confirmed', 'sub': 'morale soars; the legend grows', 'color': '#7c3aed'},
      ], edge_labels=['then', 'so'], takeaway='He rejected the terms of an impossible problem and redefined success on his own terms.', accent=AC),
      bg='Wintering at <b>Gordium</b> in 333 BC, Alexander encountered the famous ox-cart knot, tied by legend so intricately that whoever undid it was fated to rule Asia.',
      people='His soldiers and the local priests, all watching to see whether the young king was truly favoured by the gods.',
      what='Unable (or unwilling) to untie it, Alexander <b>cut the knot with his sword</b> (some sources say he pulled out the linchpin). That night, a thunderstorm was read as the gods’ approval.',
      crux='Faced with a problem defined to be unsolvable on its own terms, he <b>changed the terms</b>. Whether bravado or genius, it was a masterclass in propaganda and self-belief.',
      conseq='The stunt cemented his men’s conviction that he was destined to conquer Asia — a belief that carried them through the far harder years ahead.',
      matters='Some problems are traps only if you accept their rules. Redefining the problem — “cut, don’t untie” — is often the boldest and best solution.'),
]

# ==================================================================  PHASE 3 — ISSUS & THE LEVANT
PHASE_LEVANT = [
    E('issus', 'Nov 333 BC', 'Issus — beating the Great King himself', ['BATTLE', 'TRIUMPH'],
      'Darius slips behind him and cuts his supply line — but on a narrow coastal plain where Persia’s numbers can’t deploy, Alexander drives straight at the king, who flees, abandoning his own mother, wife and children.',
      svg_compare('Why terrain decided Issus', {
          'head': 'Darius III', 'color': '#dc2626',
          'items': ['Vastly larger army', 'Trapped in a narrow plain', 'Numbers can’t deploy', 'Flees when charged directly']},
          {'head': 'Alexander', 'color': '#a16207',
           'items': ['Smaller, superb army', 'Fights on constricted ground', 'Aims his charge at Darius', 'Rolls up the line and wins']},
          verdict='On narrow ground, quality beats quantity — and the king’s nerve was the real target.',
          takeaway='He kept fighting where the enemy’s biggest advantage — numbers — could not be used.', accent=AC),
      bg='<b>Darius III</b> took the field in person in 333 BC and manoeuvred behind Alexander, forcing battle at <b>Issus</b> on a cramped coastal plain between mountains and sea.',
      people='<b>Darius III</b>, King of Kings; his captured <b>family</b> — his mother <b>Sisygambis</b>, wife <b>Stateira</b> and children — treated by Alexander with famous courtesy.',
      what='On the narrow field Persia’s numbers were useless. Alexander punched through the left and drove at Darius, who <b>fled the field</b>, collapsing his army. The royal family was captured; Alexander treated them as royalty.',
      crux='He negated Persia’s one advantage (numbers) by fighting in a bottleneck, then aimed at the psychological centre — the king. Remove the king’s nerve and the army evaporates.',
      conseq='Alexander’s prestige soared. Darius sued for peace — offering ransom, land west of the Euphrates, and a daughter — and Alexander refused; he wanted the whole empire.',
      matters='Fight on ground that cancels the enemy’s strengths, and aim at the point whose collapse ends everything — often a person, not a position.'),

    E('sisygambis', '333 BC', 'The captive queens — magnanimity as strategy', ['POLITICS', 'LOVE'],
      'When Darius’s mother, wife and children fall into his hands after Issus, Alexander treats them not as spoils but as royalty — protecting their honour, keeping their rank, and winning such devotion that Darius’s own mother, Sisygambis, comes to love him as a son, later grieving his death more than her own child’s. It is conquest by grace as much as by the sword.',
      svg_row('Winning hearts he could have crushed', [
          {'n': 1, 'label': 'The royal women captured', 'sub': 'Darius’s mother, wife and children taken', 'color': '#a16207'},
          {'n': 2, 'label': 'Treated as royalty', 'sub': 'their honour and rank scrupulously protected', 'color': '#166534'},
          {'n': 3, 'label': 'Sisygambis loves him', 'sub': 'the queen mother comes to see him as a son', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='He conquered by grace as well as force — winning the devotion of the very family he had captured.', accent=AC),
      bg='After Issus, the family of <b>Darius III</b> — his mother <b>Sisygambis</b>, wife <b>Stateira</b>, and children — fell into Alexander’s hands.',
      people='<b>Sisygambis</b>, the Persian queen mother; <b>Stateira</b>, Darius’s wife; the captured royal children.',
      what='Alexander <b>treated Darius’s captured family with scrupulous honour</b>, preserving their royal status and dignity. He won such loyalty that <b>Sisygambis came to regard him as a son</b> — and, by tradition, mourned his death more deeply than that of Darius himself.',
      crux='He understood that <b>magnanimity was also strategy</b>: honouring the defeated royal family cast him as a legitimate king, not a mere conqueror, easing his rule over Persia.',
      conseq='His clemency burnished his image across the Persian world and helped him claim the mantle of rightful Great King.',
      matters='Conquest is completed by legitimacy. Alexander’s grace toward Darius’s family shows that mercy can be as powerful a tool of empire as the sword.'),

    E('tyre', 'Jan–Jul 332 BC', 'The Siege of Tyre — making an island a peninsula', ['BATTLE', 'TRIUMPH'],
      'The island-fortress of Tyre defies him. Rather than bypass a hostile port at his back, he spends seven brutal months building a kilometre-long causeway out to the walls — literally re-shaping the coastline to take it.',
      svg_tyre(),
      bg='Continuing the coastal strategy, Alexander needed every Phoenician port to strangle the Persian navy. <b>Tyre</b>, on a fortified island half a mile offshore, refused to admit him.',
      people='The Tyrians, who executed his envoys and defended fiercely; the Phoenician and Cypriot fleets that <b>defected</b> to Alexander, letting him blockade the island.',
      what='Alexander built a <b>mole (causeway)</b> from the mainland toward the island, using rubble from old Tyre. The Tyrians fought back with fireships and sorties; when Phoenician and Cypriot ships joined him, he blockaded and finally <b>stormed the city</b> after seven months, with heavy slaughter and mass enslavement.',
      crux='He refused to leave a strong enemy port behind him — and when the terrain (an island) was the obstacle, he <b>changed the terrain</b>, out-engineering the problem with sheer persistence.',
      conseq='The fall of Tyre broke Persian sea power in the eastern Mediterranean and completed the coastal strategy. (The causeway remains — Tyre is a peninsula to this day.)',
      matters='Persistence plus engineering can overcome “impossible” obstacles. And never leave a hostile strongpoint at your back for the sake of speed.'),

    E('gaza', 'Sep–Oct 332 BC', 'The Siege of Gaza — and a wound', ['BATTLE'],
      'The last fortress on the road to Egypt holds out on a high mound; Alexander takes it after a hard siege in which he is seriously wounded — clearing the final barrier to Egypt.',
      svg_row('Clearing the last door to Egypt', [
          {'n': 1, 'label': 'Gaza’s high mound', 'sub': 'the eunuch Batis defies him from a fortress-hill', 'color': '#dc2626'},
          {'n': 2, 'label': 'Siege ramps & mines', 'sub': 'engineers build up to the walls; Alexander wounded', 'color': '#a16207'},
          {'n': 3, 'label': 'Egypt lies open', 'sub': 'the road south is clear', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He accepted personal wounds and time-cost to leave no strongpoint uncleared behind him.', accent=AC),
      bg='<b>Gaza</b>, a strongly fortified town on a high mound, was the last obstacle between the Levant and Egypt, held for Persia by the commander <b>Batis</b>.',
      people='<b>Batis</b>, Gaza’s defiant defender; Alexander’s corps of <b>engineers</b>, who built earthworks up to the walls; Alexander himself, wounded in the shoulder during the siege.',
      what='After several assaults and the building of siege ramps and mines, Alexander <b>stormed Gaza</b>, suffering a serious wound. The defenders were killed or enslaved; the way to Egypt was clear.',
      crux='Again the discipline of the coastal strategy: reduce <b>every</b> fortress in turn rather than leave a threat astride his lines of communication — even at the price of blood and months.',
      conseq='With Gaza fallen, Egypt — rich, ancient and anti-Persian — opened to him without a fight.',
      matters='Thoroughness is a strategy. Clearing every strongpoint is slow and costly, but it prevents the disasters that “skipping ahead” invites.'),

    E('egypt', '332–331 BC', 'Egypt — a new city and a god’s son', ['POLITICS', 'TRIUMPH'],
      'Egypt welcomes him as a liberator from Persia. He founds Alexandria, the city that will carry his name for millennia, and treks to the desert oracle of Ammon, which hails him as the son of a god.',
      svg_row('Wealth, a great city, and divinity', [
          {'n': 1, 'label': 'Egypt welcomes him', 'sub': 'frees it from Persia; crowned pharaoh', 'color': '#0891b2'},
          {'n': 2, 'label': 'Founds Alexandria', 'sub': 'a new Greek city — future centre of the world', 'color': '#a16207'},
          {'n': 3, 'label': 'Oracle at Siwa', 'sub': 'hailed as son of Amun/Zeus — divine sanction', 'color': '#7c3aed'},
      ], edge_labels=['then', 'then'], takeaway='He secured his rear and sea, founded an immortal city, and deepened his belief in his own divinity.', accent=AC),
      bg='Egypt hated its Persian occupiers. Having secured the whole coast, Alexander could enter it safely and turn it into a friendly, wealthy base before striking into the Persian heartland.',
      people='The Egyptian priests who crowned him <b>pharaoh</b>; the oracle of <b>Amun at Siwa</b>, which greeted him as a god’s son; his architect <b>Dinocrates</b>, who laid out Alexandria.',
      what='Egypt submitted without a fight. Alexander <b>founded Alexandria</b> (332 BC) on the Mediterranean, and made a dangerous desert pilgrimage to <b>Siwa</b>, where the oracle affirmed his <b>divine sonship</b>.',
      crux='Strategic patience paid off: with his rear and sea secure, he gained wealth, a great new city, and a religious aura — while the divine affirmation fed a growing (and dangerous) sense of destiny.',
      conseq='<b>Alexandria</b> became the intellectual capital of the ancient world for centuries (its Library and Lighthouse legendary). Egypt’s wealth funded the next campaign; his sense of godhood grew.',
      matters='Conquest can create as well as destroy — Alexandria outlived his empire by two thousand years. But belief in one’s own divinity is a seed of later ruin.'),
]

# ==================================================================  PHASE 4 — THE FALL OF PERSIA
PHASE_PERSIA = [
    E('gaugamela', '1 Oct 331 BC', 'Gaugamela — the empire won', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'On open ground Darius has levelled for his chariots and vast numbers, Alexander deliberately pulls the Persian line apart, opens a gap, and drives a cavalry wedge straight at Darius. The Great King flees again — and Persia falls.',
      svg_gaugamela(),
      bg='In 331 BC Alexander crossed the Euphrates and Tigris and met Darius’s enormous new army on the prepared plain of <b>Gaugamela</b>, ground cleared so chariots and numbers could tell.',
      people='<b>Darius III</b>, staking his empire on one battle; <b>Parmenion</b>, holding the hard-pressed Macedonian left; <b>Bessus</b>, a satrap commanding the Persian left who would soon betray Darius.',
      what='Alexander marched <b>obliquely to his right</b>, stretching the Persian left until a <b>gap</b> opened; he led the <b>Companion wedge</b> straight toward Darius, who <b>fled</b>, and the vast army disintegrated. (He declined Parmenion’s advice to attack by night — “I will not steal a victory.”)',
      crux='He <b>manufactured</b> the weak point rather than waiting for one, then committed his best force to the single spot — the king — whose collapse would end the battle.',
      conseq='<b>Babylon</b> and the Persian capitals fell. Alexander became master of the Persian Empire — the richest and largest state on earth.',
      matters='Don’t just look for a gap — create one, then commit your decisive force to the single point that ends everything.'),

    E('babylon', 'Oct–Dec 331 BC', 'Babylon and Susa — the richest prize in history', ['POLITICS', 'TRIUMPH'],
      'The great cities open their gates without a fight. Babylon welcomes him as a liberator; Susa yields a treasury so vast it would take thousands of pack animals to carry — funding everything to come.',
      svg_row('Winning by welcome, not just war', [
          {'n': 1, 'label': 'Babylon surrenders', 'sub': 'welcomed in; respects its gods & customs', 'color': '#0891b2'},
          {'n': 2, 'label': 'Susa’s treasury', 'sub': 'seizes ~50,000 talents of silver & gold', 'color': '#a16207'},
          {'n': 3, 'label': 'Funds the whole campaign', 'sub': 'pays the army; bankrolls years of war', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He entered as a respectful liberator, not a looter — and inherited the wealth of an empire intact.', accent=AC),
      bg='After Gaugamela the road to the Persian heartland lay open. How Alexander treated these ancient, proud cities would determine whether he could actually rule Persia.',
      people='The priests and governors of <b>Babylon</b> who opened the gates; the satrap of <b>Susa</b>, who surrendered its immense treasury.',
      what='<b>Babylon</b> welcomed Alexander; he honoured its temples and confirmed local elites. <b>Susa</b> surrendered a treasury of roughly <b>50,000 talents</b> — an almost unimaginable fortune — which he used to pay and reward his army.',
      crux='He understood that to <b>keep</b> Persia he had to rule as a legitimate king, not a foreign plunderer: respecting local religion and administration turned conquered cities into a working empire.',
      conseq='He now had the money to sustain endless campaigning and the beginnings of a functioning imperial administration — but also the temptations and corruptions of unimaginable wealth.',
      matters='How you treat what you conquer decides whether you can hold it. Respect and restraint at the moment of victory buy loyalty that looting never can.'),

    E('gates', 'Jan 330 BC', 'The Persian Gates — a Thermopylae in reverse', ['BATTLE'],
      'The last natural barrier to Persepolis is a narrow mountain pass, and for once Alexander is stopped cold — until a captured shepherd reveals a hidden path and he climbs the mountains to take the defenders from behind.',
      svg_gates(),
      bg='Marching on the ceremonial Persian capital <b>Persepolis</b>, Alexander found the mountain pass of the <b>Persian Gates</b> walled and held by the satrap <b>Ariobarzanes</b>.',
      people='<b>Ariobarzanes</b>, who mounted a heroic defence and bloodily repulsed the first assault; a captured local guide who revealed a mountain track around the position.',
      what='Alexander’s frontal attack was <b>thrown back with heavy losses</b> — a rare check. Learning of a hidden path, he led a night march over the mountains, <b>fell on the defenders from the rear</b>, and destroyed them. Persepolis lay open.',
      crux='It was <b>Thermopylae reversed</b>: the same outflanking manoeuvre the Persians once used against the 300 Spartans now broke a Persian stand. A wall across a valley is only as strong as the ridge above it.',
      conseq='The road to Persepolis, heart of the empire, was open — leading to the campaign’s most controversial act.',
      matters='Even the best can be stopped by good ground — but few strong positions have no way around. Reconnaissance and a willingness to take the hard path unlock the “impossible.”'),

    E('persepolis', '330 BC', 'Persepolis — triumph and the great fire', ['TRIUMPH', 'TRAGEDY', 'POLITICS'],
      'He takes the ceremonial heart of the Persian Empire and its treasury — then burns the great palace of Persepolis to the ground, whether as calculated revenge for Greece or a drunken act he later regretted.',
      svg_row('The most debated act of the campaign', [
          {'n': 1, 'label': 'Take Persepolis', 'sub': 'the ceremonial capital + a vast treasury', 'color': '#a16207'},
          {'n': 2, 'label': 'The palace burns', 'sub': 'policy revenge for Xerxes’ burning of Athens? or a drunken party?', 'color': '#dc2626'},
          {'n': 3, 'label': 'A symbol destroyed', 'sub': 'the old empire’s heart is gone', 'color': '#7c3aed'},
      ], edge_labels=['then', 'so'], takeaway='A single dramatic act can close one story (revenge for Greece) while opening another (now he must rule, not just conquer).', accent=AC),
      bg='<b>Persepolis</b> was the ceremonial capital of the Achaemenid Persians — and a symbol of the empire that had once invaded and burned Greek Athens in 480 BC.',
      people='<b>Thaïs</b>, an Athenian courtesan who (in one famous account) urged the burning as revenge; Alexander’s generals, divided over the act; the Persian nobility watching how their new master behaved.',
      what='Alexander seized Persepolis and its treasury, then <b>burned the great palace complex</b>. Sources dispute whether it was <b>deliberate policy</b> (revenge for Xerxes’ sack of Athens, a message that the war of vengeance was over) or a <b>drunken impulse</b> he came to regret.',
      crux='Whatever its cause, the fire marked a <b>hinge</b>: the pan-Hellenic “revenge” war was symbolically finished. From here Alexander was no longer avenging Greece but <b>ruling Persia</b> — and had to become a Persian king to do it.',
      conseq='The act shocked Persians and ended the campaign’s original justification; Alexander now pivoted from conqueror to would-be legitimate Great King — straining his relationship with his Macedonians.',
      matters='Symbols matter as much as substance. The burning closed one chapter and forced the hardest transition of all: from winning power to holding and legitimising it.'),

    E('darius', 'Jul 330 BC', 'The death of Darius — becoming the Great King', ['POLITICS', 'TURNING POINT'],
      'Pursuing the fleeing Darius across hundreds of miles, Alexander finds him murdered by his own kinsman Bessus. By avenging the dead king and honouring him, Alexander claims to be Persia’s rightful successor.',
      svg_stack('Turning a dead rival into legitimacy', [
          {'n': 1, 'label': 'Relentless pursuit', 'sub': 'chases Darius east at brutal speed', 'color': '#a16207'},
          {'n': 2, 'label': 'Bessus murders Darius', 'sub': 'the satrap kills the king and claims the throne', 'color': '#dc2626'},
          {'n': 3, 'label': 'Alexander avenges & honours him', 'sub': 'royal burial for Darius; hunts Bessus down', 'color': '#7c3aed'},
          {'n': 4, 'label': 'Rightful successor', 'sub': 'now the legitimate Great King, not a usurper', 'color': '#16a34a'},
      ], takeaway='By avenging the king he was destroying, he transformed conquest into legitimate succession.', accent=AC),
      bg='After Persepolis, Darius fled east to raise a new army. His own satraps, led by <b>Bessus</b>, seized and then murdered him rather than let him fall into Alexander’s hands.',
      people='<b>Darius III</b>, found dying or dead by the pursuing Macedonians; <b>Bessus</b>, the regicide who declared himself Great King “Artaxerxes V” — later captured and brutally executed by Alexander.',
      what='Alexander pursued Darius relentlessly; his men found the king already murdered (July 330 BC). Alexander gave Darius a <b>royal funeral</b> and cast himself as the <b>avenger of the legitimate king</b>, then hunted down <b>Bessus</b> and had him executed for regicide.',
      crux='He converted the death of his enemy into his own <b>legitimacy</b>: by honouring Darius and punishing the usurper, he claimed to be Persia’s rightful king rather than a foreign conqueror.',
      conseq='Alexander was now, in his own eyes and increasingly in Persian eyes, the <b>Great King</b> — a status that pushed him to adopt Persian ways and set him on a collision course with his own Macedonians.',
      matters='Legitimacy is a story you construct. Alexander turned even his enemy’s murder into a claim of rightful succession — controlling the narrative of his own power.'),
]

# ==================================================================  PHASE 5 — LORD OF ASIA
PHASE_ASIA = [
    E('orientalize', '330–327 BC', 'Becoming Persian — the fatal fusion', ['POLITICS', 'TURNING POINT'],
      'To rule Persians he starts dressing and ruling like a Persian king and expects Persian-style bowing — a shrewd bid for legitimacy that his Macedonian veterans see as a betrayal of everything they fought for.',
      svg_stack('The trade-off at the heart of his rule', [
          {'n': 1, 'label': 'Adopt Persian dress & court', 'sub': 'robes, diadem, Persian nobles and eunuchs', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Demand proskynesis', 'sub': 'ritual bowing — normal for Persians, servile to Greeks', 'color': '#b45309'},
          {'n': 3, 'label': 'Recruit Persian troops', 'sub': 'blend the armies; train Persian youths', 'color': '#0891b2'},
          {'n': 4, 'label': 'Macedonians feel betrayed', 'sub': 'the seeds of mutiny and murder among his own', 'color': '#475569'},
      ], takeaway='To rule the conquered he became one of them — and began losing the loyalty of the men who had won it for him.', accent=AC),
      bg='As Great King, Alexander needed to govern millions of Persians and blend two ruling classes. Persian kingship came with dress and ceremony alien and offensive to his Macedonian and Greek followers.',
      people='The old Macedonian guard, uneasy and resentful; incoming <b>Persian nobles</b> Alexander cultivated; <b>Callisthenes</b>, his official historian, who publicly resisted proskynesis.',
      what='Alexander adopted <b>Persian royal dress and court ceremony</b>, took Persian officials, recruited Persian soldiers, and tried to introduce <b>proskynesis</b> (ritual prostration) — which Greeks reserved for gods, not men.',
      crux='A genuine, shrewd <b>fusion policy</b> to make his empire governable looked, to his veterans, like their leader turning into the oriental despot they had crossed the world to overthrow. The tension was irreconcilable.',
      conseq='This widening rift between Alexander and his own men underlies the violent episodes of the next years — the purges, the murder of Cleitus, and the failed proskynesis.',
      matters='To lead the people you’ve conquered you often must become partly one of them — but adaptation can cost you the base that made you. That trade-off is the hardest test of a conqueror.'),

    E('philotas', '330 BC', 'The Philotas affair — the first blood among his own', ['POLITICS', 'TRAGEDY'],
      'A murky conspiracy gives Alexander the pretext to destroy Philotas, a leading general — and then, chillingly, to have Philotas’s father Parmenion, his most senior commander, murdered to prevent revenge.',
      svg_row('Power turning on its own', [
          {'n': 1, 'label': 'A plot is alleged', 'sub': 'Philotas fails to report a conspiracy', 'color': '#475569'},
          {'n': 2, 'label': 'Philotas tried & executed', 'sub': 'the army condemns him under torture', 'color': '#dc2626'},
          {'n': 3, 'label': 'Parmenion murdered', 'sub': 'the loyal old general killed pre-emptively', 'color': '#9f1239'},
      ], edge_labels=['then', 'then'], takeaway='Suspicion at the top consumes even the most loyal — pre-emptive fear becomes its own kind of terror.', accent=AC),
      bg='Deep in hostile Asia, adopting Persian ways, Alexander grew wary of the powerful Macedonian old guard — above all the family of <b>Parmenion</b>, his most senior and independent general.',
      people='<b>Philotas</b>, commander of the Companion cavalry and Parmenion’s son; <b>Parmenion</b>, the veteran second-in-command who had served since Philip’s day.',
      what='Accused of failing to report a plot, <b>Philotas</b> was tried before the army, tortured, and executed. Alexander then sent orders to have the innocent <b>Parmenion</b> — far away guarding the supply lines — <b>assassinated</b>, to forestall any revenge.',
      crux='It was cold, pre-emptive politics: removing a potential power centre and its head of family before they could become a threat. The killing of the loyal Parmenion marked a darkening in Alexander himself.',
      conseq='Alexander tightened his personal control over the army, but fear now spread through his officer corps — the price of security was trust.',
      matters='Absolute power breeds pre-emptive suspicion. When leaders start destroying loyal servants to remove hypothetical threats, the rot has begun.'),

    E('bactria', '329–327 BC', 'Bactria and Sogdiana — the war that would not end', ['BATTLE', 'TRIUMPH'],
      'Beyond Persia he grinds through two brutal years of guerrilla war in the mountains of Central Asia, captures an “unclimbable” fortress rock by sending men up the cliffs at night, and marries the Bactrian princess Roxana.',
      svg_row('The hardest, dirtiest campaign', [
          {'n': 1, 'label': 'Guerrilla war (Spitamenes)', 'sub': 'no set battles; ambush, revolt, atrocity', 'color': '#dc2626'},
          {'n': 2, 'label': 'The Sogdian Rock', 'sub': '“find me men with wings” — climbers take it by night', 'color': '#a16207'},
          {'n': 3, 'label': 'Marries Roxana', 'sub': 'a marriage to bind conquered Bactria', 'color': '#db2777'},
      ], edge_labels=['then', 'then'], takeaway='Even the invincible battle-winner needed patience, brutality and diplomacy to hold ungovernable ground.', accent=AC),
      bg='The far north-eastern satrapies (<b>Bactria</b> and <b>Sogdiana</b>, roughly modern Afghanistan/Uzbekistan) rose in stubborn revolt, led by the guerrilla chieftain <b>Spitamenes</b>.',
      people='<b>Spitamenes</b>, a brilliant guerrilla leader who harried Alexander for years before being killed by his own allies; <b>Roxana</b>, daughter of a Bactrian lord, whom Alexander married in 327 BC; <b>Oxyartes</b>, her father.',
      what='Alexander waged a savage counter-insurgency — founding garrison-cities, storming mountain fortresses like the <b>Sogdian Rock</b> (captured when volunteers scaled sheer cliffs at night), and finally suppressing the revolt. He <b>married Roxana</b> to help bind the region.',
      crux='Against dispersed guerrillas his war-winning tool — the decisive battle — had no target. Victory here took <b>years of grinding attrition, terror, city-founding and marriage-diplomacy</b>, not one brilliant stroke.',
      conseq='Central Asia was subdued at heavy cost; the marriage to Roxana produced his only (posthumous) legitimate son. The strain of these years deepened his paranoia and drinking.',
      matters='Set-piece brilliance fails against insurgency. Holding rebellious ground demands patience, local alliances and, too often, brutality — a different and harder kind of war.'),

    E('cleitus', '328 BC', 'The murder of Cleitus — a friend run through', ['TRAGEDY', 'DEATH'],
      'At a drunken feast, an old general who once saved Alexander’s life mocks his Persian airs. Enraged, Alexander seizes a spear and kills him on the spot — then is consumed by guilt for days.',
      svg_row('The dark side of absolute power', [
          {'n': 1, 'label': 'A drunken argument', 'sub': 'Cleitus mocks the “orientalising” and flattery', 'color': '#b45309'},
          {'n': 2, 'label': 'Alexander kills him', 'sub': 'runs him through with a spear, in fury', 'color': '#9f1239'},
          {'n': 3, 'label': 'Days of remorse', 'sub': 'guilt-stricken; but the pattern is set', 'color': '#475569'},
      ], edge_labels=['then', 'then'], takeaway='Unchecked power + wine + paranoia turned an inspiring leader into a man his own friends feared.', accent=AC),
      bg='The tension over Alexander’s Persian ways, heavy drinking, and the flattery of his courtiers came to a head among the old Macedonian companions.',
      people='<b>Cleitus the Black</b>, the cavalry officer who had <b>saved Alexander’s life at the Granicus</b> — now killed by his hand.',
      what='At a banquet in Samarkand (328 BC), a drunken <b>Cleitus</b> openly criticised Alexander’s adoption of Persian ways and his growing arrogance. Enraged, Alexander <b>seized a spear and killed him</b>. He was afterward wracked with grief and shut himself away for days.',
      crux='Years of strain, drink, and the corrosive effects of absolute, unaccountable power destroyed his self-control. The very intensity that drove him became lethal when nothing and no one could check it.',
      conseq='Fear deepened at his court; the bond between Alexander and his old Macedonians frayed further. The god-king was now also a man who might kill a friend at dinner.',
      matters='Power without limits corrodes even great character. The absence of anyone able to check you is a danger, not a privilege.'),

    E('roxana', '327 BC', 'Roxana — love, policy, and the fusion made flesh', ['LOVE', 'POLITICS', 'TURNING POINT'],
      'In the mountains of Bactria he marries Roxana, the daughter of a local chieftain — a union of genuine attraction and shrewd policy, binding the fierce peoples he has struggled to subdue and embodying, in his own marriage bed, the fusion of East and West that his whole later reign pursues.',
      svg_row('A marriage of the heart and the empire', [
          {'n': 1, 'label': 'Marries Roxana', 'sub': 'a Bactrian noble’s daughter, 327 BC', 'color': '#a16207'},
          {'n': 2, 'label': 'Love and policy', 'sub': 'genuine attraction, and a bond with a fierce region', 'color': '#be185d'},
          {'n': 3, 'label': 'Fusion made personal', 'sub': 'East and West joined in his own marriage', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He married the East as policy and as love — his own marriage embodying the fusion his empire was built on.', accent=AC),
      bg='In <b>Bactria/Sogdiana</b>, after a brutal guerrilla war, Alexander married <b>Roxana</b>, daughter of a local baron.',
      people='<b>Roxana</b>, his wife; her father <b>Oxyartes</b>; the Bactrian nobility bound to him by the match.',
      what='Alexander <b>married Roxana (327 BC)</b> — a union of both <b>genuine attraction and calculated policy</b> that helped reconcile the fierce peoples of the northeast and embodied his vision of <b>fusing East and West</b>.',
      crux='He merged <b>the personal and the political</b>: a real marriage that was also a tool of reconciliation and a statement of his fusion ideal.',
      conseq='Roxana bore his posthumous son, Alexander IV — who, like the empire, would not survive the wars of the successors.',
      matters='Alexander lived his fusion policy in his own household. His marriage to Roxana joined love, statecraft, and his vision of a blended world.'),

    E('pages', '327 BC', 'The Pages’ Conspiracy — the bow that would not bend', ['POLITICS', 'TRAGEDY'],
      'His attempt to make everyone bow low fails when Greeks refuse; a plot by his royal pages is uncovered and crushed, and his own court historian — who had opposed the bowing — is destroyed with them.',
      svg_row('The limit of even his authority', [
          {'n': 1, 'label': 'Proskynesis rejected', 'sub': 'Greeks/Macedonians refuse to prostrate; he drops it', 'color': '#64748b'},
          {'n': 2, 'label': 'The Pages’ plot', 'sub': 'young noble attendants conspire to kill him', 'color': '#dc2626'},
          {'n': 3, 'label': 'Callisthenes destroyed', 'sub': 'the dissenting historian implicated and killed', 'color': '#9f1239'},
      ], edge_labels=['then', 'then'], takeaway='He could conquer an empire but not compel his own people to worship him — culture pushed back where armies could not.', accent=AC),
      bg='Alexander tried to standardise <b>proskynesis</b> (prostration) for everyone at court. Persians accepted it as normal; Greeks and Macedonians saw prostrating before a man as blasphemous servility.',
      people='<b>Callisthenes</b>, Aristotle’s nephew and Alexander’s official historian, who publicly refused to prostrate; the <b>royal pages</b> (noble teenage attendants) who plotted to assassinate the king.',
      what='Greek resistance forced Alexander to <b>abandon</b> universal proskynesis — a rare public retreat. Soon after, a <b>conspiracy among the pages</b> was uncovered and its members executed; <b>Callisthenes</b>, associated with the dissent, was implicated and put to death.',
      crux='Even absolute military power ran into a <b>cultural wall</b>: he could not make free Greeks treat him as a god. The affair shows both the limits of his authority and his readiness to kill dissenters.',
      conseq='Proskynesis was dropped for Westerners; but Callisthenes’ death alienated Greek opinion and later shadowed Alexander’s reputation among philosophers, including Aristotle’s circle.',
      matters='There are limits to what power can compel. Deep cultural values resist even the mightiest ruler — and forcing them breeds the very conspiracies you fear.'),
]

# ==================================================================  PHASE 6 — INDIA
PHASE_INDIA = [
    E('aornos', '327–326 BC', 'The Rock of Aornos — taking the untakeable', ['BATTLE', 'TRIUMPH'],
      'On the road into India he storms a cliff-fortress that legend said even Heracles had failed to take — building a ramp across a chasm to reach it — purely to prove that nothing is beyond him.',
      svg_row('Conquering a myth', [
          {'n': 1, 'label': 'A legendary stronghold', 'sub': 'Aornos — said to have defeated even Heracles', 'color': '#dc2626'},
          {'n': 2, 'label': 'Build a ramp to the cliff', 'sub': 'engineers bridge a ravine under fire', 'color': '#a16207'},
          {'n': 3, 'label': 'Take it — surpass Heracles', 'sub': 'proves he outdoes even the gods’ sons', 'color': '#7c3aed'},
      ], edge_labels=['then', 'so'], takeaway='He attacked the impossible partly for the legend of it — his ambition was for glory as much as ground.', accent=AC),
      bg='Entering the mountainous borderlands of India (327–326 BC), Alexander faced the fortress-mountain of <b>Aornos</b>, which local legend said had resisted even <b>Heracles</b>, his own claimed ancestor.',
      people='Alexander’s <b>engineers</b>, who bridged a deep ravine to bring siege engines within range; the defenders holding the heights.',
      what='Rather than bypass it, Alexander had his engineers <b>build a huge earthwork ramp</b> across a chasm to reach the fortress, then <b>stormed and took it</b> — deliberately succeeding where legend said Heracles had failed.',
      crux='This siege wasn’t strategic necessity so much as <b>glory-seeking</b>: to outdo a demigod and prove no obstacle could stop him. Ambition for legend, not just land, drove him ever onward.',
      conseq='Aornos added to his superhuman reputation — but the compulsion to always go further, take the untakeable, was the same drive that would soon exhaust his army past breaking.',
      matters='The hunger for glory can achieve the impossible — and also refuse to know when to stop. The same drive builds legends and burns out the people who follow it.'),

    E('hydaspes', 'May 326 BC', 'The Hydaspes — his hardest victory', ['BATTLE', 'TRIUMPH'],
      'In monsoon rain he tricks the Indian king Porus with weeks of feints, then makes a daring night river-crossing upstream, defeats a wall of war elephants in his toughest battle — and, impressed, restores Porus to his throne.',
      svg_hydaspes(),
      bg='In India in 326 BC, Alexander faced King <b>Porus</b>, whose army fielded a wall of <b>war elephants</b> across the flooded <b>Hydaspes</b> river — terrifying to horses and unfamiliar to the Macedonians.',
      people='<b>Porus</b>, the tall, defiant Indian king; <b>Bucephalus</b>, Alexander’s beloved warhorse, who died soon after (Alexander founded a city, <b>Bucephala</b>, in his memory).',
      what='Alexander wore Porus down with <b>weeks of noisy feints</b>, then <b>crossed upstream by night in a storm</b> and caught him. In a hard, bloody battle he neutralised the <b>elephants</b> (opening lanes, hamstringing them, showering them with missiles until they trampled their own side) and won. Asked how he wished to be treated, Porus said “as a king” — and Alexander <b>restored him</b> as an ally.',
      crux='Tactically he refused a frontal clash with the elephants and used <b>deception and manoeuvre</b>; politically, <b>magnanimity to a brave enemy</b> bought a loyal local ruler — cheaper than occupation.',
      conseq='It was his last great victory, and his costliest. Beyond lay only more rivers, more kingdoms, and an army at the end of its endurance.',
      matters='Beat a fearsome strength by refusing to meet it head-on — and remember that mercy to a worthy enemy can be the most profitable move of all.'),

    E('mutiny', 'Jul 326 BC', 'The mutiny at the Hyphasis — the limit', ['TURNING POINT', 'DEFEAT'],
      'At a river in India, after eight years and thousands of miles, his exhausted army finally refuses to march one step further. For the first time the unconquerable Alexander cannot get his way — and must turn back.',
      svg_stack('The one enemy he couldn’t beat: his own men’s limit', [
          {'n': 1, 'label': '8 years, thousands of miles', 'sub': 'the army is exhausted, homesick, done', 'color': '#475569'},
          {'n': 2, 'label': 'He wants the Ganges & the ocean', 'sub': 'dreams of reaching the “edge of the world”', 'color': '#a16207'},
          {'n': 3, 'label': 'The army refuses (326 BC)', 'sub': 'Coenus speaks for them; a silent, immovable “no”', 'color': '#dc2626'},
          {'n': 4, 'label': 'Alexander must turn back', 'sub': 'his only real defeat — by his own soldiers', 'color': '#9f1239'},
      ], takeaway='Even absolute will meets a wall: an exhausted army’s refusal was the one force Alexander could not overcome.', accent=AC),
      bg='By 326 BC his men had marched thousands of miles over eight years of constant fighting, far from home, into monsoon rains, with rumours of vast armies and more rivers ahead.',
      people='The war-weary <b>Macedonian veterans</b>; the officer <b>Coenus</b>, who bravely spoke for the army’s refusal to Alexander’s face.',
      what='At the <b>Hyphasis (Beas) river</b>, the army <b>refused to advance</b>. Alexander sulked in his tent for days and even took omens, but the men would not yield. For the first time, he had to <b>turn back</b>.',
      crux='He had beaten every army — but not the <b>human limits</b> of his own men. Willpower and charisma have a ceiling when bodies and morale are spent; the unconquerable had finally been told “no.”',
      conseq='He turned south down the Indus toward home — but chose a route that would cost more lives than any battle.',
      matters='There is a limit to what will and charisma can extract from people. Push past exhaustion and even the most loyal followers will finally refuse.'),

    E('gymnosophists', '326 BC', 'The naked philosophers — the conqueror questioned', ['POLITICS', 'REFORM'],
      'In India the world-conqueror meets a very different kind of power: the "gymnosophists," naked ascetic sages who own nothing and fear nothing, and who calmly challenge the point of his endless conquest — an encounter, recorded in legend, that captures the strange confrontation between boundless ambition and a philosophy of wanting nothing at all.',
      svg_row('Ambition meets its philosophical opposite', [
          {'n': 1, 'label': 'The naked sages', 'sub': 'Indian ascetics who own and fear nothing', 'color': '#a16207'},
          {'n': 2, 'label': 'They question conquest', 'sub': 'why cross the world to seize what you cannot keep?', 'color': '#166534'},
          {'n': 3, 'label': 'The conqueror confronted', 'sub': 'boundless ambition meets wanting nothing', 'color': '#7c3aed'},
      ], edge_labels=['then', 'so'], takeaway='The man who wanted the whole world met sages who wanted nothing — and could not answer them.', accent=AC),
      bg='In India, Alexander (ever Aristotle’s pupil) sought out the <b>gymnosophists</b> — naked Hindu/Jain ascetic philosophers.',
      people='The Indian <b>gymnosophists</b>; the philosopher <b>Calanus</b>, who joined Alexander and later immolated himself.',
      what='Alexander questioned the <b>gymnosophists</b>, ascetics who owned nothing and feared not even death, and who pointedly <b>challenged the purpose of his endless conquest</b>; one, <b>Calanus</b>, accompanied him and later chose a serene death by fire.',
      crux='The encounter dramatised the <b>collision between limitless ambition and a philosophy of desirelessness</b> — the conqueror faced with the question of what all his conquest was for.',
      conseq='The meeting became legendary as a moral counterpoint to Alexander’s restless drive.',
      matters='Even the greatest conqueror was, for a moment, made to answer for his ambition. The gymnosophists are the philosophical shadow over Alexander’s glory.'),

    E('mallian', '325 BC', 'The Mallian campaign — nearly killed at the wall', ['BATTLE', 'TRAGEDY'],
      'Fighting his way down the Indus, he leaps alone over the wall of a hostile town ahead of his hesitating men and is shot through the lung with an arrow — a near-fatal wound that he barely survives.',
      svg_row('The cost of always leading the charge', [
          {'n': 1, 'label': 'Storming the Mallian town', 'sub': 'his troops hesitate at the wall', 'color': '#b45309'},
          {'n': 2, 'label': 'He jumps in alone', 'sub': 'leaps inside to shame them into following', 'color': '#a16207'},
          {'n': 3, 'label': 'Arrow through the lung', 'sub': 'nearly dies; the army panics, then avenges him', 'color': '#9f1239'},
      ], edge_labels=['then', 'then'], takeaway='The front-line courage that made his legend nearly ended it — leadership by example has a terrible price.', accent=AC),
      bg='Descending the Indus in 325 BC, Alexander waged a series of brutal campaigns against the <b>Mallians</b> and other peoples who resisted his passage.',
      people='Alexander’s alarmed soldiers, who thought their king dead; the men who fought their way in to save him; his devoted guards.',
      what='Storming a Mallian stronghold, an impatient Alexander <b>scaled the wall and leapt inside almost alone</b> when his men hung back. He was <b>shot through the chest</b>, the arrow piercing his lung. His troops, believing him dead, stormed in and massacred the town; Alexander survived a desperate recovery.',
      crux='His defining habit — <b>leading from the very front</b> — had reached its logical end: a wound that nearly killed him and permanently damaged his health. The trait that inspired his men almost destroyed the campaign.',
      conseq='He never fully recovered his health; the wound likely contributed to his physical decline. The army’s panic showed how utterly everything depended on his single life.',
      matters='The greatest strength carries the matching risk. Leading from the front built Alexander’s legend — and staked an empire on one fragile, over-exposed body.'),
]

# ==================================================================  PHASE 7 — RETURN & DEATH
PHASE_DEATH = [
    E('gedrosia', '325 BC', 'The Gedrosian desert — victory’s worst wound', ['TRAGEDY', 'DEFEAT'],
      'On the way home he leads his army through a scorching desert — perhaps to prove a point, perhaps as punishment — and thousands die of thirst and heat. It is his greatest self-inflicted disaster.',
      svg_row('The march that killed what battles couldn’t', [
          {'n': 1, 'label': 'Choose the desert route', 'sub': 'the Gedrosian (Makran) wasteland', 'color': '#a16207'},
          {'n': 2, 'label': 'Heat, thirst, flash floods', 'sub': 'no water, no food, no mercy', 'color': '#dc2626'},
          {'n': 3, 'label': 'Thousands die', 'sub': 'more lost here than in any battle', 'color': '#9f1239'},
      ], edge_labels=['into', 'so'], takeaway='His worst losses came not from an enemy but from his own refusal to accept a limit — pride marched an army into a furnace.', accent=AC),
      bg='After turning back from India, Alexander split his forces and led part of the army overland through the <b>Gedrosian Desert</b> (the Makran, in modern Pakistan/Iran), while a fleet under Nearchus explored the coast.',
      people='His suffering soldiers and the camp-followers who died in droves; the admiral <b>Nearchus</b>, who sailed the fleet along the coast in parallel.',
      what='The desert march was catastrophic: <b>heat, thirst and sudden flash floods killed thousands</b> — by many accounts more than any battle in the whole campaign. Ancient sources suggest pride, or a wish to outdo legend (that no army had crossed it), drove the choice.',
      crux='The same relentless, limit-defying will that conquered an empire now had no enemy to aim at — and turned on his own army. Greatness unchecked by prudence became self-destruction.',
      conseq='The army that reached Persia was a shadow of itself. Alexander’s aura of infallible judgement was damaged, and exhaustion and losses mounted.',
      matters='The trait that makes someone unstoppable can destroy them when there’s no enemy left to point it at. Know when the fight is over.'),

    E('cyrus', '324 BC', 'Cyrus’s tomb and the reckoning with the satraps', ['POLITICS'],
      'Returning to a Persia that had assumed him dead, he finds the tomb of Cyrus the Great — his royal idol — looted and desecrated, and orders it restored, while purging the corrupt governors who misruled in his absence.',
      svg_row('Reasserting the Great King', [
          {'n': 1, 'label': 'Cyrus’s tomb desecrated', 'sub': 'at Pasargadae, robbed while he was in India', 'color': '#dc2626'},
          {'n': 2, 'label': 'He restores it', 'sub': 'honours Cyrus, his model of kingship', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Purge of the satraps', 'sub': 'executes corrupt governors who abused power', 'color': '#a16207'},
      ], edge_labels=['then', 'then'], takeaway='He modelled himself on Cyrus the Great and cracked down hard to reassert authority after years away.', accent=AC),
      bg='While Alexander was in India and the desert, many of his provincial governors (<b>satraps</b>) had assumed he would never return and had misgoverned, embezzled, or built private power.',
      people='<b>Cyrus the Great</b>, founder of the Persian Empire and Alexander’s ideal of a just conqueror-king, whose tomb at <b>Pasargadae</b> Alexander revered; the corrupt satraps he now executed.',
      what='Alexander found <b>Cyrus’s tomb broken into and looted</b> and ordered it <b>restored</b>, reading its epitaph with emotion. He then conducted a sweeping <b>purge of corrupt or disloyal officials</b> across the empire to reassert control.',
      crux='He consciously took <b>Cyrus the Great</b> as his model — a conqueror remembered for tolerance and just rule — and moved hard to restore order and accountability after his long absence.',
      conseq='Central authority was reasserted, but the purges added to the sense of a ruler whose absence, illness and unpredictability kept everyone off balance.',
      matters='Great leaders choose models to emulate. Alexander measured himself against Cyrus — and knew that an empire left unwatched will be robbed by the very people trusted to run it.'),

    E('susaopis', '324 BC', 'The Susa weddings and the Opis mutiny', ['POLITICS', 'TURNING POINT'],
      'He tries to fuse his empire by marrying his officers to Persian brides en masse — then, when his Macedonian veterans mutiny over their Persian replacements, he faces them down and stages a grand banquet of reconciliation.',
      svg_stack('Forcing two peoples into one — and the backlash', [
          {'n': 1, 'label': 'The Susa weddings', 'sub': 'Alexander & ~90 officers wed Persian noblewomen', 'color': '#db2777'},
          {'n': 2, 'label': 'Persians into the army', 'sub': 'trains Persian troops; pensions off Macedonians', 'color': '#0891b2'},
          {'n': 3, 'label': 'Mutiny at Opis', 'sub': 'veterans revolt at being replaced; he stares them down', 'color': '#dc2626'},
          {'n': 4, 'label': 'Banquet of reconciliation', 'sub': 'prays for “partnership” between the peoples', 'color': '#16a34a'},
      ], takeaway='His grand vision of fusing conqueror and conquered was real — and repeatedly crashed into his own soldiers’ resentment.', accent=AC),
      bg='Back in Persia in 324 BC, Alexander pushed hardest on his policy of <b>fusing Macedonians and Persians</b> into a single ruling elite and army.',
      people='<b>Hephaestion</b> and dozens of officers who took Persian brides; the <b>Macedonian veterans</b> who felt discarded; the Persian youths (“Successors”) trained in Macedonian style.',
      what='At the mass <b>Susa weddings</b>, Alexander and about 90 officers married Persian noblewomen. When he integrated Persian soldiers and moved to send veterans home, the Macedonians <b>mutinied at Opis</b>. Alexander <b>faced them down</b> (threatening to replace them entirely with Persians), then reconciled with them at a great feast, praying for <b>concord between the peoples</b>.',
      crux='His <b>fusion vision</b> — one empire of mixed rulers — was genuinely visionary, but it repeatedly collided with the <b>identity and pride</b> of the men who had conquered the world for him.',
      conseq='The mutiny was resolved and veterans sent home with honour, but the deep tension between Alexander’s cosmopolitan empire and his Macedonian core was never truly settled.',
      matters='Grand visions of unity meet the hard limit of human identity. Merging peoples and cultures is far harder than conquering them — and can’t simply be commanded.'),

    E('hephaestion', 'Oct 324 BC', 'The death of Hephaestion — grief unhinged', ['TRAGEDY', 'DEATH'],
      'His closest friend and likely lover dies of a fever, and Alexander is shattered — refusing food, executing the doctor, ordering a monstrously extravagant funeral, and never recovering his balance in the months he has left.',
      svg_row('The loss that broke him', [
          {'n': 1, 'label': 'Hephaestion dies (fever)', 'sub': 'his dearest companion, at Ecbatana', 'color': '#db2777'},
          {'n': 2, 'label': 'Extravagant, wild grief', 'sub': 'fasting, a vast funeral pyre, divine honours sought', 'color': '#9f1239'},
          {'n': 3, 'label': 'Alexander unravels', 'sub': 'reckless, grieving, months from his own death', 'color': '#475569'},
      ], edge_labels=['then', 'then'], takeaway='The conqueror of the world could not master grief — the human wound none of his power could heal.', accent=AC),
      bg='<b>Hephaestion</b> was Alexander’s lifelong closest companion (whom many sources treat as his lover) and one of his most senior officers — the person he loved most.',
      people='<b>Hephaestion</b>, whose death at Ecbatana devastated Alexander; the physician, reportedly executed; the whole army, ordered into mourning.',
      what='When Hephaestion died of a <b>fever</b> in 324 BC, Alexander’s grief was <b>extreme and public</b>: he refused food for days, had the attending doctor executed, ordered a colossally expensive funeral and monument, and sought divine honours for his friend.',
      crux='The man who could conquer anything was <b>helpless before loss</b>. Hephaestion’s death removed his closest emotional anchor and pushed his already strained state toward collapse.',
      conseq='Alexander never recovered his equilibrium; within about eight months he too was dead. The bond, and its breaking, is one of history’s most famous friendships.',
      matters='No amount of power protects against grief and love. The purely human — a friend’s death — undid the man no army ever could.'),

    E('logistics', '334–323 BC', 'The invisible genius — feeding an army across a world', ['REFORM', 'BATTLE'],
      'Behind every famous battle lies the achievement historians most admire and audiences most forget: the logistics of marching tens of thousands of men and animals eleven thousand miles across deserts, mountains and enemy lands for a decade — a feat of planning, timing and supply that was arguably a greater accomplishment than any single victory.',
      svg_row('The unglamorous foundation of every triumph', [
          {'n': 1, 'label': 'Tens of thousands to feed', 'sub': 'men, horses, followers, across a decade', 'color': '#a16207'},
          {'n': 2, 'label': 'Plan every march', 'sub': 'timing to harvests, rivers, coasts and depots', 'color': '#166534'},
          {'n': 3, 'label': 'Supply across a world', 'sub': '11,000 miles through desert and mountain', 'color': '#b45309'},
      ], edge_labels=['plus', 'so'], takeaway='His deepest genius may have been logistical — feeding an army across half the world for ten unbroken years.', accent=AC),
      bg='Alexander’s campaigns required moving and supplying a large army across enormous distances and hostile terrain for years on end.',
      people='His quartermasters and engineers; the fleets and supply lines he coordinated with his marches.',
      what='Alexander (building on Philip’s reforms) mastered <b>military logistics</b> — timing marches to <b>harvests, water and coasts</b>, coordinating fleets, and keeping tens of thousands supplied across <b>~11,000 miles</b> over a decade — a planning feat historians rank among his greatest.',
      crux='His victories rested on an <b>invisible foundation of supply and planning</b>; the battles were the visible tip of a vast logistical achievement.',
      conseq='This mastery let him campaign continuously where a lesser-organised army would have starved or disintegrated.',
      matters='Amateurs talk battles; professionals talk logistics. Alexander’s supply genius was arguably his greatest — and least celebrated — skill.'),

    E('wounds', '334–325 BC', 'Leading from the front — a body of scars', ['BATTLE', 'TRAGEDY'],
      'He never asks his men to face what he will not: again and again he charges at the head of his cavalry and is first over the wall, collecting a catalogue of grievous wounds — a cracked skull, a sword-cut, an arrow through the lung — that both fuel his soldiers’ devotion and steadily wear down the body that dies at thirty-two.',
      svg_row('The price of always going first', [
          {'n': 1, 'label': 'Always at the front', 'sub': 'leads every charge; first over walls', 'color': '#a16207'},
          {'n': 2, 'label': 'Wound after wound', 'sub': 'head, thigh, shoulder, and a lung pierced by an arrow', 'color': '#9f1239'},
          {'n': 3, 'label': 'Devotion — and decline', 'sub': 'inspires his men; wears down his body', 'color': '#475569'},
      ], edge_labels=['then', 'so'], takeaway='He shared every danger and bore the scars to prove it — winning fanatical loyalty at the cost of his own body.', accent=AC),
      bg='Alexander was famous for <b>leading from the very front</b> of the fighting, sharing every risk with his soldiers.',
      people='The soldiers who followed him because he faced what they faced; the physicians who repeatedly saved him.',
      what='Alexander <b>personally led charges and assaults</b> throughout his campaigns, suffering a long series of serious <b>wounds</b> — including a near-fatal <b>arrow through the lung</b> at the Mallian town — that inspired fierce devotion but progressively damaged his health.',
      crux='His <b>front-line leadership</b> was the source of his soldiers’ near-worship — and a physical toll that helped bring him down young.',
      conseq='The accumulated wounds and strain contributed to his early death at 32.',
      matters='He led by shared danger, not command from the rear — the source of his legend, and part of the reason it ended so soon.'),

    E('foundations', '331–323 BC', 'The cities — conquest as construction', ['REFORM', 'TRIUMPH'],
      'He is not only a destroyer but a builder: across his empire he founds dozens of new cities, many named Alexandria, planting Greek settlers, culture and language from Egypt to the edge of India — seeds of a Hellenistic world that will outlast his empire by centuries and carry Greek civilisation across three continents.',
      svg_row('Planting a civilisation across a continent', [
          {'n': 1, 'label': 'Founds dozens of cities', 'sub': 'many named Alexandria, from Egypt to India', 'color': '#a16207'},
          {'n': 2, 'label': 'Greek settlers and culture', 'sub': 'language, learning and institutions transplanted', 'color': '#166534'},
          {'n': 3, 'label': 'Seeds of a Hellenistic world', 'sub': 'that outlasts his empire by centuries', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='He built as he conquered — founding cities that spread Greek civilisation across three continents.', accent=AC),
      bg='As he conquered, Alexander <b>founded new cities</b> — most famously <b>Alexandria in Egypt</b> — as centres of trade, culture and control.',
      people='The Greek and Macedonian settlers; the mixed populations of the new cities; <b>Alexandria in Egypt</b>, which became a wonder of the ancient world.',
      what='Alexander founded <b>dozens of cities</b> (many named <b>Alexandria</b>) from Egypt to India, settling them with Greeks and spreading <b>Greek language, culture and institutions</b> — the foundation of the <b>Hellenistic world</b>.',
      crux='He treated conquest as <b>construction as well as destruction</b>, seeding a lasting cultural transformation across the known world.',
      conseq='Alexandria in Egypt became a centre of learning for centuries; Greek culture spread across three continents.',
      matters='Alexander’s deepest legacy was cultural: the Hellenistic world of cities and Greek civilisation that his conquests planted and that long outlived his empire.'),

    E('death', 'Jun 323 BC', 'Death at Babylon — and “to the strongest”', ['DEATH', 'TRAGEDY', 'TURNING POINT'],
      'Back in Babylon, planning fresh conquests, he falls into a fatal fever and dies at 32 with no clear heir. Asked who should succeed him, he reportedly says only “to the strongest” — and his generals tear the empire apart.',
      svg_fracture(),
      bg='Returned to <b>Babylon</b> in 323 BC, still grieving Hephaestion, Alexander was planning new expeditions (Arabia, perhaps the western Mediterranean) when he fell ill after days of feasting.',
      people='<b>Roxana</b>, pregnant with his son (the future Alexander IV, later murdered); his generals — the future <b>Diadochi</b> (Ptolemy, Seleucus, Antigonus, Perdiccas and others).',
      what='After about ten days of <b>fever</b> (illness — likely malaria or typhoid, possibly worsened by drink and his old lung wound — is the accepted cause; <b>poisoning theories are unproven and disputed</b>), Alexander <b>died on 10/11 June 323 BC, aged 32</b>. Asked to name a successor, he reportedly said his empire should go “<b>to the strongest</b>.” His generals fought over it for forty years.',
      crux='He had built an empire held together by <b>his person alone</b> — no institutions, no succession, no plan. When the one man died, nothing held it; personal empires die with the person.',
      conseq='The empire shattered into the warring <b>Hellenistic kingdoms</b> (Ptolemaic Egypt, the Seleucid East, Antigonid Macedon) — but those kingdoms spread <b>Greek language, art and ideas</b> from Egypt to India for three centuries, the lasting legacy.',
      matters='Conquest without institutions and succession is temporary. Alexander proved that building something that outlasts you is a completely different — and harder — task than winning it.'),
    E('legend', '323 BC → forever', 'The body, the tomb and the eternal archetype', ['LEGACY', 'MYTH', 'AFTERLIFE'],
      'His gold-laden funeral carriage was hijacked by Ptolemy and taken to Egypt, where his tomb became a shrine of kings. His body vanished from history — but the legend never did: for 2,000 years every would-be world-conqueror measured himself against Alexander.',
      svg_stack('The afterlife of a legend — from corpse to archetype', [
        {'n':'1','color':'#a16207','label':'The funeral hijack','sub':'Perdiccas sends the gold catafalque to Macedon; Ptolemy seizes it and takes the body to Egypt — a coup of legitimacy.'},
        {'n':'2','color':'#b45309','label':'The tomb at Alexandria','sub':'Enshrined in the “Soma”; Roman emperors from Augustus to Caracalla make pilgrimage. Then, after antiquity, the tomb is simply lost.'},
        {'n':'3','color':'#7c3aed','label':'The bloodline erased','sub':'Roxana and the boy Alexander IV, and his other kin, are all murdered by the Diadochi within ~15 years — the dynasty ends completely.'},
        {'n':'4','color':'#16a34a','label':'The archetype that outlives the man','sub':'Caesar wept before his statue; Pompey, Trajan, Napoleon all posed as “the new Alexander.” The empire died; the standard of greatness he set never has.'},
      ], 'The man vanished — no heir, no body, no tomb — yet became the yardstick every conqueror for two millennia would be measured against.', AC),
      bg='Alexander died with no arrangements for his body or his memory. His corpse became a <b>political trophy</b>: whoever held it held a piece of his legitimacy. The wars of the Diadochi were fought as much over his symbols as his lands.',
      people='<b>Ptolemy I</b> (hijacks the body, founds a dynasty in Egypt); <b>Perdiccas</b> (regent, tries to send it to Macedon, killed); <b>Roxana</b> &amp; <b>Alexander IV</b> (murdered ~309 BC); later <b>Augustus, Caligula, Caracalla</b> (Roman pilgrims to the tomb).',
      what='Ptolemy <b>diverted the vast golden funeral carriage to Egypt</b> and entombed Alexander in Alexandria, in a shrine called the <b>Soma</b> that Roman emperors visited for centuries. Sometime after antiquity the <b>tomb was lost</b> and has never been found. His widow and only legitimate son were <b>killed by his own generals</b> within fifteen years.',
      crux='A legend needs no living heir. Once Alexander was fixed as the <b>measure of human achievement</b>, the story propagated itself — culture carried him where blood and empire could not.',
      conseq='For two thousand years the phrase “<b>a new Alexander</b>” was the highest ambition a commander could name — Caesar, Pompey, Trajan, Julian, the Islamic “<b>Iskandar</b>” tradition, right through to <b>Napoleon</b>. He became less a man than a benchmark.',
      matters='The most durable thing a person can leave is not an empire but a <b>standard</b> — an idea of what is possible that others spend centuries trying to reach.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">In just thirteen years, Alexander III of Macedon marched an army from Greece to the edge of India, never lost a battle, and destroyed the mightiest empire on earth — then died at <b>32</b>, undefeated, with no heir and no plan for what came next. This guide follows the whole campaign in detail: not just the three great battles, but the sieges, the fleet-disbanding gamble, the guerrilla years, the mutinies and the near-fatal wounds in between. It is the ultimate study in <b>meteoric conquest, the intoxication of absolute power, and the difference between winning an empire and keeping one.</b></p>
<div class="ov-quote">“There is nothing impossible to him who will try.”<span>— attributed to Alexander; the animating belief of a career that refused every limit</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Engineered for greatness → seizes the throne and razes Thebes → crosses to Asia, wins at the Granicus, and disbands his own fleet to beat Persia’s navy from the land → takes Halicarnassus, cuts the Gordian Knot → beats Darius at Issus → besieges Tyre and Gaza, founds Alexandria → shatters Persia at Gaugamela, burns Persepolis, becomes Great King → grinds through Bactria, kills Cleitus → storms into India, beats Porus, is stopped only by his own army → nearly dies at the Mallian wall, loses thousands in the desert → dies at 32, and the empire fractures.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🌍</div><h4>The Hellenistic world</h4><p>He spread Greek language, art and thought from Egypt to India — shaping science, cities and culture for centuries.</p></div>
  <div class="ov-card"><div class="i">⚔️</div><h4>The decisive blow</h4><p>Aim at the one point — often the enemy king — whose collapse ends everything. Still the model of decisive battle.</p></div>
  <div class="ov-card"><div class="i">♟️</div><h4>The indirect approach</h4><p>Beat a navy by taking its ports; beat elephants by not charging them; take a wall by climbing the ridge above it.</p></div>
  <div class="ov-card"><div class="i">🏛️</div><h4>Winning ≠ keeping</h4><p>An empire held by one man’s person, with no institutions or heir, died with him. The hardest lesson in legacy.</p></div>
</div>
<div class="ov-lbl">The seven chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Origins</b><small> 356–335 BC</small><p>Prince, war machine, the throne, and Thebes destroyed.</p></div>
  <div><b>2 · Asia Minor</b><small> 334 BC</small><p>Granicus, the fleet gamble, Halicarnassus, the Gordian Knot.</p></div>
  <div><b>3 · The Levant</b><small> 333–332 BC</small><p>Issus, the Tyre mole, Gaza, Egypt and Siwa.</p></div>
  <div><b>4 · Persia</b><small> 331–330 BC</small><p>Gaugamela, Babylon, the Persian Gates, Persepolis.</p></div>
  <div><b>5 · Lord of Asia</b><small> 330–327 BC</small><p>Turning Persian; the purges; Bactria; Cleitus killed.</p></div>
  <div><b>6 · India</b><small> 327–325 BC</small><p>Aornos, Porus, the mutiny, the Mallian near-death.</p></div>
  <div><b>7 · Death</b><small> 325–323 BC</small><p>The desert, Cyrus’s tomb, the mutiny, Hephaestion, the end.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Read the takeaway strip first, then quiz yourself: <i>why did it happen, who was involved, what was the underlying logic?</i> Use <b>Key Events</b> for dates, <b>Who’s Who</b> for the cast, and <b>Master Timeline</b> for the whole life in one scroll.</p>
"""

# ==================================================================  WHO'S WHO
WHO = [
    {'name': 'Philip II of Macedon', 'role': 'father / architect', 'color': '#a16207',
     'bio': 'The ruthless king who built the professional Macedonian army and subdued Greece — handing Alexander a finished war machine and a springboard. Assassinated in 336 BC.',
     'rel': 'Gave him the army, the throne, and the model of conquest.'},
    {'name': 'Olympias', 'role': 'mother', 'color': '#7c3aed',
     'bio': 'A fierce, mystical princess of Epirus who claimed descent from Achilles and instilled in Alexander a belief in his divine destiny. A formidable political force in her own right.',
     'rel': 'Gave him the myth of divine birth and boundless ambition.'},
    {'name': 'Aristotle', 'role': 'tutor', 'color': '#0891b2',
     'bio': 'The greatest philosopher of the age, who tutored the teenage Alexander in literature, science, politics and Homeric glory. Their relationship soured after Alexander killed Aristotle’s nephew Callisthenes.',
     'rel': 'Shaped his mind and his hunger for glory.'},
    {'name': 'Hephaestion', 'role': 'closest companion', 'color': '#db2777',
     'bio': 'Alexander’s dearest friend and likely lover, and a senior officer. His death in 324 BC plunged Alexander into extravagant, inconsolable grief months before his own end.',
     'rel': 'The person he loved most; whose death broke him.'},
    {'name': 'Parmenion', 'role': 'senior general', 'color': '#475569',
     'bio': 'Philip’s veteran second-in-command, who held the line in the great battles and guarded the supply lines. His son Philotas was executed for an alleged plot; Parmenion himself was then murdered on Alexander’s order.',
     'rel': 'The loyal old general whose killing marked Alexander’s darkening.'},
    {'name': 'Cleitus the Black', 'role': 'officer & friend', 'color': '#9f1239',
     'bio': 'The cavalry officer who saved Alexander’s life at the Granicus — and was run through by Alexander himself in a drunken quarrel in 328 BC, a killing he bitterly regretted.',
     'rel': 'Saved his life, then died by his hand — the cost of unchecked power.'},
    {'name': 'Darius III', 'role': 'the Great King (Persia)', 'color': '#dc2626',
     'bio': 'The last Achaemenid king of Persia. Defeated at Issus and Gaugamela — fleeing both times — and finally murdered by his kinsman Bessus in 330 BC. Alexander avenged him to claim his throne.',
     'rel': 'His empire was Alexander’s prize; his flights decided two battles.'},
    {'name': 'Memnon of Rhodes', 'role': 'Persia’s best general', 'color': '#57534e',
     'bio': 'The Greek mercenary commander who urged scorched-earth against Alexander and led the defence of Halicarnassus and an Aegean counter-offensive. His death in 333 BC removed Persia’s ablest strategist.',
     'rel': 'The one Persian commander who might have stopped him.'},
    {'name': 'Bessus', 'role': 'regicide / usurper', 'color': '#78350f',
     'bio': 'The Bactrian satrap who murdered Darius and declared himself Great King. Alexander hunted him down and had him brutally executed — casting himself as Darius’s legitimate avenger.',
     'rel': 'His crime let Alexander claim the Persian throne by right.'},
    {'name': 'Porus', 'role': 'Indian king', 'color': '#16a34a',
     'bio': 'The tall, defiant king who fought Alexander to a standstill with war elephants at the Hydaspes. Impressed, Alexander restored him to his kingdom as an ally.',
     'rel': 'His hardest opponent — and a showcase of his magnanimity.'},
    {'name': 'Roxana', 'role': 'wife', 'color': '#f472b6',
     'bio': 'A Bactrian noblewoman Alexander married in 327 BC. Pregnant at his death, she bore Alexander IV, born posthumously and later murdered in the succession wars.',
     'rel': 'His wife and mother of an heir who never got to rule.'},
    {'name': 'Ptolemy', 'role': 'general → pharaoh', 'color': '#0e7490',
     'bio': 'A companion and general who, after Alexander’s death, seized Egypt and founded the Ptolemaic dynasty (ending with Cleopatra) — the most durable successor state. Wrote a history of the campaign.',
     'rel': 'A Diadochus who turned a piece of the empire into a 300-year dynasty.'},
    {'name': 'Callisthenes', 'role': 'historian / dissenter', 'color': '#334155',
     'bio': 'Aristotle’s nephew and Alexander’s official historian, who publicly refused to prostrate before the king. Implicated in the Pages’ conspiracy and put to death — poisoning Alexander’s reputation among Greeks.',
     'rel': 'The chronicler whose defiance and death darkened the legend.'},
    {'name': 'Nearchus', 'role': 'admiral', 'color': '#1d4ed8',
     'bio': 'Boyhood friend and admiral who led the fleet on a perilous exploratory voyage from the Indus along the coast to the Persian Gulf while the army crossed the Gedrosian desert.',
     'rel': 'His most trusted naval commander and explorer.'},
]

# ==================================================================  KEY EVENTS
KEY_EVENTS = [
    ('356 BC', 'Born in Pella; tutored by Aristotle', 'Engineered from birth for greatness.'),
    ('338 BC', 'Battle of Chaeronea', 'At 18 he breaks the Theban Sacred Band.'),
    ('336 BC', 'Philip murdered; Alexander is king', 'Seizes the throne at 20 and purges rivals.'),
    ('335 BC', 'Balkan campaign; Thebes razed', 'Secures the rear with speed and terror.'),
    ('334 BC', 'Crossing to Asia; Troy', 'Frames the war as a Homeric quest.'),
    ('334 BC', 'Battle of the Granicus', 'First victory in Asia; nearly killed.'),
    ('334 BC', 'Miletus; disbands the fleet', 'Resolves to beat Persia’s navy from the land.'),
    ('334 BC', 'Siege of Halicarnassus; Ada', 'Takes the port; a restored queen adopts him.'),
    ('333 BC', 'The Gordian Knot', 'Cuts through the “unsolvable” omen.'),
    ('333 BC', 'Battle of Issus', 'Beats Darius in person; captures his family.'),
    ('332 BC', 'Siege of Tyre', 'Builds a mole to take the island fortress.'),
    ('332 BC', 'Siege of Gaza', 'Clears the last barrier to Egypt; is wounded.'),
    ('332 BC', 'Egypt: Alexandria & Siwa', 'Founds his city; hailed as a god’s son.'),
    ('331 BC', 'Battle of Gaugamela', 'Shatters the Persian army; wins the empire.'),
    ('331 BC', 'Babylon & Susa', 'Cities and a vast treasury surrender.'),
    ('330 BC', 'The Persian Gates', 'Outflanks a pass — a Thermopylae in reverse.'),
    ('330 BC', 'Persepolis burned', 'The Persian capital’s palace goes up in flames.'),
    ('330 BC', 'Darius murdered by Bessus', 'Alexander avenges him; becomes Great King.'),
    ('330 BC', 'Philotas & Parmenion killed', 'Paranoia claims his own senior officers.'),
    ('329–327 BC', 'Bactria & Sogdiana', 'A brutal guerrilla war; marries Roxana.'),
    ('328 BC', 'Kills Cleitus', 'Murders the friend who saved his life, drunk.'),
    ('327 BC', 'Pages’ conspiracy; Callisthenes dies', 'Proskynesis fails; dissenters destroyed.'),
    ('327–326 BC', 'The Rock of Aornos', 'Takes a fortress said to have defied Heracles.'),
    ('326 BC', 'Battle of the Hydaspes vs Porus', 'His hardest victory — against war elephants.'),
    ('326 BC', 'Mutiny at the Hyphasis', 'His army refuses to go further; he turns back.'),
    ('325 BC', 'The Mallian campaign', 'Shot through the lung; nearly dies.'),
    ('325 BC', 'The Gedrosian desert march', 'Thousands die — his worst, self-inflicted disaster.'),
    ('324 BC', 'Susa weddings; Opis mutiny', 'Fusion policy; then a soldiers’ revolt and reconciliation.'),
    ('324 BC', 'Hephaestion dies', 'Devastating grief months before his own end.'),
    ('323 BC', 'Dies at Babylon, aged 32', '“To the strongest” — the empire fractures.'),
]

# ==================================================================  MASTER
MASTER = [
    {'year': '356 BC', 'age': 'born', 'phase': 'Origins', 'title': 'Born in Pella', 'desc': 'Son of Philip II and Olympias; tutored by Aristotle.'},
    {'year': '338 BC', 'age': 'age 18', 'phase': 'Origins', 'title': 'Chaeronea', 'desc': 'Breaks the Sacred Band; Greece falls to Philip.'},
    {'year': '336 BC', 'age': 'age 20', 'phase': 'Origins', 'title': 'Becomes king', 'desc': 'Philip murdered; Alexander seizes the throne.'},
    {'year': '335 BC', 'age': 'age 21', 'phase': 'Origins', 'title': 'Thebes razed', 'desc': 'Balkan campaign; a brutal example cows Greece.'},
    {'year': '334 BC', 'age': 'age 22', 'phase': 'Asia Minor', 'title': 'Granicus; fleet disbanded', 'desc': 'First Asian victory; beats the navy from the land.'},
    {'year': '334 BC', 'age': 'age 22', 'phase': 'Asia Minor', 'title': 'Halicarnassus', 'desc': 'Takes the port; the Gordian Knot follows.'},
    {'year': '333 BC', 'age': 'age 23', 'phase': 'The Levant', 'title': 'Issus', 'desc': 'Beats Darius in person; takes his family.'},
    {'year': '332 BC', 'age': 'age 24', 'phase': 'The Levant', 'title': 'Tyre & Gaza; Egypt', 'desc': 'The mole siege; founds Alexandria; Siwa oracle.'},
    {'year': '331 BC', 'age': 'age 25', 'phase': 'Persia', 'title': 'Gaugamela', 'desc': 'Destroys the Persian army; Babylon & Susa fall.'},
    {'year': '330 BC', 'age': 'age 26', 'phase': 'Persia', 'title': 'Persian Gates; Persepolis', 'desc': 'Outflanks the pass; burns the capital.'},
    {'year': '330 BC', 'age': 'age 26', 'phase': 'Lord of Asia', 'title': 'Darius dead; Great King', 'desc': 'Turns Persian; purges Philotas & Parmenion.'},
    {'year': '328 BC', 'age': 'age 28', 'phase': 'Lord of Asia', 'title': 'Bactria; kills Cleitus', 'desc': 'Guerrilla war; marries Roxana; a friend murdered.'},
    {'year': '326 BC', 'age': 'age 30', 'phase': 'India', 'title': 'Hydaspes; the mutiny', 'desc': 'Beats Porus; the army refuses to go on.'},
    {'year': '325 BC', 'age': 'age 31', 'phase': 'India', 'title': 'Mallian wound', 'desc': 'Shot through the lung storming a wall.'},
    {'year': '325 BC', 'age': 'age 31', 'phase': 'Death', 'title': 'Gedrosian desert', 'desc': 'A catastrophic march kills thousands.'},
    {'year': '324 BC', 'age': 'age 32', 'phase': 'Death', 'title': 'Susa weddings; Opis; Hephaestion dies', 'desc': 'Fusion, mutiny, and inconsolable grief.'},
    {'year': '323 BC', 'age': 'age 32', 'phase': 'Death', 'title': 'Death at Babylon', 'desc': '“To the strongest”; the empire is torn apart.'},
]

SOURCES = [
    ('Britannica — Alexander the Great', 'https://www.britannica.com/biography/Alexander-the-Great'),
    ('World History Encyclopedia — Alexander the Great', 'https://www.worldhistory.org/Alexander_the_Great/'),
    ('Britannica — Battle of Gaugamela', 'https://www.britannica.com/event/Battle-of-Gaugamela'),
    ('Britannica — Siege of Tyre', 'https://www.britannica.com/event/Siege-of-Tyre-332-BCE'),
    ('Britannica — Battle of the Hydaspes', 'https://www.britannica.com/event/Battle-of-the-Hydaspes-River'),
    ('Livius.org — Alexander the Great', 'https://www.livius.org/articles/person/alexander-the-great/'),
    ('Wikipedia — Alexander the Great', 'https://en.wikipedia.org/wiki/Alexander_the_Great'),
]

def build_meta():
    return {
        'pid': 'gm-alexander.html', 'kind': 'man', 'emoji': '🏛️', 'accent': AC,
        'name': 'Alexander the Great', 'years': '356–323 BC', 'group': 'Ancient Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'Undefeated from Greece to India by 30, master of the greatest empire on earth — and dead at 32 with no heir. Every battle, siege and decision of the campaign, in depth.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'origins', 'label': '1 · Origins', 'type': 'timeline',
             'intro': 'A prince engineered for greatness by a conquering father, a mystical mother and the finest mind in Greece — who seizes the throne at 20, subdues the Balkans, and cows Greece with fire.', 'events': PHASE_ORIGINS},
            {'id': 'asiaminor', 'label': '2 · Asia Minor', 'type': 'timeline',
             'intro': 'He crosses into Asia as the new Achilles, wins at the Granicus, then makes his boldest strategic gamble — disbanding his own fleet to defeat Persia’s navy on land.', 'events': PHASE_ASIAMINOR},
            {'id': 'levant', 'label': '3 · The Levant', 'type': 'timeline',
             'intro': 'He beats the Great King at Issus, then methodically reduces the coast — the epic seven-month siege of Tyre, the storm of Gaza, and the founding of Alexandria in a welcoming Egypt.', 'events': PHASE_LEVANT},
            {'id': 'persia', 'label': '4 · Persia', 'type': 'timeline',
             'intro': 'At Gaugamela he brings down the empire; Babylon and Susa open their gates; he forces the Persian Gates, burns Persepolis, and by avenging the murdered Darius becomes Great King.', 'events': PHASE_PERSIA},
            {'id': 'asia', 'label': '5 · Lord of Asia', 'type': 'timeline',
             'intro': 'Master of Persia, he starts ruling as a Persian king — and the strain of absolute power turns to paranoia, the murder of his own generals and friends, and years of brutal guerrilla war.', 'events': PHASE_ASIA},
            {'id': 'india', 'label': '6 · India', 'type': 'timeline',
             'intro': 'He storms into India, takes the “untakeable” Rock of Aornos, wins his hardest battle against Porus’ elephants — then meets the one enemy he cannot beat: his own army’s exhaustion.', 'events': PHASE_INDIA},
            {'id': 'death', 'label': '7 · Death', 'type': 'timeline',
             'intro': 'The march home becomes his worst disaster; he reasserts control, tries to fuse two peoples into one, loses Hephaestion — and dies at 32 with no heir, and the empire dies with him.', 'events': PHASE_DEATH,
             'sources': SOURCES, 'srcnote': 'Our ancient sources (Arrian, Plutarch, Diodorus, Curtius) were written centuries later and often disagree; where causes are debated (the burning of Persepolis, the cause of his death, the exact role of Thaïs) this guide flags it.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
