# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Satyajit Ray.
The Bengali auteur whose Apu Trilogy carried Indian cinema onto the world stage and made him one of the great directors of world film."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b45309'  # cinematic amber-gold

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE RAY LINEAGE
PHASE_ROOTS = [
    E('birth', '1921', 'Born into Bengal’s most artistic family', ['RISE', 'ORIGINS'],
      'Satyajit Ray is born on 2 May 1921 in Calcutta into a distinguished Brahmo family of writers, artists and printers — his grandfather Upendrakishore Ray a pioneer of children’s literature and printing, his father Sukumar Ray the beloved master of Bengali nonsense verse who dies when Satyajit is barely two, leaving the boy heir to an extraordinary creative inheritance.',
      svg_row('An inheritance of art and letters', [
          {'n': 1, 'label': 'Born in Calcutta, 2 May 1921', 'sub': 'into a cultured Brahmo family', 'color': '#b45309'},
          {'n': 2, 'label': 'Grandfather Upendrakishore', 'sub': 'pioneer of children’s books and printing', 'color': '#3730a3'},
          {'n': 3, 'label': 'Father Sukumar Ray', 'sub': 'nonsense-verse master; dies when Ray is 2', 'color': '#166534'},
      ], edge_labels=['heir to', 'and'], takeaway='He was born to a lineage of artists and printers — creativity was the family trade before it was his calling.', accent=AC),
      bg='<b>Satyajit Ray</b> was born on 2 May 1921 in Calcutta into the Ray family, prominent members of the reformist <b>Brahmo Samaj</b> and celebrated across Bengal for literature, illustration and printing.',
      people='his grandfather <b>Upendrakishore Ray Chowdhury</b>, writer and printing innovator; his father <b>Sukumar Ray</b>, the great humorist; his mother <b>Suprabha Ray</b>, who raised him alone.',
      what='Ray was the grandson of <b>Upendrakishore</b>, founder of the children’s magazine <i>Sandesh</i>, and son of <b>Sukumar Ray</b>, Bengal’s foremost nonsense-verse writer; Sukumar died in 1923, when Satyajit was two, and the boy was raised by his mother in modest circumstances.',
      crux='He grew up steeped in a family culture of <b>art, print and storytelling</b> — the crafts he would later fuse in cinema.',
      conseq='The lineage gave him both a name to live up to and an instinct for images, music and narrative from earliest childhood.',
      matters='Genius often has a lineage — Ray inherited a family workshop of Bengali creativity and carried it into a new medium.'),

    E('santiniketan', '1940–1942', 'Santiniketan and the eye of an artist', ['RISE', 'IDEAS'],
      'After a degree in economics at Presidency College, Ray goes reluctantly to Rabindranath Tagore’s university at Santiniketan to study fine art — and there, under the painters Nandalal Bose and Benode Behari Mukherjee, he discovers Indian and Far Eastern art and learns to see, a visual education that will shape every frame he later composes.',
      svg_stack('Learning to see', [
          {'n': 1, 'label': 'Presidency College economics degree', 'sub': 'then drawn toward art, not commerce', 'color': '#3730a3'},
          {'n': 2, 'label': 'Visva-Bharati, Santiniketan, 1940', 'sub': 'Tagore’s university; fine-art study', 'color': '#b45309'},
          {'n': 3, 'label': 'Bose and Mukherjee as teachers', 'sub': 'Indian and Oriental art; a trained eye', 'color': '#166534'},
      ], takeaway='Santiniketan gave him a painter’s eye — the compositional discipline that would define his cinema.', accent=AC),
      bg='Ray took a degree in economics at <b>Presidency College, Calcutta</b>, but his real passion was visual, and in 1940 his mother persuaded him to study at <b>Visva-Bharati University</b> in Santiniketan, founded by <b>Rabindranath Tagore</b>.',
      people='<b>Rabindranath Tagore</b>, the poet whose institution shaped him; the painters <b>Nandalal Bose</b> and <b>Benode Behari Mukherjee</b>, his teachers.',
      what='At Santiniketan Ray studied <b>fine art</b>, absorbing Indian, Mughal and Far Eastern traditions under Nandalal Bose and Benode Behari Mukherjee; though he left before finishing, the immersion trained his <b>compositional eye</b>.',
      crux='He learned there to think in <b>images and design</b> — the graphic foundation beneath his later film-making.',
      conseq='He later paid tribute to Benode Behari in the documentary <i>The Inner Eye</i> (1972) and adapted Tagore repeatedly on film.',
      matters='A director’s style begins before the camera — Ray’s painterly training is visible in the framing of every shot he made.'),

    E('keymer', '1943', 'The commercial artist and Signet Press', ['RISE', 'CRAFT'],
      'Back in Calcutta, Ray takes a job as a junior visualiser at the British advertising agency D.J. Keymer and moonlights designing book covers for Signet Press — mastering typography, layout and illustration — and is handed the task of illustrating an abridged edition of Bibhutibhushan Bandyopadhyay’s novel Pather Panchali, the book that will change his life.',
      svg_row('An apprenticeship in design', [
          {'n': 1, 'label': 'Joins D.J. Keymer, 1943', 'sub': 'junior visualiser at a British ad agency', 'color': '#3730a3'},
          {'n': 2, 'label': 'Designs covers for Signet Press', 'sub': 'typography, layout, illustration', 'color': '#b45309'},
          {'n': 3, 'label': 'Illustrates <i>Pather Panchali</i>', 'sub': 'the novel that would become his first film', 'color': '#166534'},
      ], edge_labels=['and', 'then'], takeaway='Years in commercial art gave him craft — and put the very story of his debut film into his hands.', accent=AC),
      bg='In 1943 Ray joined <b>D.J. Keymer</b>, a British-run advertising agency in Calcutta, working as a commercial artist, and also designed book jackets for the publisher <b>Signet Press</b>.',
      people='his employers at Keymer and Signet Press; the novelist <b>Bibhutibhushan Bandyopadhyay</b>, whose book he illustrated; fellow designers and artists.',
      what='As a <b>commercial artist and illustrator</b>, Ray honed typography and visual storytelling; commissioned to illustrate an <b>abridged edition of <i>Pather Panchali</i></b> (1928), he became captivated by its world and imagined it as a film.',
      crux='Advertising taught him <b>discipline and visual economy</b>, while the illustration job seeded the idea of his first film.',
      conseq='The intimacy he gained with Bibhutibhushan’s novel would, a decade later, become <i>Pather Panchali</i> on screen.',
      matters='Nothing was wasted — the day job that paid the bills also gave him both the craft and the story of his masterpiece.'),
]

# ==================================================================  PHASE 2 — THE SPARK
PHASE_SPARK = [
    E('filmsociety', '1947', 'Founding the Calcutta Film Society', ['IDEAS', 'RISE'],
      'Hungry for serious cinema, Ray helps found the Calcutta Film Society in 1947, screening and studying the classics of world film — Hollywood, French poetic realism and Soviet montage — and educating himself as a film-maker with no formal training, purely by watching, arguing and thinking about how great films are built.',
      svg_stack('A self-taught film education', [
          {'n': 1, 'label': 'Co-founds the Calcutta Film Society, 1947', 'sub': 'a hub for serious cinephiles', 'color': '#b45309'},
          {'n': 2, 'label': 'Studies the world classics', 'sub': 'Hollywood, French realism, Soviet montage', 'color': '#3730a3'},
          {'n': 3, 'label': 'Learns film-making by watching', 'sub': 'no film school; pure self-instruction', 'color': '#166534'},
      ], takeaway='He built his own film school out of a projector and a hunger to understand how cinema works.', accent=AC),
      bg='In 1947 Ray, with friends including <b>Chidananda Dasgupta</b>, founded the <b>Calcutta Film Society</b>, one of India’s first, to screen and discuss the masterworks of world cinema.',
      people='co-founder <b>Chidananda Dasgupta</b>; the visiting film-makers and critics the society drew; the directors whose films he studied.',
      what='Through the <b>Calcutta Film Society</b> Ray watched and dissected the classics of European, American and Soviet cinema, developing a critical understanding of technique without ever attending a film school.',
      crux='He taught himself the grammar of cinema by <b>close study of the masters</b> — a scholar’s route into a director’s craft.',
      conseq='The habits of analysis he formed there prepared him to make a wholly original film on his very first attempt.',
      matters='Mastery can be self-made — Ray shows that rigorous study of great work can substitute for formal training.'),

    E('renoir', '1949', 'Meeting Jean Renoir', ['TURNING POINT', 'PEOPLE'],
      'When the French master Jean Renoir comes to Bengal in 1949 to shoot The River, Ray seeks him out and helps him scout locations — and Renoir, hearing the young man’s dream of filming Pather Panchali, encourages him warmly, a benediction from one of the world’s great directors that gives Ray the courage to begin.',
      svg_row('A master’s encouragement', [
          {'n': 1, 'label': 'Renoir shoots <i>The River</i> in Bengal, 1949', 'sub': 'the great French director on location', 'color': '#3730a3'},
          {'n': 2, 'label': 'Ray helps scout locations', 'sub': 'and shares his dream of a first film', 'color': '#b45309'},
          {'n': 3, 'label': 'Renoir urges him on', 'sub': 'a blessing to make <i>Pather Panchali</i>', 'color': '#166534'},
      ], edge_labels=['where', 'so'], takeaway='A giant of world cinema told the untried young Bengali to trust his vision — and he did.', accent=AC),
      bg='In 1949 the celebrated French director <b>Jean Renoir</b> came to Bengal to film <b>The River</b>, and Ray, an admirer, contacted him and assisted in scouting rural locations.',
      people='<b>Jean Renoir</b>, son of the painter and a master of humanist cinema; Ray, still an advertising man dreaming of film.',
      what='Ray helped <b>Renoir</b> find locations for <i>The River</i> and confided his ambition to film <i>Pather Panchali</i>; Renoir <b>encouraged him strongly</b>, warning only against imitating Hollywood and urging him to trust Bengal’s own life.',
      crux='Renoir’s blessing gave Ray the <b>confidence to attempt cinema</b> — a personal endorsement from a living legend.',
      conseq='It was one of the two decisive spurs that pushed Ray from wishing to make films to actually beginning one.',
      matters='Encouragement at the right moment can launch a career — a master’s belief helped turn an amateur into a director.'),

    E('london', '1950', 'Bicycle Thieves in London', ['TURNING POINT', 'IDEAS'],
      'Sent to London by his agency in 1950, Ray gorges on cinema — some ninety-nine films in a few months — and is thunderstruck by De Sica’s Bicycle Thieves, whose austere, location-shot neorealism convinces him that a truthful, unglamorous film about ordinary Bengali life is possible; he returns home resolved to make Pather Panchali.',
      svg_stack('The film that fixed his resolve', [
          {'n': 1, 'label': 'Sent to London by Keymer, 1950', 'sub': 'watches ~99 films in a few months', 'color': '#3730a3'},
          {'n': 2, 'label': 'Sees De Sica’s <i>Bicycle Thieves</i>', 'sub': 'Italian neorealism, shot on real streets', 'color': '#b45309'},
          {'n': 3, 'label': 'Resolves to film <i>Pather Panchali</i>', 'sub': 'truthful cinema of ordinary life', 'color': '#166534'},
      ], takeaway='One neorealist masterpiece showed him the path — real places, real faces, unadorned truth.', accent=AC),
      bg='In 1950 D.J. Keymer sent Ray to its <b>London</b> headquarters; on the voyage and in the city he immersed himself in film, watching around <b>ninety-nine films</b> in a matter of months.',
      people='director <b>Vittorio De Sica</b>, whose film overwhelmed him; the Italian neorealists generally; Ray’s wife <b>Bijoya</b>, whom he had married.',
      what='In London Ray saw <b>Vittorio De Sica’s <i>Bicycle Thieves</i> (1948)</b> and was overwhelmed; its <b>location shooting, non-professional actors and unsentimental realism</b> convinced him a film about poor rural Bengal could be made his way.',
      crux='Neorealism gave him a <b>working method</b> — that cinema could be true, local and made without studios or stars.',
      conseq='He sailed home determined, and set about filming <i>Pather Panchali</i> in his spare time with an amateur crew.',
      matters='Sometimes a single film changes a life — <i>Bicycle Thieves</i> turned Ray’s ambition into a concrete plan.'),
]

# ==================================================================  PHASE 3 — THE APU TRILOGY
PHASE_APU = [
    E('pather', '1952–1955', 'Pather Panchali — a debut against the odds', ['TRIUMPH', 'TURNING POINT'],
      'Ray shoots Pather Panchali on weekends with an untrained cast and cameraman, funding it by pawning his wife’s jewels and selling his insurance until the money runs dry — then, in an unlikely rescue, the West Bengal government advances funds and the film is completed and released in 1955 to acclaim, a landmark of Indian cinema born of sheer persistence.',
      svg_row('A masterpiece scraped together', [
          {'n': 1, 'label': 'Shooting begins on weekends, 1952', 'sub': 'amateur cast; Subrata Mitra on camera', 'color': '#3730a3'},
          {'n': 2, 'label': 'Money runs out', 'sub': 'jewels pawned; insurance sold', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Bengal govt funds the finish, 1955', 'sub': 'released to acclaim as a landmark', 'color': '#166534'},
      ], edge_labels=['until', 'then'], takeaway='He willed his first film into being — poverty and setbacks could not stop it, and it changed Indian cinema.', accent=AC),
      bg='Adapting Bibhutibhushan’s novel, Ray began filming <b>Pather Panchali (Song of the Little Road)</b> in 1952 with no backing, a mostly amateur cast, and cinematographer <b>Subrata Mitra</b>, who had never shot a film.',
      people='cinematographer <b>Subrata Mitra</b>; composer <b>Ravi Shankar</b>; the child actors playing Apu and Durga; the <b>West Bengal government</b>, which rescued the project.',
      what='Ray shot the film piecemeal over three years, financing it by <b>pawning his wife’s jewellery and selling his life insurance</b>; when funds failed, the <b>West Bengal government</b> stepped in with money, and <i>Pather Panchali</i> was released in 1955.',
      crux='The film’s completion was a triumph of <b>perseverance over penury</b> — realised through faith rather than resources.',
      conseq='It won the President’s Gold and Silver Medals in India and set the stage for international recognition at Cannes.',
      matters='Great art can be made on nothing but conviction — Ray’s scraped-together debut redefined what Indian film could be.'),

    E('cannes', '1956', 'Cannes and the world takes notice', ['TRIUMPH', 'TURNING POINT'],
      'Pather Panchali travels to the Cannes Film Festival in 1956 and wins the prize for Best Human Document — thrusting a hitherto unknown Bengali director onto the world stage and announcing that a major new voice, and a serious Indian art cinema, had arrived.',
      svg_stack('Bengal’s cinema reaches the world', [
          {'n': 1, 'label': '<i>Pather Panchali</i> shown at Cannes, 1956', 'sub': 'an unknown Bengali debut', 'color': '#b45309'},
          {'n': 2, 'label': 'Wins Best Human Document', 'sub': 'the festival’s special humanist prize', 'color': '#166534'},
          {'n': 3, 'label': 'Ray becomes a world name', 'sub': 'Indian art cinema arrives internationally', 'color': '#3730a3'},
      ], takeaway='A single festival prize made a provincial debut into a global event — and Ray into a world director.', accent=AC),
      bg='In 1956 <b>Pather Panchali</b> was entered at the <b>Cannes Film Festival</b>, where its quiet realism stood apart from the era’s glossier fare.',
      people='the Cannes jury and critics; Western distributors and reviewers who championed the film; the audiences who discovered it abroad.',
      what='At Cannes the film won the award for <b>Best Human Document</b>, and Western critics hailed it; it was distributed internationally and greeted as a revelation, making <b>Ray world-famous</b>.',
      crux='Cannes certified that Ray’s intimate Bengali story had <b>universal power</b> — humanism that crossed every border.',
      conseq='International success secured backing for the two sequels that would complete the Apu Trilogy.',
      matters='Recognition abroad can transform a career at home — Cannes made Ray the face of Indian cinema to the world.'),

    E('aparajito', '1956', 'Aparajito and the Golden Lion', ['TRIUMPH', 'CRAFT'],
      'Ray follows his debut with Aparajito (The Unvanquished, 1956), tracing the boy Apu from Benares to Calcutta and the aching pull between a mother and her son’s ambition — a film that wins the Golden Lion at the Venice Film Festival and confirms that the first success was no accident.',
      svg_row('The unvanquished, honoured at Venice', [
          {'n': 1, 'label': '<i>Aparajito</i> released, 1956', 'sub': 'Apu grows up; mother and son', 'color': '#3730a3'},
          {'n': 2, 'label': 'Golden Lion at Venice', 'sub': 'the festival’s top prize', 'color': '#b45309'},
          {'n': 3, 'label': 'Ray’s stature confirmed', 'sub': 'the debut was no fluke', 'color': '#166534'},
      ], edge_labels=['wins', 'so'], takeaway='The second film took the top prize at Venice — proof that Ray was a master, not a one-film wonder.', accent=AC),
      bg='For his second feature Ray continued Apu’s story in <b>Aparajito (The Unvanquished)</b>, adapting more of Bibhutibhushan’s fiction and following the boy from a Benares childhood to student life in Calcutta.',
      people='the actors playing the adolescent Apu and his mother <b>Sarbajaya</b>; cinematographer <b>Subrata Mitra</b>; the Venice jury.',
      what='<b>Aparajito</b> (1956) portrays Apu’s coming of age and his mother’s loneliness as he leaves for the city; it won the <b>Golden Lion at the Venice Film Festival</b>, the top honour there.',
      crux='The film deepened Ray’s theme of <b>tradition versus modern aspiration</b>, told with unflinching emotional honesty.',
      conseq='Its triumph cemented Ray’s international reputation and the trilogy’s momentum toward its conclusion.',
      matters='A second masterpiece silences doubt — Venice’s highest prize placed Ray firmly among the world’s leading directors.'),

    E('apursansar', '1959', 'Apur Sansar completes the trilogy', ['TRIUMPH', 'LEGACY'],
      'With Apur Sansar (The World of Apu, 1959), Ray closes his trilogy — Apu grown, his sudden marriage, tender happiness, devastating loss and eventual reconciliation with his son — introducing the actors Soumitra Chatterjee and Sharmila Tagore and completing one of cinema’s supreme humanist achievements.',
      svg_stack('The world of Apu', [
          {'n': 1, 'label': '<i>Apur Sansar</i> released, 1959', 'sub': 'Apu as a man; marriage and grief', 'color': '#b45309'},
          {'n': 2, 'label': 'Soumitra Chatterjee debuts', 'sub': 'Ray’s greatest lead, first of many films', 'color': '#3730a3'},
          {'n': 3, 'label': 'The Apu Trilogy is complete', 'sub': 'a summit of world humanist cinema', 'color': '#166534'},
      ], takeaway='The trilogy closed with grief and grace — a life told from cradle to fatherhood, whole and unforgettable.', accent=AC),
      bg='Ray concluded Apu’s story in <b>Apur Sansar (The World of Apu, 1959)</b>, following Apu into adulthood, an unexpected marriage, the loss of his wife, and estrangement from and reunion with his son.',
      people='<b>Soumitra Chatterjee</b>, making his debut as Apu and becoming Ray’s frequent star; <b>Sharmila Tagore</b>, also debuting; composer <b>Ravi Shankar</b>.',
      what='<b>Apur Sansar</b> completed the trilogy with its most emotionally rich instalment, and launched the careers of <b>Soumitra Chatterjee</b> and <b>Sharmila Tagore</b>; together the three films form the celebrated <b>Apu Trilogy</b>.',
      crux='The trilogy traced <b>a whole human life</b> with unmatched tenderness — the work on which Ray’s fame chiefly rests.',
      conseq='The Apu Trilogy became a permanent fixture of world-cinema canons and greatest-films lists.',
      matters='Some works define a career and a national cinema at once — the Apu Trilogy did both for Ray and for India.'),
]

# ==================================================================  PHASE 4 — THE MASTER YEARS
PHASE_MASTER = [
    E('jalsaghar', '1958', 'Jalsaghar — the decaying aristocrat', ['CRAFT', 'IDEAS'],
      'Between the Apu films Ray makes Jalsaghar (The Music Room, 1958), a haunting study of a proud, ruined Bengali landlord clinging to the vanished glory of his music room — steeped in Hindustani classical music and dance, it reveals Ray’s range beyond neorealism and his deep love of India’s musical traditions.',
      svg_row('A dying world in a music room', [
          {'n': 1, 'label': '<i>Jalsaghar (The Music Room)</i>, 1958', 'sub': 'a ruined zamindar’s last pride', 'color': '#3730a3'},
          {'n': 2, 'label': 'Steeped in classical music', 'sub': 'Hindustani ragas and dance recitals', 'color': '#b45309'},
          {'n': 3, 'label': 'Ray’s range revealed', 'sub': 'mood and decay, beyond neorealism', 'color': '#166534'},
      ], edge_labels=['through', 'so'], takeaway='He showed he was no one-note realist — a lush elegy for a dying feudal world.', accent=AC),
      bg='In 1958 Ray directed <b>Jalsaghar (The Music Room)</b>, about an aging aristocrat (<b>zamindar</b>) squandering his last resources to host lavish musical soirées as his estate crumbles.',
      people='actor <b>Chhabi Biswas</b> as the landlord; the classical musicians and dancers featured; audiences who saw a new facet of Ray.',
      what='<b>Jalsaghar</b> is a mood-drenched portrait of <b>feudal decline</b>, filled with performances of Hindustani classical music and dance; it displayed Ray’s command of atmosphere and his passion for Indian music.',
      crux='The film proved Ray could master <b>evocation and decadence</b>, not just social realism — a versatile artist.',
      conseq='It became a beloved classic and foreshadowed the central place music would take in his own later scores.',
      matters='Range is the mark of a master — Ray refused to be typecast, moving from stark realism to lyrical elegy.'),

    E('teenkanya', '1961', 'Teen Kanya — Ray becomes his own composer', ['CRAFT', 'TURNING POINT'],
      'Marking Tagore’s birth centenary with Teen Kanya (Three Daughters, 1961), a set of stories adapted from Tagore, Ray for the first time composes his own musical score — thereafter writing the music for nearly all his films, making him one of the rare directors who authored image, script and music alike.',
      svg_stack('The director as composer', [
          {'n': 1, 'label': '<i>Teen Kanya</i> for Tagore’s centenary, 1961', 'sub': 'three stories adapted from Tagore', 'color': '#b45309'},
          {'n': 2, 'label': 'Ray composes his own score', 'sub': 'the first time; and from then on', 'color': '#3730a3'},
          {'n': 3, 'label': 'A total author of cinema', 'sub': 'writing image, script and music', 'color': '#166534'},
      ], takeaway='From here on he wrote his own music — a director who controlled every layer of the film.', accent=AC),
      bg='In 1961, for the centenary of <b>Rabindranath Tagore’s</b> birth, Ray made <b>Teen Kanya (Three Daughters)</b>, an anthology of Tagore short stories, and also produced a documentary on Tagore that year.',
      people='<b>Rabindranath Tagore</b>, source and honoree; the ensemble casts of the three tales; Ray himself, now composer.',
      what='With <b>Teen Kanya</b>, Ray <b>composed his own film music for the first time</b>, having previously relied on maestros like Ravi Shankar; from then on he scored nearly all his films himself.',
      crux='He took control of the <b>music as well as the image and script</b> — a near-total authorship rare among directors.',
      conseq='His self-composed scores, drawing on Indian and Western idioms, became integral to the texture of his films.',
      matters='The complete auteur writes his own music too — Ray joined the tiny company of directors who compose their scores.'),

    E('charulata', '1964', 'Charulata — his most perfect film', ['TRIUMPH', 'CRAFT'],
      'Ray reaches a peak of refinement with Charulata (The Lonely Wife, 1964), adapted from a Tagore novella about a neglected wife and her awakening feelings for her husband’s cousin — a film of exquisite subtlety that wins the Silver Bear for Best Director at Berlin and which Ray called the one film he would make again unchanged.',
      svg_row('The lonely wife, perfectly told', [
          {'n': 1, 'label': '<i>Charulata (The Lonely Wife)</i>, 1964', 'sub': 'from a Tagore novella', 'color': '#3730a3'},
          {'n': 2, 'label': 'Silver Bear at Berlin', 'sub': 'Best Director award', 'color': '#b45309'},
          {'n': 3, 'label': 'Ray’s own favourite', 'sub': 'the film he’d make again unchanged', 'color': '#166534'},
      ], edge_labels=['wins', 'and'], takeaway='Many call it his masterpiece — and Ray agreed it was the one film he’d change nothing about.', accent=AC),
      bg='In 1964 Ray directed <b>Charulata (The Lonely Wife)</b>, based on <b>Tagore’s</b> novella <i>Nastanirh</i>, set in an 1870s Calcutta household of the intellectual Bengali gentry.',
      people='<b>Madhabi Mukherjee</b> as Charulata; <b>Soumitra Chatterjee</b> as her husband’s cousin Amal; the Berlin festival jury.',
      what='<b>Charulata</b> depicts a lonely, gifted wife drawn to her husband’s literary cousin; celebrated for its exquisite restraint, it won Ray the <b>Silver Bear for Best Director at the Berlin Film Festival</b>, and he named it his most flawless work.',
      crux='It marks the summit of Ray’s <b>subtlety and psychological delicacy</b> — feeling conveyed by glance and gesture.',
      conseq='Widely regarded as among his finest films, it reinforced his standing at the very front rank of directors.',
      matters='The height of an art is often quietness — <i>Charulata</i> shows Ray saying most by showing least.'),

    E('goopy', '1969', 'Goopy Gyne Bagha Byne — the beloved fantasy', ['TRIUMPH', 'LEGACY'],
      'Ray delights a whole generation with Goopy Gyne Bagha Byne (1969), a musical fantasy — from a story by his own grandfather Upendrakishore — about two hapless musicians granted magical powers by the King of Ghosts, a huge popular hit that shows his gift for children’s cinema, comedy and song.',
      svg_stack('Magic, music and mischief', [
          {'n': 1, 'label': '<i>Goopy Gyne Bagha Byne</i>, 1969', 'sub': 'from Upendrakishore’s own tale', 'color': '#b45309'},
          {'n': 2, 'label': 'A musical fantasy for all ages', 'sub': 'ghosts, boons, song and comedy', 'color': '#3730a3'},
          {'n': 3, 'label': 'A huge popular hit', 'sub': 'beloved by Bengali audiences for decades', 'color': '#166534'},
      ], takeaway='The auteur of high art also made pure joy — a fantasy adored by children and grown-ups alike.', accent=AC),
      bg='In 1969 Ray made <b>Goopy Gyne Bagha Byne</b>, a musical fantasy-adventure based on a story by his grandfather <b>Upendrakishore Ray Chowdhury</b>, about a singer and a drummer blessed by the King of Ghosts.',
      people='his grandfather <b>Upendrakishore</b>, the original author; actors <b>Tapen Chatterjee</b> and <b>Rabi Ghosh</b>; Bengali child audiences.',
      what='<b>Goopy Gyne Bagha Byne</b> follows two exiled musicians granted three magical boons; a comic, tuneful fantasy Ray scripted, scored and directed, it was one of his <b>greatest commercial successes</b> and spawned sequels.',
      crux='The film reveals Ray’s <b>warmth and playfulness</b> — a serious artist equally at home in delight and whimsy.',
      conseq='It became a perennial Bengali favourite and confirmed his mastery of popular as well as art cinema.',
      matters='Great directors need not be solemn — Ray’s fantasy proved that depth and pure entertainment can coexist.'),

    E('calcutta', '1970–1975', 'The Calcutta trilogy — a city in crisis', ['IDEAS', 'REFORM'],
      'As Bengal seethes with unemployment and radical Naxalite unrest, Ray turns his gaze on his own troubled city in a loose Calcutta trilogy — Pratidwandi, Seemabaddha and Jana Aranya — dissecting the moral compromises of young men navigating a corrupt, jobless urban India with a sharper, more political edge than before.',
      svg_row('The auteur turns to the modern city', [
          {'n': 1, 'label': '<i>Pratidwandi</i>, 1970', 'sub': 'a jobless graduate’s disillusion', 'color': '#3730a3'},
          {'n': 2, 'label': '<i>Seemabaddha</i>, 1971', 'sub': 'corporate ambition and its costs', 'color': '#b45309'},
          {'n': 3, 'label': '<i>Jana Aranya</i>, 1975', 'sub': 'the middleman and moral surrender', 'color': '#b91c1c'},
      ], edge_labels=['then', 'then'], takeaway='He confronted his own city’s crisis — three sharp films on ambition and compromise in a decaying Calcutta.', accent=AC),
      bg='Around 1970–75, amid economic distress and <b>Naxalite</b> political turmoil in West Bengal, Ray made three films set in contemporary <b>Calcutta</b>, now known as his <b>Calcutta trilogy</b>.',
      people='the young actors playing his disillusioned protagonists; the restless urban Bengal of the era; his star <b>Soumitra Chatterjee</b> and others.',
      what='<b>Pratidwandi (1970), Seemabaddha (1971)</b> and <b>Jana Aranya (1975)</b> examine unemployment, corporate life and corruption through young men making moral compromises — Ray’s most overtly <b>political and contemporary</b> work.',
      crux='He engaged directly with <b>modern urban decay and moral drift</b>, a harsher register than his rural lyricism.',
      conseq='The trilogy showed Ray evolving with his times, unafraid to indict the society around him.',
      matters='A great artist keeps changing — Ray answered his era’s upheaval with a searching cinema of the modern city.'),

    E('feluda', '1974', 'Feluda and the storyteller’s many gifts', ['CRAFT', 'LEGACY'],
      'Beyond his art films, Ray is a prodigious writer — creator of the detective Feluda and the scientist Professor Shonku, editor of the children’s magazine Sandesh — and he brings Feluda to the screen in Sonar Kella (1974) and Joi Baba Felunath (1978), delighting audiences and proving himself a complete man of Bengali letters as well as film.',
      svg_stack('The complete Bengali storyteller', [
          {'n': 1, 'label': 'Creates the detective Feluda', 'sub': 'and Professor Shonku; revives <i>Sandesh</i>', 'color': '#b45309'},
          {'n': 2, 'label': '<i>Sonar Kella</i>, 1974', 'sub': 'Feluda’s first film adventure', 'color': '#3730a3'},
          {'n': 3, 'label': '<i>Joi Baba Felunath</i>, 1978', 'sub': 'the sleuth returns; a popular hit', 'color': '#166534'},
      ], takeaway='Director, composer, writer, illustrator — Ray was a one-man Bengali cultural institution.', accent=AC),
      bg='Alongside film-making, Ray was a celebrated <b>writer and illustrator</b>, reviving his family’s children’s magazine <i>Sandesh</i> and creating hugely popular characters in Bengali fiction.',
      people='his detective <b>Feluda (Pradosh Mitter)</b>; the scientist <b>Professor Shonku</b>; actor <b>Soumitra Chatterjee</b>, who played Feluda on screen.',
      what='Ray created the sleuth <b>Feluda</b> and the inventor <b>Professor Shonku</b> in his fiction, and filmed Feluda mysteries in <b>Sonar Kella (The Golden Fortress, 1974)</b> and <b>Joi Baba Felunath (1978)</b>, both much loved.',
      crux='He was a <b>total author of Bengali culture</b> — his stories and films fed one another across decades.',
      conseq='His fiction and films for the young shaped generations of Bengali readers and viewers.',
      matters='The greatest creators overflow their form — Ray was as central to Bengali literature as to its cinema.'),
]

# ==================================================================  PHASE 5 — HONORS, THE OSCAR, AND LEGACY
PHASE_LEGACY = [
    E('shatranj', '1977', 'Shatranj ke Khilari — his one Hindi feature', ['CRAFT', 'IDEAS'],
      'Ray steps outside Bengali for the first time with Shatranj ke Khilari (The Chess Players, 1977), a Hindi/Urdu film from a Premchand story in which two Lucknow noblemen play chess while the British annex their kingdom in 1856 — an elegant parable of a decadent aristocracy fiddling as its world is taken from it.',
      svg_row('Chess while a kingdom falls', [
          {'n': 1, 'label': '<i>Shatranj ke Khilari</i>, 1977', 'sub': 'his only Hindi/Urdu feature', 'color': '#3730a3'},
          {'n': 2, 'label': 'From a Premchand story', 'sub': 'Lucknow noblemen at their chessboard', 'color': '#b45309'},
          {'n': 3, 'label': 'A kingdom annexed, 1856', 'sub': 'Awadh falls to the British as they play', 'color': '#b91c1c'},
      ], edge_labels=['from', 'while'], takeaway='A sly parable of decadence — noblemen absorbed in a game as the empire swallows their state.', accent=AC),
      bg='In 1977 Ray made <b>Shatranj ke Khilari (The Chess Players)</b>, his first feature in <b>Hindi/Urdu</b>, adapting a story by <b>Premchand</b> and set in <b>Awadh (Oudh) in 1856</b> on the eve of British annexation.',
      people='novelist <b>Premchand</b>, the source; stars <b>Sanjeev Kumar</b>, <b>Saeed Jaffrey</b> and <b>Richard Attenborough</b> as the British general; a wider Hindi-film audience.',
      what='<b>Shatranj ke Khilari</b> follows two Lucknow aristocrats so absorbed in chess that they ignore the <b>British takeover of their kingdom</b> — a witty, melancholy allegory of a passive elite, and Ray’s only Hindi-language feature.',
      crux='The film distils Ray’s recurring theme of a <b>decadent old order</b> oblivious to the forces sweeping it away.',
      conseq='It broadened his reach beyond Bengal and stands among his most admired historical films.',
      matters='A master can work in any language — Ray’s single Hindi film is a jewel of ironic historical cinema.'),

    E('honors', '1978–1992', 'A garland of world honors', ['TRIUMPH', 'LEGACY'],
      'Honors accumulate around Ray from every quarter — a special award at Berlin, France’s Legion of Honour, an honorary doctorate from Oxford (only the second film-maker so honoured after Chaplin), India’s Dadasaheb Phalke Award in 1984 — recognition of a body of work admired by directors and critics across the world.',
      svg_stack('The world honors a master', [
          {'n': 1, 'label': 'Oxford honorary doctorate, 1978', 'sub': 'only the 2nd film-maker after Chaplin', 'color': '#b45309'},
          {'n': 2, 'label': 'France’s Legion of Honour', 'sub': 'and a special Berlin award', 'color': '#3730a3'},
          {'n': 3, 'label': 'Dadasaheb Phalke Award, 1984', 'sub': 'India’s highest cinema honour', 'color': '#166534'},
      ], takeaway='Honors poured in from every direction — Ray was revered by peers and institutions across the globe.', accent=AC),
      bg='From the late 1970s Ray was showered with the highest honors in world cinema and letters, his influence acknowledged by directors including <b>Akira Kurosawa</b> and <b>Martin Scorsese</b>.',
      people='<b>Akira Kurosawa</b>, who praised him lavishly; the University of <b>Oxford</b>; the French state; India’s film establishment.',
      what='Ray received an <b>honorary doctorate from Oxford (1978)</b> — the second film-maker so honoured after Chaplin — the <b>French Legion of Honour</b>, a special <b>Berlin</b> award, and India’s <b>Dadasaheb Phalke Award (1984)</b>.',
      crux='The tributes reflected a rare consensus that Ray was among the <b>greatest directors in the history of the medium</b>.',
      conseq='This standing set the stage for the ultimate international tribute at the very end of his life.',
      matters='Reputation was global and unanimous — Ray was one of the handful of directors revered everywhere films are studied.'),

    E('oscar', '1992', 'The honorary Oscar from a sickbed', ['TRIUMPH', 'DEATH'],
      'In 1992, gravely ill with heart disease, Ray is awarded an honorary Academy Award for his lifetime achievement — and, too weak to travel, accepts it in a moving filmed message from his Calcutta hospital bed, calling the cinema of Hollywood a formative influence; weeks later India confers its highest civilian honour, the Bharat Ratna.',
      svg_row('A lifetime crowned at the last', [
          {'n': 1, 'label': 'Honorary Academy Award, 1992', 'sub': 'for lifetime achievement in film', 'color': '#b45309'},
          {'n': 2, 'label': 'Accepts from his hospital bed', 'sub': 'a filmed message from Calcutta', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Awarded the Bharat Ratna', 'sub': 'India’s highest civilian honour', 'color': '#166534'},
      ], edge_labels=['and', 'and'], takeaway='The world’s top film honour reached him just in time — accepted with grace from a sickbed.', accent=AC),
      bg='By 1992 Ray was seriously ill with heart trouble; that year the <b>Academy of Motion Picture Arts and Sciences</b> voted him an <b>Honorary Award</b> for his lifetime of work.',
      people='the Academy; actress <b>Audrey Hepburn</b>, who introduced the tribute; the Indian government, which awarded the <b>Bharat Ratna</b>.',
      what='Too frail to attend, Ray accepted the <b>honorary Oscar</b> in a filmed message from his <b>hospital bed in Calcutta</b>, thanking the American cinema that had shaped him; India also awarded him the <b>Bharat Ratna</b>, its highest civilian honour, in 1992.',
      crux='The tributes recognised a <b>lifetime of unmatched achievement</b>, arriving at the very close of his life.',
      conseq='He died within weeks of receiving these final, crowning honors.',
      matters='A career was sealed at the end by its highest tributes — Ray’s Oscar is among the most moving in the award’s history.'),

    E('death', '1992', 'Death and an undimmed legacy', ['DEATH', 'LEGACY'],
      'Satyajit Ray dies in Calcutta on 23 April 1992, aged seventy — mourned as the giant who carried Indian cinema to the world — leaving some thirty-six films, a shelf of beloved fiction, and an influence, acknowledged by Kurosawa and Scorsese alike, that endures as one of the towering bodies of work in world cinema.',
      svg_stack('The giant of Indian cinema', [
          {'n': 1, 'label': 'Dies in Calcutta, 23 April 1992', 'sub': 'aged 70, weeks after the Oscar', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Some 36 films and much fiction', 'sub': 'the Apu Trilogy, Charulata, Feluda', 'color': '#b45309'},
          {'n': 3, 'label': 'A permanent world influence', 'sub': 'revered by Kurosawa and Scorsese', 'color': '#166534'},
      ], takeaway='He died a national and world icon — the man who made Indian cinema matter to the whole world.', accent=AC),
      bg='<b>Satyajit Ray</b> died in Calcutta on <b>23 April 1992</b>, aged 70, after prolonged heart illness; his death was mourned across India as the loss of a national treasure.',
      people='the directors he influenced (<b>Kurosawa</b>, <b>Scorsese</b>, <b>Wes Anderson</b> and others); the Bengali public; generations of film-makers and readers worldwide.',
      what='Ray left roughly <b>36 films</b> — including the <b>Apu Trilogy, Jalsaghar, Charulata</b> and the Feluda mysteries — plus a large body of fiction; <b>Akira Kurosawa</b> said not to have seen his films was to live without the sun or moon.',
      crux='His legacy is a <b>complete and coherent body of work</b> — humane, precise, and unmistakably his own.',
      conseq='He is enshrined among the greatest directors in the history of cinema and the founder of a serious Indian art film.',
      matters='Some artists define their medium in their country — Ray made Indian cinema a permanent part of world film.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Satyajit Ray was the Bengali film-maker who carried Indian cinema onto the world stage and stands among the greatest directors in the history of the medium. Born into Bengal’s most artistic family and trained as a painter and commercial illustrator, he taught himself cinema through a film society — then, spurred by meeting Jean Renoir and seeing <i>Bicycle Thieves</i>, scraped together his debut <i>Pather Panchali</i> against crushing odds. The Apu Trilogy, <i>Charulata</i>, the Calcutta films and the beloved Feluda stories followed, crowned at the last by an honorary Oscar accepted from his sickbed. He is the ultimate study in <b>the complete artist — image, script and music mastered as one.</b></p>
<div class="ov-quote">“Not to have seen the cinema of Ray means existing in the world without seeing the sun or the moon.”<span>— Akira Kurosawa on Satyajit Ray</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born to Bengal’s great artistic family and trained as a painter at Santiniketan → learns cinema through a film society, Renoir’s encouragement and <i>Bicycle Thieves</i> → wills <i>Pather Panchali</i> into being and wins Cannes → completes the Apu Trilogy and reaches perfection with <i>Charulata</i> → becomes his own composer and a total author of image, script and music → and dies in 1992 as a world icon, an honorary Oscar and the Bharat Ratna his final honors.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🎬</div><h4>Complete auteur</h4><p>Directed, wrote and composed — controlling every layer of his films.</p></div>
  <div class="ov-card"><div class="i">🌍</div><h4>Cinema to the world</h4><p>Made Indian film a permanent part of the world-cinema canon.</p></div>
  <div class="ov-card"><div class="i">💛</div><h4>Humanist eye</h4><p>Tender, precise portraits of ordinary Bengali life and feeling.</p></div>
  <div class="ov-card"><div class="i">✍️</div><h4>A cultural institution</h4><p>Detective Feluda, Professor Shonku, and a shelf of beloved fiction.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Lineage</b><small> 1921–1943</small><p>A family of artists, Santiniketan, and the commercial-art years.</p></div>
  <div><b>2 · The Spark</b><small> 1947–1950</small><p>The film society, Renoir, and <i>Bicycle Thieves</i>.</p></div>
  <div><b>3 · The Apu Trilogy</b><small> 1952–1959</small><p><i>Pather Panchali</i>, Cannes, Venice, and Apu’s whole life.</p></div>
  <div><b>4 · The Master Years</b><small> 1958–1975</small><p><i>Charulata</i>, self-composed scores, fantasy, and the city.</p></div>
  <div><b>5 · Honors &amp; Legacy</b><small> 1977–1992</small><p>The Chess Players, world honors, the Oscar, and death.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Soumitra Chatterjee', 'role': 'his leading actor', 'color': '#b45309',
     'bio': 'Ray’s favourite leading man, who debuted as the adult Apu in Apur Sansar (1959) and starred in some fourteen of his films, from Charulata to the Feluda mysteries.',
     'rel': 'The actor most identified with Ray’s cinema.'},
    {'name': 'Jean Renoir', 'role': 'mentor-inspiration', 'color': '#3730a3',
     'bio': 'The great French director who, filming The River in Bengal in 1949, encouraged the young Ray to trust his vision and make Pather Panchali.',
     'rel': 'The master whose blessing spurred Ray to begin.'},
    {'name': 'Rabindranath Tagore', 'role': 'formative influence', 'color': '#166534',
     'bio': 'The Nobel poet whose Santiniketan university trained Ray as an artist and whose stories Ray adapted in Teen Kanya, Charulata and more.',
     'rel': 'The presiding spirit over Ray’s art and many films.'},
    {'name': 'Sukumar & Upendrakishore Ray', 'role': 'father & grandfather', 'color': '#a16207',
     'bio': 'Satyajit’s father, the nonsense-verse master, and grandfather, pioneer of children’s publishing — the artistic lineage he inherited and drew on (Goopy Gyne Bagha Byne).',
     'rel': 'The creative forebears whose legacy he carried into film.'},
    {'name': 'Subrata Mitra', 'role': 'cinematographer', 'color': '#7c3aed',
     'bio': 'The gifted cameraman who shot Pather Panchali as his first film and pioneered techniques like bounce lighting across Ray’s early work.',
     'rel': 'The eye behind Ray’s celebrated early images.'},
]

KEY_EVENTS = [
    ('1921', 'Ray born in Calcutta', 'Into Bengal’s great artistic family.'),
    ('1940', 'Studies at Santiniketan', 'Fine art under Tagore’s university.'),
    ('1943', 'Commercial artist at Keymer', 'And Signet Press book covers.'),
    ('1949', 'Meets Jean Renoir', 'Encouraged to make his first film.'),
    ('1950', 'Sees Bicycle Thieves in London', 'Resolves to film Pather Panchali.'),
    ('1955', 'Pather Panchali released', 'A landmark; Bengal govt funds it.'),
    ('1956', 'Cannes Best Human Document', 'Ray becomes a world name.'),
    ('1956', 'Aparajito wins Venice', 'The Golden Lion for the sequel.'),
    ('1959', 'Apur Sansar', 'Completes the Apu Trilogy.'),
    ('1961', 'Teen Kanya', 'Ray first composes his own music.'),
    ('1964', 'Charulata', 'Silver Bear at Berlin; his own favourite.'),
    ('1969', 'Goopy Gyne Bagha Byne', 'A beloved musical fantasy hit.'),
    ('1977', 'Shatranj ke Khilari', 'His only Hindi feature.'),
    ('1992', 'Honorary Oscar & Bharat Ratna', 'Accepted from his sickbed.'),
    ('1992', 'Ray dies in Calcutta', 'Aged 70; a world icon.'),
]

MASTER = [
    {'year': '1921', 'age': 'born', 'phase': 'Lineage', 'title': 'Born in Calcutta', 'desc': 'Bengal’s great artistic family.'},
    {'year': '1940', 'age': 'age 19', 'phase': 'Lineage', 'title': 'Santiniketan', 'desc': 'Trained as an artist under Tagore.'},
    {'year': '1950', 'age': 'age 29', 'phase': 'The Spark', 'title': 'Bicycle Thieves', 'desc': 'Resolves to make films.'},
    {'year': '1955', 'age': 'age 34', 'phase': 'Apu Trilogy', 'title': 'Pather Panchali', 'desc': 'A landmark debut against the odds.'},
    {'year': '1956', 'age': 'age 35', 'phase': 'Apu Trilogy', 'title': 'Cannes & Venice', 'desc': 'A world reputation is born.'},
    {'year': '1964', 'age': 'age 43', 'phase': 'Master Years', 'title': 'Charulata', 'desc': 'The summit of his art.'},
    {'year': '1969', 'age': 'age 48', 'phase': 'Master Years', 'title': 'Goopy Gyne Bagha Byne', 'desc': 'A beloved popular hit.'},
    {'year': '1977', 'age': 'age 56', 'phase': 'Honors', 'title': 'Shatranj ke Khilari', 'desc': 'His one Hindi feature.'},
    {'year': '1992', 'age': 'age 70', 'phase': 'Legacy', 'title': 'Oscar, then death', 'desc': 'Honored at the last; dies a world icon.'},
]

SOURCES = [
    ('Britannica — Satyajit Ray', 'https://www.britannica.com/biography/Satyajit-Ray'),
    ('Wikipedia — Satyajit Ray', 'https://en.wikipedia.org/wiki/Satyajit_Ray'),
    ('Wikipedia — Pather Panchali', 'https://en.wikipedia.org/wiki/Pather_Panchali'),
    ('Wikipedia — The Apu Trilogy', 'https://en.wikipedia.org/wiki/The_Apu_Trilogy'),
    ('New World Encyclopedia — Satyajit Ray', 'https://www.newworldencyclopedia.org/entry/Satyajit_Ray'),
    ('TCM — Satyajit Ray', 'https://www.tcm.com/articles/featured-directors/022055/satyajit-ray'),
]

def build_meta():
    return {
        'pid': 'gm-satyajitray.html', 'kind': 'man', 'emoji': '🎬', 'accent': AC,
        'name': 'Satyajit Ray', 'years': '1921–1992', 'group': 'Artists & Filmmakers',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Bengali auteur whose Apu Trilogy and Charulata carried Indian cinema onto the world stage — a complete artist who directed, wrote and composed his films, crowned at the last by an honorary Academy Award.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'roots', 'label': '1 · Lineage', 'type': 'timeline',
             'intro': 'Born into Bengal’s most artistic family and trained as a painter at Tagore’s Santiniketan, Ray masters typography and illustration in the world of commercial art.', 'events': PHASE_ROOTS},
            {'id': 'spark', 'label': '2 · The Spark', 'type': 'timeline',
             'intro': 'A self-taught cinephile, Ray is set on his path by a film society, the encouragement of Jean Renoir, and the shock of De Sica’s <i>Bicycle Thieves</i>.', 'events': PHASE_SPARK},
            {'id': 'apu', 'label': '3 · The Apu Trilogy', 'type': 'timeline',
             'intro': 'Against crushing odds he wills <i>Pather Panchali</i> into being, wins Cannes and Venice, and completes one of cinema’s supreme humanist achievements.', 'events': PHASE_APU},
            {'id': 'master', 'label': '4 · The Master Years', 'type': 'timeline',
             'intro': 'From <i>Jalsaghar</i> to <i>Charulata</i>, from his own musical scores to fantasy and the troubled modern city, Ray becomes a total author of cinema.', 'events': PHASE_MASTER},
            {'id': 'legacy', 'label': '5 · Honors & Legacy', 'type': 'timeline',
             'intro': 'His one Hindi film, a garland of world honors, an honorary Oscar accepted from his sickbed, and a death mourned as the loss of a giant of world cinema.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; film dates follow standard filmographies of Ray’s work.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
