# -*- coding: utf-8 -*-
"""Full, DEEP guide content for J.R.D. Tata.
The French-born aviator and industrialist who built modern Indian aviation and led the Tata Group for over half a century."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#0e7490'  # aviation teal-blue

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — A FRENCH-BORN PARSI
PHASE_ORIGINS = [
    E('birth', '1904', 'Born in Paris to a Parsi father and a French mother', ['RISE', 'ORIGINS'],
      'Jehangir Ratanji Dadabhoy Tata is born on 29 July 1904 in Paris — the second child of the Parsi industrialist Ratanji Dadabhoy Tata, a cousin of the Tata founder Jamsetji, and his French wife Suzanne “Sooni” Brière — so that he grows up bilingual and cosmopolitan, straddling France and India from the very start.',
      svg_row('A child of two countries', [
          {'n': 1, 'label': 'Born in Paris, 29 July 1904', 'sub': 'second child of R.D. Tata and Suzanne Brière', 'color': '#0e7490'},
          {'n': 2, 'label': 'A Parsi–French heritage', 'sub': 'the Tata industrial family of Bombay', 'color': '#3730a3'},
          {'n': 3, 'label': 'Raised bilingual and cosmopolitan', 'sub': 'schooled largely in France', 'color': '#166534'},
      ], edge_labels=['into', 'so'], takeaway='He was European by birth and Indian by lineage — a dual identity that shaped a uniquely worldly industrialist.', accent=AC),
      bg='<b>Jehangir Ratanji Dadabhoy Tata</b> was born on <b>29 July 1904 in Paris</b> to <b>Ratanji Dadabhoy Tata</b>, a Parsi partner in the House of Tata, and his French wife <b>Suzanne “Sooni” Brière</b>.',
      people='his father <b>R.D. Tata</b>, cousin and partner of founder <b>Jamsetji Tata</b>; his French mother <b>Suzanne Brière</b>; the wider Tata family of Bombay.',
      what='He spent much of his childhood in <b>France</b>, growing up <b>bilingual in French and English</b> and steeped in European culture, while remaining heir to one of India’s great business houses.',
      crux='His formation was <b>genuinely transnational</b> — he belonged fully to neither France nor India, but drew on both.',
      conseq='This cosmopolitan upbringing gave him a lifelong outward-looking outlook and a love of France, aviation and modernity.',
      matters='Identity shapes vision — a man raised between two worlds would later insist that India measure itself by world standards.'),

    E('france', '1918–1925', 'A French education and the pull of flight', ['RISE', 'ORIGINS'],
      'Young Jehangir is schooled in France and even serves a stint in the French army — but the death of his mother and his father’s wish draw him back toward the family business, while a boyhood among the pioneers of French aviation, near the aviator Louis Blériot, plants a passion for flying that will define his life.',
      svg_stack('The making of an aviator', [
          {'n': 1, 'label': 'Educated in France', 'sub': 'a brief spell in the French army', 'color': '#3730a3'},
          {'n': 2, 'label': 'Boyhood among French aviators', 'sub': 'neighbours of the pioneer Louis Blériot', 'color': '#0e7490'},
          {'n': 3, 'label': 'A lifelong passion for flight', 'sub': 'the dream that would shape his career', 'color': '#166534'},
      ], takeaway='Before he was ever an industrialist, he was a boy in love with aeroplanes — a passion he would turn into a national airline.', accent=AC),
      bg='Educated largely in <b>France</b>, the young Tata absorbed French culture and, as a young man, served briefly in the <b>French army</b>.',
      people='his father <b>R.D. Tata</b>, who steered him toward the business; the French aviation pioneers, including <b>Louis Blériot</b>, near whom the family lived.',
      what='His mother’s early death and his father’s wishes pulled him toward the family firm, but a <b>childhood fascination with the pioneers of French aviation</b> gave him a passion for flying that never left him.',
      crux='Two threads ran through his youth — <b>duty to the Tata business and a dream of flight</b> — and he would spend his life weaving them together.',
      conseq='He returned to India carrying both a sense of dynastic responsibility and an ambition to fly.',
      matters='Great enterprises often begin as boyhood passions — his love of aeroplanes would become India’s first airline.'),

    E('licence', '1929', 'India’s first licensed pilot — licence No. 1', ['TRIUMPH', 'TURNING POINT'],
      'On 10 February 1929 Jehangir Tata earns the very first pilot’s licence issued in India — flying licence No. 1 — becoming the country’s first legally qualified aviator, a distinction he treasured above almost any other honour in a long life full of them.',
      svg_row('The first Indian to hold a pilot’s licence', [
          {'n': 1, 'label': 'Trains at the Bombay Flying Club', 'sub': 'a young man determined to fly', 'color': '#3730a3'},
          {'n': 2, 'label': 'Qualifies on 10 February 1929', 'sub': 'India’s first-ever pilot’s licence', 'color': '#0e7490'},
          {'n': 3, 'label': 'Holder of “Licence No. 1”', 'sub': 'the nation’s first legal aviator', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='He literally held India’s first pilot licence — the credential that opened the door to Indian civil aviation.', accent=AC),
      bg='Aviation was in its infancy in India when Tata, an enthusiast, pursued formal flight training in Bombay.',
      people='the instructors of the <b>Bombay Flying Club</b>; fellow early aviators; a young J.R.D. Tata himself.',
      what='On <b>10 February 1929</b> he was awarded the <b>first pilot’s licence ever issued in India</b> — flying licence <b>No. 1</b> — making him the country’s first officially qualified pilot.',
      crux='The licence was more than a personal triumph — it made him the <b>living embodiment of Indian aviation</b> at its birth.',
      conseq='Three years later he would use his flying skill to launch the airline that became Air India.',
      matters='Firsts carry symbolic power — the man with licence No. 1 was uniquely placed to give India its wings.'),
]

# ==================================================================  PHASE 2 — WINGS FOR A NATION
PHASE_WINGS = [
    E('tataairlines', '1932', 'Founding Tata Aviation Service', ['RISE', 'BUSINESS'],
      'In 1932 J.R.D. Tata launches Tata Aviation Service — soon Tata Airlines — winning a contract to fly airmail for Imperial Airways along the west coast, and founding, on a shoestring of two single-engined aircraft and a mud-hut hangar at Juhu, what would become India’s first great airline.',
      svg_stack('India’s first airline is born', [
          {'n': 1, 'label': 'Tata Aviation Service, 1932', 'sub': 'a division of Tata Sons', 'color': '#0e7490'},
          {'n': 2, 'label': 'An airmail contract secured', 'sub': 'carrying mail along the west coast', 'color': '#3730a3'},
          {'n': 3, 'label': 'Two Puss Moths, a Juhu hangar', 'sub': 'a tiny start with vast ambition', 'color': '#166534'},
      ], takeaway='He turned a personal passion into an enterprise — India’s first airline, begun with barely two aircraft.', accent=AC),
      bg='By the early 1930s airmail offered a commercial opening; Tata persuaded the family firm to back a modest aviation venture.',
      people='J.R.D. Tata, founder and pilot; his fellow aviator <b>Nevill Vintcent</b>, co-planner of the airline; <b>Tata Sons</b>, the parent house.',
      what='In <b>1932</b> he founded <b>Tata Aviation Service</b> (later <b>Tata Airlines</b>) as a division of Tata Sons, winning a contract to carry <b>airmail</b> for Imperial Airways between Karachi and Madras via Bombay.',
      crux='The airline began <b>tiny and precarious</b> — a handful of aircraft and a shed at Juhu — but rested on a clear commercial idea.',
      conseq='It grew steadily through the 1930s into a passenger carrier and, later, into Air India.',
      matters='Big institutions start small — India’s national aviation industry began with one enthusiast and two light aircraft.'),

    E('firstflight', '1932', 'The first flight — Karachi to Bombay with the mail', ['TRIUMPH', 'AVIATION'],
      'On 15 October 1932 J.R.D. Tata himself pilots the airline’s inaugural flight — a de Havilland Puss Moth carrying airmail from Karachi to Bombay’s Juhu aerodrome — personally inaugurating scheduled commercial aviation in India and beginning a service famed for its punctuality.',
      svg_row('The pilot who launched an industry', [
          {'n': 1, 'label': 'Karachi, 15 October 1932', 'sub': 'J.R.D. Tata at the controls', 'color': '#0e7490'},
          {'n': 2, 'label': 'A Puss Moth laden with mail', 'sub': 'via Ahmedabad to Bombay’s Juhu', 'color': '#3730a3'},
          {'n': 3, 'label': 'India’s first scheduled flight', 'sub': 'a service built on punctuality', 'color': '#b45309'},
      ], edge_labels=['carrying', 'so'], takeaway='He did not just found the airline — he flew its first flight himself, inaugurating Indian commercial aviation.', accent=AC),
      bg='With the airmail contract in hand, the young airline prepared its inaugural run up the west coast of India.',
      people='J.R.D. Tata, the pilot; his colleague <b>Nevill Vintcent</b>, who flew other legs; the ground crew at Juhu.',
      what='On <b>15 October 1932</b> Tata personally piloted a <b>de Havilland Puss Moth</b> carrying <b>mail from Karachi to Bombay</b> (via Ahmedabad), inaugurating <b>India’s first scheduled commercial air service</b>.',
      crux='The flight fused the man and the mission — the <b>owner-pilot flying his own airline’s first sortie</b>, on time to the minute.',
      conseq='The route prospered; within years Tata Airlines carried passengers as well as post and became the country’s premier carrier.',
      matters='Symbolic acts endure — an industrialist flying his own first mail run became the founding legend of Indian aviation.'),

    E('growth', '1933–1945', 'Building a punctual, professional airline', ['RISE', 'BUSINESS'],
      'Through the 1930s and the war years Tata Airlines grows from an airmail runner into a passenger carrier renowned for reliability — Tata famously chalking flight timings to the minute and inspecting aircraft himself — so that by the mid-1940s it is India’s most respected airline, poised to become a national flag carrier.',
      svg_stack('From mail runner to premier carrier', [
          {'n': 1, 'label': 'Airmail becomes passengers', 'sub': 'new routes across British India', 'color': '#0e7490'},
          {'n': 2, 'label': 'A cult of punctuality', 'sub': 'timings kept to the minute', 'color': '#3730a3'},
          {'n': 3, 'label': 'India’s most trusted airline', 'sub': 'a reputation for safety and service', 'color': '#166534'},
      ], takeaway='He built the airline on obsessive attention to detail — punctuality and safety became its hallmark and his creed.', accent=AC),
      bg='Having proved the airmail service, Tata expanded the airline’s routes and fleet through the 1930s and the Second World War.',
      people='J.R.D. Tata, hands-on chief; <b>Nevill Vintcent</b>, his aviation partner; the pilots and engineers he mentored.',
      what='Tata Airlines added <b>passenger routes and larger aircraft</b>, and Tata drove a famous obsession with <b>punctuality, safety and detail</b> — personally checking timings and cleanliness — making it India’s most admired airline.',
      crux='He treated the airline as a <b>standard-bearer</b> — proof that an Indian enterprise could match the best in the world for reliability.',
      conseq='By 1945 the airline was strong enough to be reconstituted as a public company, Air India.',
      matters='Excellence is built in the details — the punctuality culture he instilled became a template for Tata quality.'),
]

# ==================================================================  PHASE 3 — CHAIRMAN AT THIRTY-FOUR
PHASE_CHAIRMAN = [
    E('chairman', '1938', 'Chairman of Tata Sons at thirty-four', ['RISE', 'TURNING POINT'],
      'On the death of Nowroji Saklatvala in 1938, the thirty-four-year-old J.R.D. Tata is chosen to chair Tata Sons — becoming, at a strikingly young age, head of India’s largest business house, a position he will hold for more than half a century.',
      svg_row('The youngest head of the House of Tata', [
          {'n': 1, 'label': 'Saklatvala dies, 1938', 'sub': 'the chairmanship falls vacant', 'color': '#3730a3'},
          {'n': 2, 'label': 'J.R.D. chosen at age 34', 'sub': 'to lead Tata Sons', 'color': '#0e7490'},
          {'n': 3, 'label': 'Head of India’s largest house', 'sub': 'a reign that will last 50+ years', 'color': '#b45309'},
      ], edge_labels=['so', 'and'], takeaway='At thirty-four he took the helm of the House of Tata — beginning a chairmanship of extraordinary length and reach.', accent=AC),
      bg='The House of Tata, founded by Jamsetji Tata, was India’s foremost industrial group, spanning steel, power and more.',
      people='<b>Nowroji Saklatvala</b>, the chairman whose death opened the post; the Tata directors who chose J.R.D.; the founding legacy of <b>Jamsetji Tata</b>.',
      what='After <b>Saklatvala’s death in 1938</b>, J.R.D. Tata was elected <b>Chairman of Tata Sons at the age of 34</b>, becoming head of the country’s largest and most prestigious business group.',
      crux='A young, aviation-minded cosmopolitan now led a <b>vast, tradition-bound industrial empire</b> — an unusual and consequential match.',
      conseq='He would remain chairman for over 50 years, presiding over the group’s transformation and huge expansion.',
      matters='Leadership handed early can define an era — J.R.D.’s long tenure gave the Tata group rare continuity and vision.'),

    E('trusteeship', '1938–1950s', 'The philosophy of the trustee', ['IDEAS', 'REFORM'],
      'J.R.D. governs the group not as a personal fortune but in the spirit of trusteeship — championing enlightened labour practices pioneered at Tata Steel, insisting that business exists to serve the nation, and holding that “no success in material terms is worthwhile unless it serves the needs or interests of the country.”',
      svg_compare('Two ideas of what a business is for', {
          'head': 'J.R.D.’s trusteeship', 'color': '#0e7490',
          'items': ['Wealth held in trust for society', 'Pioneering welfare for workers', 'Business must serve the nation', 'Ethics and quality over quick profit'],
      }, {
          'head': 'The purely commercial view', 'color': '#3730a3',
          'items': ['Wealth as private reward', 'Labour as a cost to minimise', 'Business serves its owners', 'Profit as the sole measure'],
      }, verdict='He made social purpose central to Tata enterprise — a distinctively Indian idea of ethical capitalism.',
         takeaway='For him, profit was a means, not an end — the group’s wealth was to be held in trust for India.', accent=AC),
      bg='The Tata tradition, from Jamsetji onward, tied business success to national development and worker welfare.',
      people='the founder <b>Jamsetji Tata</b>, whose ideals he inherited; the workers of <b>Tata Steel at Jamshedpur</b>; his fellow directors.',
      what='J.R.D. embraced a philosophy of <b>trusteeship</b> — championing early <b>eight-hour days, leave and welfare</b> pioneered at Tata Steel — and held that enterprise must ultimately <b>serve the country</b>.',
      crux='He believed <b>industry carried a social duty</b> — that wealth was legitimate only if it advanced the nation’s good.',
      conseq='This ethos, embodied in the Tata charitable trusts, made the group a byword for ethical business in India.',
      matters='Values steer institutions — J.R.D.’s trusteeship gave the Tata name a moral authority few businesses ever earn.'),

    E('industry', '1939–1945', 'Chemicals, engineering and the industrial base', ['RISE', 'BUSINESS'],
      'Under J.R.D. the group broadens far beyond steel and power — Tata Chemicals is founded in 1939, and in 1945 the engineering firm Tata Engineering and Locomotive Company (Telco, later Tata Motors) is established to build locomotives and, in time, trucks and cars — laying the foundations of India’s heavy industry.',
      svg_stack('Widening the industrial empire', [
          {'n': 1, 'label': 'Tata Chemicals, 1939', 'sub': 'soda ash and heavy chemicals', 'color': '#0e7490'},
          {'n': 2, 'label': 'Telco founded, 1945', 'sub': 'locomotives, then trucks and cars', 'color': '#3730a3'},
          {'n': 3, 'label': 'Backbone of Indian industry', 'sub': 'steel, chemicals, engineering', 'color': '#166534'},
      ], takeaway='He pushed the group into the heavy industries a new India would need — chemicals, engineering, automobiles.', accent=AC),
      bg='As India moved toward independence and industrialisation, the Tata group expanded into new manufacturing sectors.',
      people='J.R.D. Tata and his fellow directors; the engineers who built <b>Telco</b>; India’s emerging industrial economy.',
      what='The group founded <b>Tata Chemicals (1939)</b> and, in <b>1945</b>, the <b>Tata Engineering and Locomotive Company (Telco)</b> — later renamed <b>Tata Motors</b> — to make locomotives and, later, trucks and cars.',
      crux='J.R.D. positioned Tata at the heart of the <b>heavy industry</b> a modernising, independent India would demand.',
      conseq='Telco became India’s largest automobile maker, and Tata Chemicals a major producer — pillars of the group.',
      matters='Nation-building needs industry — J.R.D. built the enterprises that would power and equip a self-reliant India.'),
]

# ==================================================================  PHASE 4 — AIR INDIA AND THE STATE
PHASE_AIRINDIA = [
    E('airindia', '1946–1948', 'Air India and Air India International', ['TRIUMPH', 'AVIATION'],
      'In 1946 Tata Airlines is reconstituted as a public company, Air India — and in 1948, in partnership with the new government, J.R.D. launches Air India International, whose Bombay-to-London flights make India one of the first nations of newly independent Asia to fly its own flag across the world.',
      svg_row('India takes to the world’s skies', [
          {'n': 1, 'label': 'Air India, 1946', 'sub': 'Tata Airlines goes public', 'color': '#0e7490'},
          {'n': 2, 'label': 'Air India International, 1948', 'sub': 'Bombay to London begins', 'color': '#3730a3'},
          {'n': 3, 'label': 'India’s flag over the world', 'sub': 'a world-class carrier is born', 'color': '#b45309'},
      ], edge_labels=['becomes', 'and'], takeaway='He carried India onto the world’s air routes — Air India International flew the flag of a new nation abroad.', accent=AC),
      bg='After the war, Tata Airlines was ready to become a full national carrier, and independent India wanted an international airline.',
      people='J.R.D. Tata, its guiding chairman; the new <b>Government of India</b>, a partner in the international venture; Air India’s pilots and crew.',
      what='In <b>1946</b> Tata Airlines became a public company, <b>Air India</b>; in <b>1948</b> <b>Air India International</b> was formed as a joint venture with the government, launching <b>Bombay–London</b> service.',
      crux='J.R.D. made the airline a <b>symbol of national arrival</b> — proof that a newly free India could run a world-class carrier.',
      conseq='Air India earned a global reputation for elegance and service that J.R.D. personally cultivated for decades.',
      matters='Flag carriers are statements — J.R.D. gave independent India a proud presence in the skies of the world.'),

    E('nationalisation', '1953', 'Air India nationalised — and J.R.D. kept on', ['POLITICS', 'TURNING POINT'],
      'In 1953 Nehru’s government nationalises India’s airlines — taking Air India out of Tata hands — yet, in recognition of his unmatched expertise, J.R.D. Tata is asked to stay on as chairman of the nationalised Air India, a post he will hold for a quarter of a century.',
      svg_stack('The state takes the airline, keeps the man', [
          {'n': 1, 'label': 'Air Corporations Act, 1953', 'sub': 'India’s airlines nationalised', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Air India leaves Tata control', 'sub': 'the state becomes the owner', 'color': '#78350f'},
          {'n': 3, 'label': 'J.R.D. asked to stay chairman', 'sub': 'he leads Air India until 1978', 'color': '#0e7490'},
      ], takeaway='The state took his airline but could not replace him — J.R.D. chaired the nationalised Air India for 25 years.', accent=AC),
      bg='Nehru’s government pursued state ownership of key sectors, and in 1953 brought India’s airlines under public control.',
      people='Prime Minister <b>Jawaharlal Nehru</b>; the government that nationalised the airlines; J.R.D. Tata, the airline’s founder.',
      what='The <b>Air Corporations Act of 1953</b> nationalised India’s airlines, removing Air India from Tata ownership — but J.R.D. was invited to <b>continue as chairman of the nationalised Air India</b>, which he did until <b>1978</b>.',
      crux='Even under state ownership, the airline’s success was seen to depend on <b>J.R.D.’s personal stewardship</b> and standards.',
      conseq='He guided Air India for another 25 years, keeping it among the world’s most admired airlines.',
      matters='Expertise can outlast ownership — the state nationalised the airline but still needed the man who understood it best.'),

    E('removal', '1978', 'Removed from Air India after twenty-five years', ['POLITICS', 'TRAGEDY'],
      'In 1978 the Janata government under Morarji Desai abruptly removes J.R.D. Tata from the chairmanship of Air India and Indian Airlines — ending a twenty-five-year stewardship — a decision he received with dignity but felt keenly, and one many later judged a needless loss for the airline he had built.',
      svg_row('An abrupt end to a long stewardship', [
          {'n': 1, 'label': 'Desai government, 1978', 'sub': 'a change of political guard', 'color': '#3730a3'},
          {'n': 2, 'label': 'J.R.D. removed from Air India', 'sub': 'after 25 years as chairman', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A loss keenly felt', 'sub': 'the airline loses its founder-guardian', 'color': '#78350f'},
      ], edge_labels=['so', 'and'], takeaway='Politics ended his airline stewardship in 1978 — many saw it as a self-inflicted wound for Air India.', accent=AC),
      bg='With the Janata Party in power after the Emergency, the new government reshuffled leadership of the public airlines.',
      people='Prime Minister <b>Morarji Desai</b> and his government; J.R.D. Tata, removed after decades of service; Air India’s staff.',
      what='In <b>1978</b> the government <b>removed J.R.D. Tata as chairman of Air India</b> (and Indian Airlines), ending the 25-year stewardship he had continued after nationalisation.',
      crux='The decision severed the airline from the <b>founder whose standards had defined it</b>, for essentially political reasons.',
      conseq='J.R.D. accepted the removal with characteristic grace, but observers long lamented the airline’s subsequent decline.',
      matters='Institutions can squander their builders — cutting J.R.D. loose was widely seen as a costly break with Air India’s soul.'),
]

# ==================================================================  PHASE 5 — BUILDING INSTITUTIONS
PHASE_INSTITUTIONS = [
    E('tifr', '1945', 'Founding the Tata Institute of Fundamental Research', ['REFORM', 'LEGACY'],
      'In 1945, at the urging of the physicist Homi Bhabha, J.R.D. Tata commits the group to funding the Tata Institute of Fundamental Research — the cradle of Indian science that would become the birthplace of the country’s atomic-energy and space programmes.',
      svg_stack('Seeding India’s scientific future', [
          {'n': 1, 'label': 'Bhabha’s appeal, 1944–45', 'sub': 'a home for fundamental research', 'color': '#3730a3'},
          {'n': 2, 'label': 'TIFR founded, 1945', 'sub': 'funded by the Tata trusts', 'color': '#0e7490'},
          {'n': 3, 'label': 'Cradle of atomic & space science', 'sub': 'India’s premier research institute', 'color': '#166534'},
      ], takeaway='He backed Homi Bhabha’s vision, funding the institute from which India’s nuclear and space programmes would grow.', accent=AC),
      bg='The physicist <b>Homi Bhabha</b> sought a dedicated centre for fundamental research in a country that had none.',
      people='<b>Homi Bhabha</b>, the visionary physicist; J.R.D. Tata, his patron; the <b>Sir Dorabji Tata Trust</b>, which funded it.',
      what='In <b>1945</b> J.R.D. backed Bhabha’s proposal and the Tata trusts funded the <b>Tata Institute of Fundamental Research (TIFR)</b> in Bombay, which became India’s leading centre for physics and mathematics.',
      crux='He grasped that a modern nation needed <b>deep scientific capacity</b>, and used Tata wealth to create it.',
      conseq='TIFR became the seedbed of India’s <b>atomic energy and space programmes</b>, launched under Bhabha and his successors.',
      matters='Patronage can change a nation’s trajectory — J.R.D.’s funding of TIFR helped make India a scientific power.'),

    E('hospital', '1941–1966', 'Cancer care and the arts — from hospital to NCPA', ['REFORM', 'LEGACY'],
      'Through the Tata trusts J.R.D. underwrites landmark institutions of health and culture — the Tata Memorial Hospital for cancer (1941), pioneering research and treatment, and later the National Centre for the Performing Arts (1966) in Bombay — giving India world-class institutions in medicine and the arts.',
      svg_row('Institutions for body and spirit', [
          {'n': 1, 'label': 'Tata Memorial Hospital, 1941', 'sub': 'pioneering cancer care in India', 'color': '#0e7490'},
          {'n': 2, 'label': 'A record of Tata philanthropy', 'sub': 'health, education and social science', 'color': '#3730a3'},
          {'n': 3, 'label': 'NCPA founded, 1966', 'sub': 'a home for the performing arts', 'color': '#b45309'},
      ], edge_labels=['then', 'and'], takeaway='He built institutions for the whole person — from a pioneering cancer hospital to a national home for the arts.', accent=AC),
      bg='The Tata trusts had long funded public institutions; under J.R.D. this tradition of nation-building philanthropy widened.',
      people='J.R.D. Tata, guiding the trusts; the doctors of <b>Tata Memorial</b>; the musician <b>Jamshed Bhabha</b>, co-founder of the NCPA.',
      what='Tata philanthropy under J.R.D. supported the <b>Tata Memorial Hospital (1941)</b> for cancer, the <b>Tata Institute of Social Sciences</b>, and the <b>National Centre for the Performing Arts (1966)</b>.',
      crux='He believed a great nation needed <b>great institutions</b> — in medicine, learning and culture alike.',
      conseq='These bodies became national landmarks, serving millions and setting standards in their fields.',
      matters='Enduring philanthropy compounds — the hospitals and centres J.R.D. funded still serve India today.'),

    E('population', '1970s–1992', 'Championing family planning and population work', ['REFORM', 'IDEAS'],
      'Convinced that runaway population growth would undermine every gain, J.R.D. becomes an early and outspoken champion of family planning in India — funding population and demographic research through the Tata trusts and the institute later named for him — work recognised with the United Nations Population Award in 1992.',
      svg_stack('A crusade for population and welfare', [
          {'n': 1, 'label': 'An early alarm on population', 'sub': 'growth outpacing development', 'color': '#3730a3'},
          {'n': 2, 'label': 'Funds family-planning research', 'sub': 'demographic and population studies', 'color': '#0e7490'},
          {'n': 3, 'label': 'UN Population Award, 1992', 'sub': 'global recognition of his work', 'color': '#166534'},
      ], takeaway='He was a lonely early voice on population — funding family-planning work honoured with a UN award in 1992.', accent=AC),
      bg='From the 1950s J.R.D. argued, well ahead of consensus, that unchecked population growth threatened India’s progress.',
      people='J.R.D. Tata, the campaigner; the demographers and institutes he funded; the <b>United Nations</b>, which honoured him.',
      what='He was a leading advocate of <b>family planning</b>, funding <b>population and demographic research</b> through the Tata trusts, and received the <b>United Nations Population Award in 1992</b>.',
      crux='He treated population as a <b>development challenge</b> to be met with research and planning, not neglect.',
      conseq='His advocacy helped legitimise family-planning and population studies in India over decades.',
      matters='Foresight is rare and unpopular — J.R.D. pressed a difficult cause long before others would touch it.'),
]

# ==================================================================  PHASE 6 — THE LONG REIGN AND LEGACY
PHASE_LEGACY = [
    E('expansion', '1938–1991', 'From 14 to nearly 100 enterprises', ['TRIUMPH', 'BUSINESS'],
      'Over J.R.D.’s half-century at the helm the Tata Group is transformed — its enterprises multiplying from about 14 to some 95, its assets soaring — spanning steel, motors, chemicals, power, tea, consumer goods and, from 1968, Tata Consultancy Services, the software firm that would help make India a technology giant.',
      svg_row('A group transformed over fifty years', [
          {'n': 1, 'label': '~14 enterprises in 1938', 'sub': 'steel, power, hotels, trading', 'color': '#3730a3'},
          {'n': 2, 'label': 'New pillars added', 'sub': 'TCS (1968), Titan (1987), Voltas, Tata Tea', 'color': '#0e7490'},
          {'n': 3, 'label': '~95 enterprises by 1991', 'sub': 'assets grown many times over', 'color': '#b45309'},
      ], edge_labels=['grows', 'into'], takeaway='He grew the House of Tata from roughly 14 companies to about 95 — a sprawling, modern industrial group.', accent=AC),
      bg='When J.R.D. became chairman in 1938 the group was large but concentrated; over the following decades he diversified it dramatically.',
      people='J.R.D. Tata, the long-reigning chairman; the managers he trusted; his eventual successor <b>Ratan Tata</b>.',
      what='The group’s enterprises grew from about <b>14 to some 95</b> — adding <b>Tata Consultancy Services (1968)</b>, <b>Titan (1987)</b>, <b>Voltas</b>, <b>Tata Tea</b> and more — while assets multiplied many times over.',
      crux='He presided over a <b>vast diversification</b>, from heavy industry into software, watches, tea and consumer goods.',
      conseq='By his retirement the Tata Group was one of the largest and most respected conglomerates in the world.',
      matters='Compound growth over decades builds empires — J.R.D.’s long, steady reign made Tata a global business power.'),

    E('bharatratna', '1992', 'The Bharat Ratna', ['TRIUMPH', 'LEGACY'],
      'In 1992 the nation confers its highest civilian honour, the Bharat Ratna, on J.R.D. Tata — a rare award to an industrialist — crowning a lifetime of aviation, enterprise and philanthropy, which he received with his customary modesty: “Why me? I don’t deserve it.”',
      svg_stack('The nation’s highest honour', [
          {'n': 1, 'label': 'Bharat Ratna, 1992', 'sub': 'India’s highest civilian award', 'color': '#b45309'},
          {'n': 2, 'label': 'A rare honour for a businessman', 'sub': 'for aviation, industry and philanthropy', 'color': '#0e7490'},
          {'n': 3, 'label': '“Why me? I don’t deserve it.”', 'sub': 'received with characteristic modesty', 'color': '#166534'},
      ], takeaway='India crowned his life with the Bharat Ratna in 1992 — an honour he accepted with disarming humility.', accent=AC),
      bg='By 1992 J.R.D. Tata was revered as a founder of Indian aviation, a great industrialist and a philanthropist.',
      people='the <b>Government of India</b>, which conferred the award; J.R.D. Tata, the recipient; the nation that revered him.',
      what='In <b>1992</b> he was awarded the <b>Bharat Ratna</b>, India’s highest civilian honour — an unusual distinction for a businessman — the same year he received the <b>UN Population Award</b>.',
      crux='The award recognised a life spanning <b>aviation, industry and philanthropy</b> in the service of the nation.',
      conseq='It set the seal on his standing as one of independent India’s most admired figures.',
      matters='A nation honours what it values — India’s highest award to an industrialist affirmed J.R.D.’s ideal of enterprise as service.'),

    E('death', '1993', 'Death in Geneva and an enduring legacy', ['DEATH', 'LEGACY'],
      'J.R.D. Tata dies in Geneva on 29 November 1993, aged eighty-nine — mourned across India, his Parliament adjourned in tribute — leaving a legacy that includes India’s aviation, a transformed Tata Group, and a model of ethical, nation-serving capitalism that still defines the Tata name.',
      svg_row('The passing of a nation-builder', [
          {'n': 1, 'label': 'Dies in Geneva, 29 Nov 1993', 'sub': 'aged 89', 'color': '#78350f'},
          {'n': 2, 'label': 'A nation mourns', 'sub': 'Parliament adjourns in tribute', 'color': '#3730a3'},
          {'n': 3, 'label': 'An enduring legacy', 'sub': 'aviation, industry, ethics, philanthropy', 'color': '#0e7490'},
      ], edge_labels=['and', 'leaving'], takeaway='He died in 1993 having given India its wings, a great industrial group, and a lasting ideal of ethical enterprise.', accent=AC),
      bg='After handing the Tata chairmanship to Ratan Tata in 1991, J.R.D. remained the group’s revered elder statesman.',
      people='<b>Ratan Tata</b>, his chosen successor; the millions of Indians who mourned him; the institutions he had built.',
      what='J.R.D. Tata <b>died in Geneva on 29 November 1993</b>, aged 89; India’s Parliament <b>adjourned in tribute</b>, and he was mourned as a founder of modern Indian aviation and industry.',
      crux='His legacy fused <b>enterprise with ethics</b> — a business empire built as, in his view, a trust for the nation.',
      conseq='The Tata Group he shaped grew into a global giant, still identified with the values he embodied.',
      matters='A life measured in institutions endures — J.R.D. gave India wings, industry and an ideal of capitalism with a conscience.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">J.R.D. Tata was the French-born aviator and industrialist who gave India its wings and led the House of Tata for more than half a century. Holder of India’s first pilot’s licence, he founded the airline that became Air India, flying its first mail run himself; made chairman of Tata Sons at just thirty-four, he grew the group from about 14 enterprises to some 95, and poured Tata wealth into science, medicine, the arts and family planning. Honoured with the Bharat Ratna in 1992, he is the ultimate study in <b>enterprise as national service — ambition married to conscience.</b></p>
<div class="ov-quote">“No success in material terms is worthwhile unless it serves the needs or interests of the country.”<span>— J.R.D. Tata</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born in Paris to a Parsi father and French mother → earns India’s first pilot’s licence and founds Tata Airlines, flying its first mail flight in 1932 → becomes chairman of Tata Sons at 34 → builds Air India and keeps chairing it through nationalisation → funds TIFR, cancer care, the arts and family planning → grows the group to nearly 100 companies → and is crowned with the Bharat Ratna before his death in 1993.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">✈️</div><h4>Father of Indian aviation</h4><p>Licence No. 1; founded and flew the airline that became Air India.</p></div>
  <div class="ov-card"><div class="i">🏭</div><h4>Builder of an empire</h4><p>Grew the Tata Group from ~14 to ~95 enterprises over 50 years.</p></div>
  <div class="ov-card"><div class="i">🔬</div><h4>Patron of institutions</h4><p>Funded TIFR, cancer care, the NCPA and family planning.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>Ethical capitalism</h4><p>Held wealth in trust for the nation — profit as service.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Origins</b><small> 1904–1929</small><p>Paris, France, and India’s first pilot’s licence.</p></div>
  <div><b>2 · Wings</b><small> 1932–1945</small><p>Founding and flying India’s first airline.</p></div>
  <div><b>3 · Chairman</b><small> 1938–1945</small><p>The House of Tata, trusteeship, and new industries.</p></div>
  <div><b>4 · Air India</b><small> 1946–1978</small><p>A world carrier, nationalisation, and removal.</p></div>
  <div><b>5 · Institutions</b><small> 1941–1992</small><p>Science, medicine, the arts, family planning.</p></div>
  <div><b>6 · Legacy</b><small> 1938–1993</small><p>A group transformed, the Bharat Ratna, and death.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Jamsetji Tata', 'role': 'founder of the House', 'color': '#b45309',
     'bio': 'The visionary founder of the Tata group whose ideals of enterprise as national service J.R.D. inherited and carried forward.',
     'rel': 'The founding patriarch whose legacy J.R.D. stewarded.'},
    {'name': 'Nevill Vintcent', 'role': 'aviation partner', 'color': '#0e7490',
     'bio': 'The British aviator who planned and flew the early Tata airmail service alongside J.R.D., co-architect of India’s first airline.',
     'rel': 'His partner in founding and flying Tata Airlines.'},
    {'name': 'Homi Bhabha', 'role': 'physicist', 'color': '#3730a3',
     'bio': 'The physicist whose appeal led J.R.D. to fund TIFR in 1945; father of India’s atomic-energy programme.',
     'rel': 'The scientist whose research institute J.R.D. bankrolled.'},
    {'name': 'Jawaharlal Nehru', 'role': 'prime minister', 'color': '#166534',
     'bio': 'India’s first prime minister, whose government nationalised the airlines in 1953 yet kept J.R.D. on as Air India’s chairman.',
     'rel': 'The leader who nationalised his airline but retained him.'},
    {'name': 'Ratan Tata', 'role': 'successor', 'color': '#78350f',
     'bio': 'The industrialist who succeeded J.R.D. as chairman of Tata Sons in 1991 and led the group into its global era.',
     'rel': 'His chosen successor at the head of the Tata group.'},
]

KEY_EVENTS = [
    ('1904', 'Born in Paris', 'To a Parsi father and a French mother.'),
    ('1929', 'India’s first pilot licence', 'Flying licence No. 1, on 10 February.'),
    ('1932', 'Tata Airlines founded', 'He flies the first Karachi–Bombay mail run.'),
    ('1938', 'Chairman of Tata Sons', 'Leads the House of Tata at age 34.'),
    ('1945', 'Telco & TIFR', 'Engineering firm and research institute founded.'),
    ('1946', 'Air India', 'Tata Airlines becomes a public company.'),
    ('1948', 'Air India International', 'Bombay–London; India flies the world.'),
    ('1953', 'Airline nationalised', 'He stays on as Air India chairman.'),
    ('1978', 'Removed from Air India', 'After 25 years, by the Desai government.'),
    ('1992', 'Bharat Ratna', 'India’s highest civilian honour.'),
    ('1993', 'Dies in Geneva', 'Aged 89; a nation mourns.'),
]

MASTER = [
    {'year': '1904', 'age': 'born', 'phase': 'Origins', 'title': 'Born in Paris', 'desc': 'A Parsi–French heritage.'},
    {'year': '1929', 'age': 'age 24', 'phase': 'Origins', 'title': 'Pilot licence No. 1', 'desc': 'India’s first licensed pilot.'},
    {'year': '1932', 'age': 'age 28', 'phase': 'Wings', 'title': 'Founds Tata Airlines', 'desc': 'Flies the first mail flight.'},
    {'year': '1938', 'age': 'age 34', 'phase': 'Chairman', 'title': 'Heads Tata Sons', 'desc': 'A reign of 50+ years begins.'},
    {'year': '1946', 'age': 'age 42', 'phase': 'Air India', 'title': 'Air India created', 'desc': 'And Air India International, 1948.'},
    {'year': '1953', 'age': 'age 49', 'phase': 'Air India', 'title': 'Airline nationalised', 'desc': 'He remains chairman until 1978.'},
    {'year': '1945', 'age': 'age 41', 'phase': 'Institutions', 'title': 'TIFR founded', 'desc': 'Backing Homi Bhabha’s science.'},
    {'year': '1992', 'age': 'age 88', 'phase': 'Legacy', 'title': 'Bharat Ratna', 'desc': 'India’s highest civilian honour.'},
    {'year': '1993', 'age': 'age 89', 'phase': 'Legacy', 'title': 'Dies in Geneva', 'desc': 'An enduring nation-builder.'},
]

SOURCES = [
    ('Wikipedia — J. R. D. Tata', 'https://en.wikipedia.org/wiki/J._R._D._Tata'),
    ('Britannica — J.R.D. Tata', 'https://www.britannica.com/money/J-R-D-Tata'),
    ('Tata group — JRD Tata', 'https://www.tata.com/about-us/tata-group-our-heritage/tata-titans/jrd-tata'),
    ('Tata group — Wings for a Nation', 'https://www.tata.com/newsroom/wings-for-a-nation'),
    ('The Better India — The First Air India Flight, 1932', 'https://thebetterindia.com/92669/air-india-jrd-tata-airlines-karachi-bombay/'),
    ('Simple Flying — JRD Tata, first commercial pilot in India', 'https://simpleflying.com/jrd-tata/'),
]

def build_meta():
    return {
        'pid': 'gm-jrdtata.html', 'kind': 'man', 'emoji': '✈️', 'accent': AC,
        'name': 'J.R.D. Tata', 'years': '1904–1993', 'group': 'Business & Industry',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The French-born aviator and industrialist who gave India its first airline — flying its inaugural mail run himself — and led the Tata Group for over half a century, building enterprises, institutions and an ideal of enterprise as national service.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'origins', 'label': '1 · Origins', 'type': 'timeline',
             'intro': 'Born in Paris to a Parsi father and a French mother, the young Tata grows up bilingual and in love with flight — and earns India’s first pilot’s licence.', 'events': PHASE_ORIGINS},
            {'id': 'wings', 'label': '2 · Wings', 'type': 'timeline',
             'intro': 'He turns a boyhood passion into an enterprise — founding Tata Airlines, flying its first mail run, and building India’s most admired carrier.', 'events': PHASE_WINGS},
            {'id': 'chairman', 'label': '3 · Chairman', 'type': 'timeline',
             'intro': 'Made head of the House of Tata at thirty-four, he governs by the ideal of trusteeship and pushes the group into chemicals and engineering.', 'events': PHASE_CHAIRMAN},
            {'id': 'airindia', 'label': '4 · Air India', 'type': 'timeline',
             'intro': 'His airline becomes Air India and flies the world — until the state nationalises it, keeps him at its head, and then, in 1978, lets him go.', 'events': PHASE_AIRINDIA},
            {'id': 'institutions', 'label': '5 · Institutions', 'type': 'timeline',
             'intro': 'He pours Tata wealth into nation-building — science at TIFR, cancer care, the performing arts, and a lonely early crusade for family planning.', 'events': PHASE_INSTITUTIONS},
            {'id': 'legacy', 'label': '6 · Legacy', 'type': 'timeline',
             'intro': 'Over fifty years he grows the group to nearly a hundred enterprises, is crowned with the Bharat Ratna, and dies in Geneva an enduring nation-builder.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources, together with Tata group and aviation histories; some early aviation details survive through company tradition.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
