# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Chanakya (Kautilya / Vishnugupta).
The Brahmin kingmaker who toppled the Nandas, made the Mauryan Empire, and wrote the Arthashastra."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#c2410c'  # saffron / burnt ochre

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE BRAHMIN OF TAXILA
PHASE_MAKING = [
    E('origins', 'c. 375 BC', 'A Brahmin of three names — the making of a strategist', ['RISE'],
      'Born into a Brahmin family in the twilight of the Nanda age, the man history remembers as Chanakya — also called Kautilya and Vishnugupta — steps out of the mist of legend rather than the record: no contemporary document survives about his birth, and everything we know comes from Buddhist, Jain and Kashmiri tales composed centuries later.',
      svg_stack('One man, three names, no records', [
          {'n': 1, 'label': 'A Brahmin scholar, c. 375 BC', 'sub': 'born in the late Nanda era of north India', 'color': '#c2410c'},
          {'n': 2, 'label': 'Chanakya · Kautilya · Vishnugupta', 'sub': 'three names for one strategist-philosopher', 'color': '#a16207'},
          {'n': 3, 'label': 'Known only through legend', 'sub': 'no contemporary record; tales written centuries later', 'color': '#166534'},
      ], takeaway='Almost everything about the man is legend — the history is the empire and the book he left behind.', accent=AC),
      bg='<b>Chanakya</b> was a Brahmin scholar of the late 4th century BC, traditionally dated <b>c. 375–283 BC</b>. He is also known as <b>Kautilya</b> and <b>Vishnugupta</b>.',
      people='the Buddhist, Jain and Kashmiri storytellers who preserved his legend; the Nanda kings whose age he was born into; his protégé-to-be, Chandragupta.',
      what='He emerges only through <b>legendary narratives</b> — the Buddhist <i>Mahavamsa</i>, the Jain <i>Parishishtaparvan</i>, the Kashmiri <i>Kathasaritsagara</i> and Vishakhadatta’s play <i>Mudrarakshasa</i> — all composed <b>centuries after</b> the events they describe. <b>[LEGEND]</b> No contemporary document about his life survives. <b>[HISTORY]</b>',
      crux='He is a figure of <b>tradition, not archive</b> — a real strategist wrapped in accreted myth, so legend and record must be told apart at every step.',
      conseq='The uncertainty around the man contrasts sharply with the concrete legacy — an empire and a treatise — that history does record.',
      matters='The most consequential lives are not always the best documented — Chanakya’s influence is measured by what he built, not by a biography.'),

    E('takshashila', 'c. 350 BC', 'The teacher of Takshashila — mastering the science of power', ['RISE', 'REFORM'],
      'By tradition Chanakya taught at Takshashila (Taxila), the great seat of learning in the north-west, where he mastered not only the Vedas but dandaniti and arthashastra — the sciences of punishment, politics and statecraft — turning a scholar into a theorist of raw power.',
      svg_stack('From Vedas to the science of statecraft', [
          {'n': 1, 'label': 'Teacher at Takshashila (Taxila)', 'sub': 'the famed north-western seat of learning', 'color': '#c2410c'},
          {'n': 2, 'label': 'Master of the Vedas and politics', 'sub': 'well-versed in the three Vedas and statecraft', 'color': '#a16207'},
          {'n': 3, 'label': 'The science of power', 'sub': 'dandaniti and arthashastra — rule, punishment, economy', 'color': '#166534'},
      ], takeaway='He studied power as a science — the training that would let him remake a kingdom, not merely serve one.', accent=AC),
      bg='<b>Takshashila (Taxila)</b>, in the north-west of the subcontinent, was a renowned centre of learning where Brahmin teachers trained students in the Vedas, law and the arts of government.',
      people='the students and teachers of Takshashila; the intellectual tradition of <b>dandaniti</b> (the science of governance and punishment) he inherited and would transform.',
      what='Tradition holds that Chanakya was <b>a teacher at Takshashila</b>, learned in the three Vedas and in politics. <b>[LEGEND]</b> He is credited with mastering <b>arthashastra and dandaniti</b> — the disciplines of statecraft, economics and the wielding of force.',
      crux='His genius was to treat <b>power as a craft to be studied</b> — governance, war, spying and economy as a systematic science rather than a matter of custom or virtue.',
      conseq='This training made him not a courtier but a <b>theorist of the state</b>, ready to design and direct an empire from first principles.',
      matters='Mastery of a subject as a system, not a habit, is what let Chanakya build institutions — the scholar became an engineer of power.'),

    E('nandaage', 'c. 340 BC', 'The world he judged — Nanda tyranny and a Greek invasion', ['POLITICS'],
      'Chanakya came of age in a north India ruled by the wealthy but widely resented Nanda dynasty from Pataliputra, just as Alexander of Macedon smashed into the Punjab — a landscape of a hated regime and a foreign menace that shaped his conviction that only a strong, unified state could survive.',
      svg_row('A hated regime and a foreign threat', [
          {'n': 1, 'label': 'The Nanda dynasty', 'sub': 'rich, powerful, but resented from Pataliputra', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Alexander invades, 327–325 BC', 'sub': 'Macedon smashes into the Punjab', 'color': '#a16207'},
          {'n': 3, 'label': 'A conviction is born', 'sub': 'only a strong unified state can endure', 'color': '#166534'},
      ], edge_labels=['amid', 'yields'], takeaway='A hated dynasty at home and a conqueror at the gate convinced him India needed one strong state.', accent=AC),
      bg='North India in the mid-4th century BC was dominated by the <b>Nanda dynasty</b>, immensely wealthy and militarily strong but widely disliked. In <b>327–325 BC Alexander the Great</b> invaded the north-west.',
      people='<b>Dhana Nanda</b>, the last Nanda king; <b>Alexander of Macedon</b>, whose invasion shook the region; the many small kingdoms of the Punjab.',
      what='Chanakya matured amid the <b>Nanda ascendancy</b> and the shock of <b>Alexander’s invasion</b>. <b>[HISTORY]</b> The combination — an unpopular native empire and a foreign conqueror — framed his political thought.',
      crux='He drew a hard lesson from his times: <b>disunity invites conquest</b>, and only a strong, centralised, well-defended state could hold India together.',
      conseq='This conviction pointed him toward toppling the Nandas and forging a new, more durable empire in their place.',
      matters='Crisis clarifies strategy — the twin threats of a hated regime and a foreign army set Chanakya on the path to build an empire.'),
]

# ==================================================================  PHASE 2 — THE VOW
PHASE_VOW = [
    E('humiliation', 'c. 322 BC', 'Insulted by the Nanda king — the vow of vengeance', ['POLITICS', 'TRAGEDY', 'TURNING POINT'],
      'The turning point of the legend: arriving at the Nanda court at Pataliputra, Chanakya is publicly humiliated by King Dhana Nanda — mocked for his looks and thrown out of the assembly — and in his fury swears to uproot the entire Nanda dynasty, famously untying his hair-tuft and vowing not to bind it until the deed is done.',
      svg_stack('An insult that toppled a dynasty', [
          {'n': 1, 'label': 'Chanakya at the Nanda court', 'sub': 'comes to Pataliputra, seat of Dhana Nanda', 'color': '#c2410c'},
          {'n': 2, 'label': 'Publicly humiliated and cast out', 'sub': 'mocked for his looks, thrown from the assembly', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The vow to uproot the Nandas', 'sub': 'swears to destroy the dynasty ‘root and branch’', 'color': '#78350f'},
      ], takeaway='A king’s petty insult made a mortal enemy — and set in motion the fall of his own dynasty.', accent=AC),
      bg='By tradition Chanakya came to the court of <b>Dhana Nanda</b> at <b>Pataliputra</b>, the Nanda capital, where he was slighted and expelled from the royal assembly.',
      people='<b>Dhana Nanda</b>, the last Nanda king who insulted him; the assembled court that witnessed the humiliation.',
      what='In every major version of the legend, <b>Dhana Nanda humiliates Chanakya</b> — mocking his appearance and having him removed. <b>[LEGEND]</b> Enraged, Chanakya <b>vows to destroy the Nanda dynasty</b> ‘like a great wind uproots a tree,’ and (in some tellings) leaves his <i>shikha</i> hair-tuft unbound until his vengeance is complete.',
      crux='The whole revolution turns on a <b>personal insult transmuted into political will</b> — a scholar’s wounded pride becomes a disciplined, decade-long campaign.',
      conseq='The vow launched him on the search for an instrument — a man he could raise up to overthrow the Nandas.',
      matters='Underestimating and insulting a capable enemy is a fatal error — Dhana Nanda’s contempt created the man who destroyed him.'),

    E('chandragupta', 'c. 322 BC', 'Finding Chandragupta — the making of a king', ['POLITICS', 'RISE'],
      'Seeking an instrument for his vengeance, Chanakya discovers the young Chandragupta — spotting the boy’s natural authority (in legend, ‘playing king’ among his fellows) — takes him under his wing, and trains him for seven to nine years in war and statecraft, testing his ruthlessness before entrusting him with a throne.',
      svg_row('A kingmaker chooses his king', [
          {'n': 1, 'label': 'Spots young Chandragupta', 'sub': 'notes his natural command — ‘playing king’', 'color': '#c2410c'},
          {'n': 2, 'label': 'Seven-to-nine years of training', 'sub': 'war, statecraft and the science of rule', 'color': '#a16207'},
          {'n': 3, 'label': 'Tested for ruthlessness', 'sub': 'proves the pragmatism a ruler needs', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='He did not seek a ready-made prince — he found raw talent and forged it into an emperor.', accent=AC),
      bg='In search of a candidate to overthrow the Nandas, Chanakya identified <b>Chandragupta Maurya</b>, a youth of disputed origin — commoner or minor royal — with striking natural leadership.',
      people='<b>Chandragupta Maurya</b>, the future emperor and Chanakya’s protégé; the rival candidate (Pabbata/Parvata) discarded in favour of him.',
      what='Chanakya <b>discovered and adopted Chandragupta</b>, reportedly noticing him acting as ‘king’ among playmates, then <b>trained him for seven to nine years</b> in the arts of war and government. <b>[LEGEND]</b> A famous test showed Chandragupta’s ruthless pragmatism, convincing Chanakya he had found his king.',
      crux='This is the essence of the <b>kingmaker</b>: power exercised not by holding the crown but by <b>creating and directing the one who wears it</b>.',
      conseq='With his instrument chosen and trained, Chanakya could begin the campaign to bring down the Nandas.',
      matters='The greatest strategists build the leaders who front them — Chanakya’s power lay in making a king, not being one.'),

    E('alliances', 'c. 322 BC', 'Building the war machine — gold, allies and spies', ['POLITICS', 'REFORM'],
      'Before striking, Chanakya assembles the sinews of revolt: raising money and a mercenary army, forging an alliance with a frontier king (Parvataka in the legends), and threading spies and agents through Nanda territory to sow division — the patient groundwork of a coup years in the making.',
      svg_stack('The groundwork of a revolution', [
          {'n': 1, 'label': 'Gold and an army', 'sub': 'raises funds and hires mercenary troops', 'color': '#c2410c'},
          {'n': 2, 'label': 'A frontier alliance', 'sub': 'allies with a border king (Parvataka)', 'color': '#a16207'},
          {'n': 3, 'label': 'Spies and subversion', 'sub': 'agents sow division inside Nanda lands', 'color': '#166534'},
      ], takeaway='He built the coup like an engineer — money, alliances and intelligence assembled before a single blow.', accent=AC),
      bg='Overthrowing the powerful Nandas required more than a vow. Chanakya spent years gathering the <b>resources, alliances and intelligence</b> a war of conquest demanded.',
      people='<b>Chandragupta</b>, the figurehead of the revolt; the frontier king <b>Parvataka</b>, Chanakya’s ally; the network of spies and agents he ran.',
      what='Chanakya <b>financed the rebellion</b>, raised troops, <b>allied with a border kingdom</b> and <b>deployed spies</b> to weaken Dhana Nanda from within. <b>[LEGEND]</b> The methodical, multi-year preparation mirrors the doctrine later set down in the <i>Arthashastra</i>.',
      crux='He treated revolution as <b>logistics and intelligence</b>, not passion — assembling every instrument of power before committing to open war.',
      conseq='With money, men and allies in hand, Chanakya launched the assault on the Nanda heartland.',
      matters='Great upheavals are won in preparation — Chanakya’s patient assembly of resources is the practical face of his realpolitik.'),
]

# ==================================================================  PHASE 3 — THE OVERTHROW
PHASE_OVERTHROW = [
    E('firstattempt', 'c. 322 BC', 'The first assault fails — the lesson of the hot gruel', ['BATTLE', 'DEFEAT'],
      'Chanakya and Chandragupta strike first at the Nanda capital itself — and are beaten back. The famous parable of their recovery: overhearing a mother scold her child for burning his fingers by eating from the hot centre of his gruel instead of the cool edges, Chanakya grasps his strategic error — conquer the frontier first, then close on the capital.',
      svg_row('A defeat that taught a strategy', [
          {'n': 1, 'label': 'Strike at the capital first', 'sub': 'a direct attack on Pataliputra', 'color': '#c2410c'},
          {'n': 2, 'label': 'Severe defeat', 'sub': 'the Nandas beat the rebels back', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The hot-gruel lesson', 'sub': 'take the edges first, then the centre', 'color': '#166534'},
      ], edge_labels=['brings', 'teaches'], takeaway='He learned from failure that you take the frontier before the heart — patience over a headlong rush.', accent=AC),
      bg='The first attempt to overthrow the Nandas was an <b>attack on the capital directly</b> — and it ended in a serious defeat that forced a rethink.',
      people='<b>Chandragupta</b>, leading the assault; <b>Dhana Nanda’s</b> defending forces; the anonymous mother and child of the parable.',
      what='The rebels’ initial <b>direct attack on Pataliputra failed</b>. <b>[LEGEND]</b> Chanakya then overheard a woman scold her son for burning himself on hot gruel’s centre, and realised his mistake: he should <b>subdue the outlying provinces first</b>, then converge on the capital.',
      crux='The parable encodes a real strategic principle — <b>secure the periphery before the centre</b>, so the heartland falls isolated and unsupported.',
      conseq='Applying the new strategy, Chanakya and Chandragupta ground down the Nanda frontier before their final assault.',
      matters='Learning from defeat is the mark of a strategist — the ‘eat from the edges’ lesson is a timeless rule of campaigns and negotiations alike.'),

    E('conquest', 'c. 322–321 BC', 'The fall of the Nandas — the vow fulfilled', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'With the frontier subdued, the rebels close on Pataliputra and take it — deposing and killing Dhana Nanda and ending the Nanda dynasty around 322–321 BC. Chanakya’s decade-old vow is fulfilled, and the throne of Magadha lies open for the king he has made.',
      svg_stack('The heartland falls', [
          {'n': 1, 'label': 'The frontier subdued', 'sub': 'the provinces taken first, edges before centre', 'color': '#c2410c'},
          {'n': 2, 'label': 'Pataliputra falls, c. 322–321 BC', 'sub': 'the capital is besieged and taken', 'color': '#a16207'},
          {'n': 3, 'label': 'Dhana Nanda deposed and killed', 'sub': 'the Nanda dynasty is ended', 'color': '#78350f'},
      ], takeaway='The insult of a decade before was answered in full — the Nanda line was uprooted, exactly as he vowed.', accent=AC),
      bg='Following the new strategy, Chanakya and Chandragupta pressed in on the Nanda capital <b>Pataliputra</b> after reducing the surrounding country.',
      people='<b>Dhana Nanda</b>, the deposed last king; <b>Chandragupta</b>, the victorious claimant; Chanakya, the mastermind behind the throne.',
      what='Around <b>322–321 BC</b> the rebels <b>captured Pataliputra and killed Dhana Nanda</b>, ending the Nanda dynasty. <b>[HISTORY / LEGEND]</b> The Mauryan takeover of Magadha is historical; the vivid details of the siege come from the legends.',
      crux='The overthrow was the <b>payoff of years of design</b> — training, alliances, intelligence and a corrected strategy, all converging on one decisive result.',
      conseq='The fall of the Nandas cleared the way for Chandragupta’s coronation and the founding of a new empire.',
      matters='Persistence plus method beats raw strength — a resented dynasty fell to a patient strategist with a made-to-order king.'),

    E('founding', 'c. 322 BC', 'The Mauryan Empire is born — the kingmaker enthroned', ['TRIUMPH', 'RISE', 'TURNING POINT'],
      'Chandragupta ascends the throne of Magadha and founds the Mauryan Empire — soon to become the largest state the subcontinent had ever seen — with Chanakya as the power behind it: the chief minister and mentor who conceived the whole enterprise and now sets out to govern it.',
      svg_row('A dynasty made to order', [
          {'n': 1, 'label': 'Chandragupta crowned', 'sub': 'takes the throne of Magadha, c. 322 BC', 'color': '#c2410c'},
          {'n': 2, 'label': 'The Mauryan Empire founded', 'sub': 'soon the largest empire India had seen', 'color': '#a16207'},
          {'n': 3, 'label': 'Chanakya as chief minister', 'sub': 'the mentor becomes the power behind the throne', 'color': '#166534'},
      ], edge_labels=['founds', 'guided by'], takeaway='He set his pupil on the throne and stood behind it — the empire was his design, run by his king.', accent=AC),
      bg='With the Nandas gone, <b>Chandragupta Maurya</b> took the throne of Magadha and founded the <b>Mauryan Empire (322–185 BC)</b>, which grew to dominate the subcontinent.',
      people='<b>Chandragupta Maurya</b>, first Mauryan emperor; Chanakya, his chief minister and chief architect; the Mauryan state they built together.',
      what='Chandragupta <b>founded the Mauryan Empire around 322 BC</b>, with Chanakya serving as his <b>chief minister and adviser</b>. <b>[HISTORY]</b> Chanakya, having conceived and engineered the enterprise, now turned to the harder task of governing it.',
      crux='The distinction that defines him: he was the <b>kingmaker, not the king</b> — the intellect that founded a dynasty and then chose to rule through it.',
      conseq='As chief minister he would organise administration, defence and economy, and set down his principles in the <i>Arthashastra</i>.',
      matters='The founder of the Mauryan Empire wore no crown — Chanakya shows that the decisive figure is often the strategist behind the throne, not on it.'),
]

# ==================================================================  PHASE 4 — THE ARCHITECT OF THE STATE
PHASE_STATE = [
    E('primeminister', 'c. 321–297 BC', 'Prime minister of an empire — the state-builder', ['POLITICS', 'REFORM'],
      'As chief minister to Chandragupta, Chanakya organises the young empire: a centralised bureaucracy, a system of taxation and revenue, a standing army and a web of internal control — the administrative machinery that turned a conquest into a lasting, governable state stretching across northern India.',
      svg_stack('Turning conquest into a state', [
          {'n': 1, 'label': 'Centralised administration', 'sub': 'a bureaucracy of officials and departments', 'color': '#c2410c'},
          {'n': 2, 'label': 'Taxation and revenue', 'sub': 'a fiscal system to fund the empire', 'color': '#a16207'},
          {'n': 3, 'label': 'Army and internal control', 'sub': 'standing forces and a web of oversight', 'color': '#166534'},
      ], takeaway='Winning the empire was the easy part — Chanakya’s lasting work was the machinery that made it govern.', accent=AC),
      bg='Founding an empire is not the same as running one. As <b>chief minister (mahamantri)</b>, Chanakya built the institutions that would let the Mauryan state endure.',
      people='<b>Chandragupta Maurya</b>, the emperor he served; the officials, tax-collectors, generals and spies of the Mauryan administration.',
      what='Chanakya organised a <b>centralised bureaucracy</b>, a structured system of <b>taxation and revenue</b>, a <b>standing army</b> and pervasive internal oversight. <b>[HISTORY / LEGEND]</b> The Mauryan state’s sophistication is attested; the fine detail of his role comes through tradition.',
      crux='His achievement was <b>institution-building</b> — designing durable structures of revenue, administration and force rather than relying on a strong ruler’s personality.',
      conseq='This machinery underpinned Chandragupta’s later expansion, including pushing back the Greek successor Seleucus around 305–303 BC.',
      matters='Empires last through institutions, not conquests — Chanakya’s administrative system is why the Mauryan state outlived its founders.'),

    E('arthashastra', 'c. 300 BC (attributed)', 'The Arthashastra — the science of statecraft', ['REFORM', 'POLITICS'],
      'Chanakya is traditionally the author of the Arthashastra, the great Sanskrit treatise on statecraft, economics, war, diplomacy and administration — a coldly practical manual of realpolitik whose ‘the ends justify the means’ logic has led scholars to call him the Indian Machiavelli, writing some eighteen centuries before The Prince.',
      svg_compare('A manual of power — and its Western echo', {
          'head': 'The Arthashastra (Kautilya)', 'color': '#c2410c', 'items': [
              'Statecraft, economics, war, diplomacy',
              'Administration, law, taxation, spies',
              'Ends justify the means — power first',
              'Written c. 300 BC (traditional)',
          ]}, {
          'head': 'The Prince (Machiavelli)', 'color': '#a16207', 'items': [
              'How a ruler gains and keeps power',
              'Politics divorced from conventional morality',
              'Ends justify the means — pragmatism',
              'Written 1513 AD — ~18 centuries later',
          ]},
      verdict='Two manuals of ruthless statecraft — Chanakya’s came first by some eighteen hundred years.',
      takeaway='He wrote the ancient world’s coldest, most complete manual of power — realpolitik long before the word existed.', accent=AC),
      bg='The <b>Arthashastra</b> (‘the science of wealth/statecraft’) is a comprehensive Sanskrit treatise on how to acquire, hold and expand state power, traditionally attributed to Kautilya.',
      people='<b>Kautilya</b>, its named author; <b>Chandragupta</b>, the ruler it was said to instruct; <b>Machiavelli</b>, the later Western thinker it is compared to.',
      what='The <i>Arthashastra</i> systematically treats <b>administration, law, taxation, economics, diplomacy, war and espionage</b>, teaching that a ruler must do <b>whatever the state’s interest requires</b>. <b>[HISTORY of text; authorship debated]</b> Modern scholars think it reached its final form over several centuries and doubt Chanakya wrote all of it — the name may be a later attribution.',
      crux='Its core is <b>realpolitik</b>: statecraft as a science detached from conventional morality, in which the <b>ends justify the means</b> and power is pursued methodically.',
      conseq='Lost for centuries, the text was <b>rediscovered in 1905</b> by R. Shamasastry and published in 1915, reshaping how the world saw ancient Indian political thought.',
      matters='It is one of history’s foundational works on power — the ‘Indian Machiavelli’ label reverses the truth, since Chanakya wrote first.'),

    E('spycraft', 'c. 300 BC', 'The spy state — intelligence, deception and the poison maiden', ['POLITICS', 'BATTLE'],
      'At the heart of Chanakya’s statecraft lies intelligence: a vast network of spies and informers, elaborate deception, and the darker legends of assassination — including the vish kanya, the ‘poison maiden’ raised on toxins until her very touch or kiss could kill, deployed as a living weapon against an enemy king.',
      svg_stack('Statecraft run on secrets', [
          {'n': 1, 'label': 'A network of spies', 'sub': 'informers and agents across the realm', 'color': '#c2410c'},
          {'n': 2, 'label': 'Deception and subversion', 'sub': 'forged letters, turned allies, sown discord', 'color': '#a16207'},
          {'n': 3, 'label': 'The vish kanya legend', 'sub': 'the ‘poison maiden’ as a living weapon', 'color': '#78350f'},
      ], takeaway='He built a state that ran on secrets — surveillance and subterfuge raised to a science, and darkened by legend.', accent=AC),
      bg='The <i>Arthashastra</i> devotes whole sections to <b>espionage</b>, and the Chanakya legends are thick with plots, poisons and deception as instruments of rule.',
      people='the spies and agents of the Mauryan state; the <b>vish kanya</b> (poison maiden) of legend; the rival Parvata, said to die by her in one tale.',
      what='Chanakya is credited with running an <b>extensive intelligence network</b> and mastering <b>deception</b> — forged documents, disinformation, turning enemies against one another. <b>[HISTORY of doctrine]</b> The lurid <b>vish kanya</b> legend — a maiden immunised to poison until her touch or kiss was lethal — is <b>myth</b>, not record. <b>[LEGEND]</b>',
      crux='He understood that <b>information and manipulation</b> are as decisive as armies — the state that sees and deceives best prevails.',
      conseq='This doctrine of spycraft and ‘secret means’ became one of the most enduring — and notorious — parts of his reputation.',
      matters='Intelligence and deception are ancient arts of power — Chanakya theorised the spy state two thousand years before modern statecraft named it.'),
]

# ==================================================================  PHASE 5 — THE LEGACY
PHASE_LEGACY = [
    E('niti', 'attributed', 'The Chanakya Niti — aphorisms of a hard-eyed sage', ['POLITICS'],
      'Alongside the Arthashastra, tradition credits Chanakya with the Chanakya Niti — a collection of pithy aphorisms on ethics, prudence, friendship, money and human nature, blending shrewd worldly counsel with a clear-eyed, sometimes cynical view of people that has kept his name a household word in India.',
      svg_stack('The sage of worldly wisdom', [
          {'n': 1, 'label': 'The Chanakya Niti', 'sub': 'aphorisms drawn from many shastras', 'color': '#c2410c'},
          {'n': 2, 'label': 'Prudence and human nature', 'sub': 'counsel on money, friends, trust and folly', 'color': '#a16207'},
          {'n': 3, 'label': 'A household name', 'sub': 'quoted across India to this day', 'color': '#166534'},
      ], takeaway='Beyond statecraft he became a folk-sage of hard wisdom — his maxims still quoted where his empire is forgotten.', accent=AC),
      bg='The <b>Chanakya Niti</b> (or Niti-shastra) is a collection of aphorisms on conduct and prudence traditionally attributed to Chanakya, distinct from the political <i>Arthashastra</i>.',
      people='the many generations who memorised and quoted his maxims; the wider <i>niti</i> (ethical-practical) literature the sayings draw on.',
      what='The <b>Chanakya Niti</b> gathers pithy verses on <b>ethics, friendship, money, education and human weakness</b>, mixing moral counsel with cool, worldly realism. <b>[LEGEND / attribution disputed]</b> Scholars doubt Chanakya personally compiled it, but it cements his image as a sage of practical wisdom.',
      crux='It captures his <b>unsentimental view of human nature</b> — trust cautiously, prepare for betrayal, and act on how people are rather than how they should be.',
      conseq='Through the Niti, Chanakya lives in popular culture as a wisdom-figure, far beyond the scholarly debates over his history.',
      matters='A thinker survives in his aphorisms — the Chanakya Niti keeps his hard-eyed realism alive in everyday Indian speech.'),

    E('bindusara', 'c. 297 BC', 'Serving the son — poison, immunity and a legend of birth', ['POLITICS', 'TRAGEDY'],
      'Chanakya’s service outlasts Chandragupta, continuing under his son Bindusara — and legend darkens here: the tale that Chanakya laced the emperor’s food with tiny doses of poison to build immunity against assassination, and that when a pregnant queen ate the tainted food, he cut the child from her body, naming him Bindusara for the ‘drop’ (bindu) of poison that touched him.',
      svg_stack('A ministry that outlived a reign', [
          {'n': 1, 'label': 'Poison for immunity', 'sub': 'tiny doses to guard the emperor from assassins', 'color': '#c2410c'},
          {'n': 2, 'label': 'The birth of Bindusara', 'sub': 'a ‘drop’ of poison touches the unborn child', 'color': '#78350f'},
          {'n': 3, 'label': 'Minister to the next emperor', 'sub': 'serves on under Bindusara', 'color': '#166534'},
      ], takeaway='Even the birth of the next emperor was woven into his legend of poison — service and menace intertwined.', accent=AC),
      bg='Chanakya continued as chief minister after Chandragupta’s reign, serving his son and successor <b>Bindusara</b> (r. c. 297 BC onward).',
      people='<b>Chandragupta</b>, the first emperor; his son <b>Bindusara</b>; the queen of the birth legend; Bindusara’s son would be the great <b>Ashoka</b>.',
      what='Legend holds Chanakya <b>fed Chandragupta minute doses of poison</b> to immunise him, and that when a pregnant queen shared the food, he <b>saved the child</b> — <b>Bindusara</b>, named for the drop (<i>bindu</i>) of poison. <b>[LEGEND]</b> Historically, he did <b>continue to serve under Bindusara</b>. <b>[HISTORY]</b>',
      crux='The story fuses his two faces — <b>protector and poisoner</b> — dramatising a statecraft in which even the ruler’s safety is engineered through calculated risk.',
      conseq='His continued service bridged two reigns and helped secure the dynasty that would culminate in Ashoka the Great.',
      matters='Legends encode a truth about the man — that in Chanakya’s world, protection and menace were two edges of the same calculated blade.'),

    E('death', 'c. 283 BC', 'The end and the afterlife — a rediscovered legacy', ['DEATH', 'DEFEAT'],
      'The end is as clouded as the beginning: legends have Chanakya retire to the forest, or die by slow starvation after a court intrigue by the rival Subandhu — and after his death he faded from record until 1905, when the rediscovery of the Arthashastra restored him as one of history’s foremost thinkers on power.',
      svg_row('Lost in legend, restored by a text', [
          {'n': 1, 'label': 'A clouded end, c. 283 BC', 'sub': 'retirement, or death by intrigue and starvation', 'color': '#78350f'},
          {'n': 2, 'label': 'Faded from the record', 'sub': 'his authorship and life half-forgotten', 'color': '#a16207'},
          {'n': 3, 'label': 'Rediscovered, 1905', 'sub': 'the Arthashastra restores his stature', 'color': '#166534'},
      ], edge_labels=['then', 'until'], takeaway='He vanished into legend, then a single rediscovered manuscript made him immortal as a theorist of power.', accent=AC),
      bg='As with his birth, Chanakya’s death survives only in conflicting legends, traditionally placed <b>around 283 BC</b>, near the end of Bindusara’s early reign.',
      people='<b>Subandhu</b>, the rival minister of the death legend; <b>Bindusara</b>, the emperor he served; <b>R. Shamasastry</b>, who rediscovered his text in 1905.',
      what='By legend Chanakya either <b>retired to the forest</b> or <b>starved himself to death</b> after the rival Subandhu turned the emperor against him. <b>[LEGEND]</b> After his death he was largely forgotten until the <b>Arthashastra was rediscovered in 1905</b> and published in 1915. <b>[HISTORY]</b>',
      crux='His afterlife proves the point of his life: <b>ideas outlast their author</b> — a lost manuscript, recovered, mattered more than any tomb.',
      conseq='Today he stands beside Machiavelli, Sun Tzu and Plato as a foundational thinker on statecraft, and a national symbol in India.',
      matters='The measure of Chanakya is not a documented life but a durable idea — the empire crumbled, yet his science of power endures.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Chanakya — also known as Kautilya and Vishnugupta — was the Brahmin strategist and philosopher who toppled the Nanda dynasty, made a commoner into the emperor Chandragupta Maurya, and became the architect and chief minister of India’s first great empire. Traditionally credited with the <b>Arthashastra</b>, the ancient world’s most complete manual of statecraft, espionage and war, he is the original <b>kingmaker</b>: the intellect behind the throne rather than upon it. Ruthless, systematic and centuries ahead of his time, he is the ultimate study in <b>realpolitik, the science of power, and the strategist who builds the king.</b></p>
<div class="ov-quote">“The ends justify the means.”<span>— the realpolitik long associated with the Arthashastra</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A Brahmin scholar masters the science of power at Takshashila → he is humiliated by the Nanda king and vows to destroy the dynasty → he finds and trains the young Chandragupta as his instrument → after a first defeat he learns to conquer the frontier before the capital → the Nandas fall and the Mauryan Empire is born → as chief minister he builds the state and sets down the Arthashastra → and, wrapped in legend to the end, he is restored to fame when his lost treatise resurfaces in 1905.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">📜</div><h4>The Arthashastra</h4><p>The ancient world’s great manual of statecraft, economics and war.</p></div>
  <div class="ov-card"><div class="i">👑</div><h4>The kingmaker</h4><p>Made an emperor and founded a dynasty from behind the throne.</p></div>
  <div class="ov-card"><div class="i">🕵️</div><h4>The spy state</h4><p>Theorised intelligence and deception as instruments of rule.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>Indian realpolitik</h4><p>‘Ends justify the means’ — eighteen centuries before Machiavelli.</p></div>
</div>
<div class="ov-lbl">Legend versus record — read with care</div>
<p class="ov-lead" style="font-size:15px">Almost everything about Chanakya’s <b>life</b> survives only in legends written centuries later, and even his authorship of the <i>Arthashastra</i> is debated. What is firmly historical is the <b>Mauryan Empire</b> he helped found and the <b>treatise</b> that bears his tradition. Throughout this guide, tales are marked <b>[LEGEND]</b> and firmer facts <b>[HISTORY]</b>.</p>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Brahmin of Taxila</b><small> c. 375–340 BC</small><p>Origins, Takshashila, and the world he judged.</p></div>
  <div><b>2 · The Vow</b><small> c. 322 BC</small><p>Humiliation, finding Chandragupta, building the revolt.</p></div>
  <div><b>3 · The Overthrow</b><small> c. 322–321 BC</small><p>The Nandas fall; the Mauryan Empire is born.</p></div>
  <div><b>4 · Architect of the State</b><small> c. 321–297 BC</small><p>Prime minister, the Arthashastra, and the spy state.</p></div>
  <div><b>5 · The Legacy</b><small> attributed – 283 BC</small><p>The Niti, poison legends, death and rediscovery.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Chandragupta Maurya', 'role': 'his protégé and king', 'color': '#166534',
     'bio': 'The youth Chanakya discovered, trained for years, and raised to the throne of Magadha to found the Mauryan Empire around 322 BC.',
     'rel': 'The king he made — the instrument of his vengeance and his vision.'},
    {'name': 'Dhana Nanda', 'role': 'the humiliating enemy', 'color': '#b91c1c',
     'bio': 'The last Nanda king, whose public insult at Pataliputra provoked Chanakya’s vow to destroy the dynasty — a vow fulfilled around 322–321 BC.',
     'rel': 'The enemy whose contempt created his own destroyer.'},
    {'name': 'Bindusara', 'role': 'the son he served', 'color': '#a16207',
     'bio': 'Chandragupta’s son and successor, under whom Chanakya continued as chief minister; father of the great emperor Ashoka.',
     'rel': 'The second emperor he served, bridging the dynasty toward Ashoka.'},
    {'name': 'Subandhu', 'role': 'the rival minister', 'color': '#78350f',
     'bio': 'A jealous court minister who, in the Jain legend, turned the emperor against Chanakya and engineered his downfall and death.',
     'rel': 'The court rival of his final, legendary undoing.'},
    {'name': 'R. Shamasastry', 'role': 'his rediscoverer', 'color': '#3730a3',
     'bio': 'The Sanskrit scholar who rediscovered the long-lost Arthashastra manuscript in 1905 and published it in 1915, restoring Chanakya’s stature.',
     'rel': 'The scholar who returned his masterwork to the world.'},
]

KEY_EVENTS = [
    ('c. 375 BC', 'Chanakya born', 'A Brahmin of legend — Kautilya, Vishnugupta.'),
    ('c. 350 BC', 'Teacher at Takshashila', 'Masters the Vedas and the science of statecraft.'),
    ('327–325 BC', 'Alexander invades', 'A foreign conqueror shakes the north-west.'),
    ('c. 322 BC', 'Humiliated by Dhana Nanda', 'Vows to uproot the Nanda dynasty.'),
    ('c. 322 BC', 'Finds Chandragupta', 'Discovers and trains his future king.'),
    ('c. 322–321 BC', 'The Nandas fall', 'Pataliputra taken; Dhana Nanda killed.'),
    ('c. 322 BC', 'Mauryan Empire founded', 'Kingmaker and chief minister.'),
    ('c. 300 BC', 'The Arthashastra', 'The great treatise on statecraft and power.'),
    ('c. 297 BC', 'Serves Bindusara', 'Ministry outlasts the first reign.'),
    ('c. 283 BC', 'Death (by legend)', 'Rediscovered in 1905 as a founding thinker.'),
]

MASTER = [
    {'year': 'c. 375 BC', 'age': 'born', 'phase': 'Brahmin of Taxila', 'title': 'Chanakya born', 'desc': 'A figure of legend.'},
    {'year': 'c. 350 BC', 'age': 'young', 'phase': 'Brahmin of Taxila', 'title': 'Teacher at Takshashila', 'desc': 'Masters statecraft.'},
    {'year': 'c. 322 BC', 'age': 'mature', 'phase': 'The Vow', 'title': 'The Nanda humiliation', 'desc': 'Vows revenge.'},
    {'year': 'c. 322–321 BC', 'age': '—', 'phase': 'The Overthrow', 'title': 'Nandas fall', 'desc': 'Mauryan Empire born.'},
    {'year': 'c. 300 BC', 'age': 'elder', 'phase': 'Architect of the State', 'title': 'The Arthashastra', 'desc': 'The science of power.'},
    {'year': 'c. 283 BC', 'age': 'died', 'phase': 'The Legacy', 'title': 'Death and afterlife', 'desc': 'Rediscovered in 1905.'},
]

SOURCES = [
    ('Britannica — Chanakya (Kautilya)', 'https://www.britannica.com/biography/Kautilya'),
    ('World History Encyclopedia — Chanakya', 'https://www.worldhistory.org/Chanakya/'),
    ('Britannica — Arthashastra', 'https://www.britannica.com/topic/Artha-shastra'),
    ('Britannica — Chandragupta / Mauryan Empire', 'https://www.britannica.com/biography/Chandragupta-Maurya'),
    ('Wikipedia — Chanakya', 'https://en.wikipedia.org/wiki/Chanakya'),
]

def build_meta():
    return {
        'pid': 'gm-chanakya.html', 'kind': 'man', 'emoji': '📜', 'accent': AC,
        'name': 'Chanakya', 'years': 'c. 375–283 BC', 'group': 'Indian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Brahmin kingmaker who toppled the Nandas, forged the Mauryan Empire around his protégé Chandragupta, and wrote the Arthashastra — the ancient world’s coldest manual of statecraft, espionage and power.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'making', 'label': '1 · The Brahmin of Taxila', 'type': 'timeline',
             'intro': 'A Brahmin scholar of three names masters the science of statecraft at Takshashila, in a north India menaced by a hated Nanda dynasty and Alexander’s invasion.', 'events': PHASE_MAKING},
            {'id': 'vow', 'label': '2 · The Vow', 'type': 'timeline',
             'intro': 'Publicly humiliated by the Nanda king, Chanakya vows revenge — finding and training the young Chandragupta and assembling the money, allies and spies for a revolt.', 'events': PHASE_VOW},
            {'id': 'overthrow', 'label': '3 · The Overthrow', 'type': 'timeline',
             'intro': 'A first assault fails and teaches him to take the frontier before the capital; the Nandas fall around 322–321 BC and the Mauryan Empire is born with his protégé on the throne.', 'events': PHASE_OVERTHROW},
            {'id': 'state', 'label': '4 · Architect of the State', 'type': 'timeline',
             'intro': 'As chief minister he builds the machinery of empire — bureaucracy, taxation and army — and sets down his principles in the Arthashastra, running a state on intelligence and deception.', 'events': PHASE_STATE},
            {'id': 'legacy', 'label': '5 · The Legacy', 'type': 'timeline',
             'intro': 'The Chanakya Niti, the dark poison legends of Bindusara’s birth, and a clouded death — after which his lost treatise resurfaces in 1905 to restore him as a founding thinker on power.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Chanakya’s life is known only through Buddhist, Jain and Kashmiri legends composed centuries later, and even his authorship of the Arthashastra is debated; tales are flagged [LEGEND] and firmer facts [HISTORY] throughout.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
