# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Kālidāsa.
The classical Sanskrit poet and dramatist, widely regarded as the greatest writer in the language."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#6d28d9'  # deep poetic violet

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAN BEHIND THE MYTH
PHASE_MAN = [
    E('legend', 'tradition', 'The dullard blessed by the goddess Kālī', ['LEGEND', 'ORIGINS'],
      'By popular tradition — not history — Kālidāsa began as a witless herdsman, tricked by insulted scholars into marrying the learned princess Vidyottamā; humiliated and cast out, he prayed at a temple of the goddess Kālī, who granted him wisdom and eloquence, so that his very name came to mean "servant of Kālī."',
      svg_row('A legend of transformation (tradition, not fact)', [
          {'n': 1, 'label': 'A witless herdsman', 'sub': 'said to be barely able to speak', 'color': '#78350f'},
          {'n': 2, 'label': 'Blessed by the goddess Kālī', 'sub': 'granted wisdom and eloquence', 'color': '#6d28d9'},
          {'n': 3, 'label': '“Kālī-dāsa,” servant of Kālī', 'sub': 'the name of India’s greatest poet', 'color': '#166534'},
      ], edge_labels=['prays to', 'becomes'], takeaway='The legend is folklore, not record — but it names a truth: almost nothing certain is known of the man behind the poems.', accent=AC),
      bg='Almost nothing is known of Kālidāsa’s life; the biography that survives is <b>legend and inference</b> from his own verses. The most famous tale is a devotional folk story of much later date.',
      people='the goddess <b>Kālī</b>, his patron in the legend; the princess <b>Vidyottamā</b>, the learned wife who is said to have spurned and then inspired him; the jealous scholars who plotted the match.',
      what='Tradition holds Kālidāsa was a <b>dull, uneducated man</b> whom Brahmin scholars, humiliated in debate by the princess Vidyottamā, married to her in revenge; discovering his ignorance she drove him out, whereupon he worshipped <b>Kālī</b> and rose as a <b>poet of genius</b>.',
      crux='The story explains his name — <b>Kālidāsa = “servant of Kālī”</b> — and frames his gift as a <b>divine grace</b> rather than mere learning.',
      conseq='It is a beloved but <b>unhistorical</b> legend; scholars treat it as devotional folklore layered onto a poet whose real life is lost.',
      matters='When a life vanishes, myth rushes in — Kālidāsa the man dissolved into Kālidāsa the miracle, so that only the poems remain as evidence.'),

    E('dating', 'c. 4th–5th c. CE', 'When did he live? The dating puzzle', ['CONTEXT', 'DEBATE'],
      'No inscription fixes his dates, so scholars reconstruct them from his poetry and the kings he praises — the dominant view placing him in the golden age of the Gupta empire, most likely at the court of Chandragupta II "Vikramāditya" (r. c. 380–415 CE), though rival theories stretch across centuries.',
      svg_stack('Reading a life out of the poems', [
          {'n': 1, 'label': 'No firm record survives', 'sub': 'no inscription, no dated colophon', 'color': '#78350f'},
          {'n': 2, 'label': 'The Gupta “golden age” theory', 'sub': 'flourished c. 4th–5th century CE', 'color': '#6d28d9'},
          {'n': 3, 'label': 'Likely under Chandragupta II', 'sub': '“Vikramāditya,” r. c. 380–415 CE', 'color': '#166534'},
      ], takeaway='The scholarly consensus places him in the Gupta golden age — but the date remains an inference, not a certainty.', accent=AC),
      bg='Kālidāsa left <b>no autobiographical statement and no securely datable record</b>. His era is deduced from language, allusions, and the political world reflected in his work.',
      people='the emperor <b>Chandragupta II</b>, titled Vikramāditya, the leading candidate for his patron; later Gupta rulers <b>Kumāragupta I</b> and <b>Skandagupta</b>, into whose reigns his career may have run.',
      what='The <b>most widely held view</b> places Kālidāsa in the <b>Gupta era (4th–5th c. CE)</b>, at or near the court of <b>Chandragupta II “Vikramāditya.”</b> Rival theories range from the 1st c. BCE to the 6th c. CE, but the Gupta dating dominates modern scholarship.',
      crux='His dating rests on <b>circumstantial evidence</b> — refined courtly Sanskrit, mastery presupposing a mature literary culture, and a golden-age confidence that fits the Gupta zenith.',
      conseq='Anchoring him to the Guptas makes him the <b>literary crown of India’s classical age</b>, contemporary with its greatest political and artistic flowering.',
      matters='Great art is dated by its shadow — Kālidāsa is placed in history less by documents than by the civilisation his verses could only have grown from.'),

    E('navaratna', 'tradition', 'The “nine gems” of Vikramāditya’s court', ['LEGEND', 'CONTEXT'],
      'Tradition names Kālidāsa the foremost of the navaratna — the "nine gems" said to have adorned the court of a King Vikramāditya at Ujjain — and his own Meghadūta lavishes such loving detail on Ujjayinī that many read the city as his home, the setting that shaped his poetry of season, love, and longing.',
      svg_row('Poet of Ujjayinī and the nine gems', [
          {'n': 1, 'label': 'The navaratna tradition', 'sub': 'nine gems of Vikramāditya’s court', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Kālidāsa named the foremost', 'sub': 'chief ornament among the nine', 'color': '#b45309'},
          {'n': 3, 'label': 'A poet at home in Ujjain', 'sub': 'lovingly evoked in the Meghadūta', 'color': '#166534'},
      ], edge_labels=['names him', 'set in'], takeaway='Legend crowns him first of the nine gems; his verse betrays a deep love of Ujjain, the cultural capital of the age.', accent=AC),
      bg='A later tradition lists <b>nine luminaries (navaratna)</b> — poets, physicians and astronomers — at the court of a king <b>Vikramāditya</b> of Ujjain, with Kālidāsa placed at their head.',
      people='the legendary <b>Vikramāditya</b> of Ujjain, a title claimed by several kings including Chandragupta II; fellow “gems” of tradition such as the astronomer Varāhamihira and the lexicographer Amarasiṃha.',
      what='Kālidāsa is remembered as the <b>chief of the navaratna</b>; the historicity of that court list is doubtful, but his intimate, glowing portrait of <b>Ujjayinī (Ujjain)</b> in the Meghadūta suggests a real bond with the city.',
      crux='Whether or not the nine-gems court existed, the tradition marks Kālidāsa as the <b>supreme ornament of a royal, cosmopolitan literary culture</b> centred on Ujjain.',
      conseq='It fused his memory permanently with <b>Vikramāditya and Ujjain</b>, and with the ideal of the poet-scholar honoured at a splendid court.',
      matters='Cultures remember their poets by the courts that prized them — the navaratna legend enshrines Kālidāsa as the jewel of India’s classical golden age.'),

    E('corpus', 'his life’s work', 'Seven works, three genres', ['WORKS', 'OVERVIEW'],
      'The genuine Kālidāsa canon is small and luminous: three plays, two grand epics (mahākāvya), and two lyric poems — a body of only seven works, yet enough to make him, in Britannica’s words, "probably the greatest Indian writer of any epoch."',
      svg_stack('A compact, luminous canon', [
          {'n': 1, 'label': 'Three plays (nāṭaka)', 'sub': 'Mālavikāgnimitram · Vikramōrvaśīyam · Śākuntalam', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Two epics (mahākāvya)', 'sub': 'Raghuvaṃśa · Kumārasambhava', 'color': '#b45309'},
          {'n': 3, 'label': 'Two lyric poems (khaṇḍakāvya)', 'sub': 'Meghadūta · Ṛtusaṃhāra', 'color': '#166534'},
      ], takeaway='Seven works span drama, epic and lyric — and each became a model of its form for the whole later tradition.', accent=AC),
      bg='Of the many works attributed to him over the centuries, scholars accept <b>seven as genuinely Kālidāsa’s</b>, spread across the three great forms of Sanskrit courtly literature.',
      people='the whole later tradition of Sanskrit poets and critics who took these seven works as <b>textbook models</b> of drama, epic and lyric.',
      what='The accepted canon is <b>three plays</b> (Mālavikāgnimitram, Vikramōrvaśīyam, Abhijñānaśākuntalam), <b>two epics</b> (Raghuvaṃśa, Kumārasambhava), and <b>two lyric poems</b> (Meghadūta, Ṛtusaṃhāra).',
      crux='His greatness lies not in volume but in <b>perfection across every genre</b> — he set the standard for drama, epic and lyric alike.',
      conseq='Each work became a <b>classic and a model</b>, studied and imitated for more than a thousand years.',
      matters='A handful of flawless works can outweigh libraries — Kālidāsa’s seven titles anchor the entire canon of classical Sanskrit.'),
]

# ==================================================================  PHASE 2 — THE PLAYS
PHASE_PLAYS = [
    E('malavika', 'a play', 'Mālavikāgnimitram — the first play', ['WORK', 'DRAMA'],
      'His probable first play, the Mālavikāgnimitram, is a light court comedy: King Agnimitra falls in love with a portrait of Mālavikā, a maidservant, and against the jealousy of his queens the intrigue resolves when she is revealed to be a true-born princess — a polished, worldly debut set at a real historical court.',
      svg_row('A comedy of the harem and the portrait', [
          {'n': 1, 'label': 'A king in love with a picture', 'sub': 'Agnimitra sees the servant Mālavikā', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Jealous queens intervene', 'sub': 'the girl is imprisoned in rage', 'color': '#b45309'},
          {'n': 3, 'label': 'She is a hidden princess', 'sub': 'true birth legitimises the match', 'color': '#166534'},
      ], edge_labels=['then', 'until'], takeaway='A witty, worldly court comedy — modest beside his later work, but already a master of stagecraft and intrigue.', accent=AC),
      bg='The <b>Mālavikāgnimitram</b> is generally taken as Kālidāsa’s <b>earliest surviving play</b>, a five-act romantic comedy of court intrigue.',
      people='<b>King Agnimitra</b> (a historical Śuṅga-dynasty ruler); the maidservant <b>Mālavikā</b>; the jealous senior queens; the vidūṣaka (comic Brahmin companion) who aids the king.',
      what='Agnimitra falls for a <b>portrait of Mālavikā</b>, an exiled servant girl; the queens imprison her, but she is at last shown to be a <b>true-born princess</b>, so the love match is honourably completed.',
      crux='Even in this lighter register Kālidāsa displays <b>deft stagecraft, dance, and comic intrigue</b> — the machinery of Sanskrit court drama handled with ease.',
      conseq='It established him as a dramatist and rehearsed themes — love, obstruction, recognition — he would deepen in his masterpieces.',
      matters='Great artists announce themselves in miniature — the assured comedy of his debut foretold the tragic-romantic power to come.'),

    E('vikramorvasiya', 'a play', 'Vikramōrvaśīyam — Ūrvaśī won by valour', ['WORK', 'DRAMA'],
      'In the Vikramōrvaśīyam, "Ūrvaśī Won by Valour," the mortal king Purūravas loves the celestial nymph Ūrvaśī; separated, cursed, and maddened by loss, he wanders the forest questioning beasts and clouds for her — a play whose famous "mad scene" turns grief into some of Kālidāsa’s most rapturous lyric poetry.',
      svg_stack('A king, a nymph, and a maddening loss', [
          {'n': 1, 'label': 'Purūravas loves the nymph Ūrvaśī', 'sub': 'a mortal king and a celestial apsarā', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Separated and driven to madness', 'sub': 'he roams the forest half-crazed by loss', 'color': '#b45309'},
          {'n': 3, 'label': 'Reunion after curse and trial', 'sub': 'love regained across heaven and earth', 'color': '#166534'},
      ], takeaway='Its celebrated “mad scene,” where the grieving king begs the forest for news of his love, is pure lyric rapture.', accent=AC),
      bg='The <b>Vikramōrvaśīyam</b> (“Ūrvaśī Won by Valour”) dramatises an ancient Vedic legend of the love of a mortal king for a heavenly nymph.',
      people='<b>King Purūravas</b>; the apsarā <b>Ūrvaśī</b>, sent from heaven; the celestial powers whose curse forces her return; the child whose birth threatens their union.',
      what='Purūravas and Ūrvaśī fall in love and are cruelly parted; the <b>fourth act</b> shows the king wandering the forest, <b>mad with grief</b>, addressing animals, rivers and clouds — before curse and trial are lifted and the lovers reunite.',
      crux='Kālidāsa fuses <b>drama with lyric</b>, letting the king’s madness pour out as some of the most intense nature-poetry in the corpus.',
      conseq='The play became famous for its <b>emotional extremity and lyrical richness</b>, a bridge between the light comedy of his debut and the depth of Śākuntala.',
      matters='He showed that a play could be a poem — that dramatic grief, fully sung, could carry an audience beyond mere plot into feeling itself.'),

    E('shakuntala-plot', 'his masterpiece', 'Abhijñānaśākuntalam — the story', ['WORK', 'MASTERPIECE'],
      'His crowning work, the Abhijñānaśākuntalam, tells how King Duṣyanta, hunting in the forest, loves and secretly weds the hermitage-raised Śakuntalā — daughter of the sage Viśvāmitra and the nymph Menakā — giving her his signet ring before returning to his capital.',
      svg_row('A love born in the forest hermitage', [
          {'n': 1, 'label': 'Duṣyanta hunts in the forest', 'sub': 'and enters sage Kaṇva’s hermitage', 'color': '#6d28d9'},
          {'n': 2, 'label': 'He weds Śakuntalā in secret', 'sub': 'a love-match (gāndharva) marriage', 'color': '#b45309'},
          {'n': 3, 'label': 'He leaves her his signet ring', 'sub': 'a token of recognition, then departs', 'color': '#166534'},
      ], edge_labels=['where', 'and'], takeaway='Kālidāsa transforms a bare Mahābhārata episode into a tender drama of love, memory, and reunion.', accent=AC),
      bg='The <b>Abhijñānaśākuntalam</b> (“The Recognition of Śakuntalā”), a seven-act drama, is Kālidāsa’s <b>masterpiece</b>, reworked from an episode in the Mahābhārata.',
      people='<b>King Duṣyanta</b>; <b>Śakuntalā</b>, daughter of the sage <b>Viśvāmitra</b> and the apsarā <b>Menakā</b>, raised by the sage <b>Kaṇva</b>; the son she bears, Bharata.',
      what='While hunting, Duṣyanta enters a forest hermitage, falls in love with <b>Śakuntalā</b>, and marries her by mutual consent, <b>leaving his signet ring</b> as a pledge before returning to court.',
      crux='Kālidāsa deepens the crude legend into a study of <b>love, separation and recognition</b>, framed by the beauty and moral order of the hermitage.',
      conseq='This opening sets up the play’s central engine — a curse and a lost ring that will test the lovers to the edge of tragedy.',
      matters='A source is only raw material — Kālidāsa’s genius was to turn a folk anecdote into one of world drama’s tenderest love stories.'),

    E('shakuntala-ring', 'his masterpiece', 'The curse and the ring of recognition', ['WORK', 'ARTISTRY'],
      'The play’s heart is Kālidāsa’s own invention: Śakuntalā, lost in longing, slights the irascible sage Durvāsa, who curses her so that Duṣyanta will forget her until he sees a token — and when the fatal ring slips from her finger and is later found in a fish’s belly by a fisherman, the king’s memory returns and the lovers are reunited.',
      svg_stack('A curse, a lost ring, a recovered love', [
          {'n': 1, 'label': 'Durvāsa’s curse of forgetting', 'sub': 'the king will forget her — until a token', 'color': '#78350f'},
          {'n': 2, 'label': 'The ring is lost in the river', 'sub': 'and Duṣyanta denies ever knowing her', 'color': '#b45309'},
          {'n': 3, 'label': 'A fisherman finds it in a fish', 'sub': 'memory floods back; the lovers reunite', 'color': '#166534'},
      ], takeaway='The curse rescues Duṣyanta’s honour — his rejection is not cruelty but enchantment, and the ring redeems them both.', accent=AC),
      bg='To the Mahābhārata story, which shows a callous king denying his wife, Kālidāsa <b>added the curse of Durvāsa and the ring</b> — turning rejection into tragic magic rather than mere faithlessness.',
      people='the short-tempered sage <b>Durvāsa</b>, whose curse drives the plot; the humble <b>fisherman</b> who recovers the ring; Duṣyanta, cursed to forget; Śakuntalā, unjustly disowned.',
      what='Śakuntalā, distracted by love, <b>fails to greet Durvāsa</b>, who curses her to be forgotten until a token appears; she <b>loses the ring</b> bathing, the king disowns her, and only when a <b>fisherman finds the ring inside a fish</b> does his memory — and their love — return.',
      crux='The invented device shifts the play from <b>blame to compassion</b>: Duṣyanta is a victim of enchantment, and the reunion feels earned, not merely arranged.',
      conseq='The “ring of recognition” became one of the most celebrated plot devices in world literature and gave the play its very name (abhijñāna = token of recognition).',
      matters='A single added motif can redeem a whole story — Kālidāsa’s curse-and-ring turned a tale of male fickleness into a drama of fate, memory and grace.'),
]

# ==================================================================  PHASE 3 — THE TWO EPICS
PHASE_EPICS = [
    E('raghuvamsa', 'a mahākāvya', 'Raghuvaṃśa — the dynasty of Raghu', ['WORK', 'EPIC'],
      'The Raghuvaṃśa, "The Dynasty of Raghu," is a grand epic in nineteen cantos tracing the solar kings of Rama’s line from mythic founders through the ideal reign of Rama himself to the dynasty’s decline — a sweeping meditation on kingship, dharma, and the rise and fall of a royal house.',
      svg_row('The rise and fall of a royal line', [
          {'n': 1, 'label': 'The kings of Raghu’s line', 'sub': 'the solar dynasty, ancestors of Rama', 'color': '#6d28d9'},
          {'n': 2, 'label': 'The ideal reign of Rama', 'sub': 'dharma and kingship at their height', 'color': '#b45309'},
          {'n': 3, 'label': 'Decline of the dynasty', 'sub': 'greatness followed by falling-off', 'color': '#78350f'},
      ], edge_labels=['to', 'then'], takeaway='In 19 cantos Kālidāsa turns dynastic history into a study of ideal — and failing — kingship.', accent=AC),
      bg='The <b>Raghuvaṃśa</b> is one of Kālidāsa’s two <b>mahākāvyas</b> (grand court epics), in <b>nineteen cantos</b>, narrating the legendary solar dynasty into which Rama was born.',
      people='the kings of the <b>Raghu (Ikṣvāku/solar) line</b> — Dilīpa, Raghu, Aja, Daśaratha, and above all <b>Rama</b> — down to their less worthy descendants.',
      what='The poem follows the dynasty across generations: heroic founders, the <b>exemplary rule of Rama</b>, and finally kings whose weakness brings the line to <b>decline</b> — a full arc of royal glory and decay.',
      crux='Kālidāsa uses dynastic narrative to explore <b>the ideal of the righteous king (rājadharma)</b> and the fragility of greatness across time.',
      conseq='The Raghuvaṃśa became a <b>model mahākāvya</b>, endlessly studied for its poetry and its vision of dharmic kingship.',
      matters='Epic here is moral philosophy in narrative form — the measure of a king, and of a dynasty, tested across the long span of history.'),

    E('kumarasambhava', 'a mahākāvya', 'Kumārasambhava — the birth of the war-god', ['WORK', 'EPIC'],
      'The Kumārasambhava, "The Birth of Kumāra," recounts how the gods, threatened by a demon only Śiva’s son can slay, contrive the wooing of the ascetic Śiva by the mountain-daughter Pārvatī — moving through her penance and their divine wedding toward the birth of the war-god Kumāra (Kārttikeya).',
      svg_stack('Divine love with a cosmic purpose', [
          {'n': 1, 'label': 'A demon only Śiva’s son can kill', 'sub': 'the gods need an heir to Śiva', 'color': '#78350f'},
          {'n': 2, 'label': 'Pārvatī wins the ascetic Śiva', 'sub': 'through beauty, penance and devotion', 'color': '#6d28d9'},
          {'n': 3, 'label': 'The war-god Kumāra is born', 'sub': 'Kārttikeya, destined to slay the demon', 'color': '#166534'},
      ], takeaway='Kālidāsa sets a tender divine romance inside a cosmic rescue — love as the salvation of the gods themselves.', accent=AC),
      bg='The <b>Kumārasambhava</b> (“The Birth of Kumāra/Kārttikeya”), Kālidāsa’s second mahākāvya, tells a great myth of Śiva and Pārvatī.',
      people='the ascetic god <b>Śiva</b>; the mountain-daughter <b>Pārvatī</b>; the love-god <b>Kāma</b>, burned to ash for disturbing Śiva’s meditation; the war-god <b>Kumāra (Kārttikeya)</b>, whose birth is the goal.',
      what='To defeat a demon invincible to all but Śiva’s offspring, the gods engineer the union of <b>Śiva and Pārvatī</b>; the poem moves through Kāma’s fatal intervention, Pārvatī’s <b>austerities</b>, and the <b>divine wedding</b> toward the birth of the war-god.',
      crux='Kālidāsa weds <b>erotic beauty (śṛṅgāra) to cosmic necessity</b>, and famously dares to depict the love of the great gods themselves.',
      conseq='Its sensuous poetry made it celebrated — and, in later ages, sometimes controversial — as a supreme example of the mahākāvya.',
      matters='He made the divine intimate — rendering even the loves of gods in warm, human, sensuous verse without losing their grandeur.'),
]

# ==================================================================  PHASE 4 — THE LYRIC POEMS
PHASE_LYRIC = [
    E('meghaduta', 'a lyric poem', 'Meghadūta — the Cloud Messenger', ['WORK', 'LYRIC', 'MASTERPIECE'],
      'The Meghadūta, "The Cloud Messenger," is Kālidāsa’s most beloved lyric: a yakṣa, banished by his lord Kubera and pining for his wife, begs a passing monsoon cloud to carry his message of love across the whole of India — from the hill of Rāmagiri to the celestial city of Alakā on Mount Kailāsa — inventing the "messenger poem" as a form.',
      svg_row('A love-letter carried by a cloud', [
          {'n': 1, 'label': 'A yakṣa exiled from Alakā', 'sub': 'banished a year by his lord Kubera', 'color': '#6d28d9'},
          {'n': 2, 'label': 'He hails a passing rain-cloud', 'sub': 'and begs it to bear his message', 'color': '#b45309'},
          {'n': 3, 'label': 'Across India to his grieving wife', 'sub': 'to Alakā on Mount Kailāsa', 'color': '#166534'},
      ], edge_labels=['so', 'flying'], takeaway='A whole poem addressed to a cloud — and the founding masterpiece of the Sanskrit “messenger” genre.', accent=AC),
      bg='The <b>Meghadūta</b> is a short lyric poem (khaṇḍakāvya) of about <b>110 stanzas</b> in the stately, flowing <b>mandākrāntā</b> metre, prized for its musical sweetness.',
      people='the exiled <b>yakṣa</b> (a nature-spirit in the service of the wealth-god <b>Kubera</b>); his distant, grieving <b>wife</b> in Alakā; the <b>cloud</b> itself, addressed as a living messenger.',
      what='Separated from his wife by a year’s exile, the yakṣa asks a <b>monsoon cloud</b> to fly north to <b>Alakā</b> and deliver his love; the first half maps the <b>cloud’s journey</b> over the landscape of India, the second describes the city and the message.',
      crux='The poem’s beauty lies in its <b>fusion of landscape, longing and imagination</b> — geography transfigured into an itinerary of desire.',
      conseq='The Meghadūta founded the <b>sandeśa-kāvya (“messenger poem”)</b> genre and was imitated for centuries; its evocation of Ujjain ties Kālidāsa to that city.',
      matters='Longing given a route and a courier becomes unforgettable — Kālidāsa made a cloud the vehicle of the human heart, and invented a genre doing it.'),

    E('ritusamhara', 'a lyric poem', 'Ṛtusaṃhāra — the pageant of the seasons', ['WORK', 'LYRIC'],
      'The Ṛtusaṃhāra, "The Gathering of the Seasons," is a lyrical cycle — possibly his earliest work — that leads the reader through the six Indian seasons, from scorching summer through the longed-for monsoon to spring, weaving the moods of lovers into the changing face of nature in a sustained hymn to the year.',
      svg_stack('The turning year as a poem of love', [
          {'n': 1, 'label': 'The six seasons in turn', 'sub': 'from blazing summer to blossoming spring', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Nature mirrors the lovers’ moods', 'sub': 'each season coloured by desire', 'color': '#b45309'},
          {'n': 3, 'label': 'A sustained hymn to the year', 'sub': 'perhaps his earliest surviving work', 'color': '#166534'},
      ], takeaway='A youthful, sensuous cycle that binds the rhythm of the seasons to the moods of love.', accent=AC),
      bg='The <b>Ṛtusaṃhāra</b> (“Medley/Gathering of the Seasons”) is a lyric poem describing the <b>six seasons</b> of the Indian year; many scholars regard it as an <b>early</b>, possibly juvenile, work.',
      people='the anonymous <b>lovers</b> whose feelings colour each season; nature itself — heat, rain, moonlight and flowers — as the poem’s true subject.',
      what='Across its cantos the poem moves through <b>summer, the rains, autumn, early winter, winter and spring</b>, matching each to the emotions of lovers and the life of the natural world.',
      crux='It shows Kālidāsa’s lifelong gift early: the <b>intertwining of human emotion with the natural world</b>, season by season.',
      conseq='Its very simplicity and youthful sensuousness led some to doubt it, but it is generally accepted as an <b>early Kālidāsa</b>, and William Jones printed its text in 1792.',
      matters='The seed of the master is here — even a probable first work reveals his signature marriage of feeling and landscape.'),
]

# ==================================================================  PHASE 5 — THE ART OF KĀLIDĀSA
PHASE_ART = [
    E('upama', 'his art', '“Upamā Kālidāsasya” — the master of simile', ['ARTISTRY', 'STYLE'],
      'A famous Sanskrit maxim, "Upamā Kālidāsasya," crowns Kālidāsa as unrivalled in simile — his poetry celebrated for images of startling aptness and beauty, an economy that says much in little, and a serene control that made later critics treat him as the very standard of poetic taste.',
      svg_row('Why the tradition made him the standard', [
          {'n': 1, 'label': 'Unmatched in simile (upamā)', 'sub': '“Upamā Kālidāsasya” — the maxim', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Suggestion over ornament', 'sub': 'depth of feeling, economy of means', 'color': '#b45309'},
          {'n': 3, 'label': 'The standard of good taste', 'sub': 'the model later poets measured against', 'color': '#166534'},
      ], edge_labels=['plus', 'made him'], takeaway='Later critics judged Sanskrit poetry by how near it came to Kālidāsa — he was the benchmark of taste itself.', accent=AC),
      bg='Sanskrit critics singled out Kālidāsa’s <b>similes (upamā)</b> as supreme — the proverb <b>“Upamā Kālidāsasya”</b> (“for simile, Kālidāsa”) became a byword for his mastery.',
      people='the later <b>ālaṃkārika</b> (poetic theorists) and generations of poets who took his verse as the model of excellence.',
      what='His art is marked by <b>apt, luminous similes</b>, <b>emotional depth achieved with restraint</b>, and a preference for <b>suggestion (dhvani)</b> over mere ornament — beauty that feels effortless.',
      crux='His signature is <b>balance</b>: sensuous richness held in perfect classical control, feeling and form in equilibrium.',
      conseq='He became the <b>touchstone of taste</b> in Sanskrit poetics, the standard against which all later poetry was judged.',
      matters='To be made the yardstick of an entire tradition is the rarest praise — Kālidāsa was not just a great poet but the definition of one.'),

    E('rasa', 'his art', 'Nature, rasa, and the harmony of worlds', ['ARTISTRY', 'IDEAS'],
      'Kālidāsa’s deepest theme is harmony — between human passion and the natural world, between the erotic and the ascetic, the court and the forest hermitage — and his plays, mingling refined Sanskrit for kings with softer Prakrit for women and commoners, resolve the tumult of love (śṛṅgāra) into serenity and dharmic order.',
      svg_stack('The reconciliation of opposites', [
          {'n': 1, 'label': 'Passion and the natural world', 'sub': 'human feeling mirrored in landscape', 'color': '#6d28d9'},
          {'n': 2, 'label': 'The erotic meets the ascetic', 'sub': 'court and forest hermitage in balance', 'color': '#b45309'},
          {'n': 3, 'label': 'Love resolved into order', 'sub': 'śṛṅgāra ripening into dharma', 'color': '#166534'},
      ], takeaway='His art moves through desire and disturbance toward serenity — beauty always tending, at last, to harmony.', accent=AC),
      bg='Across every genre Kālidāsa dwells on the <b>correspondence between human emotion and nature</b>, and on the balance of worldly love with spiritual order.',
      people='his kings and gods torn between <b>desire and duty</b>; his heroines rooted in the natural, hermitage world; the rasa (aesthetic emotion) theorists who prized his work.',
      what='He is the supreme poet of <b>śṛṅgāra (love)</b>, yet always turns it toward <b>reconciliation</b> — the forest and the court, the ascetic and the erotic, passion and dharma brought into accord; his plays even mix <b>Sanskrit and Prakrit</b> to voice this social harmony.',
      crux='His governing vision is <b>concord</b> — that beauty and desire, rightly understood, lead not to chaos but to a deeper order.',
      conseq='This serene, integrative vision is why he reads as the <b>calm classical centre</b> of Indian literature.',
      matters='Art that reconciles rather than merely excites endures longest — Kālidāsa’s harmony of love and order gives his work its timeless poise.'),
]

# ==================================================================  PHASE 6 — REDISCOVERY AND LEGACY
PHASE_LEGACY = [
    E('jones', '1789', 'Sir William Jones opens Śakuntalā to Europe', ['RECEPTION', 'TURNING POINT'],
      'In 1789 the Orientalist scholar-judge Sir William Jones, working in Calcutta, published the first English translation of the Abhijñānaśākuntalam — followed in 1792 by the Ṛtusaṃhāra, the first Sanskrit text ever printed — and a masterpiece unknown to the West for over a thousand years suddenly electrified Europe.',
      svg_row('A thousand-year-old play reaches the West', [
          {'n': 1, 'label': 'Jones in Calcutta, 1789', 'sub': 'translates Śakuntalā into English', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Ṛtusaṃhāra printed, 1792', 'sub': 'the first Sanskrit text ever published', 'color': '#b45309'},
          {'n': 3, 'label': 'Europe discovers Kālidāsa', 'sub': 'quickly rendered into German and beyond', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='One translation lifted Kālidāsa from an unknown language into a living force in European letters.', accent=AC),
      bg='<b>Sir William Jones</b> (1746–1794), founder of the Asiatic Society of Bengal and a pioneer of comparative linguistics, sought to make Sanskrit literature known to Europe.',
      people='<b>William Jones</b>, translator and judge in Calcutta; the European scholars and poets who read him; the Sanskrit pandits who taught him.',
      what='Jones published his English <b>“Sacontalá”</b> in <b>1789</b>, and in <b>1792</b> issued the Sanskrit text of the <b>Ṛtusaṃhāra</b> — the <b>first Sanskrit work ever to be printed</b> — bringing Kālidāsa before a Western audience for the first time.',
      crux='His translation was a <b>bridge between civilisations</b>, revealing a classical Indian literature to rival Greece and Rome.',
      conseq='Rendered from English into German, the play swept through Romantic Europe, admired by Herder, Goethe and the German Romantics.',
      matters='A single act of translation can enlarge the world’s imagination — Jones handed Europe a new classic and helped found the study of Indian literature.'),

    E('goethe', '1791', 'Goethe’s rapture — “I name thee, Śakuntalā”', ['RECEPTION', 'LEGACY'],
      'Reading the play in translation, Johann Wolfgang von Goethe wrote a famous epigram exalting Śakuntalā as heaven and earth combined in a single name — "I name thee, O Śakuntalā! and all at once is said" — and is widely believed to have modelled the "Prelude on the Stage" of his Faust on Kālidāsa’s theatrical prologue.',
      svg_stack('Kālidāsa enters world literature', [
          {'n': 1, 'label': 'Goethe reads Śakuntalā, 1791', 'sub': 'in German, from Jones’s English', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Writes his famous epigram', 'sub': '“I name thee, O Śakuntalā!”', 'color': '#b45309'},
          {'n': 3, 'label': 'Echoes in Faust’s prologue', 'sub': 'said to inspire the “Prelude on the Stage”', 'color': '#166534'},
      ], takeaway='Europe’s greatest poet bowed to India’s — proof that Kālidāsa spoke across languages, ages and worlds.', accent=AC),
      bg='By the 1790s the translated Śakuntalā was the sensation of literary Europe; <b>Goethe</b>, the towering figure of German letters, was among its most fervent admirers.',
      people='<b>Johann Wolfgang von Goethe</b>; fellow admirers such as <b>Herder</b> and the Romantic circle; later, scholars who traced Śakuntalā’s influence on Faust.',
      what='Goethe wrote a celebrated quatrain: <b>“Wouldst thou the young year’s blossoms and the fruits of its decline … / I name thee, O Śakuntalā! and all at once is said,”</b> and is traditionally held to have drawn the <b>“Prelude on the Stage” in Faust</b> from Kālidāsa’s prologue.',
      crux='Goethe’s praise <b>canonised Kālidāsa in the West</b> as a world poet, not a curiosity — a peer of the European greats.',
      conseq='It cemented Kālidāsa’s international fame and made Śakuntalā a touchstone of Romantic and world literature.',
      matters='Recognition by a rival tradition’s summit is the surest immortality — Goethe’s tribute lifted Kālidāsa onto the world stage for good.'),

    E('legacy', 'to this day', 'The Shakespeare of India', ['LEGACY', 'TRIUMPH'],
      'Hailed by Monier Williams and others as "the Shakespeare of India," honoured in tradition as Kavikulaguru — "preceptor of the family of poets" — Kālidāsa endures as the acknowledged summit of Sanskrit literature, his Śakuntalā staged and translated worldwide and his verses woven into the cultural memory of India.',
      svg_row('The enduring summit of Sanskrit letters', [
          {'n': 1, 'label': '“The Shakespeare of India”', 'sub': 'so named by Monier Williams', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Kavikulaguru', 'sub': '“preceptor of the family of poets”', 'color': '#b45309'},
          {'n': 3, 'label': 'A living classic worldwide', 'sub': 'staged, translated, endlessly studied', 'color': '#166534'},
      ], edge_labels=['and', 'still'], takeaway='Whatever remains unknown of the man, the poet stands unchallenged as the greatest in his language.', accent=AC),
      bg='For fifteen centuries Kālidāsa has been regarded as the <b>supreme classical Sanskrit poet</b>, his works the core of the literary curriculum.',
      people='the critics who crowned him (<b>Monier Williams</b> and the tradition of Sanskrit poetics); the countless readers, students, dramatists and translators who keep his work alive.',
      what='Called the <b>“Shakespeare of India”</b> and revered as <b>Kavikulaguru</b>, Kālidāsa is the acknowledged <b>greatest writer in Sanskrit</b>; his Śakuntalā is performed and translated across the world, and his name honours institutions, awards and the arts in modern India.',
      crux='His stature rests on <b>perfection across every genre</b> allied to a humane, harmonious vision — technical mastery joined to universal feeling.',
      conseq='He remains a <b>living presence</b> in Indian culture and a fixture of world literature, the classical age’s enduring gift.',
      matters='The man is a mystery, but the work is immortal — Kālidāsa proves that a life can vanish and yet leave the age it belonged to defined by its art.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Kālidāsa is the acknowledged summit of classical Sanskrit literature — a poet and dramatist so complete that later tradition made him the very standard of poetic taste. Almost nothing certain is known of his life; he most likely flourished in the golden age of the Gupta empire (4th–5th c. CE), perhaps at the court of Chandragupta II “Vikramāditya,” and legend crowns him first of the “nine gems.” His seven surviving works — three plays, two epics, two lyric poems — perfect every genre they touch. When Sir William Jones translated his <i>Śakuntalā</i> in 1789, Europe was electrified and Goethe himself bowed to it. He is the ultimate study in <b>harmony, craft, and the immortality of art over biography.</b></p>
<div class="ov-quote">“I name thee, O Śakuntalā! and all at once is said.”<span>— Goethe, on Kālidāsa’s masterpiece</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A poet whose life dissolved into legend → placed by scholars in the Gupta golden age, jewel of Vikramāditya’s Ujjain → author of three plays crowned by the <i>Abhijñānaśākuntalam</i> with its curse and ring of recognition → of two grand epics on Raghu’s dynasty and the birth of the war-god → of the beloved lyric <i>Meghadūta</i>, a love-letter borne by a cloud → the master of simile and of harmony between passion and nature → rediscovered by Europe through Jones and Goethe, and immortal ever since as “the Shakespeare of India.”</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🪶</div><h4>Perfection in every genre</h4><p>Drama, epic and lyric — he set the model for each.</p></div>
  <div class="ov-card"><div class="i">💍</div><h4>The recognition of Śakuntalā</h4><p>His curse-and-ring turned folklore into world drama.</p></div>
  <div class="ov-card"><div class="i">☁️</div><h4>The Cloud Messenger</h4><p>Longing given a route and a courier — a genre invented.</p></div>
  <div class="ov-card"><div class="i">🌍</div><h4>A world poet</h4><p>Jones and Goethe made him a classic beyond India.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Man</b><small> myth &amp; dating</small><p>The Kālī legend, the Gupta age, the nine gems, the canon.</p></div>
  <div><b>2 · The Plays</b><small> drama</small><p>Mālavikā, Ūrvaśī, and the masterpiece Śakuntalā.</p></div>
  <div><b>3 · The Epics</b><small> mahākāvya</small><p>The dynasty of Raghu; the birth of the war-god.</p></div>
  <div><b>4 · The Lyrics</b><small> khaṇḍakāvya</small><p>The Cloud Messenger and the pageant of the seasons.</p></div>
  <div><b>5 · The Art</b><small> style</small><p>Master of simile; the harmony of passion and nature.</p></div>
  <div><b>6 · Legacy</b><small> 1789–</small><p>Jones, Goethe, and the Shakespeare of India.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the idea, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Works</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references. Because his biography is largely legendary, several events are flagged as <i>tradition</i> rather than fact.</p>
"""

WHO = [
    {'name': 'Chandragupta II', 'role': 'likely patron', 'color': '#6d28d9',
     'bio': 'The Gupta emperor (r. c. 380–415 CE), titled “Vikramāditya,” at or near whose brilliant court most scholars place Kālidāsa’s career.',
     'rel': 'The emperor whose golden age is thought to have been Kālidāsa’s.'},
    {'name': 'Śakuntalā', 'role': 'his greatest heroine', 'color': '#b45309',
     'bio': 'The hermitage-raised daughter of sage Viśvāmitra and the nymph Menakā, whose love, loss and recognition drive Kālidāsa’s masterpiece.',
     'rel': 'The heroine of the Abhijñānaśākuntalam, his crowning work.'},
    {'name': 'Duṣyanta', 'role': 'the forgetful king', 'color': '#166534',
     'bio': 'The hunting king who secretly weds Śakuntalā and, under Durvāsa’s curse, forgets her until the lost signet ring is found.',
     'rel': 'The hero of Śakuntalā, cursed to forget his own bride.'},
    {'name': 'Sir William Jones', 'role': 'European translator', 'color': '#0e7490',
     'bio': 'The Orientalist and Calcutta judge who published the first English translation of Śakuntalā (1789) and printed the Ṛtusaṃhāra (1792).',
     'rel': 'The scholar who opened Kālidāsa to the Western world.'},
    {'name': 'J. W. von Goethe', 'role': 'European admirer', 'color': '#a16207',
     'bio': 'The giant of German letters whose ecstatic epigram on Śakuntalā canonised Kālidāsa as a world poet across Europe.',
     'rel': 'The poet whose praise made Kālidāsa a global classic.'},
]

KEY_EVENTS = [
    ('c. 4th–5th c. CE', 'Flourished in the Gupta age', 'Likely under Chandragupta II “Vikramāditya.”'),
    ('a play', 'Mālavikāgnimitram', 'His probable first play, a court comedy.'),
    ('a play', 'Vikramōrvaśīyam', 'King Purūravas and the nymph Ūrvaśī.'),
    ('masterpiece', 'Abhijñānaśākuntalam', 'The curse of Durvāsa and the ring of recognition.'),
    ('epic', 'Raghuvaṃśa', 'The solar dynasty of Raghu, in 19 cantos.'),
    ('epic', 'Kumārasambhava', 'The birth of the war-god from Śiva and Pārvatī.'),
    ('lyric', 'Meghadūta', 'A yakṣa’s love borne across India by a cloud.'),
    ('lyric', 'Ṛtusaṃhāra', 'A cycle of the six Indian seasons.'),
    ('1789', 'Jones translates Śakuntalā', 'Kālidāsa reaches Europe for the first time.'),
    ('1791', 'Goethe’s epigram', '“I name thee, O Śakuntalā!”'),
]

MASTER = [
    {'year': 'tradition', 'age': 'legend', 'phase': 'The Man', 'title': 'The Kālī legend', 'desc': 'A dullard blessed into a poet.'},
    {'year': 'c. 4th–5th c.', 'age': 'Gupta age', 'phase': 'The Man', 'title': 'The Gupta golden age', 'desc': 'Likely under Chandragupta II.'},
    {'year': 'his plays', 'age': 'drama', 'phase': 'The Plays', 'title': 'Abhijñānaśākuntalam', 'desc': 'His masterpiece: the ring of recognition.'},
    {'year': 'his epics', 'age': 'mahākāvya', 'phase': 'The Epics', 'title': 'Raghuvaṃśa & Kumārasambhava', 'desc': 'Dynasty of Raghu; birth of the war-god.'},
    {'year': 'his lyrics', 'age': 'khaṇḍakāvya', 'phase': 'The Lyrics', 'title': 'Meghadūta', 'desc': 'The Cloud Messenger; a genre invented.'},
    {'year': '1789', 'age': 'reception', 'phase': 'Legacy', 'title': 'Jones & Goethe', 'desc': 'Rediscovered by Europe; a world classic.'},
]

SOURCES = [
    ('Britannica — Kalidasa', 'https://www.britannica.com/biography/Kalidasa'),
    ('Wikipedia — Kalidasa', 'https://en.wikipedia.org/wiki/Kalidasa'),
    ('Wikipedia — Abhijnanashakuntalam', 'https://en.wikipedia.org/wiki/Abhijnanashakuntalam'),
    ('Wikipedia — Meghaduta', 'https://en.wikipedia.org/wiki/Meghaduta'),
    ('Wikipedia — Raghuvamsha', 'https://en.wikipedia.org/wiki/Raghuvamsha'),
    ('Wikipedia — Kumarasambhava', 'https://en.wikipedia.org/wiki/Kumarasambhava'),
    ('Poetry Foundation — Kalidasa', 'https://www.poetryfoundation.org/poets/kalidasa'),
]

def build_meta():
    return {
        'pid': 'gm-kalidasa.html', 'kind': 'man', 'emoji': '🪶', 'accent': AC,
        'name': 'Kālidāsa', 'years': 'c. 4th–5th c. CE', 'group': 'Sages, Poets & Philosophers',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The classical Sanskrit poet and dramatist — author of Śakuntalā, the Meghadūta and the great epics — widely regarded as the greatest writer in the language and “the Shakespeare of India.”',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'man', 'label': '1 · The Man', 'type': 'timeline',
             'intro': 'His life is almost pure legend — a dullard blessed by the goddess Kālī — but scholarship places him in the Gupta golden age, jewel of Vikramāditya’s Ujjain, author of a compact and luminous canon.', 'events': PHASE_MAN},
            {'id': 'plays', 'label': '2 · The Plays', 'type': 'timeline',
             'intro': 'From a light court comedy through the lyrical madness of Vikramōrvaśīyam to his masterpiece, the Abhijñānaśākuntalam, with its invented curse and ring of recognition.', 'events': PHASE_PLAYS},
            {'id': 'epics', 'label': '3 · The Epics', 'type': 'timeline',
             'intro': 'His two grand mahākāvyas: the rise and fall of Raghu’s dynasty, and the divine romance of Śiva and Pārvatī that brings the war-god to birth.', 'events': PHASE_EPICS},
            {'id': 'lyric', 'label': '4 · The Lyrics', 'type': 'timeline',
             'intro': 'The beloved Meghadūta, a love-letter carried across India by a monsoon cloud, and the seasonal cycle of the Ṛtusaṃhāra — the height of Sanskrit lyric.', 'events': PHASE_LYRIC},
            {'id': 'art', 'label': '5 · The Art', 'type': 'timeline',
             'intro': 'Why the tradition made him the standard of taste itself — supreme in simile, and the poet of harmony between human passion and the natural world.', 'events': PHASE_ART},
            {'id': 'legacy', 'label': '6 · Legacy', 'type': 'timeline',
             'intro': 'Unknown to the West for a thousand years, Kālidāsa was rediscovered by Sir William Jones and exalted by Goethe — becoming, at last, the acknowledged “Shakespeare of India.”', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Encyclopaedic and scholarly sources; because his biography is largely legendary, dating and the court traditions (Vikramāditya, the nine gems, the Kālī legend) are presented as tradition and inference rather than established fact.'},
            {'id': 'events', 'label': 'Key Works', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
