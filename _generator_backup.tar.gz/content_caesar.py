# -*- coding: utf-8 -*-
"""Full, EXHAUSTIVE birth-to-death guide content for Gaius Julius Caesar."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#7e22ce'  # Roman purple

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_triumvirate():
    W, H = 720, 300
    b = '<text x="20" y="46" font-size="11" fill="#94a3b8" font-weight="700">60 BC · a private bargain between three men, sealed by a marriage</text>'
    def box(x, y, w, h, c, name, brings, wants):
        s = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="#fff" stroke="{c}" stroke-width="1.9"/>'
        s += f'<text x="{x+14}" y="{y+22}" font-size="12.5" font-weight="800" fill="{c}">{esc(name)}</text>'
        s1, _ = _tspans(x+14, y+40, 'brings: ' + brings, 10, '#334155', 600, 11, int((w-24)/5.2))
        s += s1
        s2, _ = _tspans(x+14, y+62, 'wants: ' + wants, 10, '#6b7280', 500, 11, int((w-24)/5.2))
        return s + s2
    b += box(285, 54, 150, 86, '#7e22ce', 'CAESAR', 'ambition, talent, the mob', 'a consulship + an army')
    b += box(46, 172, 200, 84, '#2563eb', 'POMPEY “the Great”', 'Rome’s first soldier, prestige', 'land for his veterans')
    b += box(474, 172, 200, 84, '#b45309', 'CRASSUS', 'the richest man in Rome', 'influence + a war vs Parthia')
    b += '<line x1="330" y1="140" x2="180" y2="172" stroke="#94a3b8" stroke-width="1.6"/>'
    b += '<line x1="390" y1="140" x2="548" y2="172" stroke="#94a3b8" stroke-width="1.6"/>'
    b += '<line x1="246" y1="214" x2="474" y2="214" stroke="#94a3b8" stroke-width="1.4" stroke-dasharray="5 4"/>'
    b += '<rect x="300" y="150" width="120" height="24" rx="8" fill="#f3e8ff"/><text x="360" y="166" font-size="10.5" fill="#7e22ce" font-weight="800" text-anchor="middle">the informal pact</text>'
    b += '<text x="360" y="196" font-size="9.5" fill="#94a3b8" text-anchor="middle">sealed: Pompey marries Caesar’s daughter Julia</text>'
    return _wrap(W, H, 'The First Triumvirate — three men divide the Republic', _tk(b, W, H, 'Alone none could rule; together they made the Senate irrelevant.'), '', AC)

def svg_alesia():
    W, H = 720, 300
    cx, cy = 470, 158
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">ALESIA · 52 BC · two walls, two fronts, one battle</text>'
    b += f'<circle cx="{cx}" cy="{cy}" r="112" fill="none" stroke="#dc2626" stroke-width="2" stroke-dasharray="7 5"/>'
    b += f'<circle cx="{cx}" cy="{cy}" r="84" fill="#f3e8ff" stroke="#7e22ce" stroke-width="9" opacity=".92"/>'
    b += f'<circle cx="{cx}" cy="{cy}" r="54" fill="#fff" stroke="#7e22ce" stroke-width="1.6"/>'
    b += f'<circle cx="{cx}" cy="{cy}" r="30" fill="#fee2e2" stroke="#b45309" stroke-width="1.8"/>'
    b += f'<text x="{cx}" y="{cy-3}" font-size="10" font-weight="800" fill="#b45309" text-anchor="middle">Vercingetorix</text>'
    b += f'<text x="{cx}" y="{cy+11}" font-size="8.5" fill="#6b7280" text-anchor="middle">~80k Gauls</text>'
    b += f'<text x="{cx}" y="{cy-64}" font-size="9.5" font-weight="800" fill="#7e22ce" text-anchor="middle">Roman legions</text>'
    for (x, y) in [(690, 70), (690, 250), (470, 292)]:
        b += f'<text x="{x}" y="{y}" font-size="9.5" fill="#dc2626" font-weight="800" text-anchor="middle">relief ~250k</text>'
    b += f'<line x1="660" y1="80" x2="{cx+78}" y2="{cy-30}" stroke="#dc2626" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += f'<line x1="660" y1="240" x2="{cx+78}" y2="{cy+30}" stroke="#dc2626" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += f'<line x1="470" y1="284" x2="{cx}" y2="{cy+86}" stroke="#dc2626" stroke-width="1.6" marker-end="url(#ah)"/>'
    lx = 26
    b += f'<text x="{lx}" y="86" font-size="10.5" font-weight="800" fill="#334155" letter-spacing=".08em">THE TRAP</text>'
    b += f'<rect x="{lx}" y="98" width="16" height="12" rx="3" fill="#7e22ce"/>'
    s1, _ = _tspans(lx+24, 108, 'inner wall (contravallation) — pens Vercingetorix in', 10, '#4a5568', 600, 12, 30); b += s1
    b += f'<rect x="{lx}" y="140" width="16" height="12" rx="3" fill="none" stroke="#dc2626" stroke-width="2" stroke-dasharray="4 3"/>'
    s2, _ = _tspans(lx+24, 150, 'outer wall (circumvallation) — repels the relief army', 10, '#4a5568', 600, 12, 30); b += s2
    s3, _ = _tspans(lx, 196, '→ both Gallic armies break on Roman spades and discipline; Gaul falls.', 10, '#7e22ce', 700, 12, 34); b += s3
    return _wrap(W, H, 'Alesia — the double siege', _tk(b, W, H, 'Trapped between two armies, he besieged one and defended against the other — and won both.'), '', AC)

def svg_rubicon():
    W, H = 720, 268
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">JANUARY 49 BC · the Senate orders Caesar to disband his army and come home alone</text>'
    b += '<rect x="230" y="56" width="260" height="46" rx="12" fill="#fff" stroke="#334155" stroke-width="1.8"/>'
    b += '<text x="360" y="76" font-size="11.5" font-weight="800" fill="#334155" text-anchor="middle">Lay down command?</text>'
    b += '<text x="360" y="92" font-size="9.5" fill="#6b7280" text-anchor="middle">the river Rubicon = the legal border of Italy</text>'
    b += '<line x1="300" y1="102" x2="150" y2="140" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="420" y1="102" x2="570" y2="140" stroke="#7e22ce" stroke-width="1.8" marker-end="url(#ah)"/>'
    b += '<rect x="40" y="142" width="240" height="72" rx="12" fill="#fff" stroke="#475569" stroke-width="1.6"/>'
    b += '<text x="52" y="164" font-size="11" font-weight="800" fill="#475569">OBEY → return alone</text>'
    s1,_=_tspans(52,182,'prosecuted by his enemies, stripped of everything, career and life over',10,'#5b6472',500,11,40); b+=s1
    b += '<rect x="440" y="142" width="240" height="72" rx="12" fill="#faf5ff" stroke="#7e22ce" stroke-width="1.9"/>'
    b += '<text x="452" y="164" font-size="11" font-weight="800" fill="#7e22ce">CROSS → “alea iacta est”</text>'
    s2,_=_tspans(452,182,'treason and civil war — but a real shot at supreme power',10,'#6b21a8',500,11,40); b+=s2
    return _wrap(W, H, 'The Rubicon — a point of no return', _tk(b, W, H, '“The die is cast.” A choice with no path back becomes clarifying: he committed totally.'), '', AC)

def svg_ides():
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">15 MARCH 44 BC · the assassins’ intention vs. what they actually caused</text>'
    steps = [(40,'#64748b','1 · The fear','he is dictator for life — looks like a king; Rome loathes kings'),
             (270,'#dc2626','2 · The act','~60 senators; 23 stab wounds at the Theatre of Pompey'),
             (500,'#7e22ce','3 · The aim','“restore the free Republic”')]
    for x,c,t,s in steps:
        b += f'<rect x="{x}" y="58" width="180" height="70" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="11.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.6,'#5b6472',500,11,30); b+=ss
    b += '<line x1="220" y1="93" x2="268" y2="93" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="93" x2="498" y2="93" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="590" y1="128" x2="590" y2="158" stroke="#dc2626" stroke-width="1.8" marker-end="url(#ah)"/>'
    b += '<rect x="360" y="160" width="330" height="30" rx="9" fill="#fee2e2"/><text x="525" y="180" font-size="10.5" fill="#b91c1c" font-weight="800" text-anchor="middle">ACTUAL: civil war → his heir Octavian → the Empire</text>'
    return _wrap(W, H, 'The Ides of March — the irony of the act', _tk(b, W, H, 'They killed the man to save the Republic — and killed the Republic by killing the man.'), '', AC)

def svg_pharsalus_line():
    """The hidden fourth line that beat Pompey's cavalry."""
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">PHARSALUS · 48 BC · outnumbered, he plans for Pompey’s one big move</text>'
    b += svg_row('', [
        {'n': 1, 'label': 'Pompey’s plan', 'sub': 'huge cavalry sweep to turn Caesar’s open flank', 'color': '#2563eb'},
        {'n': 2, 'label': 'A hidden 4th line', 'sub': 'Caesar conceals cohorts behind his flank', 'color': '#7e22ce'},
        {'n': 3, 'label': 'Charge the horses', 'sub': 'they jab at faces; the cavalry panics & flees', 'color': '#16a34a'},
    ], edge_labels=['vs', 'so'], takeaway='', accent=AC).split('role="img">')[1].rsplit('</svg>',1)[0]
    return _wrap(W, H, 'Pharsalus — defeating the plan, not just the army', _tk(b, W, H, 'Predict the enemy’s one decisive move and prepare a specific counter — beat the plan before it works.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — RISE
PHASE_RISE = [
    E('birth', '100 BC', 'Born into a fading name, in a dying Republic', ['RISE'],
      'A patrician by blood but not by power or wealth, born as Rome tears itself apart between the populist Marius and the dictator Sulla — the chaos that will make his career possible.',
      svg_stack('The world he was born into', [
          {'n': 1, 'label': 'The Julii: old blood, little power', 'sub': 'patrician lineage (claiming descent from Venus) but not rich or dominant', 'color': '#64748b'},
          {'n': 2, 'label': 'A Republic at war with itself', 'sub': 'Marius (his uncle-by-marriage) vs Sulla', 'color': '#b45309'},
          {'n': 3, 'label': 'Norms already broken', 'sub': 'proscriptions, marches on Rome — the rules are up for grabs', 'color': '#7e22ce'},
      ], takeaway='He was born ambitious in a system whose rules were already collapsing — perfect conditions for a man willing to break them.', accent=AC),
      bg='Rome in 100 BC was a republic in slow crisis: a tiny elite, a restless mob, land-hungry armies loyal to their generals, and a constitution buckling under the strain of empire.',
      people='<b>Gaius Marius</b>, the great populist general, married to Caesar’s aunt Julia — tying young Caesar to the <b>populares</b>. His rival <b>Sulla</b> would soon rule by terror.',
      what='Gaius Julius Caesar was born (traditionally 100 BC) into the patrician <b>gens Julia</b> — prestigious but sidelined — on the populist side of a violent factional divide.',
      crux='Blood gave him status but not power; he would have to <b>earn</b> real power in a system where the old guarantees no longer held.',
      conseq='He grew up inside Rome’s factional bloodletting, learning that in a broken system, boldness and the loyalty of soldiers and the mob mattered more than legality.',
      matters='Great disruptors often arrive when the old order is already failing. Caesar didn’t break a healthy republic — he finished off a dying one.'),

    E('sulla', 'c. 82–80 BC', 'Defying Sulla — the boy who wouldn’t bend', ['RISE', 'POLITICS'],
      'The dictator Sulla orders the young Caesar to divorce his wife. He refuses, is stripped of everything, and goes into hiding — until powerful friends beg for his life. Sulla relents, with a warning.',
      svg_row('An early lesson in nerve', [
          {'n': 1, 'label': 'Sulla’s demand', 'sub': 'divorce Cornelia (a populist’s daughter)', 'color': '#b45309'},
          {'n': 2, 'label': 'Caesar refuses', 'sub': 'loses dowry, priesthood, inheritance; goes on the run', 'color': '#7e22ce'},
          {'n': 3, 'label': 'Spared, with a warning', 'sub': '“in that boy are many Mariuses”', 'color': '#16a34a'},
      ], edge_labels=['then', 'result'], takeaway='He learned young that refusing to bend — even to a dictator — could build a reputation worth more than safety.', accent=AC),
      bg='After winning the civil war, <b>Sulla</b> ruled as dictator and purged enemies through <b>proscriptions</b> (published death-lists). As a Marian by marriage, Caesar was suspect.',
      people='<b>Sulla</b>, the dictator; <b>Cornelia</b>, Caesar’s wife and daughter of a leading populist; the relatives and priests who interceded.',
      what='Ordered to divorce Cornelia, Caesar <b>refused</b>, forfeiting property and position and hiding in the countryside. Friends won a pardon; Sulla reportedly warned that in Caesar he saw “many a Marius.”',
      crux='<b>Defiance as strategy</b>: by risking everything rather than submit, he signalled a spine that made him a rallying point for the populares — reputation bought with courage.',
      conseq='He left Rome for military service and study, surviving Sulla and returning as the young man who stood up to the dictator.',
      matters='Sometimes the reputation you build by refusing to fold is worth more than what you lose. Nerve is a form of capital.'),

    E('cornelia', '84–69 BC', 'The marriage he would not give up', ['RISE', 'LOVE', 'POLITICS'],
      'The root of his defiance of Sulla is personal: ordered by the dictator to divorce his wife Cornelia — daughter of one of Sulla’s dead enemies — the young Caesar simply refuses, risking death and losing his fortune and priesthood rather than betray her, an early sign that beneath the charm lay an iron, dangerous will.',
      svg_row('Loyalty as an act of defiance', [
          {'n': 1, 'label': 'Marries Cornelia', 'sub': 'daughter of Sulla’s enemy Cinna', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Ordered to divorce her', 'sub': 'Sulla commands it; Caesar refuses', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Loses all but his wife', 'sub': 'stripped of fortune and priesthood; goes into hiding', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He risked death and lost everything rather than betray his wife — an early glimpse of his iron will.', accent=AC),
      bg='Caesar had married <b>Cornelia</b>, daughter of Cinna, a leader of Sulla’s defeated faction. The victorious dictator <b>Sulla</b> demanded he divorce her.',
      people='His wife <b>Cornelia</b>; the dictator <b>Sulla</b>; the relatives who interceded to save Caesar’s life.',
      what='Ordered by <b>Sulla</b> to divorce <b>Cornelia</b>, Caesar <b>refused</b>, and was stripped of his inheritance, his wife’s dowry and his priesthood, going into hiding — spared execution only after powerful relatives interceded (Sulla warning that in this young man there was “many a Marius”).',
      crux='His refusal revealed a <b>deep loyalty fused with reckless courage</b> — he would not betray his wife even to save his fortune or his life.',
      conseq='He survived, marked from youth as a man of dangerous nerve whom even Sulla saw as a future threat.',
      matters='Character shows early. Caesar’s refusal to abandon Cornelia is the first proof of the iron will beneath his famous charm.'),

    E('pirates', '75 BC', 'Captured by pirates — and the promise kept', ['RISE'],
      'Kidnapped by pirates, he jokes with them, raises his own ransom, tells them he will come back and crucify them — and, freed, does exactly that. A perfect early portrait of his confidence and ruthlessness.',
      svg_row('A story that captures the man', [
          {'n': 1, 'label': 'Seized by pirates', 'sub': 'scoffs at their ransom; demands they raise it', 'color': '#64748b'},
          {'n': 2, 'label': 'Promises revenge — cheerfully', 'sub': 'tells them he’ll return and crucify them', 'color': '#7e22ce'},
          {'n': 3, 'label': 'He does it', 'sub': 'freed, he raises a fleet and executes them', 'color': '#dc2626'},
      ], edge_labels=['then', 'so'], takeaway='Total self-assurance plus follow-through — he meant every threat, and people learned to believe him.', accent=AC),
      bg='As a young man travelling east, Caesar was captured by <b>Cilician pirates</b>, then endemic in the Mediterranean.',
      people='The pirates, whom he treated as inferiors even as their prisoner; the provincial authorities he bypassed to take his own revenge.',
      what='Held for ransom, Caesar reportedly <b>mocked the pirates</b>, insisted they raise his ransom, joined their games, and promised to return and crucify them. Freed, he <b>raised ships, hunted them down, and had them crucified</b> (mercifully cutting their throats first).',
      crux='The episode shows his defining traits early: <b>supreme self-confidence</b>, charm, and a cold willingness to follow a threat through to the end. His word — even a threat — was reliable.',
      conseq='It burnished his reputation for boldness and decisiveness, and his rise up the Roman ladder continued.',
      matters='Credibility comes from follow-through. A person who always does exactly what they promise — reward or revenge — becomes someone others take very seriously.'),

    E('pontifex', '69–63 BC', 'The ladder — bought with debt and spectacle', ['POLITICS', 'RISE'],
      'He climbs by borrowing vast sums to stage dazzling public games, buying the crowd’s love — then gambles everything to win Rome’s highest priesthood by outright bribery, telling his mother he’ll return elected or not at all.',
      svg_row('Turning debt into power', [
          {'n': 1, 'label': 'Borrow massively', 'sub': 'huge loans (much from Crassus)', 'color': '#b45309'},
          {'n': 2, 'label': 'Spend on the people', 'sub': 'lavish games, feasts → popularity', 'color': '#7e22ce'},
          {'n': 3, 'label': 'Cash it in for office', 'sub': 'quaestor, aedile → Pontifex Maximus (63 BC)', 'color': '#16a34a'},
      ], edge_labels=['fund', 'convert'], takeaway='He treated popularity as an investable asset — borrow to buy the crowd, then convert the crowd into office.', accent=AC),
      bg='Roman careers ran up the <b>cursus honorum</b>, the ladder of offices, which required staggering spending on games and favours — so ambitious men ran up ruinous debt.',
      people='<b>Marcus Crassus</b>, Rome’s richest man, who bankrolled Caesar’s debts (feeding the coming Triumvirate); the Roman <b>mob</b>, whose favour he bought. (At a quaestorship in Spain he reportedly wept before a statue of Alexander, who had conquered the world by his age.)',
      what='As <b>aedile</b> he staged spectacular games, going deep into debt; in <b>63 BC</b> he won election as <b>Pontifex Maximus</b>, Rome’s chief priest, reportedly telling his mother he would come home elected or not at all — having bribed heavily.',
      crux='He understood the flywheel of Roman politics — <b>money → spectacle → popularity → office → more power</b> — and ran it harder and more riskily than anyone.',
      conseq='He became a major public and religious figure, and so deep in debt that he <b>needed</b> a great military command to pay it off — which drove everything next.',
      matters='Popularity is a currency you can invest and compound. But debt-fuelled ambition also forces your hand — it made bold conquest a necessity, not just a choice.'),

    E('spain', '69–61 BC', 'Spain and the statue of Alexander', ['RISE', 'POLITICS'],
      'Serving in Spain as a young official, he comes upon a statue of Alexander the Great and reportedly weeps — for at an age when Alexander had already conquered the world, he, Caesar, has done nothing of note. It is a revealing glimpse of the immense, impatient ambition burning beneath the affable politician.',
      svg_row('The moment ambition became conscious', [
          {'n': 1, 'label': 'Posted to Spain', 'sub': 'serves as quaestor, then governor', 'color': '#7e22ce'},
          {'n': 2, 'label': 'The statue of Alexander', 'sub': 'sees it and weeps at his own lack of achievement', 'color': '#b45309'},
          {'n': 3, 'label': 'Ambition unbound', 'sub': 'resolves to make his name at any cost', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='Weeping before Alexander’s statue, he revealed the boundless ambition that would drive him to conquer and rule.', accent=AC),
      bg='As a rising official, Caesar served in <b>Spain</b>, where an encounter with the memory of <b>Alexander the Great</b> reportedly crystallised his ambition.',
      people='<b>Alexander the Great</b>, his lifelong model; the Roman soldiers and provincials of Spain.',
      what='Serving in <b>Spain</b>, Caesar reportedly <b>wept before a statue of Alexander</b> — reflecting that at his age Alexander had conquered the known world while he had done nothing comparable — a famous glimpse of his consuming ambition.',
      crux='Beneath his charm burned an <b>immense, impatient ambition</b>, measured against the greatest conqueror in history.',
      conseq='He returned to Rome determined to reach the heights of power by whatever means necessary.',
      matters='Ambition needs a measuring stick. Caesar measured himself against Alexander — and that restless comparison drove his whole extraordinary career.'),

    E('catiline', '63 BC', 'The Catiline affair — a dangerous moderation', ['POLITICS', 'TURNING POINT'],
      'When a violent conspiracy to overthrow the Republic is exposed, Caesar takes an audacious risk: in the great Senate debate he argues against executing the conspirators without trial, standing almost alone against Cato and Cicero — a stand that hints at both his principles and his willingness to court danger and suspicion for the popular cause.',
      svg_row('Standing apart in a moment of crisis', [
          {'n': 1, 'label': 'The Catiline conspiracy', 'sub': 'a plot to seize Rome is uncovered', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Caesar opposes execution', 'sub': 'argues against death without trial', 'color': '#b45309'},
          {'n': 3, 'label': 'Against Cato and Cicero', 'sub': 'stands nearly alone; is suspected of sympathy', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'so'], takeaway='He risked his safety to argue for legal restraint — revealing both principle and a taste for dangerous, popular positions.', accent=AC),
      bg='In <b>63 BC</b> the <b>Catiline conspiracy</b> to overthrow the Republic was exposed, and the Senate debated the fate of the captured plotters.',
      people='<b>Cicero</b>, the consul who exposed the plot; <b>Cato the Younger</b>, who demanded execution; Caesar, who opposed it.',
      what='In the Senate debate, Caesar <b>argued against executing the conspirators without trial</b> — standing against <b>Cato and Cicero</b> — a bold, risky stance that drew suspicion he sympathised with the plotters, but also displayed his independence.',
      crux='He was willing to take a <b>dangerous, principled, and popular stand</b> against the establishment, courting suspicion for the sake of legal restraint and his popularis image.',
      conseq='The conspirators were executed anyway, but Caesar had marked himself as a fearless leader of the popular cause.',
      matters='The Catiline debate reveals Caesar’s nerve and his politics — willing to stand nearly alone, and to court danger, for the popular side.'),
]

# ==================================================================  PHASE 2 — THE TRIUMVIRATE
PHASE_TRIUMVIRATE = [
    E('deal', '60 BC', 'The First Triumvirate — a private deal to own Rome', ['POLITICS', 'TURNING POINT'],
      'Three men who can’t win alone — Caesar, the great general Pompey, and the mega-rich Crassus — secretly pool their power. Between them they can make the Senate irrelevant.',
      svg_triumvirate(),
      bg='The Senate kept blocking all three: Pompey wanted land for his veterans, Crassus commercial favours and a command, Caesar the consulship. Individually, each was stymied.',
      people='<b>Pompey the Great</b>, Rome’s most celebrated soldier; <b>Marcus Crassus</b>, its richest man and Caesar’s creditor; <b>Caesar</b>, the rising populist. Sealed by marriage: Pompey wed Caesar’s daughter <b>Julia</b>.',
      what='In <b>60 BC</b> the three formed an informal, secret alliance (the “First Triumvirate” — not an office). Pooling votes, money and veterans, they could push through what the Senate refused each of them.',
      crux='<b>Complementary strengths</b>: none could dominate alone, but Pompey’s soldiers + Crassus’s money + Caesar’s drive made them, together, stronger than the state’s institutions.',
      conseq='It won Caesar the consulship for 59 BC and, crucially, a long military command in Gaul — the platform for everything after. It also set up a three-body rivalry that could only end in collapse.',
      matters='Alliances are built on complementary needs, not friendship. The strongest coalitions combine people who each supply exactly what the others lack.'),

    E('consul', '59 BC', 'The consulship of “Julius and Caesar”', ['POLITICS'],
      'As consul he rams his agenda through by force, sidelines his powerless co-consul so completely that Romans joke the year’s consuls are "Julius and Caesar," and secures the long Gallic command he needs.',
      svg_stack('Turning one year in office into a decade of power', [
          {'n': 1, 'label': 'Elected consul for 59 BC', 'sub': 'backed by Triumvirate votes & money', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Force through the land law', 'sub': 'intimidates the assembly; co-consul Bibulus retreats home', 'color': '#b45309'},
          {'n': 3, 'label': 'Secure Gaul for 5 (then 10) years', 'sub': 'a province, an army, and a road to glory & wealth', 'color': '#16a34a'},
      ], takeaway='He used a single legal year in power to grab an extended military command — the real prize was the army, not the office.', accent=AC),
      bg='The consulship lasted a year, but a <b>provincial command</b> afterward meant an army, plunder, and the military glory Roman power was built on.',
      people='<b>Marcus Bibulus</b>, his optimate co-consul, so outmuscled he withdrew to “watch the skies” — Romans mocked the consuls as “Julius and Caesar.” <b>Cato the Younger</b> led the opposition.',
      what='In <b>59 BC</b> Caesar forced through land redistribution for Pompey’s veterans and other goals, overriding vetoes, then secured a multi-year command over <b>Gaul</b> — an army of his own.',
      crux='He converted a temporary office into <b>durable power</b> by using it to win a long command. Control of legions, not the consular title, was the lasting asset.',
      conseq='For a decade he would have a loyal, battle-hardened army and a theatre (Gaul) in which to build wealth, reputation, and the force he’d one day turn on Rome.',
      matters='Look past the title to the real lever. The consulship was fleeting; the army it let him raise was permanent.'),

    E('julia', '59–54 BC', 'Julia — the marriage that held Rome together', ['POLITICS', 'LOVE', 'TRAGEDY'],
      'The alliance that lets him conquer Gaul is sealed not only by politics but by love: he gives his beloved daughter Julia in marriage to Pompey, and the union — genuinely happy — binds the two great rivals together. When Julia dies in childbirth in 54 BC, the human bond between Caesar and Pompey dies with her, and the road to civil war opens.',
      svg_row('A daughter’s marriage — and death — moves history', [
          {'n': 1, 'label': 'Julia weds Pompey', 'sub': 'sealing the Caesar–Pompey alliance', 'color': '#7e22ce'},
          {'n': 2, 'label': 'A genuinely happy union', 'sub': 'the personal bond steadies the Triumvirate', 'color': '#166534'},
          {'n': 3, 'label': 'Julia dies, 54 BC', 'sub': 'the human link between the rivals is gone', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='His daughter’s marriage bound Caesar and Pompey; her death untied them — and opened the road to civil war.', accent=AC),
      bg='To cement the Triumvirate, Caesar married his only daughter <b>Julia</b> to <b>Pompey</b> — a match that became a genuine love.',
      people='His daughter <b>Julia</b>; <b>Pompey</b>, her husband and Caesar’s ally-turned-rival.',
      what='Caesar gave <b>Julia</b> in marriage to <b>Pompey</b>, and their happy union helped hold the alliance together — until <b>Julia died in childbirth in 54 BC</b>, severing the personal bond between the two men.',
      crux='The alliance rested partly on a <b>human tie</b>; when Julia died, the personal bond that restrained the rivalry died too.',
      conseq='With Julia and then Crassus gone, nothing personal remained to prevent the fatal collision between Caesar and Pompey.',
      matters='History can turn on a family tragedy. Julia’s death removed the human bond holding Rome’s two great men together.'),
]

# ==================================================================  PHASE 3 — THE GALLIC WARS
PHASE_GAUL = [
    E('veneti', '56 BC', 'The Veneti — winning a war at sea', ['BATTLE', 'TRIUMPH'],
      'His conquest of Gaul is not only on land: when the seafaring Veneti of the Atlantic coast revolt, trusting their tides and sturdy ships, Caesar builds a fleet from nothing and defeats them in a sea-battle won by a clever trick — cutting the rigging of their sails with hooks — showing his adaptability across every kind of warfare.',
      svg_row('Adapting to a war on the water', [
          {'n': 1, 'label': 'The Veneti revolt', 'sub': 'a seafaring Atlantic tribe trusts its ships', 'color': '#64748b'},
          {'n': 2, 'label': 'Caesar builds a fleet', 'sub': 'improvises Roman naval power in Gaul', 'color': '#7e22ce'},
          {'n': 3, 'label': 'Wins by a trick', 'sub': 'hooks cut the enemy’s rigging; they are becalmed', 'color': '#16a34a'},
      ], edge_labels=['then', 'then'], takeaway='He mastered even naval war by improvisation and cunning — no form of warfare was beyond him.', accent=AC),
      bg='The <b>Veneti</b>, a powerful seafaring people of the Atlantic coast of Gaul, revolted, confident in their ships and knowledge of the tides.',
      people='The <b>Veneti</b> and their formidable sailing fleet; the Roman soldiers Caesar turned into sailors.',
      what='Caesar <b>built a fleet</b> and defeated the Veneti in a <b>sea-battle</b>, won partly by a clever device — <b>hooks on poles to cut the ropes</b> holding up the enemy’s sails, leaving their ships helpless.',
      crux='He showed his <b>total adaptability</b>: facing a naval enemy, he improvised Roman sea power and won through ingenuity.',
      conseq='The Atlantic coast was subdued; Caesar’s reputation for versatility grew.',
      matters='Genius adapts to any medium. Caesar’s naval victory over the Veneti shows he could master forms of war entirely new to him.'),

    E('germans', '55 BC', 'The German massacre — glory and atrocity', ['BATTLE', 'TRIUMPH', 'TRAGEDY'],
      'The dark side of his conquest shows starkly when two German tribes cross the Rhine: Caesar attacks during a truce and annihilates them — men, women and children — in a slaughter so brutal that even in Rome his enemy Cato demands he be handed over to the Germans for war crimes. Caesar, unmoved, bridges the Rhine to overawe Germania and marches on.',
      svg_row('Conquest at a horrifying human cost', [
          {'n': 1, 'label': 'German tribes cross the Rhine', 'sub': 'the Usipetes and Tencteri enter Gaul', 'color': '#64748b'},
          {'n': 2, 'label': 'Massacre during a truce', 'sub': 'Caesar annihilates them — hundreds of thousands claimed', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Cato demands he be tried', 'sub': 'even in Rome, the atrocity shocks', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='His Gallic glory was built on atrocities so severe that even Romans called for him to answer for them.', accent=AC),
      bg='In <b>55 BC</b> two German tribes, the <b>Usipetes and Tencteri</b>, crossed the Rhine into Gaul, and negotiations were underway.',
      people='The German tribes he destroyed; <b>Cato the Younger</b>, who denounced the act in Rome.',
      what='Caesar <b>attacked the German tribes during a truce</b> and <b>massacred them</b> — by his own account hundreds of thousands, including women and children — an atrocity so extreme that <b>Cato proposed handing Caesar over</b> to the Germans. Caesar then bridged the Rhine to intimidate Germania.',
      crux='His Gallic conquest, for all its brilliance, involved <b>massacres and enslavement on a staggering scale</b> — glory built on atrocity.',
      conseq='Gaul was terrorised into submission; the human cost of Caesar’s conquest was immense, and remains a stain on his record.',
      matters='Caesar’s greatness cannot be separated from his brutality. The German massacre is a stark reminder of the human price of his conquests.'),

    E('commentaries', '58–50 BC', 'Writing his own legend — the Commentaries', ['REFORM', 'POLITICS'],
      'He wins the war twice — once in Gaul, and again in Rome, on the page: his Commentaries on the Gallic War, written in crisp, deceptively modest third-person prose, are dispatched home as brilliant self-promotion, shaping his image, dazzling the public, and becoming, almost incidentally, one of the masterpieces of Latin literature.',
      svg_row('Conquest, then its perfect telling', [
          {'n': 1, 'label': 'Writes the Commentaries', 'sub': 'clear, modest-seeming third-person accounts', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Sent home as propaganda', 'sub': 'shapes his image with the Roman public', 'color': '#b45309'},
          {'n': 3, 'label': 'A literary masterpiece', 'sub': 'still read as a model of Latin prose', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He controlled his own legend by writing it himself — propaganda so good it became great literature.', accent=AC),
      bg='Throughout the Gallic Wars, Caesar wrote and sent home accounts of his campaigns.',
      people='The Roman public he was courting; later readers who prized the work as literature.',
      what='Caesar’s <b>Commentarii de Bello Gallico</b> — written in crisp, seemingly modest <b>third-person prose</b> — were dispatched to Rome as masterful <b>self-promotion</b>, shaping public opinion in his favour, and are now regarded as a <b>masterpiece of Latin literature</b>.',
      crux='He understood that <b>controlling the narrative was as important as winning the battle</b>, and had the literary genius to do it superbly.',
      conseq='His writings burnished his fame, justified his wars, and secured his image for posterity.',
      matters='Caesar wrote his own history — brilliantly. His Commentaries are a landmark in both propaganda and literature.'),

    E('helvetii', '58 BC', 'The Helvetii — a war of choice, dressed as defence', ['BATTLE', 'RISE'],
      'His command begins with a migrating tribe as a pretext: he blocks the Helvetii, defeats them at Bibracte, and turns a border incident into the opening of an eight-year war of conquest.',
      svg_row('Manufacturing the war he needed', [
          {'n': 1, 'label': 'The Helvetii migrate', 'sub': 'a whole people move west across Gaul', 'color': '#64748b'},
          {'n': 2, 'label': 'Caesar blocks & attacks', 'sub': 'defeats them at Bibracte; forces survivors home', 'color': '#7e22ce'},
          {'n': 3, 'label': 'A foothold in Gaul', 'sub': 'now “protector” of Gauls → pretext to stay & conquer', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He turned a defensive pretext into an open-ended war of conquest — the glory and wealth he needed.', accent=AC),
      bg='Caesar needed a great war to win glory and pay his debts. In <b>58 BC</b> the migration of the <b>Helvetii</b> (a Gallic tribe from modern Switzerland) gave him his opening.',
      people='The <b>Helvetii</b>; allied Gaulish tribes who “appealed” to Rome for protection, giving Caesar his justification to intervene deep in Gaul.',
      what='Caesar blocked the Helvetii, defeated them decisively at <b>Bibracte</b>, and forced the survivors back to their homeland — then stayed, cast as the protector of Rome’s Gaulish allies.',
      crux='The war was <b>a choice sold as a necessity</b>. A border incident became the license for an eight-year conquest that no one in Rome had actually authorised in full.',
      conseq='Caesar was now embedded in Gaul with a growing army and reputation — and would keep finding reasons to conquer more of it.',
      matters='Ambition often advances behind the language of defence and duty. Watch what a “defensive” action is actually used to justify.'),

    E('ariovistus', '58 BC', 'Ariovistus — driving the Germans back over the Rhine', ['BATTLE', 'TRIUMPH'],
      'Still in his first year, he confronts a powerful German warlord who has crossed into Gaul, steadies his frightened troops, and beats Ariovistus — casting the Rhine as Rome’s natural frontier.',
      svg_row('The Rhine becomes Rome’s line', [
          {'n': 1, 'label': 'Ariovistus in Gaul', 'sub': 'a Germanic king settling west of the Rhine', 'color': '#dc2626'},
          {'n': 2, 'label': 'Panic in the legions', 'sub': 'his men fear the Germans; Caesar shames them into courage', 'color': '#b45309'},
          {'n': 3, 'label': 'Germans beaten back', 'sub': 'driven across the Rhine; the river becomes the frontier', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='Leadership is often about morale: he beat his own army’s fear before he beat the enemy.', accent=AC),
      bg='The Germanic king <b>Ariovistus</b> had crossed the Rhine and was dominating parts of Gaul — a rival power Caesar could not tolerate in “his” theatre.',
      people='<b>Ariovistus</b>, the German warlord; Caesar’s own soldiers, gripped by rumours of the Germans’ ferocity — until he shamed and rallied them.',
      what='When his troops nearly panicked at tales of German prowess, Caesar rallied them (offering to advance with only the loyal Tenth Legion). He then <b>defeated Ariovistus</b> and drove the Germans back across the <b>Rhine</b>.',
      crux='Half the battle was <b>his own army’s morale</b>. By confronting their fear directly and staking his prestige on the loyal Tenth, he turned panic into resolve.',
      conseq='The Rhine was established as the effective boundary between Gaul and Germania — and Caesar as the dominant power in Gaul.',
      matters='Before you can beat the enemy, you often must beat your own side’s fear. Managing morale is as decisive as any manoeuvre.'),

    E('sabis', '57 BC', 'The Sambre (Sabis) — snatching victory from ambush', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'The fierce Belgae ambush his army mid-camp and nearly destroy it; Caesar grabs a shield, rushes to the front line, and personally rallies his reeling legions to a desperate, come-from-behind win.',
      svg_row('Leading from the front to reverse a disaster', [
          {'n': 1, 'label': 'Ambushed at the Sabis', 'sub': 'the Nervii fall on the half-built camp', 'color': '#dc2626'},
          {'n': 2, 'label': 'The line nearly breaks', 'sub': 'a genuine near-defeat; chaos in the ranks', 'color': '#b45309'},
          {'n': 3, 'label': 'Caesar rallies in person', 'sub': 'grabs a shield, fights in the front rank; the tide turns', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='His personal presence at the breaking point turned a rout into a victory — the commander as morale weapon.', accent=AC),
      bg='In <b>57 BC</b> Caesar turned on the <b>Belgae</b>, the warlike tribes of northern Gaul. The fierce <b>Nervii</b> caught his army by surprise as it made camp on the river <b>Sabis</b> (Sambre).',
      people='The <b>Nervii</b>, who fought almost to extinction; Caesar himself, who fought in the front line at the crisis; the veteran centurions who held the line.',
      what='The Nervii’s ambush nearly shattered the Roman army. Caesar seized a shield, went to the most threatened point, and <b>personally rallied his men</b>; the legions recovered and all but annihilated the Nervii.',
      crux='At the moment of maximum danger, the <b>commander’s visible courage</b> at the front was worth more than any order — it re-anchored an army on the edge of collapse.',
      conseq='The Belgae were broken and much of northern Gaul submitted; Caesar’s reputation for personal bravery and cool under disaster grew.',
      matters='In a crisis, presence is power. A leader who shows up at the worst point, sharing the risk, can reverse a collapse no plan could.'),

    E('britain', '55–54 BC', 'The Rhine bridge and the invasions of Britain', ['BATTLE', 'POLITICS'],
      'He bridges the Rhine in ten days to overawe the Germans, then twice crosses the sea to Britain — achieving little militarily but stunning Rome, which had never imagined its armies at the edge of the world.',
      svg_row('Feats of engineering and propaganda', [
          {'n': 1, 'label': 'Bridge the Rhine (10 days)', 'sub': 'a show of Roman power; raid, then dismantle it', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Cross to Britain (55 & 54 BC)', 'sub': 'beyond the known world — a sensation in Rome', 'color': '#2563eb'},
          {'n': 3, 'label': 'Little gained, huge fame', 'sub': 'militarily thin; politically dazzling', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='Some victories are theatre: the deeds mattered less than the story they told Rome about Caesar.', accent=AC),
      bg='To impress both the Germans and the Roman public, Caesar undertook two spectacular feats: a bridge over the <b>Rhine</b> and expeditions across the sea to mysterious <b>Britain</b>.',
      people='His <b>engineers</b>, who built a Rhine bridge in about ten days; the British tribes; the Roman public, thrilled by news from the edge of the world.',
      what='Caesar’s army <b>bridged the Rhine</b> to raid Germania (then destroyed the bridge), and <b>crossed to Britain</b> in 55 and 54 BC. Militarily the British expeditions achieved little, but they were a <b>propaganda sensation</b> in Rome.',
      crux='The value was <b>political theatre</b>: no Roman army had done such things. The Commentarii turned engineering stunts and inconclusive raids into evidence of superhuman reach.',
      conseq='Caesar’s fame in Rome soared even as the real war in Gaul was far from over — and his enemies grew more alarmed at his power.',
      matters='Reputation can outrun results. A leader who performs the spectacular — and controls the story — can win politically even where they win little on the ground.'),

    E('eburones', '54–53 BC', 'The Eburones revolt — a legion destroyed', ['BATTLE', 'DEFEAT', 'TRAGEDY'],
      'Gaul is not as conquered as it looks: the chieftain Ambiorix lures a Roman force out of camp and massacres it — an entire legion and a half wiped out, the worst disaster of the war, which Caesar avenges brutally.',
      svg_row('The conquest was more fragile than it seemed', [
          {'n': 1, 'label': 'Ambiorix rebels', 'sub': 'the Eburones rise against winter garrisons', 'color': '#dc2626'},
          {'n': 2, 'label': 'A legion lured out & massacred', 'sub': '~15 cohorts destroyed under Sabinus & Cotta', 'color': '#9f1239'},
          {'n': 3, 'label': 'Brutal reprisal', 'sub': 'Caesar hunts the Eburones near to extinction', 'color': '#7e22ce'},
      ], edge_labels=['then', 'so'], takeaway='Occupation is never as complete as the map suggests — and Caesar answered revolt with near-genocidal reprisal.', accent=AC),
      bg='By 54 BC Gaul appeared subdued, but resentment simmered. The chieftain <b>Ambiorix</b> of the <b>Eburones</b> struck at the dispersed Roman winter camps.',
      people='<b>Ambiorix</b>, the rebel leader who eluded Caesar for good; the Roman commanders <b>Sabinus and Cotta</b>, tricked into leaving their camp and killed with their men.',
      what='Ambiorix persuaded a Roman garrison to march out under safe-conduct, then <b>ambushed and massacred it</b> — about a legion and a half lost, the war’s worst defeat. Caesar responded with a <b>campaign of extermination</b> against the Eburones.',
      crux='It exposed that the “conquest” was a lid on a boiling pot. Caesar’s answer — <b>collective, near-genocidal reprisal</b> — was designed to terrorise Gaul into submission.',
      conseq='The disaster and the brutal reprisals set the stage for a far larger, unified Gallic revolt the following year under Vercingetorix.',
      matters='Subjugation breeds resistance. Ruling by terror can suppress revolt for a time — but it also stores up the rage that fuels the next, bigger one.'),

    E('gergovia', '52 BC', 'Vercingetorix and the defeat at Gergovia', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'All Gaul finally unites under one brilliant leader, Vercingetorix, who adopts scorched-earth tactics and hands Caesar a rare, clear defeat at the hill-town of Gergovia — the war’s most dangerous moment.',
      svg_row('The one time the Gauls got it right', [
          {'n': 1, 'label': 'Gaul unites under Vercingetorix', 'sub': 'a single charismatic leader at last', 'color': '#dc2626'},
          {'n': 2, 'label': 'Scorched earth', 'sub': 'burn supplies; avoid open battle; starve the Romans', 'color': '#b45309'},
          {'n': 3, 'label': 'Caesar repulsed at Gergovia', 'sub': 'a costly assault fails — a clear defeat', 'color': '#9f1239'},
      ], edge_labels=['then', 'so'], takeaway='A united enemy with the right strategy nearly undid him — the war hung in the balance.', accent=AC),
      bg='In <b>52 BC</b> the Gauls at last united under <b>Vercingetorix</b>, chief of the Arverni, who understood that open battle favoured Rome and adopted <b>scorched-earth</b> tactics instead.',
      people='<b>Vercingetorix</b>, the one Gallic leader able to unite the tribes and out-think Caesar strategically; wavering Gallic allies now defecting to the revolt.',
      what='Vercingetorix burned supplies and towns to starve the Romans and avoided pitched battle. Caesar’s assault on the hill-fortress of <b>Gergovia</b> was <b>bloodily repulsed</b> — a rare, undeniable defeat that emboldened all Gaul.',
      crux='For once Caesar faced a <b>united enemy with a sound strategy</b> (deny battle, deny supply). Gergovia showed he was beatable and brought the whole war to a knife-edge.',
      conseq='The revolt swelled; but Vercingetorix soon made the fatal error of letting himself be besieged — at Alesia.',
      matters='Even the greatest can be beaten by a united opponent who refuses to fight on your terms. The danger is real until the enemy makes a mistake.'),

    E('alesia', 'Sep 52 BC', 'Alesia — the double siege that wins Gaul', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'Trapped between Vercingetorix’s army inside a hilltop town and a vast Gallic relief force outside, Caesar builds two rings of fortifications — one facing in, one facing out — and defeats both. Gaul is broken.',
      svg_alesia(),
      bg='After Gergovia, Vercingetorix withdrew into the hill-fort of <b>Alesia</b>. Caesar besieged him — but a huge Gallic <b>relief army</b> was marching to trap the Romans in turn.',
      people='<b>Vercingetorix</b>, besieged inside; the vast relief army outside; Caesar’s legions, who fought on two fronts at once. Vercingetorix surrendered and was later paraded in Caesar’s triumph and executed.',
      what='Caesar built a <b>double line of siege works</b> — an inner wall (contravallation) to pen Vercingetorix in, and an outer wall (circumvallation) to hold off the relief army — and defeated attacks from both sides. Vercingetorix surrendered.',
      crux='Facing encirclement, he <b>out-engineered</b> the problem: rather than choose which enemy to fight, he fortified against both at once and let Gallic numbers break on Roman discipline.',
      conseq='Gallic resistance collapsed; the conquest of Gaul was complete. Alesia sealed Caesar’s military immortality and gave him an unbeatable veteran army for the civil war to come.',
      matters='When trapped between two threats, the answer isn’t always to pick one — sometimes it’s to build a position that neutralises both.'),
]

# ==================================================================  PHASE 4 — CIVIL WAR
PHASE_CIVIL = [
    E('collapse', '54–50 BC', 'The Triumvirate unravels', ['POLITICS', 'TRAGEDY'],
      'The two bonds holding the alliance snap: Caesar’s daughter Julia (Pompey’s beloved wife) dies, and Crassus is killed in a disastrous war. With nothing between them, Pompey drifts to Caesar’s enemies.',
      svg_stack('Why the three-way balance broke', [
          {'n': 1, 'label': 'Julia dies (54 BC)', 'sub': 'the marriage bond between Caesar & Pompey is gone', 'color': '#db2777'},
          {'n': 2, 'label': 'Crassus killed at Carrhae (53 BC)', 'sub': 'the third leg — the balancer — is removed', 'color': '#dc2626'},
          {'n': 3, 'label': 'Pompey joins the optimates', 'sub': 'made sole consul; the Senate’s champion vs Caesar', 'color': '#b45309'},
          {'n': 4, 'label': 'Ultimatum to Caesar', 'sub': 'disband your army and stand trial', 'color': '#475569'},
      ], takeaway='A three-way balance is stable; remove one leg and it collapses into a duel. Two rivals with no buffer must fight.', accent=AC),
      bg='The Triumvirate held only while all three needed each other and personal bonds bound them. Two deaths destroyed both conditions.',
      people='<b>Julia</b>, Caesar’s daughter and Pompey’s wife, who died in 54 BC; <b>Crassus</b>, killed invading Parthia at <b>Carrhae</b> (53 BC); <b>Pompey</b>, who now aligned with <b>Cato</b> and the Senate.',
      what='With Julia and Crassus gone, Pompey moved toward Caesar’s enemies, becoming sole consul in 52 BC. The Senate demanded Caesar give up his command and army and return to Rome to face prosecution.',
      crux='Remove the balancing third party and the personal tie, and a stable trio becomes a <b>zero-sum duel</b>. Caesar and Pompey were now rivals with nothing to lose by fighting.',
      conseq='Caesar faced a trap: disarm and be destroyed in the courts, or defy the Senate and march. There was no safe middle path.',
      matters='Watch what holds an alliance together. When the balancing party or the personal tie is gone, former partners often become the deadliest enemies.'),

    E('rubicon', 'Jan 49 BC', 'Crossing the Rubicon — “the die is cast”', ['TURNING POINT', 'POLITICS'],
      'Ordered to disband his army or be ruined, Caesar leads a single legion across a small river that no general may cross under arms. It is treason and civil war — and he knows there is no going back.',
      svg_rubicon(),
      bg='By law a general had to lay down command before entering Italy proper. The Rubicon was that boundary; to cross it under arms was to declare war on the Roman state.',
      people='<b>Pompey</b> and the Senate optimates on one side; Caesar’s loyal legions on the other. The whole Roman world had to choose sides.',
      what='In January <b>49 BC</b>, refusing to be disarmed and prosecuted, Caesar crossed the <b>Rubicon</b> with the 13th Legion — reportedly saying <b>“alea iacta est”</b> (“the die is cast”). Civil war began; Pompey and much of the Senate fled Italy.',
      crux='A <b>point of no return, chosen deliberately</b>. Once across, retreat meant death, so hesitation was pointless — the irreversible commitment concentrated all his energy on winning.',
      conseq='Italy fell to him quickly as Pompey withdrew to gather forces in the east. The Republic split into all-out civil war between its two greatest men.',
      matters='Some decisions are one-way doors. Recognising when you’ve reached one — and then committing totally rather than half-measuring — separates the decisive from the doomed.'),

    E('ilerda', '49 BC', 'Ilerda — “an army without a general”', ['BATTLE', 'TRIUMPH'],
      'Before chasing Pompey, he secures his rear by out-manoeuvring Pompey’s legions in Spain — winning largely by marches, entrenchment and cutting supply rather than pitched battle.',
      svg_row('Winning by manoeuvre, not slaughter', [
          {'n': 1, 'label': 'Secure the rear first', 'sub': '“I go to fight an army without a general”', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Out-manoeuvre at Ilerda', 'sub': 'cut their water & supply; trap them by marching', 'color': '#b45309'},
          {'n': 3, 'label': 'Surrender, then clemency', 'sub': 'Pompey’s Spanish legions give up; he pardons them', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He preferred to win by position and supply — and to pardon the defeated, turning enemies into neutrals.', accent=AC),
      bg='Rather than chase Pompey east immediately, Caesar first turned <b>west to Spain</b> (49 BC) to eliminate Pompey’s strong legions there and secure his rear — quipping he went “to fight an army without a general.”',
      people='Pompey’s legates <b>Afranius and Petreius</b>, out-generalled in Spain; the Spanish legions Caesar spared and absorbed.',
      what='At <b>Ilerda (Lleida)</b>, Caesar manoeuvred to cut the Pompeians off from water and supply, forcing their <b>surrender with little bloodshed</b> — then showed his trademark <b>clemency</b>, pardoning them.',
      crux='He won by <b>logistics and position</b>, not a bloodbath — and used <b>mercy as strategy</b>: pardoning fellow Romans denied Pompey manpower and won Caesar goodwill.',
      conseq='His western flank secure, Caesar could turn east to face Pompey himself. His reputation for clemency (unlike Sulla’s proscriptions) grew.',
      matters='The cheapest victory is one that avoids a battle — and in a civil war, mercy can be more powerful than force, converting enemies rather than creating martyrs.'),

    E('dyrrhachium', '48 BC', 'Dyrrhachium — a defeat that teaches', ['BATTLE', 'DEFEAT'],
      'Chasing Pompey to Greece, Caesar is outfought and nearly destroyed at Dyrrhachium — but Pompey fails to press the advantage, and Caesar coolly withdraws to fight another day on ground of his choosing.',
      svg_row('Losing a battle without losing the war', [
          {'n': 1, 'label': 'Caesar besieges Pompey’s camp', 'sub': 'an over-ambitious blockade on the coast', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Pompey breaks out', 'sub': 'routs Caesar’s lines — a real defeat', 'color': '#dc2626'},
          {'n': 3, 'label': 'Pompey doesn’t pursue', 'sub': '“today the enemy would have won, if they had a winner”', 'color': '#b45309'},
      ], edge_labels=['then', 'but'], takeaway='He survived a defeat by staying cool and by his enemy’s caution — then chose better ground for the decider.', accent=AC),
      bg='Following Pompey to <b>Greece</b> in 48 BC, Caesar — short of supplies and numbers — tried to blockade Pompey’s larger army near <b>Dyrrhachium</b>.',
      people='<b>Pompey</b>, who won the engagement but hesitated to finish it; Caesar, who reportedly said Pompey didn’t know how to win.',
      what='Pompey broke Caesar’s over-extended siege lines and <b>defeated him at Dyrrhachium</b> — but, wary of a trap, <b>failed to pursue and destroy</b> the retreating army. Caesar withdrew inland in good order.',
      crux='Caesar <b>lost the battle but not his nerve or his army</b>, while Pompey’s excess caution wasted a chance to end the war. Caesar then manoeuvred to fight the decisive battle on his own terms.',
      conseq='Weeks later the two armies met at Pharsalus — where Caesar, though still outnumbered, would win everything.',
      matters='A defeat need not be decisive if you keep your head and your force intact — and a victory not pressed home can be worse than none.'),

    E('pharsalus', 'Aug 48 BC', 'Pharsalus — beating Pompey against the odds', ['BATTLE', 'TRIUMPH'],
      'Outnumbered on a Greek plain, Caesar reads Pompey’s battle plan, hides a fourth line of infantry to smash Pompey’s cavalry charge, and shatters the larger army. Pompey flees — and is murdered in Egypt.',
      svg_compare('Why the smaller army won', {
          'head': 'Pompey', 'color': '#2563eb',
          'items': ['Larger army, more cavalry', 'Reluctant, divided command', 'Plan: cavalry sweeps Caesar’s flank', 'Senators pressuring him to fight']},
          {'head': 'Caesar', 'color': '#7e22ce',
           'items': ['Fewer men, veteran & loyal', 'Sole, decisive command', 'Hidden 4th line to stop the cavalry', 'Reads and counters Pompey’s plan']},
          verdict='Veterans + unity of command + anticipating the enemy beat raw numbers.',
          takeaway='He didn’t just fight Pompey’s army — he defeated Pompey’s plan before it could work.', accent=AC),
      bg='After Dyrrhachium, the armies met at <b>Pharsalus</b> in Greece (Aug 48 BC). Caesar was outnumbered, especially in cavalry, on which Pompey pinned his plan.',
      people='<b>Pompey the Great</b>, pushed into battle by impatient senators; <b>Mark Antony</b>, commanding a wing for Caesar; the veteran legions whose discipline decided the day.',
      what='Anticipating that Pompey’s superior cavalry would turn his flank, Caesar hid a <b>fourth line</b> of infantry who charged the horsemen (jabbing at their faces) at the crucial moment, routing them and then the whole army. Pompey fled to <b>Egypt</b>, where he was assassinated on arrival.',
      crux='He won by <b>out-thinking, not out-numbering</b>: predicting the enemy’s one big move and preparing a specific counter, backed by veteran troops under a single clear command.',
      conseq='Pompey’s death left Caesar the dominant man in the Roman world, though Pompeian resistance regrouped in Egypt, Africa and Spain.',
      matters='Anticipate the opponent’s decisive move and neutralise it in advance. A smaller force that defeats the enemy’s plan beats a larger one that merely fights.'),
]

# ==================================================================  PHASE 5 — DICTATOR
PHASE_DICTATOR = [
    E('cleopatra', '48–47 BC', 'Egypt, Cleopatra, and the Alexandrian War', ['POLITICS', 'LOVE', 'BATTLE'],
      'Arriving in Egypt to find Pompey already murdered, he backs Cleopatra to the throne, becomes her lover, and survives a dangerous war trapped in Alexandria — nearly dying for a dynastic entanglement.',
      svg_row('A perilous detour in the East', [
          {'n': 1, 'label': 'Pompey murdered in Egypt', 'sub': 'the Egyptians kill him to court Caesar — who is disgusted', 'color': '#64748b'},
          {'n': 2, 'label': 'Backs Cleopatra', 'sub': 'takes her side & her bed; a son, Caesarion, is claimed', 'color': '#db2777'},
          {'n': 3, 'label': 'The Alexandrian War', 'sub': 'nearly trapped & killed; wins a hard urban campaign', 'color': '#dc2626'},
      ], edge_labels=['then', 'then'], takeaway='Even the master risked everything for a personal-dynastic entanglement — power and passion tangled dangerously.', accent=AC),
      bg='Chasing the last of Pompey’s cause, Caesar reached <b>Egypt</b> — a rich client kingdom torn by a civil war between the young queen <b>Cleopatra</b> and her brother Ptolemy XIII.',
      people='<b>Cleopatra VII</b>, the brilliant Ptolemaic queen who allied with (and bore a son, Caesarion, reputedly to) Caesar; Ptolemy XIII’s court, which had murdered Pompey.',
      what='Presented with Pompey’s severed head, Caesar reportedly wept. He <b>backed Cleopatra</b>, began a famous affair, and was nearly trapped and killed in the <b>Alexandrian War</b> before winning and installing her on the throne.',
      crux='It was a dangerous, semi-personal detour: he risked his life and months of the war for a <b>dynastic-romantic alliance</b> — showing even his cold judgement could be swayed.',
      conseq='Egypt became a friendly client state and a source of grain and money; but the Cleopatra affair and his near-royal style fed Roman fears about his ambitions.',
      matters='Even the most calculating leaders have entanglements that cloud judgement. Power and passion, mixed, can put everything at risk.'),

    E('zela', '47 BC', 'Zela — “veni, vidi, vici”', ['BATTLE', 'TRIUMPH'],
      'A rebel king in the east is crushed so fast that Caesar reports the whole campaign in three words — the most famous victory dispatch in history, and a masterclass in propaganda by brevity.',
      svg_row('Victory as a three-word headline', [
          {'n': 1, 'label': 'Pharnaces rebels (Pontus)', 'sub': 'exploits Rome’s civil war to grab territory', 'color': '#dc2626'},
          {'n': 2, 'label': 'Caesar crushes him at Zela', 'sub': 'a lightning campaign of days', 'color': '#7e22ce'},
          {'n': 3, 'label': '“Veni, vidi, vici”', 'sub': '“I came, I saw, I conquered”', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='The right three words can immortalise a victory — brevity itself is a form of power.', accent=AC),
      bg='While Caesar was occupied, <b>Pharnaces II of Pontus</b> exploited the chaos to seize territory in Asia Minor.',
      people='<b>Pharnaces II</b>, son of Rome’s old enemy Mithridates; the Roman public, dazzled by the speed and the phrase.',
      what='Caesar marched east and <b>crushed Pharnaces at Zela (47 BC)</b> in a swift campaign, reporting it to Rome in the immortal three words <b>“veni, vidi, vici.”</b>',
      crux='A minor war became a <b>propaganda triumph</b> through sheer brevity and speed — mastery of image as much as of arms.',
      conseq='The east was secured; Caesar’s legend and rhetorical brilliance grew. He turned to the last Pompeian holdouts.',
      matters='How you tell a victory shapes how it’s remembered. A perfect phrase can outlast the battle itself.'),

    E('thapsus', '46 BC', 'Thapsus — and the suicide of Cato', ['BATTLE', 'TRIUMPH', 'TRAGEDY'],
      'He crushes the Pompeian army in Africa; rather than accept Caesar’s famous mercy, his great enemy Cato the Younger kills himself — becoming a martyr for the dead Republic and a rebuke Caesar cannot answer.',
      svg_row('Victory that mercy cannot complete', [
          {'n': 1, 'label': 'Thapsus (46 BC)', 'sub': 'the Pompeians in Africa are destroyed', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Caesar offers clemency', 'sub': 'his policy: pardon Roman enemies', 'color': '#16a34a'},
          {'n': 3, 'label': 'Cato’s suicide', 'sub': 'chooses death over accepting Caesar’s mercy', 'color': '#9f1239'},
      ], edge_labels=['then', 'but'], takeaway='Cato denied Caesar the one thing he wanted — to be seen as merciful — by dying free rather than pardoned.', accent=AC),
      bg='Pompeian resistance regrouped in <b>Africa</b> under Cato, Scipio and others. Caesar crossed to destroy them.',
      people='<b>Cato the Younger</b>, the incorruptible defender of the old Republic; the Pompeian commanders defeated at Thapsus.',
      what='At <b>Thapsus (46 BC)</b> Caesar crushed the Pompeian army. Rather than accept a pardon and live under Caesar’s rule, <b>Cato took his own life</b> at Utica — a deliberate act of defiance.',
      crux='Cato’s suicide was a <b>political weapon</b>: by refusing Caesar’s clemency and dying free, he made himself a martyr for the Republic and denied Caesar the reconciliation he craved.',
      conseq='Caesar was now nearly unchallenged, but Cato became an enduring symbol of republican virtue — a rebuke that outlived them both.',
      matters='Mercy only works if the enemy accepts it. A principled opponent can turn even defeat and death into a lasting moral victory.'),

    E('munda', '45 BC', 'Munda — the last, hardest fight', ['BATTLE', 'TRIUMPH'],
      'Pompey’s sons raise one final army in Spain, and at Munda Caesar fights the most desperate battle of his life — later saying that before he had fought for victory, but at Munda he fought for his life.',
      svg_row('The bloodiest, closest win of all', [
          {'n': 1, 'label': 'Pompey’s sons rally Spain', 'sub': 'a last, large Pompeian army', 'color': '#dc2626'},
          {'n': 2, 'label': 'A desperate battle', 'sub': 'Caesar himself steadies the wavering line', 'color': '#b45309'},
          {'n': 3, 'label': 'Total victory', 'sub': 'the war ends; “I fought for my life”', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='Even at the end, the hardest fight was the last one — victory was never as easy as the legend suggests.', accent=AC),
      bg='The final Pompeian holdouts, led by Pompey’s sons <b>Gnaeus and Sextus</b>, raised a large army in <b>Spain</b> in 45 BC.',
      people='Pompey’s sons; the veteran Pompeian legions who fought bitterly; Caesar, who reportedly considered suicide if the day was lost.',
      what='At <b>Munda (45 BC)</b>, in a brutal, closely fought battle, Caesar’s line nearly broke before he rallied it in person and won. He later said that in earlier battles he had fought for victory, but at Munda <b>he fought for his life</b>.',
      crux='The <b>closest, bloodiest</b> of his victories ended the civil war — a reminder that his supremacy was won by desperate fighting, not effortless genius.',
      conseq='With the last resistance crushed, Caesar returned to Rome as its undisputed master — and made his rule permanent.',
      matters='The final obstacle is often the hardest. Success can hinge on one desperate effort when everything is already at stake.'),

    E('triumphs', '46 BC', 'Four triumphs — the greatest spectacle Rome had seen', ['TRIUMPH', 'POLITICS'],
      'Master of the world, he celebrates his victories with four spectacular triumphs in a single month — parading the spoils of Gaul, Egypt, Pontus and Africa, feasting the entire city, and cancelling debts and distributing gifts — a dazzling display of power and generosity designed to bind Rome to him with awe and gratitude.',
      svg_row('Power made into spectacle', [
          {'n': 1, 'label': 'Four triumphs in a month', 'sub': 'Gaul, Egypt, Pontus, Africa paraded', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Feasts and games for all', 'sub': 'the whole city banqueted and entertained', 'color': '#b45309'},
          {'n': 3, 'label': 'Gifts and debt relief', 'sub': 'binds Rome to him with awe and gratitude', 'color': '#166534'},
      ], edge_labels=['plus', 'so'], takeaway='He turned victory into unprecedented spectacle and largesse — binding Rome to him through awe and generosity.', accent=AC),
      bg='Having won the civil war, Caesar celebrated his triumphs in <b>46 BC</b> on a scale Rome had never witnessed.',
      people='The Roman people, feasted and entertained; the captives paraded (including Vercingetorix, executed at the Gallic triumph).',
      what='Caesar held <b>four great triumphs</b> in a single month for his victories in <b>Gaul, Egypt, Pontus and Africa</b>, staging vast <b>games, feasts for the whole city</b>, and distributing money and relief — an overwhelming display of power and generosity.',
      crux='He used <b>spectacle and largesse as instruments of power</b>, binding the Roman people to him through awe, entertainment and gratitude.',
      conseq='His popularity soared to unprecedented heights, even as elite fears of his dominance deepened.',
      matters='Caesar understood politics as theatre. His triumphs were a masterclass in binding a people to a leader through spectacle.'),

    E('legions', '58–45 BC', 'The bond with the legions — his true power base', ['POLITICS', 'BATTLE'],
      'The deepest source of his power is the fanatical devotion of his soldiers: he shares their hardships, doubles their pay, remembers their names, calls them "comrades," and leads from the front — a bond so strong that when he once quells a mutiny by coldly addressing his men as mere "citizens" instead of "soldiers," they beg to be taken back.',
      svg_row('An army that loved him', [
          {'n': 1, 'label': 'Shares their hardships', 'sub': 'marches, eats and fights alongside them', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Rewards and remembers them', 'sub': 'doubles their pay; knows their names', 'color': '#166534'},
          {'n': 3, 'label': 'The “Quirites” mutiny', 'sub': 'one cold word — “citizens” — breaks a mutiny', 'color': '#b45309'},
      ], edge_labels=['plus', 'so'], takeaway='His soldiers’ fanatical loyalty was the real foundation of his power — an army that followed him against Rome itself.', accent=AC),
      bg='Caesar’s ultimate power rested not on the Senate but on the <b>fierce loyalty of his legions</b>, built over years of shared campaigning.',
      people='His veteran <b>legions</b>, especially the famed Tenth; the soldiers whose devotion he cultivated relentlessly.',
      what='Caesar bound his soldiers with <b>shared hardship, doubled pay, personal recognition and front-line leadership</b>. Their devotion was legendary: when a mutinous legion demanded discharge, he <b>coldly addressed them as “citizens” (Quirites)</b> rather than “soldiers,” and the shamed men <b>begged to be taken back</b>.',
      crux='His deepest power base was <b>the personal loyalty of his army</b> — a professional force devoted to him, not the state, which he could turn even against Rome.',
      conseq='This loyalty let him cross the Rubicon and win the civil war; it also marked the fatal shift of Roman armies’ allegiance from Republic to general.',
      matters='Caesar’s legions loved him — and that personal army, loyal to a man over the state, is what let one man overturn the Republic.'),

    E('reforms', '46–44 BC', 'Dictator for life — reform, and the fatal crown', ['REFORM', 'POLITICS', 'TURNING POINT'],
      'Master of Rome, he uses absolute power not to slaughter enemies but to reform the state — a new calendar, debt relief, colonies, citizenship — yet by taking the title dictator for life, he starts to look unbearably like a king.',
      svg_stack('What he did with total power — and the line he crossed', [
          {'n': 1, 'label': 'The Julian calendar', 'sub': 'fixes the year — the basis of ours today', 'color': '#0891b2'},
          {'n': 2, 'label': 'Reforms', 'sub': 'debt relief, veteran colonies, citizenship extended, Senate enlarged', 'color': '#16a34a'},
          {'n': 3, 'label': 'Clemency', 'sub': 'pardons enemies instead of proscribing them', 'color': '#7e22ce'},
          {'n': 4, 'label': 'Dictator perpetuo (44 BC)', 'sub': 'power for life + royal honours → he looks like a king', 'color': '#dc2626'},
      ], takeaway='He used power to build, not purge — but making that power permanent is exactly what got him killed.', accent=AC),
      bg='After Munda, Caesar was the unchallenged master of Rome. How he used that power — and how permanent he made it — would decide his fate.',
      people='The senators he pardoned (some of whom would kill him); <b>Mark Antony</b>, who offered him a crown in public (which he theatrically refused); the reformers who implemented his laws.',
      what='Caesar reformed the <b>calendar</b> (the Julian calendar, basis of ours), relieved debt, settled veterans and the poor in <b>colonies</b>, extended <b>citizenship</b>, enlarged the Senate, and pardoned enemies. But in 44 BC he became <b>dictator perpetuo</b> — dictator for life — with near-royal honours.',
      crux='He turned domination into <b>useful administration</b>, but by accepting <b>lifelong</b> one-man rule and kingly trappings he crossed the line Rome could not forgive: he looked like a <b>king</b>, the one thing the Republic was founded to prevent.',
      conseq='Rome got lasting reforms (we still use his calendar), but the Republic was effectively dead — and to the old elite, dictator-for-life was intolerable.',
      matters='It’s not only how you use power, but how permanent you make it. Rome could accept a temporary strongman; a permanent one it would kill.'),

    E('clementia', '49–44 BC', 'The clemency that killed him', ['POLITICS', 'REFORM', 'TRAGEDY'],
      'His most admired and most fatal policy is mercy: breaking with the bloody proscriptions of Sulla and Marius, he pardons his defeated enemies again and again — including Brutus and Cassius — winning a reputation for greatness of spirit, but also, fatally, sparing the very men who will gather around him with daggers on the Ides of March.',
      svg_compare('Mercy — noble, and fatal',
          {'head': 'The nobility of clemency', 'color': '#166534',
           'items': ['no proscriptions or mass killings', 'pardons defeated foes, even Brutus and Cassius', 'wins fame for magnanimity']},
          {'head': 'The fatal cost', 'color': '#7f1d1d',
           'items': ['spares the men who will kill him', 'pardoned enemies feel humiliated, not grateful', 'his mercy arms his assassins']},
          verdict='The policy that most ennobled him also, directly, put the daggers in his enemies’ hands.',
          takeaway='His famous clemency spared the very men who murdered him — mercy that was both his glory and his undoing.', accent=AC),
      bg='In contrast to the murderous proscriptions of earlier strongmen like Sulla, Caesar made <b>clemency (clementia)</b> a hallmark of his rule.',
      people='The pardoned enemies — including <b>Brutus</b> and <b>Cassius</b>, who would lead his assassination; the Romans who admired his mercy.',
      what='Caesar <b>repeatedly pardoned his defeated enemies</b> rather than killing them, breaking with the bloody tradition of proscriptions — famously sparing <b>Brutus and Cassius</b>, who would later organise his murder on the <b>Ides of March</b>.',
      crux='His clemency was <b>genuinely noble and genuinely fatal</b>: it won him admiration but also spared — and humiliated — the men who would kill him.',
      conseq='The pardoned conspirators, resentful of owing their lives to a would-be king, gathered to assassinate him.',
      matters='Even mercy can be a mortal risk. Caesar’s clemency was his noblest trait — and it directly enabled his own murder.'),
]

# ==================================================================  PHASE 6 — THE IDES
PHASE_IDES = [
    E('ides', '15 Mar 44 BC', 'The Ides of March', ['TRAGEDY', 'DEATH', 'TURNING POINT'],
      'Fearing he means to make himself king, some sixty senators — including men he had pardoned — surround Caesar at a Senate meeting and stab him twenty-three times. Among them is Brutus.',
      svg_ides(),
      bg='Caesar’s lifelong dictatorship and royal trappings convinced many senators he intended monarchy — the one thing the Republic was founded to prevent.',
      people='<b>Marcus Junius Brutus</b> (whom Caesar had pardoned and favoured) and <b>Gaius Cassius Longinus</b> led the plot; <b>Mark Antony</b>, kept away; <b>Calpurnia</b>, his wife, who reportedly begged him not to go.',
      what='On <b>15 March 44 BC</b> (the Ides), the conspirators — the self-styled <b>Liberatores</b> — surrounded Caesar at the Senate (meeting in the Theatre of Pompey) and stabbed him <b>23 times</b>. (Shakespeare’s “Et tu, Brute?” is invention; Suetonius reports a Greek phrase, “kai su, teknon?”, and even that is doubted.)',
      crux='They believed removing the man would restore the free Republic. But the Republic’s institutions were already hollow; killing Caesar removed a ruler, not the underlying collapse that produced him.',
      conseq='The murder triggered not a restored Republic but a fresh round of civil wars — between the assassins and Caesar’s avengers, then among the avengers themselves.',
      matters='You cannot fix a broken system by killing the one person who filled the vacuum. The vacuum remains — and usually something worse rushes in.'),

    E('aftermath', '44–27 BC', 'The Republic dies anyway — and the Empire is born', ['POLITICS', 'TURNING POINT'],
      'The assassins wanted to save the Republic. Instead, Caesar’s name and fortune pass to his teenage grand-nephew Octavian, who wins the wars that follow and becomes Augustus, Rome’s first emperor.',
      svg_row('The opposite of what the killers intended', [
          {'n': 1, 'label': 'Caesar deified; heir named', 'sub': 'his will adopts Octavian, his grand-nephew', 'color': '#64748b'},
          {'n': 2, 'label': 'Avengers vs Liberators', 'sub': 'Antony & Octavian crush Brutus & Cassius (Philippi 42)', 'color': '#dc2626'},
          {'n': 3, 'label': 'Octavian → Augustus (27 BC)', 'sub': 'wins the final war (Actium); becomes first emperor', 'color': '#7e22ce'},
      ], edge_labels=['then', 'then'], takeaway='Caesar lost his life but won history: his heir turned his name into a 400-year empire — and a title, “Caesar,” that outlived Rome.', accent=AC),
      bg='Caesar’s <b>will</b> adopted his 18-year-old grand-nephew <b>Octavian</b> and left him his name, fortune and the loyalty of his veterans — a young man almost no one had reckoned with.',
      people='<b>Octavian</b> (the future <b>Augustus</b>); <b>Mark Antony</b> and <b>Cleopatra</b>, his eventual rivals; <b>Brutus</b> and <b>Cassius</b>, defeated at Philippi (42 BC).',
      what='Antony and Octavian first destroyed the assassins, then turned on each other. Octavian won at <b>Actium (31 BC)</b> and by <b>27 BC</b> became <b>Augustus</b>, first Roman <b>emperor</b>. The name “Caesar” became the very word for ruler (Kaiser, Tsar).',
      crux='By naming a capable heir and leaving him name, money and soldiers, Caesar ensured his cause <b>outlived his body</b>. The assassination accelerated exactly the monarchy the killers feared.',
      conseq='Rome became an empire that lasted centuries. Caesar’s reforms endured; his name became a title across Europe for two thousand years.',
      matters='Legacy is about succession. Caesar’s greatest victory came after death — because he had an heir ready to carry the name and the loyalty forward.'),
]

OVERVIEW_HTML = """
<p class="ov-lead">Gaius Julius Caesar rose from a debt-ridden aristocrat in a decaying republic to the master of the Roman world — conqueror of all Gaul, victor of a civil war fought across three continents, and dictator for life — before falling to the daggers of the men who feared he had become a king. This guide follows the whole story in detail: the full eight-year Gallic War, the entire civil war from the Rubicon to Munda, the reforms, and the assassination. His murder didn’t save the Republic; it <b>ended</b> it, clearing the way for the Roman Empire and making his name, “Caesar,” the very word for ruler for two thousand years.</p>
<div class="ov-quote">“Alea iacta est.” — “The die is cast.”<span>— reportedly said as he crossed the Rubicon in 49 BC, beginning the civil war</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Faded patrician → popular showman who buys his way up the ladder → one leg of a secret three-man pact → conqueror of Gaul (Helvetii, Ariovistus, the Belgae, Britain, the Eburones revolt, Gergovia, Alesia) → crosses the Rubicon → wins the civil war (Ilerda, a loss at Dyrrhachium, then Pharsalus, Zela, Thapsus, Munda) → dictator and reformer → assassinated on the Ides → his heir Octavian becomes Augustus and the Republic becomes an Empire.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">📅</div><h4>The calendar</h4><p>The Julian calendar he imposed is the direct basis of the one the world uses today — July is named for him.</p></div>
  <div class="ov-card"><div class="i">👑</div><h4>“Caesar” = ruler</h4><p>His name became a title: Kaiser, Tsar. The end of his Republic created the imperial model that shaped Europe.</p></div>
  <div class="ov-card"><div class="i">✍️</div><h4>Narrative as power</h4><p>His Commentarii show how controlling the story of your own deeds is as strategic as the deeds themselves.</p></div>
  <div class="ov-card"><div class="i">⚠️</div><h4>How republics die</h4><p>The definitive case study in ambition, loyal armies, and how a free state slides into one-man rule.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Rise</b><small> 100–60 BC</small><p>Faded blood, huge debts, pirates, and buying the crowd.</p></div>
  <div><b>2 · Triumvirate</b><small> 60–59 BC</small><p>The secret pact with Pompey and Crassus; the consulship.</p></div>
  <div><b>3 · Gaul</b><small> 58–50 BC</small><p>Eight years of conquest — Helvetii to Alesia.</p></div>
  <div><b>4 · Civil War</b><small> 49–48 BC</small><p>The Rubicon, Ilerda, Dyrrhachium, Pharsalus.</p></div>
  <div><b>5 · Dictator</b><small> 48–45 BC</small><p>Cleopatra, Zela, Thapsus, Munda, and reform.</p></div>
  <div><b>6 · The Ides</b><small> 44 BC</small><p>Assassination — and the Empire it accidentally made.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b> for dates, <b>Who’s Who</b> for the cast, and <b>Master Timeline</b> for the whole life in one scroll.</p>
"""

WHO = [
    {'name': 'Pompey the Great', 'role': 'ally → rival', 'color': '#2563eb',
     'bio': 'Rome’s most celebrated general and Caesar’s partner (and son-in-law) in the Triumvirate. After Julia’s and Crassus’s deaths he became the Senate’s champion — beaten at Pharsalus, then murdered in Egypt.',
     'rel': 'Partner turned chief enemy; defeating him made Caesar supreme.'},
    {'name': 'Marcus Crassus', 'role': 'financier / triumvir', 'color': '#b45309',
     'bio': 'The richest man in Rome, who bankrolled Caesar’s early debts. The third leg of the Triumvirate; his death at Carrhae (53 BC) removed the balance between Caesar and Pompey.',
     'rel': 'His money made Caesar; his death made civil war inevitable.'},
    {'name': 'Cato the Younger', 'role': 'principled enemy', 'color': '#334155',
     'bio': 'The Senate’s incorruptible defender of the old Republic and Caesar’s most implacable opponent. Chose suicide at Utica (46 BC) rather than accept Caesar’s pardon — a martyr for the Republic.',
     'rel': 'The moral face of the resistance to Caesar’s rise.'},
    {'name': 'Cicero', 'role': 'orator / witness', 'color': '#0891b2',
     'bio': 'Rome’s greatest orator, a republican who admired and feared Caesar. Pardoned in the civil war; his letters are a key source. Killed in the aftermath by Antony’s men.',
     'rel': 'The eloquent conscience of the dying Republic.'},
    {'name': 'Vercingetorix', 'role': 'Gallic nemesis', 'color': '#dc2626',
     'bio': 'The chieftain who finally united the Gauls (52 BC) and used scorched-earth to beat Caesar at Gergovia — before being besieged and defeated at Alesia. Paraded in Caesar’s triumph and executed.',
     'rel': 'His near-victory, then defeat at Alesia, sealed the conquest of Gaul.'},
    {'name': 'Cleopatra VII', 'role': 'ally & lover (Egypt)', 'color': '#db2777',
     'bio': 'The brilliant last pharaoh of Egypt. Caesar backed her to the throne and took her as a lover; she bore a son, Caesarion, she claimed was his. Later allied with Mark Antony.',
     'rel': 'His dynastic-personal alliance in the East — and fuel for Roman fears.'},
    {'name': 'Mark Antony', 'role': 'loyal deputy', 'color': '#7e22ce',
     'bio': 'Caesar’s trusted lieutenant, who commanded a wing at Pharsalus, roused Rome with the funeral oration, then fought Octavian for the succession and lost.',
     'rel': 'His most loyal general — who avenged him, then lost the empire.'},
    {'name': 'Marcus Brutus', 'role': 'assassin', 'color': '#475569',
     'bio': 'A respected republican whom Caesar pardoned and favoured. Persuaded by conscience and Cassius to join the plot; his role gave the murder its moral cover. Defeated at Philippi (42 BC).',
     'rel': 'The pardoned friend whose betrayal defined the tragedy.'},
    {'name': 'Cassius', 'role': 'lead conspirator', 'color': '#57534e',
     'bio': 'The driving organiser of the conspiracy — sharper and more resolute than Brutus. Recruited the senators who struck Caesar down; dead at Philippi.',
     'rel': 'The prime mover of the assassination plot.'},
    {'name': 'Octavian / Augustus', 'role': 'heir → first emperor', 'color': '#16a34a',
     'bio': 'Caesar’s teenage grand-nephew, adopted as heir in his will. Turned that name and fortune into victory over the assassins and then Antony, becoming Augustus, first Roman emperor (27 BC).',
     'rel': 'Caesar’s true legacy: the heir who turned his name into an empire.'},
    {'name': 'Sulla', 'role': 'the earlier dictator', 'color': '#991b1b',
     'bio': 'The dictator whose proscriptions nearly killed the young Caesar. Sulla resigned his power; Caesar, unlike him, never let go — which cost him his life.',
     'rel': 'The cautionary precedent Caesar survived and refused to imitate.'},
    {'name': 'Julia', 'role': 'daughter / the bond', 'color': '#f472b6',
     'bio': 'Caesar’s beloved daughter, married to Pompey to seal the Triumvirate. Her death in childbirth (54 BC) removed the personal tie holding the two men together.',
     'rel': 'The human bond whose loss helped unravel the alliance.'},
    {'name': 'Ambiorix', 'role': 'Gallic rebel', 'color': '#78350f',
     'bio': 'The chieftain of the Eburones who lured a Roman legion to destruction in 54 BC — the worst defeat of the Gallic War — and then eluded Caesar’s vengeance for good.',
     'rel': 'Inflicted Caesar’s worst Gallic disaster and got away with it.'},
]

KEY_EVENTS = [
    ('100 BC', 'Born into the patrician gens Julia', 'A prestigious but sidelined family, tied to Marius.'),
    ('c. 82 BC', 'Defies Sulla; is spared', '“In that boy are many Mariuses.”'),
    ('75 BC', 'Captured by pirates', 'Jokes, escapes, returns and crucifies them.'),
    ('63 BC', 'Elected Pontifex Maximus', 'Wins Rome’s top priesthood by audacious bribery.'),
    ('60 BC', 'First Triumvirate formed', 'Secret pact with Pompey and Crassus.'),
    ('59 BC', 'Consul; secures Gaul', 'Forces through his agenda; wins a long command.'),
    ('58 BC', 'Helvetii & Ariovistus', 'The Gallic War opens; Germans driven back over the Rhine.'),
    ('57 BC', 'The Belgae; the Sabis', 'A near-disaster reversed by his personal leadership.'),
    ('55 & 54 BC', 'Rhine bridge; invasions of Britain', 'Feats of engineering and propaganda.'),
    ('54 BC', 'The Eburones destroy a legion', 'Ambiorix inflicts the war’s worst defeat.'),
    ('52 BC', 'Gergovia (defeat) & Alesia (victory)', 'Vercingetorix beats him, then is crushed at Alesia.'),
    ('54–53 BC', 'Julia and Crassus die', 'The Triumvirate breaks; Pompey drifts to the Senate.'),
    ('Jan 49 BC', 'Crosses the Rubicon', '“The die is cast.” Civil war begins.'),
    ('49 BC', 'Ilerda (Spain)', 'Out-manoeuvres Pompey’s legions; secures his rear.'),
    ('48 BC', 'Dyrrhachium (defeat)', 'Beaten by Pompey, but not pursued or destroyed.'),
    ('Aug 48 BC', 'Pharsalus', 'Outnumbered, he crushes Pompey, who flees and is killed.'),
    ('48–47 BC', 'Egypt & Cleopatra', 'The Alexandrian War; backs Cleopatra’s throne.'),
    ('47 BC', 'Zela', '“Veni, vidi, vici.”'),
    ('46 BC', 'Thapsus; Cato’s suicide', 'The African Pompeians crushed; Cato dies free.'),
    ('45 BC', 'Munda', 'The last, hardest battle; the civil war ends.'),
    ('46–44 BC', 'Reforms; the Julian calendar', 'Debt relief, colonies, citizenship, a new calendar.'),
    ('44 BC', 'Dictator perpetuo', 'Dictator for life — he now looks like a king.'),
    ('15 Mar 44 BC', 'Assassinated (the Ides of March)', 'Stabbed 23 times by ~60 senators, including Brutus.'),
    ('27 BC', 'Octavian becomes Augustus', 'Caesar’s heir ends the Republic; the Empire begins.'),
]

MASTER = [
    {'year': '100 BC', 'age': 'born', 'phase': 'Rise', 'title': 'Born into the gens Julia', 'desc': 'Patrician blood, little power, a Republic in crisis.'},
    {'year': 'c.82 BC', 'age': 'youth', 'phase': 'Rise', 'title': 'Defies Sulla', 'desc': 'Refuses to divorce Cornelia; is spared.'},
    {'year': '63 BC', 'age': 'age ~37', 'phase': 'Rise', 'title': 'Pontifex Maximus', 'desc': 'Wins Rome’s chief priesthood by bold bribery.'},
    {'year': '60 BC', 'age': 'age ~40', 'phase': 'Triumvirate', 'title': 'The First Triumvirate', 'desc': 'Secret pact with Pompey and Crassus.'},
    {'year': '59 BC', 'age': 'age ~41', 'phase': 'Triumvirate', 'title': 'Consul', 'desc': 'Forces through his agenda; secures Gaul.'},
    {'year': '58 BC', 'age': 'age ~42', 'phase': 'Gaul', 'title': 'Gallic Wars begin', 'desc': 'Helvetii and Ariovistus defeated.'},
    {'year': '57 BC', 'age': 'age ~43', 'phase': 'Gaul', 'title': 'The Belgae', 'desc': 'A near-disaster at the Sabis, reversed in person.'},
    {'year': '52 BC', 'age': 'age ~48', 'phase': 'Gaul', 'title': 'Gergovia & Alesia', 'desc': 'A defeat, then the double siege that wins Gaul.'},
    {'year': '49 BC', 'age': 'age ~50', 'phase': 'Civil War', 'title': 'Crosses the Rubicon', 'desc': 'Civil war; secures Spain at Ilerda.'},
    {'year': '48 BC', 'age': 'age ~52', 'phase': 'Civil War', 'title': 'Dyrrhachium & Pharsalus', 'desc': 'A loss, then beats Pompey; Pompey murdered.'},
    {'year': '47 BC', 'age': 'age ~53', 'phase': 'Dictator', 'title': 'Cleopatra; “veni, vidi, vici”', 'desc': 'Egypt secured; Pharnaces crushed at Zela.'},
    {'year': '46 BC', 'age': 'age ~54', 'phase': 'Dictator', 'title': 'Thapsus; the calendar', 'desc': 'Cato dies; Caesar reforms Rome.'},
    {'year': '45 BC', 'age': 'age ~55', 'phase': 'Dictator', 'title': 'Munda', 'desc': 'The last Pompeian resistance is crushed.'},
    {'year': '44 BC', 'age': 'age 55', 'phase': 'The Ides', 'title': 'Dictator for life → assassinated', 'desc': 'Killed on the Ides of March by ~60 senators.'},
    {'year': '27 BC', 'age': 'legacy', 'phase': 'The Ides', 'title': 'Augustus & the Empire', 'desc': 'His heir ends the Republic; “Caesar” becomes a title.'},
]

SOURCES = [
    ('Britannica — Julius Caesar', 'https://www.britannica.com/biography/Julius-Caesar-Roman-ruler'),
    ('World History Encyclopedia — Julius Caesar', 'https://www.worldhistory.org/Julius_Caesar/'),
    ('Livius.org — Gaius Julius Caesar', 'https://www.livius.org/articles/person/caesar/'),
    ('Britannica — Gallic Wars', 'https://www.britannica.com/event/Gallic-Wars'),
    ('Britannica — Battle of Pharsalus', 'https://www.britannica.com/event/Battle-of-Pharsalus'),
    ('Wikipedia — Assassination of Julius Caesar', 'https://en.wikipedia.org/wiki/Assassination_of_Julius_Caesar'),
    ('Wikipedia — Julius Caesar', 'https://en.wikipedia.org/wiki/Julius_Caesar'),
]

def build_meta():
    return {
        'pid': 'gm-caesar.html', 'kind': 'man', 'emoji': '🏛️', 'accent': AC,
        'name': 'Julius Caesar', 'years': '100–44 BC', 'group': 'Ancient Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'From debt-ridden aristocrat to dictator of Rome — the full Gallic War and civil war, the rise that broke the Republic and the murder that built an Empire, in depth.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · Rise', 'type': 'timeline',
             'intro': 'A patrician with a great name, little power and enormous debts — climbing a corrupt ladder (and defying pirates and a dictator) in a Republic already tearing itself apart.', 'events': PHASE_RISE},
            {'id': 'triumvirate', 'label': '2 · Triumvirate', 'type': 'timeline',
             'intro': 'Blocked alone, three ambitious men pool their power in secret — and make the Senate irrelevant, winning Caesar the army he needs.', 'events': PHASE_TRIUMVIRATE},
            {'id': 'gaul', 'label': '3 · Gaul', 'type': 'timeline',
             'intro': 'Eight years of conquest — from the Helvetii and the Germans to the Belgae, Britain, a legion lost to revolt, a defeat at Gergovia, and the masterpiece of Alesia.', 'events': PHASE_GAUL},
            {'id': 'civil', 'label': '4 · Civil War', 'type': 'timeline',
             'intro': 'The alliance collapses; rather than submit, he crosses the Rubicon — securing Spain, surviving a defeat at Dyrrhachium, and destroying Pompey at Pharsalus.', 'events': PHASE_CIVIL},
            {'id': 'dictator', 'label': '5 · Dictator', 'type': 'timeline',
             'intro': 'Master of Rome, he settles the East with Cleopatra, crushes the last resistance from Zela to Munda, and uses total power to reform Rome — and to make his rule permanent.', 'events': PHASE_DICTATOR},
            {'id': 'ides', 'label': '6 · The Ides', 'type': 'timeline',
             'intro': 'Fearing a king, the senators strike. But killing the man does not restore the Republic — it destroys it for good, and makes his heir the first emperor.', 'events': PHASE_IDES,
             'sources': SOURCES, 'srcnote': 'Where lines are legendary (Shakespeare’s “Et tu, Brute?”) or figures are disputed (ancient casualty and enslavement numbers for Gaul, which Caesar himself reported), this guide flags the documented position.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
