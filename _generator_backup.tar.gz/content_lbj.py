# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Lyndon B. Johnson.
The Texas master of legislative power who won the Great Society and lost Vietnam."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#1e3a8a'  # LBJ navy blue

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE RISE
PHASE_RISE = [
    E('origins', '1908–1931', 'Hard land, hungry ambition — the Hill Country boy', ['RISE', 'REFORM'],
      'Born in the poor Texas Hill Country, Lyndon Johnson watches his father go broke and never forgets the humiliation of hard times — then, teaching dirt-poor Mexican-American children in Cotulla, he sees poverty’s face up close, forging a lifelong drive to gain power and use it to lift the powerless.',
      svg_row('Poverty makes an ambition', [
          {'n': 1, 'label': 'Born in the Hill Country, 1908', 'sub': 'near Stonewall, Texas; father Sam goes broke', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Teacher at Cotulla, 1928', 'sub': 'sees poor Mexican-American children up close', 'color': '#a16207'},
          {'n': 3, 'label': 'A hunger for power to help', 'sub': 'to lift the powerless as he climbs', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='The poverty that shamed his boyhood became the engine of his ambition — and the cause of his life.', accent=AC),
      bg='<b>Lyndon Baines Johnson</b> was born on 27 August 1908 near Stonewall in the hardscrabble <b>Texas Hill Country</b>; his father, state legislator Sam Ealy Johnson Jr., lost the family’s money and status.',
      people='his father <b>Sam Johnson</b>, the ruined legislator; his mother <b>Rebekah</b>; the poor children of <b>Cotulla, Texas</b> he taught in 1928–29.',
      what='After graduating <b>Southwest Texas State Teachers College (1930)</b>, Johnson taught Mexican-American pupils at the <b>Welhausen School in Cotulla</b>, an experience of raw poverty he would invoke all his life.',
      crux='Early hardship bred a <b>ferocious drive for power</b> — and a genuine conviction that government should lift the poor.',
      conseq='He left teaching for politics, determined to rise fast and far in Washington.',
      matters='Formative poverty can forge both ruthless ambition and real compassion — in Johnson the two were inseparable.'),

    E('congress', '1931–1941', 'The New Deal protégé — a young man in a hurry', ['RISE', 'POLITICS'],
      'Johnson storms into Washington as a congressional aide, runs Texas’s New Deal youth agency, and at 28 wins a seat in Congress as an ardent New Dealer and protégé of Franklin Roosevelt — mastering the machinery of federal power and the art of cultivating older, more powerful men.',
      svg_stack('Learning the machinery of power', [
          {'n': 1, 'label': 'Congressional secretary, 1931', 'sub': 'aide to Rep. Richard Kleberg; masters Capitol Hill', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Texas NYA director, 1935', 'sub': 'runs FDR’s youth relief agency at 26', 'color': '#a16207'},
          {'n': 3, 'label': 'Elected to Congress, 1937', 'sub': 'New Deal Democrat; protégé of Roosevelt', 'color': '#166534'},
      ], takeaway='He rose fast by mastering the levers of federal power and winning the favour of the men who held them.', accent=AC),
      bg='Johnson went to Washington in 1931 as a congressional secretary, arriving as Franklin Roosevelt’s <b>New Deal</b> remade the role of the federal government.',
      people='<b>Franklin D. Roosevelt</b>, his political idol and patron; Rep. <b>Richard Kleberg</b>, his first boss; <b>Lady Bird Johnson</b>, whom he married in 1934.',
      what='He directed the <b>Texas National Youth Administration (1935)</b>, then won a 1937 special election to the <b>U.S. House</b> on a fervent pro-Roosevelt platform, becoming an FDR favourite.',
      crux='He built power by <b>attaching himself to the powerful</b> — FDR above all — and delivering federal projects to his district.',
      conseq='He served in the House until 1949, briefly seeing wartime naval service and winning a Silver Star in 1942.',
      matters='Johnson’s genius for cultivating patrons and mastering institutions was visible from the start of his career.'),

    E('landslide', '1948', 'Landslide Lyndon — the stolen Senate seat', ['POLITICS', 'TURNING POINT', 'TRAGEDY'],
      'Johnson wins a U.S. Senate seat by a notorious 87 votes in a Democratic primary marred by fraud on both sides — the infamous "Box 13" in Jim Wells County delivering the margin — earning him the mocking nickname "Landslide Lyndon" and a seat that would become the stage for his mastery.',
      svg_compare('The 87-vote miracle',
        {'head': 'Coke Stevenson', 'color': '#b91c1c', 'items': ['popular former governor', 'led on election night', 'later challenges the result in court']},
        {'head': 'Lyndon Johnson', 'color': '#1e3a8a', 'items': ['trails, then “finds” new votes', 'Box 13, Jim Wells County, Alice', 'wins the primary by 87 votes']},
        'Amended returns from Box 13 in the town of Alice handed Johnson the runoff by 87 ballots.',
        'A disputed 87-vote win — “Landslide Lyndon” — carried him into the Senate that would make him.', AC),
      bg='In the 1948 Texas Democratic primary — tantamount to election in the one-party South — Johnson faced popular former governor <b>Coke Stevenson</b> in a bitter runoff.',
      people='<b>Coke Stevenson</b>, the front-runner Johnson beat; the political boss <b>George Parr</b>, whose county produced the crucial votes; <b>Robert Caro</b>, whose biography exposed the fraud.',
      what='Johnson won by <b>87 votes out of nearly a million</b>, after amended returns from <b>“Box 13” in Jim Wells County (Alice, Texas)</b> appeared days later; Stevenson’s legal challenge failed and Johnson took the seat.',
      crux='The election was <b>stolen amid fraud on both sides</b> — a taint of illegitimacy that shadowed him even as it launched his rise.',
      conseq='The mocking title <b>“Landslide Lyndon”</b> stuck, but the Senate gave him the arena in which his genius would flower.',
      matters='Johnson’s path to greatness ran through a tainted election — power won by any means, then used for large ends.'),
]

# ==================================================================  PHASE 2 — MASTER OF THE SENATE
PHASE_SENATE = [
    E('leader', '1953–1955', 'Master of the Senate — the youngest leader', ['POLITICS', 'TRIUMPH'],
      'Johnson rises through the Senate at breathtaking speed — chosen Democratic leader in 1953, the youngest ever, and Majority Leader by 1955 — where, as Robert Caro chronicles in "Master of the Senate," he turns a sleepy chamber into an instrument of his will.',
      svg_stack('The fastest rise in the Senate', [
          {'n': 1, 'label': 'Elected to the Senate, 1949', 'sub': 'quickly cultivates the powerful "Club"', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Democratic Leader, 1953', 'sub': 'the youngest floor leader in history', 'color': '#a16207'},
          {'n': 3, 'label': 'Majority Leader, 1955', 'sub': 'commands the chamber as few ever have', 'color': '#166534'},
      ], takeaway='He mastered the Senate faster than anyone before him — and bent it to his will.', accent=AC),
      bg='Entering the Senate in 1949, Johnson courted its power-brokers — above all Georgia’s <b>Richard Russell</b> — and rose with astonishing speed.',
      people='<b>Richard Russell</b> of Georgia, his mentor and patron; the Senate <b>“Club”</b> of senior members; <b>Robert Caro</b>, whose <i>Master of the Senate</i> anatomised his methods.',
      what='Johnson became <b>Democratic Leader in 1953</b> (the youngest in history) and <b>Majority Leader in 1955</b>, transforming the position into one of real command over legislation and members.',
      crux='He mastered the Senate by <b>counting votes, controlling schedules, and knowing every member’s needs and weaknesses</b> better than they did.',
      conseq='He suffered a serious <b>heart attack in 1955</b> but returned to dominate the chamber more completely than ever.',
      matters='Johnson made the Senate Majority Leader a genuinely powerful office — a lasting lesson in institutional mastery.'),

    E('treatment', '1955–1959', 'The Johnson Treatment — persuasion as force', ['POLITICS', 'REFORM'],
      'Johnson perfects the "Johnson Treatment" — an overwhelming, physical art of persuasion, looming over a senator, flattering, cajoling, threatening and pleading until resistance collapses — and uses it to pass the 1957 Civil Rights Act, the first such law since Reconstruction.',
      svg_row('Persuasion as an overwhelming force', [
          {'n': 1, 'label': 'The "Johnson Treatment"', 'sub': 'looms, flatters, threatens, pleads — all at once', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Reads every member', 'sub': 'knows each senator’s needs, fears and vanities', 'color': '#a16207'},
          {'n': 3, 'label': 'Civil Rights Act of 1957', 'sub': 'first civil-rights law since Reconstruction', 'color': '#166534'},
      ], edge_labels=['via', 'delivers'], takeaway='He turned face-to-face persuasion into an irresistible instrument — and used it to move the immovable.', accent=AC),
      bg='By the mid-1950s Johnson had made personal persuasion his signature weapon, deployed one senator at a time.',
      people='the senators he cornered and converted; journalists <b>Rowland Evans and Robert Novak</b>, who named the <b>“Treatment”</b>; <b>Richard Russell</b> and the Southern bloc he had to outmanoeuvre.',
      what='The <b>“Johnson Treatment”</b> — a physical, relentless close-quarters lobbying — helped him thread the <b>Civil Rights Act of 1957</b> through a Senate long deadlocked on race, the first such law since <b>Reconstruction</b>.',
      crux='He treated persuasion as <b>total war on a single will</b> — overwhelming a man with attention, information and pressure until he yielded.',
      conseq='The 1957 act was modest, but it broke a taboo and marked Johnson as a national figure who could deliver.',
      matters='Johnson proved that legislative power is ultimately about people — read them, and you can move the unmovable.'),

    E('vicepresident', '1960–1963', 'From rival to running mate — the frustrated Vice President', ['POLITICS', 'DEFEAT'],
      'Johnson runs for president in 1960, loses the nomination to the younger John F. Kennedy, then stuns his allies by accepting the vice presidency — helping carry Texas and the South for the ticket, only to find the office a gilded cage after the command of the Senate.',
      svg_stack('The gilded cage', [
          {'n': 1, 'label': 'Runs for President, 1960', 'sub': 'loses the nomination to John F. Kennedy', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Accepts the vice presidency', 'sub': 'balances the ticket; helps carry Texas & the South', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'Sidelined and frustrated', 'sub': 'the powerless office chafes the master of power', 'color': '#78350f'},
      ], takeaway='He traded the command of the Senate for a ceremonial office — and chafed in its powerlessness.', accent=AC),
      bg='In 1960 Johnson sought the Democratic nomination but was outrun by the charismatic young senator <b>John F. Kennedy</b>.',
      people='<b>John F. Kennedy</b>, the nominee and president; <b>Robert Kennedy</b>, who distrusted him; the Southern and Texan voters Johnson delivered.',
      what='Johnson accepted the <b>vice-presidential nomination</b>, helping the ticket <b>carry Texas and the South</b> in a razor-thin 1960 win — then found the office marginal after his Senate dominance.',
      crux='He calculated that the vice presidency, however hollow, was a <b>path to the presidency</b> worth the frustration.',
      conseq='For three years he waited, sidelined — until Dallas transformed his position overnight.',
      matters='Even the shrewdest strategist may accept a diminished role to stay near the ultimate prize.'),
]

# ==================================================================  PHASE 3 — THE GREAT SOCIETY
PHASE_GREAT = [
    E('assassination', '1963', 'Dallas — sworn in aboard Air Force One', ['POLITICS', 'TURNING POINT', 'DEATH'],
      'On 22 November 1963, John F. Kennedy is assassinated in Dallas and Johnson is sworn in as president aboard Air Force One, standing beside the slain president’s widow — then rallies a grieving nation with "Let us continue," turning mourning into momentum for Kennedy’s stalled agenda.',
      svg_stack('Mourning turned into momentum', [
          {'n': 1, 'label': 'JFK assassinated, 22 Nov 1963', 'sub': 'shot in Dallas, Texas', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Sworn in on Air Force One', 'sub': 'oath by Judge Sarah T. Hughes; Jackie beside him', 'color': '#1e3a8a'},
          {'n': 3, 'label': '“Let us continue”', 'sub': 'channels grief into Kennedy’s stalled agenda', 'color': '#166534'},
      ], takeaway='He took the oath in tragedy’s shadow — then converted a nation’s grief into legislative force.', accent=AC),
      bg='On <b>22 November 1963</b>, President Kennedy was assassinated in <b>Dallas</b>; Johnson, riding two cars behind, suddenly became president.',
      people='the murdered <b>John F. Kennedy</b>; <b>Jacqueline Kennedy</b>, at his side for the oath; Judge <b>Sarah T. Hughes</b>, who administered it.',
      what='Johnson was <b>sworn in aboard Air Force One</b> at Dallas’s Love Field, then told Congress <b>“Let us continue,”</b> vowing to pass Kennedy’s stalled civil-rights and tax measures as a memorial.',
      crux='He grasped that <b>national grief could be channelled into legislative momentum</b> no living president could have summoned.',
      conseq='Within months he drove through the tax cut and, above all, the landmark Civil Rights Act.',
      matters='Johnson turned the trauma of Dallas into the launchpad for the most productive reform presidency since the New Deal.'),

    E('civilrights', '1964', 'The Civil Rights Act — breaking the filibuster', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'Johnson makes the Civil Rights Act his monument — spending his Senate mastery and Kennedy’s memory to break the longest filibuster in history and sign, on 2 July 1964, the law that outlaws segregation in public life, knowing it will cost his party the South "for a generation."',
      svg_row('Cashing a lifetime of Senate power', [
          {'n': 1, 'label': 'Southern filibuster', 'sub': 'the longest in Senate history blocks the bill', 'color': '#b91c1c'},
          {'n': 2, 'label': 'LBJ and Dirksen break it', 'sub': 'wins over GOP leader Everett Dirksen for cloture', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'Civil Rights Act, 2 Jul 1964', 'sub': 'outlaws segregation in public accommodations', 'color': '#166534'},
      ], edge_labels=['broken by', 'yields'], takeaway='He spent every ounce of his legislative genius to end legal segregation — knowing the cost to his party.', accent=AC),
      bg='Kennedy’s civil-rights bill was stalled by a determined <b>Southern filibuster</b>; Johnson, a Southerner himself, resolved to pass it whole.',
      people='Republican leader <b>Everett Dirksen</b>, whose votes broke the filibuster; the Southern bloc led by his old mentor <b>Richard Russell</b>; the civil-rights movement pressing from outside.',
      what='Johnson mobilised his Senate mastery to win <b>cloture</b> against the longest filibuster in history and signed the <b>Civil Rights Act on 2 July 1964</b>, banning segregation in public accommodations and employment discrimination.',
      crux='He <b>spent his accumulated political capital</b> on the one cause he judged historic — reportedly saying it would lose the South for Democrats “for a generation.”',
      conseq='The act transformed American society and law — and began the realignment of the once-solid Democratic South toward the Republicans.',
      matters='Johnson proved a master politician could spend, not just hoard, power — on a cause larger than his own party’s interest.'),

    E('greatsociety', '1964–1965', 'The Great Society — a war on poverty', ['REFORM', 'TRIUMPH'],
      'Johnson unveils the "Great Society" — the most sweeping reform agenda since the New Deal — declaring an unconditional War on Poverty and driving through Congress a torrent of laws: Medicare and Medicaid, federal aid to education, Head Start, and the programs that reshape American government.',
      svg_stack('A torrent of reform', [
          {'n': 1, 'label': 'The Great Society, 1964', 'sub': 'unveiled at Ann Arbor; a War on Poverty declared', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Medicare & Medicaid, 1965', 'sub': 'health coverage for the aged and the poor', 'color': '#a16207'},
          {'n': 3, 'label': 'Education, Head Start & more', 'sub': 'federal aid to schools; the safety net expands', 'color': '#166534'},
      ], takeaway='He drove through the widest wave of domestic reform since Roosevelt — remaking the role of government.', accent=AC),
      bg='With huge Democratic majorities behind him, Johnson set out to build a <b>“Great Society”</b>, announced in a May 1964 speech at the University of Michigan.',
      people='the poor his programs targeted; the Congress he commanded; the reformers and administrators who built the new agencies.',
      what='Johnson declared an <b>unconditional War on Poverty</b> and won <b>Medicare and Medicaid (1965)</b>, the Economic Opportunity Act, <b>federal aid to education</b>, Head Start, food stamps and immigration reform — a legislative flood.',
      crux='He used <b>overwhelming majorities and relentless drive</b> to pass more landmark domestic laws than any president since the New Deal.',
      conseq='Poverty rates fell sharply and the programs endured for generations, though critics faulted their cost and reach.',
      matters='The Great Society remade the American state — Medicare, Medicaid and civil rights are Johnson’s enduring monument.'),
]

# ==================================================================  PHASE 4 — TRIUMPH AND THE TURN
PHASE_TURN = [
    E('landslide64', '1964', 'The 1964 landslide — a mandate to reform', ['POLITICS', 'TRIUMPH'],
      'Johnson wins the 1964 election in one of the greatest landslides in American history, crushing conservative Barry Goldwater with 61 percent of the vote and 486 electoral votes — a mandate, and the huge congressional majorities, that make the full Great Society possible.',
      svg_row('A landslide becomes a mandate', [
          {'n': 1, 'label': 'Beats Barry Goldwater', 'sub': 'paints him as a dangerous extremist', 'color': '#1e3a8a'},
          {'n': 2, 'label': '61% and 486 electoral votes', 'sub': 'one of the largest landslides ever', 'color': '#a16207'},
          {'n': 3, 'label': 'Vast congressional majorities', 'sub': 'the numbers to pass the Great Society', 'color': '#166534'},
      ], edge_labels=['by', 'yields'], takeaway='His crushing win gave him the congressional numbers to enact the boldest reform agenda in a generation.', accent=AC),
      bg='In 1964 Johnson faced conservative Republican <b>Barry Goldwater</b>, whom his campaign cast as a reckless extremist (the famous “Daisy” ad).',
      people='<b>Barry Goldwater</b>, the defeated Republican; running mate <b>Hubert Humphrey</b>; the voters who handed Johnson a landslide.',
      what='Johnson won <b>about 61% of the popular vote and 486 electoral votes to 52</b> — among the biggest landslides in U.S. history — sweeping in huge Democratic majorities in Congress.',
      crux='The mandate translated directly into <b>legislative power</b> — the votes that made the 1965 wave of Great Society laws possible.',
      conseq='With those majorities he passed Medicare, the Voting Rights Act, and much more in a single extraordinary year.',
      matters='Johnson’s 1964 landslide shows how an electoral mandate can be cashed into a historic burst of legislation.'),

    E('votingrights', '1965', 'Selma and the Voting Rights Act', ['REFORM', 'TRIUMPH'],
      'After the brutal images of Selma shock the nation, Johnson goes before Congress and, adopting the movement’s own anthem — "We shall overcome" — demands and wins the Voting Rights Act of 1965, striking down the barriers that had disenfranchised Black Americans for a century.',
      svg_stack('The vote won at last', [
          {'n': 1, 'label': 'Selma, March 1965', 'sub': '“Bloody Sunday” shocks the nation', 'color': '#b91c1c'},
          {'n': 2, 'label': '“We shall overcome”', 'sub': 'LBJ takes the movement’s anthem to Congress', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'Voting Rights Act, 6 Aug 1965', 'sub': 'ends literacy tests and disenfranchisement', 'color': '#166534'},
      ], takeaway='He answered Selma with the law that finally secured Black Americans the ballot.', accent=AC),
      bg='In early 1965 the voting-rights campaign in <b>Selma, Alabama</b> met violent repression on <b>“Bloody Sunday,”</b> broadcast into American homes.',
      people='<b>Martin Luther King Jr.</b> and the Selma marchers; the segregationist officials who beat them; a Congress Johnson pressed for action.',
      what='Johnson delivered a landmark address invoking <b>“We shall overcome,”</b> then signed the <b>Voting Rights Act on 6 August 1965</b>, banning literacy tests and authorising federal oversight of elections.',
      crux='He seized the <b>moral moment of Selma</b> to push through the law that gave civil rights their essential enforcement — the vote.',
      conseq='Black voter registration in the South surged, permanently transforming American politics.',
      matters='The Voting Rights Act, paired with the 1964 Civil Rights Act, is the legislative heart of the Second Reconstruction.'),

    E('tonkin', '1964–1965', 'The Gulf of Tonkin — a blank check for war', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'Even as he wins his domestic triumphs, Johnson takes the fateful step into Vietnam — using a murky clash in the Gulf of Tonkin to win a near-unanimous congressional resolution that becomes his blank check for war, then unleashing sustained bombing and, in 1965, the first American ground troops.',
      svg_row('A murky clash becomes a war', [
          {'n': 1, 'label': 'Gulf of Tonkin, Aug 1964', 'sub': 'reported attacks on U.S. destroyers', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Tonkin Resolution, 7 Aug 1964', 'sub': 'passes 416–0 in the House, 88–2 in the Senate', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'Escalation, 1965', 'sub': 'Rolling Thunder bombing; first ground troops', 'color': '#78350f'},
      ], edge_labels=['yields', 'enables'], takeaway='A murky naval incident became the legal warrant for a war that would consume his presidency.', accent=AC),
      bg='In August 1964 U.S. destroyers reported clashes with North Vietnamese boats in the <b>Gulf of Tonkin</b>; the second, disputed attack was likely misread.',
      people='Defense Secretary <b>Robert McNamara</b>, architect of escalation; the senators <b>Wayne Morse and Ernest Gruening</b>, the only two to vote no; the North Vietnamese leadership.',
      what='Johnson won the <b>Gulf of Tonkin Resolution on 7 August 1964 (416–0 House; 88–2 Senate)</b>, an open-ended authorisation, then launched <b>Operation Rolling Thunder</b> and sent the first U.S. ground combat troops in 1965.',
      crux='He used a <b>contested incident to obtain a sweeping mandate</b>, then escalated a war he privately doubted could be won cheaply.',
      conseq='The resolution became the legal basis for a vast war — and later a symbol of executive overreach and deception.',
      matters='The Gulf of Tonkin is a lasting warning about how thin pretexts and blank checks can pull a nation into war.'),
]

# ==================================================================  PHASE 5 — VIETNAM AND THE FALL
PHASE_FALL = [
    E('escalation', '1965–1967', 'Guns and butter — the war swallows the presidency', ['BATTLE', 'TRAGEDY'],
      'Johnson tries to fight the Vietnam War and build the Great Society at once — "guns and butter" — pouring in half a million troops while insisting the nation can afford both, but the mounting casualties and the growing gap between his rosy claims and the grim reality open a corrosive "credibility gap."',
      svg_compare('Guns and butter — the impossible balance',
        {'head': 'The war (guns)', 'color': '#b91c1c', 'items': ['troops climb toward ~500,000', 'bombing and rising casualties', 'no victory in sight']},
        {'head': 'The Great Society (butter)', 'color': '#166534', 'items': ['reform programs to fund', 'a booming domestic agenda', 'promises he means to keep']},
        'Trying to fund both at once strained the budget and eroded trust in his rosy war reports.',
        'The attempt to have both war and reform bred inflation abroad and a “credibility gap” at home.', AC),
      bg='From 1965 Johnson steadily escalated, unwilling to “lose” Vietnam yet determined to protect his domestic programs.',
      people='General <b>William Westmoreland</b>, commanding in Vietnam; Defense Secretary <b>Robert McNamara</b>, whose faith in the war waned; a rising anti-war movement.',
      what='U.S. troop levels climbed toward <b>roughly half a million</b> by 1968; Johnson pursued <b>“guns and butter,”</b> insisting America could afford both war and reform, while casualties mounted and no victory came.',
      crux='The widening gulf between his <b>optimistic public claims and the grim battlefield reality</b> opened the corrosive <b>“credibility gap.”</b>',
      conseq='The war’s cost fed inflation and division, and drained the political capital that had powered the Great Society.',
      matters='Johnson’s tragedy was believing he could have everything — and losing the nation’s trust when the war belied his words.'),

    E('tet', '1968', 'Tet — the year everything breaks', ['BATTLE', 'DEFEAT', 'TRAGEDY'],
      'The 1968 Tet Offensive shatters Johnson’s claims that victory is near — and though a military defeat for the enemy, it is a devastating political blow at home, as Walter Cronkite declares the war a stalemate and a challenger nearly beats a sitting president in the New Hampshire primary.',
      svg_stack('The illusion of victory shatters', [
          {'n': 1, 'label': 'Tet Offensive, Jan 1968', 'sub': 'coordinated assault across South Vietnam', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Cronkite calls it a stalemate', 'sub': '“the most trusted man in America” turns', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'New Hampshire, March 1968', 'sub': 'McCarthy nearly beats a sitting president', 'color': '#78350f'},
      ], takeaway='Tet was a battlefield defeat for the enemy but a political catastrophe for Johnson at home.', accent=AC),
      bg='In late January 1968 the North launched the massive <b>Tet Offensive</b>, striking cities across South Vietnam — including the U.S. embassy in Saigon.',
      people='anchor <b>Walter Cronkite</b>, whose verdict swayed opinion; anti-war senator <b>Eugene McCarthy</b>; <b>Robert Kennedy</b>, who soon entered the race.',
      what='Though Tet was <b>repulsed militarily</b>, it exposed Johnson’s optimism as hollow; Cronkite pronounced the war a <b>stalemate</b>, and <b>Eugene McCarthy nearly beat Johnson in the New Hampshire primary</b> in March.',
      crux='The offensive destroyed the <b>credibility of his central promise</b> — that the end was in sight — and broke his political standing.',
      conseq='With his own party fracturing and Robert Kennedy entering the race, Johnson’s position collapsed within weeks.',
      matters='Tet shows how a battlefield “victory” can be a strategic defeat when it shatters the public’s belief in the cause.'),

    E('notseek', '1968–1973', '“I shall not seek” — the broken president', ['POLITICS', 'DEFEAT', 'DEATH'],
      'On 31 March 1968 a spent Johnson stuns the nation, announcing a bombing halt and then — "I shall not seek, and I will not accept, the nomination of my party for another term" — walking away from power, the master of politics broken by a war he could neither win nor end. He dies in January 1973.',
      svg_stack('The master walks away', [
          {'n': 1, 'label': '“I shall not seek…”, 31 Mar 1968', 'sub': 'renounces re-election; halts much of the bombing', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'A year of turmoil', 'sub': 'King and RFK killed; chaos at the Chicago convention', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Retirement and death, 1973', 'sub': 'returns to his Texas ranch; dies 22 Jan 1973', 'color': '#111827'},
      ], takeaway='The greatest legislative president of his age was broken by Vietnam — and chose to walk away.', accent=AC),
      bg='By March 1968, besieged by the war, a near-loss in New Hampshire, and a fracturing party, Johnson concluded he could not both govern and campaign.',
      people='his successor <b>Richard Nixon</b>; the assassinated <b>Martin Luther King Jr.</b> and <b>Robert Kennedy</b>; Vice President <b>Hubert Humphrey</b>, who lost that November.',
      what='In a televised address on <b>31 March 1968</b> Johnson announced a partial bombing halt and declared <b>“I shall not seek, and I will not accept, the nomination of my party for another term,”</b> stunning the nation; he retired to his Texas ranch and died of a heart attack on <b>22 January 1973</b>.',
      crux='The paradox of his presidency was complete — <b>historic domestic triumphs and a catastrophic war</b>, the second overwhelming the first.',
      conseq='Vietnam ground on; his reputation, long overshadowed by the war, was later partly restored by recognition of his reforms.',
      matters='Johnson embodies the tragedy of power — one of the great reform records in American history, broken by a war he could not master.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Lyndon B. Johnson was the supreme master of American legislative power — and the president broken by Vietnam. From dirt-poor beginnings in the Texas Hill Country he clawed his way up through Congress and the Senate, where the “Johnson Treatment” made him the most effective leader the chamber has ever seen. Sworn in after Kennedy’s assassination, he drove through the greatest wave of reform since the New Deal — the Civil Rights Act, the Voting Rights Act, Medicare, Medicaid and the Great Society — then destroyed his presidency in the jungles of Vietnam. He is the ultimate study in <b>the uses and the tragedy of power — a giant of reform undone by a war he could neither win nor abandon.</b></p>
<div class="ov-quote">“I shall not seek, and I will not accept, the nomination of my party for another term as your President.”<span>— Lyndon B. Johnson, 31 March 1968</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A poor Hill Country boy hungers for power → rises through Congress as a New Deal protégé → wins the Senate by a stolen 87 votes → becomes its youngest and greatest leader → loses to Kennedy, then serves as his frustrated Vice President → is sworn in after Dallas and passes the Civil Rights Act, the Voting Rights Act and the Great Society → wins a historic 1964 landslide → but escalates the Vietnam War, opens a “credibility gap,” is broken by Tet, and walks away in 1968.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🏛️</div><h4>Master of the Senate</h4><p>Made legislative persuasion — the “Johnson Treatment” — an art of power.</p></div>
  <div class="ov-card"><div class="i">✊</div><h4>Civil & voting rights</h4><p>Passed the landmark laws of the Second Reconstruction.</p></div>
  <div class="ov-card"><div class="i">🩺</div><h4>The Great Society</h4><p>Medicare, Medicaid and the War on Poverty remade the state.</p></div>
  <div class="ov-card"><div class="i">🪖</div><h4>The Vietnam tragedy</h4><p>Escalation and the credibility gap destroyed his presidency.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Rise</b><small> 1908–1948</small><p>Hill Country poverty to “Landslide Lyndon.”</p></div>
  <div><b>2 · Master of the Senate</b><small> 1949–1963</small><p>The Treatment; the frustrated vice presidency.</p></div>
  <div><b>3 · The Great Society</b><small> 1963–1965</small><p>Dallas, civil rights, and the war on poverty.</p></div>
  <div><b>4 · Triumph and the Turn</b><small> 1964–1965</small><p>The landslide, voting rights — and Tonkin.</p></div>
  <div><b>5 · Vietnam &amp; the Fall</b><small> 1965–1973</small><p>Guns and butter, Tet, and “I shall not seek.”</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Lady Bird Johnson', 'role': 'wife & partner', 'color': '#166534',
     'bio': 'Claudia “Lady Bird” Johnson, whom he married in 1934; her steadiness and business sense underpinned his career, and she championed conservation as First Lady.',
     'rel': 'His wife and lifelong political partner.'},
    {'name': 'John F. Kennedy', 'role': 'predecessor', 'color': '#b91c1c',
     'bio': 'The president who beat Johnson for the 1960 nomination, made him Vice President, and whose 1963 assassination raised him to the presidency.',
     'rel': 'The rival-then-running-mate whose death made him president.'},
    {'name': 'Richard Russell', 'role': 'mentor', 'color': '#a16207',
     'bio': 'The powerful Georgia senator who mentored Johnson’s Senate rise — and whom Johnson then had to defeat to pass civil rights.',
     'rel': 'His Senate patron, later opposed on civil rights.'},
    {'name': 'Robert McNamara', 'role': 'war architect', 'color': '#475569',
     'bio': 'The Defense Secretary, inherited from Kennedy, who managed the escalation in Vietnam before his own faith in the war collapsed.',
     'rel': 'His chief architect of the Vietnam escalation.'},
    {'name': 'Martin Luther King Jr.', 'role': 'movement leader', 'color': '#1e3a8a',
     'bio': 'The civil-rights leader whose Selma campaign spurred the Voting Rights Act; ally on rights, later critic of the Vietnam War.',
     'rel': 'The movement leader who pressed and partnered with him on rights.'},
]

KEY_EVENTS = [
    ('1908', 'Born in the Hill Country', 'Poverty near Stonewall, Texas.'),
    ('1937', 'Elected to Congress', 'A young New Deal protégé of FDR.'),
    ('1948', '“Landslide Lyndon”', 'Wins the Senate by a disputed 87 votes.'),
    ('1955', 'Senate Majority Leader', 'The youngest, and among the greatest.'),
    ('1963', 'Sworn in after Dallas', 'JFK assassinated; “Let us continue.”'),
    ('1964', 'Civil Rights Act', 'Outlaws segregation; the 1964 landslide.'),
    ('1965', 'Voting Rights Act & Medicare', 'The Great Society at its height.'),
    ('1964–65', 'Gulf of Tonkin & escalation', 'The blank check for the Vietnam War.'),
    ('1968', '“I shall not seek…”', 'Broken by Tet, he renounces re-election.'),
    ('1973', 'Death of Johnson', 'Dies at his Texas ranch, 22 January.'),
]

MASTER = [
    {'year': '1908', 'age': 'born', 'phase': 'The Rise', 'title': 'Born in the Hill Country', 'desc': 'Poverty near Stonewall, Texas.'},
    {'year': '1948', 'age': 'age 40', 'phase': 'The Rise', 'title': '“Landslide Lyndon”', 'desc': 'Wins the Senate by 87 votes.'},
    {'year': '1955', 'age': 'age 46', 'phase': 'Master of the Senate', 'title': 'Majority Leader', 'desc': 'Masters the chamber.'},
    {'year': '1963', 'age': 'age 55', 'phase': 'The Great Society', 'title': 'Sworn in after Dallas', 'desc': 'JFK assassinated.'},
    {'year': '1964', 'age': 'age 56', 'phase': 'The Great Society', 'title': 'Civil Rights Act & landslide', 'desc': 'Reform and a mandate.'},
    {'year': '1965', 'age': 'age 56', 'phase': 'Triumph and the Turn', 'title': 'Voting Rights & Medicare', 'desc': 'The Great Society peaks.'},
    {'year': '1968', 'age': 'age 59', 'phase': 'Vietnam & the Fall', 'title': '“I shall not seek”', 'desc': 'Broken by Vietnam.'},
    {'year': '1973', 'age': 'age 64', 'phase': 'Vietnam & the Fall', 'title': 'Death at the ranch', 'desc': 'Dies 22 January 1973.'},
]

SOURCES = [
    ('Britannica — Lyndon B. Johnson', 'https://www.britannica.com/biography/Lyndon-B-Johnson'),
    ('The White House — Lyndon B. Johnson', 'https://www.whitehouse.gov/about-the-white-house/presidents/lyndon-b-johnson/'),
    ('LBJ Presidential Library', 'https://www.lbjlibrary.org/'),
    ('Miller Center — LBJ', 'https://millercenter.org/president/lbjohnson'),
    ('Wikipedia — Lyndon B. Johnson', 'https://en.wikipedia.org/wiki/Lyndon_B._Johnson'),
]

def build_meta():
    return {
        'pid': 'gm-lbj.html', 'kind': 'man', 'emoji': '🗳️', 'accent': AC,
        'name': 'Lyndon B. Johnson', 'years': '1908–1973', 'group': 'Modern Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Texas master of legislative power who drove through the Civil Rights Act, the Voting Rights Act and the Great Society — and was broken by the tragedy of Vietnam.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Rise', 'type': 'timeline',
             'intro': 'A poor Hill Country boy who saw poverty up close climbs through Congress as a New Deal protégé — and wins a Senate seat by a notorious, disputed 87 votes.', 'events': PHASE_RISE},
            {'id': 'senate', 'label': '2 · Master of the Senate', 'type': 'timeline',
             'intro': 'He becomes the youngest and most masterful leader the Senate has known, perfecting the “Johnson Treatment,” then loses to Kennedy and chafes as a frustrated Vice President.', 'events': PHASE_SENATE},
            {'id': 'great', 'label': '3 · The Great Society', 'type': 'timeline',
             'intro': 'Sworn in after Dallas, he turns grief into momentum — breaking the filibuster for the Civil Rights Act and driving through Medicare, Medicaid and the War on Poverty.', 'events': PHASE_GREAT},
            {'id': 'turn', 'label': '4 · Triumph and the Turn', 'type': 'timeline',
             'intro': 'A historic 1964 landslide and the Voting Rights Act mark the summit of his power — even as the Gulf of Tonkin quietly opens the door to the war that will destroy him.', 'events': PHASE_TURN},
            {'id': 'fall', 'label': '5 · Vietnam & the Fall', 'type': 'timeline',
             'intro': 'Trying to have both guns and butter, he escalates a war he cannot win, opens a “credibility gap,” is broken by the Tet Offensive, and walks away from power.', 'events': PHASE_FALL,
             'sources': SOURCES, 'srcnote': 'Standard biographies (notably Robert Caro’s multi-volume The Years of Lyndon Johnson) and encyclopaedic and presidential-archive sources; quotations are drawn from the public record.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
