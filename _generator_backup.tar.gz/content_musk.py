# -*- coding: utf-8 -*-
"""Birth-to-present guide content for Elon Musk (living figure; researched to 2026)."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#0891b2'  # electric cyan

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_2008():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">2008 · the year he almost lost everything — twice over</text>'
    boxes=[(40,'#7f1d1d','Both firms near death','SpaceX has failed 3 launches; Tesla is out of cash'),
           (270,'#b45309','He goes all-in','pours his last PayPal millions into both at once'),
           (500,'#166534','Saved at the buzzer','Falcon 1’s 4th launch works; a NASA contract lands')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Days from bankruptcy at both companies, he bet his entire fortune — and the fourth rocket flew.</text>'
    return _wrap(W, H, '2008 — the near-death of the whole dream', _tk(b, W, H, 'He risked his entire fortune to keep both companies alive — and survived by a matter of days.'), '', AC)

def svg_reuse():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">why SpaceX broke the cost of spaceflight</text>'
    b += '<rect x="40" y="60" width="300" height="82" rx="12" fill="#fef2f2" stroke="#b45309" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#b45309">The old way</text>'
    s1,_=_tspans(54,100,'rockets are thrown away after one flight — like scrapping a jet after one trip',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="82" rx="12" fill="#ecfeff" stroke="#0891b2" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#0891b2">Land and reuse the booster</text>'
    s2,_=_tspans(394,100,'the first stage flies back and lands upright — then flies again and again',10,'#0891b2',600,12,44); b+=s2
    b += '<line x1="340" y1="101" x2="378" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Reusing the most expensive part slashed launch costs and let SpaceX dominate the global launch market.</text>'
    return _wrap(W, H, 'Reusable rockets — the cost revolution', _tk(b, W, H, 'He attacked spaceflight’s biggest cost — throwing the rocket away — and made the booster land and fly again.'), '', AC)

def svg_platform():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">2022–2025 · buying a megaphone, then an AI</text>'
    rows=[('#0891b2','Buys Twitter for $44B (2022)','renames it X; fires ~half the staff; loosens moderation'),
          ('#7c3aed','Founds xAI and Grok (2023)','builds a rival to OpenAI, trained partly on X'),
          ('#b45309','xAI absorbs X (2025)','the platform and the AI lab merge into one company')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="42" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+21}" r="9" fill="{c}"/><text x="62" y="{y+25}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+18}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+34,s,9.3,'#5b6472',500,11,78); b+=ss
        y+=50
    return _wrap(W, H, 'From social media to AI empire', _tk(b, W, H, 'He bought the world’s town square, then folded it into his bet on artificial intelligence.'), '', AC)

def svg_doge():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">2024–2025 · the plunge into politics — and the fallout</text>'
    boxes=[(40,'#0891b2','Backs Trump, leads DOGE','a "Department of Government Efficiency" to cut spending'),
           (270,'#b45309','Slashes and dismantles','shrinks agencies; guts USAID; huge controversy'),
           (500,'#7f1d1d','Breaks with Trump (2025)','quits over a tax bill; the alliance turns to feud')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">The world’s richest man became one of its most polarising political actors — then fell out with the president he backed.</text>'
    return _wrap(W, H, 'The political turn', _tk(b, W, H, 'He staked his reputation on hard-edged politics — gaining enormous power and enormous controversy in a single year.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE OUTSIDER
PHASE_RISE = [
    E('boy', '1971–1992', 'A bullied boy who taught himself to code', ['RISE'],
      'Born in Pretoria, South Africa, a bookish, relentlessly bullied child, he escapes into science fiction and computers — teaching himself to program and selling his first video game at twelve — before leaving for Canada and then America as soon as he can.',
      svg_stack('An outsider builds his own escape', [
          {'n': 1, 'label': 'Bullied, bookish, in Pretoria', 'sub': 'reads voraciously; retreats into ideas', 'color': '#0891b2'},
          {'n': 2, 'label': 'Sells a game at 12', 'sub': 'teaches himself to code; makes his first money', 'color': '#b45309'},
          {'n': 3, 'label': 'Leaves for Canada, then the US', 'sub': 'emigrates at ~17; studies physics and economics', 'color': '#166534'},
      ], takeaway='He turned an unhappy, isolated childhood into a self-driven education and a ticket out.', accent=AC),
      bg='Musk was born in <b>1971</b> in <b>Pretoria, South Africa</b>, into a comfortable but troubled family, and had a difficult, isolated childhood.',
      people='His family in South Africa; the science-fiction authors and computing that shaped his imagination.',
      what='A relentlessly bullied but brilliant child, Musk <b>taught himself programming</b> and sold a game (<i>Blastar</i>) at about twelve. At seventeen he emigrated to <b>Canada</b>, then the United States, studying at <b>Queen’s University</b> and the <b>University of Pennsylvania</b> (physics and economics).',
      crux='He was an <b>outsider driven by big ideas</b> — determined from youth to work on things he considered important to humanity’s future.',
      conseq='Arriving in America in the 1990s, he headed for Silicon Valley just as the internet boom was beginning.',
      matters='Outsiders often see what insiders miss. Musk’s restless, self-taught, sci-fi-fuelled mind set the pattern for everything he built.'),

    E('zip2', '1995–1999', 'Zip2 — the first win', ['RISE', 'TRIUMPH'],
      'He drops out of a Stanford PhD after two days to ride the internet wave, builds an early online city-guide business with his brother while sleeping in the office, and sells it for over $300 million — his first fortune before thirty.',
      svg_row('From office floor to millionaire', [
          {'n': 1, 'label': 'Drops out for the internet', 'sub': 'quits a Stanford PhD after two days', 'color': '#0891b2'},
          {'n': 2, 'label': 'Builds Zip2', 'sub': 'online maps/directories; lives in the office', 'color': '#b45309'},
          {'n': 3, 'label': 'Sold for ~$307M (1999)', 'sub': 'his first fortune; ~$22M to him', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='His first company proved the pattern: spot a wave early, work obsessively, cash out big.', accent=AC),
      bg='In the mid-1990s the commercial internet was exploding. Musk abandoned graduate school to build a company.',
      people='His brother <b>Kimbal Musk</b>, co-founder of Zip2; the early internet investors of Silicon Valley.',
      what='Musk co-founded <b>Zip2</b>, providing online city guides and maps to newspapers, working obsessively (reportedly sleeping in the office). In <b>1999</b> <b>Compaq bought Zip2 for about $307 million</b>, netting Musk roughly $22 million.',
      crux='He showed early his willingness to <b>bet his whole life on a trend</b> and to <b>outwork everyone</b> — and cashed out with the capital to think bigger.',
      conseq='With his Zip2 windfall, Musk immediately reinvested in a far more ambitious venture: online banking.',
      matters='First wins fund big dreams. Zip2 gave Musk both capital and confidence to attack much larger problems.'),
]

# ==================================================================  PHASE 2 — THE FIRST FORTUNE
PHASE_PAYPAL = [
    E('paypal', '1999–2002', 'PayPal and the nine-figure exit', ['RISE', 'TRIUMPH'],
      'He pours his Zip2 money into an online bank, X.com, which merges into what becomes PayPal. Forced out as CEO but still its largest shareholder, he walks away with around $180 million when eBay buys it — the war-chest for everything to come.',
      svg_row('The stake that funded the future', [
          {'n': 1, 'label': 'Founds X.com', 'sub': 'an online bank; merges into PayPal', 'color': '#0891b2'},
          {'n': 2, 'label': 'Ousted as CEO', 'sub': 'but remains the largest shareholder', 'color': '#b45309'},
          {'n': 3, 'label': 'eBay buys PayPal (2002)', 'sub': '$1.5B deal; ~$180M to Musk', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='Even pushed out of his own company, he emerged with the fortune that made SpaceX and Tesla possible.', accent=AC),
      bg='Musk reinvested his Zip2 money into <b>X.com (1999)</b>, an ambitious online financial-services company that merged with a rival to become <b>PayPal</b>.',
      people='His PayPal co-founders and the "PayPal Mafia" (later founders of many major tech firms).',
      what='Musk founded <b>X.com</b>, which became <b>PayPal</b>. He was <b>removed as CEO</b> amid disputes but remained its largest shareholder; when <b>eBay bought PayPal for $1.5 billion in 2002</b>, Musk received around <b>$180 million</b>.',
      crux='He again demonstrated the pattern — <b>bold bet, big exit</b> — and gained the capital to attack the two hardest industries he could imagine: rockets and cars.',
      conseq='Instead of retiring rich, Musk poured his PayPal fortune into founding <b>SpaceX</b> and funding <b>Tesla</b>.',
      matters='What you do with a fortune matters more than making it. Musk risked all of his on ventures almost everyone thought would fail.'),
]

# ==================================================================  PHASE 3 — THE IMPOSSIBLE BETS
PHASE_BETS = [
    E('founding', '2002–2006', 'Betting the fortune on rockets and cars', ['RISE', 'POLITICS'],
      'He does the opposite of what a newly rich man should: he founds SpaceX to make spaceflight cheap enough to reach Mars, and bankrolls the tiny electric-car startup Tesla — pouring his entire PayPal fortune into two industries famous for destroying investors.',
      svg_stack('Two "impossible" companies at once', [
          {'n': 1, 'label': 'Founds SpaceX (2002)', 'sub': 'cheap, reusable rockets; the goal is Mars', 'color': '#0891b2'},
          {'n': 2, 'label': 'Funds Tesla (2004)', 'sub': 'leads investment in an electric-car startup', 'color': '#166534'},
          {'n': 3, 'label': 'Stakes his whole fortune', 'sub': 'on the two hardest industries imaginable', 'color': '#b45309'},
      ], takeaway='He chose the two industries most likely to bankrupt him — because he thought they mattered most.', accent=AC),
      bg='After PayPal, Musk set out to work on what he saw as humanity’s biggest challenges: <b>making life multi-planetary</b> and <b>ending dependence on fossil fuels</b>.',
      people='The early SpaceX engineers; Tesla co-founders <b>Martin Eberhard</b> and <b>Marc Tarpenning</b>, and later partner <b>JB Straubel</b>.',
      what='Musk founded <b>SpaceX in 2002</b> to build low-cost, reusable rockets, and became the lead investor and chairman (later CEO) of <b>Tesla</b> from <b>2004</b> — putting essentially his entire fortune into both.',
      crux='He bet everything on <b>two capital-hungry industries famous for ruining people</b>, driven by mission rather than the odds — an extraordinary appetite for risk.',
      conseq='Both companies nearly failed repeatedly; by 2008 they brought Musk to the edge of ruin.',
      matters='Conviction plus risk tolerance defines Musk. He backed his beliefs with every dollar he had — and nearly lost it all.'),

    E('2008', '2008', 'The year everything nearly died', ['DEFEAT', 'TURNING POINT', 'TRIUMPH'],
      'By 2008 both companies are collapsing: SpaceX has failed three straight launches and Tesla is out of money in the financial crisis. Broke and divorcing, Musk pours his last millions into both — and is saved within days by a successful fourth launch and a NASA contract.',
      svg_2008(),
      bg='By <b>2008</b>, in the depths of the global financial crisis, both SpaceX and Tesla were nearly bankrupt; Musk’s personal fortune was almost gone.',
      people='The SpaceX launch team; NASA, which awarded a crucial contract; Tesla’s desperate investors.',
      what='SpaceX’s first three <b>Falcon 1</b> launches failed; Tesla was out of cash. Musk split his last money between them. Then the <b>fourth Falcon 1 launch succeeded (Sept 2008)</b>, NASA awarded SpaceX a <b>~$1.6 billion resupply contract</b>, and Tesla secured last-minute funding — all within weeks.',
      crux='He <b>refused to let either company die</b>, betting his last resources on both at once — and survived by the narrowest possible margin.',
      conseq='Both companies pulled back from the brink and began the ascents that would make Musk the richest person in the world.',
      matters='The line between failure and triumph can be days wide. Musk’s 2008 is a legendary case of surviving on sheer refusal to quit.'),

    E('reuse', '2010–2020', 'Reusable rockets and a real electric car', ['TRIUMPH', 'REFORM'],
      'Through the 2010s he does what the establishment said was impossible: SpaceX lands and reuses rockets, collapsing the cost of reaching orbit, while Tesla’s Model S and then the mass-market Model 3 prove electric cars can be desirable and dominant.',
      svg_reuse(),
      bg='Conventional wisdom held that rockets must be discarded after each flight and that electric cars could never be mainstream. Musk set out to disprove both.',
      people='SpaceX’s engineering teams; Tesla’s designers and factory workers; the legacy aerospace and auto giants he disrupted.',
      what='SpaceX developed the <b>Falcon 9</b>, first <b>landing and reusing</b> its booster (from 2015), slashing launch costs and capturing much of the global market, while building <b>Dragon</b> (carrying astronauts from 2020) and <b>Starlink</b>. Tesla shipped the <b>Model S</b> and the mass-market <b>Model 3</b>, becoming the world’s most valuable automaker.',
      crux='His edge was <b>attacking the biggest cost or assumption head-on</b> — reusing rockets, mass-producing desirable EVs — where incumbents wouldn’t.',
      conseq='SpaceX and Tesla became dominant and hugely valuable; by around 2021 Musk was the <b>richest person in the world</b>.',
      matters='"Impossible" often just means "not yet done." Musk’s 2010s reshaped both spaceflight and the auto industry.'),

    E('method', '2002–present', 'The method — first principles and “production hell”', ['REFORM', 'POLITICS'],
      'His signature is a way of thinking and working: reasoning from “first principles” rather than analogy, attacking the biggest cost of everything, and driving his companies through brutal, round-the-clock sprints — famously sleeping on the factory floor during the “production hell” of scaling the Model 3 — a management style that produces both extraordinary results and burnout and turnover.',
      svg_row('How he actually builds', [
          {'n': 1, 'label': 'First-principles reasoning', 'sub': 'break problems down to physics, not precedent', 'color': '#0891b2'},
          {'n': 2, 'label': 'Attack the biggest cost', 'sub': 'relentlessly re-engineer what everyone accepts', 'color': '#166534'},
          {'n': 3, 'label': '“Production hell”', 'sub': 'brutal sprints; sleeping on the factory floor', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='Reason from physics, kill the biggest cost, and sprint brutally — his method drives both breakthroughs and burnout.', accent=AC),
      bg='Musk’s companies run on a distinctive engineering and management philosophy that he applies across rockets, cars and AI.',
      people='His engineers and workers, driven hard through crunch periods; the managers who thrived or burned out under his style.',
      what='Musk reasons from <b>“first principles”</b> (from physics rather than analogy), obsessively <b>attacks the largest cost</b> of any problem, and drives his teams through <b>brutal sprints</b> — most famously the <b>“production hell”</b> of the Model 3, when he slept on the factory floor.',
      crux='His method fuses <b>radical rethinking with punishing intensity</b> — a formula that yields breakthroughs at the cost of high burnout and turnover.',
      conseq='It produced achievements others called impossible, but also a reputation as an extraordinarily demanding, sometimes harsh boss.',
      matters='Musk’s way of thinking and working is itself influential — first-principles reasoning and cost-attack, delivered through relentless, controversial intensity.'),
]

# ==================================================================  PHASE 4 — THE EMPIRE
PHASE_EMPIRE = [
    E('mars', '2001–present', 'The real mission — making life multiplanetary', ['REFORM', 'POLITICS'],
      'Beneath the rockets and cars lies the goal he says drives everything: making humanity a multiplanetary species by settling Mars, as insurance against extinction. It is the founding purpose of SpaceX, the reason for Starship, and the frame he uses to justify his relentless risk-taking — a science-fiction dream pursued with industrial seriousness.',
      svg_row('The dream beneath the empire', [
          {'n': 1, 'label': 'Humanity as multiplanetary', 'sub': 'a backup for life beyond Earth', 'color': '#0891b2'},
          {'n': 2, 'label': 'Settle Mars', 'sub': 'the explicit long-term goal of SpaceX', 'color': '#b45309'},
          {'n': 3, 'label': 'Starship as the vehicle', 'sub': 'the giant rocket built to carry it out', 'color': '#166534'},
      ], edge_labels=['so', 'so'], takeaway='His stated north star is Mars — the mission he says every rocket and dollar ultimately serves.', accent=AC),
      bg='Musk founded SpaceX with the explicit long-term goal of <b>making humanity a multiplanetary species</b>, beginning with a <b>Mars settlement</b>.',
      people='The SpaceX engineers building toward Mars; the scientific and public debate over the feasibility and ethics of the vision.',
      what='Musk frames <b>settling Mars</b> — as insurance against human extinction — as the <b>founding purpose of SpaceX</b> and the reason for <b>Starship</b>, pursuing a science-fiction goal with unusual industrial and financial seriousness (though timelines have repeatedly slipped).',
      crux='He treats an almost utopian <b>long-term mission as the organising purpose</b> of a real, cash-generating industrial empire — mission and business intertwined.',
      conseq='Whether or not Mars is reached, the goal has driven genuine advances in rocketry and reusability.',
      matters='Grand missions can drive real engineering. Musk’s Mars vision, however distant, is the stated engine behind SpaceX’s concrete achievements.'),

    E('energy', '2006–present', 'The other half of the vision — solar, batteries, and energy', ['REFORM', 'TRIUMPH'],
      'Tesla was never only about cars: alongside them he pushes solar power and, above all, batteries — home Powerwalls, grid-scale storage, and the giant "Gigafactories" built to make batteries at world-changing scale — pursuing a parallel mission to shift the world to sustainable energy.',
      svg_row('Beyond cars — an energy company', [
          {'n': 1, 'label': 'Solar and Powerwall', 'sub': 'home solar and battery storage (SolarCity, Tesla Energy)', 'color': '#0891b2'},
          {'n': 2, 'label': 'Grid-scale batteries', 'sub': 'giant storage projects to stabilise power grids', 'color': '#166534'},
          {'n': 3, 'label': 'The Gigafactories', 'sub': 'battery manufacturing at unprecedented scale', 'color': '#b45309'},
      ], edge_labels=['plus', 'plus'], takeaway='He built Tesla into an energy company as much as a carmaker — betting the future on batteries at scale.', accent=AC),
      bg='Musk framed Tesla’s mission as <b>accelerating the world’s transition to sustainable energy</b>, not just selling electric cars.',
      people='The <b>SolarCity</b> team (later folded into Tesla); the engineers of Tesla Energy and the Gigafactories.',
      what='Tesla expanded into <b>solar power</b> (via SolarCity), <b>home and grid batteries</b> (Powerwall, Megapack), and built giant <b>“Gigafactories”</b> to manufacture batteries at massive scale — pursuing sustainable energy alongside electric vehicles.',
      crux='He recognised that <b>batteries and energy storage</b>, not just cars, were key to a sustainable-energy future — and industrialised their production.',
      conseq='Tesla became a major force in energy storage and solar, broadening Musk’s impact beyond automobiles.',
      matters='The deeper Tesla mission is energy, not cars. Musk’s battery bet aimed at changing how the world powers itself.'),

    E('autonomy', '2014–present', 'The self-driving bet — Autopilot, robotaxis, and Optimus', ['REFORM', 'POLITICS'],
      'He stakes much of Tesla’s future on artificial intelligence: Autopilot and "Full Self-Driving" software promising autonomous cars, a coming fleet of robotaxis, and even a humanoid robot, Optimus — a vision of an AI-and-robotics company that has drawn both huge valuations and sharp criticism over repeatedly missed timelines and safety concerns.',
      svg_row('Betting Tesla’s future on AI', [
          {'n': 1, 'label': 'Autopilot & “Full Self-Driving”', 'sub': 'driver-assist software promising autonomy', 'color': '#0891b2'},
          {'n': 2, 'label': 'Robotaxis', 'sub': 'a promised fleet of self-driving cars', 'color': '#b45309'},
          {'n': 3, 'label': 'The Optimus robot', 'sub': 'a humanoid robot for labour', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He recast Tesla as an AI-and-robotics company — a huge, contested bet dogged by missed timelines.', accent=AC),
      bg='Musk increasingly framed Tesla’s value around <b>artificial intelligence and robotics</b>, not just building cars.',
      people='Tesla’s AI and Autopilot teams; regulators and critics scrutinising safety and the repeated missed deadlines.',
      what='Tesla developed <b>Autopilot</b> and <b>“Full Self-Driving”</b> software, promised a <b>robotaxi</b> fleet, and unveiled the <b>Optimus</b> humanoid robot — recasting itself as an AI-and-robotics company, amid <b>repeatedly missed timelines</b> and safety criticism.',
      crux='He bet Tesla’s future on <b>autonomy and robotics</b>, driving enormous valuations — while critics point to over-promising and unmet deadlines.',
      conseq='The AI narrative reshaped Tesla’s valuation and strategy, even as full autonomy remained unrealised.',
      matters='Musk’s autonomy bet shows both his visionary framing and his pattern of over-promising — the two sides of his salesmanship.'),

    E('starlink', '2015–present', 'Starlink — connectivity and geopolitical power', ['TRIUMPH', 'POLITICS'],
      'His satellite-internet network becomes not just a business but a geopolitical actor: with thousands of satellites providing internet across the globe, Starlink proves decisive in the war in Ukraine — and Musk’s personal control over whether and where it operates gives one private individual a startling degree of power over a real conflict.',
      svg_row('When a company becomes a geopolitical force', [
          {'n': 1, 'label': 'Global satellite internet', 'sub': 'thousands of satellites; connectivity anywhere', 'color': '#0891b2'},
          {'n': 2, 'label': 'Decisive in Ukraine', 'sub': 'Starlink becomes vital battlefield infrastructure', 'color': '#b45309'},
          {'n': 3, 'label': 'One man’s leverage', 'sub': 'Musk’s personal control raises real power questions', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'so'], takeaway='Starlink turned a private company — and Musk personally — into a genuine actor in war and geopolitics.', accent=AC),
      bg='SpaceX’s <b>Starlink</b> built a vast satellite-internet constellation, with reach and strategic importance far beyond a normal business.',
      people='The Ukrainian forces relying on Starlink; governments and militaries dependent on or wary of it; Musk himself.',
      what='<b>Starlink</b> grew to thousands of satellites providing global internet, and became <b>decisive infrastructure in the war in Ukraine</b> — while Musk’s <b>personal control</b> over its operation gave one private individual startling <b>geopolitical leverage</b>.',
      crux='It raised a profound new question: what does it mean when a <b>single private individual</b> controls infrastructure that can shape the outcome of a war?',
      conseq='Starlink made SpaceX hugely valuable and Musk a geopolitical actor, prompting debate over private power in global affairs.',
      matters='Starlink is a landmark in the rise of private power. Musk’s control of critical global infrastructure is one of the defining issues of the age.'),

    E('ventures', '2015–present', 'The other ventures — Neuralink, Boring, and OpenAI’s origin', ['REFORM', 'POLITICS'],
      'His restless empire spawns still more bets: Neuralink, implanting chips in human brains (with its first human trial in 2024); the Boring Company, digging tunnels to beat traffic; and — fatefully — OpenAI, the AI lab he co-founded in 2015 and later left, only to build a rival and sue it, seeding the AI rivalry that now defines part of his life.',
      svg_stack('A constellation of side-bets', [
          {'n': 1, 'label': 'Neuralink', 'sub': 'brain-computer implants; first human trial in 2024', 'color': '#0891b2'},
          {'n': 2, 'label': 'The Boring Company', 'sub': 'tunnels to beat urban traffic', 'color': '#b45309'},
          {'n': 3, 'label': 'Co-founds OpenAI (2015)', 'sub': 'later leaves, then builds and sues a rival', 'color': '#7c3aed'},
      ], takeaway='Even his "side" ventures are audacious — brain chips, tunnels, and the AI lab whose founding he later came to rival.', accent=AC),
      bg='Beyond Tesla and SpaceX, Musk launched a cluster of ambitious ventures spanning neuroscience, infrastructure and AI.',
      people='The Neuralink patients and researchers; the Boring Company engineers; the OpenAI co-founders he later split from.',
      what='Musk founded <b>Neuralink</b> (brain-computer implants, with its first <b>human trial in 2024</b>) and the <b>Boring Company</b> (traffic tunnels), and <b>co-founded OpenAI in 2015</b> over AI-safety concerns — later leaving, then building <b>xAI</b> to rival it and suing it.',
      crux='He pursues <b>multiple frontier technologies at once</b>, and his tangled history with OpenAI shows how his ventures and rivalries intertwine.',
      conseq='These ventures extended his reach into neuroscience, infrastructure and the center of the AI race.',
      matters='Musk’s sheer breadth is singular — and his OpenAI history seeded the AI rivalry now central to his public life.'),
    E('richest', '2020–2022', 'The richest person in the world', ['TRIUMPH'],
      'As Tesla’s stock soars and SpaceX’s value balloons, Musk becomes the wealthiest person on earth — presiding over a sprawling empire of rockets, cars, satellites, tunnels, and brain-chips, and cultivating a vast, devoted online following.',
      svg_stack('An empire across many frontiers', [
          {'n': 1, 'label': 'Tesla and SpaceX soar', 'sub': 'stock and valuation make him #1 in wealth', 'color': '#0891b2'},
          {'n': 2, 'label': 'Starlink and Starship', 'sub': 'a satellite internet; a giant Mars rocket in testing', 'color': '#166534'},
          {'n': 3, 'label': 'Neuralink, Boring Co.', 'sub': 'brain-chips and tunnels — many bets at once', 'color': '#7c3aed'},
      ], takeaway='He built not one company but a constellation of them, spanning space, energy, transport and the brain.', accent=AC),
      bg='By the early 2020s Musk’s companies were dominant in their fields and their valuations had made him extraordinarily rich.',
      people='His companies’ leaders and engineers; his enormous following on social media.',
      what='Musk became the <b>world’s richest person</b> (around 2021) as <b>Tesla</b> and <b>SpaceX</b> soared. His empire spanned rockets, EVs, <b>Starlink</b> satellites, the giant <b>Starship</b>, the <b>Neuralink</b> brain-interface, and the <b>Boring Company</b>.',
      crux='He ran an unprecedented <b>portfolio of high-risk, high-ambition companies simultaneously</b>, unified by a self-styled mission to secure humanity’s future.',
      conseq='His wealth and reach gave him enormous influence — which he increasingly turned toward media and politics.',
      matters='Few people have ever concentrated so much industrial ambition in one career. Musk’s empire is singular in modern business history.'),

    E('starship', '2023–2026', 'Starship, Starlink, and a trillion-dollar orbit', ['TRIUMPH', 'REFORM'],
      'His space ambitions scale to staggering size: thousands of Starlink satellites blanket the globe, the giant Starship rocket is developed for the Moon and Mars, and by 2026 a record SpaceX public offering helps push Musk’s paper wealth toward the trillion-dollar mark.',
      svg_row('Space at industrial scale', [
          {'n': 1, 'label': 'Starlink blankets Earth', 'sub': 'thousands of satellites; millions of subscribers', 'color': '#0891b2'},
          {'n': 2, 'label': 'Starship for the Moon/Mars', 'sub': 'the largest rocket ever, in flight testing', 'color': '#166534'},
          {'n': 3, 'label': 'Record SpaceX offering (2026)', 'sub': 'valuation in the trillions; Musk’s wealth soars', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='He turned rockets into a mass-scale business — and, on paper, one of the greatest fortunes ever recorded.', accent=AC),
      bg='By the mid-2020s SpaceX dominated global launch and satellite internet, and was developing the enormous <b>Starship</b> for deep-space missions.',
      people='SpaceX’s teams; the customers and governments relying on Starlink; the investors in SpaceX.',
      what='By <b>2026</b>, <b>Starlink</b> had grown to thousands of satellites and millions of users, <b>Starship</b> was in ambitious flight testing, and a <b>record SpaceX public offering</b> valued the company in the trillions — pushing Musk’s reported net worth toward or past the <b>trillion-dollar</b> level (figures vary widely and fluctuate with markets).',
      crux='He scaled space from a niche to a <b>mass industrial market</b>, with Starlink’s revenue funding ever-more-ambitious rockets.',
      conseq='SpaceX became one of the most valuable private companies in history; Musk’s wealth reached historically unprecedented levels.',
      matters='Musk industrialised access to space. Whatever one makes of him, his companies reshaped how humanity reaches orbit.'),
]

# ==================================================================  PHASE 5 — THE POLARIZING YEARS
PHASE_NOW = [
    E('twitter', '2022–2025', 'Buying the town square, building an AI', ['POLITICS', 'TURNING POINT'],
      'He buys Twitter for $44 billion, renames it X, and turns it into a personal megaphone — then founds the AI company xAI and its chatbot Grok, ultimately merging the social platform and the AI lab into a single company.',
      svg_platform(),
      bg='In 2022 Musk turned toward media, and then toward the AI race that was reshaping technology.',
      people='Twitter/X employees, many laid off; the xAI team; rivals like <b>OpenAI</b>, which Musk had co-founded and then split from.',
      what='Musk <b>bought Twitter for $44 billion (2022)</b>, renamed it <b>X</b>, cut much of its staff and loosened content moderation; founded <b>xAI</b> and its chatbot <b>Grok (2023)</b>; and in <b>2025 merged X into xAI</b>, uniting platform and AI lab.',
      crux='He sought to control both a <b>global communications platform</b> and a <b>frontier AI</b> — combining reach and technology, while courting intense controversy over speech, misinformation and his own conduct.',
      conseq='X became central to Musk’s growing political influence; xAI made him a major player in the AI race.',
      matters='Musk’s media and AI moves show power concentrating: one person owning the megaphone and the machine that increasingly speaks through it.'),

    E('politics', '2024–2025', 'The plunge into politics — and the feud', ['POLITICS', 'DEFEAT', 'TURNING POINT'],
      'He throws his fortune and platform behind Donald Trump, then leads a "Department of Government Efficiency" that slashes agencies and dismantles USAID — before a bitter, public break with Trump ends the alliance in feud within months.',
      svg_doge(),
      bg='In 2024–25 Musk became one of the most powerful and polarising political actors in the world, backing <b>Donald Trump</b> and taking a formal role in the new administration.',
      people='<b>Donald Trump</b>; the federal workers and agencies affected by DOGE; his supporters and fierce critics.',
      what='Musk spent heavily to back Trump, then as a special government employee led the <b>Department of Government Efficiency (DOGE)</b> in <b>2025</b>, cutting spending, shrinking the workforce and gutting <b>USAID</b>. He <b>left the role in mid-2025</b> after clashing with Trump over a tax-and-spending bill, and the two exchanged public attacks.',
      crux='He converted wealth directly into <b>political power</b> — and discovered its limits, as the alliance that gave him influence collapsed into a personal feud.',
      conseq='DOGE’s cuts drew fierce controversy and legal challenges; Musk’s political turn deeply divided public opinion about him.',
      matters='Musk’s political chapter is a live experiment in what happens when the world’s richest man wields direct state power — and how fast such alliances can break.'),

    E('assessment', '2025–present', 'The most polarising builder of the age', ['POLITICS'],
      'He remains a figure of extremes: to admirers, the visionary who revived American spaceflight, forced the world into electric cars, and dares to aim at Mars; to critics, an erratic, controversial force whose conduct and politics overshadow the achievements. Both pictures are, in part, true.',
      svg_compare('Two honest readings of Elon Musk',
          {'head': 'The case for', 'color': '#166534',
           'items': ['revived US spaceflight; reusable rockets', 'forced the auto world electric', 'relentless drive at "impossible" goals']},
          {'head': 'The case against', 'color': '#7f1d1d',
           'items': ['erratic, combative public conduct', 'controversial politics and speech', 'over-promises; treatment of workers/critics']},
          verdict='A genuinely transformative builder and a genuinely divisive figure — the guide presents both, and lets you judge.',
          takeaway='Honest history holds both truths at once: extraordinary achievement and extraordinary controversy.', accent=AC),
      bg='Musk is among the most consequential — and most divisive — figures of the early 21st century, and assessments of him vary enormously.',
      people='His admirers and his critics; the millions affected by his companies and his politics.',
      what='By the mid-2020s Musk was simultaneously credited with <b>reviving spaceflight and electrifying transport</b> and criticised for <b>erratic conduct, divisive politics, and a pattern of over-promising</b>. Reasonable observers weigh these very differently.',
      crux='He embodies a genuine tension: <b>real, historic achievement</b> alongside <b>real, serious controversy</b> — and any honest account has to hold both.',
      conseq='His ultimate legacy remains unwritten and hotly contested, depending heavily on what his companies — and his politics — do next.',
      matters='Living history is unsettled. This guide deliberately presents Musk’s achievements and controversies side by side rather than choosing a verdict for you.'),

    E('sec', '2018–present', 'The controversies — “funding secured” and erratic conduct', ['POLITICS', 'DEFEAT'],
      'His impulsiveness repeatedly lands him in trouble: a 2018 tweet claiming he had “funding secured” to take Tesla private draws an SEC fraud charge and a costly settlement; he baselessly smears a rescuer in the Thai cave episode; and a pattern of provocative, sometimes reckless public statements becomes as much a part of his story as his engineering.',
      svg_row('When impulse becomes liability', [
          {'n': 1, 'label': '“Funding secured,” 2018', 'sub': 'a tweet triggers an SEC fraud charge and settlement', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'The Thai cave smear', 'sub': 'baselessly insults a rescuer online', 'color': '#b45309'},
          {'n': 3, 'label': 'A pattern of provocation', 'sub': 'reckless, controversial public statements', 'color': '#0891b2'},
      ], edge_labels=['then', 'then'], takeaway='His impulsiveness is a recurring liability — costing money, credibility, and goodwill again and again.', accent=AC),
      bg='Musk’s unfiltered, impulsive public conduct — especially on social media — has repeatedly created legal and reputational trouble.',
      people='The <b>SEC</b>, which charged and settled with him; the Thai cave diver he defamed; the many observers alarmed by his conduct.',
      what='In 2018 Musk’s tweet that he had <b>“funding secured”</b> to take Tesla private drew an <b>SEC securities-fraud charge</b> and a costly settlement (including stepping down as Tesla chairman); he also <b>baselessly smeared a diver</b> in the Thai cave rescue, amid a broader <b>pattern of provocative, reckless statements</b>.',
      crux='His <b>impulsiveness is a genuine liability</b> — the same disregard for convention that drives his boldness also produces serious self-inflicted damage.',
      conseq='These episodes fed persistent questions about his judgment and temperament, even among admirers of his companies.',
      matters='The traits behind Musk’s triumphs also drive his blunders. His impulsive conduct is inseparable from an honest account of him.'),

    E('aisafety', '2014–present', 'The AI prophet — warning of the thing he races to build', ['POLITICS', 'REFORM'],
      'On artificial intelligence he holds a striking, paradoxical position: for years he has warned that AI is among the greatest existential threats to humanity — likening it to “summoning the demon” — even as he co-founds OpenAI, then builds his own frontier AI, xAI, and its chatbot Grok, racing to shape the very technology he says could doom us.',
      svg_compare('The paradox of Musk on AI',
          {'head': 'The warner', 'color': '#7f1d1d',
           'items': ['calls AI an existential risk', '“summoning the demon”', 'urges regulation and caution']},
          {'head': 'The builder', 'color': '#0891b2',
           'items': ['co-founded OpenAI', 'now builds xAI and Grok', 'races at the AI frontier himself']},
          verdict='He sounds the loudest alarm about AI — and is among those building it fastest.',
          takeaway='He warns AI could doom humanity while racing to build it — trusting himself more than rivals to do it safely.', accent=AC),
      bg='Musk has long been one of the most prominent voices <b>warning about the dangers of advanced AI</b>, while also being deeply involved in developing it.',
      people='Fellow AI-risk voices; the OpenAI and xAI teams; rivals like OpenAI’s leadership.',
      what='Musk has repeatedly warned that <b>AI is an existential threat</b> (“summoning the demon”) and urged regulation — yet he <b>co-founded OpenAI</b>, and later built <b>xAI</b> and <b>Grok</b>, racing to develop frontier AI himself, reasoning that he must help shape it rather than leave it to others.',
      crux='He embodies a deep <b>paradox</b>: warning that AI could doom humanity while being among those building it fastest — trusting his own hands over his rivals’.',
      conseq='His stance keeps AI risk in public debate even as he intensifies the very race he warns about.',
      matters='Musk’s AI paradox captures a central dilemma of the age: those most worried about a technology are often those racing hardest to control it.'),

    E('person', '1971–present', 'The private man — family, Asperger’s, and relentless work', ['POLITICS'],
      'Behind the public spectacle is a complex, driven, often lonely person: father of many children, publicly identified with Asperger’s, sleeping in factories and offices during crises, running a dozen companies on little rest — a man whose extraordinary output comes wound together with turbulence in his personal life and relationships.',
      svg_row('The person behind the persona', [
          {'n': 1, 'label': 'A large, complicated family', 'sub': 'father of many children; turbulent relationships', 'color': '#0891b2'},
          {'n': 2, 'label': 'Publicly identifies with Asperger’s', 'sub': 'frames his difference as part of his focus', 'color': '#166534'},
          {'n': 3, 'label': 'Relentless, sleepless work', 'sub': 'runs many companies on little rest', 'color': '#b45309'},
      ], edge_labels=['plus', 'plus'], takeaway='His superhuman output is entangled with a turbulent, driven, often isolated personal life.', accent=AC),
      bg='Musk’s personal life is as intense and unconventional as his companies, and he has spoken about his own psychology.',
      people='His many children and their mothers; his family, including his brother Kimbal; his employees and inner circle.',
      what='Musk is the <b>father of many children</b> with several partners, has <b>publicly identified with Asperger’s</b> (autism), and is known for <b>extreme, sleepless work habits</b> — sleeping at factories during crises and running multiple companies at once — amid a turbulent personal life.',
      crux='His <b>extraordinary drive and unusual mind</b> are inseparable from both his achievements and the turbulence around him.',
      conseq='The same intensity that builds his empire strains his personal relationships and well-being.',
      matters='The person and the phenomenon are one. Musk’s psychology and relentless work are central to understanding both his triumphs and his controversies.'),

    E('giving', '2010s–present', 'Wealth without a Carnegie — the philanthropy question', ['POLITICS'],
      'Unlike the Gilded-Age titans he sometimes evokes, the richest man in history has not (so far) become a great systematic philanthropist: his giving, while substantial in dollar terms, is widely seen as modest and unstrategic relative to his fortune — he argues that reinvesting in Mars, energy and AI is itself the truest way to help humanity’s future.',
      svg_compare('Two views of Musk and giving',
          {'head': 'The critique', 'color': '#7f1d1d',
           'items': ['giving is small relative to his wealth', 'no Carnegie-style systematic philanthropy', 'foundation seen as underused']},
          {'head': 'His answer', 'color': '#0891b2',
           'items': ['reinvests in Mars, energy and AI', 'argues these best serve humanity’s future', 'sees his companies as the philanthropy']},
          verdict='He reframes building his companies as the highest form of helping humanity — a claim admirers accept and critics reject.',
          takeaway='The richest man in history argues his companies are his philanthropy — a contested reframing of what giving means.', accent=AC),
      bg='Compared with predecessors like Carnegie, Musk has drawn criticism for <b>relatively limited, unstrategic philanthropy</b> given his unprecedented wealth.',
      people='Philanthropy analysts and critics; the causes his foundation has (and has not) funded.',
      what='Though his donations are large in absolute terms, Musk is widely criticised for <b>giving modestly and unsystematically</b> relative to his fortune, and for an underused foundation. He counters that <b>reinvesting in SpaceX, Tesla and AI</b> is itself the best way to serve humanity’s long-term future.',
      crux='He <b>reframes company-building as philanthropy</b> — a claim that admirers find compelling and critics find self-serving.',
      conseq='The debate over his giving is part of the larger argument about whether his concentration of wealth and power serves the public good.',
      matters='Musk challenges the Carnegie model itself, arguing that building the future directly, not giving money away, is the higher good — a genuinely contested idea.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Elon Musk turned two fortunes from the internet into an unprecedented industrial empire — reusable rockets, mass-market electric cars, global satellite internet — becoming the richest person in history while also becoming one of its most polarising public figures. He is a study in <b>extreme risk tolerance, mission-driven obsession, attacking "impossible" problems at their root, and the collision of vast wealth with media and politics.</b></p>
<div class="ov-quote">“When something is important enough, you do it even if the odds are not in your favor.”<span>— Elon Musk</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A bullied South African boy teaches himself to code → sells Zip2 and then PayPal for his first fortunes → bets everything on SpaceX and Tesla → nearly loses both in 2008 → pioneers reusable rockets and mainstream electric cars → becomes the richest person on earth → buys Twitter and builds xAI → plunges into politics with Trump and DOGE, then feuds with him → and by 2026 sits atop a trillion-dollar empire as the age’s most divisive builder.</p>
<div class="ov-lbl">Why he matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🚀</div><h4>He revived spaceflight</h4><p>Reusable rockets collapsed launch costs and made SpaceX dominant.</p></div>
  <div class="ov-card"><div class="i">⚡</div><h4>He electrified cars</h4><p>Tesla forced the entire auto industry toward electric vehicles.</p></div>
  <div class="ov-card"><div class="i">🎲</div><h4>Extreme risk</h4><p>He repeatedly bet his entire fortune on "impossible" ventures.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>Deeply polarising</h4><p>His conduct and politics divide opinion as sharply as his achievements impress.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Outsider</b><small> 1971–99</small><p>South Africa, self-taught code, and Zip2.</p></div>
  <div><b>2 · The First Fortune</b><small> 1999–2002</small><p>PayPal and the war-chest.</p></div>
  <div><b>3 · The Impossible Bets</b><small> 2002–20</small><p>SpaceX, Tesla, and the 2008 near-death.</p></div>
  <div><b>4 · The Empire</b><small> 2020–26</small><p>Richest man; Starship and Starlink at scale.</p></div>
  <div><b>5 · The Polarizing Years</b><small> 2022–now</small><p>X, xAI, and the plunge into politics.</p></div>
</div>
<div class="ov-lbl">A note on a living figure</div>
<p class="ov-lead" style="font-size:15px">Musk is very much alive and active, and the facts here (especially net worth and his political and AI ventures) change fast; this guide was researched to <b>2026</b> and deliberately presents his achievements and controversies side by side. Treat the most recent items as a snapshot, not the last word.</p>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Kimbal Musk', 'role': 'brother / co-founder', 'color': '#0891b2',
     'bio': 'Elon’s younger brother and co-founder of Zip2, later a restaurateur and food-focused entrepreneur.',
     'rel': 'The brother beside him at the very start.'},
    {'name': 'JB Straubel', 'role': 'Tesla co-founder / CTO', 'color': '#166534',
     'bio': 'A key technical mind behind Tesla’s batteries and powertrain, long its chief technology officer and central to its engineering success.',
     'rel': 'The engineer who helped make Tesla technically real.'},
    {'name': 'Gwynne Shotwell', 'role': 'SpaceX president', 'color': '#7c3aed',
     'bio': 'SpaceX’s long-time president and COO, widely credited with running the company’s operations and commercial success alongside Musk’s vision.',
     'rel': 'The operator who turned SpaceX’s vision into a working business.'},
    {'name': 'Donald Trump', 'role': 'political ally → rival', 'color': '#7f1d1d',
     'bio': 'The U.S. president Musk backed heavily in 2024 and served under via DOGE in 2025, before a bitter public falling-out.',
     'rel': 'The president he empowered — and then feuded with.'},
    {'name': 'OpenAI / Sam Altman', 'role': 'AI rivals', 'color': '#b45309',
     'bio': 'The AI lab Musk co-founded and then left; he later sued it and built xAI to compete, making its leadership among his sharpest rivals.',
     'rel': 'The AI venture he started, split from, and now races.'},
]

KEY_EVENTS = [
    ('1971', 'Born in Pretoria, South Africa', 'A bullied, bookish, self-taught child.'),
    ('1995', 'Founds Zip2', 'Drops out of Stanford for the internet.'),
    ('1999', 'Zip2 sold for ~$307M', 'His first fortune.'),
    ('2002', 'PayPal sold to eBay', '~$180M; founds SpaceX the same year.'),
    ('2004', 'Funds and joins Tesla', 'Leads the electric-car startup.'),
    ('2008', 'Both firms nearly fail', 'Falcon 1 succeeds; NASA contract saves SpaceX.'),
    ('2015', 'First rocket landing', 'SpaceX begins reusing boosters.'),
    ('~2021', 'World’s richest person', 'Tesla and SpaceX valuations soar.'),
    ('2022', 'Buys Twitter for $44B', 'Renames it X.'),
    ('2023', 'Founds xAI / Grok', 'Enters the AI race; merges X into xAI in 2025.'),
    ('2025', 'Leads then leaves DOGE', 'Cuts agencies; then feuds with Trump.'),
    ('2026', 'SpaceX record offering', 'Wealth pushes toward the trillion-dollar mark.'),
]

MASTER = [
    {'year': '1971', 'age': 'born', 'phase': 'Outsider', 'title': 'Born in South Africa', 'desc': 'Bullied, self-taught.'},
    {'year': '1999', 'age': 'age 27', 'phase': 'First Fortune', 'title': 'Zip2 sold', 'desc': 'His first fortune.'},
    {'year': '2002', 'age': 'age 30', 'phase': 'First Fortune', 'title': 'PayPal; founds SpaceX', 'desc': 'Bets on rockets.'},
    {'year': '2008', 'age': 'age 36', 'phase': 'Impossible Bets', 'title': 'The near-death year', 'desc': 'Saved at the buzzer.'},
    {'year': '2015', 'age': 'age 43', 'phase': 'Impossible Bets', 'title': 'Rocket landing', 'desc': 'Reusability achieved.'},
    {'year': '~2021', 'age': 'age ~49', 'phase': 'Empire', 'title': 'Richest person', 'desc': 'Tesla and SpaceX soar.'},
    {'year': '2022', 'age': 'age 51', 'phase': 'Polarizing', 'title': 'Buys Twitter/X', 'desc': 'The media turn.'},
    {'year': '2025', 'age': 'age 53', 'phase': 'Polarizing', 'title': 'DOGE and the feud', 'desc': 'Politics and fallout.'},
    {'year': '2026', 'age': 'age 54', 'phase': 'Empire', 'title': 'Trillion-dollar orbit', 'desc': 'Record SpaceX offering.'},
]

SOURCES = [
    ('Britannica Money — Elon Musk', 'https://www.britannica.com/money/Elon-Musk'),
    ('Britannica — Elon Musk (biography)', 'https://www.britannica.com/biography/Elon-Musk'),
    ('Britannica — SpaceX', 'https://www.britannica.com/topic/SpaceX'),
    ('Britannica — Tesla, Inc.', 'https://www.britannica.com/topic/Tesla-Motors'),
]

def build_meta():
    return {
        'pid': 'gm-musk.html', 'kind': 'man', 'emoji': '🚀', 'accent': AC,
        'name': 'Elon Musk', 'years': 'b. 1971', 'group': 'Business & Industry',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'From a bullied boy coding in Pretoria to reusable rockets, mainstream electric cars, and the greatest fortune in history — the most transformative and most polarising builder of the age.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Outsider', 'type': 'timeline',
             'intro': 'A bullied, bookish South African boy teaches himself to code, emigrates to America, and builds his first internet company — Zip2 — sleeping in the office.', 'events': PHASE_RISE},
            {'id': 'paypal', 'label': '2 · The First Fortune', 'type': 'timeline',
             'intro': 'He turns Zip2 into a bigger bet — PayPal — and, though ousted as CEO, walks away with the war-chest that will fund rockets and electric cars.', 'events': PHASE_PAYPAL},
            {'id': 'bets', 'label': '3 · The Impossible Bets', 'type': 'timeline',
             'intro': 'He stakes his whole fortune on SpaceX and Tesla, nearly loses both in 2008, and then pioneers reusable rockets and mainstream electric cars.', 'events': PHASE_BETS},
            {'id': 'empire', 'label': '4 · The Empire', 'type': 'timeline',
             'intro': 'Tesla and SpaceX soar, making him the richest person on earth atop a sprawling empire — and by 2026 a trillion-dollar space business.', 'events': PHASE_EMPIRE},
            {'id': 'now', 'label': '5 · The Polarizing Years', 'type': 'timeline',
             'intro': 'He buys the world’s town square, builds a frontier AI, and plunges into politics with Trump and DOGE — becoming as divisive as he is consequential.', 'events': PHASE_NOW,
             'sources': SOURCES, 'srcnote': 'Musk is a living, highly active figure; net-worth figures and his political and AI ventures change rapidly and are widely disputed. This guide was researched to 2026 and presents achievements and controversies side by side.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
