# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Andrew Carnegie."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#475569'  # steel gray

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_ladder():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the climb: from $1.20 a week upward</text>'
    rows=[('#78350f','Bobbin boy','12 years old, a cotton mill, $1.20 a week'),
          ('#b45309','Telegraph messenger','learns the wires; memorises the city and its men'),
          ('#475569','Telegraph operator','one of the few who can read Morse by ear — noticed')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="42" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+21}" r="9" fill="{c}"/><text x="62" y="{y+25}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+18}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+34,s,9.3,'#5b6472',500,11,78); b+=ss
        y+=50
    return _wrap(W, H, 'The bottom rungs — a boy on the make', _tk(b, W, H, 'Every job was a school: he turned each humble post into a way of being noticed by powerful men.'), '', AC)

def svg_bessemer():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">why his steel crushed every rival on price</text>'
    boxes=[(40,'#475569','Bet on Bessemer steel','builds the huge Edgar Thomson works, 1875'),
           (270,'#0e7490','Vertical integration','owns the ore, coke, ships and rails — end to end'),
           (500,'#166534','Obsessive cost control','“watch the costs and the profits take care of themselves”')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">By owning the whole chain and knowing every cost, he sold steel cheaper than anyone alive.</text>'
    return _wrap(W, H, 'The steel machine — cost as a weapon', _tk(b, W, H, 'He won not by charging more but by relentlessly making steel cheaper than any competitor could.'), '', AC)

def svg_homestead():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1892 · the contradiction at the heart of his story</text>'
    left = {'title':'The public friend of labour', 'color':'#166534',
            'lines':['wrote warmly of workers’ rights','claimed to support unions and fair wages','cultivated the image of a kindly boss']}
    right = {'title':'The Homestead strike', 'color':'#7f1d1d',
             'lines':['Frick moves to break the union','Pinkerton guards; a gun battle; deaths','the union is crushed — Carnegie away in Scotland']}
    b += f'<rect x="40" y="58" width="300" height="96" rx="12" fill="#f0fdf4" stroke="{left["color"]}" stroke-width="1.7"/>'
    b += f'<text x="56" y="80" font-size="11.5" font-weight="800" fill="{left["color"]}">{left["title"]}</text>'
    yy=98
    for ln in left['lines']:
        b += f'<circle cx="60" cy="{yy-3}" r="2.6" fill="{left["color"]}"/>'
        ss,_=_tspans(72,yy,ln,9.4,'#5b6472',500,12,40); b+=ss; yy+=17
    b += f'<rect x="380" y="58" width="300" height="96" rx="12" fill="#fef2f2" stroke="{right["color"]}" stroke-width="1.9"/>'
    b += f'<text x="396" y="80" font-size="11.5" font-weight="800" fill="{right["color"]}">{right["title"]}</text>'
    yy=98
    for ln in right['lines']:
        b += f'<circle cx="400" cy="{yy-3}" r="2.6" fill="{right["color"]}"/>'
        ss,_=_tspans(412,yy,ln,9.4,'#5b6472',500,12,40); b+=ss; yy+=17
    b += '<line x1="340" y1="106" x2="378" y2="106" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    return _wrap(W, H, 'Homestead — the stain on his name', _tk(b, W, H, 'The self-styled friend of the worker let his partner crush a union by force — a permanent blot on his legend.'), '', AC)

def svg_gospel():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">what to do with the greatest fortune on earth</text>'
    boxes=[(40,'#475569','Sells to Morgan, 1901','$480M for Carnegie Steel — richest man alive'),
           (270,'#0e7490','The Gospel of Wealth','the rich are trustees; give it away while living'),
           (500,'#166534','Gives away ~90%','~2,500 libraries, Carnegie Hall, universities, peace')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">“The man who dies rich dies disgraced” — he spent his last years giving the fortune away.</text>'
    return _wrap(W, H, 'The Gospel of Wealth', _tk(b, W, H, 'He argued the rich are only trustees of their wealth — and gave away almost all of his to prove it.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — BOBBIN BOY
PHASE_RISE = [
    E('scotland', '1835–1848', 'A weaver’s son, ruined by machines', ['RISE', 'TRAGEDY'],
      'He is born poor in Scotland, the son of a handloom weaver whose trade is destroyed by the very industrial machines that will one day make his son the richest man on earth. The ruined family emigrates to America with almost nothing.',
      svg_stack('Born on the losing side of industry', [
          {'n': 1, 'label': 'Weaver’s son, Scotland', 'sub': 'Dunfermline, 1835; a proud, radical family', 'color': '#78350f'},
          {'n': 2, 'label': 'Father ruined by power looms', 'sub': 'machines destroy the handloom trade', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Emigrates to America, 1848', 'sub': 'the family arrives near Pittsburgh, penniless', 'color': '#475569'},
      ], takeaway='Industrialisation destroyed his father — and Carnegie would ride the same force to unimaginable wealth.', accent=AC),
      bg='Carnegie was born in <b>1835</b> in <b>Dunfermline, Scotland</b>, into a poor but politically radical weaving family whose livelihood was being destroyed by mechanised looms.',
      people='His father <b>William</b>, a handloom weaver undone by machines; his ambitious, determined mother <b>Margaret</b>.',
      what='As industrial machines destroyed the handloom trade, the impoverished Carnegie family <b>emigrated to the United States in 1848</b>, settling near <b>Pittsburgh</b> with almost nothing.',
      crux='He experienced, in his own family, both the <b>destructive and creative sides of the Industrial Revolution</b> — a force that ruined his father and that he would learn to master.',
      conseq='The thirteen-year-old boy went straight to work to help support the family, beginning at the very bottom.',
      matters='The same forces that destroy one generation can be harnessed by the next. Carnegie learned that lesson from his own father’s ruin.'),

    E('bobbin', '1848–1853', 'Bobbin boy to telegraph operator', ['RISE'],
      'He starts at twelve as a bobbin boy for $1.20 a week, becomes a telegraph messenger who memorises every business and face in Pittsburgh, and teaches himself to read Morse code by ear — turning each humble job into a ladder rung.',
      svg_ladder(),
      bg='In industrial <b>Pittsburgh</b>, the young Carnegie took a series of jobs, each of which he used to learn, connect and rise.',
      people='The Pittsburgh businessmen he came to know as a messenger; the telegraph office that trained him.',
      what='Carnegie began as a <b>bobbin boy</b> in a cotton mill ($1.20/week), became a <b>telegraph messenger</b> (learning the city and its powerful men), and rose to <b>telegraph operator</b> — one of the few able to read Morse by ear.',
      crux='He treated every job as a <b>school and a network</b>, making himself useful, visible and irreplaceable to influential people at each step.',
      conseq='His skill and drive as a telegrapher brought him to the attention of a rising railroad executive, Thomas Scott.',
      matters='Opportunity favours the prepared and the noticed. Carnegie turned menial jobs into a launchpad by learning relentlessly and making the right friends.'),

    E('radical', '1835–1860s', 'The radical inheritance — a weaver’s democratic creed', ['RISE', 'POLITICS'],
      'He carries from Scotland more than poverty: a fierce family tradition of radical, democratic politics — Chartists and agitators who despised inherited privilege — that shapes his lifelong belief in merit over birth, his American patriotism, and, eventually, the egalitarian conscience behind his giving.',
      svg_row('The politics behind the fortune', [
          {'n': 1, 'label': 'A radical family', 'sub': 'Chartist agitators who scorned aristocracy', 'color': '#475569'},
          {'n': 2, 'label': 'Merit over birth', 'sub': 'a lifelong belief in the self-made man', 'color': '#0e7490'},
          {'n': 3, 'label': 'The seed of the Gospel', 'sub': 'egalitarian conscience behind his later giving', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='His radical, anti-aristocratic roots shaped both his rise and the democratic conscience behind his philanthropy.', accent=AC),
      bg='Carnegie’s family in <b>Dunfermline</b> were politically radical — <b>Chartists</b> and reformers who hated inherited privilege and championed the common man.',
      people='His father and uncles, radical agitators; the democratic ideals he absorbed and carried to America.',
      what='Carnegie inherited a <b>fierce radical, anti-aristocratic creed</b> from his Scottish family, which shaped his passionate <b>American patriotism</b>, his faith in <b>merit over birth</b>, and ultimately the egalitarian conscience behind his philanthropy.',
      crux='His politics were the <b>unseen engine</b> of his life: a belief that privilege should be earned, not inherited — which justified both his own rise and his later giving.',
      conseq='This creed underlay his celebration of America and his conviction that great fortunes owed a debt to society.',
      matters='Ideas shape empires of wealth too. Carnegie’s radical roots explain both his relentless self-making and his eventual gospel of giving.'),

    E('war', '1861–1865', 'The Civil War — telegraphs, railroads, and a first killing', ['RISE', 'BATTLE'],
      'The Civil War is his great accelerator: he helps run the Union’s military railroads and telegraphs, sees how vital iron and rails are to modern war, and — like many of the era’s tycoons — quietly grows rich on wartime contracts and investments while avoiding the fighting himself.',
      svg_row('War as a business school and a windfall', [
          {'n': 1, 'label': 'Runs war railroads & telegraphs', 'sub': 'organises Union military transport and wires', 'color': '#475569'},
          {'n': 2, 'label': 'Sees the future: iron & rails', 'sub': 'war proves the value of metal and transport', 'color': '#0e7490'},
          {'n': 3, 'label': 'Grows rich (and stays out)', 'sub': 'wartime contracts and investments; hires a substitute', 'color': '#b45309'},
      ], edge_labels=['then', 'plus'], takeaway='The war taught him the future was iron and rails — and made him richer, while he avoided the front himself.', accent=AC),
      bg='The <b>American Civil War</b> transformed the economy and Carnegie’s prospects, showing the decisive importance of <b>railroads, telegraphs and iron</b>.',
      people='The Union war effort he served in a logistical role; the era’s other tycoons who prospered from the war.',
      what='Carnegie helped organise the Union’s <b>military railroads and telegraphs</b>, grasped the wartime importance of <b>iron and transport</b>, and (like many) <b>grew wealthy through wartime contracts and investments</b> — while, in the custom of the rich, <b>paying for a substitute</b> rather than serving in combat.',
      crux='He learned firsthand that the <b>future belonged to iron, steel and railroads</b>, and used the war to accelerate his fortune and his focus.',
      conseq='The war sharpened Carnegie’s focus on the industries — iron, steel, transport — that would make him the richest man in the world.',
      matters='Great fortunes often crystallise in upheaval. The Civil War pointed Carnegie squarely at the metal-and-rails future he would come to dominate.'),
]

# ==================================================================  PHASE 2 — THE RAILROAD YEARS
PHASE_RAIL = [
    E('scott', '1853–1865', 'The railroad and a mentor’s lessons', ['RISE', 'POLITICS'],
      'Hired by the powerful Thomas Scott of the Pennsylvania Railroad, he learns big-business management from the inside — and the transformative lesson that would define his life: how to make money work for you through investment.',
      svg_row('Learning how capitalism really works', [
          {'n': 1, 'label': 'Scott’s protégé', 'sub': 'joins the Pennsylvania Railroad under Thomas Scott', 'color': '#475569'},
          {'n': 2, 'label': 'Learns management', 'sub': 'runs telegraph and traffic; rises fast', 'color': '#0e7490'},
          {'n': 3, 'label': 'His first investments', 'sub': 'discovers income that comes without daily labour', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='A mentor taught him the secret that money, well invested, could earn far more than any wage.', accent=AC),
      bg='<b>Thomas A. Scott</b>, a top executive of the <b>Pennsylvania Railroad</b>, hired the talented young telegrapher and became his mentor.',
      people='His mentor <b>Thomas Scott</b>; the Pennsylvania Railroad, then one of the largest and most sophisticated businesses in the world.',
      what='Under Scott, Carnegie mastered <b>modern management</b> in the railroad — the era’s cutting-edge big business — and, crucially, made his <b>first investments</b> (in express and sleeping-car companies), earning his first returns from capital rather than wages.',
      crux='He absorbed two things that made his fortune: the <b>management techniques of large-scale industry</b>, and the revelation that <b>invested capital could generate wealth on its own</b>.',
      conseq='Carnegie began accumulating investments in iron, bridges and oil, steadily building the capital and connections for his own empire.',
      matters='The wealthy think in terms of assets, not wages. Carnegie’s great lesson — make money work for you — is the hinge of his whole rise.'),

    E('goldengoose', '1856–1863', 'The goose that lays golden eggs', ['RISE', 'TURNING POINT'],
      'A tip from his railroad mentor lets the young Carnegie buy his first shares — in Adams Express and a sleeping-car company — and when the first dividend cheque arrives for money he did not have to work for, he grasps the idea that will make him rich: capital that earns while you sleep.',
      svg_stack('Discovering that money can work for you', [
          {'n': 1, 'label': 'A first, borrowed investment', 'sub': 'Scott helps him buy Adams Express shares on credit', 'color': '#475569'},
          {'n': 2, 'label': 'The Woodruff sleeping car', 'sub': 'an early stake in the new railway sleeping-car business', 'color': '#334155'},
          {'n': 3, 'label': '“Here’s the goose”', 'sub': 'a dividend arrives for no labour — the great epiphany', 'color': '#16a34a'},
      ], takeaway='He learned young that owning a share of a growing business beats any wage — and never forgot it.', accent=AC),
      bg='Still a young railroad employee, Carnegie was let into his first investments by his mentor Thomas Scott, who advanced or guided the money.',
      people='<b>Thomas Scott</b>, the mentor who opened the door; <b>Theodore Woodruff</b>, inventor of the sleeping car; the express and railway firms whose shares he bought.',
      what='Carnegie bought early shares in <b>Adams Express</b> and the <b>Woodruff sleeping-car</b> venture. When the first <b>dividend cheque</b> arrived, he reportedly exclaimed, “Here’s the goose that lays the golden eggs” — the birth of his philosophy of capital.',
      crux='He saw that <b>ownership, not wages, builds fortune</b> — money invested in a growing enterprise multiplies without labour.',
      conseq='He poured every spare dollar into investments thereafter, building the capital base that let him move into iron and steel.',
      matters='The pivotal insight of wealth is simple and early-learned: make capital work so you are paid while you sleep.'),

    E('iron', '1865–1872', 'Into iron, bridges, and his own ventures', ['RISE', 'POLITICS'],
      'Leaving the railroad, he strikes out on his own, building bridge and iron works and growing rich — until a trip to Britain shows him a new technology that will let him bet everything on one industry: steel.',
      svg_stack('Building the base of an empire', [
          {'n': 1, 'label': 'Leaves the railroad', 'sub': 'goes into business fully for himself', 'color': '#475569'},
          {'n': 2, 'label': 'Iron and bridges', 'sub': 'Keystone Bridge and iron works prosper', 'color': '#0e7490'},
          {'n': 3, 'label': 'Sees the future: steel', 'sub': 'in Britain he watches the Bessemer process', 'color': '#166534'},
      ], takeaway='He built wealth in iron — then had the vision to abandon diversification and bet it all on steel.', accent=AC),
      bg='By the late 1860s Carnegie was a prosperous businessman with interests in iron, bridges and oil, looking for the one great opportunity.',
      people='His business partners in the Keystone Bridge and iron ventures; the British steelmakers using the <b>Bessemer process</b>.',
      what='Carnegie left the railroad to run his own <b>iron and bridge-building</b> ventures. On a trip to <b>Britain</b>, he saw the <b>Bessemer process</b> for cheaply mass-producing steel and grasped its revolutionary potential.',
      crux='He made the pivotal decision to <b>concentrate rather than diversify</b> — to stake his future on the single, transformative industry of <b>steel</b>.',
      conseq='Carnegie poured his capital and energy into building the most advanced, lowest-cost steel operation in America.',
      matters='Focus can beat diversification. Carnegie’s willingness to bet everything on one rising technology made him the steel king.'),

    E('bonds', '1867–1872', 'The bond salesman — selling America to Europe', ['RISE', 'POLITICS'],
      'Before he ever made steel, Carnegie grew rich as a middleman — crossing the Atlantic again and again to sell American railroad bonds to European investors, pocketing enormous commissions and learning that reputation and salesmanship could be as lucrative as any factory.',
      svg_row('Getting rich in the middle', [
          {'n': 1, 'label': 'America needs capital', 'sub': 'railroads and bridges hunger for investment', 'color': '#475569'},
          {'n': 2, 'label': 'Europe has the money', 'sub': 'Carnegie sells US railway bonds to British and German buyers', 'color': '#334155'},
          {'n': 3, 'label': 'Fat commissions', 'sub': 'huge fees for brokering the deals fund his own ventures', 'color': '#16a34a'},
      ], edge_labels=['meets', 'yields'], takeaway='He learned that the person who connects capital to opportunity can profit as much as either side.', accent=AC),
      bg='In the post–Civil War boom, American railroads needed vast capital that European investors were eager to supply. Carnegie positioned himself as the trusted broker between them.',
      people='the European bankers and investors he courted; the American railroads and bridge companies raising money; his own growing web of iron and bridge ventures.',
      what='Through the late 1860s and early 1870s Carnegie made repeated trips to Europe <b>selling American railroad bonds</b>, earning <b>large commissions</b> — some deals were sharp-elbowed, trading on inside knowledge and relationships.',
      crux='He grasped the power of the <b>intermediary and the reputation</b> — brokering trust between capital and opportunity was itself a fortune.',
      conseq='The commissions gave him the capital, contacts and confidence to commit fully to the iron and steel business that made his name.',
      matters='Fortunes are often made in the connective role — matching those who have money with those who can use it.'),

    E('oil', '1861–1870s', 'The golden goose — oil and the magic of investment', ['RISE', 'TRIUMPH'],
      'A single early investment teaches him the lesson of his life: a stake in a Pennsylvania oil farm pays out enormous dividends for almost no work, and the young Carnegie realises that capital, wisely placed, can earn far more than any wage — the insight that turns a clever employee into a capitalist.',
      svg_row('Discovering that money can breed money', [
          {'n': 1, 'label': 'Invests in Storey Farm oil', 'sub': 'a stake in a Pennsylvania oil property', 'color': '#475569'},
          {'n': 2, 'label': 'Huge, easy dividends', 'sub': 'enormous returns for little effort', 'color': '#0e7490'},
          {'n': 3, 'label': 'The capitalist’s lesson', 'sub': 'invested capital beats any salary', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='One oil windfall taught him the defining lesson: make capital, not labour, the engine of wealth.', accent=AC),
      bg='Amid the early Pennsylvania oil boom, Carnegie made investments that produced spectacular, near-effortless returns.',
      people='His fellow investors; the Pennsylvania oil fields (notably <b>Storey Farm</b>).',
      what='Carnegie’s stake in the <b>Storey Farm</b> oil property (and similar investments) paid <b>enormous dividends</b> for little work, driving home the lesson that <b>invested capital vastly outperforms wages</b> — the foundation of his capitalist strategy.',
      crux='He internalised early that the path to real wealth was <b>owning assets, not earning a salary</b> — and reinvested aggressively.',
      conseq='Carnegie built a diversified portfolio (iron, bridges, oil, bonds) that gave him the capital to attack steel.',
      matters='The oil windfall crystallised Carnegie’s whole method — turn every dollar into an asset that earns more dollars.'),
]

# ==================================================================  PHASE 3 — THE STEEL KING
PHASE_STEEL = [
    E('bessemer', '1872–1880', 'The steel bet and the cult of cost', ['RISE', 'TRIUMPH', 'TURNING POINT'],
      'He builds a giant modern steelworks, integrates everything from ore to rail under his control, and applies a fanatical obsession with cost — driving the price of steel down and down until he can undersell every rival on earth.',
      svg_bessemer(),
      bg='Steel — stronger and more versatile than iron — was becoming the material of the modern age: rails, bridges, buildings, machines.',
      people='His managers and partners; the ore mines, coke works and railroads he brought under one integrated empire.',
      what='Carnegie built the huge <b>Edgar Thomson Steel Works (1875)</b>, pursued <b>vertical integration</b> (owning ore, coke, transport and mills), and enforced <b>ruthless cost accounting</b> — his maxim: "watch the costs and the profits take care of themselves."',
      crux='His edge was <b>relentless cost reduction through integration and measurement</b>: by knowing and cutting every cost, he could always undersell competitors and still profit.',
      conseq='The price of steel plummeted, fuelling America’s industrial boom; Carnegie’s operation became the most efficient in the world.',
      matters='In commodity industries, the low-cost producer wins. Carnegie’s obsession with cost is a founding lesson of modern industrial business.'),

    E('thomson', '1872–1875', 'The Edgar Thomson Works — flattering the customer in steel', ['RISE', 'TRIUMPH', 'REFORM'],
      'Carnegie builds his first great steel plant and names it after the president of the Pennsylvania Railroad — his biggest potential customer — a masterstroke of flattery that guarantees orders, wrapped around a mill built from scratch around the latest, most efficient technology.',
      svg_stack('A mill designed to win — and to sell', [
          {'n': 1, 'label': 'A state-of-the-art Bessemer plant', 'sub': 'built new and optimal, not patched onto old works', 'color': '#475569'},
          {'n': 2, 'label': 'Named for J. Edgar Thomson', 'sub': 'the Pennsylvania Railroad’s president — his key customer', 'color': '#334155'},
          {'n': 3, 'label': 'Orders guaranteed', 'sub': 'the flattered railroad becomes a loyal buyer of its own namesake’s rails', 'color': '#16a34a'},
      ], takeaway='He combined ruthless technical efficiency with shrewd salesmanship — even the plant’s name was a business weapon.', accent=AC),
      bg='Committing to steel, Carnegie built his first major works near Pittsburgh in the mid-1870s, designed from the ground up for maximum efficiency.',
      people='<b>J. Edgar Thomson</b>, president of the Pennsylvania Railroad; the engineers who built the plant; the rail customers Carnegie meant to lock in.',
      what='He built the <b>Edgar Thomson Steel Works</b> (opened 1875), a modern Bessemer plant, and <b>named it after his biggest customer</b> — ensuring the Pennsylvania Railroad would buy rails bearing its own president’s name.',
      crux='He fused <b>best-in-class technology with psychological salesmanship</b> — efficiency to cut costs, flattery to guarantee demand.',
      conseq='The Edgar Thomson Works became the cornerstone of Carnegie Steel and a model of low-cost, high-volume production.',
      matters='Winning business is part engineering, part psychology — even a factory’s name can be an instrument of strategy.'),

    E('empire', '1880–1892', 'Carnegie Steel dominates America', ['TRIUMPH', 'POLITICS'],
      'Consolidating his mills into Carnegie Steel and taking on the ferociously effective Henry Clay Frick to run them, he builds the largest and most profitable steel enterprise on the planet — and becomes one of the richest men in the world.',
      svg_row('Building the dominant steel empire', [
          {'n': 1, 'label': 'Consolidates his mills', 'sub': 'forms the mighty Carnegie Steel Company', 'color': '#475569'},
          {'n': 2, 'label': 'Partners with Frick', 'sub': 'the hard-driving coke king runs operations', 'color': '#0e7490'},
          {'n': 3, 'label': 'World’s largest steelmaker', 'sub': 'immense output and profit; huge personal fortune', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He assembled the greatest steel enterprise on earth — and one of history’s great fortunes.', accent=AC),
      bg='Through the 1880s Carnegie consolidated his steel interests and drove ever-greater scale and efficiency.',
      people='His partner and operations chief <b>Henry Clay Frick</b>, the "coke king"; his managers, chosen for talent and drive.',
      what='Carnegie merged his operations into <b>Carnegie Steel</b>, brought in <b>Henry Clay Frick</b> to run the mills and secure coke supplies, and built the <b>largest and most profitable steel company in the world</b>.',
      crux='He combined <b>scale, integration, cost control and ruthless talent selection</b> to dominate the defining industry of the age.',
      conseq='Carnegie became one of the wealthiest men alive — but his partnership with the hard-line Frick set up the darkest episode of his career.',
      matters='Great enterprises are built by great operators as much as visionaries. Carnegie’s genius included choosing — and unleashing — men like Frick.'),

    E('frick', '1881–1899', 'The Frick alliance — coke, and a bitter break', ['POLITICS', 'TRIUMPH', 'TRAGEDY'],
      'To feed his furnaces, Carnegie partners with the ruthless coke king Henry Clay Frick, securing the fuel his steel needs and a brilliant manager to run the empire — a hugely profitable union that curdles into one of American business’s most venomous feuds.',
      svg_stack('A powerful partnership that turned to poison', [
          {'n': 1, 'label': 'Frick brings the coke', 'sub': 'H.C. Frick Coke controls the fuel steelmaking depends on', 'color': '#334155'},
          {'n': 2, 'label': 'A formidable manager', 'sub': 'Frick runs Carnegie Steel with iron efficiency', 'color': '#475569'},
          {'n': 3, 'label': 'A savage falling-out, 1899', 'sub': 'they clash over price and control; “I’ll see you in hell”', 'color': '#b91c1c'},
      ], takeaway='He gained the coke and the manager he needed — and made a partner whose talent matched his own capacity for grudges.', accent=AC),
      bg='Steelmaking required <b>coke</b> (processed coal). <b>Henry Clay Frick</b> dominated its supply — so Carnegie bought into Frick’s company and made him a partner and manager.',
      people='<b>Henry Clay Frick</b>, the coke magnate and hard-driving executive; Carnegie, the senior partner; the courts that later settled their split.',
      what='From 1881 Carnegie and Frick were allied: Frick’s <b>coke secured the fuel supply</b> and Frick’s management drove profits. But by <b>1899 they broke bitterly</b> over the price of coke and Frick’s stake, ending in litigation and lifelong enmity — Frick reportedly refusing a deathbed reconciliation.',
      crux='He secured a <b>vital input and a great manager</b> in one move — but two dominant, unyielding men could not share power forever.',
      conseq='The alliance built much of Carnegie Steel’s strength; the feud (and Frick’s role at Homestead) left permanent scars.',
      matters='The best partnerships secure what you lack — but combining two strong wills stores up conflict for later.'),

    E('partners', '1870s–1901', 'The young geniuses — management by partnership', ['REFORM', 'TRIUMPH'],
      'His secret weapon is people: he spots and promotes brilliant young managers — men like Charles Schwab, who rose from stake-driver — binds them with junior partnerships and profit shares so they think like owners, and drives them with fierce internal competition, building a management machine as formidable as his mills.',
      svg_row('Turning employees into owner-operators', [
          {'n': 1, 'label': 'Spot young talent', 'sub': 'promotes able men fast, regardless of origin', 'color': '#475569'},
          {'n': 2, 'label': 'Junior partnerships', 'sub': 'profit shares make managers think like owners', 'color': '#0e7490'},
          {'n': 3, 'label': 'Fierce internal rivalry', 'sub': 'managers pushed to outdo each other on cost', 'color': '#166534'},
      ], edge_labels=['then', 'plus'], takeaway='He built a machine of hungry, part-owner managers — his real competitive edge was people, not just plant.', accent=AC),
      bg='Carnegie’s success rested as much on his <b>management method</b> as on technology — above all his knack for finding and motivating talent.',
      people='<b>Charles Schwab</b>, who rose from stake-driver to president; the many young managers Carnegie made junior partners.',
      what='Carnegie <b>identified and rapidly promoted talented young managers</b>, bound them with <b>junior partnerships and profit-sharing</b> so they acted like owners, and drove them with <b>intense internal competition</b> to cut costs and boost output.',
      crux='He understood that <b>motivated, part-owner managers</b> would outwork and out-think salaried employees — turning human incentive into a competitive weapon.',
      conseq='This management culture made Carnegie Steel extraordinarily efficient and produced a generation of industrial leaders.',
      matters='People are the real machine. Carnegie’s system of talent-spotting and profit-sharing is a founding template of modern management.'),

    E('vertical', '1880s–1900', 'Owning the whole chain — from ore to rail', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'Carnegie’s decisive strategy is to own every link in the steel chain — the iron ore in the ground, the ships and railroads that carry it, the coke that fires it, and the mills that shape it — so that no supplier can squeeze him and every stage adds only his own profit.',
      svg_row('Controlling every step, paying no middleman', [
          {'n': 1, 'label': 'The ore', 'sub': 'vast Mesabi Range iron-ore reserves locked up', 'color': '#475569'},
          {'n': 2, 'label': 'Transport & coke', 'sub': 'own lake ships, railroads and coke supply', 'color': '#334155'},
          {'n': 3, 'label': 'The mills', 'sub': 'raw ore to finished steel under one owner', 'color': '#16a34a'},
      ], edge_labels=['to', 'to'], takeaway='By owning the entire supply chain he removed every middleman’s markup — and every rival’s leverage.', accent=AC),
      bg='Steelmaking depended on many inputs and carriers, each a potential chokepoint. Carnegie set out to control them all — “vertical integration.”',
      people='<b>John D. Rockefeller</b>, whose Mesabi ore Carnegie leased; the managers of his ships, railroads and coke works; the suppliers he no longer had to pay.',
      what='Carnegie secured the rich <b>Mesabi Range</b> ore (via a deal with Rockefeller), owned <b>lake steamers and railroads</b> to move it, controlled <b>coke</b> through Frick, and ran the <b>mills</b> — an unbroken chain from ground to finished rail.',
      crux='He grasped that <b>owning the whole chain</b> both slashed costs and made him immune to being squeezed by suppliers or carriers.',
      conseq='Vertical integration made Carnegie Steel the lowest-cost, most powerful producer in the world — the template for industrial giants after him.',
      matters='Controlling your entire supply chain removes both cost and vulnerability — dependence on others is a weakness to be engineered away.'),

    E('pricewars', '1870s–1890s', 'Winning by cost — price wars and hard times', ['TRIUMPH', 'POLITICS'],
      'His cost obsession becomes a weapon in the market: where rivals join cartels to prop up prices, Carnegie often does the opposite — cutting prices hard, especially in downturns when he builds and expands while competitors retrench, so that every slump ends with Carnegie Steel stronger and its rivals weaker.',
      svg_row('Using downturns to crush rivals', [
          {'n': 1, 'label': 'Lowest cost producer', 'sub': 'always able to undersell and still profit', 'color': '#475569'},
          {'n': 2, 'label': 'Expand in the slumps', 'sub': 'builds cheaply when rivals retrench', 'color': '#0e7490'},
          {'n': 3, 'label': 'Emerge stronger each cycle', 'sub': 'downturns leave Carnegie dominant', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='He turned recessions into opportunities — expanding when others cut back, and undercutting them into submission.', accent=AC),
      bg='In an age of <b>pools and cartels</b> that tried to fix prices, Carnegie’s low costs let him play a different, more aggressive game.',
      people='His cartel-minded rivals; the customers who benefited from ever-cheaper steel.',
      what='As the lowest-cost producer, Carnegie frequently <b>cut prices hard</b> and <b>expanded during downturns</b> — investing cheaply while rivals retrenched — so that each economic cycle left <b>Carnegie Steel stronger and competitors weaker</b>.',
      crux='His unbeatable costs let him treat <b>price competition and downturns as weapons</b>, not threats — the opposite of his cartel-seeking rivals.',
      conseq='Carnegie steadily crushed or absorbed competitors, driving toward near-domination of American steel.',
      matters='The low-cost producer can weaponise the very downturns that ruin others. Carnegie’s counter-cyclical aggression is a classic of competitive strategy.'),
]

# ==================================================================  PHASE 4 — THE STAIN AND THE SALE
PHASE_SALE = [
    E('panics', '1873–1893', 'Cash is king — thriving in the panics', ['TRIUMPH', 'POLITICS', 'TURNING POINT'],
      'While rivals overextend and collapse in the great financial panics, Carnegie keeps his firm liquid and conservatively financed — then uses the downturns to expand cheaply and modernise, emerging from each crisis stronger and more dominant.',
      svg_stack('Turning downturns into opportunity', [
          {'n': 1, 'label': 'Stay liquid, avoid debt', 'sub': 'keeps cash and shuns the speculation that ruins others', 'color': '#475569'},
          {'n': 2, 'label': 'Panic strikes (1873, 1893)', 'sub': 'over-leveraged competitors fail and sell cheap', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Buy and build in the slump', 'sub': 'expand capacity when costs and rivals are weakest', 'color': '#16a34a'},
      ], takeaway='He treated crashes as buying seasons — discipline in good times let him pounce in bad ones.', accent=AC),
      bg='The Gilded Age was punctuated by severe financial panics that wiped out heavily-indebted firms. Carnegie ran his conservatively.',
      people='the over-leveraged rivals who failed; Carnegie’s partners, kept on a tight financial rein; the workforce and suppliers affected by the cycles.',
      what='Through the panics of <b>1873 and 1893</b>, Carnegie stayed <b>liquid and low on debt</b>, then <b>expanded and modernised</b> when construction and acquisitions were cheapest — “the man who has cash in a panic is king.”',
      crux='He understood the <b>counter-cyclical logic</b>: financial discipline in booms buys overwhelming advantage in busts.',
      conseq='Each panic left Carnegie Steel relatively stronger, steadily crushing or absorbing weaker competitors.',
      matters='The disciplined survive downturns; the bold among them use downturns to win — cash and nerve compound in a crisis.'),

    E('johnstown', '1889', 'The Johnstown Flood — the other shadow', ['TRAGEDY'],
      'Three years before Homestead, a dam owned by an exclusive retreat that Carnegie and his partners belonged to fails catastrophically, unleashing a flood that kills over two thousand people — a disaster the wealthy club members were never held to account for, a darker footnote to the Gilded-Age fortune.',
      svg_row('A disaster the rich escaped blame for', [
          {'n': 1, 'label': 'An elite mountain club', 'sub': 'Carnegie and partners among its members', 'color': '#475569'},
          {'n': 2, 'label': 'Its dam fails, 1889', 'sub': 'poorly maintained; it gives way in heavy rain', 'color': '#7f1d1d'},
          {'n': 3, 'label': '2,200+ dead', 'sub': 'Johnstown destroyed; no members held liable', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='The flood is a stark emblem of Gilded-Age wealth escaping accountability for the harm around it.', accent=AC),
      bg='Carnegie and his business partners were members of the exclusive <b>South Fork Fishing and Hunting Club</b>, whose lake was held back by an ageing, poorly maintained <b>dam</b> above Johnstown, Pennsylvania.',
      people='The wealthy club members; the more than <b>2,200 people</b> killed in the flood; the town of Johnstown.',
      what='In <b>1889</b> the club’s <b>dam failed</b>, sending a wall of water into <b>Johnstown</b> and killing over <b>2,200 people</b> — one of the deadliest disasters in American history. The club’s members, including men in Carnegie’s circle, were <b>never held legally liable</b>.',
      crux='It is a stark case of <b>Gilded-Age wealth avoiding accountability</b> for catastrophe — a shadow over the era’s fortunes, including Carnegie’s.',
      conseq='Carnegie donated to Johnstown’s relief and later library, but the disaster remained a dark association of his social world.',
      matters='Great fortunes cast shadows beyond the factory floor. Johnstown is a reminder of the human costs and unaccountable privilege of the age Carnegie epitomised.'),

    E('homestead', '1892', 'Homestead — the stain', ['TRAGEDY', 'POLITICS'],
      'The self-styled friend of the working man is forever stained when, with Carnegie conveniently away in Scotland, Frick moves to smash the union at the Homestead mill — leading to a pitched battle with Pinkerton guards and deaths on both sides.',
      svg_homestead(),
      bg='Carnegie had publicly presented himself as a <b>friend of labour</b>, writing sympathetically of workers’ rights — even as his business pushed hard on wages and hours.',
      people='His partner <b>Henry Clay Frick</b>, who led the confrontation; the striking steelworkers; the <b>Pinkerton</b> guards hired to break the strike.',
      what='In <b>1892</b>, during a wage dispute at the <b>Homestead</b> works, Frick (with Carnegie’s tacit approval, while Carnegie stayed in Scotland) locked out the workers and brought in <b>Pinkerton guards</b>; a <b>violent battle</b> left men dead and the union broken.',
      crux='It exposed the <b>contradiction between his benevolent public philosophy and his ruthless business practice</b> — a gap he tried, unconvincingly, to disown by being absent.',
      conseq='Homestead permanently stained Carnegie’s reputation and became a landmark in the bitter history of American labour relations.',
      matters='Words and deeds must match. Homestead is the enduring shadow over Carnegie’s legend — proof that his benevolence had hard limits.'),

    E('schwab', '1897–1901', 'Charles Schwab — the protégé who brokered the sale', ['POLITICS', 'TRIUMPH'],
      'The man who engineers Carnegie’s exit is his own protégé Charlie Schwab, who rose from driving stakes to running Carnegie Steel — and whose after-dinner speech so dazzles J.P. Morgan that Morgan resolves to buy the company, with Schwab shuttling the price between the two titans.',
      svg_stack('From stake-driver to kingmaker', [
          {'n': 1, 'label': 'Schwab rises through the ranks', 'sub': 'a day-labourer becomes president of Carnegie Steel', 'color': '#475569'},
          {'n': 2, 'label': 'The 1900 dinner speech', 'sub': 'his vision of consolidation captivates J.P. Morgan', 'color': '#334155'},
          {'n': 3, 'label': 'Brokers the deal', 'sub': 'carries Carnegie’s price to Morgan — the sale is struck', 'color': '#16a34a'},
      ], takeaway='Carnegie’s greatest deal was closed by the ablest of the young men he had raised up on merit.', accent=AC),
      bg='Carnegie famously promoted talent regardless of origin. <b>Charles M. Schwab</b> exemplified it, rising from humble beginnings to lead Carnegie Steel.',
      people='<b>Charles M. Schwab</b>, the protégé-president; <b>J.P. Morgan</b>, the financier assembling U.S. Steel; Carnegie, ready to retire.',
      what='After a celebrated <b>1900 dinner speech</b> on industrial consolidation, Schwab convinced <b>J.P. Morgan</b> to buy Carnegie Steel and then <b>shuttled the negotiations</b> — Carnegie scrawled his price, Morgan accepted.',
      crux='Carnegie’s <b>merit-based promotion</b> paid its ultimate dividend: the man he had raised engineered his fortune-making exit.',
      conseq='The deal created U.S. Steel, the first billion-dollar company; Schwab went on to build Bethlehem Steel.',
      matters='Investing in talent compounds — the people you raise up may one day deliver your greatest outcome.'),

    E('sale', '1901', 'The half-billion-dollar sale', ['TRIUMPH', 'TURNING POINT'],
      'At sixty-five he sells Carnegie Steel to J.P. Morgan for the staggering sum of about $480 million — creating U.S. Steel, the world’s first billion-dollar corporation — and walks away, on paper, the richest man in the world.',
      svg_row('Cashing out at the very top', [
          {'n': 1, 'label': 'Morgan wants to consolidate', 'sub': 'the banker aims to build a steel giant', 'color': '#475569'},
          {'n': 2, 'label': 'Sells for ~$480 million', 'sub': 'an almost unimaginable sum in 1901', 'color': '#0e7490'},
          {'n': 3, 'label': 'U.S. Steel is born', 'sub': 'the world’s first billion-dollar company', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He sold at the peak, turned his empire into cash, and became the richest man on earth.', accent=AC),
      bg='By 1901 the financier <b>J.P. Morgan</b> sought to consolidate the American steel industry into a single colossus.',
      people='<b>J.P. Morgan</b>, the great banker; <b>Charles Schwab</b>, the Carnegie Steel executive who brokered the deal.',
      what='Carnegie sold <b>Carnegie Steel to J.P. Morgan for about $480 million</b> in 1901, forming <b>U.S. Steel</b> — the world’s first <b>billion-dollar corporation</b> — and making Carnegie, on paper, the richest man in the world.',
      crux='He recognised the moment to <b>convert an operating empire into liquid wealth</b> at the top of the market — and to turn from making money to giving it away.',
      conseq='Freed of business, Carnegie devoted the rest of his life and nearly all of his fortune to philanthropy.',
      matters='Knowing when to sell is its own genius. Carnegie exited at the summit and turned to the project that would define his final years.'),

    E('writings', '1880s–1900s', 'The writing tycoon — “Triumphant Democracy” and the public voice', ['REFORM', 'POLITICS'],
      'He is not only a maker of steel but a maker of arguments: a prolific author and essayist who celebrates American democracy in a bestselling book, writes warmly (if inconsistently) about the rights of labour, and — most famously — sets out in "The Gospel of Wealth" the moral philosophy that will define modern philanthropy.',
      svg_row('The industrialist as public intellectual', [
          {'n': 1, 'label': '“Triumphant Democracy”', 'sub': 'a bestselling hymn to America’s rise', 'color': '#475569'},
          {'n': 2, 'label': 'Essays on labour and wealth', 'sub': 'writes on workers’ rights — not always matched in practice', 'color': '#0e7490'},
          {'n': 3, 'label': '“The Gospel of Wealth” (1889)', 'sub': 'the creed of duty-bound giving', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He shaped public opinion with his pen as much as the economy with his mills — a rare writer-tycoon.', accent=AC),
      bg='Carnegie was an unusually <b>literary businessman</b>, writing books and essays that made him a public intellectual as well as an industrialist.',
      people='His wide readership; the reformers and workers who cited (and challenged) his writings on labour.',
      what='Carnegie wrote the bestselling <b>“Triumphant Democracy”</b> celebrating America, essays sympathetic to <b>labour’s rights</b> (in tension with his conduct at Homestead), and above all <b>“The Gospel of Wealth” (1889)</b>, his enduring philosophy of philanthropy.',
      crux='He wielded <b>ideas and public argument</b> as deliberately as capital, shaping opinion and, ultimately, the ethics of great giving.',
      conseq='His writings, especially the Gospel of Wealth, gave his philanthropy an intellectual framework that influenced generations.',
      matters='Carnegie shows the tycoon as public thinker — his ideas about wealth and society proved as influential as his steel.'),
]

# ==================================================================  PHASE 5 — THE GOSPEL OF WEALTH
PHASE_GOSPEL = [
    E('gospel', '1889–1919', 'The Gospel of Wealth', ['REFORM', 'TRIUMPH'],
      'Long before the sale, he had written that the rich are merely trustees of their fortunes and must give them away in their lifetimes — and now he spends his last years doing exactly that, funding some 2,500 libraries, concert halls, universities and a mission for world peace.',
      svg_gospel(),
      bg='In his 1889 essay <b>"The Gospel of Wealth,"</b> Carnegie argued that the rich have a duty to use their fortunes for the public good <b>during their lifetimes</b>.',
      people='The millions who used his free public <b>libraries</b>; the institutions he founded and endowed.',
      what='Carnegie gave away roughly <b>90% of his fortune</b> (about $350 million): funding some <b>2,500 public libraries</b>, building <b>Carnegie Hall</b>, founding <b>Carnegie Mellon University</b> and the <b>Carnegie Endowment for International Peace</b>, and endowing education and science.',
      crux='He turned philanthropy into a <b>systematic philosophy and duty</b> — "the man who dies rich dies disgraced" — pioneering large-scale, strategic giving aimed at helping people help themselves.',
      conseq='His libraries and institutions shaped American education and culture for generations; he became the model for modern philanthropy.',
      matters='Carnegie redefined what wealth is for. His Gospel of Wealth still frames how the super-rich think about giving today.'),

    E('education', '1900–1912', 'Endowing knowledge — schools, science and pensions', ['REFORM', 'TRIUMPH'],
      'Beyond libraries, Carnegie pours his fortune into the machinery of knowledge — founding a technical school that becomes a great university, an institution for pure science, a pension fund for professors, and a medal for everyday heroism.',
      svg_row('Building institutions to outlast him', [
          {'n': 1, 'label': 'Carnegie Technical Schools, 1900', 'sub': 'grows into Carnegie Mellon University', 'color': '#475569'},
          {'n': 2, 'label': 'Science and teaching', 'sub': 'the Carnegie Institution for research; pensions for professors (TIAA)', 'color': '#334155'},
          {'n': 3, 'label': 'The Hero Fund, 1904', 'sub': 'medals and aid for ordinary people who risk their lives', 'color': '#16a34a'},
      ], edge_labels=['plus', 'plus'], takeaway='He funded the permanent institutions of learning and recognition, not just buildings — endowments meant to run forever.', accent=AC),
      bg='Carnegie sought to give in ways that would multiply knowledge and reward merit long after his death, endowing lasting institutions rather than one-off gifts.',
      people='the students of his technical schools; the scientists of the Carnegie Institution; the professors covered by his pension fund; the “heroes” it recognised.',
      what='He founded the <b>Carnegie Technical Schools</b> (1900, later <b>Carnegie Mellon</b>), the <b>Carnegie Institution of Washington</b> for research (1902), a <b>pension fund for professors</b> (the seed of TIAA, 1905/1918), and the <b>Hero Fund</b> (1904) — and supported Black institutions like Tuskegee.',
      crux='He aimed his giving at <b>knowledge, science and merit</b> — endowed institutions designed to compound their good indefinitely.',
      conseq='These bodies — a major university, a research institution, a huge pension system — still shape American education and science today.',
      matters='The most durable philanthropy builds self-sustaining institutions, seeding benefits that outlive the giver by centuries.'),

    E('peace', '1900–1919', 'The crusade for world peace — and its heartbreak', ['REFORM', 'TRAGEDY'],
      'The old steel-master pours his last energies into the cause of ending war itself — funding the Peace Palace at The Hague, endowing a great peace endowment, and lobbying world leaders — only to watch, heartbroken, as the First World War shatters his conviction that reasonable men would never again choose slaughter.',
      svg_row('Fortune turned against war itself', [
          {'n': 1, 'label': 'Funds the peace movement', 'sub': 'the Hague Peace Palace; a peace endowment', 'color': '#475569'},
          {'n': 2, 'label': 'Lobbies world leaders', 'sub': 'presses for arbitration instead of war', 'color': '#0e7490'},
          {'n': 3, 'label': 'WWI breaks his heart', 'sub': '1914 shatters his faith in human reason', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He spent his last years and fortune trying to abolish war — and the Great War broke that dream, and him.', accent=AC),
      bg='In his final decades Carnegie became one of the world’s leading advocates and funders of <b>international peace and arbitration</b>.',
      people='The world leaders he lobbied; the <b>Carnegie Endowment for International Peace</b>; the diplomats of the Hague conferences.',
      what='Carnegie funded the <b>Peace Palace at The Hague</b>, founded the <b>Carnegie Endowment for International Peace (1910)</b>, and personally lobbied rulers to settle disputes by arbitration. The outbreak of <b>World War I in 1914</b> devastated him, destroying his optimistic belief that war was becoming obsolete.',
      crux='He applied his fortune to what he saw as humanity’s greatest problem — <b>war</b> — with the same ambition he had brought to steel, but ran into the tragic limits of idealism.',
      conseq='The war left him disillusioned in his final years, though his peace institutions endure to this day.',
      matters='Even the mightiest fortune cannot buy off history’s tragedies. Carnegie’s peace crusade is a poignant coda to a life of relentless achievement.'),

    E('libraries', '1883–1919', 'The library crusade — 2,500 temples of self-improvement', ['REFORM', 'TRIUMPH'],
      'Carnegie’s signature gift is the free public library — he funds over 2,500 of them across the English-speaking world — because a library gave the penniless immigrant boy his own education, and he believes above all in giving people not charity but the means to lift themselves.',
      svg_stack('Giving the ladder he had climbed', [
          {'n': 1, 'label': 'A boy with no books', 'sub': 'a benefactor’s library educated the young Carnegie', 'color': '#475569'},
          {'n': 2, 'label': 'Fund the building, locals run it', 'sub': 'he pays for the library; the town must stock and staff it', 'color': '#334155'},
          {'n': 3, 'label': '~2,500 libraries worldwide', 'sub': 'from Pittsburgh to Britain to New Zealand', 'color': '#16a34a'},
      ], takeaway='He gave not handouts but the tools of self-education — the same ladder that had raised him.', accent=AC),
      bg='As a poor boy, Carnegie had borrowed books from a benefactor’s library; he credited it with his rise and made libraries his central philanthropy.',
      people='the towns and cities that received libraries; the young readers who used them; the local governments required to maintain them.',
      what='Carnegie funded the construction of more than <b>2,500 public libraries</b> across the US, Britain and the Empire, typically <b>paying for the building</b> on condition that the community <b>stock and staff it</b> — ensuring local commitment.',
      crux='He believed in <b>“help to self-help”</b> — providing the means of improvement, not mere relief, and requiring the recipient to invest too.',
      conseq='The Carnegie libraries transformed access to books and learning for millions and remain his most beloved legacy.',
      matters='The most empowering gift is a tool, not a handout — and one that asks something of the receiver endures.'),

    E('institutions', '1900–1919', 'The machinery of giving — funds, institutes, and heroes', ['REFORM', 'TRIUMPH'],
      'He does not just write cheques but builds enduring institutions of giving: research bodies, a fund for teachers’ pensions, and — one of his most personal creations — a Hero Fund to reward ordinary people who risk their lives for others, pioneering the idea of the permanent, professionally run foundation.',
      svg_stack('Inventing the modern foundation', [
          {'n': 1, 'label': 'Endows research and learning', 'sub': 'the Carnegie Institution; teacher pensions (TIAA’s roots)', 'color': '#475569'},
          {'n': 2, 'label': 'The Hero Fund', 'sub': 'rewards ordinary people who risk their lives for others', 'color': '#0e7490'},
          {'n': 3, 'label': 'The permanent foundation', 'sub': 'professional bodies to keep giving after him', 'color': '#166534'},
      ], takeaway='He built lasting institutions, not just gifts — pioneering the professionally run foundation that outlives its founder.', accent=AC),
      bg='Carnegie sought to make his giving <b>systematic and permanent</b>, founding institutions designed to keep working long after his death.',
      people='The scholars and teachers his funds supported; the ordinary heroes recognised by the <b>Carnegie Hero Fund</b>.',
      what='Carnegie founded enduring bodies — the <b>Carnegie Institution</b> for science, a fund for <b>teachers’ pensions</b> (a root of TIAA), the <b>Carnegie Corporation</b>, and the personal <b>Hero Fund</b> rewarding civilian bravery — pioneering the <b>modern professional foundation</b>.',
      crux='He institutionalised philanthropy, creating <b>permanent, professionally managed foundations</b> rather than one-off gifts — a lasting innovation in how great wealth is given away.',
      conseq='These institutions still operate today, and the foundation model Carnegie helped pioneer shaped 20th-century philanthropy.',
      matters='Carnegie’s deepest philanthropic innovation was structural: the permanent foundation, a machine for giving that outlives its founder.'),

    E('scotland', '1881–1919', 'The immigrant’s heart — Skibo and Dunfermline', ['REFORM'],
      'For all his American triumph, his heart stays Scottish: he buys a Highland castle, Skibo, where he spends his summers, and lavishes gifts on his birthplace Dunfermline — beginning his library-building there — the sentimental thread of a poor emigrant boy who never forgot where he came from.',
      svg_row('The emigrant who came home a lord of giving', [
          {'n': 1, 'label': 'Buys Skibo Castle', 'sub': 'a Highland home for his summers', 'color': '#475569'},
          {'n': 2, 'label': 'Showers Dunfermline', 'sub': 'gifts to his birthplace; his first library there', 'color': '#0e7490'},
          {'n': 3, 'label': 'Never forgets his roots', 'sub': 'the poor emigrant boy honours where he began', 'color': '#166534'},
      ], edge_labels=['plus', 'so'], takeaway='The richest man in the world stayed, at heart, the poor Dunfermline boy who came home to give.', accent=AC),
      bg='Carnegie retained a deep, lifelong attachment to <b>Scotland</b> and his birthplace <b>Dunfermline</b>.',
      people='The people of Dunfermline; the Highland community around <b>Skibo Castle</b>, his summer home.',
      what='Carnegie bought <b>Skibo Castle</b> in the Scottish Highlands, where he summered, and <b>lavished gifts on Dunfermline</b> — including one of his first libraries — remaining sentimentally devoted to the homeland he had left in poverty.',
      crux='His giving was rooted in a <b>personal, emigrant sense of gratitude and belonging</b> — the poor boy repaying, symbolically, the places that formed him.',
      conseq='Dunfermline and Scotland benefited richly from his devotion; his identity remained proudly Scottish-American.',
      matters='Behind the global titan was a sentimental emigrant. Carnegie’s giving flowed partly from a poor boy’s enduring love of home.'),

    E('critics', '1889–1919', 'The paradox — Homestead blood and “tainted money”', ['POLITICS', 'TRAGEDY'],
      'Carnegie’s vast generosity could never fully escape its source: the same man who preached that the rich should give away their fortunes had built his by crushing his workers’ union at Homestead — leading critics to ask whether libraries could ever wash out the “tainted money” that paid for them.',
      svg_compare('The two Carnegies',
        {'head': 'The philanthropist', 'color': '#16a34a', 'items': ['gives away ~90% of his fortune', '2,500 libraries, universities, peace funds', '“The man who dies rich dies disgraced”']},
        {'head': 'The industrialist', 'color': '#b91c1c', 'items': ['broke the union at Homestead (1892)', 'wages cut; men killed in the strike', 'fortune built on brutal cost-cutting']},
        'Both are true at once — the record must hold the generosity and the harm together.',
        'Judge the whole person: the giving was real, and so was the suffering that funded it.', AC),
      bg='Carnegie’s <b>Gospel of Wealth</b> urged the rich to give away their fortunes. But that fortune was made by relentless cost-cutting and, at <b>Homestead</b>, violent union-breaking.',
      people='the <b>Homestead strikers</b> and the men killed there; critics who spoke of “tainted money”; the millions who benefited from his gifts; Carnegie himself, wrestling with the contradiction.',
      what='Reformers and clergy questioned whether philanthropy could <b>redeem money earned by exploitation</b>. Carnegie gave away roughly <b>90% of his wealth</b>, yet the shadow of Homestead and harsh labour practices never lifted.',
      crux='His life poses the enduring question: does <b>great giving offset the harm of the getting</b>, or are they simply two separate moral facts?',
      conseq='The debate over Carnegie — benefactor or exploiter — continues, a template for every discussion of billionaire philanthropy since.',
      matters='Generosity and exploitation can coexist in one life; honest judgement holds both, refusing to let either erase the other.'),

    E('death', '1919', 'The man who tried not to die rich', ['DEATH'],
      'He dies in 1919, having given away all but a fraction of the greatest fortune of his age — worried, to the end, that he had not managed to give away enough, and leaving a legacy less of steel than of libraries.',
      svg_row('The final accounting', [
          {'n': 1, 'label': 'Gives away ~90%', 'sub': 'most of the fortune distributed in his lifetime', 'color': '#475569'},
          {'n': 2, 'label': 'Dies in 1919', 'sub': 'aged 83, having outlived his own business era', 'color': '#111827'},
          {'n': 3, 'label': 'A legacy of libraries', 'sub': 'remembered for giving more than for steel', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He is remembered less as the ruthless steel baron than as the man who gave a fortune away.', accent=AC),
      bg='Carnegie spent his final years, and nearly all his money, on his philanthropic mission, even setting up foundations to continue giving after him.',
      people='The foundations and trustees who carried on his giving; the public who benefited from his institutions.',
      what='Carnegie <b>died in 1919</b>, aged 83, having distributed the vast majority of his wealth. He reportedly worried he had <b>failed to give enough away</b> before the end.',
      crux='His life embodies a profound <b>double lesson</b>: the ruthless accumulation of wealth, and its equally deliberate redistribution for public good.',
      conseq='His name endures worldwide — on libraries, a concert hall, a university, and a peace endowment — far more than on the steel he made.',
      matters='How you spend a fortune can outweigh how you made it. Carnegie is remembered for the second act — the giving — as much as the first.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Andrew Carnegie rose from a penniless immigrant bobbin-boy to the richest man in the world — building the modern steel industry on relentless cost-cutting and integration — and then spent his last years giving almost all of it away, pioneering modern philanthropy. He is a study in <b>the self-made rise, focus and cost as competitive weapons, the harsh contradictions of Gilded-Age capitalism, and the idea that wealth is a trust to be repaid.</b></p>
<div class="ov-quote">“The man who dies rich dies disgraced.”<span>— Andrew Carnegie, “The Gospel of Wealth”</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A weaver’s son, ruined by machines, emigrates poor to America → climbs from bobbin-boy to telegraph operator → learns big business and investing under a railroad mentor → bets everything on steel and wins by obsessive cost control → builds the world’s dominant steel empire → stains his name at Homestead → sells to Morgan for ~$480 million and becomes the richest man alive → gives away ~90% of his fortune on libraries and learning → dies still trying to give it all away.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🪜</div><h4>Rags to riches</h4><p>The archetypal immigrant rise, from $1.20 a week to the greatest fortune of the age.</p></div>
  <div class="ov-card"><div class="i">🏭</div><h4>Cost as a weapon</h4><p>Integration and relentless cost-cutting built the modern industrial playbook.</p></div>
  <div class="ov-card"><div class="i">⚒️</div><h4>The dark side</h4><p>Homestead exposed the brutal contradictions of Gilded-Age capitalism.</p></div>
  <div class="ov-card"><div class="i">📚</div><h4>Modern philanthropy</h4><p>The Gospel of Wealth still shapes how the super-rich give today.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Bobbin Boy</b><small> 1835–53</small><p>Scottish poverty to the telegraph office.</p></div>
  <div><b>2 · The Railroad Years</b><small> 1853–72</small><p>A mentor, management, and his first investments.</p></div>
  <div><b>3 · The Steel King</b><small> 1872–92</small><p>The Bessemer bet and the cult of cost.</p></div>
  <div><b>4 · The Stain and the Sale</b><small> 1892–1901</small><p>Homestead, and the half-billion-dollar exit.</p></div>
  <div><b>5 · The Gospel of Wealth</b><small> 1889–1919</small><p>Giving away the greatest fortune of the age.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Thomas A. Scott', 'role': 'mentor', 'color': '#475569',
     'bio': 'The Pennsylvania Railroad executive who hired the young Carnegie, taught him big-business management, and started him on the path of investment that made his fortune.',
     'rel': 'The mentor who taught him how capitalism really works.'},
    {'name': 'Henry Clay Frick', 'role': 'partner / operations chief', 'color': '#7f1d1d',
     'bio': 'The hard-driving "coke king" who ran Carnegie Steel’s operations and led the brutal suppression of the Homestead strike; later he and Carnegie fell out bitterly.',
     'rel': 'The ruthless partner behind both the profits and the Homestead stain.'},
    {'name': 'J.P. Morgan', 'role': 'the buyer', 'color': '#0e7490',
     'bio': 'The most powerful financier of the age, who bought Carnegie Steel in 1901 to form U.S. Steel, the world’s first billion-dollar corporation.',
     'rel': 'The banker who bought his empire and made him the richest man alive.'},
    {'name': 'Charles Schwab', 'role': 'executive / broker', 'color': '#166534',
     'bio': 'A brilliant Carnegie Steel executive who rose from stake-driver to president and brokered the 1901 sale to Morgan.',
     'rel': 'The protégé who helped engineer the great sale.'},
    {'name': 'Margaret Carnegie', 'role': 'mother', 'color': '#b45309',
     'bio': 'Carnegie’s determined, ambitious mother, a powerful influence on his drive and values throughout his life.',
     'rel': 'The formidable mother behind his relentless ambition.'},
]

KEY_EVENTS = [
    ('1835', 'Born in Dunfermline, Scotland', 'A poor weaver’s son.'),
    ('1848', 'Emigrates to America', 'The ruined family settles near Pittsburgh.'),
    ('1848–53', 'Bobbin boy to telegrapher', 'Climbs from $1.20 a week.'),
    ('1853', 'Joins the Pennsylvania Railroad', 'Mentored by Thomas Scott; learns investing.'),
    ('1875', 'Edgar Thomson Steel Works', 'Bets everything on Bessemer steel.'),
    ('1880s', 'Carnegie Steel dominates', 'World’s largest, lowest-cost steelmaker.'),
    ('1889', 'Publishes “The Gospel of Wealth”', 'The rich as trustees of their fortunes.'),
    ('1892', 'Homestead strike', 'The union crushed; a permanent stain.'),
    ('1901', 'Sells to J.P. Morgan', '~$480M; U.S. Steel is formed.'),
    ('1889–1919', 'Gives away ~90%', '2,500 libraries, Carnegie Hall, universities.'),
    ('1919', 'Death of Carnegie', 'Dies having given the fortune away.'),
]

MASTER = [
    {'year': '1835', 'age': 'born', 'phase': 'Bobbin Boy', 'title': 'Born in Scotland', 'desc': 'A poor weaver’s son.'},
    {'year': '1848', 'age': 'age 13', 'phase': 'Bobbin Boy', 'title': 'Emigrates to America', 'desc': 'Starts at the bottom.'},
    {'year': '1853', 'age': 'age 18', 'phase': 'Railroad', 'title': 'Joins the railroad', 'desc': 'Learns business and investing.'},
    {'year': '1875', 'age': 'age 40', 'phase': 'Steel King', 'title': 'Bets on steel', 'desc': 'The Edgar Thomson works.'},
    {'year': '1889', 'age': 'age 54', 'phase': 'Gospel', 'title': 'Gospel of Wealth', 'desc': 'His philanthropic creed.'},
    {'year': '1892', 'age': 'age 57', 'phase': 'The Sale', 'title': 'Homestead strike', 'desc': 'The stain on his name.'},
    {'year': '1901', 'age': 'age 65', 'phase': 'The Sale', 'title': 'Sells to Morgan', 'desc': 'Richest man in the world.'},
    {'year': '1919', 'age': 'age 83', 'phase': 'Gospel', 'title': 'Death of Carnegie', 'desc': 'Gave away ~90%.'},
]

SOURCES = [
    ('Britannica — Andrew Carnegie', 'https://www.britannica.com/biography/Andrew-Carnegie'),
    ('U.S. Library of Congress / PBS — Carnegie', 'https://www.pbs.org/wgbh/americanexperience/films/carnegie/'),
    ('Carnegie Corporation of New York — Andrew Carnegie', 'https://www.carnegie.org/interactives/foundersstory/'),
    ('Wikipedia — Andrew Carnegie', 'https://en.wikipedia.org/wiki/Andrew_Carnegie'),
]

def build_meta():
    return {
        'pid': 'gm-carnegie.html', 'kind': 'man', 'emoji': '🏭', 'accent': AC,
        'name': 'Andrew Carnegie', 'years': '1835–1919', 'group': 'Business & Industry',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'A penniless immigrant bobbin-boy who built the modern steel industry, became the richest man in the world — and then gave almost all of it away.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · Bobbin Boy', 'type': 'timeline',
             'intro': 'Born a poor weaver’s son whose father was ruined by industrial machines, he emigrates to America and climbs from a $1.20-a-week bobbin boy to a skilled telegraph operator.', 'events': PHASE_RISE},
            {'id': 'rail', 'label': '2 · The Railroad Years', 'type': 'timeline',
             'intro': 'Under a railroad mentor he learns modern management and the life-changing lesson of investment — then strikes out on his own in iron and bridges.', 'events': PHASE_RAIL},
            {'id': 'steel', 'label': '3 · The Steel King', 'type': 'timeline',
             'intro': 'He bets everything on steel and wins through vertical integration and a fanatical obsession with cost — building the largest, cheapest steel empire in the world.', 'events': PHASE_STEEL},
            {'id': 'sale', 'label': '4 · The Stain and the Sale', 'type': 'timeline',
             'intro': 'His reputation is stained forever by the violent breaking of the Homestead strike — before he sells his empire to J.P. Morgan for a half-billion dollars and becomes the richest man alive.', 'events': PHASE_SALE},
            {'id': 'gospel', 'label': '5 · The Gospel of Wealth', 'type': 'timeline',
             'intro': 'Believing the rich are only trustees of their fortunes, he spends his last years giving almost all of his away — libraries, halls, universities and a mission for peace.', 'events': PHASE_GOSPEL,
             'sources': SOURCES, 'srcnote': 'Dollar figures (the ~$480M sale, ~$350M in giving) are the standard historical estimates; Carnegie’s own memoir is self-serving and is read critically by historians.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
