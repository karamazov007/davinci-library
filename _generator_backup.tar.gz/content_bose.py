# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Subhas Chandra Bose ("Netaji").
The militant nationalist who raised an army abroad to win India’s freedom by force."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#c2410c'  # revolutionary saffron

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING
PHASE_RISE = [
    E('origins', '1897–1921', 'The brilliant student who walked away from the Raj’s elite', ['RISE', 'TURNING POINT'],
      'Born in Cuttack in 1897, Bose is a gifted, intensely spiritual student who passes the fiercely competitive Indian Civil Service examination in England — ranking fourth — only to resign the safe, prestigious post in 1921, unwilling to serve a government he means to overthrow.',
      svg_row('Renouncing privilege for the freedom struggle', [
          {'n': 1, 'label': 'Brilliant student, born 1897', 'sub': 'Cuttack; Presidency College and Cambridge', 'color': '#c2410c'},
          {'n': 2, 'label': 'Passes the ICS, ranked 4th', 'sub': 'clears the Raj’s elite examination in England, 1920', 'color': '#a16207'},
          {'n': 3, 'label': 'Resigns the post, 1921', 'sub': 'refuses to serve a foreign government', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He threw away the most coveted career in British India to join the men trying to end British India.', accent=AC),
      bg='<b>Subhas Chandra Bose</b> was born in 1897 at Cuttack into a prosperous Bengali family, a proud and religiously intense student educated at Presidency College, Calcutta and Cambridge.',
      people='his father Janakinath Bose; the British Raj he refused to serve; the nationalist leaders he was about to join.',
      what='Bose passed the <b>Indian Civil Service examination in 1920</b>, placing fourth, then <b>resigned in 1921</b> — abandoning the most prestigious career open to an Indian rather than administer British rule.',
      crux='He chose <b>conviction over comfort</b>, judging that no honest patriot could serve the government he intended to fight.',
      conseq='Free of the ICS, he returned to India and threw himself into the Congress-led freedom movement.',
      matters='The costliest sacrifices announce the deepest commitments — Bose staked his whole future on ending the Raj.'),

    E('apprentice', '1921–1930', 'The radical apprentice — jail, and a mentor in C. R. Das', ['RISE', 'POLITICS'],
      'Bose enters the freedom struggle under the Bengali leader Chittaranjan Das, throwing himself into agitation, boycotts and civic work — and paying for it with the first of many spells in prison, where a pattern of arrest, hunger and defiance begins to define his political life.',
      svg_stack('Learning the struggle the hard way', [
          {'n': 1, 'label': 'Joins under C. R. Das', 'sub': 'Bengal’s foremost nationalist becomes his mentor', 'color': '#c2410c'},
          {'n': 2, 'label': 'Agitation and boycott', 'sub': 'non-cooperation, civic work, mass organising', 'color': '#a16207'},
          {'n': 3, 'label': 'In and out of prison', 'sub': 'repeated arrests, exile and hunger strikes', 'color': '#b91c1c'},
      ], takeaway='He served his political apprenticeship in agitation and jail cells — hardening into a leader forged by confrontation.', accent=AC),
      bg='Returning to India in 1921, Bose attached himself to <b>Chittaranjan Das</b>, the towering Bengali Congress leader, and plunged into the non-cooperation movement.',
      people='<b>C. R. Das</b>, his mentor; the Bengal Congress; the British authorities who jailed him repeatedly.',
      what='Through the 1920s Bose organised boycotts and civic work, rising in the Bengal Congress while enduring <b>repeated imprisonment and deportation</b> for his activities.',
      crux='He built his following through <b>confrontation, not compromise</b> — an activist who accepted jail as the price of the cause.',
      conseq='His energy, courage and organising skill marked him out as a coming man in the national movement.',
      matters='Movements are built by those willing to pay the price personally — Bose’s prison record was his credential.'),

    E('militant', '1930–1937', 'The militant creed — freedom must be seized, not begged', ['RISE', 'POLITICS'],
      'As Bose becomes mayor of Calcutta and a national figure, he crystallizes a conviction that divides him from Gandhi: that Britain will never simply concede independence, and that it must ultimately be won by organized force and mass power, not by moral appeal and nonviolence alone.',
      svg_compare('Two roads to independence', {
          'head': 'Gandhi’s way', 'color': '#166534',
          'items': ['Nonviolence (ahimsa) as principle', 'Moral pressure and self-suffering', 'Negotiate and compromise with the Raj', 'Change the oppressor’s heart'],
      }, {
          'head': 'Bose’s way', 'color': '#b91c1c',
          'items': ['Independence seized by force', 'Discipline, organisation, an army', 'No faith in British goodwill', 'Complete freedom, taken not granted'],
      }, verdict='Bose admired Gandhi but believed an empire yields only to power — a difference that would split them.',
         takeaway='Bose parted from Gandhi not on the goal but on the method: he thought freedom had to be taken, not petitioned for.', accent=AC),
      bg='Rising to become <b>mayor of Calcutta</b> and a national leader, Bose absorbed radical and socialist ideas and grew impatient with gradualism.',
      people='<b>Mahatma Gandhi</b>, whose creed he respected but doubted; the Congress left; India’s restless youth.',
      what='Bose came to believe that <b>independence would have to be won by organised force and mass mobilisation</b>, not by nonviolence and negotiation alone — a militant conviction that set him against Gandhi’s method.',
      crux='He held that <b>a great empire concedes only to power</b>, and that moral appeal without strength would never break the Raj.',
      conseq='This conviction would drive every later gamble — from the Congress presidency to an army raised abroad.',
      matters='Means as much as ends divide reformers — Bose and Gandhi shared the dream of freedom but split on how to seize it.'),
]

# ==================================================================  PHASE 2 — THE CONGRESS PRESIDENT
PHASE_POWER = [
    E('haripura', '1938', 'President of Congress — the vision of a modern, planned India', ['POLITICS', 'TRIUMPH'],
      'At the height of his popularity Bose is elected President of the Indian National Congress at the Haripura session — using the platform to press a bold, forward-looking programme of industrialization, national planning and uncompromising demand for complete independence.',
      svg_stack('A radical takes the Congress helm', [
          {'n': 1, 'label': 'Elected President, Haripura 1938', 'sub': 'the young radical leads the national party', 'color': '#c2410c'},
          {'n': 2, 'label': 'A programme of planning', 'sub': 'industrialisation and a National Planning Committee', 'color': '#a16207'},
          {'n': 3, 'label': 'Complete independence', 'sub': 'no dominion status; full freedom, soon', 'color': '#166534'},
      ], takeaway='At the top of the Congress he pushed a modern, industrial, uncompromising vision of a free India.', accent=AC),
      bg='By 1938 Bose was one of India’s most popular leaders. He was elected <b>President of the Indian National Congress</b> at the <b>Haripura</b> session.',
      people='the Congress rank and file who backed him; <b>Jawaharlal Nehru</b>, a fellow modernist; the Gandhian old guard.',
      what='As President from <b>Haripura (1938)</b>, Bose championed <b>industrialisation and national planning</b> (setting up a National Planning Committee) and demanded <b>complete independence</b> rather than gradual concessions.',
      crux='He used the presidency to argue that a free India must be <b>modern, industrial and self-reliant</b>, planned by the state.',
      conseq='His success emboldened him to seek a second term — the decision that would bring his clash with Gandhi to a head.',
      matters='Leaders shape a movement’s imagination — Bose gave the freedom struggle a blueprint for the modern nation to come.'),

    E('tripuri', '1939', 'Tripuri — re-elected against Gandhi, then cornered', ['POLITICS', 'TURNING POINT'],
      'Bose stands for a second term and wins re-election at Tripuri, defeating the candidate backed by Gandhi — a stunning personal triumph that curdles into crisis, as Gandhi and the Congress establishment refuse to cooperate, leaving the elected President isolated and powerless.',
      svg_row('A victory that becomes a trap', [
          {'n': 1, 'label': 'Stands for re-election, 1939', 'sub': 'against Gandhi’s wishes', 'color': '#c2410c'},
          {'n': 2, 'label': 'Defeats Sitaramayya at Tripuri', 'sub': 'beats the Gandhi-backed candidate', 'color': '#166534'},
          {'n': 3, 'label': 'The old guard withholds support', 'sub': 'the Working Committee resigns; he is isolated', 'color': '#b91c1c'},
      ], edge_labels=['but', 'and'], takeaway='He won the election and lost the party — a triumph that left him president in name only.', accent=AC),
      bg='Seeking a second term, Bose ran against <b>Pattabhi Sitaramayya</b>, whom Gandhi openly supported, at the <b>Tripuri</b> session of 1939.',
      people='<b>Mahatma Gandhi</b>, whose candidate he beat; Pattabhi Sitaramayya, the defeated rival; the Congress Working Committee that abandoned Bose.',
      what='Bose <b>won re-election at Tripuri (1939)</b>, defeating Gandhi’s candidate — but Gandhi called it a personal defeat, and the Congress establishment refused to work with Bose, leaving him <b>isolated and unable to govern the party</b>.',
      crux='His electoral win collided with the <b>reality of Gandhi’s moral authority</b> — without the old guard, the presidency was hollow.',
      conseq='Unable to lead a party that would not follow him, Bose resigned the presidency within months.',
      matters='Formal power is not the same as real authority — Bose held the office but not the party that gave it meaning.'),

    E('forwardbloc', '1939–1940', 'Resignation and the Forward Bloc — breaking with the Congress', ['POLITICS', 'TRAGEDY'],
      'Boxed in, Bose resigns the Congress presidency and founds the Forward Bloc to rally the militant, left-leaning forces within the movement — but with war breaking out and his agitation intensifying, the British place him under arrest and then house arrest in Calcutta.',
      svg_stack('A militant faction, then a cage', [
          {'n': 1, 'label': 'Resigns the presidency, 1939', 'sub': 'unable to lead a party set against him', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Founds the Forward Bloc', 'sub': 'rallies the radical, socialist wing', 'color': '#c2410c'},
          {'n': 3, 'label': 'Arrest and house arrest', 'sub': 'jailed, then confined at his Calcutta home, 1940', 'color': '#78350f'},
      ], takeaway='Cut off inside the Congress, he built his own militant vehicle — and the Raj promptly locked him up.', accent=AC),
      bg='Unable to work with the Gandhian leadership, Bose <b>resigned the Congress presidency</b> in 1939 and looked to organise the movement’s radical wing.',
      people='the leftists and militants who rallied to him; the Congress high command he broke from; the British authorities.',
      what='Bose founded the <b>Forward Bloc (1939)</b> to unite the radical left, and with the Second World War underway he intensified anti-British agitation — leading the British to arrest him and place him under <b>house arrest in Calcutta</b>.',
      crux='He gambled on <b>a militant faction outside the Gandhian mainstream</b> — and became too dangerous for the Raj to leave free.',
      conseq='Confined and watched, Bose resolved on a desperate plan: to escape India and seek foreign help against Britain.',
      matters='When the door closes at home, the determined look abroad — house arrest set the stage for his most audacious act.'),
]

# ==================================================================  PHASE 3 — THE GREAT ESCAPE
PHASE_ORDER = [
    E('escape', '1941', 'The Great Escape — Calcutta to Berlin in disguise', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'In one of the most daring episodes of the freedom struggle, Bose slips out of house arrest in Calcutta in January 1941, travels in disguise across India to the North-West Frontier, crosses Afghanistan, and makes his way through the Soviet Union to Nazi Germany in search of allies against Britain.',
      svg_row('A fugitive’s journey to the enemies of his enemy', [
          {'n': 1, 'label': 'Escapes Calcutta, Jan 1941', 'sub': 'slips house arrest disguised as a Pathan', 'color': '#c2410c'},
          {'n': 2, 'label': 'Across Afghanistan', 'sub': 'reaches Kabul via the North-West Frontier', 'color': '#a16207'},
          {'n': 3, 'label': 'Onward to Germany', 'sub': 'through the USSR to Berlin, April 1941', 'color': '#3730a3'},
      ], edge_labels=['then', 'to'], takeaway='He vanished from a guarded house in Calcutta and reappeared in Berlin — an escape of astonishing nerve.', accent=AC),
      bg='Under house arrest in Calcutta and determined to fight on, Bose planned a secret flight from India to seek the help of Britain’s wartime enemies.',
      people='his nephew Sisir Bose, who drove him from the house; the Frontier and Afghan contacts who smuggled him; the Axis powers ahead.',
      what='In <b>January 1941</b> Bose escaped house arrest in disguise, travelled to the North-West Frontier, crossed into <b>Afghanistan (Kabul)</b>, and journeyed via the Soviet Union to <b>Germany, arriving in April 1941</b>.',
      crux='He acted on the maxim that <b>the enemy of my enemy is my ally</b> — seeking Axis support to strike at British India.',
      conseq='In Berlin he began building an Indian force from prisoners of war and broadcasting to India — but Europe proved the wrong theatre.',
      matters='Desperate causes drive audacious means — Bose’s escape showed the lengths he would go to for independence.'),

    E('germany', '1941–1943', 'Seeking Axis help — the difficult bargain in Berlin', ['POLITICS'],
      'In Germany Bose sets up the Free India Centre, raises the Indian Legion from captured Indian soldiers, broadcasts anti-British radio, and wins the honorific "Netaji" — but Hitler shows little real interest in Indian freedom, and Bose grows convinced that his true theatre lies in Asia, close to India’s borders.',
      svg_stack('A controversial alliance, coldly judged', [
          {'n': 1, 'label': 'Free India Centre & Legion', 'sub': 'raises an Indian force from POWs; the name “Netaji”', 'color': '#c2410c'},
          {'n': 2, 'label': 'Radio war on the Raj', 'sub': 'broadcasts to India from Berlin', 'color': '#a16207'},
          {'n': 3, 'label': 'Hitler proves indifferent', 'sub': 'no real German commitment to Indian freedom', 'color': '#3730a3'},
      ], takeaway='He took help where he could find it, but Nazi Germany offered words, not a road to Delhi — so he looked east.', accent=AC),
      bg='In wartime Berlin, Bose sought to enlist Axis power against Britain, working with the German government and Italian and Japanese contacts.',
      people='<b>Adolf Hitler</b>, whom he met but could not move; the Indian POWs of the Legion; the Japanese, who beckoned from Asia.',
      what='Bose founded the <b>Free India Centre</b>, raised the <b>Indian Legion</b> from captured Indian soldiers, broadcast propaganda, and was hailed as <b>“Netaji.”</b> But he found <b>Hitler indifferent to Indian independence</b> and Europe far from the fight.',
      crux='He judged the Axis coldly as a <b>means, not a cause</b> — willing to deal with tyrannies abroad to end tyranny at home, yet finding Germany unwilling to help.',
      conseq='Convinced Asia was the decisive theatre, Bose resolved to reach Japanese-held Southeast Asia, near India’s frontiers.',
      matters='Alliances of convenience are fraught and often barren — Bose’s German bargain gained a title and a legion, but no path to India.'),

    E('submarine', '1943', 'Half the world by submarine — Germany to Southeast Asia', ['POLITICS', 'TURNING POINT'],
      'To reach the Asian front Bose undertakes an extraordinary secret voyage — sailing from Germany by U-boat, transferring at sea to a Japanese submarine near Madagascar, and arriving in Japanese-occupied Southeast Asia in 1943 to take up the cause of Indian freedom in the theatre that borders India itself.',
      svg_row('An underwater passage between two war fronts', [
          {'n': 1, 'label': 'Leaves Germany by U-boat, 1943', 'sub': 'departs the European theatre for Asia', 'color': '#3730a3'},
          {'n': 2, 'label': 'Transfer at sea', 'sub': 'switches to a Japanese submarine near Madagascar', 'color': '#a16207'},
          {'n': 3, 'label': 'Arrives in Southeast Asia', 'sub': 'reaches Japanese-held territory near India', 'color': '#166534'},
      ], edge_labels=['then', 'to'], takeaway='One of the war’s few civilian submarine transfers carried him from a spent front to the theatre that mattered.', accent=AC),
      bg='Persuaded that only from Asia could India be liberated, Bose arranged a dangerous transfer from the German to the Japanese sphere.',
      people='the German and Japanese submarine crews; the Japanese command that would host him; the Indian expatriates of Southeast Asia awaiting a leader.',
      what='In 1943 Bose sailed from Germany by <b>German U-boat</b>, transferred at sea to a <b>Japanese submarine near Madagascar</b>, and reached <b>Japanese-occupied Southeast Asia</b> — a voyage of some 90 days across half the globe.',
      crux='He went to <b>where the fight could actually reach India</b> — trading a stalled European effort for the border theatre of the east.',
      conseq='In Southeast Asia he took command of a ready-made movement of Indian soldiers and expatriates: the Indian National Army.',
      matters='Strategy is choosing the decisive point — Bose crossed the world to fight where victory could touch Indian soil.'),
]

# ==================================================================  PHASE 4 — AZAD HIND
PHASE_REPRESSION = [
    E('ina', '1943', 'Commander of the Indian National Army', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'In Singapore, Bose takes supreme command of the Indian National Army (Azad Hind Fauj) — a force first raised from Indian prisoners of war under Japanese auspices — and, with electrifying leadership, revives and expands it into a disciplined army pledged to march on India and end British rule.',
      svg_stack('An army of exiles and prisoners, reborn', [
          {'n': 1, 'label': 'INA first raised, 1942', 'sub': 'Mohan Singh forms it from Indian POWs', 'color': '#a16207'},
          {'n': 2, 'label': 'Bose takes command, 1943', 'sub': 'assumes leadership in Singapore', 'color': '#c2410c'},
          {'n': 3, 'label': 'A revived Azad Hind Fauj', 'sub': 'disciplined, expanded, pledged to free India', 'color': '#166534'},
      ], takeaway='He inherited a struggling army of prisoners and expatriates and turned it into a genuine liberation force.', accent=AC),
      bg='The <b>Indian National Army (Azad Hind Fauj)</b> had first been raised in 1942 from Indian POWs by Captain <b>Mohan Singh</b>, with Japanese support, but had faltered.',
      people='<b>Rash Behari Bose</b>, who handed him the Indian Independence League; Mohan Singh, the INA’s first commander; the Indian POWs and Southeast-Asian expatriates.',
      what='In <b>1943</b> Bose took <b>supreme command of the INA</b> in Singapore, reviving and enlarging it into a disciplined army of tens of thousands, drawn from prisoners of war and the Indian diaspora of Southeast Asia.',
      crux='His personal magnetism <b>transformed a demoralised force into a committed army</b> — men now fighting for a leader they believed in.',
      conseq='With an army in hand, Bose moved to give it a state — proclaiming a government of free India.',
      matters='Armies run on belief as much as arms — Bose’s gift was to make exiled soldiers feel they were liberating a nation.'),

    E('provisional', '1943', 'The Provisional Government — “Give me blood, and I will give you freedom”', ['POLITICS', 'TRIUMPH'],
      'Bose proclaims the Provisional Government of Free India (Azad Hind), recognized by the Axis powers, and rallies his movement with the war-cries "Chalo Delhi" — On to Delhi — and "Give me blood, and I will give you freedom," fusing soldiers and expatriates into a nation-in-exile.',
      svg_row('A government and a rallying cry', [
          {'n': 1, 'label': 'Provisional Government, Oct 1943', 'sub': 'Azad Hind proclaimed at Singapore', 'color': '#c2410c'},
          {'n': 2, 'label': '“Chalo Delhi!”', 'sub': 'On to Delhi — the march is declared', 'color': '#b91c1c'},
          {'n': 3, 'label': '“Give me blood…”', 'sub': '“…and I will give you freedom”', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='He gave the movement a state, a slogan and a promise of sacrifice — the machinery and the myth of a free India.', accent=AC),
      bg='With the INA under his command, Bose sought to give free India a government and a cause its soldiers could die for.',
      people='the Axis governments that recognised Azad Hind; the soldiers and expatriates who swore allegiance; the millions of Indians he addressed by radio.',
      what='On <b>21 October 1943</b> Bose proclaimed the <b>Provisional Government of Free India (Azad Hind)</b> at Singapore — recognised by several Axis states — and roused his followers with <b>“Chalo Delhi”</b> and the immortal <b>“Give me blood, and I will give you freedom.”</b>',
      crux='He understood that a movement needs <b>a state, a symbol and a demand for sacrifice</b> — and gave Azad Hind all three.',
      conseq='The Provisional Government issued its own stamps and currency and declared war on Britain, and prepared to march.',
      matters='Words can forge a nation — Bose’s slogans still echo, giving his failed campaign an enduring hold on India’s imagination.'),

    E('ranijhansi', '1943–1944', 'The Rani of Jhansi Regiment — women under arms', ['POLITICS', 'REFORM'],
      'Among Bose’s boldest innovations is the Rani of Jhansi Regiment — an all-women combat unit, extraordinary for its time and place — drawing women of the Indian diaspora into military service and giving flesh to his belief that the whole nation, women included, must fight for its freedom.',
      svg_stack('A women’s regiment for a national war', [
          {'n': 1, 'label': 'An all-women combat unit', 'sub': 'named for the warrior queen of Jhansi', 'color': '#c2410c'},
          {'n': 2, 'label': 'Led by Capt. Lakshmi', 'sub': 'Lakshmi Swaminathan (Sahgal) commands', 'color': '#a16207'},
          {'n': 3, 'label': 'The whole nation in arms', 'sub': 'women of the diaspora enlist to fight', 'color': '#166534'},
      ], takeaway='He put women in uniform as combatants — a radical assertion that freedom was the whole nation’s fight.', accent=AC),
      bg='Bose believed the struggle demanded the energies of every Indian, and moved to enlist women directly into the armed struggle.',
      people='<b>Captain Lakshmi Swaminathan (Sahgal)</b>, its commander; the women of the Southeast-Asian Indian diaspora who volunteered; the queen of Jhansi, its namesake.',
      what='Bose founded the <b>Rani of Jhansi Regiment</b>, an <b>all-women combat regiment</b> of the INA — remarkable for the 1940s — commanded by <b>Lakshmi Sahgal</b> and drawn from the Indian communities of Southeast Asia.',
      crux='He treated <b>the liberation of India as the task of the whole people</b>, women bearing arms alongside men.',
      conseq='The regiment became a lasting emblem of the INA’s radical, egalitarian spirit, even as the military campaign faltered.',
      matters='Symbols outlive campaigns — a women’s combat regiment in the 1940s marked Bose’s vision of an inclusive national struggle.'),
]

# ==================================================================  PHASE 5 — THE MARCH AND THE END
PHASE_END = [
    E('imphal', '1944', 'Chalo Delhi — the march on India, and its failure', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'The INA advances with Japanese forces toward India, crossing the frontier and planting the flag on Indian soil at Moirang — but the great offensive against Imphal and Kohima stalls against fierce British and Indian resistance, monsoon, disease and collapsing supply lines, and the dream of marching to Delhi dies at the border.',
      svg_row('The offensive that reached India — and broke', [
          {'n': 1, 'label': 'Advance with Japan, 1944', 'sub': 'the flag raised on Indian soil at Moirang', 'color': '#c2410c'},
          {'n': 2, 'label': 'Imphal and Kohima', 'sub': 'the offensive stalls against fierce defence', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The march collapses', 'sub': 'monsoon, hunger, disease, broken supply', 'color': '#78350f'},
      ], edge_labels=['at', 'then'], takeaway='The INA reached Indian soil but could not break through — the battles of Imphal and Kohima ended the dream of Delhi.', accent=AC),
      bg='In 1944 the INA joined the Japanese offensive toward north-east India, aiming to breach the frontier and spark a rising against the Raj.',
      people='the INA and Japanese soldiers of the offensive; the British and Indian troops who held Imphal and Kohima; the villagers of Moirang, where the flag was first raised.',
      what='INA forces crossed into India and <b>raised the flag at Moirang, Manipur</b>, but the <b>Imphal–Kohima offensive (1944)</b> collapsed against determined defence, the monsoon, disease and failed supply — the campaign’s decisive defeat.',
      crux='The offensive foundered on <b>logistics and firepower</b> — courage could not overcome hunger, disease and a well-supplied enemy.',
      conseq='The broken campaign began the INA’s long retreat, and with Japan itself failing, the cause lost its base.',
      matters='Will alone does not win wars — the INA’s furthest advance exposed the gulf between a movement’s spirit and its means.'),

    E('retreat', '1944–1945', 'Retreat and collapse — the cause loses its ground', ['BATTLE', 'DEFEAT', 'TRAGEDY'],
      'As the Imphal offensive fails, the INA falls back through Burma in a punishing retreat, its ranks thinned by battle, hunger and disease — and with Japan itself facing defeat in 1945, the base that made Azad Hind possible crumbles beneath Bose’s feet.',
      svg_stack('An army worn down as its patron falls', [
          {'n': 1, 'label': 'The long retreat', 'sub': 'the INA falls back through Burma', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Ranks broken', 'sub': 'losses to battle, hunger and disease', 'color': '#78350f'},
          {'n': 3, 'label': 'Japan collapses, 1945', 'sub': 'the Axis base for Azad Hind falls away', 'color': '#3730a3'},
      ], takeaway='Tied to a losing power, the INA could not survive Japan’s defeat — the retreat became a collapse.', accent=AC),
      bg='After Imphal, the INA and its Japanese allies were pushed back across Burma while the wider war turned decisively against the Axis.',
      people='the retreating INA soldiers; the failing Japanese command; Bose, still rallying a cause running out of ground.',
      what='Through <b>1944–45</b> the INA <b>retreated through Burma</b>, its strength drained by combat, starvation and disease, and with <b>Japan nearing surrender</b> the whole basis of the Provisional Government dissolved.',
      crux='Azad Hind’s fatal weakness was <b>dependence on a collapsing patron</b> — when Japan fell, Bose’s enterprise had no foundation left.',
      conseq='With his army broken and his ally beaten, Bose sought to reach friendly territory as the war ended — his final journey.',
      matters='A cause tethered to another’s power shares that power’s fate — the INA rose and fell with Japan’s war.'),

    E('death', '1945', 'Death in Taiwan — and the debate that never ended', ['DEATH', 'TRAGEDY'],
      'In August 1945, as the war ends, Bose is reported to have died of burns from a plane crash in Taiwan — an account officially accepted but never fully believed by many Indians, spawning enduring rumours, inquiries and legends, and leaving Netaji a martyr whose end remains among modern India’s most debated mysteries.',
      svg_compare('One death, two stories', {
          'head': 'The official account', 'color': '#78350f',
          'items': ['Plane crash at Taihoku, Taiwan', 'Died of burns, 18 August 1945', 'Confirmed by later inquiries', 'The accepted historical record'],
      }, {
          'head': 'The persistent doubt', 'color': '#b91c1c',
          'items': ['Many refused to believe he died', 'Rumours he survived in secret', 'Repeated commissions and petitions', 'A mystery still argued in India'],
      }, verdict='Most historians accept the 1945 crash; yet doubt endures, keeping Netaji’s end a national controversy.',
         takeaway='Whether one accepts the crash or not, Bose passed into legend — a martyr whose death India could not quite let go.', accent=AC),
      bg='With Japan surrendering, Bose tried to reach territory beyond British reach. He is reported to have boarded an overloaded aircraft that crashed on take-off.',
      people='the Japanese officers who accompanied him; the later commissions of inquiry; the millions of Indians who mourned and doubted.',
      what='Bose is reported to have <b>died on 18 August 1945 of burns</b> after a <b>plane crash at Taihoku (Taipei), Taiwan</b>. Though official inquiries accepted this, <b>many Indians never did</b>, and rival theories about his fate persist to this day.',
      crux='His end became <b>as contested as his life</b> — a documented crash shadowed by an enduring refusal to believe he was gone.',
      conseq='In death Bose became a martyr; the postwar INA trials in Delhi ignited mass sympathy and hastened the pressure that ended the Raj.',
      matters='Some figures loom larger in death than life — Bose’s disputed end sealed his place as an undying symbol of defiant patriotism.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Subhas Chandra Bose — “Netaji” — was the militant conscience of India’s freedom struggle, the man who believed independence had to be seized by force rather than won by moral appeal alone. A brilliant student who threw away an elite Civil Service career, he rose to lead the Congress twice before breaking with Gandhi, escaped British house arrest in an epic flight across Asia, and raised the Indian National Army abroad to march on India. His campaign failed and his death in 1945 remains disputed, but he stands as the enduring study in <b>uncompromising nationalism, the ethics of allying with tyrants against tyranny, and the power of sacrifice as a rallying idea.</b></p>
<div class="ov-quote">“Give me blood, and I will give you freedom.”<span>— Subhas Chandra Bose</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A gifted student resigns the elite Indian Civil Service to fight the Raj → rises through jail and agitation into a militant creed of force over nonviolence → leads the Congress twice, then breaks with Gandhi at Tripuri → escapes house arrest across Afghanistan to Germany → sails by submarine to Southeast Asia → takes command of the Indian National Army and proclaims the Provisional Government of Free India → marches on Imphal and fails → and dies in a disputed 1945 plane crash, passing into legend.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🔥</div><h4>Freedom by force</h4><p>Insisted an empire yields only to power, not petition.</p></div>
  <div class="ov-card"><div class="i">🎖️</div><h4>An army abroad</h4><p>Raised the INA and a government-in-exile to fight for India.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>The Axis question</h4><p>Allied with tyrannies against the Raj — a choice still debated.</p></div>
  <div class="ov-card"><div class="i">🕊️</div><h4>Martyr and myth</h4><p>His sacrifice and disputed death made him an undying symbol.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Making</b><small> 1897–1937</small><p>ICS renounced; jail; the militant creed.</p></div>
  <div><b>2 · Congress President</b><small> 1938–1940</small><p>Haripura, Tripuri, and the break with Gandhi.</p></div>
  <div><b>3 · The Great Escape</b><small> 1941–1943</small><p>Calcutta to Berlin; the submarine to Asia.</p></div>
  <div><b>4 · Azad Hind</b><small> 1943–1944</small><p>The INA, the Provisional Government, the Rani of Jhansi.</p></div>
  <div><b>5 · The March & the End</b><small> 1944–1945</small><p>Imphal, retreat, and a disputed death.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Mahatma Gandhi', 'role': 'rival and elder', 'color': '#166534',
     'bio': 'The apostle of nonviolence whose method Bose respected but rejected; their clash at Tripuri in 1939 drove Bose from the Congress.',
     'rel': 'The moral rival over means — nonviolence versus force.'},
    {'name': 'Jawaharlal Nehru', 'role': 'Congress contemporary', 'color': '#c2410c',
     'bio': 'The modernist Congress leader who shared Bose’s socialism and vision of a planned India, but stayed loyal to Gandhi and the mainstream.',
     'rel': 'A fellow radical who chose the Gandhian path.'},
    {'name': 'Chittaranjan Das', 'role': 'mentor', 'color': '#a16207',
     'bio': 'The revered Bengali nationalist under whom Bose began his political life in the 1920s, shaping his early career.',
     'rel': 'The mentor who launched him into the struggle.'},
    {'name': 'Lakshmi Sahgal', 'role': 'INA officer', 'color': '#b91c1c',
     'bio': 'The doctor who commanded the all-women Rani of Jhansi Regiment, embodying Bose’s call for the whole nation to bear arms.',
     'rel': 'Commander of his women’s combat regiment.'},
    {'name': 'Rash Behari Bose', 'role': 'INA founder-elder', 'color': '#3730a3',
     'bio': 'The veteran revolutionary in exile who built the Indian Independence League and INA in Southeast Asia and handed leadership to Bose in 1943.',
     'rel': 'The elder who passed him the INA and the League.'},
]

KEY_EVENTS = [
    ('1897', 'Bose born at Cuttack', 'A gifted, intensely patriotic student.'),
    ('1920', 'Passes the ICS', 'Ranks fourth in the elite examination.'),
    ('1921', 'Resigns the ICS', 'Renounces the Raj’s service for the struggle.'),
    ('1938', 'Congress President, Haripura', 'A radical leads the national party.'),
    ('1939', 'Re-elected at Tripuri; resigns', 'Beats Gandhi’s candidate, then breaks away.'),
    ('1941', 'The Great Escape', 'Flees house arrest via Afghanistan to Germany.'),
    ('1943', 'Commands the INA; Azad Hind', 'Provisional Government of Free India proclaimed.'),
    ('1944', 'Imphal–Kohima campaign', 'The march on India fails at the border.'),
    ('1945', 'Death in Taiwan', 'Reported plane crash; still debated.'),
]

MASTER = [
    {'year': '1897', 'age': 'born', 'phase': 'The Making', 'title': 'Born at Cuttack', 'desc': 'A gifted, patriotic student.'},
    {'year': '1921', 'age': 'age 24', 'phase': 'The Making', 'title': 'Resigns the ICS', 'desc': 'Joins the freedom struggle.'},
    {'year': '1938', 'age': 'age 41', 'phase': 'Congress President', 'title': 'Elected at Haripura', 'desc': 'Leads the Congress.'},
    {'year': '1941', 'age': 'age 44', 'phase': 'The Great Escape', 'title': 'Escape to Germany', 'desc': 'Seeks Axis help.'},
    {'year': '1943', 'age': 'age 46', 'phase': 'Azad Hind', 'title': 'INA & Free India', 'desc': 'Commands an army abroad.'},
    {'year': '1945', 'age': 'age 48', 'phase': 'The End', 'title': 'Death in Taiwan', 'desc': 'A disputed plane crash.'},
]

SOURCES = [
    ('Britannica — Subhas Chandra Bose', 'https://www.britannica.com/biography/Subhas-Chandra-Bose'),
    ('Britannica — Indian National Army', 'https://www.britannica.com/topic/Indian-National-Army'),
    ('National Library Board Singapore — Subhas Chandra Bose', 'https://www.nlb.gov.sg/main/article-detail?cmsuuid=f35c76fb-68ac-47ee-af04-0d174740a3c4'),
    ('Wikipedia — Subhas Chandra Bose', 'https://en.wikipedia.org/wiki/Subhas_Chandra_Bose'),
    ('Wikipedia — Indian National Army', 'https://en.wikipedia.org/wiki/Indian_National_Army'),
]

def build_meta():
    return {
        'pid': 'gm-bose.html', 'kind': 'man', 'emoji': '🔥', 'accent': AC,
        'name': 'Subhas Chandra Bose', 'years': '1897–1945', 'group': 'Independence & Nation-Building',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The militant nationalist who renounced an elite career, broke with Gandhi over the ethics of force, and raised an army abroad — the Indian National Army — to seize India’s freedom by the sword.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Making', 'type': 'timeline',
             'intro': 'A brilliant student renounces the elite Indian Civil Service, serves an apprenticeship in agitation and jail, and hardens into a militant who believes freedom must be seized by force, not begged.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · Congress President', 'type': 'timeline',
             'intro': 'He leads the Congress twice, from Haripura to Tripuri, defeating Gandhi’s candidate — then, isolated by the old guard, resigns and founds the Forward Bloc, only to be placed under house arrest.', 'events': PHASE_POWER},
            {'id': 'order', 'label': '3 · The Great Escape', 'type': 'timeline',
             'intro': 'He slips British house arrest in Calcutta, crosses Afghanistan to Nazi Germany in search of allies, and — finding Hitler indifferent — sails by submarine across half the world to the Asian front.', 'events': PHASE_ORDER},
            {'id': 'repression', 'label': '4 · Azad Hind', 'type': 'timeline',
             'intro': 'In Southeast Asia he takes command of the Indian National Army, proclaims the Provisional Government of Free India, and rallies soldiers and women alike with “Chalo Delhi” and a promise of blood for freedom.', 'events': PHASE_REPRESSION},
            {'id': 'end', 'label': '5 · The March & the End', 'type': 'timeline',
             'intro': 'The INA marches on India and raises the flag on Indian soil, but the Imphal offensive fails; the army retreats as Japan collapses, and Bose meets a disputed death in a 1945 plane crash — passing into legend.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; the circumstances of Bose’s 1945 death remain contested, and his Axis alliance is presented here as the pragmatic, controversial choice it was.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
