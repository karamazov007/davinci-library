# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Antoine-Henri Jomini.
The Swiss banker turned theorist who tried to reduce war to a science of principles."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#155e75'  # campaign-map teal

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE BANKER TURNED SOLDIER
PHASE_RISE = [
    E('origins', '1779–1798', 'From bank ledger to battlefield — a Swiss clerk chooses war', ['RISE', 'ORIGINS'],
      'Born into a Swiss merchant family and steered into finance, the young Jomini works as a banker and stockbroker in Paris — but finds the counting-house unbearable, devours military history, and resolves to make war, not money, his life’s study.',
      svg_row('A banker abandons the ledger for the sword', [
          {'n': 1, 'label': 'Born in Payerne, 1779', 'sub': 'a Swiss merchant family in the Vaud', 'color': '#155e75'},
          {'n': 2, 'label': 'A young banker in Paris', 'sub': 'stockbroker in the finance houses of the 1790s', 'color': '#a16207'},
          {'n': 3, 'label': 'Quits “the tedious life of a banker”', 'sub': 'craves military glory instead', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='A restless clerk who found ledgers intolerable turned instead to the study of war — and never looked back.', accent=AC),
      bg='<b>Antoine-Henri Jomini</b> was born in 1779 at Payerne in the Swiss canton of Vaud, into a comfortable merchant family that pushed him toward commerce.',
      people='his commercially minded family; the Paris banking houses that employed him; the soldiers whose campaigns he read about.',
      what='Sent to business school and then to banks in Basel and <b>Paris</b>, Jomini worked as a clerk and stockbroker, but grew obsessed with military affairs and abandoned finance for the study of war.',
      crux='He rejected a settled, prosperous career for an uncertain one — driven by a conviction that <b>war could be studied and mastered like a science</b>.',
      conseq='With no formal military schooling, he set out to teach himself strategy from the campaigns of the great captains.',
      matters='A self-taught outsider can reshape a field — Jomini came to military theory not through the army but through obsessive reading.'),

    E('warministry', '1798–1804', 'Self-taught in the war ministry — decoding Frederick and Napoleon', ['RISE', 'IDEAS'],
      'Seizing the chaos of revolutionary Switzerland, Jomini talks his way into the Helvetic war ministry, then pores over the campaigns of Frederick the Great and the young Napoleon — convinced that beneath every victory lie a few timeless, discoverable principles, which he begins to set down in a treatise.',
      svg_stack('A clerk teaches himself the science of war', [
          {'n': 1, 'label': 'Secretary in the Helvetic war ministry', 'sub': 'wins a captaincy in the new Swiss republic, 1798', 'color': '#155e75'},
          {'n': 2, 'label': 'Dissects the great captains', 'sub': 'studies Frederick the Great and Napoleon', 'color': '#a16207'},
          {'n': 3, 'label': 'Begins a treatise on strategy', 'sub': 'hunts the timeless principles behind victory', 'color': '#166534'},
      ], takeaway='He mined history for a hidden order — the belief that all great victories obey the same few rules became his life’s thesis.', accent=AC),
      bg='The founding of the Helvetic Republic in 1798 let Jomini enter the Swiss war ministry, where he reorganised operations and rose to major.',
      people='<b>Frederick the Great</b> and <b>Napoleon</b>, whose campaigns he studied; the officials of the Helvetic Republic.',
      what='In the war ministry and after, Jomini analysed the <b>campaigns of Frederick the Great and Napoleon</b>, convinced that their successes revealed <b>a few unchanging principles of strategy</b>, which he began to codify in writing.',
      crux='He sought to distil war into a <b>rational, teachable system</b> — the geometric, scientific approach that would define all his work.',
      conseq='The manuscript he produced would soon catch the eye of one of Napoleon’s marshals.',
      matters='The idea that war has laws as fixed as geometry is Jomini’s signature — and the ground of his lifelong quarrel with Clausewitz.'),

    E('ney', '1804–1805', 'Marshal Ney’s patron and staff officer at Ulm', ['RISE', 'TURNING POINT'],
      'Marshal Michel Ney reads Jomini’s manuscript, is dazzled, and pays to have it published — launching the unknown Swiss theorist into the Grande Armée, where he becomes a colonel on Ney’s staff and witnesses Napoleon trap an entire Austrian army at Ulm.',
      svg_row('A marshal adopts the unknown theorist', [
          {'n': 1, 'label': 'Ney reads the manuscript', 'sub': 'the marshal funds its publication', 'color': '#155e75'},
          {'n': 2, 'label': 'Colonel on Ney’s staff', 'sub': 'joins the Grande Armée, 1805', 'color': '#a16207'},
          {'n': 3, 'label': 'Baptism at Ulm', 'sub': 'watches Napoleon trap an army by manoeuvre', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='A single admiring reader — a marshal of France — carried the outsider straight into Napoleon’s war machine.', accent=AC),
      bg='By 1804 Jomini had a manuscript on grand operations but no patron. Marshal <b>Michel Ney</b> read it and was deeply impressed.',
      people='Marshal <b>Michel Ney</b>, his patron; <b>Napoleon</b>, whose campaign he now watched; the Grande Armée he joined.',
      what='Ney <b>subsidised the publication</b> of Jomini’s treatise and took him onto his staff. Commissioned a <b>colonel</b>, Jomini served in the <b>1805 campaign</b> and witnessed the encirclement of an Austrian army at <b>Ulm</b>.',
      crux='A theorist became a practitioner — Jomini could now test his principles against Napoleon’s campaigns <b>at first hand</b>.',
      conseq='He had entered the inner machinery of the greatest army of the age, with a marshal for a patron.',
      matters='Ideas need patrons — Ney’s patronage turned a self-taught clerk into a staff officer at the summit of European war.'),
]

# ==================================================================  PHASE 2 — WITH THE GRANDE ARMÉE
PHASE_POWER = [
    E('campaigns', '1806–1807', 'Jena, Eylau and Napoleon’s headquarters', ['BATTLE', 'POLITICS'],
      'Jomini serves through Napoleon’s greatest campaigns — attached to the emperor’s own headquarters at Jena and through the carnage of Eylau — winning the Legion of Honour, the rank of baron, and appointment as chief of staff to Marshal Ney.',
      svg_stack('Rising at the emperor’s side', [
          {'n': 1, 'label': 'At Jena, 1806', 'sub': 'attached to Napoleon’s headquarters', 'color': '#155e75'},
          {'n': 2, 'label': 'Bloody Eylau, 1807', 'sub': 'earns the Legion of Honour', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Chief of staff to Ney, made baron', 'sub': 'after the Peace of Tilsit', 'color': '#166534'},
      ], takeaway='He rose through the campaigns he would later theorise — living the Napoleonic warfare he sought to reduce to rules.', accent=AC),
      bg='In 1806–07 Napoleon crushed Prussia and fought Russia to a standstill. Jomini served through these campaigns close to the emperor.',
      people='<b>Napoleon</b>, at whose headquarters he served; Marshal <b>Ney</b>, whose chief of staff he became; the Prussian and Russian armies.',
      what='Jomini was present at <b>Jena (1806)</b> and the brutal winter battle of <b>Eylau (1807)</b>, earning the <b>Legion of Honour</b>, the title of <b>baron</b>, and appointment as <b>chief of staff to Ney</b>.',
      crux='He watched the Napoleonic method — <b>rapid manoeuvre and concentration at the decisive point</b> — succeed again and again, confirming his theory.',
      conseq='His reputation as both soldier and theorist now stood high in the Grande Armée.',
      matters='Jomini’s principles were drawn from lived experience — he theorised the very campaigns he had helped to fight.'),

    E('treatise', '1805–1810', 'The Traité de grande tactique — campaigns become doctrine', ['IDEAS', 'REFORM'],
      'Across a decade Jomini publishes his great treatise on grand operations, turning the campaigns of Frederick and Napoleon into a systematic doctrine of strategy — a work quickly translated and argued over by every general staff in Europe.',
      svg_row('Turning campaigns into principles', [
          {'n': 1, 'label': 'Traité de grande tactique', 'sub': 'his treatise on grand operations, 1804–10', 'color': '#155e75'},
          {'n': 2, 'label': 'Frederick and Napoleon dissected', 'sub': 'their campaigns distilled into rules', 'color': '#a16207'},
          {'n': 3, 'label': 'Read by every European staff', 'sub': 'quickly translated and widely debated', 'color': '#166534'},
      ], edge_labels=['from', 'to'], takeaway='He converted the raw history of war into a teachable doctrine — the first modern attempt at a systematic strategy.', accent=AC),
      bg='Jomini’s <b>Traité de grande tactique / Treatise on Grand Military Operations</b> appeared in volumes between 1804 and 1810.',
      people='the readers and staff officers across Europe; <b>Frederick</b> and <b>Napoleon</b>, his case studies; rival theorists.',
      what='The <b>Traité</b> analysed the campaigns of Frederick the Great and Napoleon to extract <b>general principles of strategy and grand tactics</b> — one of the first systematic treatments of the subject — and was translated and discussed across the continent.',
      crux='He argued that a handful of principles — <b>lines of operation, interior lines, the decisive point</b> — governed all successful war.',
      conseq='The work made Jomini the foremost interpreter of the Napoleonic art of war.',
      matters='Jomini gave armies a vocabulary — lines of operation, the decisive point — that professional staffs still use today.'),

    E('friction', '1808–1813', 'Feuds with Ney and Berthier — a career blocked', ['POLITICS', 'TRAGEDY'],
      'For all his brilliance, Jomini is a prickly outsider — he quarrels bitterly with Ney in Spain, is repeatedly blocked from promotion by Napoleon’s powerful chief of staff Berthier, and is finally censured and briefly arrested after the Battle of Bautzen.',
      svg_stack('The outsider hits a ceiling', [
          {'n': 1, 'label': 'Quarrels in Spain, 1808', 'sub': 'falls out with Marshal Ney', 'color': '#a16207'},
          {'n': 2, 'label': 'Blocked by Berthier', 'sub': 'the chief of staff denies him advancement', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Censured and arrested after Bautzen', 'sub': 'the final humiliation, 1813', 'color': '#78350f'},
      ], takeaway='Genius without allies stalls — the vain, foreign theorist made enemies at the top and saw his rise choked off.', accent=AC),
      bg='Jomini’s talent was matched by his vanity and touchiness, and he clashed repeatedly with the marshals and staff around him.',
      people='Marshal <b>Ney</b>, with whom he quarrelled; <b>Louis-Alexandre Berthier</b>, Napoleon’s chief of staff and his nemesis.',
      what='Jomini feuded with <b>Ney</b> during the <b>Spanish campaign (1808)</b>, was repeatedly denied promotion by <b>Berthier</b>, and after the <b>Battle of Bautzen (1813)</b> was censured and briefly placed under arrest.',
      crux='A gifted foreigner without a power base, he found his ambitions <b>thwarted by court and staff politics</b> he could not master.',
      conseq='Slighted and embittered, Jomini began to look for a service that would value him more highly.',
      matters='Brilliance is not enough inside an institution — Jomini’s grievances, as much as his ideas, set the stage for his defection.'),
]

# ==================================================================  PHASE 3 — THE GREAT DEFECTION
PHASE_DEFECTION = [
    E('defection', '1813', 'The great defection — crossing to the Tsar', ['TURNING POINT', 'POLITICS'],
      'Humiliated by his arrest after Bautzen and passed over once too often, Jomini crosses the lines during the 1813 armistice and enters the service of Tsar Alexander of Russia — a switch French officers denounce as desertion, and which he defends by pointing to his Swiss birth.',
      svg_row('A theorist changes armies', [
          {'n': 1, 'label': 'Arrested by Berthier', 'sub': 'humiliated after Bautzen', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Crosses in the 1813 armistice', 'sub': 'enters the service of the Tsar', 'color': '#155e75'},
          {'n': 3, 'label': 'Branded a deserter', 'sub': 'his Swiss birth his only defence', 'color': '#78350f'},
      ], edge_labels=['so', 'and'], takeaway='A wounded ego and a foreigner’s divided loyalty turned Napoleon’s theorist into the Tsar’s adviser overnight.', accent=AC),
      bg='After his arrest at Bautzen, and with Russia having courted him for years, Jomini decided to leave French service during the 1813 armistice.',
      people='<b>Tsar Alexander I</b>, his new master; the French officers who cried treason; Napoleon, whom he abandoned.',
      what='In August <b>1813</b> Jomini crossed to the <b>Russian side during the armistice</b>, taking service with Tsar Alexander. French officers branded him a <b>deserter</b>; Jomini argued that, as a <b>Swiss</b> with an earlier Russian commission, he had betrayed no country of his own.',
      crux='He put <b>personal grievance and ambition</b> above loyalty to the army that made him — a choice that shadowed his reputation forever.',
      conseq='He took his knowledge of French methods into the enemy camp at the decisive moment of the war.',
      matters='The most famous defection in military-intellectual history — proof of how personal slights can redirect the course of a life.'),

    E('tsar', '1813–1815', 'Aide-de-camp to Tsar Alexander', ['POLITICS', 'TRIUMPH'],
      'In Russian service Jomini is showered with honours — made a lieutenant-general and aide-de-camp to the Tsar — advising the allied campaign that topples Napoleon and attending the Congress of Vienna, yet showing his loyalty by pleading in vain for the life of his old chief Ney.',
      svg_stack('From French staff to Russian court', [
          {'n': 1, 'label': 'Lieutenant-general for the Tsar', 'sub': 'aide-de-camp to Alexander I', 'color': '#155e75'},
          {'n': 2, 'label': 'Advises the allied campaign', 'sub': 'and attends the Congress of Vienna, 1814–15', 'color': '#a16207'},
          {'n': 3, 'label': 'Pleads for Ney’s life, 1815', 'sub': 'loyal to his old chief to the end', 'color': '#166534'},
      ], takeaway='Honoured by the Tsar yet still bound to his old patron, Jomini showed the divided loyalties of the perpetual outsider.', accent=AC),
      bg='Russia welcomed the celebrated theorist, giving him high rank and access to the Tsar as the coalition closed in on Napoleon.',
      people='<b>Tsar Alexander I</b>, his patron; his old chief Marshal <b>Ney</b>, whom he tried to save; the allied commanders.',
      what='Jomini was made a <b>lieutenant-general and aide-de-camp to Tsar Alexander</b>, advised the <b>1813–14 campaign</b> against Napoleon, took part in the <b>Congress of Vienna</b>, and in 1815 <b>pleaded unsuccessfully for the life of Marshal Ney</b>, condemned for treason.',
      crux='He served his new master faithfully while still honouring the old bonds — the ambiguous position of a <b>stateless professional of war</b>.',
      conseq='He was now a fixture of the Russian court and its foremost military thinker.',
      matters='Expertise is portable — Jomini shows how a theorist’s knowledge can serve whichever power will honour it.'),

    E('academy', '1823–1832', 'General of Russia — founding the staff college', ['REFORM', 'IDEAS'],
      'Promoted to full general and entrusted with the military education of the future Tsar Nicholas I, Jomini crowns his Russian career by founding the imperial staff academy — embedding his systematic method at the heart of the Russian army.',
      svg_row('Building Russia’s brain of war', [
          {'n': 1, 'label': 'Promoted full general', 'sub': 'the Tsar’s trusted military mind', 'color': '#155e75'},
          {'n': 2, 'label': 'Tutors the future Nicholas I', 'sub': 'shapes the heir’s military thought', 'color': '#a16207'},
          {'n': 3, 'label': 'Founds the Russian staff academy', 'sub': 'institutionalises his method, 1832', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He turned his private doctrine into a national institution — teaching an empire to think about war his way.', accent=AC),
      bg='Trusted by the Romanovs, Jomini rose to the top of Russian military life and shaped its professional education.',
      people='the future <b>Tsar Nicholas I</b>, his pupil; the Russian officer corps; Tsar Alexander I.',
      what='Jomini rose to <b>full general</b>, tutored the <b>Tsarevich Nicholas</b> in military science, and was the moving spirit behind the <b>Russian staff college (established 1832)</b>, embedding his doctrine in the army’s training.',
      crux='He converted personal theory into <b>institutional doctrine</b> — a staff academy that would outlive him.',
      conseq='His systematic approach became the intellectual backbone of a great power’s army.',
      matters='Doctrine outlives the man when it is institutionalised — Jomini’s academy carried his method for generations.'),
]

# ==================================================================  PHASE 4 — THE ART OF WAR
PHASE_IDEAS = [
    E('artofwar', '1838', 'The Art of War — the summa of his thought', ['IDEAS', 'TRIUMPH'],
      'In 1838 Jomini publishes his masterwork, the Précis de l’art de la guerre — “The Art of War” — a clear, systematic summary of strategy, grand tactics and logistics that becomes the single most influential military textbook of the nineteenth century.',
      svg_stack('The masterwork of a lifetime', [
          {'n': 1, 'label': 'Précis de l’art de la guerre, 1838', 'sub': 'his “Summary of the Art of War”', 'color': '#155e75'},
          {'n': 2, 'label': 'War made systematic', 'sub': 'strategy, grand tactics and logistics', 'color': '#a16207'},
          {'n': 3, 'label': 'The soldier’s handbook of the age', 'sub': 'read in every 19th-century academy', 'color': '#166534'},
      ], takeaway='He compressed a lifetime of study into one lucid manual — the book that taught a century of officers to think.', accent=AC),
      bg='After decades of study and service, Jomini set out the mature form of his system in a single accessible volume.',
      people='the generations of cadets who studied it; translators across Europe and America; rival theorists.',
      what='The <b>Précis de l’art de la guerre (The Art of War, 1838)</b> distilled Jomini’s system into a clear treatment of <b>strategy, grand tactics and logistics</b>, and became the most widely read and translated military manual of its century.',
      crux='He offered commanders a <b>usable, teachable framework</b> — clarity and prescription over philosophical depth.',
      conseq='The book carried his principles into every major military academy of the age.',
      matters='Clarity conquers — Jomini’s influence flowed from a manual generals could actually read and apply.'),

    E('principles', '1838', 'The fundamental principle — the geometry of victory', ['IDEAS', 'REFORM'],
      'At the core of Jomini’s system is one fundamental principle — throw the mass of your force, by interior lines, against the decisive point of the enemy — supported by a geometric vocabulary of bases and lines of operation that made strategy look almost like applied mathematics.',
      svg_row('The Jominian system in three moves', [
          {'n': 1, 'label': 'Move on interior lines', 'sub': 'a central position beats divided foes', 'color': '#155e75'},
          {'n': 2, 'label': 'Find the decisive point', 'sub': 'where a blow tells most', 'color': '#a16207'},
          {'n': 3, 'label': 'Concentrate mass there', 'sub': 'superior force at the decisive point', 'color': '#166534'},
      ], edge_labels=['to', 'and'], takeaway='One principle, endlessly applied: mass your strength, by the shortest lines, against the point that decides.', accent=AC),
      bg='Jomini held that all successful strategy obeyed a single fundamental principle, expressed through the geometry of the theatre of war.',
      people='the commanders who applied his maxims; the cadets who memorised them; his critics who found them too rigid.',
      what='Jomini taught that a general should <b>concentrate the mass of his force at the decisive point</b>, using <b>interior lines</b> (a central position) to strike divided enemies in turn, while securing a sound <b>base and lines of operation</b> — a largely <b>geometric, prescriptive</b> approach.',
      crux='He reduced war to <b>a few immutable principles</b> — interior lines, the decisive point, concentration of force — that could be taught and repeated.',
      conseq='This gave staffs a shared method, but invited the charge that he mistook <b>the map for the war</b>.',
      matters='Interior lines, the decisive point and concentration of force remain foundational strategic concepts — Jomini named them.'),

    E('jominiclausewitz', '1830s', 'Jomini versus Clausewitz — two philosophies of war', ['IDEAS', 'RIVALRY'],
      'Jomini’s great intellectual rival is the Prussian Carl von Clausewitz — and their contrast frames all later military thought: Jomini the engineer of timeless, geometric principles against Clausewitz the philosopher of friction, chance and the primacy of politics.',
      svg_compare('Jomini vs Clausewitz — the great debate',
        {'head': 'Jomini — the scientist', 'color': '#155e75', 'items': ['war obeys timeless, geometric principles', 'interior lines, the decisive point, mass', 'prescriptive rules and maps', 'strategy as a teachable science', 'downplays politics, friction and chance']},
        {'head': 'Clausewitz — the philosopher', 'color': '#b91c1c', 'items': ['war is a clash of living, hostile wills', 'friction, fog and chance rule the field', '“war is the continuation of policy”', 'no formula — only judgement and genius', 'politics and passion decide everything']},
        'Prescriptive principles versus a philosophy of war — the enduring poles of military thought.',
        'Jomini told commanders what to do; Clausewitz told them what war is — and history has favoured the philosopher.', AC),
      bg='<b>Carl von Clausewitz</b> and Jomini were the two towering military theorists to emerge from the Napoleonic wars, and offered opposed visions of war.',
      people='<b>Carl von Clausewitz</b>, his Prussian rival; the two schools of officers who followed each; later strategists who judged between them.',
      what='Jomini sought <b>fixed, prescriptive principles</b> and treated strategy as a near-scientific system of lines and points; Clausewitz saw war as a <b>violent, unpredictable clash of wills</b> shaped by <b>friction, chance and politics</b> — famously “the continuation of policy by other means.”',
      crux='The contrast is between <b>war as a science with rules</b> (Jomini) and <b>war as an art bound to politics and uncertainty</b> (Clausewitz).',
      conseq='Jomini dominated the nineteenth century, but Clausewitz’s deeper vision prevailed in the twentieth and beyond.',
      matters='The Jomini–Clausewitz divide still structures strategic debate — checklist of principles versus philosophy of war.'),
]

# ==================================================================  PHASE 5 — INFLUENCE AND LEGACY
PHASE_LEGACY = [
    E('westpoint', '1830s–1865', 'Master of West Point — teaching America’s generals', ['LEGACY', 'BATTLE'],
      'Translated and taught by Dennis Hart Mahan and Henry Halleck, Jomini’s doctrine dominates West Point and shapes a whole generation of American officers — so that both Union and Confederate generals fight the Civil War with his principles in their heads, even as Grant and Sherman begin to burst their limits.',
      svg_stack('The theorist who taught the Civil War', [
          {'n': 1, 'label': 'Translated for West Point', 'sub': 'Mahan and Halleck spread his gospel', 'color': '#155e75'},
          {'n': 2, 'label': 'Both blue and grey learn Jomini', 'sub': 'Union and Confederate officers alike', 'color': '#a16207'},
          {'n': 3, 'label': 'Grant and Sherman move beyond', 'sub': 'total war outgrows the geometry', 'color': '#78350f'},
      ], takeaway='America’s Civil War was fought by officers raised on Jomini — until its scale and savagery outran his tidy principles.', accent=AC),
      bg='Jomini’s works, translated into English, became the core strategic texts at the United States Military Academy at West Point.',
      people='<b>Dennis Hart Mahan</b> and <b>Henry Halleck</b>, who taught him; the West Point graduates of both armies; <b>Grant</b> and <b>Sherman</b>.',
      what='Through instructors like <b>Mahan</b> and the translator <b>Halleck</b>, Jomini’s principles dominated <b>West Point</b>, so that most generals of the <b>American Civil War</b> were schooled in his system — though commanders like <b>Grant and Sherman</b> ultimately waged a total war his geometry did not foresee.',
      crux='His prescriptive doctrine gave a generation its <b>common strategic language</b>, for better and worse.',
      conseq='American professional military education carried a Jominian stamp for decades.',
      matters='A European theorist quietly shaped America’s bloodiest war — doctrine travels far beyond its author’s army and age.'),

    E('crimea', '1853–1856', 'The old oracle — advising the Crimean War', ['LEGACY', 'POLITICS'],
      'Long retired to Brussels and then Passy, and writing prolifically into old age, the venerable Jomini is consulted once more as a living authority — advising the Tsar during the Crimean War, decades after the campaigns that made his name.',
      svg_row('The sage consulted to the last', [
          {'n': 1, 'label': 'Retired to Brussels and Passy', 'sub': 'writing prolifically in old age', 'color': '#155e75'},
          {'n': 2, 'label': 'Consulted on the Crimean War', 'sub': 'advises the Tsar once more, 1853–56', 'color': '#a16207'},
          {'n': 3, 'label': 'The living authority on strategy', 'sub': 'Europe’s courts still seek his word', 'color': '#166534'},
      ], edge_labels=['yet', 'still'], takeaway='Half a century after Ulm, the old theorist was still the oracle to whom emperors turned for the science of war.', accent=AC),
      bg='In retirement Jomini settled in Brussels and later Passy near Paris, remaining Europe’s most famous living military thinker.',
      people='the Tsar and his commanders in the <b>Crimean War</b>; the courts that consulted him; his readers across Europe.',
      what='Though retired since 1829, Jomini kept writing and was <b>consulted as a military adviser during the Crimean War (1853–56)</b>, his authority undimmed decades after the Napoleonic wars.',
      crux='His reputation had become <b>institutional</b> — he was the recognised sage of strategy for two generations.',
      conseq='He remained a reference point for European staffs to the end of his long life.',
      matters='Authority can long outlast active service — Jomini remained the voice of strategy across half a century.'),

    E('death', '1869', 'Death at Passy — and a contested legacy', ['LEGACY', 'DEATH'],
      'Jomini dies at Passy in 1869, aged ninety, just a year before the Franco-Prussian War would usher in an age of railways and mass armies — and though Clausewitz would ultimately eclipse him, his vocabulary of interior lines, decisive points and lines of operation endures in military doctrine to this day.',
      svg_stack('The last of Napoleon’s theorists', [
          {'n': 1, 'label': 'Dies at Passy, 1869', 'sub': 'aged ninety, near Paris', 'color': '#155e75'},
          {'n': 2, 'label': 'A year before Sedan', 'sub': 'his geometry meets the railway age', 'color': '#a16207'},
          {'n': 3, 'label': 'Clausewitz eclipses him', 'sub': 'yet his terms endure in doctrine', 'color': '#166534'},
      ], takeaway='The great systematiser of Napoleonic war died on the eve of a new kind of war — outlived by his rival, but never by his vocabulary.', accent=AC),
      bg='Jomini lived to ninety, a bridge between the Napoleonic age and the industrial warfare that followed.',
      people='<b>Clausewitz</b>, the rival who eclipsed him; the staffs who kept his terms; the Napoleonic era he outlived.',
      what='Jomini <b>died at Passy in 1869</b>, one year before the <b>Franco-Prussian War</b>. In the long run <b>Clausewitz’s</b> philosophy overtook his prescriptive system, but Jomini’s core concepts — <b>interior lines, the decisive point, lines of operation, concentration of force</b> — remain embedded in modern military doctrine.',
      crux='His fate is that of the great systematiser: <b>surpassed in philosophy, indispensable in vocabulary</b>.',
      conseq='He is remembered as the foremost interpreter of Napoleonic warfare and the co-founder, with Clausewitz, of modern strategic thought.',
      matters='Even an eclipsed theorist can shape the language of a field forever — we still speak Jomini’s strategy without knowing it.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Antoine-Henri Jomini was the Swiss banker who became the great systematiser of war. Abandoning finance for the study of strategy, he dissected the campaigns of Frederick the Great and Napoleon — serving under Marshal Ney, then defecting to the Tsar — and distilled them into a set of clear, prescriptive principles: interior lines, the decisive point, the concentration of force. His masterwork, <i>The Art of War</i> (1838), taught a century of officers, dominated West Point, and shaped the generals of the American Civil War. His lifelong rival Carl von Clausewitz would ultimately eclipse him, but Jomini remains the man who gave strategy its vocabulary. He is the ultimate study in <b>war as a science, the search for timeless principles, and the limits of reducing battle to geometry.</b></p>
<div class="ov-quote">“Strategy is the art of making war upon the map.”<span>— Antoine-Henri Jomini</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A Swiss banker quits finance for the study of war → teaches himself strategy from Frederick and Napoleon → Marshal Ney makes him a staff officer in the Grande Armée → blocked by Berthier, he defects to the Tsar in 1813 → rises to general and founds Russia’s staff academy → publishes <i>The Art of War</i> and its geometric principles → shapes West Point and the American Civil War → and is finally eclipsed by Clausewitz, though his vocabulary endures.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">📐</div><h4>War as a science</h4><p>Sought timeless, teachable principles beneath every victory.</p></div>
  <div class="ov-card"><div class="i">🎯</div><h4>The decisive point</h4><p>Concentrate mass, by interior lines, where the blow tells most.</p></div>
  <div class="ov-card"><div class="i">📖</div><h4>The Art of War</h4><p>The most influential military textbook of the 19th century.</p></div>
  <div class="ov-card"><div class="i">⚔️</div><h4>Jomini vs Clausewitz</h4><p>Prescriptive principles against a philosophy of war.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Banker Turned Soldier</b><small> 1779–1805</small><p>From ledger to Ney’s staff at Ulm.</p></div>
  <div><b>2 · With the Grande Armée</b><small> 1806–1813</small><p>Jena, Eylau, the treatise — and a career blocked.</p></div>
  <div><b>3 · The Great Defection</b><small> 1813–1832</small><p>Crossing to the Tsar; general of Russia.</p></div>
  <div><b>4 · The Art of War</b><small> 1838</small><p>His principles, and the duel with Clausewitz.</p></div>
  <div><b>5 · Influence & Legacy</b><small> 1830s–1869</small><p>West Point, Crimea, and a contested name.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Marshal Michel Ney', 'role': 'patron', 'color': '#155e75',
     'bio': 'The marshal of France who read Jomini’s manuscript, funded its publication, and took him onto his staff — launching his career.',
     'rel': 'The patron who carried the outsider into the Grande Armée.'},
    {'name': 'Napoleon Bonaparte', 'role': 'model & master', 'color': '#b91c1c',
     'bio': 'The emperor whose campaigns Jomini served in and studied obsessively, and from whose method he drew his principles of war.',
     'rel': 'The commander whose art he theorised — and then abandoned.'},
    {'name': 'Carl von Clausewitz', 'role': 'intellectual rival', 'color': '#78350f',
     'bio': 'The Prussian theorist whose philosophy of war — friction, chance and politics — stood against Jomini’s prescriptive principles and ultimately eclipsed them.',
     'rel': 'His great rival and the other founder of modern strategy.'},
    {'name': 'Tsar Alexander I', 'role': 'Russian patron', 'color': '#166534',
     'bio': 'The Russian emperor who welcomed the defecting Jomini, made him a lieutenant-general and aide-de-camp, and set him over Russian military education.',
     'rel': 'The sovereign he served after leaving Napoleon.'},
    {'name': 'Louis-Alexandre Berthier', 'role': 'nemesis', 'color': '#a16207',
     'bio': 'Napoleon’s chief of staff, whose repeated blocking of Jomini’s promotion and censure after Bautzen drove him into Russian service.',
     'rel': 'The rival whose obstruction pushed him to defect.'},
]

KEY_EVENTS = [
    ('1779', 'Jomini born', 'A Swiss merchant family at Payerne.'),
    ('1804', 'Ney funds his treatise', 'A marshal adopts the unknown theorist.'),
    ('1805', 'Colonel at Ulm', 'Joins the Grande Armée on Ney’s staff.'),
    ('1807', 'Eylau & the Legion of Honour', 'Chief of staff to Ney; made baron.'),
    ('1813', 'Defects to Russia', 'Crosses to the Tsar after Bautzen.'),
    ('1814–15', 'Aide to the Tsar at Vienna', 'And pleads in vain for Ney.'),
    ('1832', 'Russian staff academy', 'Institutionalises his method.'),
    ('1838', 'The Art of War', 'His masterwork of strategy.'),
    ('1854', 'Advises in the Crimean War', 'The old oracle consulted again.'),
    ('1869', 'Death at Passy', 'Aged 90, on the eve of a new age of war.'),
]

MASTER = [
    {'year': '1779', 'age': 'born', 'phase': 'The Making', 'title': 'Born at Payerne', 'desc': 'A banker’s path he would reject.'},
    {'year': '1805', 'age': 'age 26', 'phase': 'Grande Armée', 'title': 'Colonel under Ney', 'desc': 'Baptism of fire at Ulm.'},
    {'year': '1813', 'age': 'age 34', 'phase': 'The Defection', 'title': 'Crosses to the Tsar', 'desc': 'Branded a deserter.'},
    {'year': '1832', 'age': 'age 53', 'phase': 'Russian Service', 'title': 'Founds the staff academy', 'desc': 'Doctrine made institution.'},
    {'year': '1838', 'age': 'age 59', 'phase': 'The Art of War', 'title': 'Publishes his masterwork', 'desc': 'Interior lines, the decisive point.'},
    {'year': '1869', 'age': 'age 90', 'phase': 'Legacy', 'title': 'Dies at Passy', 'desc': 'Clausewitz’s great rival.'},
]

SOURCES = [
    ('Britannica — Antoine-Henri, baron de Jomini', 'https://www.britannica.com/biography/Antoine-Henri-baron-de-Jomini'),
    ('Wikipedia — Antoine-Henri Jomini', 'https://en.wikipedia.org/wiki/Antoine-Henri_Jomini'),
    ('napoleon.org — Jomini, Antoine-Henri, Baron de', 'https://www.napoleon.org/en/history-of-the-two-empires/biographies/jomini-antoine-henri-baron-de/'),
    ('Clausewitz.com — Jomini and Clausewitz: Their Interaction', 'https://clausewitz.com/readings/Bassford/Jomini/JOMINIX.htm'),
    ('Encyclopedia.com — Antoine Henri Jomini', 'https://www.encyclopedia.com/people/history/swiss-history-biographies/antoine-henri-jomini'),
]

def build_meta():
    return {
        'pid': 'gm-jomini.html', 'kind': 'man', 'emoji': '♟️', 'accent': AC,
        'name': 'Antoine-Henri Jomini', 'years': '1779–1869', 'group': 'Diplomats & Strategists',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Swiss banker turned military theorist who reduced Napoleonic war to a science of principles — interior lines, the decisive point, the concentration of force — and, as Clausewitz’s great rival, gave strategy its lasting vocabulary.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Banker Turned Soldier', 'type': 'timeline',
             'intro': 'A Swiss banker quits finance to study war, teaches himself strategy from Frederick and Napoleon, and is carried into the Grande Armée by the patronage of Marshal Ney.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · With the Grande Armée', 'type': 'timeline',
             'intro': 'He rises through Napoleon’s campaigns and turns them into doctrine in his great treatise — but his vanity and staff politics leave his own career blocked.', 'events': PHASE_POWER},
            {'id': 'defection', 'label': '3 · The Great Defection', 'type': 'timeline',
             'intro': 'Slighted once too often, he crosses to the Tsar in 1813 — becoming a Russian general, tutor to a future Tsar, and founder of the imperial staff academy.', 'events': PHASE_DEFECTION},
            {'id': 'ideas', 'label': '4 · The Art of War', 'type': 'timeline',
             'intro': 'His masterwork sets out the principles of interior lines, the decisive point and the concentration of force — and frames his enduring duel with Clausewitz.', 'events': PHASE_IDEAS},
            {'id': 'legacy', 'label': '5 · Influence & Legacy', 'type': 'timeline',
             'intro': 'His doctrine dominates West Point and shapes the American Civil War; consulted to old age, he dies in 1869 — eclipsed by Clausewitz, yet embedded in military language forever.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; the phrasing of his principles follows his own works and their common summaries.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
