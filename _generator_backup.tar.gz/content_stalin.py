# -*- coding: utf-8 -*-
"""Full birth-to-death guide content for Joseph Stalin."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#3f3f46'  # steel

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_gensec():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1922+ · the “boring” job everyone underrated</text>'
    boxes=[(40,'#3f3f46','General Secretary','controls who gets which party job'),
           (270,'#b45309','Appoint loyalists everywhere','the whole apparatus owes him'),
           (500,'#7f1d1d','Control the votes','out-votes the brilliant Trotsky')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="76" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="82" font-size="11.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,100,s,9.6,'#5b6472',500,11,30); b+=ss
    b += '<line x1="220" y1="98" x2="268" y2="98" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="98" x2="498" y2="98" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Brilliance lost to bureaucracy: he who controls appointments controls the party — and the state.</text>'
    return _wrap(W, H, 'How Stalin won — the power of the personnel file', _tk(b, W, H, 'Control who gets the jobs, and you control everything — the dullest lever is often the strongest.'), '', AC)

def svg_collectivize():
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1928–33 · forcing an agrarian country to become an industrial superpower — fast</text>'
    b += svg_compareless()
    return _wrap(W, H, 'Collectivisation — industry bought with millions of lives', _tk(b, W, H, 'He built a superpower in a decade — and deliberately starved millions to pay for it.'), '', AC)

def svg_compareless():
    # two-column: the gain vs the cost
    x1,x2=40,380; top=58
    def col(x,head,c,items):
        h=40+len(items)*22+10
        s=f'<rect x="{x}" y="{top}" width="300" height="{h}" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        s+=f'<rect x="{x}" y="{top}" width="300" height="28" rx="12" fill="{c}"/><rect x="{x}" y="{top+14}" width="300" height="14" fill="{c}"/>'
        s+=f'<text x="{x+14}" y="{top+19}" font-size="12" font-weight="800" fill="#fff">{esc(head)}</text>'
        yy=top+46
        for it in items:
            s+=f'<circle cx="{x+16}" cy="{yy-4}" r="3" fill="{c}"/>'
            ln,_=_tspans(x+26,yy,it,10.4,'#334155',500,12,46); s+=ln; yy+=22
        return s
    s=col(x1,'THE GAIN','#3f3f46',['seize grain to fund factories','Five-Year Plans; heavy industry','USSR becomes a superpower'])
    s+=col(x2,'THE COST','#dc2626',['peasants resist → dekulakisation','forced famine (Holodomor)','millions dead'])
    s+=f'<text x="360" y="{top+12}" font-size="14" font-weight="800" fill="#94a3b8" text-anchor="middle">/</text>'
    return s

def svg_terror():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1936–38 · the Great Terror · a machine that consumes everyone, even itself</text>'
    steps=[(40,'#7f1d1d','1 · Accuse','anyone can be an “enemy of the people”'),
           (270,'#b45309','2 · Confess','torture + show trials produce guilt'),
           (500,'#3f3f46','3 · Name others','each victim names more → it spreads')]
    for x,c,t,s in steps:
        b += f'<rect x="{x}" y="60" width="180" height="72" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="82" font-size="11" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,100,s,9.6,'#5b6472',500,11,30); b+=ss
    b += '<line x1="220" y1="96" x2="268" y2="96" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="96" x2="498" y2="96" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    # loop back
    b += '<path d="M590,132 C590,168 200,172 130,134" fill="none" stroke="#7f1d1d" stroke-width="1.6" stroke-dasharray="6 4" marker-end="url(#ah)"/>'
    b += '<text x="360" y="170" font-size="10" fill="#7f1d1d" font-weight="800" text-anchor="middle">the confessions generate the next round of victims → self-sustaining terror</text>'
    return _wrap(W, H, 'The Great Terror — a self-feeding machine', _tk(b, W, H, 'Terror based on forced confessions feeds itself: fear makes everyone accuse everyone, so no one is safe.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1
PHASE_ORIGINS = [
    E('gori', '1878–1917', 'From a Georgian gutter to the Bolsheviks', ['RISE'],
      'Born poor to a violent, drunken cobbler in a Georgian town, the young Stalin escapes a seminary, becomes a revolutionary, and funds the Bolsheviks with bank robberies — a hardened, resentful outsider.',
      svg_stack('The forging of a ruthless outsider', [
          {'n': 1, 'label': 'Poor, beaten childhood in Gori', 'sub': 'a violent father; a devoted mother; deep grievance', 'color': '#78350f'},
          {'n': 2, 'label': 'Seminary → revolutionary', 'sub': 'expelled; becomes an underground Marxist', 'color': '#b45309'},
          {'n': 3, 'label': 'Robberies & loyalty to Lenin', 'sub': '“expropriations” fund the party; a useful hard man', 'color': '#3f3f46'},
      ], takeaway='He rose from real poverty and abuse — a resentful outsider who learned that ruthlessness, not brilliance, got results.', accent=AC),
      bg='Iosif Dzhugashvili (“Stalin” — man of steel) was born in 1878 in <b>Gori, Georgia</b>, on the empire’s edge — poor, provincial, and far from the intellectual world of the Bolshevik elite.',
      people='His brutal father and pious mother; <b>Lenin</b>, whose loyal and useful operative he became; the Tsarist police who exiled him repeatedly.',
      what='He abandoned a seminary for revolution, organised strikes, robbed banks to fund the Bolsheviks, and endured arrests and Siberian exile — proving himself a reliable, ruthless doer rather than a theorist.',
      crux='Unlike the cosmopolitan intellectuals around Lenin, Stalin’s value was as a <b>practical, ruthless operator</b>. His outsider resentment and appetite for hard, dirty work set him apart — and would carry him past cleverer men.',
      conseq='By 1917 he was a trusted, if unglamorous, Bolshevik insider — well placed, when the party seized power, to take on the dull administrative jobs others disdained.',
      matters='The “boring,” ruthless doer is easy to underestimate. Stalin’s rise began with a willingness to do the grubby, practical work brilliant men thought beneath them.'),

    E('koba', '1901–1917', '“Koba” the outlaw — robbery, prison, exile', ['RISE', 'BATTLE'],
      'Under the alias “Koba,” he spends over a decade as a professional revolutionary outlaw — organising strikes, running the spectacular 1907 Tiflis bank raid to fund the party, and cycling through arrests, prison and Siberian exile from which he repeatedly escapes.',
      svg_row('The making of a professional revolutionary', [
          {'n': 1, 'label': 'Agitator “Koba”', 'sub': 'organises strikes in the Caucasus oil towns', 'color': '#3f3f46'},
          {'n': 2, 'label': 'The 1907 Tiflis raid', 'sub': 'a bloody bank robbery funds the Bolsheviks', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Prison, exile, escape', 'sub': 'arrested repeatedly; escapes Siberia again and again', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='A decade in the revolutionary underground taught him conspiracy, hardness and absolute loyalty to the cause.', accent=AC),
      bg='In the years before 1917, Stalin lived the life of a hunted underground revolutionary in the Caucasus and beyond, taking the nickname <b>“Koba”</b> after a folk-hero bandit.',
      people='The Bolshevik underground; the Tsarist <b>Okhrana</b> secret police who hunted and exiled him; Lenin, who valued his results.',
      what='He organised labour agitation in <b>Baku and Tiflis</b>, helped stage the violent <b>1907 Tiflis bank “expropriation”</b> to fund the party, and endured a cycle of <b>arrest, prison and Siberian exile</b> — escaping several times.',
      crux='These years bred in him the habits of <b>secrecy, conspiracy and ruthlessness</b>, and a scorn for émigré theorists who debated abroad while he did the dangerous work at home.',
      conseq='He emerged battle-hardened and utterly committed — a doer the party could rely on for its dirtiest tasks.',
      matters='Character is forged in the trenches of a cause. The conspiratorial underground shaped the suspicious, merciless operator Stalin would remain.'),

    E('civilwar', '1917–1922', 'Revolution, civil war, and the taste of terror', ['BATTLE', 'POLITICS'],
      'He plays a solid if secondary role in the 1917 seizure of power, then in the civil war shows his method at Tsaritsyn — later renamed Stalingrad — where he shoots “traitors” freely and first clashes with Trotsky.',
      svg_row('War teaches him his method', [
          {'n': 1, 'label': '1917: a Bolshevik insider', 'sub': 'a solid organiser in the October seizure', 'color': '#3f3f46'},
          {'n': 2, 'label': 'Commissar for Nationalities', 'sub': 'his first great administrative post', 'color': '#b45309'},
          {'n': 3, 'label': 'Terror at Tsaritsyn', 'sub': 'shoots “enemies” freely; clashes with Trotsky', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='In the civil war he learned that terror got results — and began his lifelong feud with Trotsky.', accent=AC),
      bg='The Bolsheviks seized power in <b>October 1917</b> and then fought a brutal <b>civil war (1918–21)</b> to hold it. Stalin took on hard administrative and military-political jobs.',
      people='<b>Lenin</b>, who trusted him with tough assignments; <b>Trotsky</b>, the war commissar with whom Stalin repeatedly clashed; the “class enemies” he had shot.',
      what='Stalin became <b>Commissar for Nationalities</b> and a civil-war troubleshooter. At <b>Tsaritsyn</b> (later <b>Stalingrad</b>) he ran a ruthless regime of requisition and summary executions, and quarrelled bitterly with Trotsky over authority.',
      crux='He discovered that <b>terror and iron control produced results</b> in a crisis — and nursed a growing rivalry with the more brilliant, more famous Trotsky.',
      conseq='He accumulated administrative posts and grievances alike, positioning himself for the succession struggle to come.',
      matters='Methods learned in crisis become permanent habits. The young commissar who shot “traitors” at Tsaritsyn was rehearsing the ruler he would become.'),
]

# ==================================================================  PHASE 2
PHASE_RISE = [
    E('nationalities', '1913–1923', 'Commissar of Nationalities — and the clash with Lenin', ['POLITICS', 'REFORM'],
      'Stalin makes his name as the party’s expert on its many nations, writes the pamphlet that defines Bolshevik nationality policy, then as Commissar helps design the USSR itself — bullying Georgia so brutally that a dying Lenin turns against him.',
      svg_stack('The nationalities expert who overreached', [
          {'n': 1, 'label': '“Marxism and the National Question”, 1913', 'sub': 'the pamphlet that makes him the party’s authority on nations', 'color': '#71717a'},
          {'n': 2, 'label': 'Commissar of Nationalities, 1917', 'sub': 'a Georgian running policy for the empire’s minorities', 'color': '#3f3f46'},
          {'n': 3, 'label': 'The Georgian Affair, 1922', 'sub': 'his heavy-handed crushing of Georgian communists appals Lenin', 'color': '#b91c1c'},
      ], takeaway='He built real expertise and power in a dull-sounding brief — then his ruthlessness in it gave Lenin the first alarm.', accent=AC),
      bg='The Russian empire was a patchwork of nations. The Bolsheviks needed a policy; Stalin, a non-Russian from the Caucasus, became their specialist, writing on the subject before 1917 with Lenin’s encouragement.',
      people='<b>Lenin</b>, who first sponsored then recoiled from him; <b>Ordzhonikidze</b>, Stalin’s enforcer in Georgia; the Georgian communists he crushed to force them into the union.',
      what='He wrote the defining pamphlet (1913), served as <b>Commissar of Nationalities</b> from 1917, and helped structure the <b>USSR</b> founded in 1922 — but his bullying in the <b>Georgian Affair</b> so disturbed the ailing Lenin that it fed Lenin’s Testament.',
      crux='He turned an unglamorous portfolio into a base of real administrative power — the same instinct that made the General Secretaryship deadly.',
      conseq='The episode planted Lenin’s distrust just as Stalin was accumulating the levers he would use to win — and it shaped a union built to look federal but run from the centre.',
      matters='Power often accrues fastest in the jobs no rival wants — mastery of the “boring” brief is underrated.'),

    E('tsaritsyn', '1918–1920', 'Tsaritsyn — a first taste of command and terror', ['BATTLE', 'POLITICS'],
      'Sent south to secure grain during the civil war, Stalin seizes military control of Tsaritsyn — the city later renamed Stalingrad — ruling by shooting and clashing bitterly with Trotsky, a rehearsal for everything that follows.',
      svg_row('The civil-war template of Stalin’s rule', [
          {'n': 1, 'label': 'Sent to get grain', 'sub': 'a food-supply mission to a starving Red republic', 'color': '#3f3f46'},
          {'n': 2, 'label': 'Seizes military power', 'sub': 'overrides commanders; rules the city by execution', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Feud with Trotsky', 'sub': 'defies the war commissar — a rivalry that never dies', 'color': '#a16207'},
      ], edge_labels=['becomes', 'breeds'], takeaway='The civil war taught him that terror gets results and that Trotsky is the enemy — two lifelong lessons.', accent=AC),
      bg='In 1918 the Bolshevik regime was fighting for survival and starving. Stalin was dispatched to <b>Tsaritsyn</b> on the Volga to requisition grain and hold the south.',
      people='<b>Trotsky</b>, the war commissar whose authority Stalin flouted; the ex-Tsarist “military specialists” Stalin distrusted and had shot; local Reds who obeyed through fear.',
      what='Stalin took over military affairs in the city, <b>executed suspected counter-revolutionaries and officers</b> on his own authority, and repeatedly <b>defied Trotsky’s orders</b> — Lenin had to mediate. The city was later renamed <b>Stalingrad</b>.',
      crux='He learned that <b>ruthlessness produced compliance</b> and that formal command mattered less than control on the ground — lessons he never unlearned.',
      conseq='The Trotsky feud hardened into the central rivalry of the 1920s; the taste for terror as an administrative tool became his signature.',
      matters='Formative crises forge a leader’s methods — what works in the emergency becomes the habit of a lifetime.'),

    E('gensec', '1922–1928', 'The General Secretary — winning by boredom', ['POLITICS', 'TURNING POINT'],
      'Everyone underrates the dull administrative post of General Secretary. Stalin uses it to appoint loyalists throughout the party — quietly building a machine that lets him outvote the brilliant Trotsky.',
      svg_gensec(),
      bg='After Lenin’s strokes and death (1924), the Bolshevik leaders competed to succeed him. The obvious heir was the charismatic <b>Trotsky</b>; Stalin held the unglamorous post of <b>General Secretary</b>.',
      people='<b>Leon Trotsky</b>, the brilliant rival; <b>Kamenev</b> and <b>Zinoviev</b>, whom Stalin first allied with against Trotsky, then destroyed; a dying <b>Lenin</b>, whose warning about Stalin was suppressed.',
      what='As <b>General Secretary from 1922</b>, Stalin controlled party <b>appointments</b>, packing committees with men who owed him their jobs. He allied with rivals to isolate Trotsky, then turned on each ally in turn, until by 1928 he was dominant. He preached “<b>Socialism in One Country</b>” against Trotsky’s world revolution.',
      crux='He grasped that in a one-party state, <b>control of personnel is control of power</b>. The “boring” bureaucratic lever — who gets which job — beat charisma, oratory and theory.',
      conseq='By the late 1920s Stalin had outmanoeuvred every rival and stood as the unchallenged leader of the Soviet Union, free to remake it.',
      matters='The most powerful lever is often the least glamorous. While others sought the spotlight, Stalin quietly controlled the machine — and machines beat stars.'),

    E('testament', '1922–1924', 'Lenin’s Testament — the warning that was buried', ['POLITICS', 'TURNING POINT'],
      'The dying Lenin, alarmed by Stalin’s rudeness and concentration of power, dictates a testament urging the party to remove him as General Secretary — but Stalin and his allies suppress it, and the one document that could have stopped him is quietly buried.',
      svg_row('The warning that never landed', [
          {'n': 1, 'label': 'Lenin turns against Stalin', 'sub': 'alarmed by his rudeness and power-hoarding', 'color': '#b45309'},
          {'n': 2, 'label': 'The Testament', 'sub': 'urges removing Stalin as General Secretary', 'color': '#3f3f46'},
          {'n': 3, 'label': 'It is suppressed', 'sub': 'Stalin’s allies keep it from the party', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='The one warning that might have stopped him was buried by the very men he would later destroy.', accent=AC),
      bg='In his final illness, <b>Lenin</b> grew alarmed at Stalin’s growing power and personal rudeness (including to Lenin’s wife), and dictated a <b>“Testament”</b> assessing the party’s leaders.',
      people='The dying <b>Lenin</b>; his allies <b>Kamenev and Zinoviev</b>, who helped bury the document to use Stalin against Trotsky.',
      what='Lenin’s <b>Testament</b> criticised all the leaders but specifically urged that <b>Stalin be removed as General Secretary</b> for having “concentrated enormous power” and being “too rude.” Stalin’s temporary allies helped <b>suppress it</b> rather than act on it.',
      crux='The men who could have removed Stalin <b>underestimated him and used him for their own ends</b> — a fatal miscalculation, since he would destroy them all in turn.',
      conseq='The Testament was hushed up; Stalin kept his post and his machine, and the moment to stop him passed.',
      matters='Warnings ignored for short-term advantage can be catastrophic. The party had, and buried, the one document that named the danger exactly.'),

    E('oppositions', '1925–1929', 'Divide and destroy — the defeat of every faction', ['POLITICS', 'TRIUMPH'],
      'He plays the party’s factions against each other with cold brilliance: allying with the Right to crush the Left and Trotsky, then turning on the Right — until, one by one, every rival is politically dead and Stalin stands alone.',
      svg_row('Beating the factions one at a time', [
          {'n': 1, 'label': 'Ally right, crush left', 'sub': 'uses Bukharin to defeat Trotsky, Zinoviev, Kamenev', 'color': '#3f3f46'},
          {'n': 2, 'label': 'Then crush the right', 'sub': 'turns on Bukharin and the “Right Opposition”', 'color': '#b45309'},
          {'n': 3, 'label': 'Stands alone', 'sub': 'by 1929 every rival is politically finished', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He never fought all his enemies at once — he borrowed each faction to destroy the next.', accent=AC),
      bg='After isolating Trotsky, Stalin faced shifting party factions debating the pace of industrialisation and the fate of the revolution.',
      people='<b>Trotsky, Zinoviev and Kamenev</b> (the Left); <b>Nikolai Bukharin</b> and the Right, whom Stalin used and then destroyed.',
      what='Stalin <b>allied with the Right (Bukharin)</b> to defeat the Left Opposition (Trotsky, Zinoviev, Kamenev), then abruptly <b>turned on the Right</b>, adopting their rivals’ programme of rapid industrialisation and crushing Bukharin — leaving himself unchallenged by 1929.',
      crux='He mastered the art of the <b>temporary alliance</b>: never facing all enemies at once, but using each faction to eliminate another before discarding it.',
      conseq='With every rival politically destroyed, Stalin held absolute control of the party and could impose his revolution from above.',
      matters='Divide and conquer is timeless. Stalin’s serial betrayals of his own allies are a masterclass in the ruthless mechanics of one-party politics.'),
]

# ==================================================================  PHASE 3
PHASE_TERROR = [
    E('collectivize', '1928–1933', 'Collectivisation — a superpower built on famine', ['REFORM', 'TRAGEDY'],
      'To industrialise fast, he forces peasants onto collective farms and seizes their grain to pay for factories. Resistance is crushed; a deliberate famine kills millions — but the USSR becomes an industrial power.',
      svg_collectivize(),
      bg='The USSR was a backward, largely peasant country. Stalin resolved to industrialise at breakneck speed — to “catch up” with the West in a decade — and to pay for it by squeezing the countryside.',
      people='The <b>kulaks</b> (better-off peasants), branded enemies and destroyed; the people of <b>Ukraine</b> and other regions, victims of the <b>Holodomor</b> famine; the planners of the <b>Five-Year Plans</b>.',
      what='From 1928 he forced peasants into <b>collective farms</b>, “liquidated the kulaks,” and requisitioned grain to fund the <b>Five-Year Plans</b>. Resistance and grain seizures produced a catastrophic <b>famine (1932–33)</b> that killed millions, while heavy industry expanded rapidly.',
      crux='He treated human beings as a <b>resource to be spent</b>: the countryside was drained to build industry, and mass death was an accepted price. Central terror overrode all resistance.',
      conseq='The USSR became a genuine industrial and military power — which would prove decisive against Nazi Germany — but at the cost of millions of lives and a terrorised, obedient society.',
      matters='Coerced, top-down transformation can deliver staggering results and staggering horror at once. Ends-justify-means thinking, taken to its extreme, treats people as raw material.'),

    E('kirov', '1 Dec 1934', 'The murder of Kirov — the spark for the Terror', ['POLITICS', 'TURNING POINT', 'DEATH'],
      'The assassination of the popular Leningrad boss Sergei Kirov gives Stalin both a pretext and a rallying cry — emergency laws follow within hours, and the road to the Great Terror is opened.',
      svg_stack('One killing, engineered into a purge', [
          {'n': 1, 'label': 'Kirov shot in Leningrad, Dec 1934', 'sub': 'a rising, popular rival is murdered at party HQ', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Emergency decree, same day', 'sub': 'summary trials, no appeal, immediate execution for “terrorism”', 'color': '#3f3f46'},
          {'n': 3, 'label': 'A pretext for mass repression', 'sub': 'the killing is blamed on ever-widening “conspiracies”', 'color': '#71717a'},
      ], takeaway='Whether or not he ordered it, Stalin used the murder as the legal and emotional engine of the Terror.', accent=AC),
      bg='<b>Sergei Kirov</b>, the charismatic Leningrad party chief, had drawn applause at the 1934 Congress that unsettled Stalin. On 1 December 1934 he was shot dead by a lone gunman inside party headquarters.',
      people='<b>Kirov</b>, the victim; the assassin <b>Nikolaev</b>; <b>Yagoda</b>’s NKVD; the Old Bolsheviks (Zinoviev, Kamenev) soon accused of masterminding it.',
      what='Within hours Stalin pushed through the <b>Law of 1 December</b> — accelerated trials, no defence, no appeal, instant execution for terrorism. Historians still debate his role in the murder itself; his exploitation of it is not in doubt.',
      crux='A single death, wrapped in the language of a vast conspiracy, became the <b>legal machinery and moral pretext</b> for killing on an industrial scale.',
      conseq='The investigation was steered to implicate Stalin’s old rivals, leading directly into the show trials and the Great Terror of 1936–38.',
      matters='Tyrants rarely need to invent a crisis — they need only seize one and write the laws before the shock fades.'),

    E('purges', '1936–1938', 'The Great Terror', ['TRAGEDY', 'POLITICS', 'DEATH'],
      'Gripped by paranoia and a will to total control, he unleashes a wave of arrests, show trials and executions that consumes the old Bolsheviks, the army’s officers, and ordinary citizens alike — even his own enforcers.',
      svg_terror(),
      bg='By the mid-1930s Stalin was supreme, but feared rivals real and imagined. The murder of party boss <b>Kirov</b> (1934) became the pretext for mass repression.',
      people='The <b>NKVD</b> secret police (under Yagoda, then Yezhov, then Beria); the old Bolshevik leaders (Zinoviev, Kamenev, Bukharin) executed in <b>show trials</b>; the Red Army officer corps, decimated on the eve of war.',
      what='The <b>Great Terror (1936–38)</b> saw hundreds of thousands executed and millions sent to the <b>Gulag</b>. Show trials extracted false confessions; the army was gutted of its best commanders; even the secret police chiefs who ran the terror were themselves shot.',
      crux='Terror based on <b>forced confessions is self-perpetuating</b>: each victim, under torture, names others, and universal fear makes everyone denounce everyone — so no one, not even the executioners, is safe.',
      conseq='Stalin achieved total, unchallengeable control, but crippled the army just before Hitler’s invasion and traumatised Soviet society for generations.',
      matters='Absolute power secured by terror devours competence and loyalty alike. The very machine that protects the tyrant also blinds and weakens the state he rules.'),

    E('fiveyear', '1928–1937', 'The Five-Year Plans — a superpower built at speed', ['REFORM', 'TRIUMPH'],
      'Alongside the horror, the achievement: crash industrialisation on a colossal scale. Whole new industrial cities like Magnitogorsk rise from nothing, steel and tractor output soars, and a peasant nation is dragged, brutally, into the industrial age in barely a decade.',
      svg_stack('Industrialising a nation from scratch', [
          {'n': 1, 'label': 'Targets set from the top', 'sub': 'Five-Year Plans demand impossible output leaps', 'color': '#3f3f46'},
          {'n': 2, 'label': 'New cities from nothing', 'sub': 'Magnitogorsk, Dnieper dam, vast steelworks', 'color': '#b45309'},
          {'n': 3, 'label': 'A superpower base', 'sub': 'heavy industry that will out-produce Germany at war', 'color': '#16a34a'},
      ], takeaway='He compressed a century of industrial growth into a decade — the foundation of Soviet superpower, however brutally built.', accent=AC),
      bg='The USSR launched successive <b>Five-Year Plans</b> from 1928 to transform a backward agrarian economy into an industrial giant at breakneck speed.',
      people='The planners of <b>Gosplan</b>; the workers, prisoners and “shock brigades” who built the projects; the propaganda that glorified record-breaking labour.',
      what='The Plans drove <b>staggering growth in heavy industry</b> — steel, coal, machinery, electricity — and built whole new industrial centres like <b>Magnitogorsk</b>, often with forced or semi-forced labour and enormous waste and suffering.',
      crux='He proved that a <b>command economy could force rapid industrialisation</b> by fiat — mobilising a whole society toward state-set targets, regardless of the human cost.',
      conseq='The industrial base created in the 1930s would let the USSR out-produce Nazi Germany in tanks and guns and survive the coming war.',
      matters='Coerced central planning can achieve real, rapid industrial results — a fact that made Stalinism genuinely attractive to some, and its human cost easy to hide behind the statistics.'),

    E('showtrials', '1936–1938', 'The Moscow Show Trials', ['TRAGEDY', 'POLITICS'],
      'The old heroes of the revolution are paraded before the world in scripted trials, confessing to fantastical crimes they never committed, and then shot — a grotesque theatre of guilt designed to erase the Bolshevik old guard and rewrite history.',
      svg_row('Theatre of the absurd — and lethal', [
          {'n': 1, 'label': 'Arrest the old guard', 'sub': 'Zinoviev, Kamenev, then Bukharin', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Scripted confessions', 'sub': 'torture and threats produce absurd guilty pleas', 'color': '#b45309'},
          {'n': 3, 'label': 'Execute and erase', 'sub': 'shot; airbrushed from photos and history', 'color': '#3f3f46'},
      ], edge_labels=['then', 'then'], takeaway='He didn’t just kill his old comrades — he made them publicly confess to lies first, then unpersoned them.', accent=AC),
      bg='At the heart of the Great Terror were the <b>Moscow Show Trials</b> — public spectacles in which leading old Bolsheviks confessed to elaborate conspiracies.',
      people='<b>Zinoviev and Kamenev</b> (1936); <b>Bukharin</b> (1938); the prosecutor <b>Andrei Vyshinsky</b>; foreign observers who were fooled or looked away.',
      what='In staged trials, the <b>founding heroes of the revolution</b> confessed — after torture and threats to their families — to being spies, wreckers and assassins, then were <b>executed</b>. They were then erased from photographs and official history.',
      crux='The trials’ purpose was <b>total control of the past and present</b>: destroying anyone with independent revolutionary authority and terrorising everyone else into submission through spectacle.',
      conseq='The Bolshevik old guard was annihilated; a new elite that owed everything to Stalin took their place.',
      matters='Totalitarian power seeks to control not just actions but memory and truth. The show trials are the definitive image of a lie enforced by terror.'),

    E('militarypurge', '1937–1938', 'Decapitating the Red Army', ['TRAGEDY', 'POLITICS', 'DEATH'],
      'At the height of the Terror Stalin turns on his own officer corps, shooting his most brilliant marshal and tens of thousands of commanders — a self-inflicted wound that nearly loses the war four years later.',
      svg_row('Destroying the army before the war', [
          {'n': 1, 'label': 'Tukhachevsky shot, Jun 1937', 'sub': 'the USSR’s finest military mind, on forged evidence', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The officer corps gutted', 'sub': '3 of 5 marshals, most generals, tens of thousands of officers', 'color': '#3f3f46'},
          {'n': 3, 'label': 'A leaderless army in 1941', 'sub': 'inexperienced commanders face Barbarossa', 'color': '#a16207'},
      ], edge_labels=['triggers', 'produces'], takeaway='Fear of a coup led him to cripple the very institution he would soon need to survive.', accent=AC),
      bg='By 1937 the Terror reached the armed forces. Stalin feared the professional military as a potential rival power centre — and possibly believed German-planted disinformation about a plot.',
      people='Marshal <b>Mikhail Tukhachevsky</b>, the innovative theorist of “deep battle,” tortured into confession and shot; three of five marshals; the mass of executed and imprisoned commanders.',
      what='In 1937–38 Stalin had <b>Tukhachevsky and much of the high command executed</b> and purged tens of thousands of officers. Command experience collapsed just as war approached.',
      crux='He treated his own army as a threat to be pre-empted — trading <b>military competence for political safety</b>.',
      conseq='The gutted, cowed officer corps contributed directly to the catastrophes of 1941; many purged officers were only rehabilitated when disaster forced it.',
      matters='A leader who purges competence to secure loyalty may win the palace and lose the field.'),

    E('yezhov', '1937–1938', 'The Yezhovshchina — terror by quota', ['TRAGEDY', 'POLITICS', 'DEATH'],
      'The Terror’s deadliest phase runs not on show trials but on secret quotas: the NKVD under Nikolai Yezhov is ordered to arrest and shoot fixed numbers of “enemies,” region by region — bureaucratic mass murder, then Yezhov himself is shot to end it.',
      svg_stack('Mass murder run like a production plan', [
          {'n': 1, 'label': 'Order No. 00447, Jul 1937', 'sub': 'regional quotas for arrests and executions of “anti-Soviet elements”', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Local bosses ask for MORE', 'sub': 'zeal and fear drive quotas upward; ~700,000+ shot', 'color': '#3f3f46'},
          {'n': 3, 'label': 'Yezhov made the scapegoat, 1938', 'sub': 'the terror is “corrected”; its executor is executed', 'color': '#71717a'},
      ], takeaway='By turning killing into a quota system, the regime industrialised terror — then blamed the tool it had used.', accent=AC),
      bg='The public show trials were the tip; the mass killing happened in secret “<b>mass operations</b>” against peasants, ex-kulaks, national minorities and “socially harmful” people.',
      people='<b>Nikolai Yezhov</b>, the tiny, fanatical NKVD chief who gave the period its name (the “Yezhovshchina”); <b>Beria</b>, who replaced and then executed him; the anonymous hundreds of thousands.',
      what='<b>Operational Order No. 00447</b> set numerical <b>quotas</b> for execution and imprisonment; local officials often requested increases. Perhaps <b>750,000 people were shot</b> in 1937–38. In 1938 Stalin wound it down and had Yezhov arrested and later shot.',
      crux='Terror became a <b>self-amplifying bureaucratic process</b> — numbers to be met, not crimes to be judged — with the organiser discarded to signal a “return to order.”',
      conseq='Society was atomised into obedience; the NKVD was itself purged; and the fiction that “excesses” were the fault of one man let the system continue.',
      matters='When killing is set as a target to hit, the machinery kills to meet the target — the most chilling form of the banality of evil.'),

    E('cult', '1929–1953', 'The cult of personality — rewriting reality', ['POLITICS', 'REFORM'],
      'Stalin remakes himself into a living god: cities and prizes bear his name, history is rewritten to erase his rivals, and purged men are literally airbrushed out of photographs — control of the past to control the present.',
      svg_stack('Manufacturing a god and erasing his enemies', [
          {'n': 1, 'label': 'The 50th birthday, 1929', 'sub': 'the cult launches; “Stalin” means the revolution itself', 'color': '#3f3f46'},
          {'n': 2, 'label': 'The “Short Course”, 1938', 'sub': 'an official party history that rewrites his central role', 'color': '#a16207'},
          {'n': 3, 'label': 'Airbrushed photographs', 'sub': 'executed men vanish from images beside him', 'color': '#b91c1c'},
      ], takeaway='He didn’t just kill rivals — he unmade their existence, editing the historical record itself.', accent=AC),
      bg='From his 50th birthday in 1929 the regime built a systematic <b>cult</b>. Loyalty required not just obedience but adoration, and a single official version of history.',
      people='Propagandists, artists and historians who produced the imagery and the texts; the retouchers who deleted purged figures; the schoolchildren raised on the “<b>Short Course</b>.”',
      what='Stalin’s name was given to <b>Stalingrad</b>, prizes and peaks; the <b>“Short Course” History</b> (1938) became scripture; and photographs were <b>doctored to erase</b> executed officials — a visible rewriting of the past.',
      crux='By owning both worship and memory he made opposition almost unthinkable — <b>whoever controls the past controls the present</b>.',
      conseq='The cult’s scale is exactly what Khrushchev denounced in his 1956 “Secret Speech,” which finally named it a crime.',
      matters='Total power seeks control not only of what people do but of what they are allowed to remember.'),

    E('gulag', '1930s–1953', 'The Gulag — an empire of camps', ['TRAGEDY'],
      'Behind the trials lies a vast archipelago of forced-labour camps stretching across the frozen expanses of the USSR, where millions of prisoners — political and ordinary alike — are worked, starved and frozen, both as punishment and as a slave workforce for the plans.',
      svg_stack('Terror as an economic system', [
          {'n': 1, 'label': 'Millions arrested', 'sub': 'political prisoners and ordinary people alike', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Shipped to the camps', 'sub': 'a vast network across Siberia and the Arctic', 'color': '#3f3f46'},
          {'n': 3, 'label': 'Worked to build the state', 'sub': 'slave labour for canals, mines and railways', 'color': '#b45309'},
      ], takeaway='The camps were both a punishment and a slave-labour engine — terror fused with the economy of the plans.', accent=AC),
      bg='The <b>Gulag</b> (the camp administration) ran a huge network of <b>forced-labour camps</b> that became central to both repression and the Soviet economy.',
      people='The millions of prisoners; the <b>NKVD</b> that ran the camps; the writer <b>Aleksandr Solzhenitsyn</b>, who later exposed the system.',
      what='Millions passed through the <b>Gulag</b> — sentenced by quota, denunciation or association — and were used as <b>slave labour</b> on canals, mines, railways and Arctic projects in lethal conditions; vast numbers died.',
      crux='The camps welded <b>terror to economics</b>: fear disciplined society while prisoners were literally worked into the state’s infrastructure — a self-justifying machine of repression.',
      conseq='The Gulag scarred Soviet society for generations and became, through Solzhenitsyn and others, a defining symbol of totalitarian cruelty.',
      matters='When a state treats its own people as expendable labour, terror and economy fuse. The Gulag is the physical geography of Stalinist power.'),
]

# ==================================================================  PHASE 4
PHASE_WAR = [
    E('pact', '23 Aug 1939', 'The Nazi–Soviet Pact — dividing Europe with Hitler', ['POLITICS', 'TURNING POINT'],
      'The world is stunned when the two great enemies, Nazism and Communism, sign a non-aggression pact — with a secret protocol carving up Poland and the Baltics between them, buying Stalin time and territory at a terrible later cost.',
      svg_row('A cynical bargain that reshaped the map', [
          {'n': 1, 'label': 'Molotov–Ribbentrop Pact', 'sub': 'sworn enemies sign non-aggression, Aug 1939', 'color': '#3f3f46'},
          {'n': 2, 'label': 'A secret protocol', 'sub': 'divides Poland, Baltics, Finland into “spheres”', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The USSR takes its half', 'sub': 'invades eastern Poland, annexes the Baltic states', 'color': '#a16207'},
      ], edge_labels=['hides', 'enables'], takeaway='He bought time and land by allying with the enemy he most feared — and disarmed his own vigilance.', accent=AC),
      bg='By 1939 Stalin distrusted the West’s willingness to fight Hitler and feared standing alone. When talks with Britain and France stalled, he turned to a deal with Germany.',
      people='Foreign ministers <b>Molotov</b> and <b>Ribbentrop</b>, who signed; <b>Hitler</b>, buying a free hand in the west; the peoples of Poland and the Baltics, traded between dictators.',
      what='On <b>23 August 1939</b> the two powers signed a non-aggression pact with a <b>secret protocol</b> partitioning Eastern Europe. Weeks later both invaded Poland; the USSR then absorbed the <b>Baltic states</b> and attacked Finland.',
      crux='Stalin gained <b>~2 years and a buffer of territory</b> — but grew so invested in the pact that he ignored every warning of the coming betrayal.',
      conseq='The land was overrun in days in 1941; his refusal to believe Hitler would break the pact made Barbarossa far worse.',
      matters='A deal that buys time can also buy complacency — the respite is worthless if it dulls the warning signs.'),

    E('winterwar', '1939–1940', 'The Winter War exposes the gutted army', ['BATTLE', 'DEFEAT'],
      'Emboldened by his pact with Hitler, he attacks tiny Finland — and the world watches the huge Red Army, its officer corps freshly shattered by his own purges, humiliated for months by a fraction of its numbers before grinding out a costly, embarrassing win.',
      svg_row('The price of purging your own generals', [
          {'n': 1, 'label': 'Invades Finland, 1939', 'sub': 'expects an easy, quick conquest', 'color': '#3f3f46'},
          {'n': 2, 'label': 'Humiliation', 'sub': 'the purged, badly-led army is mauled for months', 'color': '#dc2626'},
          {'n': 3, 'label': 'A costly, hollow win', 'sub': 'victory at last — but the weakness is exposed', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='His own terror had wrecked the army’s leadership — and Finland made that fatal weakness visible to Hitler.', accent=AC),
      bg='Having divided Eastern Europe with Hitler, Stalin moved to expand the Soviet sphere, attacking <b>Finland</b> in late 1939.',
      people='The tiny but skilled <b>Finnish army</b>; the Soviet commanders hamstrung by the purges; a watching <b>Hitler</b>.',
      what='In the <b>Winter War (1939–40)</b>, the vastly larger Red Army — its experienced officers destroyed in the Terror — was <b>humiliated for months</b> by Finnish forces before finally winning at heavy cost and seizing territory.',
      crux='The debacle exposed how badly the <b>purges had crippled the army’s leadership</b> — a weakness that encouraged Hitler to believe the USSR would collapse quickly.',
      conseq='It prompted some military reforms, but the damage was done: the Wehrmacht drew confidence from the Red Army’s poor showing.',
      matters='Self-inflicted wounds have consequences. Stalin’s terror against his own officers nearly cost him the far greater war to come.'),

    E('katyn', '1940', 'The Katyn massacre — murdering a nation’s elite', ['TRAGEDY', 'POLITICS', 'DEATH'],
      'On Stalin’s written order the NKVD shoots some 22,000 captured Polish officers, police and intellectuals in the Katyn forest and other sites — then blames the Nazis, a lie the USSR maintained for fifty years.',
      svg_stack('The secret killing of Poland’s leadership', [
          {'n': 1, 'label': 'Politburo order, Mar 1940', 'sub': 'Stalin signs the death warrant for the Polish prisoners', 'color': '#b91c1c'},
          {'n': 2, 'label': '~22,000 shot', 'sub': 'officers, police, doctors, professors — the educated class', 'color': '#3f3f46'},
          {'n': 3, 'label': 'Blamed on Germany, denied to 1990', 'sub': 'the Soviet state lies about it for half a century', 'color': '#71717a'},
      ], takeaway='He aimed to behead Poland as a nation by killing the people who could lead it — then erased the crime.', accent=AC),
      bg='After the 1939 partition of Poland, the USSR held hundreds of thousands of prisoners, including the reserve officers who were also Poland’s doctors, lawyers, teachers and engineers.',
      people='The <b>Polish officer prisoners</b>; <b>Beria</b>, who proposed the shootings; <b>Stalin and the Politburo</b>, who signed the order; the Nazis who exposed the graves in 1943 to split the Allies.',
      what='In spring 1940 about <b>22,000 Poles were executed</b> at Katyn and elsewhere on a signed Politburo order. When Germany found the graves in 1943, the USSR <b>blamed the Nazis</b> and only admitted responsibility in <b>1990</b>.',
      crux='It was <b>decapitation as policy</b> — destroy a subjugated nation’s leadership class so it cannot resist or revive.',
      conseq='The massacre poisoned Polish–Soviet relations for generations and became a defining symbol of Soviet lies about their own crimes.',
      matters='The deadliest form of conquest targets not a country’s soldiers but the small class of people capable of leading it.'),

    E('barbarossa', '1941', 'Barbarossa — catastrophe and recovery', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'Trusting a pact with Hitler, he ignores every warning of invasion — and is caught catastrophically off guard when Germany attacks. The USSR nearly collapses before Stalin steadies it into total war.',
      svg_row('From blunder to grim resolve', [
          {'n': 1, 'label': 'Nazi–Soviet Pact (1939)', 'sub': 'buys time; carves up Poland with Hitler', 'color': '#3f3f46'},
          {'n': 2, 'label': 'Ignores invasion warnings', 'sub': 'purged army; 1941 attack is a disaster', 'color': '#dc2626'},
          {'n': 3, 'label': 'Total war & survival', 'sub': 'move factories east; “Not one step back”', 'color': '#16a34a'},
      ], edge_labels=['then', 'then'], takeaway='His worst blunder nearly lost the war; his ruthless resolve — and Russia’s scale — clawed it back.', accent=AC),
      bg='In <b>1939</b> Stalin signed a non-aggression pact with Hitler, dividing Eastern Europe. He believed it bought years of safety and dismissed intelligence warning of a German attack.',
      people='<b>Hitler</b>, who invaded in June 1941; the Soviet generals Stalin had purged (and those, like <b>Zhukov</b>, who rose to save the USSR); the Soviet people, who bore staggering losses.',
      what='<b>Operation Barbarossa (June 1941)</b> caught the USSR unprepared; the Germans advanced to the gates of Moscow. After initial paralysis, Stalin rallied the country — relocating industry east, imposing brutal discipline (“<b>Not one step back</b>”), and mobilising total war.',
      crux='His catastrophic <b>misjudgement</b> of Hitler nearly destroyed the USSR; but his <b>ruthlessness and the country’s vast scale and resources</b> turned initial disaster into eventual endurance.',
      conseq='At enormous human cost, the Soviet Union survived 1941 and began the long, grinding fight back that would end in Berlin.',
      matters='Even total power can be blinded by its own assumptions. Recovery came not from foresight but from ruthless resilience and sheer depth of resources.'),

    E('order227', '28 Jul 1942', 'Order No. 227 — “Not one step back”', ['BATTLE', 'POLITICS', 'TRAGEDY'],
      'With the Germans surging toward Stalingrad, Stalin issues the most brutal order of the war: retreat without permission is treason, punishable by death — enforced by blocking detachments and penal battalions that drive men forward at gunpoint.',
      svg_row('Holding the line with terror', [
          {'n': 1, 'label': 'Crisis: retreat to the Volga', 'sub': 'summer 1942; the army is collapsing eastward', 'color': '#a16207'},
          {'n': 2, 'label': 'Order No. 227', 'sub': '“Not one step back” — unauthorised retreat = death', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Blocking units & penal battalions', 'sub': 'shoot deserters; send offenders on suicidal tasks', 'color': '#3f3f46'},
      ], edge_labels=['answered by', 'enforced by'], takeaway='He stiffened the front with fear of his own side as much as fear of the enemy.', accent=AC),
      bg='By July 1942 German forces were driving toward Stalingrad and the Caucasus oilfields. Stalin believed only iron discipline could stop the rout.',
      people='The frontline soldiers caught between two fires; the <b>blocking detachments</b> posted behind them; the <b>penal battalions</b> (shtrafbats) sent to the deadliest sectors.',
      what='<b>Order No. 227</b> forbade any retreat without orders, established <b>blocking detachments</b> to shoot those who fled, and created <b>penal units</b> for offenders. Combined with reinforcement and resolve, the line held at Stalingrad.',
      crux='It fused genuine patriotism with <b>lethal coercion</b> — the Soviet soldier was to fear retreat more than death in attack.',
      conseq='It is credited with helping halt the 1942 collapse, at enormous cost in lives; it also defined the pitiless character of the Eastern Front.',
      matters='Coercion can hold a line that morale alone might not — but the price is measured in one’s own dead.'),

    E('victory', '1942–1945', 'Stalingrad to Berlin — the Great Patriotic War', ['BATTLE', 'TRIUMPH'],
      'The tide turns at Stalingrad, and the Red Army grinds its way to Berlin, breaking the bulk of the Nazi war machine. Victory makes Stalin the master of half of Europe — and a superpower.',
      svg_stack('How the USSR won the war in the East', [
          {'n': 1, 'label': 'Stalingrad (1942–43)', 'sub': 'a whole German army destroyed; the turning point', 'color': '#16a34a'},
          {'n': 2, 'label': 'Industry + manpower + Allied aid', 'sub': 'tanks in huge numbers; the West supplies material', 'color': '#3f3f46'},
          {'n': 3, 'label': 'The Red Army reaches Berlin (1945)', 'sub': 'the Eastern Front breaks the Nazis', 'color': '#b45309'},
          {'n': 4, 'label': 'Master of Eastern Europe', 'sub': 'the USSR emerges a superpower', 'color': '#7f1d1d'},
      ], takeaway='The Soviet Union bore the main weight of defeating Hitler — and Stalin cashed the victory into an empire.', accent=AC),
      bg='After surviving 1941, the USSR fought the largest and bloodiest land war in history against Nazi Germany, absorbing the majority of German military effort.',
      people='Marshal <b>Zhukov</b> and the Soviet generals; the tens of millions of Soviet dead; the wartime allies <b>Roosevelt</b> and <b>Churchill</b>, with whom Stalin bargained at Tehran and Yalta.',
      what='Victory at <b>Stalingrad (1943)</b> turned the war. The Red Army — rebuilt, hugely reinforced, and aided by Western Lend-Lease — pushed the Germans back across Eastern Europe to <b>Berlin in 1945</b>. The USSR suffered ~27 million dead but ended the war dominating Eastern Europe.',
      crux='Soviet victory came from <b>scale and sacrifice</b>: vast manpower and industry (much relocated east), immense casualties accepted, and the sheer strategic depth of Russia — orchestrated with brutal resolve.',
      conseq='Stalin emerged as one of the two dominant powers on earth, with the Red Army occupying Eastern Europe — setting up the Cold War division of the continent.',
      matters='Wars of attrition are won by depth and will as much as skill. The victory also shows how triumph in a just cause can entrench a tyrant’s power.'),

    E('deportations', '1943–1944', 'Deporting whole nations', ['TRAGEDY', 'POLITICS'],
      'Even while fighting for survival, Stalin uproots entire ethnic groups — Chechens, Crimean Tatars, Volga Germans and others — loading millions onto cattle trains to the east on charges of collective disloyalty, with vast numbers dying on the way.',
      svg_stack('Collective punishment on a national scale', [
          {'n': 1, 'label': 'Whole peoples accused', 'sub': 'entire nations branded collaborators or unreliable', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Deported in days', 'sub': 'Chechens, Ingush, Crimean Tatars, Volga Germans, others', 'color': '#3f3f46'},
          {'n': 3, 'label': 'Mass death in exile', 'sub': 'huge losses in transit and in Central Asian “special settlements”', 'color': '#71717a'},
      ], takeaway='He punished not individuals but ethnicities — erasing whole nations from their homelands.', accent=AC),
      bg='Stalin treated certain nationalities as inherently suspect. During and after the war he ordered the wholesale removal of entire ethnic groups from their historic lands.',
      people='The <b>Chechens and Ingush</b> (Feb 1944), the <b>Crimean Tatars</b> (May 1944), the <b>Volga Germans</b>, Kalmyks, Balkars and others; the NKVD that carried it out; the exiles who died by the hundreds of thousands.',
      what='Millions were <b>deported in sealed trains</b> to Central Asia and Siberia on charges of collective treason. A large fraction <b>died of cold, hunger and disease</b>; the homelands were repopulated and the names erased from maps.',
      crux='It was <b>ethnic collective punishment</b> as state policy — guilt assigned by birth, not act.',
      conseq='Many groups were only allowed home after 1956; the Crimean Tatars far later. The deportations remain open wounds across the former USSR — some now recognised as genocide.',
      matters='When a state assigns guilt by ethnicity, it licenses the destruction of entire peoples in the name of security.'),

    E('yalta', '1943–1945', 'Tehran and Yalta — carving up the postwar world', ['POLITICS', 'TRIUMPH'],
      'As victory nears, he sits as an equal with Roosevelt and Churchill at Tehran and Yalta, using the Red Army’s presence on the ground to secure Soviet dominance over Eastern Europe — winning at the conference table what his soldiers had won in the field.',
      svg_compare('Bargaining from strength',
          {'head': 'Stalin’s leverage', 'color': '#3f3f46',
           'items': ['the Red Army already occupies Eastern Europe', 'the USSR bore the main cost of beating Hitler', 'facts on the ground he can simply keep']},
          {'head': 'What he secured', 'color': '#7f1d1d',
           'items': ['a Soviet sphere across Eastern Europe', 'a divided Germany and Poland', 'recognition as a co-equal superpower']},
          verdict='He converted battlefield victory into a permanent empire, sketched out at the conference table.',
          takeaway='Possession is nine-tenths of diplomacy: his armies’ position let him dictate the postwar map.', accent=AC),
      bg='At the wartime summits of <b>Tehran (1943)</b> and <b>Yalta (1945)</b>, the “Big Three” — Stalin, <b>Roosevelt</b> and <b>Churchill</b> — shaped the postwar world.',
      people='<b>Franklin Roosevelt</b> and <b>Winston Churchill</b>; the nations of Eastern Europe whose fate was decided over their heads.',
      what='With the <b>Red Army occupying Eastern Europe</b>, Stalin negotiated from strength, securing a <b>Soviet sphere of influence</b> across the region, agreement on a divided Germany, and his status as a co-equal victor and superpower.',
      crux='He understood that <b>military facts on the ground dictate diplomacy</b>: what his armies held, he could keep, whatever the fine words of the agreements said.',
      conseq='The summits ratified a Europe split between East and West — the frontier of the coming Cold War.',
      matters='Diplomacy ratifies power more often than it constrains it. Stalin turned the Red Army’s advance into a lasting empire by treaty.'),
]

# ==================================================================  PHASE 5
PHASE_END = [
    E('coldwar', '1945–1949', 'The Iron Curtain and the Bomb', ['POLITICS', 'TURNING POINT'],
      'Victory becomes empire: he clamps communist regimes across Eastern Europe behind an “Iron Curtain,” blockades Berlin, and drives a crash programme that breaks the American nuclear monopoly in 1949 — locking the world into the Cold War.',
      svg_row('From wartime ally to Cold War rival', [
          {'n': 1, 'label': 'The Eastern Bloc', 'sub': 'communist regimes imposed across Eastern Europe', 'color': '#3f3f46'},
          {'n': 2, 'label': 'The Berlin Blockade', 'sub': 'the first great Cold War confrontation, 1948–49', 'color': '#b45309'},
          {'n': 3, 'label': 'The Soviet bomb, 1949', 'sub': 'ends the US nuclear monopoly', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He turned the lands his army had liberated into an empire — and made the USSR a nuclear rival to the US.', accent=AC),
      bg='After 1945 the wartime alliance collapsed into rivalry as Stalin consolidated Soviet control of Eastern Europe and raced to match American power.',
      people='The Eastern European communist parties installed under Soviet control; the scientists (and spies) behind the Soviet bomb; the Western powers now cast as adversaries.',
      what='Stalin installed <b>satellite regimes</b> across Eastern Europe (the “Iron Curtain”), confronted the West in the <b>Berlin Blockade (1948–49)</b>, and drove the crash project that produced the <b>Soviet atomic bomb in 1949</b>, ending the US monopoly.',
      crux='He converted the Red Army’s wartime advance into a <b>permanent sphere of empire</b> and armed the USSR to stand as the West’s equal — the architecture of the Cold War.',
      conseq='The world settled into a decades-long standoff between two nuclear-armed superpowers.',
      matters='The Cold War order was, in large part, Stalin’s creation — the direct legacy of how he cashed in his wartime victory.'),

    E('doctors', '1948–1953', 'The last paranoia — antisemitism and the Doctors’ Plot', ['TRAGEDY', 'POLITICS'],
      'In his final years his suspicion curdles into a new, antisemitic wave of terror — culminating in the fabricated “Doctors’ Plot,” a claim that Kremlin physicians were murdering the leadership, which seemed poised to trigger a fresh purge when he suddenly died.',
      svg_row('Terror gearing up one last time', [
          {'n': 1, 'label': 'Postwar repression resumes', 'sub': 'crackdowns; an antisemitic turn', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'The “Doctors’ Plot” (1953)', 'sub': 'fabricated charge that doctors are killing leaders', 'color': '#b45309'},
          {'n': 3, 'label': 'A new purge looms', 'sub': 'seemingly the prelude to fresh terror — then he dies', 'color': '#3f3f46'},
      ], edge_labels=['then', 'then'], takeaway='At the end his paranoia was spinning up another great purge — halted only by his own death.', accent=AC),
      bg='After the war Stalin’s suspicion deepened; repression resumed and took an increasingly <b>antisemitic</b> cast (the campaign against “rootless cosmopolitans”).',
      people='The persecuted Soviet Jews and doctors; the terrified inner circle who feared they might be next.',
      what='Stalin fabricated the <b>“Doctors’ Plot” (1953)</b>, alleging that mostly Jewish Kremlin physicians were murdering Soviet leaders — a charge that appeared to be the <b>opening of a new mass purge</b>, cut short only by his death that March.',
      crux='His paranoia was <b>self-generating and endless</b>: having destroyed every real rival, he manufactured new enemies, and no level of control could ever make him feel safe.',
      conseq='The looming purge dissolved with his death; the accused doctors were freed, and his terrified heirs moved to dismantle the machinery of terror.',
      matters='Terror-based rule has no stable end point. Stalin’s final plot shows a tyranny that could only keep devouring, right up to the tyrant’s last breath.'),

    E('death', '1953–1956', 'Death — and the fear that outlived him', ['DEATH', 'POLITICS'],
      'The absolute master of a superpower dies helpless on his floor, because the aides who found him are too terrified to enter his room without permission. Three years later his own successor stuns the world by denouncing his crimes.',
      svg_row('The tyrant undone by his own terror', [
          {'n': 1, 'label': 'A stroke, alone', 'sub': 'collapses; guards afraid to disturb him', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Dies untreated, 1953', 'sub': 'fear paralyses the very people who could help', 'color': '#3f3f46'},
          {'n': 3, 'label': 'Denounced, 1956', 'sub': 'Khrushchev exposes his crimes in the Secret Speech', 'color': '#64748b'},
      ], edge_labels=['then', 'then'], takeaway='The fear he built killed him: no one dared help, and within three years his own heir condemned him.', accent=AC),
      bg='By 1953 Stalin ruled a nuclear-armed superpower through a court frozen with fear, in which not even his closest aides dared act without his command.',
      people='<b>Beria</b> and the terrified inner circle; his successor <b>Nikita Khrushchev</b>; the tens of millions of victims of famine, terror and the Gulag.',
      what='Stalin suffered a <b>stroke in March 1953</b> and was reportedly <b>left for hours</b> because guards and aides feared to enter uninvited; he died soon after. In <b>1956</b>, Khrushchev’s “<b>Secret Speech</b>” denounced Stalin’s crimes and cult of personality, beginning <b>de-Stalinisation</b>.',
      crux='He had built a system so saturated with <b>fear that it paralysed everyone around him</b> — even to the point of no one daring to save his life. Total control produced total paralysis.',
      conseq='He left a nuclear superpower locked in the Cold War and a death toll in the tens of millions; his name became the byword for totalitarian terror, condemned even by his heirs.',
      matters='Absolute power builds monuments and mass graves alike. Stalin is the starkest case study in what unchecked, fear-based authority can achieve — and destroy.'),
]

OVERVIEW_HTML = """
<p class="ov-lead">Joseph Stalin rose from a beaten, impoverished childhood on the empire’s edge to become the absolute master of the Soviet Union — turning a backward peasant country into a nuclear superpower while killing tens of millions of his own people through famine, terror and the Gulag. His life is the definitive study in <b>how bureaucratic control beats brilliance, how terror sustains itself, and the monstrous price of ends-justify-means power.</b></p>
<div class="ov-quote">“Death solves all problems — no man, no problem.”<span>— attributed to Stalin; whether or not he said it, it captures his method exactly</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A poor, abused Georgian boy becomes Lenin’s useful hard man → wins power through the “boring” job of General Secretary → forces industrialisation with a man-made famine → unleashes the Great Terror → blunders into WWII then grinds out victory at colossal cost → dies a superpower ruler, later denounced for his crimes.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🗄️</div><h4>Control the machine</h4><p>He proved that in a system, whoever controls appointments and process beats those with charisma and ideas.</p></div>
  <div class="ov-card"><div class="i">🥶</div><h4>The logic of terror</h4><p>A chilling case study in how fear-based, confession-driven repression becomes self-sustaining.</p></div>
  <div class="ov-card"><div class="i">🏭</div><h4>Forced transformation</h4><p>Industrialisation and victory in WWII — bought with millions of deliberate deaths.</p></div>
  <div class="ov-card"><div class="i">⚠️</div><h4>Unaccountable power</h4><p>The starkest warning in modern history about what absolute, unchecked authority does.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Origins</b><small> 1878–1917</small><p>Gutter to Bolshevik; the ruthless outsider.</p></div>
  <div><b>2 · The Rise</b><small> 1922–1928</small><p>Winning power through the personnel file.</p></div>
  <div><b>3 · Terror</b><small> 1928–1938</small><p>Collectivisation, famine, and the Great Terror.</p></div>
  <div><b>4 · The War</b><small> 1941–1945</small><p>Barbarossa, Stalingrad, and superpower victory.</p></div>
  <div><b>5 · The End</b><small> 1945–1953</small><p>Cold War, atomic power, death, denunciation.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Lenin', 'role': 'predecessor', 'color': '#b91c1c',
     'bio': 'Founder of the Soviet state, whose machine of one-party rule and terror Stalin inherited — even as Lenin, dying, warned that Stalin was too dangerous and should be removed.',
     'rel': 'The man whose system Stalin inherited and turned deadlier still.'},
    {'name': 'Leon Trotsky', 'role': 'great rival', 'color': '#b45309',
     'bio': 'The brilliant intellectual and organiser widely expected to succeed Lenin. Stalin isolated and outvoted him, expelled him, and finally had him assassinated in Mexico in 1940.',
     'rel': 'The gifted rival that bureaucratic Stalin destroyed.'},
    {'name': 'Nikita Khrushchev', 'role': 'successor & denouncer', 'color': '#64748b',
     'bio': 'A Stalin loyalist who, after Stalin’s death, rose to power and stunned the world in 1956 by denouncing Stalin’s crimes and the “cult of personality.”',
     'rel': 'The heir who exposed him and began de-Stalinisation.'},
    {'name': 'Beria', 'role': 'secret police chief', 'color': '#3f3f46',
     'bio': 'The ruthless last head of Stalin’s secret police (NKVD), overseer of the Gulag and the terror’s final phase — arrested and shot in the power struggle after Stalin died.',
     'rel': 'The enforcer of his later repressions.'},
    {'name': 'Marshal Zhukov', 'role': 'top general', 'color': '#16a34a',
     'bio': 'The Soviet Union’s greatest WWII commander — Moscow, Stalingrad, Berlin. Stalin relied on him to win the war, then sidelined him for becoming too popular.',
     'rel': 'The general who delivered victory Stalin then feared.'},
    {'name': 'Adolf Hitler', 'role': 'partner then enemy', 'color': '#7f1d1d',
     'bio': 'Signed the 1939 pact with Stalin, then invaded the USSR in 1941. Their war on the Eastern Front was the largest and deadliest in history.',
     'rel': 'The ally-turned-invader whose defeat made Stalin a superpower.'},
    {'name': 'The kulaks & victims', 'role': 'the cost', 'color': '#991b1b',
     'bio': 'The peasants destroyed in collectivisation, the millions starved in the famine, and the countless sent to the Gulag or shot in the Terror — the human price of Stalin’s rule.',
     'rel': 'The tens of millions who paid for his transformation of the USSR.'},
]

KEY_EVENTS = [
    ('1878', 'Born in Gori, Georgia', 'Poor, beaten childhood on the empire’s edge.'),
    ('1900s', 'Revolutionary and bank-robber', 'A useful hard man for the Bolsheviks.'),
    ('1922', 'Becomes General Secretary', 'The “boring” job that becomes his power base.'),
    ('1924', 'Lenin dies', 'Stalin begins outmanoeuvring his rivals.'),
    ('1928', 'Defeats all rivals', 'Unchallenged leader; “Socialism in One Country.”'),
    ('1929–33', 'Collectivisation & famine', 'Industry funded by a man-made famine; millions die.'),
    ('1934', 'Kirov murdered', 'The pretext for mass repression.'),
    ('1936–38', 'The Great Terror', 'Show trials, executions, and the Gulag.'),
    ('1939', 'Nazi–Soviet Pact', 'A deal with Hitler that carves up Eastern Europe.'),
    ('Jun 1941', 'Operation Barbarossa', 'Germany invades; the USSR nearly collapses.'),
    ('1942–43', 'Stalingrad', 'The turning point of the war in the East.'),
    ('1945', 'Victory; master of Eastern Europe', 'The USSR emerges a superpower.'),
    ('1949', 'Soviet atomic bomb', 'The Cold War arms race begins.'),
    ('Mar 1953', 'Death', 'Dies of a stroke; his circle too afraid to help.'),
    ('1956', 'Denounced by Khrushchev', 'The “Secret Speech” exposes his crimes.'),
]

MASTER = [
    {'year': '1878', 'age': 'born', 'phase': 'Origins', 'title': 'Born in Gori', 'desc': 'Poverty and abuse on the empire’s edge.'},
    {'year': '1917', 'age': 'age 39', 'phase': 'Origins', 'title': 'A Bolshevik insider', 'desc': 'Lenin’s reliable, ruthless operative.'},
    {'year': '1922', 'age': 'age 44', 'phase': 'The Rise', 'title': 'General Secretary', 'desc': 'Builds control of the party machine.'},
    {'year': '1928', 'age': 'age 50', 'phase': 'The Rise', 'title': 'Unchallenged leader', 'desc': 'Outmanoeuvres Trotsky and all rivals.'},
    {'year': '1932', 'age': 'age 54', 'phase': 'Terror', 'title': 'Famine', 'desc': 'Collectivisation kills millions; industry grows.'},
    {'year': '1937', 'age': 'age 59', 'phase': 'Terror', 'title': 'The Great Terror', 'desc': 'Show trials, purges, the Gulag.'},
    {'year': '1941', 'age': 'age 62', 'phase': 'The War', 'title': 'Barbarossa', 'desc': 'Caught off guard; near collapse.'},
    {'year': '1943', 'age': 'age 64', 'phase': 'The War', 'title': 'Stalingrad', 'desc': 'The tide turns against Germany.'},
    {'year': '1945', 'age': 'age 66', 'phase': 'The War', 'title': 'Victory', 'desc': 'Superpower and master of Eastern Europe.'},
    {'year': '1953', 'age': 'age 74', 'phase': 'The End', 'title': 'Death', 'desc': 'Dies a superpower ruler; later denounced.'},
]

SOURCES = [
    ('Britannica — Joseph Stalin', 'https://www.britannica.com/biography/Joseph-Stalin'),
    ('World History Encyclopedia — Joseph Stalin', 'https://www.worldhistory.org/Joseph_Stalin/'),
    ('Britannica — Great Purge', 'https://www.britannica.com/event/Great-Purge'),
    ('Wikipedia — Joseph Stalin', 'https://en.wikipedia.org/wiki/Joseph_Stalin'),
]

def build_meta():
    return {
        'pid': 'gm-stalin.html', 'kind': 'man', 'emoji': '☭', 'accent': AC,
        'name': 'Joseph Stalin', 'years': '1878–1953', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'From a cobbler’s son and bank-robber to absolute ruler — he industrialised a nation, won a world war, and killed tens of millions. The starkest study in terror and unaccountable power.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'origins', 'label': '1 · Origins', 'type': 'timeline',
             'intro': 'Born poor and beaten on the empire’s edge, he becomes a hardened revolutionary and Lenin’s useful hard man — an outsider who trades brilliance for ruthlessness.', 'events': PHASE_ORIGINS},
            {'id': 'rise', 'label': '2 · The Rise', 'type': 'timeline',
             'intro': 'While rivals seek the spotlight, Stalin takes the dull job of General Secretary — and uses control of appointments to out-organise the brilliant Trotsky.', 'events': PHASE_RISE},
            {'id': 'terror', 'label': '3 · Terror', 'type': 'timeline',
             'intro': 'He forces a peasant nation to industrialise through famine, then unleashes a self-feeding machine of terror that consumes the party, the army, and ordinary people alike.', 'events': PHASE_TERROR},
            {'id': 'war', 'label': '4 · The War', 'type': 'timeline',
             'intro': 'His trust in Hitler nearly destroys the USSR — then ruthlessness and sheer scale turn catastrophe into the victory that makes him a superpower.', 'events': PHASE_WAR},
            {'id': 'end', 'label': '5 · The End', 'type': 'timeline',
             'intro': 'He builds an empire and a bomb, resumes the terror, and dies amid a circle so afraid of him that no one dares help — leaving a superpower and tens of millions dead.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Death-toll estimates vary by source and definition; historians debate the exact figures for the famine, the Terror and the Gulag. This guide reflects the mainstream scholarly consensus that the toll ran into the tens of millions.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
