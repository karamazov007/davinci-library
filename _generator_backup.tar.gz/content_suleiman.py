# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Suleiman the Magnificent (the Lawgiver)."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#854d0e'  # imperial gold

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_vienna():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1529 · why the unstoppable army finally stopped at Vienna</text>'
    rows=[('#166534','Too far from Istanbul','the march ate the campaign season; guns left behind'),
          ('#b45309','Autumn rains and mud','swollen rivers slowed the army; disease set in'),
          ('#7f1d1d','A determined defence','Vienna’s garrison held the walls until winter forced retreat')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="42" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+21}" r="9" fill="{c}"/><text x="62" y="{y+25}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+18}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+34,s,9.3,'#5b6472',500,11,78); b+=ss
        y+=50
    return _wrap(W, H, 'Vienna 1529 — the limit of empire', _tk(b, W, H, 'Not an army but distance and the calendar defeated him: Vienna marked the outer edge of Ottoman reach.'), '', AC)

def svg_preveza():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">how a land empire became master of the sea</text>'
    boxes=[(40,'#854d0e','Recruit a corsair','the pirate-admiral Barbarossa is made grand admiral'),
           (270,'#b45309','Build a war fleet','Ottoman sea power rivals Venice and Spain'),
           (500,'#166534','Preveza, 1538','the Holy League fleet beaten; the sea is Ottoman')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He turned a Barbary corsair into an admiral — and the Mediterranean into an Ottoman lake for a generation.</text>'
    return _wrap(W, H, 'Preveza — commanding the Mediterranean', _tk(b, W, H, 'He built sea power the way he built armies: by hiring the best talent, wherever it came from.'), '', AC)

def svg_lawgiver():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">why the West calls him “the Magnificent” but the East calls him “Kanuni”</text>'
    b += '<rect x="40" y="60" width="300" height="82" rx="12" fill="#f0f9ff" stroke="#0369a1" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#0369a1">Sharia — the sacred law</text>'
    s1,_=_tspans(54,100,'religious law, fixed and interpreted by scholars — but silent on much of statecraft',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="82" rx="12" fill="#fdf6e3" stroke="#854d0e" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#854d0e">Kanun — the sultan’s law</text>'
    s2,_=_tspans(394,100,'harmonised secular law on tax, land, crime and administration — a coherent code',10,'#854d0e',600,12,44); b+=s2
    b += '<line x1="340" y1="101" x2="378" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He fitted a coherent state law alongside religious law — order and fairness that outlasted him for centuries.</text>'
    return _wrap(W, H, 'The Lawgiver — codifying an empire', _tk(b, W, H, 'His lasting monument was not a conquest but a legal order that made the empire governable and fair.'), '', AC)

def svg_succession():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the tragedy that seeded the decline</text>'
    boxes=[(40,'#166534','The able heir: Mustafa','a gifted, popular son — the natural successor'),
           (270,'#7f1d1d','Harem intrigue','plots convince Suleiman his son is a threat'),
           (500,'#b45309','Mustafa strangled, 1553','the best heir dies; the weak Selim II remains')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He killed his ablest sons — and left the throne to “Selim the Sot,” opening the door to slow decline.</text>'
    return _wrap(W, H, 'The succession he ruined', _tk(b, W, H, 'The greatest sultan’s darkest act was against his own blood — and it cost the empire its future.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE GOLDEN INHERITANCE
PHASE_START = [
    E('accession', '1494–1520', 'The one heir inherits a superpower', ['RISE'],
      'The only surviving son of Selim the Grim, he inherits — without a drop of fratricidal blood — the richest, strongest empire in the world, primed by his father’s conquests and hungry for a ruler who can use it.',
      svg_stack('Inheriting the empire at its peak', [
          {'n': 1, 'label': 'Selim’s only heir', 'sub': 'succeeds in 1520 with no succession war', 'color': '#854d0e'},
          {'n': 2, 'label': 'A superpower ready-made', 'sub': 'Egypt, Syria, the holy cities already won', 'color': '#b45309'},
          {'n': 3, 'label': 'Well-educated and able', 'sub': 'a trained governor, poet and statesman', 'color': '#166534'},
      ], takeaway='He began where most conquerors end — atop a vast, secure, wealthy empire, free to make it magnificent.', accent=AC),
      bg='Selim I’s eight-year blitz had <b>tripled the empire</b> and made it the paramount power of the Muslim world. His only son, <b>Suleiman</b>, inherited it whole and secure in <b>1520</b>.',
      people='His father <b>Selim I</b>, whose conquests he inherited; his close friend and future Grand Vizier <b>Ibrahim Pasha</b>.',
      what='Educated as a prince and seasoned as a provincial governor, Suleiman came to the throne in <b>1520</b> at about 26, taking control of an empire at the height of its strength and treasury.',
      crux='He enjoyed a rare advantage: he began his reign <b>already at the summit of power</b>, so his energies went into using and refining the empire rather than merely surviving to build it.',
      conseq='He launched almost at once into a reign of conquest, law and culture that Europe would remember as “the Magnificent.”',
      matters='Inheritance shapes greatness as much as effort. Suleiman’s genius was to build brilliantly on a platform his ruthless father had already raised.'),

    E('belgrade', '1521', 'Belgrade — the gate Mehmed could not open', ['BATTLE', 'TRIUMPH'],
      'In his first campaign he takes Belgrade, the fortress-gateway to Hungary that even Mehmed the Conqueror had failed to storm — announcing that the new sultan means to march deep into Europe.',
      svg_row('Opening the road into Europe', [
          {'n': 1, 'label': 'Targets Belgrade', 'sub': 'the key fortress guarding the Danube into Hungary', 'color': '#854d0e'},
          {'n': 2, 'label': 'Takes it, 1521', 'sub': 'succeeds where Mehmed II had been repulsed', 'color': '#b45309'},
          {'n': 3, 'label': 'Hungary lies open', 'sub': 'the door to Central Europe is unlocked', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='His opening move cracked open the gateway that had stopped even the Conqueror.', accent=AC),
      bg='<b>Belgrade</b> was the great Danube fortress guarding the route from the Balkans into <b>Hungary</b> and Central Europe — a barrier that had held against earlier Ottoman assaults.',
      people='The Hungarian border defenders; the young Suleiman proving himself in his first campaign.',
      what='In <b>1521</b>, in his very first campaign as sultan, Suleiman <b>captured Belgrade</b> — a fortress Mehmed II had failed to take in 1456 — opening the road to Hungary.',
      crux='He struck first at the <b>strategic hinge</b>: with Belgrade taken, the whole Hungarian plain lay exposed to Ottoman armies.',
      conseq='The conquest set up the annihilation of Hungary five years later at Mohács, and marked Suleiman as a conqueror to match his ancestors.',
      matters='A reign is announced by its first move. Suleiman opened his by breaking a barrier that had defied the Conqueror himself.'),

    E('rhodes', '1522', 'Rhodes — finishing his ancestor’s unfinished war', ['BATTLE', 'TRIUMPH'],
      'He besieges Rhodes and, after a brutal five-month siege, expels the Knights Hospitaller — the crusading order that had humiliated Mehmed II — clearing the eastern Mediterranean of a dangerous thorn.',
      svg_row('Taking the fortress that beat Mehmed', [
          {'n': 1, 'label': 'Besieges Rhodes', 'sub': 'the Knights Hospitaller’s island fortress', 'color': '#854d0e'},
          {'n': 2, 'label': 'A five-month siege', 'sub': 'costly assaults grind down the defenders', 'color': '#b45309'},
          {'n': 3, 'label': 'Knights expelled, 1522', 'sub': 'they withdraw (later to Malta)', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He avenged Mehmed’s failure and cleared a corsair-nest from his sea lanes — a foe he would meet again at Malta.', accent=AC),
      bg='The island of <b>Rhodes</b>, held by the <b>Knights Hospitaller</b>, controlled key eastern Mediterranean sea lanes and had repelled Mehmed II in 1480.',
      people='The Grand Master <b>Philippe Villiers de L’Isle-Adam</b> and his Knights; Suleiman, matching himself against his great-grandfather’s failure.',
      what='In <b>1522</b> Suleiman besieged Rhodes for about five months and forced the <b>Knights to surrender and evacuate</b> — a costly but complete success where Mehmed II had failed.',
      crux='He was willing to pay a <b>high price for a strategic and symbolic prize</b>: clearing his sea lanes and outdoing his illustrious ancestor.',
      conseq='The Knights relocated to <b>Malta</b> — where, decades later, they would famously halt Suleiman’s own forces in the great siege of 1565.',
      matters='Old enemies have a way of returning. The Knights Suleiman drove from Rhodes became the wall that stopped him at Malta.'),
]

# ==================================================================  PHASE 2 — THE HAMMER OF EUROPE
PHASE_EUROPE = [
    E('mohacs', '1526', 'Mohács — the annihilation of Hungary', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'On the field of Mohács he destroys the Hungarian army in under two hours; the king drowns fleeing, the nobility is wiped out, and a great Christian kingdom simply ceases to exist as an independent power.',
      svg_row('A kingdom destroyed in an afternoon', [
          {'n': 1, 'label': 'Meets Hungary’s army', 'sub': 'King Louis II gives battle on open ground', 'color': '#854d0e'},
          {'n': 2, 'label': 'Guns and Janissaries', 'sub': 'artillery and disciplined infantry break the charge', 'color': '#b45309'},
          {'n': 3, 'label': 'Hungary destroyed', 'sub': 'King Louis dies fleeing; the realm collapses', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='In one short battle he erased a medieval kingdom and pushed the empire into the heart of Europe.', accent=AC),
      bg='The Kingdom of <b>Hungary</b> was the great Christian bulwark of Central Europe. Its young king <b>Louis II</b> gathered a feudal army to stop the Ottoman advance.',
      people='<b>King Louis II</b> of Hungary, who died in the rout; the Hungarian nobility, largely destroyed; Suleiman and his artillery.',
      what='At the <b>Battle of Mohács (1526)</b>, Ottoman <b>artillery and Janissary firepower</b> annihilated the Hungarian army in a couple of hours; King Louis drowned fleeing, and the Hungarian state effectively collapsed.',
      crux='He again won by <b>combined firepower and discipline</b> over feudal cavalry — but the deeper effect was political: the destruction of Hungary’s ruling class left a power vacuum.',
      conseq='Hungary was partitioned between the Ottomans, a vassal Transylvania, and the Habsburgs — beginning a long Ottoman-Habsburg struggle for Central Europe.',
      matters='A single battle can delete a nation. Mohács remains a national trauma for Hungary and a hinge of European history.'),

    E('vienna', '1529', 'Vienna — the tide reaches its limit', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'He marches on Vienna itself, the Habsburg capital — and there, far from home and beaten by autumn mud and a stubborn garrison, the unstoppable Ottoman tide meets its high-water mark and recedes.',
      svg_vienna(),
      bg='After Mohács, Suleiman pressed on toward <b>Vienna</b>, capital of the <b>Habsburgs</b> under Archduke Ferdinand (brother of Emperor Charles V) — the deepest thrust into Europe the Ottomans would attempt.',
      people='Archduke <b>Ferdinand</b> and the defenders of Vienna; Emperor <b>Charles V</b>, Suleiman’s great western rival.',
      what='In <b>1529</b> Suleiman besieged <b>Vienna</b>, but the enormous distance from Istanbul, <b>autumn rains</b> that bogged down his heavy artillery, disease, and a determined defence forced him to abandon the siege as winter closed in.',
      crux='He hit the <b>logistical limit of empire</b>: Vienna lay at the very edge of what an army marching from Istanbul in a single campaign season could reach and supply.',
      conseq='Vienna marked the <b>furthest extent</b> of the Ottoman advance into Europe; the Ottoman-Habsburg frontier would seesaw here for over a century.',
      matters='Every empire has a reach beyond which it cannot strike. Vienna 1529 defined the outer boundary of Ottoman power in Europe.'),

    E('habsburg', '1530s–1560s', 'The world-duel with the Habsburgs', ['POLITICS', 'BATTLE'],
      'His reign becomes a global chess match with Emperor Charles V for mastery of Europe and the Mediterranean — fought from Hungary to North Africa, and even in a startling alliance with Catholic France against a fellow Christian power.',
      svg_compare('The two superpowers of the age',
          {'head': 'Suleiman’s Ottomans', 'color': '#854d0e',
           'items': ['Hungary, the Balkans, the Middle East', 'the Mediterranean fleet under Barbarossa', 'allied with France against the Habsburgs']},
          {'head': 'Charles V’s Habsburgs', 'color': '#0369a1',
           'items': ['Spain, Austria, the Low Countries, the Americas', 'defends Vienna and Italy', 'leads Christian Holy Leagues at sea']},
          verdict='Two universal empires, each claiming to be the true heir of Rome, deadlocked across a continent.',
          takeaway='He treated all Europe as one board — even allying with Catholic France to keep the Habsburgs off balance.', accent=AC),
      bg='The <b>Habsburgs</b> under <b>Charles V</b> — ruling Spain, Austria, the Low Countries and the Americas — were the Ottomans’ mirror-image rival for European and Mediterranean supremacy.',
      people='Emperor <b>Charles V</b> and his brother <b>Ferdinand</b>; King <b>Francis I of France</b>, Suleiman’s surprising ally against the Habsburgs.',
      what='Suleiman waged a decades-long, continent-spanning struggle with the Habsburgs — over Hungary, Italy and the Mediterranean — and formed a pragmatic <b>Franco-Ottoman alliance</b> with Francis I, shocking Christendom.',
      crux='He practised <b>grand strategy on a global scale</b>, using diplomacy (even with a Christian king) and multiple theatres to stretch and pressure his rival everywhere at once.',
      conseq='The rivalry ended in a rough stalemate that fixed the religious and political map of Central Europe and the Mediterranean for generations.',
      matters='The greatest powers fight not one war but many at once, with diplomacy as sharp a weapon as armies. Suleiman was a master of both.'),

    E('buda', '1541', 'Swallowing Hungary — the occupation of Buda', ['BATTLE', 'TRIUMPH', 'POLITICS'],
      'Years after Mohács, he completes Hungary’s dismemberment: he occupies its capital Buda and annexes central Hungary directly into the empire, turning a great Christian kingdom into an Ottoman province and a permanent frontier of religious war with the Habsburgs.',
      svg_row('From battlefield victory to annexation', [
          {'n': 1, 'label': 'Occupies Buda, 1541', 'sub': 'the Hungarian capital taken directly', 'color': '#854d0e'},
          {'n': 2, 'label': 'Central Hungary annexed', 'sub': 'made an Ottoman province', 'color': '#b45309'},
          {'n': 3, 'label': 'A partitioned kingdom', 'sub': 'Ottoman centre, Habsburg west, vassal Transylvania', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He converted the ruin of Mohács into permanent conquest — central Hungary became Ottoman for 150 years.', accent=AC),
      bg='After Mohács destroyed the Hungarian army, control of Hungary was contested between the Ottomans, the Habsburgs and local claimants.',
      people='The Habsburgs contesting Hungary; the vassal princes of <b>Transylvania</b>; the people of Buda.',
      what='In <b>1541</b> Suleiman <b>occupied Buda</b> and <b>annexed central Hungary</b> directly into the empire, partitioning the old kingdom into an Ottoman core, a Habsburg-held west, and a vassal <b>Transylvania</b>.',
      crux='He turned <b>battlefield victory into durable territorial control</b>, making Hungary a directly ruled Ottoman land and a fortified frontier.',
      conseq='Central Hungary remained Ottoman for about 150 years, the front line of the long Ottoman-Habsburg struggle.',
      matters='Conquest is completed by administration, not just battle. Suleiman’s annexation of Buda made his Hungarian victory permanent.'),

    E('ibrahim', '1523–1536', 'The favourite who rose too high — Ibrahim Pasha', ['POLITICS', 'TRAGEDY'],
      'His closest friend becomes the second man in the empire: Ibrahim, raised from slave to Grand Vizier, wields almost royal power — until his growing arrogance and the intrigues of the court turn Suleiman against him, and one morning the favourite is found strangled, a chilling lesson in how fast Ottoman favour could turn to death.',
      svg_row('The meteoric rise and sudden fall of a favourite', [
          {'n': 1, 'label': 'Slave to Grand Vizier', 'sub': 'Ibrahim raised to near-royal power', 'color': '#854d0e'},
          {'n': 2, 'label': 'Grows overmighty', 'sub': 'arrogance and court intrigue turn the sultan', 'color': '#b45309'},
          {'n': 3, 'label': 'Strangled, 1536', 'sub': 'the favourite executed without warning', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='The empire’s second man rose from slavery to near-kingship — and was strangled the moment he became a risk.', accent=AC),
      bg='<b>Ibrahim Pasha</b>, Suleiman’s boyhood friend, rose from slavery to become an unusually powerful Grand Vizier and the sultan’s intimate.',
      people='<b>Ibrahim Pasha</b>; the rival court faction (including <b>Hurrem</b>) that worked against him.',
      what='Ibrahim wielded <b>immense, near-royal power</b> for over a decade — but his growing arrogance, and court intrigue, turned Suleiman against him, and in <b>1536</b> the sultan had his old friend <b>strangled</b> in the palace.',
      crux='It showed the <b>terrifying conditionality of Ottoman favour</b>: even the sultan’s closest friend, raised to the heights, could be destroyed in an instant.',
      conseq='Ibrahim’s fall reshaped court politics and demonstrated that no one, however favoured, was safe.',
      matters='Proximity to absolute power is perilous. Ibrahim’s rise and sudden death is the classic Ottoman parable of favour’s fatal edge.'),

    E('france', '1536', 'The scandalous alliance — the Sultan and the King of France', ['POLITICS', 'TURNING POINT'],
      'He shocks Christendom with a piece of pure realpolitik: an open alliance with Catholic France against their common Habsburg enemy, complete with trade privileges (the "Capitulations") and even joint naval operations — proving that in the game of power, faith bows to interest.',
      svg_row('When faith gave way to interest', [
          {'n': 1, 'label': 'A common enemy', 'sub': 'both fear Habsburg domination of Europe', 'color': '#854d0e'},
          {'n': 2, 'label': 'Muslim-Christian alliance', 'sub': 'Suleiman and Francis I align openly', 'color': '#0369a1'},
          {'n': 3, 'label': 'The Capitulations', 'sub': 'trade privileges; even joint fleets', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='He allied with a Christian king against a Christian emperor — realpolitik over religion, centuries early.', accent=AC),
      bg='Both Suleiman and King <b>Francis I of France</b> feared <b>Habsburg</b> domination of Europe, giving the Muslim sultan and Catholic king a shared enemy.',
      people='King <b>Francis I of France</b>; the Habsburg <b>Charles V</b>, the common adversary; the French merchants who won trading rights.',
      what='Suleiman formed an open <b>alliance with Catholic France</b> against the Habsburgs — granting France the <b>Capitulations (trade privileges)</b>, coordinating strategy, and even mounting <b>joint naval operations</b> — a stunning subordination of religion to power politics.',
      crux='He treated diplomacy as pure <b>interest over ideology</b>, willing to ally across the great religious divide to check a common rival.',
      conseq='The Franco-Ottoman alliance endured for generations and the Capitulations shaped Ottoman-European trade for centuries.',
      matters='Realpolitik is old. Suleiman’s alliance with Christian France against a Christian emperor is a founding example of interest trumping ideology.'),

    E('vienna1532', '1532', 'The second thrust — the campaign that fizzled', ['BATTLE', 'DEFEAT'],
      'Three years after his failure at Vienna, he tries again — a massive campaign meant to draw the Habsburg emperor into a decisive battle — but a small fortress at Kőszeg delays him for weeks, the season runs out, and Charles V refuses to give battle, confirming that the road to Vienna was closed for good.',
      svg_row('A second try, blunted again', [
          {'n': 1, 'label': 'A huge new campaign', 'sub': 'aims to force a decisive battle with Charles V', 'color': '#854d0e'},
          {'n': 2, 'label': 'Held up at Kőszeg', 'sub': 'a tiny fortress delays him for weeks', 'color': '#b45309'},
          {'n': 3, 'label': 'Charles won’t fight', 'sub': 'the season ends; no battle; Suleiman withdraws', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='His second bid for central Europe stalled at a tiny fort — confirming Vienna as the limit of his reach.', accent=AC),
      bg='Determined to avenge 1529, Suleiman launched a second great campaign in <b>1532</b> aimed at central Europe and a decisive clash with Charles V.',
      people='The garrison of <b>Kőszeg</b> that delayed him; Emperor <b>Charles V</b>, who declined battle.',
      what='In <b>1532</b> Suleiman’s huge army was <b>delayed for weeks by the small fortress of Kőszeg</b>; the campaigning season ran out and <b>Charles V refused a decisive battle</b>, so Suleiman withdrew without taking Vienna.',
      crux='It reconfirmed the <b>logistical limit</b> exposed in 1529: central Europe lay just beyond the reach of an army marching each year from Istanbul.',
      conseq='The Ottoman-Habsburg frontier in Hungary hardened; Vienna would not be seriously threatened again until 1683.',
      matters='Limits, once found, tend to hold. Suleiman’s second failure before Vienna fixed the outer boundary of Ottoman Europe for 150 years.'),
]

# ==================================================================  PHASE 3 — LORD OF THE SEAS AND THE EAST
PHASE_SEAS = [
    E('preveza', '1533–1538', 'Barbarossa and the mastery of the sea', ['BATTLE', 'TRIUMPH'],
      'A land empire becomes a sea power almost overnight: he makes the fearsome corsair Barbarossa his grand admiral, builds a great fleet, and at Preveza in 1538 smashes a combined Christian armada — turning the Mediterranean into an Ottoman lake.',
      svg_preveza(),
      bg='The Ottomans were a land power, but Mediterranean supremacy required a fleet to rival <b>Venice</b> and <b>Habsburg Spain</b>. Suleiman turned to the Barbary corsairs.',
      people='<b>Hayreddin Barbarossa</b>, the corsair Suleiman made <b>Kapudan Pasha</b> (grand admiral); the Genoese admiral <b>Andrea Doria</b>, who led the Christian fleet.',
      what='Suleiman recruited <b>Barbarossa</b>, built a powerful navy, and at the <b>Battle of Preveza (1538)</b> defeated the combined fleet of the Christian <b>Holy League</b>, establishing Ottoman naval dominance in the eastern and central Mediterranean.',
      crux='He built sea power the way he built everything — by <b>recruiting the best available talent regardless of origin</b>, turning a pirate into the admiral of an imperial fleet.',
      conseq='For roughly a generation the Ottomans dominated the Mediterranean; their reach extended along the North African coast.',
      matters='Talent beats pedigree. Suleiman’s willingness to elevate an outsider corsair won him command of the sea.'),

    E('corsairs', '1530s–1560s', 'The Barbary coast — an empire of corsairs', ['BATTLE', 'POLITICS'],
      'His sea power rests on an unlikely alliance: the ferocious Barbary corsairs of North Africa, who under Ottoman flags seize Algiers, Tunis and Tripoli, raid the coasts of Italy and Spain, and carry off tens of thousands of Christian captives — extending Suleiman’s reach across the whole southern Mediterranean.',
      svg_row('Ruling the sea through the corsairs', [
          {'n': 1, 'label': 'Ally with the Barbary corsairs', 'sub': 'Barbarossa and his captains under Ottoman flags', 'color': '#854d0e'},
          {'n': 2, 'label': 'Seize North African ports', 'sub': 'Algiers, Tunis, Tripoli become Ottoman bases', 'color': '#b45309'},
          {'n': 3, 'label': 'Raid Christian coasts', 'sub': 'terror and captives across Italy and Spain', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He extended his empire across the southern Mediterranean through the fearsome Barbary corsairs.', accent=AC),
      bg='The <b>Barbary corsairs</b> of North Africa, formidable raiders, became the instrument of Ottoman power in the western Mediterranean.',
      people='<b>Barbarossa</b> and his corsair captains; the peoples of the North African ports; the coastal populations of Christian Europe.',
      what='Under Suleiman, the <b>Barbary corsairs</b> — flying Ottoman colours — seized <b>Algiers, Tunis and Tripoli</b>, raided the coasts of <b>Italy and Spain</b>, and took tens of thousands of captives, projecting Ottoman power across the southern Mediterranean.',
      crux='He harnessed <b>semi-independent sea-raiders as an arm of empire</b>, extending Ottoman reach far beyond what a conventional fleet could hold.',
      conseq='North Africa came under Ottoman suzerainty, and Christian Mediterranean shipping lived under the corsair threat for generations.',
      matters='Empire can be projected through proxies. Suleiman’s corsair alliance shows power extended by co-opting the fearsome men on its edges.'),

    E('indianocean', '1538–1560s', 'The forgotten front — the Indian Ocean and the Portuguese', ['BATTLE', 'DEFEAT'],
      'His ambitions reach an ocean away: to break the Portuguese stranglehold on the spice trade, he sends Ottoman fleets from the Red Sea into the Indian Ocean — besieging Diu in India, campaigning to Aden and the Gulf — a remarkable global reach that ultimately fails to dislodge the Portuguese but marks the Ottomans as a world power.',
      svg_row('A global bid for the spice routes', [
          {'n': 1, 'label': 'Portuguese control the spice trade', 'sub': 'their bases choke the Indian Ocean routes', 'color': '#854d0e'},
          {'n': 2, 'label': 'Ottoman fleets sail east', 'sub': 'from the Red Sea; the siege of Diu (1538)', 'color': '#b45309'},
          {'n': 3, 'label': 'A checked, global reach', 'sub': 'fails to oust the Portuguese, but spans the world', 'color': '#7f1d1d'},
      ], edge_labels=['so', 'then'], takeaway='He fought the Portuguese an ocean away — a global reach unmatched by any Ottoman before or after.', accent=AC),
      bg='The <b>Portuguese</b> had seized the Indian Ocean spice routes, threatening the trade wealth of Suleiman’s Muslim world.',
      people='The Ottoman admirals of the Red Sea fleets; the Portuguese defenders of <b>Diu</b> and their Indian Ocean bases.',
      what='Suleiman dispatched Ottoman fleets from the <b>Red Sea into the Indian Ocean</b> to challenge Portugal — including the <b>siege of Diu (1538)</b> in India and campaigns toward Aden and the Gulf — a vast reach that ultimately <b>failed to dislodge the Portuguese</b>.',
      crux='He contested a <b>global trade war thousands of miles from home</b>, showing the Ottomans as a world power even where they could not win.',
      conseq='The Portuguese kept their grip on the ocean routes, but the Ottomans secured the Red Sea and the pilgrimage lanes.',
      matters='The Ottoman-Portuguese struggle is early global history. Suleiman’s Indian Ocean campaigns show his empire reaching across the world.'),

    E('baghdad', '1533–1555', 'The eastern front — Baghdad and Persia', ['BATTLE', 'TRIUMPH'],
      'While duelling the Habsburgs in the west, he also wars with Safavid Persia in the east, taking Baghdad and Iraq and, by the Peace of Amasya, fixing a frontier between the Sunni and Shia empires that broadly survives as a border today.',
      svg_row('Winning the war on the other frontier', [
          {'n': 1, 'label': 'Wars with the Safavids', 'sub': 'renews his father’s eastern struggle', 'color': '#854d0e'},
          {'n': 2, 'label': 'Takes Baghdad, 1534', 'sub': 'adds Iraq and the shrine cities to the empire', 'color': '#b45309'},
          {'n': 3, 'label': 'Peace of Amasya, 1555', 'sub': 'fixes the Ottoman-Persian frontier', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He fought a two-front empire and won lasting gains on both — Baghdad in the east, Hungary in the west.', accent=AC),
      bg='To the east lay <b>Safavid Persia</b>, the Shia rival his father Selim had beaten at Chaldiran. The frontier and the great city of <b>Baghdad</b> remained contested.',
      people='The Safavid Shah <b>Tahmasp I</b>; Suleiman’s commanders on the eastern campaigns.',
      what='Suleiman campaigned repeatedly against Persia, <b>capturing Baghdad in 1534</b> and adding Iraq, and finally concluded the <b>Peace of Amasya (1555)</b>, which stabilised the frontier between the two empires.',
      crux='He managed the extraordinary strain of <b>fighting on two distant fronts at once</b> — Habsburgs in the west, Safavids in the east — without collapse, a mark of the empire’s depth under him.',
      conseq='The Ottoman-Safavid border set by Amasya broadly foreshadows the modern Turkey-Iran-Iraq frontier region.',
      matters='Sustaining war on two fronts is one of the hardest tests of a state. Suleiman’s empire passed it at its zenith.'),

    E('malta', '1565', 'Malta — the old enemy holds the line', ['BATTLE', 'DEFEAT'],
      'Near the end of his reign he sends a vast armada to crush the Knights he had expelled from Rhodes — now dug in on Malta — but in one of history’s most famous sieges the Knights hold, and the Ottoman tide is checked at sea as it was at Vienna on land.',
      svg_row('The siege the Knights survived', [
          {'n': 1, 'label': 'Armada to Malta', 'sub': 'a huge force to destroy the Knights Hospitaller', 'color': '#854d0e'},
          {'n': 2, 'label': 'A brutal summer siege', 'sub': 'the tiny garrison holds against terrible odds', 'color': '#b45309'},
          {'n': 3, 'label': 'Relief and retreat', 'sub': 'a Christian relief force arrives; the Ottomans withdraw', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='The enemy he spared at Rhodes became the wall that halted his navy — his Vienna at sea.', accent=AC),
      bg='The <b>Knights Hospitaller</b>, expelled from Rhodes in 1522, had fortified <b>Malta</b>, a strategic island commanding the central Mediterranean.',
      people='The Grand Master <b>Jean de Valette</b>, who led the heroic defence; the Ottoman commanders of the great armada.',
      what='In <b>1565</b> Suleiman launched the <b>Great Siege of Malta</b>. Despite overwhelming numbers, the Ottomans failed to take the island; the Knights held until a relief force arrived, and the fleet withdrew.',
      crux='Like Vienna, Malta exposed the <b>limits of Ottoman power at the far edge of its reach</b> — and the ferocious resilience of a determined, well-fortified defender.',
      conseq='Malta remained Christian and became a symbol of resistance; Ottoman Mediterranean dominance began, slowly, to be contested.',
      matters='Mercy shown to a beaten foe can return as an obstacle. The Knights spared at Rhodes stopped Suleiman’s navy at Malta.'),
]

# ==================================================================  PHASE 4 — THE LAWGIVER AND THE GOLDEN AGE
PHASE_LAW = [
    E('kanun', '1520s–1560s', 'The Lawgiver — an empire under law', ['REFORM', 'TRIUMPH'],
      'To his own people he is not “the Magnificent” but “Kanuni” — the Lawgiver — because his most lasting achievement was not a conquest but a coherent body of secular law, fitted alongside the sacred law, that made a sprawling empire governable and, for its age, remarkably fair.',
      svg_lawgiver(),
      bg='A vast, multi-ethnic empire needed clear, workable rules on <b>taxation, land tenure, crime and administration</b> — matters on which religious law (sharia) was often silent or unsettled.',
      people='The chief jurist (<b>Şeyhülislam</b>) <b>Ebussuud Efendi</b>, who helped harmonise sultanic and religious law; the empire’s administrators and subjects.',
      what='Suleiman oversaw the systematic revision and codification of the <b>kanun</b> (sultanic secular law), harmonised with <b>sharia</b>, producing a coherent legal order covering the whole empire and curbing arbitrary abuses.',
      crux='He grasped that <b>durable power rests on law and administration, not just conquest</b> — and that a fair, predictable legal order binds a diverse empire together.',
      conseq='His legal framework governed the Ottoman Empire for centuries; his name, “Kanuni,” honours the lawgiver above the warrior.',
      matters='The deepest legacy of the greatest rulers is often institutional, not territorial. Suleiman’s law outlasted every one of his conquests.'),

    E('goldenage', '1520s–1560s', 'The golden age — Sinan, poetry, and Roxelana', ['REFORM', 'TRIUMPH'],
      'His court becomes the summit of Ottoman civilisation: the architect Sinan raises the sublime Süleymaniye mosque, the sultan himself writes poetry, and his beloved wife Hurrem — Roxelana — rises from slave to empress, transforming the very nature of the palace.',
      svg_stack('The height of Ottoman civilisation', [
          {'n': 1, 'label': 'Mimar Sinan', 'sub': 'the master architect; the Süleymaniye mosque', 'color': '#854d0e'},
          {'n': 2, 'label': 'A poet-sultan', 'sub': 'Suleiman writes verse under the name “Muhibbi”', 'color': '#b45309'},
          {'n': 3, 'label': 'Hurrem (Roxelana)', 'sub': 'a slave who became his wife and political partner', 'color': '#be185d'},
      ], takeaway='Under him the empire reached its cultural zenith — in stone, in verse, and in a court transformed by an extraordinary woman.', accent=AC),
      bg='Wealth from conquest and stable government funded an unprecedented flowering of <b>architecture, art, poetry and law</b> — the classical age of Ottoman culture.',
      people='The architect <b>Mimar Sinan</b>; the sultan-poet <b>“Muhibbi”</b> (Suleiman himself); his wife <b>Hurrem Sultan (Roxelana)</b>, who broke every rule of the harem.',
      what='Suleiman patronised the genius architect <b>Sinan</b> (the <b>Süleymaniye</b> and countless other works), wrote accomplished poetry, and <b>married Hurrem</b>, a former slave who became his consort and a powerful political actor — beginning the era of influential royal women.',
      crux='He understood that a great empire must be <b>magnificent as well as powerful</b> — that art, architecture and learning are instruments of prestige and legitimacy.',
      conseq='The buildings, poetry and courtly culture of his reign defined Ottoman identity; Hurrem’s rise began the so-called “Sultanate of Women.”',
      matters='Power and beauty reinforce each other. Suleiman’s age is remembered as much for Sinan’s domes as for his armies.'),

    E('roxelana', '1520s–1558', 'Roxelana — the slave who became an empress', ['POLITICS', 'TURNING POINT'],
      'She breaks every rule of the harem: a captured slave girl, Hurrem — Roxelana to Europe — wins Suleiman’s heart so completely that he marries her, keeps her at his side against all custom, and lets her become a genuine political power, founding the era of influential royal women that historians call the "Sultanate of Women."',
      svg_row('From concubine to political power', [
          {'n': 1, 'label': 'A captured slave', 'sub': 'enters the harem as a concubine', 'color': '#be185d'},
          {'n': 2, 'label': 'Suleiman marries her', 'sub': 'unheard-of; she becomes legal wife and confidante', 'color': '#854d0e'},
          {'n': 3, 'label': 'A power behind the throne', 'sub': 'shapes politics and the succession', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'so'], takeaway='A slave girl rose to be Suleiman’s wife and a real political force — beginning the "Sultanate of Women."', accent=AC),
      bg='Ottoman sultans traditionally did not marry their concubines or let them wield political power. Hurrem shattered both conventions.',
      people='<b>Hurrem Sultan (Roxelana)</b>; her son-in-law and ally the Grand Vizier <b>Rüstem Pasha</b>; the rivals she outmanoeuvred (including Ibrahim and Mustafa).',
      what='<b>Hurrem</b>, a slave concubine, so captivated Suleiman that he <b>married her</b> and kept her beside him, and she became a real <b>political actor</b> — influencing appointments, diplomacy and the succession — launching the era of powerful royal women.',
      crux='She converted <b>intimacy into genuine political power</b>, an unprecedented role for a woman in the Ottoman system, reshaping court politics.',
      conseq='Her influence, and that of later royal women, became a lasting feature of Ottoman government — for better and worse.',
      matters='Power can flow through unexpected channels. Roxelana’s rise from slave to empress is one of history’s most remarkable, and consequential, love stories.'),

    E('lawdetail', '1530s–1560s', 'The fabric of the law — land, crime, and the millets', ['REFORM', 'TRIUMPH'],
      'His law-code reaches into every corner of the empire: rationalising land tenure and taxation, curbing arbitrary and cruel punishments, protecting subjects from official abuse, and formalising the millet system by which each religious community governs its own affairs — a body of secular law, harmonised with sharia, that held the empire together for centuries.',
      svg_stack('A coherent legal order for a diverse empire', [
          {'n': 1, 'label': 'Land and tax law', 'sub': 'rational, recorded rules on tenure and revenue', 'color': '#854d0e'},
          {'n': 2, 'label': 'Curb arbitrary cruelty', 'sub': 'limits on punishments; protection from official abuse', 'color': '#0369a1'},
          {'n': 3, 'label': 'The millet system', 'sub': 'each faith governs its own community affairs', 'color': '#166534'},
      ], takeaway='His code touched land, crime and community life — a working legal order that made the empire govern itself fairly for its age.', accent=AC),
      bg='Suleiman’s <b>kanun</b> was not an abstraction but a detailed, practical body of law reaching land, taxation, crime and community organisation.',
      people='The chief jurist <b>Ebussuud Efendi</b>; the subjects of every faith governed under the millet system.',
      what='Suleiman’s codified law <b>rationalised land tenure and taxation</b>, <b>curbed arbitrary and cruel punishments</b>, protected subjects from official abuse, and formalised the <b>millet system</b> of communal self-government — all harmonised with sharia.',
      crux='He made the empire <b>governable and, for its age, remarkably fair</b> through detailed, coherent secular law, not just decree or force.',
      conseq='This legal fabric endured for centuries, the true foundation of Ottoman stability and Suleiman’s title "Lawgiver."',
      matters='The deepest institutions are legal. Suleiman’s detailed law-code, more than any battle, is why his own people called him the Lawgiver.'),
]

# ==================================================================  PHASE 5 — TRAGEDY AND DEATH
PHASE_END = [
    E('sons', '1553–1561', 'The sons he destroyed', ['TRAGEDY', 'POLITICS'],
      'The greatest sultan’s darkest chapter is against his own blood: manipulated by harem politics, he has his gifted, popular heir Mustafa strangled, and later a second son killed — leaving the throne to the weak, pleasure-loving Selim, and planting the seed of decline.',
      svg_succession(),
      bg='Suleiman had several sons by different women; the succession became entangled in the rivalries of the harem, especially around <b>Hurrem</b> and her son-in-law, the Grand Vizier <b>Rüstem Pasha</b>.',
      people='His able eldest son <b>Şehzade Mustafa</b>, strangled in 1553; his son <b>Bayezid</b>, later killed after fleeing to Persia; the surviving heir <b>Selim II</b>, “the Sot.”',
      what='Convinced (through court intrigue) that <b>Mustafa</b> threatened his throne, Suleiman had him <b>strangled in 1553</b>; a later civil conflict led to the execution of another son, <b>Bayezid</b> (1561), leaving <b>Selim II</b> as sole heir.',
      crux='In protecting his throne he <b>eliminated his most capable successors</b> — a decision driven by fear and intrigue that sacrificed the empire’s future to short-term security.',
      conseq='The uninspiring <b>Selim II</b> inherited the throne in 1566, and historians often date the slow beginning of Ottoman decline to this ruined succession.',
      matters='Even great rulers can be blinded by fear and faction. Suleiman’s worst act was against his own children — and it cost the empire dearly.'),

    E('economy', '1520s–1560s', 'The empire at its zenith — wealth, trade, and reach', ['REFORM', 'TRIUMPH'],
      'At his height he rules perhaps the most powerful state on earth: astride the great trade routes between Europe, Asia and Africa, its treasury swollen by Egyptian grain and the customs of three continents, its capital Istanbul the largest city in Europe — a superpower whose wealth funded both his wars and his golden age.',
      svg_row('A superpower economy spanning three continents', [
          {'n': 1, 'label': 'Astride the trade routes', 'sub': 'controls the crossroads of Europe, Asia and Africa', 'color': '#854d0e'},
          {'n': 2, 'label': 'A vast treasury', 'sub': 'Egyptian grain, three continents’ customs revenue', 'color': '#0369a1'},
          {'n': 3, 'label': 'Istanbul, Europe’s greatest city', 'sub': 'a teeming metropolis at the empire’s heart', 'color': '#166534'},
      ], edge_labels=['so', 'so'], takeaway='He ruled perhaps the richest, most powerful state on earth — the wealth behind both his wars and his splendour.', accent=AC),
      bg='Under Suleiman the empire sat at the <b>crossroads of world trade</b>, drawing revenue from three continents.',
      people='The merchants of the empire and its trading partners; the population of <b>Istanbul</b>, the largest city in Europe.',
      what='At its zenith, Suleiman’s empire <b>controlled the great trade routes</b> linking Europe, Asia and Africa, drew immense revenue from <b>Egyptian grain and customs</b>, and centred on <b>Istanbul</b>, then the largest city in Europe — arguably the most powerful state of its day.',
      crux='His conquests translated into <b>economic supremacy</b>: control of the trade crossroads made the empire fabulously rich, funding both war and culture.',
      conseq='This wealth underwrote the golden age of art and law — and masked the structural strains that would show under weaker successors.',
      matters='Behind the armies and mosques lay an economy at its peak. Suleiman’s empire was, in his day, one of the richest and most powerful on earth.'),

    E('theman', '1494–1566', 'The man behind the titles — poet, goldsmith, and melancholy king', ['POLITICS', 'TRAGEDY'],
      'Behind "the Magnificent" and "the Lawgiver" was a complex human being: a skilled goldsmith by training, a gifted poet who wrote tender verse to Hurrem under the name "Muhibbi," and, in his final years, an increasingly pious, lonely and melancholy old man, worn by the killing of his own sons and the deaths of those he loved.',
      svg_stack('The private man inside the legend', [
          {'n': 1, 'label': 'Craftsman and poet', 'sub': 'a trained goldsmith; writes verse as “Muhibbi”', 'color': '#854d0e'},
          {'n': 2, 'label': 'Devoted, then bereaved', 'sub': 'his love for Hurrem; grief at her death', 'color': '#be185d'},
          {'n': 3, 'label': 'A melancholy old age', 'sub': 'pious, lonely, worn by the loss of his sons', 'color': '#475569'},
      ], takeaway='The most magnificent of sultans was, at the last, a grieving, devout old poet worn down by his own hard choices.', accent=AC),
      bg='For all his public grandeur, Suleiman was a cultivated, introspective man whose long reign brought private sorrows as well as triumphs.',
      people='His beloved wife <b>Hurrem</b>, whose death grieved him deeply; the sons he had destroyed; the poets and craftsmen of his court.',
      what='Suleiman was trained as a <b>goldsmith</b>, wrote accomplished <b>poetry</b> under the pen-name <b>“Muhibbi,”</b> loved Hurrem devotedly — and in his last years grew <b>pious, lonely and melancholy</b>, worn by the executions of his sons and the deaths of those closest to him.',
      crux='Behind the imperial titles was a <b>real, complex, ultimately sorrowful human being</b> — creator and destroyer, magnificent and grieving.',
      conseq='He died on campaign a devout and weary old man, his golden age already shadowed by the succession he had ruined.',
      matters='Even the most magnificent life is a human one. Suleiman the man — poet, lover, grieving father — is as revealing as Suleiman the sultan.'),

    E('death', '1566', 'Death at Szigetvár', ['DEATH', 'TRIUMPH'],
      'At over seventy, ailing but unbowed, he leads one last campaign into Hungary and dies in his tent during the siege of Szigetvár — his death hidden from the army for weeks so the assault would not falter, a conqueror who died still conquering.',
      svg_row('The last campaign of the old lion', [
          {'n': 1, 'label': 'One last march', 'sub': 'aged ~71 and ill, he campaigns in Hungary again', 'color': '#854d0e'},
          {'n': 2, 'label': 'Dies at Szigetvár', 'sub': 'in his tent during the siege, 1566', 'color': '#111827'},
          {'n': 3, 'label': 'Death concealed', 'sub': 'hidden for weeks to keep the army steady', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='He died as he had lived — on campaign at the head of his army, still expanding the empire.', accent=AC),
      bg='Despite age and illness, Suleiman never stopped campaigning. In <b>1566</b> he led another great expedition into <b>Hungary</b>, besieging the fortress of <b>Szigetvár</b>.',
      people='His Grand Vizier <b>Sokollu Mehmed Pasha</b>, who concealed the death to preserve the army’s morale; his heir <b>Selim II</b>.',
      what='Suleiman <b>died in his tent during the siege of Szigetvár in 1566</b>, aged around 71. Sokollu Mehmed Pasha <b>kept the death secret</b> for weeks until the succession was secured and the fortress had fallen.',
      crux='He personified the ideal of the <b>warrior-sultan to the very end</b>, and even his death was managed as a matter of state to protect the army and the succession.',
      conseq='His reign of 46 years — the longest and greatest in Ottoman history — ended at the empire’s zenith; decline would come only gradually under lesser successors.',
      matters='The end of a golden age is often quiet. Suleiman died at the summit; the long descent belonged to those who came after.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Suleiman I — “the Magnificent” to Europe, <b>Kanuni</b>, “the Lawgiver,” to his own people — ruled 46 years over the Ottoman Empire at its absolute zenith: conqueror of Belgrade, Rhodes, Hungary and Baghdad, master of the Mediterranean, and the codifier and patron who made his age the summit of Ottoman civilisation. He is a study in <b>power at its height, grand strategy across continents, law as the deepest legacy, and the family tragedy that seeded a decline.</b></p>
<div class="ov-quote">“The people think of wealth and power as the greatest fate — but law and justice are the true measure of a reign.”<span>— sentiment associated with Suleiman</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">The only heir inherits a superpower → takes Belgrade and Rhodes → annihilates Hungary at Mohács → reaches his limit at Vienna → duels Charles V across a continent → makes Barbarossa admiral and wins the sea at Preveza → takes Baghdad in the east → is checked at Malta → codifies the law and raises a golden age of Sinan and poetry → destroys his ablest sons in a succession tragedy → dies on campaign at Szigetvár, at the empire’s peak.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">👑</div><h4>The zenith</h4><p>Under him the empire reached its greatest extent, wealth and prestige.</p></div>
  <div class="ov-card"><div class="i">🌍</div><h4>Grand strategy</h4><p>He fought Habsburgs and Safavids on two fronts and duelled for a continent.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>The Lawgiver</h4><p>His deepest legacy was a coherent legal order, not a conquest.</p></div>
  <div class="ov-card"><div class="i">🕌</div><h4>A golden age</h4><p>Sinan’s domes, a poet-sultan, and the extraordinary rise of Roxelana.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Golden Inheritance</b><small> 1494–1522</small><p>A superpower inherited; Belgrade and Rhodes.</p></div>
  <div><b>2 · The Hammer of Europe</b><small> 1526–60s</small><p>Mohács, Vienna, and the duel with Charles V.</p></div>
  <div><b>3 · Lord of the Seas</b><small> 1533–65</small><p>Barbarossa, Preveza, Baghdad, Malta.</p></div>
  <div><b>4 · The Lawgiver</b><small> 1520s–60s</small><p>The law-code and the cultural golden age.</p></div>
  <div><b>5 · Tragedy and Death</b><small> 1553–66</small><p>The sons he destroyed; death at Szigetvár.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Selim I', 'role': 'father', 'color': '#713f12',
     'bio': 'Suleiman’s father, whose eight-year blitz tripled the empire and left his only son a secure superpower to inherit.',
     'rel': 'The father whose conquests were Suleiman’s platform.'},
    {'name': 'Hurrem Sultan (Roxelana)', 'role': 'wife / empress', 'color': '#be185d',
     'bio': 'A slave concubine who became Suleiman’s beloved wife and a formidable political actor, breaking harem convention and beginning the era of influential royal women.',
     'rel': 'The love of his life and a power behind the throne.'},
    {'name': 'Ibrahim Pasha', 'role': 'grand vizier / friend', 'color': '#0369a1',
     'bio': 'Suleiman’s boyhood friend, raised to Grand Vizier and immense power — then suddenly executed in 1536, a warning of how fast Ottoman favour could turn.',
     'rel': 'The favourite whose rise and fall marked the reign.'},
    {'name': 'Hayreddin Barbarossa', 'role': 'grand admiral', 'color': '#166534',
     'bio': 'The Barbary corsair Suleiman made Kapudan Pasha; he built and led the fleet that won Preveza and dominated the Mediterranean.',
     'rel': 'The pirate turned admiral who won Suleiman the sea.'},
    {'name': 'Mimar Sinan', 'role': 'chief architect', 'color': '#854d0e',
     'bio': 'The greatest Ottoman architect, whose Süleymaniye Mosque and hundreds of other works defined the classical age of Ottoman architecture.',
     'rel': 'The genius who built Suleiman’s golden age in stone.'},
    {'name': 'Şehzade Mustafa', 'role': 'the lost heir', 'color': '#7f1d1d',
     'bio': 'Suleiman’s gifted and popular eldest son, strangled on his father’s order in 1553 amid harem intrigue — the tragedy that ruined the succession.',
     'rel': 'The able son Suleiman destroyed, dooming the succession.'},
    {'name': 'Charles V', 'role': 'Habsburg rival', 'color': '#475569',
     'bio': 'Holy Roman Emperor and Suleiman’s mirror-image rival for European and Mediterranean mastery — the other “universal empire” of the age.',
     'rel': 'The great western adversary of Suleiman’s reign.'},
]

KEY_EVENTS = [
    ('1494', 'Born, son of Selim I', 'The only heir to a rising superpower.'),
    ('1520', 'Accession', 'Inherits the empire at its peak, without a succession war.'),
    ('1521', 'Capture of Belgrade', 'Opens the road into Hungary.'),
    ('1522', 'Siege of Rhodes', 'Expels the Knights Hospitaller.'),
    ('1526', 'Battle of Mohács', 'Annihilates Hungary; King Louis II dies.'),
    ('1529', 'Siege of Vienna', 'The high-water mark; the siege fails.'),
    ('1534', 'Capture of Baghdad', 'Adds Iraq in the war with Persia.'),
    ('1538', 'Battle of Preveza', 'Barbarossa wins Mediterranean dominance.'),
    ('1553', 'Execution of Mustafa', 'The able heir strangled amid intrigue.'),
    ('1565', 'Great Siege of Malta', 'The Knights hold; the Ottomans withdraw.'),
    ('1566', 'Death at Szigetvár', 'Dies on campaign after 46 years; Selim II succeeds.'),
]

MASTER = [
    {'year': '1494', 'age': 'born', 'phase': 'The Start', 'title': 'Born to Selim I', 'desc': 'The only heir.'},
    {'year': '1520', 'age': 'age ~26', 'phase': 'The Start', 'title': 'Accession', 'desc': 'Inherits a superpower.'},
    {'year': '1526', 'age': 'age ~31', 'phase': 'Europe', 'title': 'Mohács', 'desc': 'Hungary destroyed.'},
    {'year': '1529', 'age': 'age ~34', 'phase': 'Europe', 'title': 'Vienna', 'desc': 'The high-water mark.'},
    {'year': '1538', 'age': 'age ~43', 'phase': 'The Seas', 'title': 'Preveza', 'desc': 'Mastery of the sea.'},
    {'year': '1553', 'age': 'age ~58', 'phase': 'Tragedy', 'title': 'Mustafa killed', 'desc': 'The succession ruined.'},
    {'year': '1565', 'age': 'age ~70', 'phase': 'The Seas', 'title': 'Malta', 'desc': 'The Knights hold.'},
    {'year': '1566', 'age': 'age ~71', 'phase': 'The End', 'title': 'Death at Szigetvár', 'desc': 'Dies on campaign at the peak.'},
]

SOURCES = [
    ('Britannica — Suleyman the Magnificent', 'https://www.britannica.com/biography/Suleyman-the-Magnificent'),
    ('World History Encyclopedia — Suleiman the Magnificent', 'https://www.worldhistory.org/Suleiman_the_Magnificent/'),
    ('Britannica — Battle of Mohács', 'https://www.britannica.com/event/Battle-of-Mohacs-1526'),
    ('Wikipedia — Suleiman the Magnificent', 'https://en.wikipedia.org/wiki/Suleiman_the_Magnificent'),
]

def build_meta():
    return {
        'pid': 'gm-suleiman.html', 'kind': 'man', 'emoji': '\U0001f54c', 'accent': AC,
        'name': 'Suleiman the Magnificent', 'years': '1494–1566', 'group': 'Ottoman Sultans',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Lawgiver. In a 46-year reign he took the empire to its zenith — Mohács, Baghdad and the Mediterranean — and raised the golden age of Ottoman law, architecture and art.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'start', 'label': '1 · The Golden Inheritance', 'type': 'timeline',
             'intro': 'The only heir inherits the richest, strongest empire in the world — and announces himself by taking Belgrade and Rhodes, two fortresses that had defied his ancestors.', 'events': PHASE_START},
            {'id': 'europe', 'label': '2 · The Hammer of Europe', 'type': 'timeline',
             'intro': 'He annihilates Hungary at Mohács, reaches the limit of empire at the gates of Vienna, and duels Emperor Charles V for mastery of a whole continent.', 'events': PHASE_EUROPE},
            {'id': 'seas', 'label': '3 · Lord of the Seas', 'type': 'timeline',
             'intro': 'He makes a corsair his admiral and wins the Mediterranean at Preveza, takes Baghdad in the east — and is finally checked by his old enemies, the Knights, at Malta.', 'events': PHASE_SEAS},
            {'id': 'law', 'label': '4 · The Lawgiver', 'type': 'timeline',
             'intro': 'His deepest legacy is not a conquest but a body of law — and a golden age of Sinan’s architecture, his own poetry, and the extraordinary rise of Roxelana.', 'events': PHASE_LAW},
            {'id': 'end', 'label': '5 · Tragedy and Death', 'type': 'timeline',
             'intro': 'The greatest sultan’s darkest act is against his own blood — the destruction of his ablest sons — before he dies on one last campaign, at the empire’s very peak.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Details of the harem intrigues around the succession are drawn partly from later and sometimes hostile accounts; the executions of Mustafa (1553) and Bayezid (1561) are well documented.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
