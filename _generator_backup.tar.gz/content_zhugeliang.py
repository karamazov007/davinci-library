# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Zhuge Liang (Kongming).
The Sleeping Dragon of Longzhong — chancellor and strategist of Shu Han, and China’s enduring symbol of loyal wisdom."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#0f766e'  # jade / teal — the strategist’s calm

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE SLEEPING DRAGON
PHASE_RISE = [
    E('origins', '181–197', 'An orphan of a broken age', ['RISE', 'TRAGEDY'],
      'Born in 181 in Yangdu, Langya, as the Han dynasty collapsed into warlord chaos, Zhuge Liang loses his parents young and is raised by an uncle, Zhuge Xuan — wandering south with a war-torn family until he settles as a farmer near Xiangyang, shaped by an era of ruin into a man who dreams of restoring order.',
      svg_row('A childhood in the wreckage of Han', [
          {'n': 1, 'label': 'Born 181, Langya', 'sub': 'the Han empire dissolving into warlord wars', 'color': '#0f766e'},
          {'n': 2, 'label': 'Orphaned young', 'sub': 'raised by his uncle Zhuge Xuan', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Flees south to Jing', 'sub': 'settles as a farmer near Xiangyang', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='The collapse of the Han forged a boy who would spend his life trying to restore order to a shattered realm.', accent=AC),
      bg='<b>Zhuge Liang</b>, courtesy name <b>Kongming</b>, was born in 181 in Yangdu, Langya Commandery (modern Shandong), as the Later Han dynasty disintegrated into the warlordism of the Three Kingdoms era.',
      people='his uncle <b>Zhuge Xuan</b>, who raised him; his scattered family; the collapsing Han court far to the north.',
      what='Orphaned as a child, Zhuge Liang was raised by his uncle and, amid the wars, migrated south to <b>Jing Province</b>, eventually settling to farm near <b>Xiangyang</b> — an education in the ruin of a great dynasty.',
      crux='He grew up watching <b>a broken empire</b> — an experience that fixed his lifelong ambition to see the Han restored and order returned.',
      conseq='In Jing Province he entered the circle of scholars whose talk of statecraft would shape the strategist he became.',
      matters='An age of collapse can forge its own remedy — the orphan of a dying dynasty became the man who dreamed of rebuilding it.'),

    E('sleepingdragon', '197–207', 'The Sleeping Dragon of Longzhong', ['RISE', 'POLITICS'],
      'Living quietly as a farmer-scholar at Longzhong, Zhuge Liang studies statecraft, compares himself to the great ancient ministers, and earns from the local literati the nickname “Sleeping Dragon” — a hidden talent of vast promise, waiting for the ruler worthy of him.',
      svg_stack('A hidden talent biding his time', [
          {'n': 1, 'label': 'Farmer-scholar at Longzhong', 'sub': 'studies statecraft and history in retreat', 'color': '#0f766e'},
          {'n': 2, 'label': 'Likens himself to the sages', 'sub': 'to the ancient statesmen Guan Zhong and Yue Yi', 'color': '#a16207'},
          {'n': 3, 'label': 'Called the “Sleeping Dragon”', 'sub': 'a hidden genius awaiting the right lord', 'color': '#166534'},
      ], takeaway='He cultivated himself in obscurity and let his reputation grow — a dragon coiled, waiting for the moment to rise.', accent=AC),
      bg='At Longzhong near Xiangyang, Zhuge Liang lived modestly, farming and studying, married into the local gentry, and moved among the region’s leading scholars.',
      people='the Jing Province literati who praised him; the recluse-teachers of his circle; the warlords he pointedly declined to serve.',
      what='He compared himself to the celebrated ancient ministers <b>Guan Zhong and Yue Yi</b> and earned the epithet <b>“Sleeping Dragon” (Wolong)</b> — a man of extraordinary gifts holding himself in reserve for a worthy ruler.',
      crux='He understood the value of <b>reputation and patience</b> — refusing lesser masters so that his talent would be sought, not spent cheaply.',
      conseq='His fame reached a desperate, wandering warlord named Liu Bei, who came looking for him.',
      matters='Patience is a form of strategy — the talent that waits for the right moment commands a higher price than the one that rushes to serve.'),

    E('threevisits', '207', 'The Three Visits and the Longzhong Plan', ['POLITICS', 'TURNING POINT', 'TRIUMPH'],
      'The warlord Liu Bei, humbled and landless, visits Zhuge Liang’s cottage three times before the recluse agrees to see him — and Zhuge Liang answers with the Longzhong Plan: seize Jing and Yi provinces, ally with Sun Quan in the east, oppose Cao Cao in the north, and so divide the realm into three as the base for restoring the Han.',
      svg_stack('A grand strategy for a landless lord', [
          {'n': 1, 'label': 'Liu Bei visits three times', 'sub': 'the humble warlord courts the recluse, 207', 'color': '#a16207'},
          {'n': 2, 'label': 'The Longzhong Plan', 'sub': 'take Jing and Yi; ally Sun Quan; resist Cao Cao', 'color': '#0f766e'},
          {'n': 3, 'label': 'Divide the realm in three', 'sub': 'a tripartite balance as the base to restore Han', 'color': '#166534'},
      ], takeaway='In a single audience he handed a landless wanderer a blueprint for a kingdom — the strategy that would shape the age.', accent=AC),
      bg='By 207 <b>Liu Bei</b> was a charismatic but landless warlord sheltering in Jing Province, seeking talent equal to his ambition of reviving the Han.',
      people='<b>Liu Bei</b>, the visiting lord; <b>Cao Cao</b>, the northern hegemon; <b>Sun Quan</b>, the lord of the southeast — the three around whom the plan turned.',
      what='After Liu Bei’s celebrated <b>“three visits to the thatched cottage,”</b> Zhuge Liang laid out the <b>Longzhong Plan</b> — seize <b>Jing and Yi provinces</b> as a power base, ally with <b>Sun Quan</b>, hold off <b>Cao Cao</b>, and split the empire three ways.',
      crux='He gave Liu Bei a <b>realistic map to power</b>: not to fight everyone at once, but to carve out a defensible third of the realm and wait.',
      conseq='Liu Bei took Zhuge Liang as his chief strategist; the Longzhong Plan became the strategic spine of the coming Three Kingdoms.',
      matters='Vision beats force — a clear strategy handed to the weakest of three contenders let him claim a kingdom he had no land to build on.'),
]

# ==================================================================  PHASE 2 — FORGING THE THREE KINGDOMS
PHASE_ALLIANCE = [
    E('redcliffs', '208', 'Red Cliffs — the alliance against Cao Cao', ['BATTLE', 'TURNING POINT', 'TRIUMPH'],
      'As Cao Cao’s vast army sweeps south and Liu Bei flees for his life, Zhuge Liang is sent as envoy to Sun Quan — and by argument and nerve persuades the wavering southern lord to join Liu Bei against the invader, forging the coalition that destroys Cao Cao’s fleet at the Battle of Red Cliffs.',
      svg_row('Diplomacy that turned an invasion', [
          {'n': 1, 'label': 'Cao Cao invades the south', 'sub': 'a huge army drives Liu Bei into flight, 208', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Envoy to Sun Quan', 'sub': 'Zhuge Liang argues for a Sun–Liu alliance', 'color': '#0f766e'},
          {'n': 3, 'label': 'Victory at Red Cliffs', 'sub': 'the allied fleet destroys Cao Cao on the Yangtze', 'color': '#166534'},
      ], edge_labels=['met by', 'wins'], takeaway='He talked a hesitant rival into alliance — and that diplomacy, not any single sword, broke Cao Cao’s march to conquest.', accent=AC),
      bg='In 208 <b>Cao Cao</b> conquered Jing Province and drove south to finish Liu Bei and subdue Sun Quan, threatening to unite all China under his rule.',
      people='<b>Sun Quan</b>, the wavering southern lord; his commander <b>Zhou Yu</b>; <b>Cao Cao</b>, the invader; Liu Bei, the fugitive ally.',
      what='Zhuge Liang went as <b>envoy to Sun Quan</b> and persuaded him to ally with Liu Bei; the combined forces then crushed Cao Cao’s fleet at the <b>Battle of Red Cliffs (Chibi, 208)</b>, one of history’s decisive river battles. (The novel’s tales of Zhuge Liang “borrowing arrows” and summoning the east wind are later fiction.)',
      crux='He grasped that <b>the alliance was everything</b> — that two weaker powers united could halt a stronger one that either alone could not.',
      conseq='Cao Cao’s failure ended his hope of quick reunification and locked in the three-way division the Longzhong Plan had foreseen.',
      matters='A well-made alliance can defeat a superior force — the diplomat who unites the weak reshapes the balance of an age.'),

    E('yizhou', '211–219', 'Building the base — Jing and Yi provinces', ['POLITICS', 'REFORM', 'RISE'],
      'With Red Cliffs won, Zhuge Liang helps Liu Bei execute the Longzhong Plan in earnest — securing Jing Province and then conquering Yi Province (Shu, modern Sichuan) — while Zhuge Liang organizes government, law, taxes and supply, turning conquered land into a functioning state.',
      svg_stack('From strategy on paper to a real state', [
          {'n': 1, 'label': 'Hold Jing Province', 'sub': 'the eastern base won after Red Cliffs', 'color': '#0f766e'},
          {'n': 2, 'label': 'Conquer Yi Province (Shu)', 'sub': 'Liu Bei takes fertile Sichuan, 214', 'color': '#a16207'},
          {'n': 3, 'label': 'Zhuge Liang builds the state', 'sub': 'law, taxes, supply and administration', 'color': '#166534'},
      ], takeaway='He proved as able in government as in strategy — turning a conqueror’s gains into an organized, self-sustaining kingdom.', accent=AC),
      bg='After Red Cliffs, Liu Bei expanded from Jing Province into the rich basin of Yi Province (Shu), the heartland the Longzhong Plan had marked out.',
      people='<b>Liu Bei</b>, now a territorial ruler; his generals <b>Guan Yu</b> and <b>Zhang Fei</b>; Zhuge Liang, the organizing hand behind the throne.',
      what='As Liu Bei secured <b>Jing</b> and then conquered <b>Yi Province (214)</b>, Zhuge Liang managed the <b>administration, law and logistics</b> — establishing the institutions, revenue and supply that a durable state required.',
      crux='He understood that <b>conquest is only the beginning</b> — that lasting power rests on sound law, full granaries and honest government.',
      conseq='Shu now had a wealthy, defensible base; the stage was set for Liu Bei to claim an imperial title of his own.',
      matters='States are built by administrators, not only generals — the strategist who could also govern gave his lord something that would endure.'),

    E('chancellor', '221–223', 'Chancellor of Shu Han', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'After Cao Cao’s son deposes the last Han emperor, Liu Bei proclaims himself emperor to carry on the Han line — founding the state of Shu Han in 221 and making Zhuge Liang his Chancellor, the head of government of the new kingdom in the west.',
      svg_row('The Sleeping Dragon becomes chancellor', [
          {'n': 1, 'label': 'The Han is deposed, 220', 'sub': 'Cao Pi ends the Han and founds Wei', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Liu Bei declares emperor', 'sub': 'founds Shu Han to continue the Han line, 221', 'color': '#a16207'},
          {'n': 3, 'label': 'Zhuge Liang made Chancellor', 'sub': 'head of government of the new state', 'color': '#0f766e'},
      ], edge_labels=['so', 'and'], takeaway='The recluse of Longzhong now ran a kingdom — chief minister of the state his own strategy had brought into being.', accent=AC),
      bg='In 220 <b>Cao Pi</b>, Cao Cao’s son, forced the abdication of the last Han emperor and founded the state of <b>Wei</b>, formally ending the Han dynasty.',
      people='<b>Liu Bei</b>, now emperor of Shu Han; <b>Cao Pi</b> of Wei; <b>Sun Quan</b> of Wu; Zhuge Liang, the new chancellor.',
      what='Presenting himself as the Han’s rightful heir, <b>Liu Bei proclaimed himself emperor in 221</b>, founding <b>Shu Han</b> — and appointed <b>Zhuge Liang as Chancellor (Chengxiang)</b>, the head of its government.',
      crux='Shu positioned itself as the <b>legitimate continuation of the Han</b>, with Zhuge Liang as the minister charged with making that claim real.',
      conseq='The three-way division was now three declared empires — Wei, Shu and Wu — with Zhuge Liang steering the smallest of them.',
      matters='The plan drawn in a cottage had become a throne — the strategist’s vision realized as a state he now had to govern and defend.'),
]

# ==================================================================  PHASE 3 — GUARDIAN OF SHU
PHASE_REGENT = [
    E('baidicheng', '223', 'The deathbed trust at Baidicheng', ['POLITICS', 'DEATH', 'TURNING POINT'],
      'After a catastrophic defeat by Wu, a broken Liu Bei dies at Baidicheng — entrusting his young, weak heir Liu Shan and the whole future of Shu to Zhuge Liang, even telling him to take the throne himself if the boy proves unfit; Zhuge Liang refuses, and vows to serve with total loyalty.',
      svg_stack('A dying emperor’s extraordinary trust', [
          {'n': 1, 'label': 'Liu Bei’s ruin at Yiling', 'sub': 'crushing defeat by Wu breaks him, 222', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Dies at Baidicheng, 223', 'sub': 'entrusts his heir Liu Shan to Zhuge Liang', 'color': '#a16207'},
          {'n': 3, 'label': 'The regent’s vow of loyalty', 'sub': 'declines the throne; serves the boy-emperor', 'color': '#0f766e'},
      ], takeaway='Offered the throne itself, he chose loyalty — becoming the all-powerful regent who never reached for the crown.', accent=AC),
      bg='Liu Bei’s war of revenge against Wu ended in disaster at the <b>Battle of Xiaoting/Yiling (222)</b>; the shattered emperor withdrew to Baidicheng and fell ill.',
      people='the dying <b>Liu Bei</b>; his young son and heir <b>Liu Shan</b> (Houzhu); Zhuge Liang, the appointed regent.',
      what='On his deathbed in 223, Liu Bei <b>entrusted Liu Shan and the state to Zhuge Liang</b>, reportedly telling him to take the throne himself if the heir proved incapable. Zhuge Liang <b>refused</b> and pledged to serve the young emperor faithfully unto death.',
      crux='He was handed <b>unlimited power with permission to seize the crown</b> — and answered with unbroken loyalty, the choice that made his name synonymous with devotion.',
      conseq='As regent, Zhuge Liang now held effective power over all of Shu, with a weak emperor and a fragile state to preserve.',
      matters='Character is revealed by what a man does with unchecked power — Zhuge Liang’s refusal of the throne became China’s model of the loyal minister.'),

    E('governing', '223–225', 'Rebuilding Shu — law, farms and the Wu alliance', ['POLITICS', 'REFORM'],
      'As regent, Zhuge Liang stabilizes a battered Shu — restoring the alliance with Wu he had helped forge, promoting agriculture and irrigation, and governing by strict but fair law, building the disciplined, well-supplied state from which he can one day challenge mighty Wei.',
      svg_stack('A small state made strong and orderly', [
          {'n': 1, 'label': 'Restore the alliance with Wu', 'sub': 'reconcile with Sun Quan against Wei', 'color': '#0f766e'},
          {'n': 2, 'label': 'Farms, irrigation, granaries', 'sub': 'rebuild the economy and food supply', 'color': '#166534'},
          {'n': 3, 'label': 'Strict but impartial law', 'sub': 'discipline and fair reward for all', 'color': '#a16207'},
      ], takeaway='He made a small, poor kingdom disciplined and well-fed — the administrative base for everything that came after.', accent=AC),
      bg='Shu was the weakest of the three states, shaken by defeat and Liu Bei’s death. Its survival depended on order, food and diplomacy.',
      people='Emperor <b>Liu Shan</b>, in whose name he ruled; <b>Sun Quan</b> of Wu, the ally he re-cultivated; the officials and farmers of Shu.',
      what='Zhuge Liang <b>repaired the alliance with Wu</b>, promoted <b>agriculture and irrigation</b> to fill the granaries, and governed by <b>clear, strictly enforced law</b> applied fairly to high and low alike, praised for its impartiality.',
      crux='He built strength through <b>order and administration</b> — knowing a small state could rival great ones only if flawlessly organized.',
      conseq='A stabilized, well-supplied Shu gave Zhuge Liang the security to turn south, and then north, on campaign.',
      matters='Sound administration is the foundation of power — the strategist won more by good government than he could by any single battle.'),

    E('menghuo', '225', 'The Southern Campaign — seven times freeing Meng Huo', ['BATTLE', 'POLITICS', 'TRIUMPH'],
      'To secure his rear before turning north, Zhuge Liang leads a campaign into the rebellious south (Nanzhong) — and, rather than merely crushing the tribal leader Meng Huo, is said to have captured and released him seven times until Meng Huo submitted willingly, winning the south’s lasting loyalty by clemency rather than force.',
      svg_row('Conquest by winning hearts, not just battles', [
          {'n': 1, 'label': 'The south rebels', 'sub': 'Nanzhong rises against Shu, 225', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Capture and release Meng Huo', 'sub': 'freed seven times until he submits by will', 'color': '#0f766e'},
          {'n': 3, 'label': 'The south pacified for good', 'sub': 'loyalty won by clemency, rear secured', 'color': '#166534'},
      ], edge_labels=['so', 'yields'], takeaway='He conquered by winning consent — a pacification through mercy that held far better than any garrison could.', accent=AC),
      bg='While Zhuge Liang rebuilt Shu, its southern frontier of Nanzhong (modern Yunnan/Guizhou) rose in revolt, threatening his rear and his resources.',
      people='the rebel leader <b>Meng Huo</b> of the southern tribes; local chieftains; Zhuge Liang, seeking a lasting settlement, not just a victory.',
      what='In 225 Zhuge Liang campaigned into <b>Nanzhong</b> and, famously, is said to have <b>captured and released Meng Huo seven times</b> until he submitted sincerely — securing the region’s loyalty and resources. (The dramatic “seven captures” is celebrated in tradition and greatly embellished in the novel.)',
      crux='He aimed to <b>win the peace, not just the war</b> — knowing a submission of the heart would outlast one forced by the sword.',
      conseq='With the south loyal and supplying men and resources, Zhuge Liang’s rear was safe for the great task ahead: the war against Wei.',
      matters='True victory secures consent — the conqueror who wins loyalty, not just territory, need not fight the same enemy twice.'),
]

# ==================================================================  PHASE 4 — THE NORTHERN EXPEDITIONS
PHASE_EXPEDITIONS = [
    E('chushibiao', '227–228', 'The Chu Shi Biao and the first march north', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'Before marching against Wei, Zhuge Liang presents to Liu Shan the Chu Shi Biao — a memorial of such loyalty and moral force it became a masterpiece of Chinese prose — then launches the first of his Northern Expeditions, only to see early gains lost when his protégé Ma Su disobeys orders and is routed at Jieting.',
      svg_stack('Duty declared, then a costly lesson', [
          {'n': 1, 'label': 'The Chu Shi Biao, 227', 'sub': 'a memorial of loyalty urging the campaign', 'color': '#0f766e'},
          {'n': 2, 'label': 'First Northern Expedition, 228', 'sub': 'early gains against Wei in the northwest', 'color': '#a16207'},
          {'n': 3, 'label': 'Disaster at Jieting', 'sub': 'Ma Su disobeys and is routed; retreat', 'color': '#b91c1c'},
      ], takeaway='He opened his life’s campaign with a masterpiece of prose — then learned that even a great plan fails on a subordinate’s error.', accent=AC),
      bg='By 227 Shu was strong enough for Zhuge Liang to pursue the Longzhong Plan’s ultimate goal: attacking Wei to restore the Han. Its throne was held by young Liu Shan.',
      people='Emperor <b>Liu Shan</b>, addressee of the memorial; the general <b>Ma Su</b>, whose disobedience proved fatal; the Wei defenders of the northwest.',
      what='Zhuge Liang submitted the <b>Chu Shi Biao (“Memorial on the Case for War,” 227)</b>, a revered statement of loyal purpose, then launched the <b>First Northern Expedition (228)</b>. Early success collapsed when <b>Ma Su ignored his orders and lost the key position of Jieting</b>, forcing retreat.',
      crux='He staked everything on a bold offensive — and discovered that <b>strategy is only as good as the discipline of those who execute it.</b>',
      conseq='Zhuge Liang tearfully executed Ma Su for the failure and demoted himself, upholding the strict law he governed by even against his own favorite.',
      matters='A plan lives or dies in execution — and the leader who punishes even his favorites for failure keeps the discipline that makes plans work.'),

    E('inventions', '228–234', 'Logistics and ingenuity — the ox, the horse, the crossbow', ['REFORM', 'BATTLE'],
      'Waging war across brutal mountain terrain against a richer enemy, Zhuge Liang wrestles above all with supply — devising the “wooden ox” and “gliding horse” transport carts to move grain over the passes, improving the repeating crossbow, and pioneering the disciplined logistics that let tiny Shu strike again and again at mighty Wei.',
      svg_row('Winning by supply and invention', [
          {'n': 1, 'label': 'The problem: supply', 'sub': 'grain over mountains against a richer foe', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Wooden ox and gliding horse', 'sub': 'transport carts to move grain over the passes', 'color': '#0f766e'},
          {'n': 3, 'label': 'The repeating crossbow', 'sub': 'improved rapid-firing bow; drilled troops', 'color': '#166534'},
      ], edge_labels=['solved by', 'and'], takeaway='He knew wars are won by logistics — his supply inventions let a small state punch far above its weight.', accent=AC),
      bg='Shu was smaller and poorer than Wei, and its armies had to campaign across the rugged terrain between Sichuan and the northern plains — a logistical nightmare.',
      people='the Wei commanders he faced; the engineers and soldiers of Shu; Zhuge Liang, celebrated as an inventor as well as a strategist.',
      what='Zhuge Liang is credited with the <b>“wooden ox” and “gliding horse” (mu niu liu ma)</b> — wheelbarrow-like carts for hauling grain over mountains — and with improving the <b>repeating crossbow (Zhuge nu)</b>, alongside meticulous drill and supply discipline.',
      crux='He recognized that against a stronger enemy, <b>logistics and organization are the real weapons</b> — moving food reliably mattered more than any single tactic.',
      conseq='These innovations let Shu mount repeated expeditions it could not otherwise have sustained, and cemented Zhuge Liang’s fame as an ingenious mind.',
      matters='Amateurs talk tactics; masters manage supply — Zhuge Liang’s genius for logistics let the weakest state stay permanently on the attack.'),

    E('simayi', '228–234', 'The duel with Sima Yi — and the Empty Fort legend', ['BATTLE', 'POLITICS'],
      'Wei sends its ablest strategist, Sima Yi, to stop him — and the two settle into a war of patience, Sima Yi refusing open battle and betting that Shu’s supply lines will fail before Zhuge Liang can force a decision; from this rivalry grows the famous (and fictional) Empty Fort Strategy, where Zhuge Liang bluffs a whole army with an open, undefended gate.',
      svg_compare('Two masters in a war of nerves', {
          'head': 'Zhuge Liang (Shu)', 'color': '#0f766e', 'items': [
              'Smaller, poorer state on the offensive',
              'Must force a decision before supplies fail',
              'Repeated bold expeditions north',
              'Legend: bluffs an army with an open gate']},
        {'head': 'Sima Yi (Wei)', 'color': '#b91c1c', 'items': [
              'Larger, richer state on the defensive',
              'Refuses open battle; plays for time',
              'Bets Shu’s logistics will break first',
              'Cautious patience against a bolder mind']},
        verdict='Two brilliant minds locked in stalemate — daring offense against patient defense.',
        takeaway='Against a stronger, patient foe, even genius could not force a breakthrough — the duel became a study in strategic deadlock.', accent=AC),
      bg='To halt Zhuge Liang’s expeditions, Wei entrusted its defense to <b>Sima Yi</b>, an equally cautious and capable strategist who understood Shu’s weakness was supply.',
      people='<b>Sima Yi</b>, the Wei commander and Zhuge Liang’s great rival; the armies of Wei and Shu strung along the northern front.',
      what='Sima Yi met Zhuge Liang with <b>patient, defensive warfare</b>, declining battle to let Shu’s supply lines fail. From their rivalry comes the celebrated <b>Empty Fort Strategy</b> — Zhuge Liang calmly sitting at an open, undefended city gate to bluff a wary Sima Yi into retreat (a dramatic tale from the novel, not the histories).',
      crux='The contest turned on <b>time and logistics</b>: Zhuge Liang needed a swift decision, Sima Yi needed only to wait — and waiting favored the richer state.',
      conseq='Neither could destroy the other; the expeditions ground on inconclusively, wearing down Zhuge Liang’s health and Shu’s strength.',
      matters='Not every genius can overcome a structural disadvantage — the master strategist met his match in an enemy patient enough to do nothing.'),
]

# ==================================================================  PHASE 5 — DEATH AND IMMORTALITY
PHASE_END = [
    E('wuzhang', '234', 'Death at the Wuzhang Plains', ['DEATH', 'BATTLE', 'TRAGEDY'],
      'On his fifth and final expedition, worn out by years of labor and illness, Zhuge Liang dies in camp at the Wuzhang Plains in 234, his great campaign unfinished — and even in death, a ruse said to be his own devising frightens the cautious Sima Yi into retreat, birthing the proverb about “a dead Zhuge scaring off a living Sima.”',
      svg_stack('The strategist falls with his work undone', [
          {'n': 1, 'label': 'Fifth expedition, 234', 'sub': 'stalemate with Sima Yi at the Wuzhang Plains', 'color': '#a16207'},
          {'n': 2, 'label': 'Zhuge Liang dies in camp', 'sub': 'worn out by illness and labor, age 54', 'color': '#111827'},
          {'n': 3, 'label': 'Dead Zhuge routs Sima Yi', 'sub': 'a final ruse frightens Wei into retreat', 'color': '#0f766e'},
      ], takeaway='He died in harness with his campaign unfinished — yet his reputation alone still scattered the enemy one last time.', accent=AC),
      bg='By 234 Zhuge Liang had spent his health on repeated expeditions. His fifth campaign settled into another stalemate with Sima Yi at the <b>Wuzhang Plains</b>.',
      people='<b>Sima Yi</b>, still refusing battle; the officers of Shu who carried out his last orders; Emperor <b>Liu Shan</b> in the capital.',
      what='Exhausted and ill, <b>Zhuge Liang died in camp at the Wuzhang Plains in 234</b>, his goal of restoring the Han unrealized. As Shu withdrew, a ruse — traditionally credited to his own planning — <b>panicked the cautious Sima Yi into retreat</b>, giving rise to the proverb “a dead Zhuge frightens away a living Zhongda.”',
      crux='His life’s campaign ended <b>unfinished</b> — the structural odds against tiny Shu were never overcome, even by his genius.',
      conseq='Shu lost its guiding mind; though it survived three more decades, it never again seriously threatened Wei and fell in 263.',
      matters='Even the greatest ability meets limits it cannot break — Zhuge Liang’s tragedy is the brilliant effort spent against impossible odds.'),

    E('historyvsnovel', 'after 234', 'The man and the legend — history vs the novel', ['POLITICS', 'REFORM'],
      'Zhuge Liang is remembered twice over: as the real chancellor of the Records of the Three Kingdoms — a superb administrator, loyal minister and inventive strategist — and as the near-magical sage of the later novel Romance of the Three Kingdoms, master of wind and prophecy, whose brilliant fictions have all but eclipsed the historical man.',
      svg_compare('Two Zhuge Liangs across the centuries', {
          'head': 'The historical man', 'color': '#0f766e', 'items': [
              'Records of the Three Kingdoms (Chen Shou)',
              'Superb administrator and loyal chancellor',
              'Inventive in logistics and law',
              'A good, not infallible, field commander']},
        {'head': 'The novel’s sage', 'color': '#7c3aed', 'items': [
              'Romance of the Three Kingdoms (14th c.)',
              'Near-magical genius who summons the wind',
              'Borrowed arrows, the Empty Fort bluff',
              'An almost supernatural master of prophecy']},
        verdict='A real, gifted statesman transfigured by fiction into a symbol of superhuman wisdom.',
        takeaway='The legend grew from a genuinely great man — but the novel’s magic must not be mistaken for the sober historical record.', accent=AC),
      bg='Zhuge Liang’s fame rests on two sources: the near-contemporary history of <b>Chen Shou</b>, and the immensely popular Ming-era novel written over a thousand years later.',
      people='the historian <b>Chen Shou</b>, who knew Shu; <b>Luo Guanzhong</b>, credited with the novel; the generations who loved the fictional sage.',
      what='The <b>Records of the Three Kingdoms</b> shows a brilliant administrator, loyal regent and inventive strategist — praised more for governance than generalship. The <b>Romance of the Three Kingdoms</b> later reimagined him as an almost supernatural genius (the east wind, the straw-boat arrows, the Empty Fort), the version most people know.',
      crux='The popular Zhuge Liang is a <b>literary creation built on a real foundation</b> — the historical minister was great, but the wizard is fiction.',
      conseq='The novel made Zhuge Liang one of the most beloved figures in all Chinese culture, worshipped in temples and quoted for centuries.',
      matters='Legends grow from, but exceed, their subjects — separating the real chancellor from the novel’s sage is the key to understanding both.'),

    E('legacy', 'to today', 'Immortal — the model of the loyal sage', ['TRIUMPH', 'POLITICS'],
      'Zhuge Liang becomes one of the most enduring figures in Chinese civilization — the very emblem of loyalty, wisdom and selfless service — his feather fan and calm gaze a cultural icon, his name a byword for the perfect strategist, and his Chu Shi Biao still memorized for its devotion centuries after his death.',
      svg_stack('A statesman who became a cultural ideal', [
          {'n': 1, 'label': 'Emblem of loyalty and wisdom', 'sub': 'the model minister who served without self-interest', 'color': '#0f766e'},
          {'n': 2, 'label': 'A lasting cultural icon', 'sub': 'the feather fan; temples; the Chu Shi Biao', 'color': '#a16207'},
          {'n': 3, 'label': 'Byword for genius', 'sub': 'his name still means “the perfect strategist”', 'color': '#166534'},
      ], takeaway='He won an immortality no battlefield could give — the enduring symbol of the wise, loyal servant of a just cause.', accent=AC),
      bg='Honored after death as <b>Marquis Zhongwu (“Loyal and Martial”)</b>, Zhuge Liang was revered by later dynasties and immortalized in literature, opera and folklore.',
      people='the emperors and scholars who venerated him; the countless readers of the novel; those who quote his Chu Shi Biao to this day.',
      what='Zhuge Liang became <b>the archetype of the loyal, wise minister</b> in Chinese culture — his image (the feather fan and Taoist robe), his devotion to a hopeless cause, and his <b>Chu Shi Biao</b> memorized for its loyalty — his name a synonym for supreme strategic genius.',
      crux='His enduring power lies in the union of <b>brilliance and virtue</b> — a genius who used his gifts selflessly for a cause and a lord he never abandoned.',
      conseq='Centuries on, he remains a household name across the Chinese world, a fixture of fiction, film and proverb — perhaps the most beloved strategist in history.',
      matters='The strategist who joins genius to loyalty outlives his defeats — Zhuge Liang lost his war yet won an immortality of the highest kind.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Zhuge Liang, styled Kongming, was the chancellor and chief strategist of Shu Han during China’s Three Kingdoms era — and, in the centuries since, its supreme symbol of loyal wisdom. Emerging from obscurity as the “Sleeping Dragon” of Longzhong, he handed the landless warlord Liu Bei a blueprint to divide the realm in three, forged the alliance that broke Cao Cao at Red Cliffs, built a small state into a disciplined kingdom, and spent his final years hurling that kingdom against a far mightier Wei. He is the ultimate study in <b>strategy over strength, loyalty over ambition, and the tragic limits of genius against the odds.</b></p>
<div class="ov-quote">“I have given my utmost, and only in death shall I stop.”<span>— sentiment of the Chu Shi Biao, attributed to Zhuge Liang</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">An orphan of the dying Han becomes the recluse “Sleeping Dragon” → gives Liu Bei the Longzhong Plan to split the realm in three → forges the alliance that wins Red Cliffs → builds Shu into a state and is made its chancellor → is entrusted the dying Liu Bei’s heir and refuses the throne → pacifies the south by freeing Meng Huo seven times → launches the Northern Expeditions and duels Sima Yi → and dies at the Wuzhang Plains, his cause unfinished but his name immortal.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🪶</div><h4>Strategy over strength</h4><p>The Longzhong Plan won a kingdom for a lord with no land.</p></div>
  <div class="ov-card"><div class="i">🤝</div><h4>The winning alliance</h4><p>His diplomacy at Red Cliffs halted Cao Cao’s conquest.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>The loyal minister</h4><p>Offered the throne, he chose devotion — China’s model of loyalty.</p></div>
  <div class="ov-card"><div class="i">🏔️</div><h4>Genius against the odds</h4><p>Logistics and ingenuity let tiny Shu strike at mighty Wei.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Sleeping Dragon</b><small> 181–207</small><p>Orphan to recluse to the Longzhong Plan.</p></div>
  <div><b>2 · Forging Three Kingdoms</b><small> 208–223</small><p>Red Cliffs, the base in Shu, chancellor.</p></div>
  <div><b>3 · Guardian of Shu</b><small> 223–225</small><p>The deathbed trust; rebuilding; Meng Huo.</p></div>
  <div><b>4 · The Northern Expeditions</b><small> 227–234</small><p>Chu Shi Biao, logistics, the duel with Sima Yi.</p></div>
  <div><b>5 · Death & Immortality</b><small> 234–today</small><p>Wuzhang Plains; history vs the novel; the legend.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Liu Bei', 'role': 'his lord', 'color': '#a16207',
     'bio': 'The landless warlord who courted Zhuge Liang with three visits, founded Shu Han, and on his deathbed entrusted his heir and state to him.',
     'rel': 'The ruler he served, and whose kingdom his strategy created.'},
    {'name': 'Sima Yi', 'role': 'great rival', 'color': '#b91c1c',
     'bio': 'The able Wei strategist who checked Zhuge Liang’s Northern Expeditions with patient, defensive warfare — his match in a war of nerves.',
     'rel': 'The rival whose caution his genius could never overcome.'},
    {'name': 'Cao Cao', 'role': 'the northern hegemon', 'color': '#111827',
     'bio': 'The dominant warlord of the north whose southern invasion Zhuge Liang’s alliance defeated at Red Cliffs in 208.',
     'rel': 'The great adversary his diplomacy first halted.'},
    {'name': 'Sun Quan', 'role': 'ally of the southeast', 'color': '#166534',
     'bio': 'The lord of Wu whom Zhuge Liang persuaded into alliance before Red Cliffs, and whose partnership Shu’s survival depended on.',
     'rel': 'The ally he won by diplomacy and cultivated for decades.'},
    {'name': 'Liu Shan', 'role': 'the boy-emperor', 'color': '#0f766e',
     'bio': 'Liu Bei’s young and weak heir, whom Zhuge Liang served as loyal regent — declining Liu Bei’s offer to take the throne himself.',
     'rel': 'The heir he guarded rather than supplanted.'},
]

KEY_EVENTS = [
    ('181', 'Zhuge Liang born', 'In Langya, as the Han collapses.'),
    ('207', 'The Three Visits', 'Liu Bei wins him; the Longzhong Plan.'),
    ('208', 'Battle of Red Cliffs', 'His alliance breaks Cao Cao.'),
    ('221', 'Chancellor of Shu Han', 'Liu Bei declares emperor.'),
    ('223', 'The trust at Baidicheng', 'Regent for young Liu Shan.'),
    ('225', 'Southern Campaign', 'Frees Meng Huo seven times.'),
    ('227', 'The Chu Shi Biao', 'Memorial before marching north.'),
    ('228–234', 'Northern Expeditions', 'The long duel with Sima Yi.'),
    ('234', 'Death at Wuzhang Plains', 'His campaign left unfinished.'),
]

MASTER = [
    {'year': '181', 'age': 'born', 'phase': 'Sleeping Dragon', 'title': 'Born in Langya', 'desc': 'Orphan of the dying Han.'},
    {'year': '207', 'age': 'age 26', 'phase': 'Sleeping Dragon', 'title': 'The Longzhong Plan', 'desc': 'Divide the realm in three.'},
    {'year': '208', 'age': 'age 27', 'phase': 'Three Kingdoms', 'title': 'Red Cliffs', 'desc': 'Alliance halts Cao Cao.'},
    {'year': '221', 'age': 'age 40', 'phase': 'Three Kingdoms', 'title': 'Chancellor of Shu', 'desc': 'Shu Han founded.'},
    {'year': '223', 'age': 'age 42', 'phase': 'Guardian of Shu', 'title': 'Regent for Liu Shan', 'desc': 'Refuses the throne.'},
    {'year': '225', 'age': 'age 44', 'phase': 'Guardian of Shu', 'title': 'Meng Huo pacified', 'desc': 'The rear secured.'},
    {'year': '227', 'age': 'age 46', 'phase': 'Northern Expeditions', 'title': 'Chu Shi Biao', 'desc': 'The march north begins.'},
    {'year': '234', 'age': 'age 54', 'phase': 'Death & Legend', 'title': 'Wuzhang Plains', 'desc': 'Dies in camp, campaign undone.'},
]

SOURCES = [
    ('Wikipedia — Zhuge Liang', 'https://en.wikipedia.org/wiki/Zhuge_Liang'),
    ('World History Encyclopedia — Zhuge Liang', 'https://www.worldhistory.org/Zhuge_Liang/'),
    ('Britannica — Zhuge Liang', 'https://www.britannica.com/biography/Zhuge-Liang'),
    ('Britannica — Three Kingdoms', 'https://www.britannica.com/place/Three-Kingdoms'),
    ('World History Encyclopedia — Battle of Red Cliffs', 'https://www.worldhistory.org/article/1201/battle-of-the-red-cliffs-208-ce/'),
]

def build_meta():
    return {
        'pid': 'gm-zhugeliang.html', 'kind': 'man', 'emoji': '🪶', 'accent': AC,
        'name': 'Zhuge Liang', 'years': '181–234', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Sleeping Dragon of Longzhong — chancellor and strategist of Shu Han, who drew the map of the Three Kingdoms, forged the alliance that won Red Cliffs, and became China’s enduring emblem of loyal wisdom.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Sleeping Dragon', 'type': 'timeline',
             'intro': 'An orphan of the collapsing Han grows into the recluse-scholar known as the “Sleeping Dragon,” then hands the wandering Liu Bei the Longzhong Plan to divide the realm in three.', 'events': PHASE_RISE},
            {'id': 'alliance', 'label': '2 · Forging Three Kingdoms', 'type': 'timeline',
             'intro': 'His diplomacy forges the alliance that breaks Cao Cao at Red Cliffs; he builds Liu Bei a real state in Shu and becomes chancellor of the new empire of Shu Han.', 'events': PHASE_ALLIANCE},
            {'id': 'regent', 'label': '3 · Guardian of Shu', 'type': 'timeline',
             'intro': 'Entrusted the dying Liu Bei’s young heir — and offered the throne itself — he chooses loyalty, rebuilds a battered Shu, and pacifies the south by winning hearts, not just battles.', 'events': PHASE_REGENT},
            {'id': 'expeditions', 'label': '4 · The Northern Expeditions', 'type': 'timeline',
             'intro': 'With the Chu Shi Biao he opens his life’s campaign against mighty Wei — winning by logistics and invention, and settling into a war of nerves with his great rival Sima Yi.', 'events': PHASE_EXPEDITIONS},
            {'id': 'end', 'label': '5 · Death & Immortality', 'type': 'timeline',
             'intro': 'He dies in camp at the Wuzhang Plains with his cause unfinished — but the real chancellor of the histories is transfigured by the later novel into an almost supernatural sage, and becomes immortal.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard encyclopaedic and historical sources; the historical record follows Chen Shou’s Records of the Three Kingdoms, while famous episodes such as the Empty Fort Strategy and the borrowed arrows derive from the later novel Romance of the Three Kingdoms and are noted as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
