# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Otto Skorzeny.
The Waffen-SS commando officer of Nazi Germany — famed for the Gran Sasso raid, dubbed by Allied press "the most dangerous man in Europe," and clear-eyed about the regime he served."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#57534e'  # field-grey / stone — grim, non-glorifying

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — VIENNA AND THE ROAD TO THE SS
PHASE_ORIGINS = [
    E('birth', '1908', 'Born in Vienna at the empire’s twilight', ['RISE', 'ORIGINS'],
      'Otto Skorzeny is born on 12 June 1908 in Vienna, capital of Austria-Hungary, into a middle-class family of engineers — a big, physically imposing child raised in the German-nationalist milieu of a multinational empire soon to collapse in the First World War.',
      svg_row('An Austrian childhood in a dying empire', [
          {'n': 1, 'label': 'Born in Vienna, 12 June 1908', 'sub': 'in the Austro-Hungarian Empire', 'color': '#57534e'},
          {'n': 2, 'label': 'A family of engineers', 'sub': 'middle-class, German-nationalist', 'color': '#3730a3'},
          {'n': 3, 'label': 'Empire collapses, 1918', 'sub': 'defeat and a shrunken Austrian republic', 'color': '#b45309'},
      ], edge_labels=['into', 'then'], takeaway='He grew up German-speaking and nationalist in an empire that lost the First World War and vanished — the grievance-soaked world that bred Austrian fascism.', accent=AC),
      bg='<b>Otto Skorzeny</b> was born on <b>12 June 1908</b> in Vienna, then capital of the sprawling, multi-ethnic Austro-Hungarian Empire, which collapsed in defeat in 1918 when he was ten.',
      people='his engineer father; the German-nationalist Viennese milieu; a defeated Austrian republic humiliated by the post-war settlement.',
      what='Skorzeny grew up an unusually tall, strong boy in a <b>middle-class Viennese family</b>, absorbing the German-nationalist resentments common in post-imperial Austria — the same soil from which Austrian Nazism would grow.',
      crux='His formation was <b>ordinary and provincial</b> — nothing marked him for infamy but the poisoned nationalist politics of inter-war Austria.',
      conseq='He would come of age in a country ripe for the fascist and pan-German agitation that eventually drew him in.',
      matters='Monstrous careers often start in unremarkable homes — the Vienna that shaped Hitler shaped Skorzeny too.'),

    E('mensur', '1926–1931', 'Engineering studies and the duelling scar', ['RISE', 'IDEAS'],
      'Skorzeny studies civil engineering at the Technical University of Vienna, where he joins a duelling fraternity and fights in the ritual Mensur — earning the deep facial scar (Schmiss) that would later brand him in the press as "Scarface," a badge of the aggressive student nationalism of his day.',
      svg_stack('The scar and the fraternity', [
          {'n': 1, 'label': 'Technical University of Vienna', 'sub': 'trains as a civil engineer', 'color': '#3730a3'},
          {'n': 2, 'label': 'Joins a duelling fraternity', 'sub': 'fights the ritual Mensur with sabres', 'color': '#57534e'},
          {'n': 3, 'label': 'Earns his facial Schmiss', 'sub': 'the scar that made him “Scarface”', 'color': '#b91c1c'},
      ], takeaway='The scar he wore as a mark of honour among nationalist students became, years later, the press-friendly face of “the most dangerous man in Europe.”', accent=AC),
      bg='Skorzeny studied <b>civil engineering</b> at the Technical University of Vienna in the late 1920s, a hotbed of pan-German and antisemitic student politics.',
      people='his duelling-fraternity comrades; the student nationalist movements of Weimar-era Austria; later Allied journalists who seized on his scar.',
      what='He took part in the <b>Mensur</b>, the ritualised academic fencing duel, and received a prominent <b>facial scar (Schmiss)</b> — worn as a mark of courage in fraternity culture — which the wartime press later turned into his nickname <b>“Scarface.”</b>',
      crux='The duelling scar embodied a <b>cult of martial toughness</b> among nationalist students that shaded easily into fascist politics.',
      conseq='He left university a trained engineer and a hardened German nationalist, drawn to the rising Nazi movement.',
      matters='Image and reality diverge — a fencing scar, not battlefield valour, gave Skorzeny the menacing face his legend traded on.'),

    E('nazi', '1932–1934', 'Joining the Nazi movement', ['POLITICS', 'RISE'],
      'Skorzeny commits himself to Nazism early — joining the Austrian Nazi party in 1932 and the SA in 1934, active in the pan-German agitation that sought to fold Austria into Hitler’s Reich, a cause consummated by the 1938 Anschluss he welcomed.',
      svg_row('From nationalist to Nazi', [
          {'n': 1, 'label': 'Joins Austrian Nazis, 1932', 'sub': 'the party is soon banned in Austria', 'color': '#78350f'},
          {'n': 2, 'label': 'Enters the SA, 1934', 'sub': 'Nazi paramilitary street politics', 'color': '#57534e'},
          {'n': 3, 'label': 'The Anschluss, 1938', 'sub': 'Austria absorbed into Hitler’s Reich', 'color': '#b91c1c'},
      ], edge_labels=['then', 'to'], takeaway='He was no reluctant conscript — Skorzeny chose Nazism voluntarily and early, years before the war made it expedient.', accent=AC),
      bg='In the early 1930s the Austrian Nazi party agitated — often violently — for union with Germany; it was banned after a failed 1934 putsch that murdered Chancellor Dollfuss.',
      people='the Austrian Nazi movement; the SA (Sturmabteilung) he joined; Adolf Hitler, whose pan-German project he embraced.',
      what='Skorzeny joined the <b>Austrian Nazi party in 1932</b> and the <b>SA in 1934</b>, taking part in the pan-German movement to annex Austria — a goal achieved by the <b>Anschluss of March 1938</b>, which he actively supported.',
      crux='His Nazism was a matter of <b>early, deliberate conviction</b>, not wartime opportunism — a fact any honest account must state plainly.',
      conseq='When war came he volunteered for Hitler’s armed forces, entering the Waffen-SS.',
      matters='It is essential to be clear-eyed: Skorzeny embraced a criminal, antisemitic regime by choice, long before his commando fame.'),

    E('waffenss', '1939–1941', 'Into the Waffen-SS', ['BATTLE', 'RISE'],
      'Rejected as too old and too tall for the Luftwaffe, Skorzeny joins the Waffen-SS — the armed wing of the SS — training with the Leibstandarte SS Adolf Hitler and going to war as an officer of a force that was, alongside its battlefield role, an instrument of the Nazi regime’s crimes.',
      svg_stack('An officer of the armed SS', [
          {'n': 1, 'label': 'Rejected by the Luftwaffe, 1939', 'sub': 'deemed too old at 31, too tall at 1.94m', 'color': '#a16207'},
          {'n': 2, 'label': 'Joins the Waffen-SS', 'sub': 'the armed wing of Himmler’s SS', 'color': '#57534e'},
          {'n': 3, 'label': 'Serves with the Leibstandarte', 'sub': 'Hitler’s SS bodyguard division', 'color': '#b91c1c'},
      ], takeaway='He served in the Waffen-SS — a force that fought as regular troops but was bound to the SS, an organisation declared criminal at Nuremberg.', accent=AC),
      bg='On the outbreak of war Skorzeny sought combat service; turned down by the Luftwaffe, he entered the <b>Waffen-SS</b>, the military formations of Heinrich Himmler’s SS.',
      people='the Leibstandarte SS Adolf Hitler, his first unit; the wider SS, the Nazi regime’s core instrument of terror and genocide.',
      what='Skorzeny trained with the <b>Leibstandarte SS Adolf Hitler</b> and served as an engineer and officer, joining a force that combined front-line fighting with the SS’s role in the regime’s atrocities.',
      crux='He advanced within an organisation whose institutions — the SS — ran the machinery of the Holocaust, a context his exploits can never be separated from.',
      conseq='He was posted to the Eastern Front, where his war — and the regime’s worst crimes — would unfold.',
      matters='The uniform mattered: to narrate Skorzeny is to narrate a Waffen-SS officer, not a neutral soldier of fortune.'),
]

# ==================================================================  PHASE 2 — THE EASTERN FRONT AND THE COMMANDO TURN
PHASE_COMMANDO = [
    E('eastern', '1941–1942', 'The Eastern Front and a wound', ['BATTLE', 'TURNING POINT'],
      'Skorzeny fights on the Eastern Front with the SS Division Das Reich through the invasion of the Soviet Union and the drive on Moscow — a campaign of unparalleled brutality — until he is wounded by shrapnel in early 1942 and invalided back, his front-line combat career effectively over.',
      svg_row('War in the East, then a wound', [
          {'n': 1, 'label': 'Barbarossa, 1941', 'sub': 'invasion of the USSR with Das Reich', 'color': '#78350f'},
          {'n': 2, 'label': 'The drive on Moscow', 'sub': 'a war of annihilation in the East', 'color': '#57534e'},
          {'n': 3, 'label': 'Wounded, early 1942', 'sub': 'shrapnel ends his front-line service', 'color': '#b91c1c'},
      ], edge_labels=['to', 'until'], takeaway='His conventional combat was brief; a wound pulled him from the line and set him on the path to special operations.', accent=AC),
      bg='Skorzeny served with the <b>SS Division Das Reich</b> during Operation Barbarossa (1941), the Nazi invasion of the Soviet Union — a campaign marked by mass atrocities against civilians and prisoners.',
      people='the men of Das Reich; the Soviet soldiers and civilians on the receiving end of the Nazi war of annihilation.',
      what='He took part in the <b>advance into the USSR and toward Moscow</b>, then was <b>wounded by shrapnel in early 1942</b> and evacuated, ending his career as a front-line combat officer.',
      crux='The wound was a <b>hinge</b> — it removed him from ordinary soldiering and opened the way to a staff and special-operations role.',
      conseq='Recovering in Berlin, he was available when the SS looked for an officer to build a commando unit.',
      matters='The Eastern Front context is inescapable — the theatre where Skorzeny won his spurs was the site of the regime’s greatest crimes.'),

    E('friedenthal', '1943', 'Chosen to lead the SS commandos', ['RISE', 'REFORM'],
      'In April 1943 Skorzeny — an obscure captain — is unexpectedly picked to command a new SS special-forces unit at Friedenthal, tasked with sabotage, raids and unconventional warfare, modelled loosely on British commandos: the springboard from which his fame would suddenly erupt.',
      svg_stack('Building a special-operations unit', [
          {'n': 1, 'label': 'Chosen, April 1943', 'sub': 'an unknown captain given a new command', 'color': '#3730a3'},
          {'n': 2, 'label': 'Sonderverband Friedenthal', 'sub': 'SS sabotage and commando unit', 'color': '#57534e'},
          {'n': 3, 'label': 'Unconventional warfare', 'sub': 'raids, sabotage, deception, kidnappings', 'color': '#b45309'},
      ], takeaway='A minor officer was handed the tools of special warfare — and would use the first big mission to make himself a household name.', accent=AC),
      bg='In 1943 the SS sought to develop <b>special-operations capability</b>, partly in imitation of British commando and SOE units, and needed a commander for a new formation.',
      people='the SS leadership who selected him; the men of the Friedenthal unit (later SS Jagdverband); the rival Wehrmacht/Abwehr special forces.',
      what='In <b>April 1943</b> Skorzeny was appointed to command the <b>Sonderverband z.b.V. Friedenthal</b>, a unit for sabotage, raids and irregular warfare — an appointment that would soon make him famous.',
      crux='He was given a <b>blank slate for daring missions</b> at the exact moment Hitler needed a spectacular success.',
      conseq='Within months he was handed the mission that would define him — the rescue of Mussolini.',
      matters='Institutions create their heroes — Skorzeny’s legend began with a bureaucratic posting, not a battlefield.'),
]

# ==================================================================  PHASE 3 — GRAN SASSO AND SUDDEN FAME
PHASE_GRANSASSO = [
    E('gransasso', '1943', 'Gran Sasso — the glider rescue of Mussolini', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'On 12 September 1943, in Operation Eiche, Skorzeny leads a glider-borne raid onto the Gran Sasso plateau to snatch the deposed Italian dictator Benito Mussolini from the Campo Imperatore hotel where he is held — a near-bloodless coup de main that stuns the world and makes Skorzeny instantly famous.',
      svg_row('The raid that made his name', [
          {'n': 1, 'label': 'Mussolini deposed, held on Gran Sasso', 'sub': 'imprisoned at the Campo Imperatore hotel', 'color': '#78350f'},
          {'n': 2, 'label': 'Gliders land on the peak, 12 Sep 1943', 'sub': 'paratroopers and SS commandos storm in', 'color': '#57534e'},
          {'n': 3, 'label': 'Mussolini flown out', 'sub': 'spirited off in a light Storch aircraft', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='A daring, near-bloodless raid handed Nazi propaganda a spectacular victory — and turned Skorzeny into a celebrity commando overnight.', accent=AC),
      bg='After Mussolini’s fall in July 1943, Italy’s new government held him prisoner; by September he was confined at the <b>Campo Imperatore hotel</b> high on the Gran Sasso massif. Hitler ordered a rescue.',
      people='<b>Benito Mussolini</b>, the rescued dictator; the German Fallschirmjäger (paratroopers) who did much of the fighting; General Kurt Student, who planned the airborne operation.',
      what='On <b>12 September 1943</b>, gliders carrying paratroopers and Skorzeny’s SS commandos landed on the plateau; the guards surrendered without a real fight, and Mussolini was flown out in a small <b>Fieseler Storch</b> aircraft — <b>Operation Eiche (Oak)</b>.',
      crux='Skorzeny grasped the <b>propaganda value</b> of the coup, ensuring he was photographed at Mussolini’s side and credited as the hero, though paratroopers bore the main effort.',
      conseq='He was decorated with the Knight’s Cross the next day, promoted, and lionised across the Reich as the model of the audacious commando.',
      matters='It was a genuine feat of nerve — but also a manufactured legend, propping up a puppet fascist state and a faltering regime.'),

    E('fame', '1943–1944', '“The most dangerous man in Europe”', ['LEGACY', 'POLITICS'],
      'Gran Sasso transforms Skorzeny into a propaganda icon — promoted, decorated, and set up by Goebbels as the daring face of German special forces — while Allied newspapers, half in alarm and half in fascination, brand him "the most dangerous man in Europe."',
      svg_stack('Manufacturing a commando legend', [
          {'n': 1, 'label': 'Knight’s Cross, 13 Sep 1943', 'sub': 'decorated and promoted after Gran Sasso', 'color': '#166534'},
          {'n': 2, 'label': 'Nazi propaganda hero', 'sub': 'Goebbels makes him a household name', 'color': '#b91c1c'},
          {'n': 3, 'label': '“Most dangerous man in Europe”', 'sub': 'the Allied press’s alarmed label', 'color': '#57534e'},
      ], takeaway='His reputation was as much a media creation as a military one — useful to Nazi propaganda and, ironically, amplified by his enemies.', accent=AC),
      bg='The Nazi propaganda ministry seized on Gran Sasso as a rare good-news story in a war turning against Germany, promoting Skorzeny relentlessly.',
      people='Joseph Goebbels’ propaganda apparatus; Hitler, who received him personally; the Allied journalists who coined his nickname.',
      what='Skorzeny was decorated with the <b>Knight’s Cross</b>, promoted to major, and built up as the archetypal daring commando; the Allied press dubbed him <b>“the most dangerous man in Europe.”</b>',
      crux='His fame rested on a <b>symbiosis of propaganda</b> — Nazi glorification and Allied dread feeding the same larger-than-life image.',
      conseq='He was now Hitler’s favoured troubleshooter, entrusted with the regime’s most delicate special missions.',
      matters='Reputation can outrun reality — Skorzeny’s later career, and his post-war myth, rode on an image inflated by both sides.'),
]

# ==================================================================  PHASE 4 — KEEPING THE REICH IN THE WAR
PHASE_WAR = [
    E('panzerfaust', '1944', 'Operation Panzerfaust — coercing Hungary', ['BATTLE', 'POLITICS'],
      'In October 1944, as Hungary’s regent Miklós Horthy tries to make peace with the advancing Soviets, Skorzeny’s men kidnap Horthy’s son — reportedly rolled up in a carpet — and Skorzeny storms Budapest’s castle in Operation Panzerfaust, forcing Horthy out and installing the fascist Arrow Cross to keep Hungary fighting for Germany.',
      svg_row('Kidnap and coup to hold an ally', [
          {'n': 1, 'label': 'Horthy seeks an armistice', 'sub': 'Hungary tries to quit the war, Oct 1944', 'color': '#78350f'},
          {'n': 2, 'label': 'His son seized, “in a carpet”', 'sub': 'Skorzeny abducts Miklós Horthy Jr.', 'color': '#57534e'},
          {'n': 3, 'label': 'Castle Hill stormed', 'sub': 'Horthy forced out; Arrow Cross installed', 'color': '#b91c1c'},
      ], edge_labels=['so', 'then'], takeaway='By kidnapping and coup Skorzeny kept Hungary in the war — clearing the way for the murderous Arrow Cross regime and the deportation of Budapest’s Jews.', accent=AC),
      bg='By late 1944 Hungary’s regent <b>Miklós Horthy</b>, seeing the war lost, sought a separate peace with the USSR — a defection Hitler was determined to prevent.',
      people='<b>Admiral Horthy</b> and his son <b>Miklós Horthy Jr.</b>, the kidnap victim; the fascist <b>Arrow Cross</b> movement installed in power.',
      what='In <b>Operation Panzerfaust (October 1944)</b>, Skorzeny’s men abducted Horthy’s son (legend has it wrapped in a carpet) and Skorzeny seized <b>Budapest’s Castle Hill</b>, coercing Horthy’s abdication and the installation of the pro-Nazi Arrow Cross.',
      crux='This was <b>political thuggery in uniform</b> — coercion and hostage-taking to keep a wavering ally chained to a losing, genocidal cause.',
      conseq='The Arrow Cross regime unleashed a reign of terror and accelerated the deportation and murder of Hungarian Jews.',
      matters='Behind the “daring raid” framing lies an atrocity-enabling coup — the human cost of keeping Hungary in Hitler’s war was catastrophic.'),

    E('greif', '1944', 'Operation Greif — false flags in the Bulge', ['BATTLE', 'DRAMA'],
      'For the December 1944 Ardennes offensive, Skorzeny mounts Operation Greif — sending English-speaking German soldiers in captured US uniforms and jeeps behind Allied lines to sow confusion and seize Meuse bridges — a false-flag scheme that largely fails militarily but triggers extraordinary panic.',
      svg_stack('German soldiers in American uniforms', [
          {'n': 1, 'label': 'Battle of the Bulge, Dec 1944', 'sub': 'Hitler’s last western offensive', 'color': '#78350f'},
          {'n': 2, 'label': 'Panzer Brigade 150 & Einheit Stielau', 'sub': 'English speakers in captured US kit', 'color': '#57534e'},
          {'n': 3, 'label': 'Mission largely fails', 'sub': 'shortages; bridges never taken', 'color': '#b45309'},
      ], takeaway='Militarily Greif achieved little — but the mere idea of infiltrators in American uniform threw the Allied rear into disproportionate chaos.', accent=AC),
      bg='For the surprise <b>Ardennes offensive</b> (Battle of the Bulge) in December 1944, Skorzeny was ordered to seize bridges over the Meuse and disrupt the Allied rear.',
      people='the roughly 2,500 men of <b>Panzer Brigade 150</b>; the small <b>Einheit Stielau</b> commando teams of English speakers; disguised Panther tanks masquerading as US M10s.',
      what='In <b>Operation Greif</b>, English-speaking Germans in <b>captured American uniforms and vehicles</b> slipped behind US lines; but with the offensive stalling and equipment lacking, the brigade never took its bridges and was used as ordinary infantry.',
      crux='The operation’s real weapon was <b>psychological</b> — deception and false-flag disguise rather than combat power.',
      conseq='It provoked a wave of paranoia in the Allied lines, and its captured participants faced execution as spies.',
      matters='Greif is a case study in asymmetric effect — a failed raid whose disruption came from fear, not force.'),

    E('spypanic', '1944–1945', 'Spy panic, the Eisenhower rumour, and executions', ['DRAMA', 'TRAGEDY'],
      'Greif spawns a frenzy of suspicion behind Allied lines — jittery GIs man checkpoints quizzing each other on baseball and state capitals, a rumour spreads that Skorzeny plans to kill Eisenhower (briefly confining the general), and captured Germans caught out of uniform are shot as spies, seeding the war-crimes charge Skorzeny will later face.',
      svg_row('Fear does the work the raid could not', [
          {'n': 1, 'label': 'Checkpoint mania', 'sub': 'GIs quiz each other on US trivia', 'color': '#57534e'},
          {'n': 2, 'label': 'The Eisenhower rumour', 'sub': 'plot to kill Ike; general kept confined', 'color': '#b45309'},
          {'n': 3, 'label': 'Captured spies executed', 'sub': 'Germans in US uniform shot; ~13+ die', 'color': '#b91c1c'},
      ], edge_labels=['then', 'and'], takeaway='The panic was wildly out of proportion to the threat — and the execution of captured infiltrators set up the war-crimes case against Skorzeny.', accent=AC),
      bg='Word that German commandos in American uniform were loose behind the lines spread quickly, and Allied security clamped down hard.',
      people='General <b>Dwight D. Eisenhower</b>, the rumoured target; nervous American sentries; the captured Greif soldiers court-martialled and shot.',
      what='US troops set up <b>checkpoints quizzing soldiers on American trivia</b>; a rumour that Skorzeny meant to <b>assassinate Eisenhower</b> saw the general briefly confined; and captured Germans caught in US uniform were <b>executed as spies</b> (at least around thirteen).',
      crux='The disruption flowed from <b>rumour and dread</b> — the alleged Eisenhower plot was never substantiated and may have been exaggerated.',
      conseq='The wartime killings and disguise tactics became the basis of the post-war charge that Skorzeny had ordered illegal use of enemy uniforms.',
      matters='Legend outran fact here — the Eisenhower “plot” is best read as disputed rumour, and it is flagged as such rather than taken at face value.'),
]

# ==================================================================  PHASE 5 — DEFEAT, TRIAL, AND ESCAPE
PHASE_TRIAL = [
    E('capture', '1945', 'Defeat and surrender', ['DEATH', 'TURNING POINT'],
      'As the Reich collapses, Skorzeny — after a final scheme to organise Alpine "Werwolf" resistance comes to nothing — surrenders to American forces in May 1945, ending the war as one of the Allies’ most wanted men and a prisoner facing investigation.',
      svg_stack('The commando gives himself up', [
          {'n': 1, 'label': 'The Reich collapses, 1945', 'sub': 'Germany overrun from east and west', 'color': '#78350f'},
          {'n': 2, 'label': 'Alpine “redoubt” fizzles', 'sub': 'Werwolf resistance amounts to little', 'color': '#57534e'},
          {'n': 3, 'label': 'Surrenders to the US, May 1945', 'sub': 'held as a most-wanted prisoner', 'color': '#b91c1c'},
      ], takeaway='The feared commando ended the war in Allied custody — his notoriety now a liability as investigators weighed charges.', accent=AC),
      bg='In the last weeks of the war rumours swirled of a Nazi <b>“Alpine Redoubt”</b> and Werwolf guerrilla resistance; little of it materialised.',
      people='the American forces to whom he surrendered; Allied war-crimes investigators; the vanished Nazi command structure.',
      what='After the collapse, Skorzeny <b>surrendered to US troops in May 1945</b>, having failed to organise meaningful last-ditch resistance, and was held as a high-value prisoner pending investigation.',
      crux='His fame made him a <b>marked man</b> — captured, interrogated, and slated for trial.',
      conseq='He was brought before an American military tribunal at Dachau in 1947.',
      matters='The hunter became the hunted — Skorzeny’s wartime celebrity ensured he would answer for his methods in court.'),

    E('dachau', '1947', 'The Dachau trial and acquittal', ['POLITICS', 'DRAMA'],
      'In 1947 Skorzeny is tried before a US military tribunal at Dachau, chiefly over Operation Greif’s use of American uniforms — and is acquitted, in part after a British SOE officer, Forest Yeo-Thomas, testifies that the Allies used similar ruses, leaving the legality question unresolved but Skorzeny cleared.',
      svg_compare('The war-crimes case at Dachau', {
          'head': 'The prosecution', 'color': '#b91c1c',
          'items': ['Ordered Germans into US uniforms', 'Improper use of enemy insignia', 'Linked to executed “spy” infiltrators', 'A violation of the laws of war'],
      }, {
          'head': 'The defence', 'color': '#3730a3',
          'items': ['Uniforms for deception, not combat', 'A recognised “ruse of war”', 'Allies used the same tactics', 'SOE’s Yeo-Thomas testifies for defence'],
      }, verdict='Acquitted in 1947 — the tribunal accepted that wearing enemy uniform short of actual fighting was a lawful ruse.',
         takeaway='He was cleared on the uniform charge — an acquittal on a narrow legal point, not an exoneration of his service to the Nazi regime.', accent=AC),
      bg='Skorzeny faced a <b>US military tribunal at Dachau in 1947</b>, the central charge being that Operation Greif had improperly used American uniforms.',
      people='the American prosecutors and judges; British SOE officer <b>Forest “Tommy” Yeo-Thomas</b>, who testified for the defence; Skorzeny’s co-accused.',
      what='The court weighed whether wearing enemy uniform was a war crime; <b>Yeo-Thomas testified that Allied special forces used comparable deceptions</b>, and Skorzeny was <b>acquitted in 1947</b> — the tribunal treating uniform-deception short of combat as a lawful ruse of war.',
      crux='The verdict turned on a <b>fine and still-contested point of the laws of war</b>, not on any broad judgement of his career.',
      conseq='Cleared of the criminal charge, he nonetheless remained in an internment camp pending denazification proceedings.',
      matters='Acquittal on a technical charge is not vindication — it is reported here as fact, without erasing what he served.'),

    E('escape', '1948', 'Escape from internment', ['DRAMA', 'POLITICS'],
      'Held in a denazification internment camp after his acquittal, Skorzeny escapes in July 1948 — reportedly with the help of former SS men, some accounts claim in ex-German uniforms — vanishing into the underground networks of fugitive Nazis and never facing a denazification verdict.',
      svg_row('The fugitive slips away', [
          {'n': 1, 'label': 'Held pending denazification', 'sub': 'interned after the 1947 acquittal', 'color': '#3730a3'},
          {'n': 2, 'label': 'Escapes, 27 July 1948', 'sub': 'reportedly aided by ex-SS comrades', 'color': '#57534e'},
          {'n': 3, 'label': 'Into the Nazi underground', 'sub': 'linked in lore to “ODESSA” networks', 'color': '#78350f'},
      ], edge_labels=['then', 'to'], takeaway='He walked away from justice into the shadow world of escaped Nazis — the milieu that fed the ODESSA legend.', accent=AC),
      bg='Even after acquittal, Skorzeny remained interned awaiting a <b>denazification hearing</b> that could have penalised him for his SS role.',
      people='the former SS comrades said to have aided him; the fugitive-Nazi networks (romanticised as <b>“ODESSA”</b>); post-war intelligence services.',
      what='On <b>27 July 1948</b> Skorzeny <b>escaped from the internment camp</b> — by some accounts with the help of ex-SS men — and disappeared, never completing the denazification process.',
      crux='His flight placed him squarely in the <b>post-war underworld of escaped Nazis</b>, later mythologised as the ODESSA network.',
      conseq='He surfaced in Franco’s Spain, beginning a long and murky post-war career.',
      matters='The neat “ODESSA” story is partly legend; what is documented is that a wanted SS officer escaped and was quietly helped to a new life.'),
]

# ==================================================================  PHASE 6 — EXILE, INTRIGUE, AND LEGEND
PHASE_EXILE = [
    E('madrid', '1950s', 'Madrid — arms dealer and Franco’s guest', ['POLITICS', 'LEGACY'],
      'Skorzeny settles in Franco’s Spain, building a comfortable life in Madrid as a businessman and arms dealer, advising security services and moving among a network of exiled fascists, former Nazis and Cold War intelligence contacts across Spain, Latin America and the Middle East.',
      svg_stack('A new life in fascist Spain', [
          {'n': 1, 'label': 'Settles in Madrid', 'sub': 'under Franco’s protection', 'color': '#3730a3'},
          {'n': 2, 'label': 'Businessman and arms dealer', 'sub': 'engineering firms and weapons deals', 'color': '#57534e'},
          {'n': 3, 'label': 'Advisor and fixer', 'sub': 'security work; ties to exiled fascists', 'color': '#78350f'},
      ], takeaway='He converted his notoriety into a prosperous exile — trading on contacts and reputation as an arms dealer and shadowy advisor.', accent=AC),
      bg='By around 1950 Skorzeny had made his way to <b>Franco’s Spain</b>, which sheltered many former Nazis, and established himself in Madrid.',
      people='the Franco regime that hosted him; exiled fascists and former SS men; the arms buyers, governments and agencies he dealt with.',
      what='In Madrid he worked as a <b>businessman and international arms dealer</b>, reportedly advised security and intelligence services, and became a hub in a <b>web of former Nazis and Cold War operators</b>.',
      crux='His post-war role was that of a <b>well-connected fixer</b>, monetising his fame and contacts rather than any renewed ideology.',
      conseq='These connections drew persistent — and often unverifiable — claims of work for various intelligence agencies.',
      matters='The line between fact and legend blurs here: the documented arms dealer is real, the omnipotent spymaster of myth largely is not.'),

    E('intelligence', '1950s–1960s', 'Intelligence claims — fact and legend', ['POLITICS', 'DISPUTED'],
      'Skorzeny’s post-war years attract a swirl of intelligence claims — advising Egypt’s military, links to Western services, and a much-repeated but disputed story that around 1962 he worked for Israel’s Mossad against German rocket scientists in Egypt — tales where documented fact and Cold War legend are hard to separate.',
      svg_row('Where legend outruns the record', [
          {'n': 1, 'label': 'Advisor in the Middle East', 'sub': 'reportedly to Egypt’s military', 'color': '#3730a3'},
          {'n': 2, 'label': 'The alleged Mossad episode', 'sub': 'c.1962, targeting scientists in Egypt', 'color': '#b45309'},
          {'n': 3, 'label': 'Claims “disputed”', 'sub': 'sourced largely to later accounts', 'color': '#b91c1c'},
      ], edge_labels=['then', 'so'], takeaway='These episodes are flagged as DISPUTED — repeated in popular histories, but resting on thin, contested evidence.', accent=AC),
      bg='Cold War Madrid was thick with rumour, and Skorzeny’s name attached itself to countless intelligence stories, many impossible to verify.',
      people='Egypt’s government and the German rocket scientists working there; Israel’s <b>Mossad</b>; the journalists and memoirists who later spread the tales.',
      what='He is said to have <b>advised Egyptian and other security forces</b>, and — in a <b>much-disputed account</b> — to have been recruited by <b>Israeli Mossad around 1962</b> to help target German scientists aiding Egypt’s missile programme (Operation Damocles).',
      crux='The <b>Mossad story is unverified</b> — dramatic, widely retold, but drawn largely from later journalistic accounts rather than solid contemporary proof.',
      conseq='Such tales inflated his post-war mystique far beyond what the documentary record can support.',
      matters='Honest biography must separate the two: a real arms-dealing fixer surrounded by legends that should be labelled, not repeated as fact.'),

    E('death', '1975', 'Death in Madrid', ['DEATH', 'LEGACY'],
      'Otto Skorzeny dies of cancer in Madrid on 5 July 1975, aged 67 — an unrepentant former SS officer who never faced a reckoning for his service to the Nazi regime, buried with a graveside gathering of old comrades giving the Nazi salute.',
      svg_stack('An unrepentant end', [
          {'n': 1, 'label': 'Dies in Madrid, 5 July 1975', 'sub': 'lung cancer, aged 67', 'color': '#78350f'},
          {'n': 2, 'label': 'Never fully brought to account', 'sub': 'no reckoning for his SS service', 'color': '#57534e'},
          {'n': 3, 'label': 'Old comrades salute the grave', 'sub': 'unrepentant to the last', 'color': '#b91c1c'},
      ], takeaway='He died comfortable and unrepentant — a reminder that many Nazi functionaries were never truly held to account.', accent=AC),
      bg='After a quarter-century of comfortable exile, Skorzeny fell ill with cancer in his final years in Spain.',
      people='the old SS comrades who attended his funeral; his family; the biographers and mythmakers who kept his story alive.',
      what='Skorzeny <b>died in Madrid on 5 July 1975</b>, aged 67; at his burial, former comrades reportedly gave the <b>Nazi salute</b>, and he went to his grave <b>unrepentant</b> about his role in the regime.',
      crux='His death underlined a hard truth — he <b>escaped any real accounting</b> for serving one of history’s most criminal regimes.',
      conseq='His name endured in commando lore, conspiracy theories and popular history alike.',
      matters='The comfortable, unpunished end of an SS officer is itself part of the reckoning with how many Nazis evaded justice.'),

    E('legacy', '1975–', 'The legend and the record', ['LEGACY', 'IDEAS'],
      'Skorzeny leaves a double legacy — remembered in military circles as a pioneer of modern special operations for Gran Sasso, and in popular culture as a near-mythical super-commando and conspiracy figure — a reputation that must be weighed against the criminal regime he served and the myths he helped spin.',
      svg_compare('Weighing the man against the myth', {
          'head': 'The documented record', 'color': '#57534e',
          'items': ['Voluntary early Nazi and SS officer', 'Gran Sasso: a real, daring raid', 'Coup and kidnap kept Hungary in the war', 'Post-war arms dealer and fixer'],
      }, {
          'head': 'The inflated legend', 'color': '#b45309',
          'items': ['“Most dangerous man in Europe”', 'Omniscient super-commando', 'Master of a vast “ODESSA”', 'Unverified Mossad and spy tales'],
      }, verdict='A skilled and daring raider — but a Nazi officer whose legend, much of it self-made, should be reported, not admired.',
         takeaway='The lasting lesson is to hold both truths: real operational audacity, in the service of an evil cause, wrapped in a myth bigger than the man.', accent=AC),
      bg='Skorzeny’s exploits, especially Gran Sasso, became standard references in the history of special operations and irregular warfare.',
      people='military historians who study his raids; conspiracy writers who mythologise him; the veterans and victims of the regime he served.',
      what='He is remembered both as a <b>pioneer of modern commando and special-forces methods</b> and as a <b>figure of legend and conspiracy</b> — a reputation inseparable from the <b>criminal Nazi regime</b> he chose to serve.',
      crux='His legacy demands <b>critical distance</b> — recognising the operational skill without lionising the man or the cause.',
      conseq='He remains a contested figure, studied for his methods and cited as a cautionary example of how myth can eclipse fact.',
      matters='The point is not to admire but to understand — a daring soldier can still be an instrument of evil, and legend can outgrow the record.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Otto Skorzeny was a Waffen-SS commando officer of Nazi Germany — best known for the 1943 glider raid that plucked Mussolini off the Gran Sasso, an exploit that made him a propaganda celebrity and earned him the Allied press label “the most dangerous man in Europe.” An Austrian engineer who embraced Nazism early and by choice, he led false-flag and kidnapping operations to prop up Hitler’s war, was acquitted at a 1947 Dachau war-crimes trial on a narrow legal point, escaped internment in 1948, and lived out a comfortable, unrepentant exile in Franco’s Madrid as an arms dealer trailed by disputed intelligence legends. This guide recounts his exploits accurately while remaining <b>clear-eyed about the regime he served.</b></p>
<div class="ov-quote">“The most dangerous man in Europe.”<span>— the wartime Allied press label, as much myth as fact</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A Viennese engineer who joins the Nazis early and enters the Waffen-SS → is wounded on the Eastern Front and picked to lead SS commandos → wins sudden fame with the Gran Sasso rescue of Mussolini → keeps Hungary in the war by kidnap and coup, then sows panic in the Bulge with false-flag Operation Greif → surrenders in 1945, is acquitted at Dachau in 1947 and escapes internment in 1948 → and dies an unrepentant exile in Franco’s Madrid, wrapped in intelligence legends larger than the man.</p>
<div class="ov-lbl">How to read him honestly</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⚑</div><h4>A Nazi by choice</h4><p>Joined the party in 1932; an SS officer, not a neutral soldier.</p></div>
  <div class="ov-card"><div class="i">🪂</div><h4>Real operational daring</h4><p>Gran Sasso was a genuine feat — recounted, not glorified.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>Acquitted, not exonerated</h4><p>Cleared at Dachau on a narrow point of the laws of war.</p></div>
  <div class="ov-card"><div class="i">🌫️</div><h4>Myth over record</h4><p>ODESSA and Mossad tales are flagged as disputed, not fact.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Vienna &amp; the SS</b><small> 1908–1941</small><p>Birth, engineering, the duelling scar, and the choice of Nazism.</p></div>
  <div><b>2 · The Commando Turn</b><small> 1941–1943</small><p>The Eastern Front, a wound, and the Friedenthal command.</p></div>
  <div><b>3 · Gran Sasso</b><small> 1943</small><p>The Mussolini raid and sudden propaganda fame.</p></div>
  <div><b>4 · Holding the Reich</b><small> 1944–1945</small><p>Kidnap in Hungary and false flags in the Bulge.</p></div>
  <div><b>5 · Defeat &amp; Trial</b><small> 1945–1948</small><p>Surrender, the Dachau acquittal, and escape.</p></div>
  <div><b>6 · Exile &amp; Legend</b><small> 1950–1975</small><p>Madrid, arms dealing, disputed spy tales, and death.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Where legend outruns documented fact — the Eisenhower plot, ODESSA, the Mossad story — the guide <b>flags it as disputed</b>. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Benito Mussolini', 'role': 'rescued dictator', 'color': '#78350f',
     'bio': 'Italy’s fascist dictator, deposed and imprisoned in 1943, then freed in the Gran Sasso raid and installed as head of a German puppet state in northern Italy.',
     'rel': 'The prize of Skorzeny’s most famous operation.'},
    {'name': 'Adolf Hitler', 'role': 'Nazi leader', 'color': '#b91c1c',
     'bio': 'Dictator of Nazi Germany, who personally ordered the Mussolini rescue and used Skorzeny as a favoured troubleshooter for his most delicate special missions.',
     'rel': 'The leader whose criminal regime Skorzeny served throughout the war.'},
    {'name': 'Miklós Horthy', 'role': 'Hungarian regent', 'color': '#3730a3',
     'bio': 'Regent of Hungary who sought a separate peace with the USSR in 1944; his son was kidnapped and he himself forced out by Skorzeny’s Operation Panzerfaust.',
     'rel': 'The ally coerced back into the war, clearing the way for the Arrow Cross.'},
    {'name': 'Forest Yeo-Thomas', 'role': 'SOE witness', 'color': '#166534',
     'bio': 'A decorated British SOE officer (“the White Rabbit”) who testified for the defence at Skorzeny’s 1947 Dachau trial, saying the Allies used similar ruses of war.',
     'rel': 'The former enemy whose testimony helped secure Skorzeny’s acquittal.'},
    {'name': 'Francisco Franco', 'role': 'Spanish dictator', 'color': '#57534e',
     'bio': 'Spain’s authoritarian ruler, whose regime sheltered many former Nazis and gave Skorzeny a comfortable base in Madrid for his post-war business and intrigues.',
     'rel': 'The dictator who hosted Skorzeny’s long post-war exile.'},
]

KEY_EVENTS = [
    ('1908', 'Born in Vienna', 'Into an Austro-Hungarian engineering family.'),
    ('1932', 'Joins the Austrian Nazis', 'Later the SA; a Nazi early and by choice.'),
    ('1943', 'Leads SS commandos', 'Given the Friedenthal special-forces unit.'),
    ('1943', 'Gran Sasso raid', 'Glider rescue of Mussolini, 12 September.'),
    ('1944', 'Operation Panzerfaust', 'Kidnap and coup keep Hungary in the war.'),
    ('1944', 'Operation Greif', 'False-flag raid in the Battle of the Bulge.'),
    ('1945', 'Surrenders to the US', 'Held as a most-wanted prisoner.'),
    ('1947', 'Dachau acquittal', 'Cleared on the uniform charge; Yeo-Thomas testifies.'),
    ('1948', 'Escapes internment', 'Vanishes into the Nazi underground.'),
    ('1975', 'Dies in Madrid', 'Unrepentant, aged 67.'),
]

MASTER = [
    {'year': '1908', 'age': 'born', 'phase': 'Vienna & the SS', 'title': 'Born in Vienna', 'desc': 'An Austrian engineering family.'},
    {'year': '1932', 'age': 'age 24', 'phase': 'Vienna & the SS', 'title': 'Joins the Nazis', 'desc': 'Party then SA; SS by 1939–41.'},
    {'year': '1942', 'age': 'age 33', 'phase': 'Commando Turn', 'title': 'Wounded in the East', 'desc': 'Leaves the front line.'},
    {'year': '1943', 'age': 'age 35', 'phase': 'Gran Sasso', 'title': 'Rescues Mussolini', 'desc': 'The Gran Sasso raid; fame.'},
    {'year': '1944', 'age': 'age 36', 'phase': 'Holding the Reich', 'title': 'Hungary & the Bulge', 'desc': 'Panzerfaust and Greif.'},
    {'year': '1947', 'age': 'age 38', 'phase': 'Defeat & Trial', 'title': 'Acquitted at Dachau', 'desc': 'Cleared on the uniform charge.'},
    {'year': '1948', 'age': 'age 40', 'phase': 'Defeat & Trial', 'title': 'Escapes internment', 'desc': 'Into the Nazi underground.'},
    {'year': '1975', 'age': 'age 67', 'phase': 'Exile & Legend', 'title': 'Dies in Madrid', 'desc': 'Unrepentant in exile.'},
]

SOURCES = [
    ('Wikipedia — Otto Skorzeny', 'https://en.wikipedia.org/wiki/Otto_Skorzeny'),
    ('Wikipedia — Gran Sasso raid', 'https://en.wikipedia.org/wiki/Gran_Sasso_raid'),
    ('Wikipedia — Operation Greif', 'https://en.wikipedia.org/wiki/Operation_Greif'),
    ('Wikipedia — Operation Panzerfaust', 'https://en.wikipedia.org/wiki/Operation_Panzerfaust'),
    ('Britannica — Otto Skorzeny', 'https://www.britannica.com/biography/Otto-Skorzeny'),
    ('Imperial War Museums — The Rescue of Mussolini', 'https://www.iwm.org.uk/history/the-rescue-of-mussolini'),
    ('Wikipedia — Operation Damocles (disputed Mossad claims)', 'https://en.wikipedia.org/wiki/Operation_Damocles'),
]

def build_meta():
    return {
        'pid': 'gm-skorzeny.html', 'kind': 'man', 'emoji': '🪂', 'accent': AC,
        'name': 'Otto Skorzeny', 'years': '1908–1975', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Austrian-born Waffen-SS commando officer of Nazi Germany — famed for the daring Gran Sasso raid that freed Mussolini and dubbed by the Allied press “the most dangerous man in Europe” — whose real operational audacity served a criminal regime and later dissolved into arms dealing and disputed intelligence legends.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'origins', 'label': '1 · Vienna & the SS', 'type': 'timeline',
             'intro': 'A Viennese engineer with a duelling scar who embraced Nazism early and by choice, joining the party in 1932 and, by war, the Waffen-SS.', 'events': PHASE_ORIGINS},
            {'id': 'commando', 'label': '2 · The Commando Turn', 'type': 'timeline',
             'intro': 'Wounded on the Eastern Front amid a war of annihilation, he is unexpectedly chosen in 1943 to build and lead an SS special-operations unit.', 'events': PHASE_COMMANDO},
            {'id': 'gransasso', 'label': '3 · Gran Sasso', 'type': 'timeline',
             'intro': 'The glider-borne rescue of Mussolini turns an obscure captain into a Nazi propaganda celebrity — and the Allied press’s “most dangerous man in Europe.”', 'events': PHASE_GRANSASSO},
            {'id': 'war', 'label': '4 · Holding the Reich', 'type': 'timeline',
             'intro': 'He keeps Hungary in the war by kidnap and coup, then sows disproportionate panic in the Battle of the Bulge with false-flag Operation Greif.', 'events': PHASE_WAR},
            {'id': 'trial', 'label': '5 · Defeat & Trial', 'type': 'timeline',
             'intro': 'Surrendering in 1945, he is acquitted at a 1947 Dachau war-crimes trial on a narrow legal point — then escapes internment in 1948 into the Nazi underground.', 'events': PHASE_TRIAL},
            {'id': 'exile', 'label': '6 · Exile & Legend', 'type': 'timeline',
             'intro': 'In Franco’s Madrid he lives an unrepentant exile as an arms dealer and fixer, trailed by disputed intelligence legends, until his death in 1975.', 'events': PHASE_EXILE,
             'sources': SOURCES, 'srcnote': 'Encyclopaedic and museum sources plus standard histories; several post-war episodes (the Eisenhower “plot,” the ODESSA network, the alleged Mossad recruitment) rest on contested evidence and are flagged in the text as disputed.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
