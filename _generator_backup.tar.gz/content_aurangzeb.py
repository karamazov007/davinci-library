# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Aurangzeb (Alamgir).
The last of the great Mughals — who pushed the empire to its widest and its breaking point at once."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#3f6212'  # austere Mughal olive-green

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE ORTHODOX PRINCE
PHASE_RISE = [
    E('origins', '1618–1636', 'The austere prince — a Mughal apart', ['RISE', 'FAITH'],
      'Born the third son of Shah Jahan and Mumtaz Mahal, the young Muhi al-Din grows into a grave, disciplined and devout prince — sparing in habit, orthodox in faith, and temperamentally the opposite of the glittering, syncretic court around him.',
      svg_row('A grave prince in a glittering court', [
          {'n': 1, 'label': 'Born a Mughal prince, 1618', 'sub': 'third son of Shah Jahan and Mumtaz Mahal', 'color': '#3f6212'},
          {'n': 2, 'label': 'Grave, disciplined, devout', 'sub': 'austere habits; strict Sunni orthodoxy', 'color': '#a16207'},
          {'n': 3, 'label': 'A temperament apart', 'sub': 'unlike the opulent, eclectic court', 'color': '#166534'},
      ], edge_labels=['becomes', 'and so'], takeaway='From the start he was the plainest of the Mughals — piety and discipline where his house prized splendour.', accent=AC),
      bg='<b>Muhi al-Din Muhammad</b>, later Aurangzeb, was born in 1618, the third surviving son of the emperor <b>Shah Jahan</b> and <b>Mumtaz Mahal</b>, for whom the Taj Mahal was raised.',
      people='his father <b>Shah Jahan</b>; his mother <b>Mumtaz Mahal</b>; his elder brother and rival-to-be <b>Dara Shikoh</b>.',
      what='He grew into a <b>grave, austere and strictly orthodox</b> prince — sparing in food, dress and pleasure, devoted to Sunni piety and law — starkly unlike the luxurious, culturally eclectic Mughal court of his father.',
      crux='His <b>character was formed young</b>: self-denial, discipline and religious conviction, in deliberate contrast to Mughal opulence.',
      conseq='This temperament shaped both his later industrious rule and his reputation for austere, uncompromising orthodoxy.',
      matters='Character set early foreshadows a reign — the austere, devout boy became the austere, devout emperor.'),

    E('deccan', '1636–1657', 'The proven soldier-administrator', ['RISE', 'BATTLE'],
      'Aurangzeb earns his spurs as a provincial governor and general — twice viceroy of the Deccan, campaigning in Central Asia and against Kandahar — showing himself an able, tireless administrator and a competent, cautious commander who understands the machinery of empire.',
      svg_stack('Earning the empire the hard way', [
          {'n': 1, 'label': 'Viceroy of the Deccan', 'sub': 'governs the empire’s turbulent south', 'color': '#3f6212'},
          {'n': 2, 'label': 'Campaigns in the field', 'sub': 'Balkh, Badakhshan and Kandahar', 'color': '#a16207'},
          {'n': 3, 'label': 'A capable administrator', 'sub': 'tireless, methodical, hands-on', 'color': '#166534'},
      ], takeaway='He learned power from the ground up — as governor and general — building a reputation for competence and stamina.', accent=AC),
      bg='From the 1630s Shah Jahan gave his sons provinces and armies. Aurangzeb served as <b>viceroy of the Deccan</b> and campaigned on the empire’s frontiers.',
      people='his father <b>Shah Jahan</b>, who assigned the commands; the <b>Deccan sultanates</b> he pressed; rival brothers watching the same prizes.',
      what='He proved himself an <b>able governor and general</b> — twice viceroy of the <b>Deccan</b>, and campaigning in <b>Balkh, Badakhshan and against Kandahar</b> — mastering administration and cautious, methodical warfare.',
      crux='He built a base of <b>real competence and experience</b> — an administrator’s grasp of the empire’s machinery and finances.',
      conseq='This record of hard, practical service gave him the standing and the seasoned troops to make his bid for the throne.',
      matters='Long apprenticeship in provinces and campaigns forged the skills — and the following — that a throne-seeker needs.'),

    E('brothers', '1650s', 'Two brothers, two visions of the empire', ['RISE', 'FAITH'],
      'The coming clash is also a clash of ideas: the orthodox, disciplined Aurangzeb against his eldest brother Dara Shikoh — Shah Jahan’s favourite, a liberal, mystical seeker who blends Islam with Hindu thought — two rival visions of what a Mughal empire should be.',
      svg_compare('A contest of temperaments and creeds',
          {'head': 'Dara Shikoh — the seeker', 'color': '#a16207',
           'items': ['Shah Jahan’s favourite and chosen heir', 'liberal, mystical, syncretic mind', 'translated the Upanishads; sought Hindu–Muslim unity', 'a scholar more than a soldier']},
          {'head': 'Aurangzeb — the orthodox', 'color': '#3f6212',
           'items': ['third son, out of favour at court', 'austere, disciplined, strictly Sunni', 'a seasoned general and administrator', 'patient, ruthless, politically shrewd']},
          verdict='Not merely a family quarrel but a fork in the road for the empire’s character.',
          takeaway='The war of succession pitted two visions of Mughal India — Dara’s syncretism against Aurangzeb’s orthodoxy.', accent=AC),
      bg='Shah Jahan favoured his eldest son, the mystic prince <b>Dara Shikoh</b>, keeping him at court as heir, while Aurangzeb governed distant provinces.',
      people='<b>Dara Shikoh</b>, the liberal favourite; <b>Aurangzeb</b>, the orthodox soldier; <b>Shah Jahan</b>, the ageing father dividing them.',
      what='The brothers embodied <b>opposed visions</b>: Dara, a scholar who translated Hindu scripture and sought a fusion of faiths; Aurangzeb, an austere general committed to Islamic orthodoxy and law.',
      crux='Their rivalry was <b>ideological as well as personal</b> — the succession would decide whether the empire leaned toward syncretism or orthodoxy.',
      conseq='When their father fell ill in 1657, this simmering rivalry erupted into open civil war.',
      matters='Succession struggles can turn on ideas as much as ambition — here, the soul of an empire was at stake.'),
]

# ==================================================================  PHASE 2 — THE WAR OF SUCCESSION
PHASE_THRONE = [
    E('civilwar', '1657–1658', 'Civil war — the throne up for grabs', ['BATTLE', 'TURNING POINT'],
      'When Shah Jahan falls gravely ill in 1657, rumours of his death set his four sons at war for the throne — and Aurangzeb, allying briefly with a brother, marches north and shatters the imperial armies at Dharmat and Samugarh in 1658, breaking Dara Shikoh’s power.',
      svg_stack('The empire decided by the sword', [
          {'n': 1, 'label': 'Shah Jahan falls ill, 1657', 'sub': 'rumours of death spark a four-way war', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Dharmat & Samugarh, 1658', 'sub': 'Aurangzeb crushes the imperial armies', 'color': '#3f6212'},
          {'n': 3, 'label': 'Dara’s power broken', 'sub': 'the favourite heir routed and in flight', 'color': '#78350f'},
      ], takeaway='He won the throne on the battlefield — outgeneralling the favourite heir at the decisive encounters of 1658.', accent=AC),
      bg='In <b>1657 Shah Jahan fell seriously ill</b>. Believing him dying, his four sons — Dara, Shuja, Aurangzeb and Murad — moved to seize the throne.',
      people='<b>Dara Shikoh</b>, defending his claim; <b>Murad Baksh</b>, Aurangzeb’s temporary ally; <b>Shah Shuja</b>, a third claimant; the imperial armies.',
      what='Aurangzeb, allied for the moment with his brother Murad, marched north and won the <b>Battle of Dharmat (April 1658)</b> and the decisive <b>Battle of Samugarh (May 1658)</b>, routing Dara Shikoh’s forces.',
      crux='He proved the <b>superior general and tactician</b>, using discipline and artillery to break the numerically strong but poorly led imperial army.',
      conseq='With Dara defeated and fleeing, Aurangzeb turned to seize the capital, the treasury and his father.',
      matters='A disputed throne is often settled by force — Aurangzeb won his crown as a soldier, not an heir.'),

    E('shahjahan', '1658', 'Imprisoning a father, seizing a crown', ['POLITICS', 'TRAGEDY'],
      'Victorious, Aurangzeb takes Agra and confines his own father — the recovered Shah Jahan — as a prisoner in the fort, where the deposed emperor will live out his last years gazing at the Taj Mahal; Aurangzeb crowns himself emperor under the title Alamgir, “World-Seizer.”',
      svg_row('The son who caged his father', [
          {'n': 1, 'label': 'Agra and the treasury taken', 'sub': 'Aurangzeb seizes the imperial centre', 'color': '#3f6212'},
          {'n': 2, 'label': 'Shah Jahan imprisoned', 'sub': 'confined in Agra Fort until his death, 1666', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Crowned “Alamgir”', 'sub': 'proclaimed emperor, the World-Seizer', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='He took the throne by caging the father who had built the Taj — a ruthlessness that shadows his legend.', accent=AC),
      bg='Shah Jahan had in fact recovered, but power had already passed to the sword. Aurangzeb was not willing to surrender it.',
      people='<b>Shah Jahan</b>, the deposed emperor; <b>Aurangzeb</b>, now master of Agra; the courtiers and garrison who submitted.',
      what='Aurangzeb seized <b>Agra and the treasury</b> and confined his father as a prisoner in <b>Agra Fort</b>, where Shah Jahan lived under guard until his death in 1666. Aurangzeb had himself crowned emperor as <b>Alamgir</b>, “World-Seizer.”',
      crux='He chose <b>power over filial duty</b> — deposing and jailing his own father rather than risk his restoration.',
      conseq='Only his brothers now stood between him and unchallenged rule; he moved to destroy them.',
      matters='The ruthlessness of dynastic power — even a father becomes an obstacle to be removed.'),

    E('dara-death', '1659', 'Killing the brothers — the throne secured in blood', ['BATTLE', 'DEATH', 'TURNING POINT'],
      'Aurangzeb hunts down his surviving brothers: Dara Shikoh is captured, paraded in rags through Delhi, condemned as an apostate and executed; Murad is imprisoned and later killed, and Shah Shuja driven to his death in exile — clearing every rival from the path.',
      svg_stack('Every rival removed', [
          {'n': 1, 'label': 'Dara captured and killed, 1659', 'sub': 'condemned as an apostate, executed at Delhi', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Murad imprisoned and executed', 'sub': 'the ally of 1658 eliminated, 1661', 'color': '#78350f'},
          {'n': 3, 'label': 'Shah Shuja driven to death', 'sub': 'defeated and forced into fatal exile', 'color': '#3f6212'},
      ], takeaway='He secured the throne by destroying his own brothers — the standard, savage arithmetic of Mughal succession.', accent=AC),
      bg='After Samugarh, Dara fled westward while the other brothers still lived. Aurangzeb resolved to leave no rival claimant alive.',
      people='<b>Dara Shikoh</b>, the captured heir; <b>Murad Baksh</b>, the betrayed ally; <b>Shah Shuja</b>, the fugitive brother.',
      what='<b>Dara Shikoh was captured, humiliated through Delhi, tried on a charge of apostasy and executed (1659)</b>. <b>Murad</b> was imprisoned and later put to death (1661), and <b>Shah Shuja</b> was defeated and driven into exile, where he perished.',
      crux='He <b>eliminated every claimant</b> — using an apostasy charge to cloak the killing of Dara in the language of orthodoxy.',
      conseq='By 1659–61 Aurangzeb ruled without a rival, master of the wealthiest empire on earth.',
      matters='The brutal logic of a throne without clear succession law — brothers become mortal enemies, and the winner rules over their graves.'),
]

# ==================================================================  PHASE 3 — ALAMGIR, THE WORLD-SEIZER
PHASE_ZENITH = [
    E('austere', '1659–1707', 'The emperor who sewed caps and copied the Quran', ['FAITH', 'REFORM'],
      'On the throne Aurangzeb rules as no Mughal before him — plain in dress and diet, refusing to live off the treasury, earning his private money by sewing prayer-caps and copying the Quran by hand, working tirelessly at the business of the state as a pious, self-denying autocrat.',
      svg_row('Power exercised with monkish discipline', [
          {'n': 1, 'label': 'Austere personal style', 'sub': 'plain food, plain dress, no luxury', 'color': '#3f6212'},
          {'n': 2, 'label': 'Earns his own money', 'sub': 'sews caps, copies the Quran by hand', 'color': '#a16207'},
          {'n': 3, 'label': 'Tireless at the desk', 'sub': 'an industrious, hands-on autocrat', 'color': '#166534'},
      ], edge_labels=['even', 'while'], takeaway='He wielded the wealthiest throne on earth like an ascetic clerk — pious, frugal and relentlessly industrious.', accent=AC),
      bg='Where his forebears prized splendour, Aurangzeb governed as a self-denying, devout ruler, distrustful of luxury and display.',
      people='the courtiers and officials he drove hard; the ulama whose favour he cultivated; the vast bureaucracy he oversaw personally.',
      what='He lived with famed <b>austerity</b> — refusing to fund his private wants from the treasury, reportedly earning money by <b>sewing prayer-caps and copying the Quran</b>, and working exhaustively at administration and correspondence.',
      crux='He fused <b>absolute power with personal self-denial</b> — an autocrat who saw himself as a servant of God and duty, not pleasure.',
      conseq='This industrious, orthodox style set the tone of his long reign and endeared him to the pious even as it alienated others.',
      matters='A ruler’s personal discipline can be real and admirable — and still coexist with a harsh, narrowing statecraft.'),

    E('sharia', '1660s–1670s', 'Ruling by the law of God', ['FAITH', 'REFORM'],
      'Aurangzeb sets out to govern by Islamic law as he understands it — commissioning the great legal digest the Fatawa Alamgiri, appointing censors of morals, curbing court music and un-Islamic customs, and steering the empire away from the eclectic, cosmopolitan style of his great-grandfather Akbar.',
      svg_stack('An empire reordered around orthodoxy', [
          {'n': 1, 'label': 'The Fatawa Alamgiri', 'sub': 'a vast digest of Hanafi law compiled', 'color': '#3f6212'},
          {'n': 2, 'label': 'Censors of public morals', 'sub': 'muhtasibs enforce orthodox conduct', 'color': '#a16207'},
          {'n': 3, 'label': 'Turning from Akbar’s path', 'sub': 'away from syncretism toward sharia', 'color': '#78350f'},
      ], takeaway='He tried to remake the Mughal state on Islamic law — reversing the pluralist experiment of Akbar.', accent=AC),
      bg='Akbar had built a cosmopolitan, tolerant style of rule. Aurangzeb, by conviction, sought to align the empire with orthodox Islamic law.',
      people='the <b>ulama</b> and jurists who compiled his law-book; the <b>muhtasibs</b> (censors) he empowered; the memory of <b>Akbar</b>, whose path he rejected.',
      what='He commissioned the <b>Fatawa Alamgiri</b>, a monumental compilation of Hanafi jurisprudence, appointed <b>censors of morals</b>, curbed court music and customs he deemed un-Islamic, and steered policy toward orthodoxy.',
      crux='He aimed to make <b>sharia the framework of the state</b> — a deliberate reversal of the syncretic Mughal tradition.',
      conseq='His legal and moral programme deepened the empire’s Islamic character but strained its pluralist foundations.',
      matters='How a state defines itself — pluralist or confessional — shapes the loyalty of the peoples it rules.'),

    E('expansion', '1685–1690', 'The empire at its widest', ['BATTLE', 'TRIUMPH'],
      'Aurangzeb pushes the Mughal Empire to its greatest territorial extent, annexing the rich Deccan sultanates of Bijapur (1686) and Golconda (1687) and carrying Mughal authority deep into southern India — ruling, on paper, almost the whole subcontinent and its immense wealth.',
      svg_row('The largest Mughal Empire ever', [
          {'n': 1, 'label': 'Bijapur annexed, 1686', 'sub': 'the Deccan sultanate absorbed', 'color': '#3f6212'},
          {'n': 2, 'label': 'Golconda annexed, 1687', 'sub': 'its diamond-rich lands taken', 'color': '#a16207'},
          {'n': 3, 'label': 'Greatest extent ever', 'sub': 'Mughal rule from Kabul to the deep south', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He stretched the empire to its widest limits — master, on the map, of almost all India.', accent=AC),
      bg='The independent Muslim <b>Deccan sultanates</b> and the rising Marathas drew Aurangzeb south for the decisive campaigns of his reign.',
      people='the sultans of <b>Bijapur</b> and <b>Golconda</b>; the Maratha powers beyond; the great Mughal army in the field.',
      what='Aurangzeb conquered and annexed <b>Bijapur (1686)</b> and <b>Golconda (1687)</b>, extending Mughal rule across the Deccan and giving the empire its <b>greatest territorial extent</b>, over most of the subcontinent.',
      crux='He achieved on the map what no Mughal had — but did so by plunging permanently into the costly, endless south.',
      conseq='The conquest of the sultanates removed the buffers that had contained the Marathas, exposing the empire to unending guerrilla war.',
      matters='Maximum expansion can mark the peak and the turning point at once — the widest empire was also the most overstretched.'),
]

# ==================================================================  PHASE 4 — FAITH, TAX AND THE DEBATE
PHASE_FAITH = [
    E('jizya', '1679', 'The jizya returns — taxing the unbeliever', ['FAITH', 'POLITICS', 'TRAGEDY'],
      'In 1679 Aurangzeb reimposes the jizya, the tax on non-Muslims that Akbar had abolished a century before — an act critics read as naked bigotry and some defenders explain as fiscal or ideological calculation, but which unmistakably signalled that the empire’s Hindu majority were now second-class subjects.',
      svg_stack('A tax that redrew who belonged', [
          {'n': 1, 'label': 'Jizya abolished by Akbar', 'sub': 'a century of exemption for non-Muslims', 'color': '#a16207'},
          {'n': 2, 'label': 'Reimposed in 1679', 'sub': 'the tax on unbelievers restored', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A signal of exclusion', 'sub': 'Hindus marked as subordinate subjects', 'color': '#78350f'},
      ], takeaway='Restoring the jizya was his most divisive act — read by critics as bigotry, by defenders as fiscal or ideological policy.', accent=AC),
      bg='Akbar had abolished the <b>jizya</b> — a poll tax on non-Muslims — as part of his conciliatory rule. It had lapsed for roughly a century.',
      people='the empire’s <b>Hindu majority</b>, now taxed; the <b>ulama</b>, who welcomed it; later historians who fiercely debate his motives.',
      what='In <b>1679 Aurangzeb reimposed the jizya</b> on non-Muslims. Critics see plain <b>religious discrimination</b>; some scholars point to <b>fiscal pressure from endless war</b> or to placating the orthodox — but its effect was to mark Hindus as subordinate.',
      crux='Whatever the motive, it <b>reversed Akbar’s inclusive settlement</b> and made confessional status a matter of taxation.',
      conseq='It stoked resentment among Hindu subjects and allies and became the central charge in his reputation for intolerance.',
      matters='A single fiscal measure can carry a vast symbolic weight — signalling who counts as a full member of the realm.'),

    E('temples', '1660s–1670s', 'Temples destroyed — the hardest charge', ['FAITH', 'TRAGEDY'],
      'Aurangzeb orders the destruction of prominent Hindu temples, including the great shrines at Varanasi and Mathura — the acts most cited by his critics; yet the historical record is contested, with revisionist scholars stressing that he also issued grants protecting other temples, and that demolitions were often tied to politics and rebellion.',
      svg_compare('The temple question, weighed honestly',
          {'head': 'The case against', 'color': '#b91c1c',
           'items': ['razed famous temples at Kashi (Varanasi) and Mathura', 'built mosques on cleared sites', 'ordered demolitions in rebellious regions', 'read as deliberate humiliation of Hindus']},
          {'head': 'The complicating record', 'color': '#3f6212',
           'items': ['also issued firmans protecting temples and maths', 'employed more Hindus in his service than predecessors', 'historians debate scale (Eaton counts far fewer than legend)', 'demolitions often tied to politics and revolt']},
          verdict='Real temple destruction, but embedded in politics and mixed with acts of protection — neither wholly saint nor pure zealot.',
          takeaway='The honest verdict resists caricature: documented destruction, yet more tangled and political than the legend of blanket iconoclasm.', accent=AC),
      bg='Temple destruction is the most emotive charge against Aurangzeb, and the one where popular memory and archival evidence most sharply diverge.',
      people='the priests and communities of <b>Varanasi</b> and <b>Mathura</b>; the Hindu officials still in his service; modern historians on both sides.',
      what='Aurangzeb <b>ordered the destruction of prominent temples</b>, notably at Varanasi and Mathura, sometimes replacing them with mosques. Yet he also <b>issued grants protecting other temples</b>, and historians such as <b>Richard Eaton</b> argue the demolitions were fewer, and more politically targeted, than tradition holds.',
      crux='The truth is <b>neither the total iconoclast of legend nor a tolerant pluralist</b> — a ruler who destroyed temples selectively, often as political punishment.',
      conseq='These acts, magnified in memory, made Aurangzeb the enduring symbol of religious intolerance in the popular imagination.',
      matters='Even-handed history holds two facts at once — documented destruction and documented protection — rather than flattening a figure into a symbol.'),

    E('teghbahadur', '1675', 'The execution of Guru Tegh Bahadur', ['FAITH', 'DEATH', 'TRAGEDY'],
      'Aurangzeb has the ninth Sikh Guru, Tegh Bahadur, arrested and executed at Delhi in 1675 — an act Sikh tradition remembers as martyrdom in defence of religious freedom, and one that hardened the Sikhs into militant opposition to Mughal rule for generations.',
      svg_stack('A martyrdom that forged an enemy', [
          {'n': 1, 'label': 'Guru Tegh Bahadur resists', 'sub': 'the ninth Sikh Guru defies conversion pressure', 'color': '#a16207'},
          {'n': 2, 'label': 'Executed at Delhi, 1675', 'sub': 'arrested and put to death on Aurangzeb’s order', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The Sikhs turn militant', 'sub': 'his son Gobind Singh founds the Khalsa', 'color': '#3f6212'},
      ], takeaway='Executing the Guru created a martyr and a militant foe — militarising the Sikhs against the empire for good.', accent=AC),
      bg='The <b>Sikh</b> community had grown in the Punjab. Tradition holds that Guru Tegh Bahadur resisted Aurangzeb’s pressure and defended persecuted Hindus.',
      people='<b>Guru Tegh Bahadur</b>, the ninth Guru; his son <b>Guru Gobind Singh</b>, who would answer with the Khalsa; the Sikh community.',
      what='In <b>1675 Aurangzeb ordered the arrest and execution of Guru Tegh Bahadur</b> at Delhi. Sikh tradition venerates him as a <b>martyr for religious freedom</b>; the act drove the Sikhs into lasting armed opposition to Mughal rule.',
      crux='He met religious dissent with <b>execution</b> — and in doing so created a martyr and a permanent, militarised enemy.',
      conseq='Guru Gobind Singh founded the militant <b>Khalsa</b> in 1699; Sikh–Mughal conflict became a defining strain on the empire.',
      matters='Persecution can forge the very resistance it seeks to crush — martyrdom hardens a community rather than breaking it.'),
]

# ==================================================================  PHASE 5 — THE DECCAN QUAGMIRE AND DECLINE
PHASE_END = [
    E('marathas', '1680–1707', 'The Deccan quagmire — the war that never ends', ['BATTLE', 'DEFEAT'],
      'Aurangzeb spends the last twenty-five years of his life bogged down in the Deccan, chasing the elusive Marathas — heirs of Shivaji — in an endless guerrilla war he can never win; he captures and executes Shivaji’s son Sambhaji in 1689, yet the Marathas only multiply, bleeding the empire white.',
      svg_stack('A quarter-century that could not be won', [
          {'n': 1, 'label': 'Shivaji’s Marathas rise', 'sub': 'guerrilla war from the Deccan hills', 'color': '#a16207'},
          {'n': 2, 'label': 'Sambhaji executed, 1689', 'sub': 'Shivaji’s son captured and killed', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The war spreads regardless', 'sub': 'Maratha resistance only multiplies', 'color': '#78350f'},
      ], takeaway='He sank his last decades into an unwinnable guerrilla war — every victory left the Marathas stronger.', accent=AC),
      bg='<b>Shivaji</b> had built a Maratha power in the Deccan hills, mastering guerrilla and mountain warfare against the Mughals before his death in 1680.',
      people='<b>Shivaji</b>, founder of the Maratha state; his son <b>Sambhaji</b>, captured and executed; the swarming Maratha bands Aurangzeb could never pin down.',
      what='From 1680 Aurangzeb committed himself personally to the <b>Deccan</b>, waging endless war on the <b>Marathas</b>. He captured and executed <b>Sambhaji (1689)</b>, but the decentralised Maratha resistance only <b>spread and intensified</b>, defying conquest.',
      crux='He faced a war with <b>no decisive battle to win</b> — a mobile, popular resistance that grew stronger the harder he struck.',
      conseq='The Deccan campaigns drained the treasury and armies for a generation and never achieved a lasting peace.',
      matters='A great conventional power can be exhausted by a determined guerrilla enemy — territory taken is not victory won.'),

    E('overstretch', '1690s–1707', 'Overreach — the empire strained to breaking', ['POLITICS', 'DEFEAT', 'TRAGEDY'],
      'The endless Deccan wars overextend and impoverish the empire — draining the treasury, exhausting the army, neglecting the north, and corroding the administration; the vast realm Aurangzeb built to its widest extent is by his last years financially and militarily hollowed out.',
      svg_row('The widest empire, hollowed from within', [
          {'n': 1, 'label': 'Endless war drains the treasury', 'sub': 'decades of Deccan campaigning bankrupt the state', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Army and revenue exhausted', 'sub': 'the north neglected; administration decays', 'color': '#78350f'},
          {'n': 3, 'label': 'A hollow colossus', 'sub': 'the largest empire, financially spent', 'color': '#3f6212'},
      ], edge_labels=['so', 'leaving'], takeaway='Overreach ate the empire from inside — the widest Mughal realm was also its most exhausted and brittle.', accent=AC),
      bg='By stretching the empire across the whole subcontinent and fighting without end in the south, Aurangzeb strained its finances and structures past their limits.',
      people='the overtaxed <b>peasantry and provinces</b>; the unpaid, weary <b>army</b>; the neglected north where rebellions stirred.',
      what='The <b>ceaseless Deccan wars</b> drained the treasury, wore out the army and diverted the emperor from the empire’s heartland — leaving the administration corroded and the finances <b>ruinously overstretched</b>.',
      crux='He had expanded <b>beyond what the empire could sustain</b> — turning territorial triumph into a fatal financial and military burden.',
      conseq='The exhaustion he bequeathed set the stage for the rapid Mughal decline that followed his death.',
      matters='Overextension is the classic trap of empires — conquering more than one can hold or pay for hastens collapse.'),

    E('death', '1707', 'Death in the Deccan — and the end of an age', ['DEATH', 'DEFEAT'],
      'In 1707, aged 88, Aurangzeb dies in his camp in the Deccan, worn out and full of foreboding, asking to be buried in a plain, unmarked grave — and with him the effective greatness of the Mughal Empire dies too, as his heirs fall to civil war and the vast realm begins its swift unravelling.',
      svg_stack('The last great Mughal passes', [
          {'n': 1, 'label': 'Dies in camp, 1707', 'sub': 'aged 88, still at war in the Deccan', 'color': '#3f6212'},
          {'n': 2, 'label': 'A plain, humble grave', 'sub': 'buried austerely, by his own wish', 'color': '#a16207'},
          {'n': 3, 'label': 'The empire unravels', 'sub': 'succession wars and rapid decline follow', 'color': '#78350f'},
      ], takeaway='He died as he ruled — austere and at war — and the empire he stretched to its widest swiftly began to fall apart.', accent=AC),
      bg='After nearly fifty years on the throne and decades in the field, the aged emperor’s strength and his empire’s were spent together.',
      people='his warring sons and heirs; the Marathas, Sikhs and others he never subdued; the empire he left overstretched and exhausted.',
      what='Aurangzeb <b>died in 1707, aged 88</b>, still campaigning in the Deccan, and was buried, at his own wish, in a <b>simple, unadorned grave</b>. His death triggered a war of succession and began the <b>rapid decline of the Mughal Empire</b>.',
      crux='He was the <b>last Mughal to rule the whole empire effectively</b> — after him it fractured beyond recovery.',
      conseq='Within decades the empire lost real power to Marathas, regional successors and, ultimately, the rising British.',
      matters='The reign that took the empire to its zenith also exhausted it — Aurangzeb is the hinge between Mughal greatness and Mughal collapse.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Aurangzeb, styled <b>Alamgir</b> — “World-Seizer” — was the last of the great Mughal emperors, and the most fiercely contested figure in Indian history. He seized the throne in a brutal war of succession, jailing his father and killing his brothers; ruled for nearly fifty years with monkish austerity and tireless industry; pushed the empire to its <b>greatest territorial extent</b>; and reordered the state around Islamic orthodoxy — reimposing the jizya, destroying temples, and executing the Sikh Guru Tegh Bahadur. Yet he sank his last decades into the unwinnable Deccan wars against the Marathas, overstretching and hollowing out the very empire he had built. He is the ultimate study in <b>empire-builder versus zealot, austere power, and the overreach that ruins empires.</b></p>
<div class="ov-quote">“Alamgir” — the World-Seizer.<span>— the imperial title Aurangzeb took at his coronation</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">An austere, orthodox prince proves himself as soldier and governor → he wins the throne in a savage war of succession, jailing his father and killing his brothers → rules as a self-denying, industrious emperor governing by Islamic law → pushes the empire to its widest extent by conquering the Deccan sultanates → reimposes the jizya, destroys temples and executes a Sikh Guru → and sinks his last decades into the endless Deccan war with the Marathas, dying in 1707 with the exhausted empire poised to fall.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🗺️</div><h4>The widest empire</h4><p>Took Mughal India to its greatest territorial extent.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>The great debate</h4><p>Empire-builder or intolerant zealot — India still argues.</p></div>
  <div class="ov-card"><div class="i">🕌</div><h4>Faith and the state</h4><p>Reversed Akbar’s pluralism for orthodox rule.</p></div>
  <div class="ov-card"><div class="i">📉</div><h4>The overreach</h4><p>The endless Deccan wars set up Mughal decline.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Orthodox Prince</b><small> 1618–1657</small><p>An austere prince; a proven soldier; a fateful rivalry.</p></div>
  <div><b>2 · War of Succession</b><small> 1657–1659</small><p>Civil war, a jailed father, murdered brothers.</p></div>
  <div><b>3 · Alamgir</b><small> 1659–1690</small><p>Austere rule, sharia, and the empire at its widest.</p></div>
  <div><b>4 · Faith &amp; the Debate</b><small> 1675–1679</small><p>Jizya, temples, and a martyred Guru.</p></div>
  <div><b>5 · The Deccan &amp; Decline</b><small> 1680–1707</small><p>The unwinnable war, overreach, and death.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Shah Jahan', 'role': 'his father', 'color': '#a16207',
     'bio': 'The emperor who built the Taj Mahal; Aurangzeb deposed and imprisoned him in Agra Fort, where he died in 1666.',
     'rel': 'The father he caged to take the throne.'},
    {'name': 'Dara Shikoh', 'role': 'brother and rival', 'color': '#b91c1c',
     'bio': 'Shah Jahan’s favourite son, a liberal mystic who sought Hindu–Muslim unity; defeated by Aurangzeb and executed for apostasy in 1659.',
     'rel': 'The eldest brother whose vision — and life — he destroyed.'},
    {'name': 'Shivaji', 'role': 'Maratha adversary', 'color': '#166534',
     'bio': 'Founder of the Maratha state, master of guerrilla war, who defied Mughal power in the Deccan until his death in 1680.',
     'rel': 'The rival whose Marathas Aurangzeb could never subdue.'},
    {'name': 'Guru Tegh Bahadur', 'role': 'Sikh martyr', 'color': '#5b21b6',
     'bio': 'The ninth Sikh Guru, executed on Aurangzeb’s order at Delhi in 1675 — remembered as a martyr for religious freedom.',
     'rel': 'The Guru whose execution made the Sikhs his enemies.'},
    {'name': 'Akbar', 'role': 'ancestor and foil', 'color': '#3730a3',
     'bio': 'His great-grandfather, whose tolerant, syncretic rule and abolition of the jizya Aurangzeb pointedly reversed.',
     'rel': 'The pluralist ancestor whose path he rejected.'},
]

KEY_EVENTS = [
    ('1618', 'Aurangzeb born', 'Third son of Shah Jahan and Mumtaz Mahal.'),
    ('1636', 'Viceroy of the Deccan', 'Proves himself as soldier and governor.'),
    ('1658', 'Samugarh; father jailed', 'Defeats Dara; imprisons Shah Jahan; crowned Alamgir.'),
    ('1659', 'Dara Shikoh executed', 'Brothers eliminated; throne secured.'),
    ('1675', 'Guru Tegh Bahadur killed', 'The ninth Sikh Guru executed at Delhi.'),
    ('1679', 'Jizya reimposed', 'The tax on non-Muslims restored.'),
    ('1686–87', 'Bijapur &amp; Golconda annexed', 'The empire at its greatest extent.'),
    ('1689', 'Sambhaji executed', 'Yet the Marathas fight on.'),
    ('1707', 'Death of Aurangzeb', 'Dies in the Deccan; Mughal decline begins.'),
]

MASTER = [
    {'year': '1618', 'age': 'born', 'phase': 'Orthodox Prince', 'title': 'Born a Mughal prince', 'desc': 'Austere and devout from youth.'},
    {'year': '1658', 'age': 'age 39', 'phase': 'War of Succession', 'title': 'Seizes the throne', 'desc': 'Wins Samugarh; jails Shah Jahan.'},
    {'year': '1659', 'age': 'age 40', 'phase': 'War of Succession', 'title': 'Dara executed', 'desc': 'Brothers removed; rule secured.'},
    {'year': '1679', 'age': 'age 60', 'phase': 'Faith & Empire', 'title': 'Jizya reimposed', 'desc': 'Reverses Akbar’s settlement.'},
    {'year': '1687', 'age': 'age 68', 'phase': 'Alamgir', 'title': 'Empire at its widest', 'desc': 'Golconda falls; peak extent.'},
    {'year': '1707', 'age': 'age 88', 'phase': 'Deccan & Decline', 'title': 'Dies in the Deccan', 'desc': 'The empire begins to unravel.'},
]

SOURCES = [
    ('Britannica — Aurangzeb', 'https://www.britannica.com/biography/Aurangzeb'),
    ('World History Encyclopedia — Aurangzeb', 'https://www.worldhistory.org/Aurangzeb/'),
    ('Wikipedia — Aurangzeb', 'https://en.wikipedia.org/wiki/Aurangzeb'),
    ('Britannica — Dara Shikoh', 'https://www.britannica.com/biography/Dara-Shikoh'),
    ('Britannica — Mughal Empire', 'https://www.britannica.com/topic/Mughal-dynasty'),
]

def build_meta():
    return {
        'pid': 'gm-aurangzeb.html', 'kind': 'man', 'emoji': '🗡️', 'accent': AC,
        'name': 'Aurangzeb', 'years': '1618–1707', 'group': 'Indian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The last great Mughal emperor — the austere, orthodox “World-Seizer” who took the empire to its widest extent and its breaking point at once, and who India still argues over: empire-builder or intolerant zealot.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Orthodox Prince', 'type': 'timeline',
             'intro': 'An austere, orthodox prince proves himself as a soldier and administrator in the Deccan — and grows into the ideological opposite of his eldest brother, the mystic heir Dara Shikoh.', 'events': PHASE_RISE},
            {'id': 'throne', 'label': '2 · War of Succession', 'type': 'timeline',
             'intro': 'When Shah Jahan falls ill, Aurangzeb wins the throne by the sword — crushing Dara at Samugarh, imprisoning his own father, and killing every brother who stood in his way.', 'events': PHASE_THRONE},
            {'id': 'zenith', 'label': '3 · Alamgir', 'type': 'timeline',
             'intro': 'He rules with monkish austerity and tireless industry, governs by Islamic law in reversal of Akbar, and conquers the Deccan sultanates to bring the empire to its greatest extent.', 'events': PHASE_ZENITH},
            {'id': 'faith', 'label': '4 · Faith & the Debate', 'type': 'timeline',
             'intro': 'His most contested acts — reimposing the jizya, destroying temples, and executing Guru Tegh Bahadur — are weighed here even-handedly: the case for bigotry, and the complicating record.', 'events': PHASE_FAITH},
            {'id': 'end', 'label': '5 · The Deccan & Decline', 'type': 'timeline',
             'intro': 'He sinks his last decades into the unwinnable war with the Marathas, overstretching and hollowing out the empire he built to its widest — dying in 1707 as Mughal greatness begins to unravel.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources. Aurangzeb is a deeply polarising figure; this guide presents both the traditional charge of intolerance and the revisionist, contextual scholarship (e.g. Eaton, Truschke) side by side.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
