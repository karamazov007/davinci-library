# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Sardar Vallabhbhai Patel.
The Iron Man of India who welded over 500 princely states into one nation."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#9a3412'  # iron rust / terracotta

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING
PHASE_MAKING = [
    E('origins', '1875–1897', 'A farmer’s son from Gujarat', ['RISE', 'ORIGINS'],
      'Born into a Patidar farming family in Nadiad, Gujarat, Vallabhbhai grows up in modest circumstances, works the land, and educates himself late — passing his law examinations by borrowing books, revealing early the stubborn, self-reliant will that will define him.',
      svg_row('From the fields to the bar', [
          {'n': 1, 'label': 'Patidar farming family, 1875', 'sub': 'born in Nadiad, Gujarat, of modest means', 'color': '#9a3412'},
          {'n': 2, 'label': 'Self-taught and determined', 'sub': 'passes his law exams by private study', 'color': '#a16207'},
          {'n': 3, 'label': 'A district pleader', 'sub': 'builds a reputation in the courts of Gujarat', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='Humble beginnings and iron self-discipline forged the will that would one day bind a nation.', accent=AC),
      bg='<b>Vallabhbhai Patel</b> was born in 1875 into the Patidar peasant community of Nadiad, in Gujarat, raised in a modest farming household.',
      people='his father Jhaverbhai, a farmer; his elder brother <b>Vithalbhai Patel</b>, also a nationalist; the Gujarat of his youth.',
      what='Raised on the land, Patel educated himself, qualified as a <b>district pleader</b> and made his name as a shrewd, fearless criminal lawyer — all through sheer self-reliance.',
      crux='He was <b>self-made through will alone</b>, owing his rise to discipline rather than birth or wealth.',
      conseq='This practical, unsentimental temperament would define his politics for the rest of his life.',
      matters='The unifier of India began as a farmer’s son — proof that iron character, not birth, makes the man.'),

    E('london', '1910–1913', 'Barrister trained in London', ['RISE', 'LAW'],
      'Determined to rise, Patel saves for years, sails to England, and enrols at the Middle Temple — completing the barrister’s course in record time at the top of his class before returning to become one of Ahmedabad’s most successful lawyers.',
      svg_stack('Sharpening the tool', [
          {'n': 1, 'label': 'Sails to England, 1910', 'sub': 'enrols at the Middle Temple, London', 'color': '#9a3412'},
          {'n': 2, 'label': 'Tops the barrister’s course', 'sub': 'finishes 36 months’ work in 30 — first in class', 'color': '#a16207'},
          {'n': 3, 'label': 'Ahmedabad’s leading advocate', 'sub': 'returns to a lucrative, anglicised practice', 'color': '#166534'},
      ], takeaway='He mastered the coloniser’s own law — then turned that discipline against the empire.', accent=AC),
      bg='Ambitious to become a barrister, Patel saved for years and travelled to London around 1910 to study law.',
      people='the English legal establishment; the family he supported at home; the Ahmedabad bar he would dominate.',
      what='At the <b>Middle Temple</b> he completed the barrister course in 30 months, finishing <b>first in his class</b>, and returned to build a thriving practice as an elegant, English-suited advocate.',
      crux='He acquired the empire’s <b>finest legal training</b> and its polished manners along with it.',
      conseq='The prosperous, cosmopolitan barrister seemed an unlikely rebel — until Gandhi changed his course.',
      matters='Mastery of a rival’s own tools is power — Patel learned British law before he helped end British rule.'),

    E('gandhi', '1917', 'Meeting Gandhi — the barrister turns nationalist', ['TURNING POINT', 'POLITICS'],
      'The sceptical, card-playing lawyer meets Mohandas Gandhi and is transformed — abandoning his prosperous practice and Western dress to become Gandhi’s most loyal and effective lieutenant in the freedom struggle.',
      svg_row('A conversion to the cause', [
          {'n': 1, 'label': 'A sceptical barrister', 'sub': 'dismisses Gandhi’s methods at first', 'color': '#78350f'},
          {'n': 2, 'label': 'Won over by Gandhi, 1917', 'sub': 'embraces satyagraha and swaraj', 'color': '#9a3412'},
          {'n': 3, 'label': 'Gandhi’s lieutenant', 'sub': 'gives up his practice for the movement', 'color': '#166534'},
      ], edge_labels=['then', 'becomes'], takeaway='The most practical of men bound himself to the most spiritual — and became his indispensable organiser.', accent=AC),
      bg='Initially indifferent to politics, Patel encountered <b>Gandhi</b> in 1917 and was drawn to his vision of mass nonviolent resistance.',
      people='<b>Mohandas Gandhi</b>, his new leader; the Gujarat Sabha; the peasants he would soon organise.',
      what='Patel abandoned his lucrative practice and Western lifestyle to follow Gandhi, becoming his <b>closest organiser and enforcer</b> within the Congress.',
      crux='He subordinated himself to Gandhi’s moral leadership while supplying the <b>organisational steel</b> Gandhi lacked.',
      conseq='Their partnership would drive the great mass campaigns of the freedom struggle.',
      matters='Great movements need both a prophet and an organiser — Gandhi supplied the vision, Patel the iron discipline.'),
]

# ==================================================================  PHASE 2 — THE SARDAR
PHASE_SARDAR = [
    E('kheda', '1918', 'The Kheda Satyagraha — champion of the peasant', ['POLITICS', 'TRIUMPH'],
      'When crop failure ruins the farmers of Kheda yet the British demand full taxes, Patel organises a mass no-tax campaign — his first great satyagraha — forcing the government to suspend collection and marking him as a fearless leader of the peasantry.',
      svg_row('A no-tax revolt that won', [
          {'n': 1, 'label': 'Crops fail, taxes stay', 'sub': 'Kheda’s peasants face ruin, 1918', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Patel organises resistance', 'sub': 'a disciplined no-tax satyagraha', 'color': '#9a3412'},
          {'n': 3, 'label': 'The government relents', 'sub': 'revenue collection suspended', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='His first campaign proved disciplined mass resistance could bend the empire — and made him the peasants’ champion.', accent=AC),
      bg='In 1918 famine and plague struck Kheda district, but the British insisted on collecting the full land revenue.',
      people='the Kheda peasants; <b>Gandhi</b>, who guided the campaign; the Bombay revenue authorities.',
      what='Patel led a <b>disciplined no-tax satyagraha</b>, persuading farmers to withhold revenue until the government suspended collection and returned seized property.',
      crux='He wielded <b>mass discipline and unity</b> as a weapon against the colonial state.',
      conseq='The victory made Patel a national figure and a proven master of grassroots organisation.',
      matters='Organised, disciplined non-cooperation can force a mighty state to yield — Patel’s lifelong method.'),

    E('bardoli', '1928', 'Bardoli — and the title “Sardar”', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'Patel leads the farmers of Bardoli in a total refusal to pay a steep tax hike — a campaign so disciplined and complete that the government capitulates, and a grateful people bestow on him the title “Sardar,” meaning chief or leader.',
      svg_stack('The campaign that named him', [
          {'n': 1, 'label': 'A steep tax hike, 1928', 'sub': 'Bardoli’s farmers face a sharp increase', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Total, disciplined refusal', 'sub': 'Patel unites the district to withhold all revenue', 'color': '#9a3412'},
          {'n': 3, 'label': 'Victory — and “Sardar”', 'sub': 'government backs down; women hail him as chief', 'color': '#166534'},
      ], takeaway='Bardoli made him a legend — the people crowned their disciplined leader “Sardar,” the chief.', accent=AC),
      bg='In 1928 the Bombay government sharply raised the land revenue in Bardoli taluka; the alarmed farmers turned to Patel.',
      people='the Bardoli peasants; the women who gave him the title; the Bombay Presidency officials.',
      what='Patel organised a <b>total refusal to pay</b>, holding the district in unbreakable unity until the government appointed an inquiry, rolled back the hike and released prisoners. Grateful villagers hailed him as <b>Sardar</b> (chief).',
      crux='<b>Absolute organisation and iron discipline</b> overwhelmed the state without a shot fired.',
      conseq='The triumph made Patel a first-rank national leader, and his title stuck for life.',
      matters='The Bardoli victory became a textbook of mass organisation — and it gave India its “Sardar.”'),

    E('organiser', '1931–1945', 'The iron organiser of Congress', ['POLITICS', 'REFORM'],
      'As Congress President and its chief organiser, Patel becomes the party’s disciplined enforcer — building its machine, managing its finances and factions, and enduring long imprisonment during the Quit India movement as Gandhi’s most trusted lieutenant.',
      svg_row('The party’s backbone', [
          {'n': 1, 'label': 'Congress President, 1931', 'sub': 'leads the party at the Karachi session', 'color': '#9a3412'},
          {'n': 2, 'label': 'The machine-builder', 'sub': 'organises funds, discipline and candidates', 'color': '#a16207'},
          {'n': 3, 'label': 'Jailed for Quit India, 1942', 'sub': 'imprisoned at Ahmednagar Fort', 'color': '#78350f'},
      ], edge_labels=['then', 'then'], takeaway='He was Congress’s iron spine — the organiser who built the machine that Gandhi and Nehru led.', accent=AC),
      bg='Through the 1930s and 1940s Patel was the organisational master of the Congress, complementing Gandhi’s moral authority and Nehru’s idealism.',
      people='<b>Gandhi</b> and <b>Nehru</b>, his fellow leaders; the Congress cadres he disciplined; the British who jailed him.',
      what='Elected <b>Congress President in 1931</b>, Patel ran the party’s organisation, finances and candidate selection, and was imprisoned from 1942 to 1945 for the <b>Quit India</b> movement.',
      crux='He supplied the <b>ruthless organisational discipline</b> that held the movement together.',
      conseq='This grip on the party machine made him the natural Home Minister of free India.',
      matters='Movements are won by organisers as much as by orators — Patel built the machine that delivered independence.'),
]

# ==================================================================  PHASE 3 — FREEDOM & THE STATES
PHASE_STATES = [
    E('deputypm', '1947', 'Deputy Prime Minister and Home Minister', ['POLITICS', 'TURNING POINT'],
      'At independence Patel becomes free India’s first Deputy Prime Minister and Home Minister — and immediately shoulders the most daunting task of all: welding a shattered subcontinent, including over 500 semi-independent princely states, into a single nation.',
      svg_stack('The nation’s strong man', [
          {'n': 1, 'label': 'Independence, 15 August 1947', 'sub': 'the Raj departs; India is born amid partition', 'color': '#9a3412'},
          {'n': 2, 'label': 'Deputy PM & Home Minister', 'sub': 'Patel takes charge of internal order', 'color': '#a16207'},
          {'n': 3, 'label': 'The task: one nation', 'sub': 'over 500 princely states must be integrated', 'color': '#166534'},
      ], takeaway='As Home Minister he held the levers of the new state — and faced the job of making India whole.', accent=AC),
      bg='At independence in 1947 British India was partitioned, and <b>565 princely states</b> were technically free to choose their own future.',
      people='<b>Jawaharlal Nehru</b>, the Prime Minister; <b>V.P. Menon</b>, his chief administrator; the maharajas and nizams.',
      what='Patel became the first <b>Deputy Prime Minister and Home Minister</b>, taking responsibility for internal security, the civil service and, above all, the <b>integration of the princely states</b>.',
      crux='The very <b>unity of India rested on his shoulders</b> in its most fragile hour.',
      conseq='He set about the integration with a blend of persuasion, pressure and, where needed, force.',
      matters='A nation can be born fragmented — it takes a strong hand to make it one, and Patel was India’s.'),

    E('accession', '1947', 'The Instrument of Accession — persuading the princes', ['POLITICS', 'TRIUMPH'],
      'With his trusted aide V.P. Menon, Patel confronts the maharajas — offering generous terms and privy purses to those who accede peacefully while making plain the cost of refusal — and by Independence Day persuades all but a handful of the 565 states to join the Indian Union.',
      svg_compare('Accede — or stand alone',
          {'head': 'Accede to India', 'color': '#166534', 'items': [
              'Sign the Instrument of Accession',
              'Keep titles, privy purses, dignity',
              'Join a stable, unified nation',
              'Patel’s friendly, respectful persuasion']},
          {'head': 'Refuse and resist', 'color': '#b91c1c', 'items': [
              'Face isolation and unrest',
              'Risk popular revolt within the state',
              'Confront the whole new Indian state',
              'No lasting future standing alone']},
          verdict='By 15 August 1947 all but three of 565 states had acceded',
          takeaway='Patel offered the princes a golden bridge — and left them in no doubt about the abyss on the other side.', accent=AC),
      bg='The <b>Ministry of States</b>, formed in 1947, was Patel’s instrument for integrating the princely states before and after independence.',
      people='<b>V.P. Menon</b>, his indispensable secretary; the 500-plus ruling princes; <b>Lord Mountbatten</b>, who aided the persuasion.',
      what='Patel and Menon secured the <b>Instrument of Accession</b> from all but three states by 15 August 1947, offering privy purses and guarantees to the rulers while making resistance untenable.',
      crux='He combined <b>generous incentives with the implicit threat of force</b> — the velvet glove over the iron hand.',
      conseq='A fragmented map of hundreds of states was welded into a single union with astonishing speed.',
      matters='One of history’s greatest peaceful acts of state-building — a subcontinent unified in months, not wars.'),

    E('junagadh', '1947–1948', 'Junagadh — the first holdout', ['POLITICS', 'BATTLE'],
      'When the Muslim ruler of Junagadh, a Hindu-majority state, tries to accede to Pakistan despite having no land link to it, Patel responds firmly — India moves in, the Nawab flees, and a plebiscite overwhelmingly confirms the people’s wish to join India.',
      svg_row('A ruler overruled by his people', [
          {'n': 1, 'label': 'Nawab opts for Pakistan', 'sub': 'though his people are mostly Hindu', 'color': '#b91c1c'},
          {'n': 2, 'label': 'India applies pressure', 'sub': 'blockade; the Nawab flees, 1947', 'color': '#9a3412'},
          {'n': 3, 'label': 'Plebiscite joins India', 'sub': 'over 99% vote to accede, 1948', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='Junagadh set the pattern: the wishes of the people, not the whim of a prince, would decide.', accent=AC),
      bg='Junagadh, a Hindu-majority state on the Gujarat coast with no border with Pakistan, saw its Muslim <b>Nawab accede to Pakistan</b> in 1947.',
      people='the <b>Nawab of Junagadh</b>; <b>V.P. Menon</b>; the state’s overwhelmingly Hindu population.',
      what='Patel refused to accept the accession; India imposed a <b>blockade</b>, the Nawab fled to Pakistan, and a <b>plebiscite in February 1948</b> returned over 99% in favour of joining India.',
      crux='He asserted that <b>geography and popular will</b>, not a ruler’s caprice, must govern accession.',
      conseq='Junagadh’s integration set a precedent for the far harder case of Hyderabad.',
      matters='Patel established a principle — the will of the people would override a prince’s defiance.'),
]

# ==================================================================  PHASE 4 — THE IRON MAN ACTS
PHASE_IRON = [
    E('hyderabad', '1948', 'Hyderabad — Operation Polo', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'The Nizam of Hyderabad, ruling a vast state in India’s heart, refuses to join and flirts with independence as his militia terrorises the populace — so Patel orders a swift police action, Operation Polo, and in about a hundred hours the largest princely state is absorbed into India.',
      svg_stack('The heart of India secured', [
          {'n': 1, 'label': 'The Nizam refuses, 1948', 'sub': 'seeks independence; the Razakar militia terrorises', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Operation Polo, 13 Sept 1948', 'sub': 'Patel orders a swift police action', 'color': '#9a3412'},
          {'n': 3, 'label': 'Hyderabad joins India', 'sub': 'the largest state falls in about 100 hours', 'color': '#166534'},
      ], takeaway='Where persuasion failed, Patel used decisive force — and secured the great state at India’s core.', accent=AC),
      bg='Hyderabad, the largest and richest princely state, lay landlocked in India’s centre; its <b>Nizam</b> sought independence while the <b>Razakar</b> militia spread violence.',
      people='the <b>Nizam of Hyderabad</b>; the Razakar paramilitaries; the Indian Army acting under Patel’s direction.',
      what='After negotiations failed, Patel launched <b>Operation Polo on 13 September 1948</b>; the Indian Army overwhelmed the state’s forces in roughly five days and Hyderabad acceded to India.',
      crux='He judged that a <b>landlocked, hostile state in India’s heart could not be tolerated</b>, and acted decisively.',
      conseq='With Hyderabad integrated, the map of India was very nearly complete.',
      matters='The iron will that unified India — Patel matched patience with force when the nation’s integrity demanded it.'),

    E('steelframe', '1947–1950', 'The “steel frame” — building the civil service', ['REFORM', 'POLITICS'],
      'Patel insists that the new nation needs a strong, impartial permanent bureaucracy — and against opposition he preserves and reshapes the colonial services into the All India Services, the Indian Administrative and Police Services that he calls the “steel frame” of the state.',
      svg_row('The framework of the state', [
          {'n': 1, 'label': 'A nation needs administration', 'sub': 'the chaos of partition demands order', 'color': '#9a3412'},
          {'n': 2, 'label': 'Preserve and reform the services', 'sub': 'creates the All India Services', 'color': '#a16207'},
          {'n': 3, 'label': 'The “steel frame”', 'sub': 'the IAS and IPS bind the union together', 'color': '#166534'},
      ], edge_labels=['so', 'forging'], takeaway='He built the permanent machinery of the state — the impartial steel frame that still holds India together.', accent=AC),
      bg='As Home Minister, Patel had to build the administrative machinery of the new state amid the upheaval of partition.',
      people='the Indian Civil Service officers he retained; the new <b>IAS and IPS</b> recruits; sceptical politicians.',
      what='Over the objections of some colleagues, Patel preserved and reformed the higher civil service into the <b>All India Services</b> — the Indian Administrative Service and Indian Police Service — which he called the country’s <b>“steel frame.”</b>',
      crux='He prized a <b>strong, neutral permanent bureaucracy</b> as essential to national unity and order.',
      conseq='The services he built remain the administrative backbone of the Indian state to this day.',
      matters='Institutions outlast their founders — Patel’s steel frame is among his most enduring legacies.'),

    E('partnership', '1947–1950', 'Iron will and pragmatism — Patel and Nehru', ['POLITICS', 'REFORM'],
      'Blunt, pragmatic and conservative, Patel often differs sharply with the idealistic Nehru — yet for the sake of unity the two hold together, Patel wielding the iron will and organisational grip that complement the Prime Minister’s vision.',
      svg_compare('Two pillars of the new republic',
          {'head': 'Sardar Patel', 'color': '#9a3412', 'items': [
              'Pragmatic and conservative',
              'Iron will; the organiser',
              'Strong states and firm order',
              'The nation’s unifier and enforcer']},
          {'head': 'Jawaharlal Nehru', 'color': '#1e40af', 'items': [
              'Idealistic and socialist',
              'The visionary; the orator',
              'Non-alignment and planning',
              'The nation’s face to the world']},
          verdict='Rivals in temperament, partners in building the nation',
          takeaway='India’s founding balanced Patel’s iron pragmatism against Nehru’s idealism — and needed both.', accent=AC),
      bg='Patel and Nehru, the two strongest figures in the cabinet, differed on economics, foreign policy and party matters.',
      people='<b>Jawaharlal Nehru</b>, the Prime Minister; <b>Gandhi</b>, who kept them united; the cabinet of 1947–50.',
      what='Despite frequent disagreements, Patel and Nehru maintained a <b>working partnership</b> at Gandhi’s urging, with Patel handling home affairs and integration while Nehru led on vision and foreign policy.',
      crux='He placed <b>national unity above personal rivalry</b>, subordinating differences to the common task.',
      conseq='Their uneasy partnership steadied India through its fragile first years.',
      matters='Nation-building needs complementary strengths — Patel’s iron realism balanced Nehru’s soaring idealism.'),
]

# ==================================================================  PHASE 5 — LEGACY & DEATH
PHASE_LEGACY = [
    E('death', '1948–1950', 'The Iron Man’s last years', ['DEATH', 'TRAGEDY'],
      'Grief-stricken by Gandhi’s assassination and worn down by relentless labour, Patel’s health fails — and on 15 December 1950, his great task of unification all but complete, the Iron Man of India dies in Bombay, mourned by a nation he had made whole.',
      svg_stack('The task complete', [
          {'n': 1, 'label': 'Gandhi assassinated, Jan 1948', 'sub': 'a heavy personal blow to Patel', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Health fails under the strain', 'sub': 'years of ceaseless work take their toll', 'color': '#78350f'},
          {'n': 3, 'label': 'Death, 15 December 1950', 'sub': 'the Iron Man dies, his union built', 'color': '#9a3412'},
      ], takeaway='He died with his life’s work nearly done — the fragments of India gathered into one nation.', accent=AC),
      bg='Patel’s health, never robust, declined sharply after Gandhi’s assassination in January 1948 and years of overwork.',
      people='<b>Gandhi</b>, whose death grieved him; Nehru and the nation that mourned him; his daughter <b>Maniben</b>, his devoted aide.',
      what='Worn down by heart trouble, Patel died on <b>15 December 1950</b> in Bombay, having integrated almost all of India in barely three years as Home Minister.',
      crux='He gave his <b>failing health entirely</b> to the task of unification, working to the end.',
      conseq='He was mourned across India, though the fullest national recognition came only decades later.',
      matters='He spent himself completely on one supreme achievement — making India one.'),

    E('legacy', 'legacy', 'The man who made India whole', ['LEGACY', 'TRIUMPH'],
      'Patel’s integration of over 500 states into a single union stands as one of history’s greatest feats of peaceful nation-building — the “Bismarck of India” and “Iron Man” whose firm, pragmatic will gave the republic its territorial shape.',
      svg_row('The unifier’s legacy', [
          {'n': 1, 'label': 'Over 500 states integrated', 'sub': 'a subcontinent welded into one union', 'color': '#9a3412'},
          {'n': 2, 'label': 'The “Iron Man of India”', 'sub': 'firm, pragmatic, decisive nation-builder', 'color': '#a16207'},
          {'n': 3, 'label': 'The map of modern India', 'sub': 'his greatest and most lasting achievement', 'color': '#166534'},
      ], edge_labels=['made him', 'yielding'], takeaway='Without Patel there might be no single India — his unification is his monument.', accent=AC),
      bg='In barely three years Patel welded hundreds of principalities into the Indian Union, a feat compared to Bismarck’s unification of Germany.',
      people='<b>V.P. Menon</b>, his partner in integration; the princes he absorbed; the citizens of a unified India.',
      what='Patel’s <b>peaceful integration of over 500 princely states</b> gave India its modern territorial form and earned him lasting fame as the <b>Iron Man</b> and the “Bismarck of India.”',
      crux='He achieved by <b>pragmatism and will</b> what could otherwise have taken wars.',
      conseq='The unity of India is his enduring monument, still visible in every corner of its map.',
      matters='Few individuals have shaped a nation’s very borders — Patel drew the map of modern India.'),

    E('statue', '1991–2018', 'Honoured at last — the Statue of Unity', ['LEGACY'],
      'Long underappreciated beside Gandhi and Nehru, Patel is honoured in full over the decades — awarded the Bharat Ratna, his birthday marked as National Unity Day, and commemorated by the Statue of Unity in Gujarat, at 182 metres the tallest statue in the world.',
      svg_stack('A belated tribute', [
          {'n': 1, 'label': 'Bharat Ratna, 1991', 'sub': 'India’s highest honour, awarded posthumously', 'color': '#a16207'},
          {'n': 2, 'label': 'National Unity Day, from 2014', 'sub': 'his birthday, 31 October, so marked', 'color': '#9a3412'},
          {'n': 3, 'label': 'The Statue of Unity, 2018', 'sub': 'at 182 m, the tallest statue on earth', 'color': '#166534'},
      ], takeaway='The nation he unified finally raised the world’s tallest statue to its Iron Man.', accent=AC),
      bg='For decades Patel’s role was overshadowed by other founders, but recognition grew from the late twentieth century onward.',
      people='the government that awarded him the Bharat Ratna; the people of Gujarat, his home; visitors to the statue.',
      what='Patel received the <b>Bharat Ratna in 1991</b>; his birthday became <b>Rashtriya Ekta Diwas</b> (National Unity Day) from 2014; and in 2018 the <b>Statue of Unity</b>, the world’s tallest at 182 metres, was unveiled in Gujarat.',
      crux='National memory finally <b>caught up with the scale</b> of his achievement.',
      conseq='Patel is now firmly enshrined as the unifier and Iron Man of India.',
      matters='A nation eventually honours those who made it — the Statue of Unity is India’s tribute to the man who bound it together.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Sardar Vallabhbhai Patel was the Iron Man of India — the farmer’s son who became a London barrister, Gandhi’s most effective lieutenant, and independent India’s first Deputy Prime Minister and Home Minister. His supreme achievement was the peaceful integration of over 500 princely states into a single Indian Union, welding a fragmented subcontinent into one nation in barely three years. Blunt, pragmatic and iron-willed, he took Junagadh and Hyderabad, built the civil service “steel frame,” and gave the republic its very shape. He is the ultimate study in <b>pragmatic statecraft, national unity, and the iron will to build a nation.</b></p>
<div class="ov-quote">“Every Indian should now forget that he is a Rajput, a Sikh or a Jat. He must remember that he is an Indian.”<span>— Sardar Vallabhbhai Patel</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A farmer’s son becomes a London barrister → meets Gandhi and gives up his practice to become his organiser → wins Kheda and Bardoli and is crowned “Sardar” → builds the Congress machine and endures prison → becomes free India’s Deputy PM and Home Minister → integrates over 500 princely states, taking Junagadh and Hyderabad → builds the civil service steel frame → and dies in 1950 having made India one.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🗺️</div><h4>The unifier of India</h4><p>Welded over 500 princely states into one nation, peacefully and fast.</p></div>
  <div class="ov-card"><div class="i">🛡️</div><h4>The Iron Man</h4><p>Firm, pragmatic will that held the young republic together.</p></div>
  <div class="ov-card"><div class="i">🏛️</div><h4>The steel frame</h4><p>Built the civil service that still administers India.</p></div>
  <div class="ov-card"><div class="i">🤝</div><h4>Nation-building</h4><p>Balanced Nehru’s idealism with hard, practical statecraft.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Making</b><small> 1875–1917</small><p>Farmer’s son to London barrister to Gandhi’s man.</p></div>
  <div><b>2 · The Sardar</b><small> 1918–1945</small><p>Kheda, Bardoli, the title, and the iron organiser.</p></div>
  <div><b>3 · Freedom & the States</b><small> 1947</small><p>Deputy PM; persuading the princes; Junagadh.</p></div>
  <div><b>4 · The Iron Man Acts</b><small> 1947–1950</small><p>Hyderabad, the steel frame, and Nehru.</p></div>
  <div><b>5 · Legacy & Death</b><small> 1948–2018</small><p>His death, the unity legacy, the Statue of Unity.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Mahatma Gandhi', 'role': 'his leader', 'color': '#166534',
     'bio': 'The leader Patel served as his most loyal and effective lieutenant, giving up his practice and Western dress to follow him.',
     'rel': 'The mentor whose mass movement he organised.'},
    {'name': 'V.P. Menon', 'role': 'his right hand', 'color': '#9a3412',
     'bio': 'The civil servant and secretary of the Ministry of States who was Patel’s indispensable partner in integrating the princely states.',
     'rel': 'His trusted administrator in the great integration.'},
    {'name': 'Jawaharlal Nehru', 'role': 'fellow founder & rival', 'color': '#1e40af',
     'bio': 'India’s first Prime Minister, Patel’s frequent rival in temperament and policy, yet his partner in building the nation.',
     'rel': 'The idealist counterpart to Patel’s pragmatism.'},
    {'name': 'The Nizam of Hyderabad', 'role': 'adversary', 'color': '#b91c1c',
     'bio': 'The ruler of the largest princely state, who sought independence until Operation Polo forced Hyderabad into India in 1948.',
     'rel': 'The great holdout he subdued by force.'},
    {'name': 'Vithalbhai Patel', 'role': 'his elder brother', 'color': '#a16207',
     'bio': 'A prominent nationalist and Speaker of the Central Legislative Assembly — Patel’s elder brother and an early political influence.',
     'rel': 'His elder brother and fellow politician.'},
]

KEY_EVENTS = [
    ('1875', 'Patel born', 'A farmer’s son in Nadiad, Gujarat.'),
    ('1913', 'Barrister from London', 'Tops the Middle Temple course.'),
    ('1917', 'Joins Gandhi', 'Gives up his practice for the cause.'),
    ('1918', 'Kheda Satyagraha', 'His first peasant no-tax victory.'),
    ('1928', 'Bardoli & “Sardar”', 'Wins the title of chief.'),
    ('1931', 'Congress President', 'The party’s iron organiser.'),
    ('1947', 'Deputy PM & Home Minister', 'Integrates the princely states.'),
    ('1947', 'Junagadh accedes', 'A people’s plebiscite joins India.'),
    ('1948', 'Operation Polo', 'Hyderabad absorbed into India.'),
    ('1950', 'Death of Patel', 'The Iron Man’s task complete.'),
]

MASTER = [
    {'year': '1875', 'age': 'born', 'phase': 'The Making', 'title': 'Born in Gujarat', 'desc': 'A Patidar farmer’s son.'},
    {'year': '1917', 'age': 'age 42', 'phase': 'The Sardar', 'title': 'Joins Gandhi', 'desc': 'Barrister turns nationalist.'},
    {'year': '1928', 'age': 'age 53', 'phase': 'The Sardar', 'title': 'Bardoli Satyagraha', 'desc': 'Earns the title Sardar.'},
    {'year': '1947', 'age': 'age 71', 'phase': 'Freedom & the States', 'title': 'Deputy PM & Home Minister', 'desc': 'Integrates 500+ states.'},
    {'year': '1948', 'age': 'age 72', 'phase': 'The Iron Man Acts', 'title': 'Operation Polo', 'desc': 'Hyderabad joins India.'},
    {'year': '1950', 'age': 'age 75', 'phase': 'Legacy', 'title': 'Death of the Iron Man', 'desc': 'His union built.'},
]

SOURCES = [
    ('Britannica — Vallabhbhai Patel', 'https://www.britannica.com/biography/Vallabhbhai-Patel'),
    ('Wikipedia — Vallabhbhai Patel', 'https://en.wikipedia.org/wiki/Vallabhbhai_Patel'),
    ('Wikipedia — Political integration of India', 'https://en.wikipedia.org/wiki/Political_integration_of_India'),
    ('Wikipedia — Operation Polo', 'https://en.wikipedia.org/wiki/Operation_Polo'),
    ('Statue of Unity — Official site', 'https://www.statueofunity.in/'),
]

def build_meta():
    return {
        'pid': 'gm-patel.html', 'kind': 'man', 'emoji': '🛡️', 'accent': AC,
        'name': 'Sardar Vallabhbhai Patel', 'years': '1875–1950', 'group': 'Independence & Nation-Building',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Iron Man of India — Gandhi’s lieutenant and independent India’s first Deputy Prime Minister, whose iron will and pragmatism welded over 500 princely states into a single nation.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'making', 'label': '1 · The Making', 'type': 'timeline',
             'intro': 'A Patidar farmer’s son rises by sheer will to become a London barrister and Ahmedabad’s leading advocate — until he meets Gandhi and gives it all up for the freedom struggle.', 'events': PHASE_MAKING},
            {'id': 'sardar', 'label': '2 · The Sardar', 'type': 'timeline',
             'intro': 'He champions the peasantry at Kheda and Bardoli — where a grateful people crown him “Sardar” — and becomes the iron organiser of the Congress through prison and Quit India.', 'events': PHASE_SARDAR},
            {'id': 'states', 'label': '3 · Freedom & the States', 'type': 'timeline',
             'intro': 'As free India’s Deputy PM and Home Minister he confronts the greatest task of all: integrating over 500 princely states, wielding the Instrument of Accession with V.P. Menon and bringing in Junagadh.', 'events': PHASE_STATES},
            {'id': 'iron', 'label': '4 · The Iron Man Acts', 'type': 'timeline',
             'intro': 'Where persuasion fails he uses force — taking Hyderabad in Operation Polo — while building the civil service “steel frame” and balancing his iron pragmatism against Nehru’s idealism.', 'events': PHASE_IRON},
            {'id': 'legacy', 'label': '5 · Legacy & Death', 'type': 'timeline',
             'intro': 'Worn down by his labours, the Iron Man dies in 1950 with his union built — and the nation he made whole finally honours him with the Bharat Ratna and the world’s tallest statue.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; figures such as the number of princely states and statue height follow the commonly cited standard accounts.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
