# -*- coding: utf-8 -*-
"""Full, DEEP guide content for B. R. Ambedkar.
The jurist and reformer who rose from ‘untouchability’ to draft India’s Constitution and champion social justice."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#2563eb'  # Ambedkarite blue — the colour of the Dalit movement

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — CASTE AND EDUCATION
PHASE_RISE = [
    E('origins', '1891–1907', 'Born ‘untouchable’ — a childhood of humiliation', ['RISE', 'TRAGEDY'],
      'Bhimrao Ramji Ambedkar is born into the Mahar caste — deemed ‘untouchable’ under the Hindu caste order — and grows up facing daily degradation: made to sit apart on a sack in school, denied water others could drink, treated as polluting by birth. The wounds of that childhood become the fire of his life’s work.',
      svg_row('Caste marks a child at birth', [
          {'n': 1, 'label': 'Born Mahar, 1891', 'sub': 'a Dalit “untouchable” caste in Mhow', 'color': '#2563eb'},
          {'n': 2, 'label': 'Daily humiliation', 'sub': 'seated apart, denied water, deemed polluting', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A resolve is born', 'sub': 'the injustice becomes his life’s cause', 'color': '#166534'},
      ], edge_labels=['means', 'forges'], takeaway='The degradation he suffered as a child became the injustice he devoted his whole life to destroying.', accent=AC),
      bg='<b>Bhimrao Ramji Ambedkar</b> was born on 14 April 1891 at Mhow, into the <b>Mahar</b> caste, classed as “untouchable” in the Hindu social order. His father was a subedar in the British Indian Army.',
      people='his father <b>Ramji Maloji Sakpal</b>, an army man who prized education; his mother Bhimabai; the caste society that shunned them.',
      what='As an untouchable child, Ambedkar was made to <b>sit apart on a gunny sack</b> in the classroom, <b>forbidden to touch the common water</b>, and treated as ritually polluting — humiliations that scarred him for life.',
      crux='He learned from the cradle that caste was not custom but <b>systematic degradation</b> — a denial of the humanity of millions.',
      conseq='The experience gave him a lifelong, burning determination to overthrow untouchability and the caste system that produced it.',
      matters='Injustice endured in childhood can forge a reformer — Ambedkar turned personal humiliation into a movement for human dignity.'),

    E('columbia', '1913–1916', 'Columbia University — a mind unbound under John Dewey', ['RISE', 'EDUCATION'],
      'Winning a scholarship from the Maharaja of Baroda, Ambedkar sails to New York and Columbia University — where, studying economics under the philosopher John Dewey, he thrives in a society that judges him by his intellect rather than his birth, earning advanced degrees and finding the ideas of democracy and equality that will guide him.',
      svg_stack('An untouchable becomes a world-class scholar', [
          {'n': 1, 'label': 'Baroda scholarship to America', 'sub': 'sails to Columbia University, New York, 1913', 'color': '#2563eb'},
          {'n': 2, 'label': 'Studies under John Dewey', 'sub': 'economics, and ideals of democracy and equality', 'color': '#a16207'},
          {'n': 3, 'label': 'Judged by his mind, not his birth', 'sub': 'earns an MA and a PhD in economics', 'color': '#166534'},
      ], takeaway='In America, freed from caste for the first time, Ambedkar flowered into a scholar of the first rank — and absorbed the language of equality.', accent=AC),
      bg='A scholarship from <b>Sayajirao Gaekwad III, Maharaja of Baroda</b>, sent the brilliant young Ambedkar abroad. In 1913 he entered Columbia University in New York.',
      people='the reformer-philosopher <b>John Dewey</b>, whose ideas of democracy shaped him; the Maharaja of Baroda, his patron.',
      what='At Columbia (1913–16) Ambedkar studied under <b>John Dewey</b>, earning an MA and a <b>PhD in economics</b> (his thesis on provincial finance), while immersing himself in Western ideas of <b>democracy, rights and equality</b>.',
      crux='In a society that valued his intellect over his caste, he saw proof that <b>human worth is not fixed by birth</b> — and found the philosophical tools to fight caste.',
      conseq='He returned to India armed with elite credentials and a conviction that democracy and equality could be built at home.',
      matters='Education can shatter the ceilings caste imposes — Ambedkar’s learning made him impossible for a hierarchical society to ignore.'),

    E('barrister', '1916–1923', 'London — barrister, economist, doctor of science', ['RISE', 'EDUCATION'],
      'From New York Ambedkar goes to London, enrolling at the London School of Economics and at Gray’s Inn — completing yet another doctorate and qualifying as a barrister, becoming one of the most highly educated Indians of his generation and building the intellectual armour he will wield against caste for the rest of his life.',
      svg_stack('Building an unassailable armoury of learning', [
          {'n': 1, 'label': 'London School of Economics', 'sub': 'a second doctorate (D.Sc.) in economics', 'color': '#2563eb'},
          {'n': 2, 'label': 'Called to the Bar, Gray’s Inn', 'sub': 'qualifies as a barrister-at-law', 'color': '#a16207'},
          {'n': 3, 'label': 'Among India’s most learned', 'sub': 'law, economics and scholarship combined', 'color': '#166534'},
      ], takeaway='He stacked degree upon degree until no one could dismiss him — armouring an untouchable in the credentials of the ruling class.', accent=AC),
      bg='After Columbia, Ambedkar studied at the <b>London School of Economics</b> and read for the bar at <b>Gray’s Inn</b>, interrupted and resumed as funds allowed.',
      people='the British academic establishment; the small circle of Indian students in London; the caste society awaiting his return.',
      what='In London Ambedkar earned a <b>D.Sc. in economics</b> from the LSE and was <b>called to the bar</b> at Gray’s Inn — adding law to economics and becoming one of the best-educated Indians of his time.',
      crux='He deliberately amassed the <b>highest credentials of the colonial elite</b>, so that his fight against caste could not be brushed aside as ignorance.',
      conseq='He came home a barrister and economist — ready to lead, argue and legislate on behalf of the Depressed Classes.',
      matters='Mastering the establishment’s own tools is a weapon of the excluded — Ambedkar out-qualified the very society that scorned him.'),
]

# ==================================================================  PHASE 2 — LEADER OF THE DEPRESSED CLASSES
PHASE_POWER = [
    E('leadership', '1919–1927', 'Voice of the voiceless — organising the Depressed Classes', ['POLITICS', 'REFORM'],
      'Back in India, Ambedkar emerges as the foremost leader of the Depressed Classes — testifying before colonial commissions, founding the newspaper Mooknayak (“Leader of the Voiceless”) and the Bahishkrit Hitakarini Sabha to press for education, rights and self-respect, and forging a movement led by untouchables themselves.',
      svg_stack('An untouchable-led movement takes shape', [
          {'n': 1, 'label': 'Speaks for the Depressed Classes', 'sub': 'testifies before colonial commissions', 'color': '#2563eb'},
          {'n': 2, 'label': 'Mooknayak & the Sabha', 'sub': 'a newspaper and society for the excluded', 'color': '#a16207'},
          {'n': 3, 'label': 'Self-respect and rights', 'sub': 'education, dignity, political voice', 'color': '#166534'},
      ], takeaway='He built a movement of the untouchables, by the untouchables — turning a scattered, silenced people into an organised political force.', accent=AC),
      bg='Returning to India, Ambedkar practised law and taught, but increasingly devoted himself to organising the millions consigned to untouchability.',
      people='the untouchable communities he mobilised; reform-minded colonial officials; the caste-Hindu establishment he challenged.',
      what='Ambedkar founded the newspaper <b>Mooknayak</b> (1920) and the <b>Bahishkrit Hitakarini Sabha</b> (1924), testified before commissions, and became the recognised <b>leader of the Depressed Classes</b>, demanding education, rights and dignity.',
      crux='He insisted the untouchables must be led and represented <b>by themselves</b>, not spoken for by caste-Hindu reformers.',
      conseq='His organising built the base for the mass direct-action campaigns to come.',
      matters='Liberation must be led by the oppressed — Ambedkar built a movement rooted in the agency of the excluded themselves.'),

    E('mahad', '1927', 'The Mahad Satyagraha — a drink of water as revolution', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'Ambedkar leads thousands of untouchables to the Chavdar Tank at Mahad to assert their right to drink from a public water source — a peaceful act that provokes violent backlash — and later publicly burns the Manusmriti, the ancient text sanctioning caste, in a thunderous rejection of the scriptures of untouchability.',
      svg_row('Claiming water — and burning the code of caste', [
          {'n': 1, 'label': 'March to Chavdar Tank', 'sub': 'untouchables assert the right to drink, 1927', 'color': '#2563eb'},
          {'n': 2, 'label': 'Violent backlash', 'sub': 'caste Hindus attack; the tank is “purified”', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The Manusmriti burned', 'sub': 'he publicly rejects the scripture of caste', 'color': '#78350f'},
      ], edge_labels=['meets', 'answered by'], takeaway='A simple drink of water became an act of revolution — and burning the Manusmriti declared the whole edifice of caste illegitimate.', accent=AC),
      bg='Public tanks and wells were routinely closed to untouchables. In 1927 Ambedkar chose the <b>Chavdar Tank at Mahad</b> as the site of a decisive challenge.',
      people='the thousands of untouchable marchers; the caste Hindus who attacked them; Ambedkar, leading from the front.',
      what='Ambedkar led the <b>Mahad Satyagraha (1927)</b>, marching untouchables to drink from the public Chavdar Tank; when caste Hindus rioted and ritually “purified” the water, he responded by <b>publicly burning the Manusmriti</b>, the text sanctioning caste.',
      crux='He turned the humblest human need — a drink of water — into a claim of <b>equal citizenship</b>, and rejected the sacred sanction of caste outright.',
      conseq='Mahad became a landmark of the anti-caste movement and marked Ambedkar as its militant national leader.',
      matters='Dignity is asserted through action — Ambedkar showed that claiming an ordinary right can be the most radical of acts.'),

    E('kalaram', '1930', 'The Kalaram Temple entry — knocking at the gods’ door', ['POLITICS', 'BATTLE'],
      'Ambedkar leads a years-long campaign to open the Kalaram Temple in Nashik to untouchables — a mass, disciplined satyagraha met by locked doors and fierce resistance — that dramatises the totality of untouchable exclusion and pushes Ambedkar toward a hard conclusion: that dignity may not be found within Hinduism at all.',
      svg_stack('Barred even from the temple of the gods', [
          {'n': 1, 'label': 'Kalaram Temple entry, 1930', 'sub': 'untouchables demand the right to worship', 'color': '#2563eb'},
          {'n': 2, 'label': 'Doors locked, resistance fierce', 'sub': 'a years-long, disciplined satyagraha', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A hardening doubt', 'sub': 'can dignity be won inside Hinduism at all?', 'color': '#78350f'},
      ], takeaway='Barred even from the presence of the gods, Ambedkar began to conclude that untouchables might never find equality within the Hindu fold.', accent=AC),
      bg='Temples, like tanks, were closed to untouchables. In 1930 Ambedkar launched a campaign to open the <b>Kalaram Temple at Nashik</b>.',
      people='the untouchable satyagrahis; the temple authorities and caste Hindus who barred them; Ambedkar and his lieutenants.',
      what='The <b>Kalaram Temple Entry Satyagraha (1930 onward)</b> saw thousands of untouchables peacefully demand the right to worship, only to be met by <b>locked doors and violence</b> over several years.',
      crux='The refusal to admit untouchables even to a temple crystallised his sense that <b>Hindu society would not reform itself</b> from within.',
      conseq='The campaign deepened his turn toward political rights — and, ultimately, toward leaving Hinduism altogether.',
      matters='When even the gods’ door is bolted, reformers look elsewhere — Kalaram set Ambedkar on the road to exit.'),
]

# ==================================================================  PHASE 3 — THE GREAT DEBATE
PHASE_ORDER = [
    E('roundtable', '1930–1932', 'The Round Table Conferences — demanding separate electorates', ['POLITICS', 'TURNING POINT'],
      'At the Round Table Conferences in London, Ambedkar speaks for the Depressed Classes on the national stage — arguing that untouchables are a distinct, disadvantaged community who need separate electorates of their own to guarantee real political representation and protection from the caste majority.',
      svg_stack('A seat at the table for the untouchables', [
          {'n': 1, 'label': 'Round Table Conferences, London', 'sub': 'Ambedkar represents the Depressed Classes', 'color': '#2563eb'},
          {'n': 2, 'label': 'A distinct, disadvantaged people', 'sub': 'untouchables need guaranteed representation', 'color': '#a16207'},
          {'n': 3, 'label': 'Demand: separate electorates', 'sub': 'seats untouchables alone would elect', 'color': '#166534'},
      ], takeaway='On the imperial stage he argued that untouchables were a people apart, needing their own votes to be heard — and won the Communal Award.', accent=AC),
      bg='Britain convened the <b>Round Table Conferences (1930–32)</b> to discuss India’s constitutional future. Ambedkar attended as spokesman for the Depressed Classes.',
      people='the British government; <b>Mahatma Gandhi</b>, representing the Congress; the princes and communal leaders; Ambedkar for the untouchables.',
      what='At the conferences Ambedkar argued that the Depressed Classes were a <b>distinct community</b> requiring <b>separate electorates</b> — reserved seats that untouchables alone would vote for — to secure genuine representation, a demand granted in the 1932 <b>Communal Award</b>.',
      crux='He believed only <b>self-chosen representatives</b>, elected by untouchables alone, could truly speak for them against the caste majority.',
      conseq='The Communal Award’s grant of separate electorates set him on a collision course with Gandhi.',
      matters='Representation is the heart of political power — Ambedkar fought for the untouchables to choose their own voice, not have it chosen for them.'),

    E('poona', '1932', 'Gandhi’s fast and the Poona Pact — a bitter compromise', ['POLITICS', 'TURNING POINT'],
      'When the British grant separate electorates to the Depressed Classes, Gandhi — fearing it would split Hindu society forever — begins a fast unto death in prison. With Gandhi’s life in the balance and public fury rising, Ambedkar is pressed into the Poona Pact: he surrenders separate electorates for a larger number of reserved seats within the general Hindu electorate.',
      svg_compare('Two leaders, two visions of the untouchables’ future',
          {'head': 'Ambedkar', 'color': '#2563eb', 'items': [
              'Untouchables are a distinct community',
              'Separate electorates: elected by themselves',
              'Only self-chosen voices truly represent them',
              'Political guarantees over Hindu unity',
          ]},
          {'head': 'Gandhi', 'color': '#b91c1c', 'items': [
              'Untouchables are part of Hindu society',
              'Separate electorates would split Hinduism',
              'Fasts unto death against the Award',
              'Reform from within, not separation',
          ]},
      verdict='Poona Pact (1932): reserved seats in a joint electorate replace separate electorates',
      takeaway='Under the moral pressure of Gandhi’s fast, Ambedkar traded separate electorates for many more reserved seats — a compromise he always resented.', accent=AC),
      bg='The <b>Communal Award (1932)</b> granted separate electorates to the Depressed Classes. Gandhi, imprisoned at Yerwada, opposed it as fatal to Hindu unity.',
      people='<b>Mahatma Gandhi</b>, fasting unto death; <b>Ambedkar</b>, holding the untouchables’ mandate; the leaders brokering a deal.',
      what='Gandhi began a <b>fast unto death</b> against separate electorates; with his life at stake, Ambedkar signed the <b>Poona Pact (24 September 1932)</b>, giving up separate electorates in exchange for a <b>larger bloc of reserved seats</b> (148) within joint Hindu electorates.',
      crux='Ambedkar yielded a principle he cherished — self-chosen representation — under the <b>moral and political coercion</b> of Gandhi’s fast.',
      conseq='He accepted the pact but felt the untouchables had been robbed of a real political guarantee; the resentment shaped his later career.',
      matters='Even a hard-won right can be bargained away under pressure — the Poona Pact remains a landmark and a wound in Dalit political memory.'),

    E('annihilation', '1936', '“Annihilation of Caste” — the case for demolition', ['POLITICS', 'REFORM'],
      'Invited then disinvited to address caste-reforming Hindus, Ambedkar publishes his undelivered speech as “Annihilation of Caste” — a blistering, closely argued indictment that caste cannot be reformed but must be destroyed, that it is rooted in scripture itself, and that real equality requires abandoning the religious sanction of hierarchy.',
      svg_stack('Not reform of caste, but its abolition', [
          {'n': 1, 'label': 'A speech too radical to deliver', 'sub': 'the reformers withdraw their invitation', 'color': '#2563eb'},
          {'n': 2, 'label': 'Caste is rooted in scripture', 'sub': 'it cannot be reformed, only destroyed', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Equality needs a new foundation', 'sub': 'abandon the religious sanction of hierarchy', 'color': '#166534'},
      ], takeaway='He argued that tinkering with caste was useless — it had to be annihilated at the root, in the scriptures that sanctified it.', accent=AC),
      bg='In 1936 a caste-reform society, the Jat-Pat-Todak Mandal, invited Ambedkar to speak — then withdrew when it saw how radical his text was.',
      people='the caste-Hindu reformers who recoiled; the untouchables he addressed; Gandhi, who publicly debated the text.',
      what='Ambedkar published the undelivered address as <b>“Annihilation of Caste” (1936)</b>, arguing that caste is <b>sanctioned by Hindu scripture</b>, cannot be reformed piecemeal, and must be <b>abolished at its religious root</b> for equality to exist.',
      crux='He located the disease not in bad behaviour but in the <b>sacred texts themselves</b> — so reform of manners was futile; the foundation had to change.',
      conseq='The text became a classic of anti-caste thought and foreshadowed his eventual break with Hinduism.',
      matters='Naming the root of an injustice is the first step to ending it — Ambedkar refused half-measures where he saw a system that had to fall.'),
]

# ==================================================================  PHASE 4 — ARCHITECT OF THE REPUBLIC
PHASE_REPRESSION = [
    E('drafting', '1947–1949', 'Architect of the Constitution — chairman of the drafting committee', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'At independence, the man once forbidden to touch the school water is made chairman of the committee that drafts the Constitution of India — the chief architect of a founding document that abolishes untouchability, guarantees equality and fundamental rights, and builds a democratic republic on the principle that all citizens are equal before the law.',
      svg_stack('The untouchable who wrote a nation’s charter', [
          {'n': 1, 'label': 'Chairman, Drafting Committee', 'sub': 'chief architect of India’s Constitution, 1947', 'color': '#2563eb'},
          {'n': 2, 'label': 'Abolishes untouchability', 'sub': 'equality, liberty and fundamental rights', 'color': '#166534'},
          {'n': 3, 'label': 'A democratic republic', 'sub': 'adopted 1949; in force 26 January 1950', 'color': '#a16207'},
      ], takeaway='The boy denied a drink of water became the principal author of the charter that made every Indian, by law, equal — and outlawed untouchability itself.', accent=AC),
      bg='With independence in 1947, India set out to write its own Constitution. Ambedkar’s unmatched legal learning made him the natural choice to lead the drafting.',
      people='Prime Minister <b>Jawaharlal Nehru</b>; the Constituent Assembly; the drafting committee Ambedkar chaired.',
      what='As <b>chairman of the Drafting Committee</b> and its guiding intellect, Ambedkar shaped the <b>Constitution of India</b> — <b>abolishing untouchability (Article 17)</b>, guaranteeing equality and fundamental rights, and founding a democratic republic, adopted 26 November 1949 and in force 26 January 1950.',
      crux='He built into the nation’s highest law the very principle denied him at birth: that <b>all citizens are equal before the law</b>.',
      conseq='The Constitution became his monument, and won him the enduring title of chief architect of the Indian republic.',
      matters='A society is remade through its laws — Ambedkar wrote his fight for equality into the permanent charter of a billion people.'),

    E('lawminister', '1947–1951', 'India’s first Law Minister — equality in statute', ['POLITICS', 'REFORM'],
      'Ambedkar joins independent India’s first cabinet as Law Minister, working to translate constitutional principle into working law and championing above all the Hindu Code Bill — a sweeping reform to give women rights to property, divorce and equality within the family, striking at social hierarchy in the home as well as the temple.',
      svg_row('From principle to statute', [
          {'n': 1, 'label': 'First Law Minister, 1947', 'sub': 'in Nehru’s independence cabinet', 'color': '#2563eb'},
          {'n': 2, 'label': 'Law to enact equality', 'sub': 'building the legal frame of the new republic', 'color': '#a16207'},
          {'n': 3, 'label': 'The Hindu Code Bill', 'sub': 'rights for women in marriage and property', 'color': '#166534'},
      ], edge_labels=['drives', 'toward'], takeaway='As Law Minister he pressed to make equality real in daily life — above all for women, through the Hindu Code Bill.', accent=AC),
      bg='Ambedkar became <b>independent India’s first Law Minister</b> in 1947, charged with building the legal architecture of the new state.',
      people='<b>Nehru</b>, the prime minister; the cabinet and Parliament; the conservatives who resisted social reform.',
      what='As Law Minister Ambedkar worked to enact the Constitution’s promises and championed the <b>Hindu Code Bill</b> — reforms granting Hindu women <b>rights to property, inheritance, marriage and divorce</b>, and equality within the family.',
      crux='He saw that legal equality had to reach into the <b>home and the family</b>, not just the public square — and that women’s rights were central to it.',
      conseq='Fierce conservative opposition would stall the Hindu Code Bill and drive him from office.',
      matters='Rights on paper mean little until they are law in daily life — Ambedkar fought to make equality enforceable, especially for women.'),

    E('resignation', '1951', 'Resignation over the Hindu Code Bill — principle over office', ['POLITICS', 'DEFEAT'],
      'When the Hindu Code Bill is stalled and gutted by conservative opposition in Parliament, Ambedkar resigns from the cabinet in protest — refusing to remain in office while the reform he considered the soul of the Constitution’s promise of equality is blocked, choosing principle over power once again.',
      svg_stack('Quitting rather than abandon reform', [
          {'n': 1, 'label': 'Hindu Code Bill blocked', 'sub': 'conservatives stall and dilute it', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Ambedkar resigns, 1951', 'sub': 'leaves the cabinet in protest', 'color': '#2563eb'},
          {'n': 3, 'label': 'Principle over office', 'sub': 'will not preside over a hollow reform', 'color': '#78350f'},
      ], takeaway='He walked out of government rather than accept the defeat of women’s equality — putting the principle above the post.', accent=AC),
      bg='The Hindu Code Bill met determined resistance from religious conservatives and was stalled and broken up in Parliament in 1951.',
      people='the conservative members who blocked the bill; Nehru’s government; Ambedkar, its frustrated champion.',
      what='When the <b>Hindu Code Bill</b> was stalled and diluted, Ambedkar <b>resigned as Law Minister in 1951</b>, unwilling to remain in a cabinet that would not enact equal rights for women.',
      crux='He treated the reform as inseparable from the Constitution’s promise, and <b>would not trade his principles for his place</b>.',
      conseq='Though he left office, versions of the reforms were later passed; his stand underscored his integrity.',
      matters='Integrity sometimes means leaving power behind — Ambedkar’s resignation showed he served the cause, not the office.'),
]

# ==================================================================  PHASE 5 — CONVERSION AND LEGACY
PHASE_END = [
    E('yeola', '1935–1956', 'The long road out of Hinduism — a search for dignity', ['REFORM', 'TURNING POINT'],
      'Having concluded that untouchables can never find equality within Hinduism, Ambedkar declares that though he was born a Hindu he will not die one — and spends two decades studying the world’s faiths before choosing Buddhism, an Indian religion of reason, compassion and equality with no caste and no god of hierarchy.',
      svg_stack('“I will not die a Hindu”', [
          {'n': 1, 'label': 'The Yeola declaration, 1935', 'sub': 'born a Hindu, but will not die one', 'color': '#2563eb'},
          {'n': 2, 'label': 'Two decades of study', 'sub': 'weighing the religions of the world', 'color': '#a16207'},
          {'n': 3, 'label': 'Choosing Buddhism', 'sub': 'reason, compassion, equality — no caste', 'color': '#7c3aed'},
      ], takeaway='Concluding Hinduism could not give the untouchables equality, he searched for twenty years and chose Buddhism — an Indian faith without caste.', accent=AC),
      bg='After decades of struggling to reform Hindu society from within, Ambedkar concluded that untouchables would never be granted equality inside it.',
      people='his untouchable followers; the scholars of many faiths he studied; the Buddhist tradition he came to embrace.',
      what='At <b>Yeola in 1935</b> Ambedkar declared that though <b>“I was born a Hindu … I will not die a Hindu”</b>, and over the next two decades studied the world’s religions before choosing <b>Buddhism</b> — a faith of reason, compassion and equality, native to India and free of caste.',
      crux='He sought a spiritual home that affirmed <b>human equality</b> and dignity rather than sanctifying hierarchy.',
      conseq='His choice set the stage for a mass conversion that would give millions a new identity.',
      matters='When a faith denies your humanity, you may seek another — Ambedkar looked for dignity and found it in the Buddha’s path.'),

    E('deekshabhoomi', '1956', 'Deekshabhoomi — half a million embrace Buddhism', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'On 14 October 1956 at Nagpur, Ambedkar formally converts to Buddhism and, in the same ceremony, administers vows to hundreds of thousands of his followers — one of the largest religious conversions in history — giving the untouchables a new faith, a new self-respect, and a decisive rejection of the caste order.',
      svg_row('A mass exodus from caste into a new faith', [
          {'n': 1, 'label': 'Nagpur, 14 October 1956', 'sub': 'Ambedkar formally embraces Buddhism', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Hundreds of thousands follow', 'sub': 'a mass conversion in a single ceremony', 'color': '#2563eb'},
          {'n': 3, 'label': 'A new identity and dignity', 'sub': 'a people reborn outside the caste order', 'color': '#166534'},
      ], edge_labels=['leads', 'into'], takeaway='In one ceremony he led hundreds of thousands out of caste and into Buddhism — an act of collective self-liberation.', accent=AC),
      bg='Having chosen Buddhism, Ambedkar prepared a mass ceremony at Nagpur, on ground since known as <b>Deekshabhoomi</b>.',
      people='the <b>hundreds of thousands</b> of untouchable followers who converted with him; the Buddhist monks who administered the rites.',
      what='On <b>14 October 1956</b> at Nagpur, Ambedkar took the vows of Buddhism and led <b>hundreds of thousands of followers</b> to convert with him — among the largest mass conversions in history — decisively rejecting the caste order.',
      crux='Conversion was both spiritual and political: a <b>collective act of self-respect</b> that removed millions from the hierarchy that had degraded them.',
      conseq='It founded the modern Navayana Buddhist movement and remains a living force among India’s Dalits.',
      matters='A people can reclaim its dignity by choosing its own identity — Ambedkar’s conversion was liberation enacted en masse.'),

    E('death', '1956–1990', 'Mahaparinirvan and legacy — the Constitution as monument', ['DEATH', 'TRIUMPH'],
      'Just weeks after the conversion, Ambedkar dies — leaving behind his final work “The Buddha and His Dhamma,” the Constitution of a republic pledged to equality, and a Dalit movement he had transformed. Decades later a grateful nation awards him its highest honour, and he is remembered as the towering champion of social justice and equality.',
      svg_stack('The reformer passes; the work endures', [
          {'n': 1, 'label': 'Death, 6 December 1956', 'sub': 'weeks after the conversion; “The Buddha and His Dhamma”', 'color': '#78350f'},
          {'n': 2, 'label': 'The Constitution as monument', 'sub': 'equality written into a republic’s law', 'color': '#2563eb'},
          {'n': 3, 'label': 'Bharat Ratna, 1990', 'sub': 'honoured as champion of social justice', 'color': '#166534'},
      ], takeaway='He died weeks after his greatest act, but his Constitution and his movement carried his fight for equality far beyond his lifetime.', accent=AC),
      bg='Ambedkar died on <b>6 December 1956</b> in Delhi, only weeks after the Nagpur conversion, having completed his last book <b>“The Buddha and His Dhamma.”</b>',
      people='the millions of Dalits who revere him as Babasaheb; independent India, which he helped found; later generations who honoured him.',
      what='Ambedkar’s death (remembered as <b>Mahaparinirvan Diwas</b>) left behind the <b>Constitution of India</b>, a mass Buddhist and anti-caste movement, and a body of scholarship; in <b>1990</b> he was posthumously awarded the <b>Bharat Ratna</b>, India’s highest civilian honour.',
      crux='His legacy is a nation whose founding law enshrines the <b>equality he was denied at birth</b> — and a people who claimed their dignity.',
      conseq='He is venerated across India as the emancipator of the Dalits and the chief architect of the republic.',
      matters='A life against injustice outlives the person — Ambedkar remains the towering symbol of India’s pledge to equality and social justice.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">B. R. Ambedkar rose from the very bottom of the caste order — born an “untouchable,” humiliated as a child — to become one of the most learned men of his age and the chief architect of the Constitution of India. Jurist, economist and reformer, he devoted his life to the annihilation of caste and the dignity of the oppressed: leading the Depressed Classes, forcing the question of untouchability onto the national stage, writing equality into a republic’s founding law, and finally leading hundreds of thousands out of Hinduism into Buddhism. He is the towering champion of <b>social justice, equality, and the human dignity of every person.</b></p>
<div class="ov-quote">“I measure the progress of a community by the degree of progress which women have achieved.”<span>— B. R. Ambedkar</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born Mahar and degraded as untouchable → educated at Columbia and London against every barrier → emerges as leader of the Depressed Classes → leads the Mahad and Kalaram satyagrahas → clashes with Gandhi over separate electorates and signs the Poona Pact → writes “Annihilation of Caste” → chairs the drafting of the Constitution and abolishes untouchability → serves as first Law Minister and resigns over the Hindu Code Bill → and converts to Buddhism with hundreds of thousands of followers shortly before his death.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⚖️</div><h4>Architect of the Constitution</h4><p>Wrote equality and the abolition of untouchability into India’s founding law.</p></div>
  <div class="ov-card"><div class="i">✊</div><h4>Champion of the Dalits</h4><p>Built a movement led by the untouchables for their own dignity and rights.</p></div>
  <div class="ov-card"><div class="i">📜</div><h4>Annihilation of caste</h4><p>Argued caste must be destroyed at its root, not merely reformed.</p></div>
  <div class="ov-card"><div class="i">☸️</div><h4>The turn to Buddhism</h4><p>Led a mass conversion to a faith of reason, compassion and equality.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Caste & Education</b><small> 1891–1923</small><p>Born untouchable; educated at Columbia and London.</p></div>
  <div><b>2 · Leader of the Depressed Classes</b><small> 1919–1930</small><p>Mooknayak, Mahad and the Kalaram temple.</p></div>
  <div><b>3 · The Great Debate</b><small> 1930–1936</small><p>Gandhi, the Poona Pact and Annihilation of Caste.</p></div>
  <div><b>4 · Architect of the Republic</b><small> 1947–1951</small><p>The Constitution, Law Minister, and resignation.</p></div>
  <div><b>5 · Conversion & Legacy</b><small> 1935–1990</small><p>Buddhism, death, and an enduring legacy.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Mahatma Gandhi', 'role': 'rival & interlocutor', 'color': '#b91c1c',
     'bio': 'The nationalist leader who opposed separate electorates for the Depressed Classes and fasted unto death, forcing the Poona Pact; he and Ambedkar clashed deeply over how to end untouchability.',
     'rel': 'The great adversary in the debate over the untouchables’ political future.'},
    {'name': 'Jawaharlal Nehru', 'role': 'prime minister', 'color': '#166534',
     'bio': 'India’s first prime minister, who brought Ambedkar into the cabinet as Law Minister and backed the drafting of the Constitution and the Hindu Code Bill.',
     'rel': 'The premier under whom he wrote the Constitution and served in government.'},
    {'name': 'John Dewey', 'role': 'teacher', 'color': '#a16207',
     'bio': 'The American philosopher of democracy and education under whom Ambedkar studied at Columbia University, shaping his ideals of equality and reasoned reform.',
     'rel': 'The mentor whose democratic philosophy shaped his thought.'},
    {'name': 'Sayajirao Gaekwad III', 'role': 'patron', 'color': '#2563eb',
     'bio': 'The reformist Maharaja of Baroda whose scholarship sent Ambedkar to study at Columbia, and who later employed him.',
     'rel': 'The patron whose scholarship opened the door to his education abroad.'},
    {'name': 'Ramji Maloji Sakpal', 'role': 'his father', 'color': '#78350f',
     'bio': 'Ambedkar’s father, a subedar in the British Indian Army who valued education and insisted his son be schooled despite the barriers of caste.',
     'rel': 'The father whose faith in education set his son on his path.'},
]

KEY_EVENTS = [
    ('1891', 'Ambedkar born', 'Into the Mahar “untouchable” caste at Mhow.'),
    ('1916', 'Columbia PhD', 'Educated under John Dewey in New York.'),
    ('1923', 'Barrister & D.Sc.', 'Called to the bar; economics doctorate in London.'),
    ('1927', 'Mahad Satyagraha', 'Claims water; burns the Manusmriti.'),
    ('1930', 'Kalaram Temple entry', 'Barred even from worship.'),
    ('1932', 'Poona Pact', 'Gandhi’s fast; reserved seats replace separate electorates.'),
    ('1936', 'Annihilation of Caste', 'Argues caste must be abolished, not reformed.'),
    ('1947', 'Chief architect & Law Minister', 'Chairs the drafting of the Constitution.'),
    ('1951', 'Resigns over Hindu Code Bill', 'Principle over office.'),
    ('1956', 'Converts to Buddhism; dies', 'Half a million follow at Nagpur.'),
]

MASTER = [
    {'year': '1891', 'age': 'born', 'phase': 'Caste & Education', 'title': 'Born untouchable', 'desc': 'Into the Mahar caste at Mhow.'},
    {'year': '1916', 'age': 'age 25', 'phase': 'Caste & Education', 'title': 'Columbia PhD', 'desc': 'Educated under John Dewey.'},
    {'year': '1927', 'age': 'age 36', 'phase': 'Depressed Classes', 'title': 'Mahad Satyagraha', 'desc': 'Water, and the Manusmriti burned.'},
    {'year': '1932', 'age': 'age 41', 'phase': 'The Great Debate', 'title': 'Poona Pact', 'desc': 'Compromise under Gandhi’s fast.'},
    {'year': '1949', 'age': 'age 58', 'phase': 'Architect of the Republic', 'title': 'Constitution adopted', 'desc': 'Untouchability abolished in law.'},
    {'year': '1956', 'age': 'age 65', 'phase': 'Conversion & Legacy', 'title': 'Buddhism & death', 'desc': 'A mass conversion; then his passing.'},
]

SOURCES = [
    ('Britannica — B. R. Ambedkar', 'https://www.britannica.com/biography/B-R-Ambedkar'),
    ('Wikipedia — B. R. Ambedkar', 'https://en.wikipedia.org/wiki/B._R._Ambedkar'),
    ('Wikipedia — Poona Pact', 'https://en.wikipedia.org/wiki/Poona_Pact'),
    ('Wikipedia — Mahad Satyagraha', 'https://en.wikipedia.org/wiki/Mahad_Satyagraha'),
    ('Wikipedia — Annihilation of Caste', 'https://en.wikipedia.org/wiki/Annihilation_of_Caste'),
]

def build_meta():
    return {
        'pid': 'gm-ambedkar.html', 'kind': 'man', 'emoji': '⚖️', 'accent': AC,
        'name': 'B. R. Ambedkar', 'years': '1891–1956', 'group': 'Independence & Nation-Building',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The jurist and reformer who rose from “untouchability” to become chief architect of the Constitution of India — champion of the Dalits, foe of caste, and, at the last, a leader of hundreds of thousands into Buddhism.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · Caste & Education', 'type': 'timeline',
             'intro': 'Born an untouchable and humiliated as a child, Ambedkar wins scholarships to Columbia and London, becoming one of the most highly educated Indians of his generation.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · Leader of the Depressed Classes', 'type': 'timeline',
             'intro': 'He emerges as the foremost leader of the untouchables, building a movement of their own and leading the Mahad and Kalaram satyagrahas against exclusion from water and worship.', 'events': PHASE_POWER},
            {'id': 'order', 'label': '3 · The Great Debate', 'type': 'timeline',
             'intro': 'On the national stage he demands separate electorates, clashes with Gandhi and signs the Poona Pact, and publishes his blistering case for the annihilation of caste.', 'events': PHASE_ORDER},
            {'id': 'repression', 'label': '4 · Architect of the Republic', 'type': 'timeline',
             'intro': 'At independence the once-untouchable becomes chief architect of the Constitution and first Law Minister — abolishing untouchability in law, then resigning over the Hindu Code Bill.', 'events': PHASE_REPRESSION},
            {'id': 'end', 'label': '5 · Conversion & Legacy', 'type': 'timeline',
             'intro': 'Concluding that Hinduism cannot give the untouchables equality, Ambedkar leads hundreds of thousands into Buddhism at Nagpur, dying weeks later and leaving the Constitution as his monument.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; dates and quotations follow widely cited records of Ambedkar’s life and writings.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
