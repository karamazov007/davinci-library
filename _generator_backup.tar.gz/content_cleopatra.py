# -*- coding: utf-8 -*-
"""Full, DEEP birth-to-death guide content for Cleopatra VII.
The last pharaoh of Egypt — brilliant ruler, not merely the seductress of Roman legend."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#0e7490'  # Nile teal

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE THRONE
PHASE_RISE = [
    E('ptolemies', '305–69 BC', 'A Greek dynasty on Egypt’s throne', ['RISE', 'POLITICS'],
      'Cleopatra is not Egyptian by blood but Greek — the last of the Ptolemies, a dynasty founded by one of Alexander’s generals that has ruled Egypt for 250 years, grown decadent and murderous, and now survives only at Rome’s sufferance.',
      svg_row('An old dynasty in Rome’s shadow', [
          {'n': 1, 'label': 'Founded by Ptolemy, 305 BC', 'sub': 'one of Alexander’s generals seizes Egypt', 'color': '#0e7490'},
          {'n': 2, 'label': 'Greek, incestuous, declining', 'sub': 'sibling marriages and murders weaken the line', 'color': '#a16207'},
          {'n': 3, 'label': 'Dependent on Rome', 'sub': 'Egypt survives only by Roman favour', 'color': '#b91c1c'},
      ], edge_labels=['becomes', 'and'], takeaway='She inherited a rich but fragile kingdom that lived or died by Rome’s goodwill.', accent=AC),
      bg='The <b>Ptolemaic dynasty</b>, Greek-Macedonian rulers descended from one of Alexander’s generals, had governed Egypt since 305 BC — by Cleopatra’s time enfeebled by feuds and reliant on Rome.',
      people='the Ptolemaic royal house; her father <b>Ptolemy XII</b>, who bought Roman support with bribes; the rising power of Rome.',
      what='By the 1st century BC, Egypt was <b>immensely rich but politically weak</b>, its throne wracked by fratricide and its independence propped up only by Roman patronage.',
      crux='Cleopatra inherited a kingdom whose <b>survival depended on managing Rome</b> — the central problem of her entire reign.',
      conseq='Her whole strategy — alliance with Rome’s most powerful men — flowed from this inherited weakness.',
      matters='Rulers are shaped by the strategic situation they inherit — Cleopatra’s was a rich prize living on borrowed time.'),

    E('education', '69–51 BC', 'The most educated queen of the age', ['RISE', 'REFORM'],
      'Far from the seductress of legend, Cleopatra is formidably intelligent — reputedly fluent in perhaps nine languages, the first of her Greek dynasty to bother learning Egyptian, and trained in the sciences and statecraft of Alexandria, the intellectual capital of the world.',
      svg_stack('A mind, not merely a face', [
          {'n': 1, 'label': 'Educated at Alexandria', 'sub': 'the great library and museum, the world’s learning centre', 'color': '#0e7490'},
          {'n': 2, 'label': 'Many languages', 'sub': 'reportedly ~9, incl. Egyptian — a first for her dynasty', 'color': '#a16207'},
          {'n': 3, 'label': 'Trained in statecraft', 'sub': 'politics, economics, science and rhetoric', 'color': '#166534'},
      ], takeaway='Her real weapon was a first-class mind — the “seductress” image is largely hostile Roman propaganda.', accent=AC),
      bg='Cleopatra grew up in <b>Alexandria</b>, home to the ancient world’s greatest library and a hub of Greek learning, and was exceptionally educated even by royal standards.',
      people='the scholars of the Museum of Alexandria; her tutors; the Egyptian priests whose language and gods she, uniquely, embraced.',
      what='Ancient writers credit Cleopatra with <b>fluency in many languages</b> (perhaps nine), including <b>Egyptian</b> — which no earlier Ptolemy had learned — and with sharp skill in politics, finance and persuasion.',
      crux='Her power rested on <b>intelligence and charm of conversation</b>, not mere beauty — even hostile sources stress her wit and voice over her looks.',
      conseq='This shrewdness let her out-manoeuvre rivals and win the two most powerful Romans of the age as allies.',
      matters='History’s image of a woman is often reduced to her looks — the record shows Cleopatra ruled by brains.'),

    E('accession', '51 BC', 'Queen at eighteen — sharing a throne she means to hold', ['POLITICS', 'TURNING POINT'],
      'On her father’s death Cleopatra becomes co-ruler with her much younger brother Ptolemy XIII, whom, by custom, she is also married to — but she has no intention of being a puppet, and quickly asserts herself as the real power, provoking her brother’s handlers.',
      svg_row('A shared crown she wants for herself', [
          {'n': 1, 'label': 'Co-ruler with Ptolemy XIII', 'sub': 'married to and reigning with her young brother', 'color': '#0e7490'},
          {'n': 2, 'label': 'She asserts real power', 'sub': 'rules in her own name, sidelining the boy', 'color': '#a16207'},
          {'n': 3, 'label': 'His court fights back', 'sub': 'the boy-king’s advisers move against her', 'color': '#b91c1c'},
      ], edge_labels=['then', 'so'], takeaway='She refused to be a figurehead — and her ambition set off the struggle that defined her early reign.', accent=AC),
      bg='Ptolemaic custom paired brother and sister as joint monarchs. In 51 BC the 18-year-old Cleopatra became co-ruler with her brother <b>Ptolemy XIII</b>, then about ten.',
      people='<b>Ptolemy XIII</b>, her boy co-ruler and husband; his powerful advisers, chiefly the eunuch <b>Pothinus</b>; the Alexandrian court.',
      what='Cleopatra <b>ruled in her own right</b>, even dropping her brother from official documents — provoking <b>Pothinus and the court</b>, who rallied around the boy-king against her.',
      crux='She was determined to be a <b>real monarch, not a co-regent’s puppet</b> — an assertiveness that started a civil war.',
      conseq='By 48 BC the court had driven her from Alexandria, and she was raising an army to fight her way back.',
      matters='The refusal to be a figurehead is the first act of a real ruler — but it invites the fight for power to begin.'),

    E('exile', '49–48 BC', 'Driven out — and refusing to stay out', ['POLITICS', 'BATTLE'],
      'Ousted by her brother’s faction, Cleopatra does not submit but withdraws to raise her own army on Egypt’s borders — demonstrating the ruthless resolve that will mark her whole career — just as the Roman civil war between Caesar and Pompey crashes into Egypt.',
      svg_stack('Down, but not out', [
          {'n': 1, 'label': 'Ousted by Pothinus’s faction', 'sub': 'driven from Alexandria by her brother’s court', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Raises her own army', 'sub': 'withdraws to the frontier and gathers forces', 'color': '#0e7490'},
          {'n': 3, 'label': 'Rome’s civil war arrives', 'sub': 'Caesar and Pompey’s struggle spills into Egypt', 'color': '#a16207'},
      ], takeaway='She met defeat with defiance — and stood ready when Rome’s civil war handed her an opening.', accent=AC),
      bg='By 48 BC Cleopatra had been forced out of Alexandria. Meanwhile the Roman civil war between <b>Julius Caesar</b> and <b>Pompey</b> was reaching its climax.',
      people='<b>Pothinus</b> and Ptolemy XIII’s court; Cleopatra, gathering an army; the Roman rivals <b>Caesar</b> and <b>Pompey</b>, about to enter Egypt’s story.',
      what='Rather than accept exile, Cleopatra <b>raised troops on the frontier</b> to reclaim her throne — and events in Rome soon offered her a far greater opportunity than any army.',
      crux='She treated defeat as <b>temporary</b>, positioning herself to exploit whatever opening appeared — and Rome’s war provided it.',
      conseq='When Pompey fled to Egypt and Caesar pursued, Cleopatra saw her chance to win back power with Roman help.',
      matters='Resilience creates opportunity — those who refuse to accept defeat are placed to seize the next opening.'),
]

# ==================================================================  PHASE 2 — CAESAR
PHASE_CAESAR = [
    E('pompey', '48 BC', 'A severed head — the fatal miscalculation', ['POLITICS', 'TRAGEDY', 'TURNING POINT'],
      'Cleopatra’s brother tries to win Caesar’s favour by murdering the fleeing Pompey and presenting his head — but the gift horrifies rather than pleases Caesar, and hands Cleopatra a priceless opening to court the Roman on her own terms.',
      svg_stack('A gift that backfired', [
          {'n': 1, 'label': 'Pompey flees to Egypt', 'sub': 'beaten by Caesar, he seeks refuge', 'color': '#a16207'},
          {'n': 2, 'label': 'Ptolemy has him killed', 'sub': 'murders Pompey to court Caesar’s favour', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Caesar is disgusted', 'sub': 'the crude murder repels him — opening a door for Cleopatra', 'color': '#0e7490'},
      ], takeaway='Her brother’s brutal blunder gave Cleopatra the chance to present herself as the wiser partner for Rome.', accent=AC),
      bg='After losing to Caesar at Pharsalus, <b>Pompey</b> fled to Egypt seeking sanctuary. Ptolemy XIII’s advisers saw a chance to ingratiate themselves with the victorious Caesar.',
      people='<b>Pompey</b>, murdered on landing; <b>Ptolemy XIII</b> and <b>Pothinus</b>, who ordered it; <b>Caesar</b>, arriving in pursuit.',
      what='Ptolemy’s men <b>killed Pompey and presented his severed head</b> to Caesar — who was reportedly <b>appalled</b> rather than gratified, turning him against Ptolemy’s faction.',
      crux='The murder revealed the boy-king’s court as <b>crude and untrustworthy</b>, while creating the moment for Cleopatra to make her move.',
      conseq='With Caesar now in Alexandria and alienated from her brother, Cleopatra resolved to reach him directly.',
      matters='A rival’s clumsy miscalculation can be your greatest opening — the wise exploit others’ blunders.'),

    E('carpet', '48 BC', 'Smuggled to Caesar', ['POLITICS', 'LOVE', 'TURNING POINT'],
      'Barred from the palace, Cleopatra has herself smuggled past her brother’s guards to Caesar — famously wrapped in a bundle of bedding — and in a single audacious meeting wins the most powerful man in the world as her ally and lover.',
      svg_row('One bold gamble for everything', [
          {'n': 1, 'label': 'Locked out of Alexandria', 'sub': 'her brother’s troops bar her return', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Smuggled in to Caesar', 'sub': 'carried past the guards, hidden in a bedroll', 'color': '#0e7490'},
          {'n': 3, 'label': 'Wins Caesar’s support', 'sub': 'charms and persuades him to back her claim', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='She staked everything on a single daring meeting — and won Rome’s master to her side.', accent=AC),
      bg='Unable to enter the palace openly with her brother’s forces in control, Cleopatra needed to reach <b>Caesar</b> in person to plead her cause.',
      people='<b>Julius Caesar</b>, then in Alexandria; the servant (traditionally Apollodorus) who smuggled her in; her brother’s watchful guards.',
      what='Cleopatra had herself <b>secretly carried into Caesar’s presence</b> — by legend rolled in bedding or a carpet — and in that meeting <b>won him as ally and lover</b>, becoming his partner in the war for her throne.',
      crux='She combined <b>audacity, intelligence and charm</b> to turn a desperate position into an alliance with the most powerful man alive.',
      conseq='Caesar backed her against Ptolemy XIII, plunging Alexandria into war.',
      matters='Fortune favours the audacious — a single bold, well-judged gamble can change everything.'),

    E('war', '48–47 BC', 'The Alexandrian War — restored to the throne', ['BATTLE', 'TRIUMPH'],
      'Caesar and Cleopatra are besieged in Alexandria by her brother’s army in a hard-fought war — during which the famous library district is damaged by fire — until reinforcements arrive, Ptolemy XIII drowns in flight, and Cleopatra is secured on the throne.',
      svg_stack('Winning the throne by war', [
          {'n': 1, 'label': 'Besieged in Alexandria', 'sub': 'Caesar and Cleopatra trapped by Ptolemy’s forces', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Fire and hard fighting', 'sub': 'the harbour and library district damaged by flames', 'color': '#a16207'},
          {'n': 3, 'label': 'Ptolemy drowns; Cleopatra restored', 'sub': 'reinforcements win the war; her rival dies fleeing', 'color': '#0e7490'},
      ], takeaway='With Caesar’s backing she won the civil war and secured the crown she had been denied.', accent=AC),
      bg='Caesar’s support for Cleopatra triggered the <b>Alexandrian War</b> against Ptolemy XIII’s forces, with Caesar’s smaller army besieged in the city.',
      people='<b>Caesar</b>; <b>Cleopatra</b>; <b>Ptolemy XIII</b>, who drowned in the Nile fleeing defeat; the relieving Roman forces.',
      what='After months of fighting — during which fire <b>damaged part of the great Library’s district</b> — reinforcements broke the siege. <b>Ptolemy XIII drowned</b> in flight, and Cleopatra was <b>restored as queen</b>, now with a compliant younger brother as co-ruler.',
      crux='Roman military power <b>secured her throne</b> — the alliance with Caesar paid off decisively.',
      conseq='Cleopatra was now the unchallenged ruler of Egypt, bound to Caesar and soon to bear his child.',
      matters='An alliance with overwhelming power can win what one’s own strength cannot — but it also creates dependence.'),

    E('caesarion', '47–44 BC', 'A son by Caesar — and a queen in Rome', ['POLITICS', 'LOVE', 'TURNING POINT'],
      'Cleopatra bears Caesar a son, Caesarion, cruises the Nile with him, and follows him to Rome as his royal guest and mistress — a scandalous, ambitious bid to bind Egypt to Caesar’s line — until Caesar’s assassination shatters everything.',
      svg_row('Binding Egypt to Rome by blood', [
          {'n': 1, 'label': 'Bears Caesarion, 47 BC', 'sub': 'a son she names as Caesar’s child', 'color': '#0e7490'},
          {'n': 2, 'label': 'A queen in Rome', 'sub': 'lives openly as Caesar’s royal guest and mistress', 'color': '#a16207'},
          {'n': 3, 'label': 'Caesar assassinated, 44 BC', 'sub': 'his murder wrecks her strategy overnight', 'color': '#b91c1c'},
      ], edge_labels=['then', 'until'], takeaway='She tried to fuse her dynasty with Caesar’s — a bold plan the Ides of March destroyed.', accent=AC),
      bg='Cleopatra’s relationship with Caesar produced a son, <b>Caesarion</b>, whom she presented as Caesar’s — a potential bridge between Egypt and Rome’s most powerful man.',
      people='<b>Caesar</b>; their son <b>Caesarion</b> (Ptolemy XV); the Roman elite, scandalised by the foreign queen in their city.',
      what='Cleopatra bore <b>Caesarion</b> (47 BC), reportedly cruised the Nile with Caesar, and stayed in <b>Rome as his guest and mistress</b> — a bold, controversial bid for status and dynastic union, ended by <b>Caesar’s assassination</b> in 44 BC.',
      crux='She aimed to <b>tie Egypt’s future to Caesar’s bloodline</b> — a far-sighted gamble that collapsed with his murder.',
      conseq='After the Ides of March she returned to Egypt to secure her throne amid the new Roman power struggle.',
      matters='Strategies built around one powerful patron are fragile — when the patron falls, the whole plan can fall with him.'),
]

# ==================================================================  PHASE 3 — ANTONY
PHASE_ANTONY = [
    E('secure', '44–41 BC', 'Securing the throne — by any means', ['POLITICS', 'TRAGEDY'],
      'Back in Egypt after Caesar’s death, Cleopatra ruthlessly secures her position — eliminating her remaining sibling rivals, elevating her son Caesarion as co-ruler — and watches the Roman world split, waiting to see which faction she must court next.',
      svg_stack('Ruthless consolidation', [
          {'n': 1, 'label': 'Returns to Egypt', 'sub': 'after Caesar’s murder, secures her rule', 'color': '#0e7490'},
          {'n': 2, 'label': 'Rivals eliminated', 'sub': 'her sister Arsinoe and others removed', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Caesarion made co-ruler', 'sub': 'her son elevated as heir and partner', 'color': '#a16207'},
      ], takeaway='She showed a Ptolemy’s ruthlessness in securing power — then waited to back the winning Roman.', accent=AC),
      bg='With Caesar dead, Rome fractured between his heirs (Octavian, Antony) and his assassins. Cleopatra needed to secure Egypt and pick a side.',
      people='her son <b>Caesarion</b>, made co-ruler; her sister <b>Arsinoe</b> and other rivals, eliminated; the contending Roman factions.',
      what='Cleopatra <b>consolidated her throne</b>, is said to have had her surviving sibling rivals killed, and raised <b>Caesarion</b> as co-ruler — positioning herself and Egypt to align with whichever Roman faction prevailed.',
      crux='She acted with <b>dynastic ruthlessness</b> to remove threats and clarify the succession before choosing her next Roman ally.',
      conseq='When the Caesarian leader Mark Antony summoned her, she prepared to make her most famous entrance.',
      matters='Securing the home base comes first — a ruler cannot play the wider game until the throne is safe.'),

    E('tarsus', '41 BC', 'The barge at Tarsus — captivating Antony', ['POLITICS', 'LOVE', 'TURNING POINT'],
      'Summoned by Mark Antony to explain herself, Cleopatra instead stages one of history’s great theatrical entrances — sailing up to Tarsus on a gilded barge dressed as the goddess Aphrodite — turning an interrogation into a seduction and winning Rome’s eastern master as her new ally.',
      svg_row('An entrance as strategy', [
          {'n': 1, 'label': 'Summoned to answer to Antony', 'sub': 'called to Tarsus to explain her loyalties', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Arrives as Aphrodite', 'sub': 'a gilded barge, purple sails, staged as a goddess', 'color': '#0e7490'},
          {'n': 3, 'label': 'Wins Antony', 'sub': 'turns judgement into alliance and romance', 'color': '#166534'},
      ], edge_labels=['answered by', 'yields'], takeaway='She turned a summons into a spectacle — political theatre that captured her next Roman patron.', accent=AC),
      bg='<b>Mark Antony</b>, now master of Rome’s eastern provinces, summoned Cleopatra to <b>Tarsus</b> to answer questions about her loyalties in the civil wars.',
      people='<b>Mark Antony</b>; Cleopatra, staging her arrival; the crowds who watched her legendary entrance.',
      what='Cleopatra sailed to Tarsus on a <b>lavishly gilded barge</b>, costumed as the goddess <b>Aphrodite/Isis</b>, and so dazzled Antony that the meeting became the start of a <b>political and romantic alliance</b>.',
      crux='She understood the <b>power of spectacle and image</b> — turning a potentially hostile summons into a triumph of persuasion.',
      conseq='Antony followed her to Egypt; their alliance would dominate — and ultimately doom — them both.',
      matters='Image and theatre are instruments of power — a masterful performance can reverse a position of weakness.'),

    E('alliance', '41–34 BC', 'Antony and Cleopatra — power and partnership', ['POLITICS', 'LOVE'],
      'Antony and Cleopatra become partners in every sense — lovers, parents of three children, and political allies pooling Rome’s eastern legions with Egypt’s bottomless wealth — a union that makes them the dominant power of the eastern Mediterranean.',
      svg_stack('Legions plus treasure', [
          {'n': 1, 'label': 'Personal partnership', 'sub': 'lovers and parents of three children', 'color': '#0e7490'},
          {'n': 2, 'label': 'Egypt’s wealth funds Antony', 'sub': 'her treasury backs his armies and ambitions', 'color': '#a16207'},
          {'n': 3, 'label': 'Masters of the East', 'sub': 'together they dominate the eastern Mediterranean', 'color': '#166534'},
      ], takeaway='Each supplied what the other lacked — his armies, her money — making them the great power of the East.', accent=AC),
      bg='After Tarsus, Antony and Cleopatra formed a deep alliance. He needed Egypt’s wealth for his wars (notably against Parthia); she needed his power to secure her throne and expand.',
      people='<b>Mark Antony</b>; Cleopatra; their children, including the twins <b>Alexander Helios</b> and <b>Cleopatra Selene</b>.',
      what='Antony and Cleopatra became <b>political and personal partners</b>, combining <b>Rome’s eastern legions with Egypt’s wealth</b>, and had three children — a formidable power bloc based in Alexandria.',
      crux='Their union was a <b>marriage of resources</b> as much as romance — mutual need bound them as tightly as affection.',
      conseq='Their growing power and Antony’s favouring of Cleopatra alarmed Rome — especially his rival Octavian.',
      matters='The strongest alliances combine complementary strengths — but a power bloc that threatens others invites their coalition against it.'),

    E('donations', '34 BC', 'The Donations of Alexandria — a fatal flourish', ['POLITICS', 'TURNING POINT'],
      'In a grand ceremony Antony parcels out Roman eastern territories to Cleopatra and their children as kings and queens — a display of eastern monarchy that hands Octavian the perfect propaganda: proof that Antony has betrayed Rome for a foreign queen.',
      svg_row('Splendour that became a weapon against them', [
          {'n': 1, 'label': 'The Donations, 34 BC', 'sub': 'Antony grants Roman lands to Cleopatra’s children', 'color': '#0e7490'},
          {'n': 2, 'label': 'Kings and queens proclaimed', 'sub': 'the children crowned over eastern realms', 'color': '#a16207'},
          {'n': 3, 'label': 'Octavian’s propaganda gift', 'sub': 'proof, to Rome, of betrayal for a foreign queen', 'color': '#b91c1c'},
      ], edge_labels=['then', 'becomes'], takeaway='Their grandest display of power became the very evidence used to destroy them.', accent=AC),
      bg='In 34 BC Antony staged the <b>Donations of Alexandria</b>, publicly assigning Roman-controlled eastern territories to Cleopatra and their children.',
      people='<b>Antony</b> and <b>Cleopatra</b>; their children, crowned as monarchs; <b>Octavian</b>, who exploited the spectacle in Rome.',
      what='At the <b>Donations of Alexandria</b>, Antony proclaimed <b>Cleopatra and her children rulers</b> of various eastern lands, including granting Caesarion status as Caesar’s true son — an ostentatious act Octavian used to brand Antony a traitor to Rome.',
      crux='The ceremony projected <b>eastern royal power</b> in a way that horrified Roman opinion — a political miscalculation of image.',
      conseq='It gave Octavian the material to turn Rome and Italy decisively against Antony and Cleopatra.',
      matters='A display of power in one context can be poison in another — image misjudged for the audience can be fatal.'),
]

# ==================================================================  PHASE 4 — THE FALL
PHASE_FALL = [
    E('propaganda', '33–31 BC', 'Rome’s war on the “foreign queen”', ['POLITICS', 'TRAGEDY', 'TURNING POINT'],
      'Octavian wages a brilliant propaganda campaign that makes Cleopatra the villain — a scheming eastern seductress who has enslaved a great Roman and means to rule Rome from Egypt — and declares war on her, not on Antony, uniting Italy against them.',
      svg_stack('Made the face of the enemy', [
          {'n': 1, 'label': 'Cast as the seductress', 'sub': 'blamed for bewitching and unmanning Antony', 'color': '#b91c1c'},
          {'n': 2, 'label': 'War declared on Cleopatra', 'sub': 'framed as Rome vs a foreign queen, not civil war', 'color': '#a16207'},
          {'n': 3, 'label': 'Italy unites against her', 'sub': 'Octavian rallies Rome behind himself', 'color': '#0e7490'},
      ], takeaway='Much of the “Cleopatra” of legend is Octavian’s propaganda — the villain he needed for his war.', accent=AC),
      bg='To justify a new civil war, <b>Octavian</b> made Cleopatra the enemy — the foreign temptress corrupting a noble Roman — and declared war on Egypt rather than on Antony directly.',
      people='<b>Octavian</b>, the propagandist; <b>Antony</b>, painted as her slave; Cleopatra, cast as the scheming villain.',
      what='Octavian’s campaign portrayed Cleopatra as a <b>dangerous foreign seductress</b> bent on ruling Rome, and he <b>declared war on her</b> — a masterstroke that turned a civil war into a patriotic one and shaped her hostile image for millennia.',
      crux='Her <b>reputation was destroyed by the winner’s propaganda</b> — the enduring “Cleopatra” is largely his creation, not the historical ruler.',
      conseq='With Italy behind him, Octavian moved to the decisive military confrontation at Actium.',
      matters='History is written by victors — the reputations of the defeated are often their enemies’ inventions.'),

    E('actium', '31 BC', 'Actium — the day it was lost', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'At the great naval battle of Actium, Antony and Cleopatra’s fleet is trapped and beaten by Octavian’s admiral Agrippa; Cleopatra’s squadron breaks out and sails for Egypt, Antony follows, and their cause — and the independence of Egypt — is effectively finished.',
      svg_stack('The battle that decided everything', [
          {'n': 1, 'label': 'Fleet trapped at Actium', 'sub': 'Agrippa blockades and outmanoeuvres them', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Cleopatra breaks for Egypt', 'sub': 'her squadron escapes the trap; Antony follows', 'color': '#0e7490'},
          {'n': 3, 'label': 'The cause collapses', 'sub': 'their power and Egypt’s freedom effectively end', 'color': '#a16207'},
      ], takeaway='Actium doomed them — after it, only the manner of the end remained to be decided.', accent=AC),
      bg='In 31 BC the fleets met near <b>Actium</b> in Greece, where Octavian’s admiral <b>Agrippa</b> had cornered Antony and Cleopatra’s ships.',
      people='<b>Agrippa</b>, the winning admiral; <b>Antony</b> and <b>Cleopatra</b>, who fled; <b>Octavian</b>, now unchallenged.',
      what='At the <b>naval Battle of Actium</b>, Antony and Cleopatra were defeated; her squadron <b>broke out and fled to Egypt</b>, Antony following, and their remaining forces melted away.',
      crux='The defeat left them <b>without the power to resist</b> Octavian — Egypt’s last stand for independence had failed.',
      conseq='Octavian pursued them to Egypt; within a year both were dead.',
      matters='A single decisive defeat can seal a fate — after Actium, only the ending remained to be written.'),

    E('death', '30 BC', 'The asp — death on her own terms', ['DEATH', 'TRAGEDY', 'TURNING POINT'],
      'With Octavian closing in and Antony dead by his own hand, Cleopatra refuses to be paraded through Rome as a trophy — and takes her own life, by tradition with the bite of an asp, dying a queen rather than living as a captive.',
      svg_stack('The last act of a sovereign', [
          {'n': 1, 'label': 'Antony’s suicide', 'sub': 'believing her dead, Antony takes his own life', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Refuses to be a trophy', 'sub': 'will not be paraded through Rome in triumph', 'color': '#0e7490'},
          {'n': 3, 'label': 'Dies by her own hand', 'sub': 'by tradition, the bite of an asp — a queen’s death', 'color': '#111827'},
      ], takeaway='Denied victory, she seized control of the one thing left — the manner of her own death.', accent=AC),
      bg='After Actium, Octavian invaded Egypt. <b>Antony</b>, wrongly believing Cleopatra dead, killed himself; Octavian wanted Cleopatra alive to display in his triumph.',
      people='<b>Antony</b>, dead by suicide; <b>Octavian</b>, who sought her as a captive; Cleopatra, choosing her own end.',
      what='Rather than be led through Rome as a captive, Cleopatra <b>took her own life</b> in 30 BC — by tradition using the venom of an <b>asp</b> (the exact means is uncertain) — dying as a sovereign, not a prisoner.',
      crux='In defeat she claimed her <b>final sovereignty — over her own death</b> — denying Octavian his prize.',
      conseq='Her son <b>Caesarion</b> was killed; Egypt was annexed by Rome, ending 3,000 years of pharaohs.',
      matters='When everything else is lost, the manner of one’s end can be the last assertion of dignity and control.'),
]

# ==================================================================  PHASE 5 — LEGACY
PHASE_LEGACY = [
    E('endofegypt', '30 BC', 'The last pharaoh — Egypt becomes Roman', ['POLITICS', 'TRAGEDY', 'TURNING POINT'],
      'With Cleopatra’s death and Caesarion’s murder, the Ptolemaic dynasty ends and Egypt — the last great independent kingdom of the Mediterranean — is swallowed as the personal property of Rome’s new master, closing three thousand years of pharaonic history.',
      svg_row('The end of an age', [
          {'n': 1, 'label': 'Caesarion killed', 'sub': 'Caesar’s son eliminated as a rival claim', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Egypt annexed by Rome', 'sub': 'made Octavian’s personal domain', 'color': '#0e7490'},
          {'n': 3, 'label': '3,000 years of pharaohs end', 'sub': 'Cleopatra is the last', 'color': '#a16207'},
      ], edge_labels=['then', 'and'], takeaway='She was the last pharaoh — her fall ended both a dynasty and an ancient civilisation’s independence.', accent=AC),
      bg='Cleopatra’s death removed the last obstacle to Rome’s absorption of Egypt, the richest kingdom of the Mediterranean.',
      people='<b>Caesarion</b>, killed on Octavian’s orders; <b>Octavian</b> (soon Augustus), Egypt’s new master; the people of Egypt.',
      what='Octavian had <b>Caesarion killed</b> and <b>annexed Egypt</b> as his personal possession, ending the <b>Ptolemaic dynasty</b> and, with it, some <b>3,000 years</b> of independent pharaonic Egypt. Its grain and treasure became the foundation of the new Roman Empire.',
      crux='Her defeat marked a <b>historical turning point</b> — the final absorption of the ancient Near East into Rome.',
      conseq='Egypt’s wealth helped bankroll Augustus’s new order; Cleopatra passed into legend.',
      matters='The fall of one determined ruler can close an entire epoch — Cleopatra’s death ended the age of the pharaohs.'),

    E('legend', '30 BC – today', 'The two Cleopatras — legend versus record', ['POLITICS', 'REFORM'],
      'For two thousand years Cleopatra has been remembered mainly as a seductress — a hostile image crafted by her Roman enemies — while the historical woman was a shrewd, multilingual ruler who governed a great kingdom and nearly bent Rome to her purposes.',
      svg_compare('Two images of one queen',
        {'head': 'The legend', 'color': '#b91c1c', 'items': ['scheming seductress', 'ruled by her looks', 'foreign temptress who ruined great men']},
        {'head': 'The record', 'color': '#0e7490', 'items': ['multilingual, highly educated ruler', 'shrewd politician and administrator', 'nearly tied Egypt to Rome’s masters']},
        'The famous seductress is largely her enemies’ propaganda; the real Cleopatra ruled by intellect.',
        'Judge her by what she did — govern a kingdom and out-think Rome’s leaders — not by the legend.', AC),
      bg='Almost all our sources on Cleopatra are <b>Roman and hostile</b>, shaped by Octavian’s propaganda and later retellings that emphasised romance over statecraft.',
      people='the Roman writers (and later Shakespeare and Hollywood) who shaped her image; the historians now reclaiming the real ruler.',
      what='The <b>popular “Cleopatra”</b> — a beautiful seductress — is largely a <b>construction of hostile Roman propaganda</b> and later art. The historical Cleopatra was a <b>capable, learned monarch</b> who ruled Egypt for over two decades and allied with Rome’s two greatest men on near-equal terms.',
      crux='Her true achievement — <b>governing a great kingdom and nearly steering Rome</b> — was buried under a legend of seduction.',
      conseq='Modern scholarship increasingly recovers the shrewd stateswoman behind the myth.',
      matters='How we remember historical women is often distorted — recovering the record means looking past the legend to the deeds.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Cleopatra VII was the last pharaoh of Egypt — and far more than the seductress of legend. A brilliant, multilingual ruler of a rich but fragile kingdom, she won the two most powerful Romans of her age, Julius Caesar and Mark Antony, as allies and lovers in a decades-long bid to preserve Egypt’s independence and her dynasty — a gamble that ended at Actium and with an asp. She is the ultimate study in <b>ruling from weakness by intelligence and alliance, the power of image, and how the losers of history are remembered by their enemies.</b></p>
<div class="ov-quote">“I will not be triumphed over.”<span>— attributed to Cleopatra, refusing to be paraded in Rome</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Last of a Greek dynasty ruling Egypt at Rome’s mercy → a brilliant, educated queen at 18 → ousted, she smuggles herself to Caesar and wins him → restored by war, bears his son → after Caesar’s murder, secures her throne and wins Antony at Tarsus → their power bloc alarms Rome → Octavian’s propaganda makes her the villain → defeat at Actium → she dies a queen by her own hand → Egypt becomes Roman, and legend buries the real ruler.</p>
<div class="ov-lbl">Why she still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">👑</div><h4>The last pharaoh</h4><p>Her fall ended 3,000 years of independent Egypt and the Ptolemaic dynasty.</p></div>
  <div class="ov-card"><div class="i">🧠</div><h4>Ruling by intellect</h4><p>Multilingual and shrewd, she governed and negotiated on near-equal terms with Rome.</p></div>
  <div class="ov-card"><div class="i">🎭</div><h4>The power of image</h4><p>From the barge at Tarsus to her final death, she mastered political theatre.</p></div>
  <div class="ov-card"><div class="i">📜</div><h4>Written by her enemies</h4><p>Her seductress legend is Roman propaganda — a lesson in how the defeated are remembered.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Throne</b><small> 69–48 BC</small><p>A Greek dynasty, a brilliant queen, and a fight for power.</p></div>
  <div><b>2 · Caesar</b><small> 48–44 BC</small><p>Smuggled to Caesar, restored by war, a son and a scandal.</p></div>
  <div><b>3 · Antony</b><small> 41–34 BC</small><p>Tarsus, partnership, and the Donations of Alexandria.</p></div>
  <div><b>4 · The Fall</b><small> 33–30 BC</small><p>Propaganda, Actium, and death on her own terms.</p></div>
  <div><b>5 · Legacy</b><small> 30 BC – today</small><p>The end of Egypt, and legend versus the record.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Julius Caesar', 'role': 'ally and lover', 'color': '#854d0e',
     'bio': 'The Roman dictator who backed Cleopatra against her brother, restored her to the throne, and fathered her son Caesarion.',
     'rel': 'The first Roman patron who secured her crown.'},
    {'name': 'Mark Antony', 'role': 'ally and lover', 'color': '#b91c1c',
     'bio': 'The Roman master of the East who allied with and married Cleopatra, pooled his legions with Egypt’s wealth, and fell with her at Actium.',
     'rel': 'Her partner in power — and in ruin.'},
    {'name': 'Octavian (Augustus)', 'role': 'nemesis', 'color': '#0e7490',
     'bio': 'Caesar’s heir, who destroyed Antony and Cleopatra through propaganda and at Actium, annexed Egypt, and shaped her hostile legend.',
     'rel': 'The rival who defeated her and wrote her villainous image.'},
    {'name': 'Ptolemy XIII', 'role': 'brother and rival', 'color': '#a16207',
     'bio': 'Cleopatra’s young brother and co-ruler, whose faction drove her out; he drowned in the Nile after losing the Alexandrian War.',
     'rel': 'The sibling rival she overcame with Caesar’s help.'},
    {'name': 'Caesarion', 'role': 'son and heir', 'color': '#166534',
     'bio': 'Cleopatra’s son, whom she presented as Caesar’s child and co-ruler; he was killed by Octavian after her death, ending the dynasty.',
     'rel': 'The son and heir on whom she staked her dynasty’s future.'},
]

KEY_EVENTS = [
    ('69 BC', 'Cleopatra born', 'Into the Greek Ptolemaic dynasty of Egypt.'),
    ('51 BC', 'Becomes queen', 'Co-ruler with her brother Ptolemy XIII.'),
    ('48 BC', 'Allies with Caesar', 'Smuggled to him; the Alexandrian War.'),
    ('47 BC', 'Bears Caesarion', 'A son she names as Caesar’s.'),
    ('41 BC', 'Meets Antony at Tarsus', 'The famous barge; a new alliance.'),
    ('34 BC', 'Donations of Alexandria', 'Territories granted to her children.'),
    ('31 BC', 'Actium', 'Defeated at sea by Octavian.'),
    ('30 BC', 'Death of Cleopatra', 'Suicide; Caesarion killed.'),
    ('30 BC', 'Egypt annexed', 'The last pharaoh; Egypt becomes Roman.'),
]

MASTER = [
    {'year': '69 BC', 'age': 'born', 'phase': 'The Throne', 'title': 'Born a Ptolemy', 'desc': 'Greek dynasty of Egypt.'},
    {'year': '51 BC', 'age': 'age 18', 'phase': 'The Throne', 'title': 'Becomes queen', 'desc': 'Co-ruler with her brother.'},
    {'year': '48 BC', 'age': 'age 21', 'phase': 'Caesar', 'title': 'Wins Caesar', 'desc': 'Restored to the throne.'},
    {'year': '41 BC', 'age': 'age 28', 'phase': 'Antony', 'title': 'Tarsus', 'desc': 'Allies with Antony.'},
    {'year': '31 BC', 'age': 'age 38', 'phase': 'The Fall', 'title': 'Actium', 'desc': 'Defeated by Octavian.'},
    {'year': '30 BC', 'age': 'age 39', 'phase': 'The Fall', 'title': 'Death', 'desc': 'The last pharaoh dies.'},
]

SOURCES = [
    ('Britannica — Cleopatra', 'https://www.britannica.com/biography/Cleopatra-queen-of-Egypt'),
    ('World History Encyclopedia — Cleopatra VII', 'https://www.worldhistory.org/Cleopatra_VII/'),
    ('Britannica — Battle of Actium', 'https://www.britannica.com/event/Battle-of-Actium-31-BC'),
    ('World History Encyclopedia — Ptolemaic Dynasty', 'https://www.worldhistory.org/Ptolemaic_Dynasty/'),
    ('Wikipedia — Cleopatra', 'https://en.wikipedia.org/wiki/Cleopatra'),
]

def build_meta():
    return {
        'pid': 'gm-cleopatra.html', 'kind': 'man', 'emoji': '👑', 'accent': AC,
        'name': 'Cleopatra VII', 'years': '69–30 BC', 'group': 'Ancient Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The last pharaoh of Egypt — a brilliant, multilingual ruler who won Caesar and Antony as allies in a decades-long bid to save her kingdom, and died a queen rather than a captive.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Throne', 'type': 'timeline',
             'intro': 'The last of a Greek dynasty ruling a rich but fragile Egypt at Rome’s mercy, a brilliant and educated queen at 18 asserts real power — and is driven out by her brother’s faction just as Rome’s civil war reaches Egypt.', 'events': PHASE_RISE},
            {'id': 'caesar', 'label': '2 · Caesar', 'type': 'timeline',
             'intro': 'Smuggled to Caesar, she wins the most powerful man in the world, is restored by war, bears his son — a bold bid to bind Egypt to Caesar’s line that his assassination shatters.', 'events': PHASE_CAESAR},
            {'id': 'antony', 'label': '3 · Antony', 'type': 'timeline',
             'intro': 'She secures her throne, captivates Antony with the legendary entrance at Tarsus, and builds a power bloc of Rome’s eastern legions and Egypt’s wealth — crowned by the fatal splendour of the Donations of Alexandria.', 'events': PHASE_ANTONY},
            {'id': 'fall', 'label': '4 · The Fall', 'type': 'timeline',
             'intro': 'Octavian’s propaganda makes her the villain and turns Rome against them; defeat at Actium dooms their cause; and rather than be paraded as a trophy, she dies a queen by her own hand.', 'events': PHASE_FALL},
            {'id': 'legacy', 'label': '5 · Legacy', 'type': 'timeline',
             'intro': 'Her death ends 3,000 years of pharaohs and hands Egypt to Rome — and for two millennia her enemies’ propaganda buries the real ruler beneath the legend of the seductress.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Nearly all ancient sources on Cleopatra are Roman and hostile; the famous “seductress” image owes much to Octavian’s propaganda and later art, and is read critically by historians.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
