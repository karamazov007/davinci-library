# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Krishnadevaraya.
The Tuluva emperor who brought the Vijayanagara Empire to its golden zenith."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#92400e'  # Vijayanagara temple-gold

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE RISE
PHASE_RISE = [
    E('origins', '1471–1509', 'A soldier’s son of the Tuluva line', ['RISE', 'ORIGINS'],
      'Krishnadevaraya is born into the Tuluva family that had risen to power at Vijayanagara through the sword — the son of the warlord Tuluva Narasa Nayaka, who seized effective control of the empire and founded a new dynasty in all but name.',
      svg_stack('A dynasty forged by warlords', [
          {'n': 1, 'label': 'Born 1471, Tuluva line', 'sub': 'son of the warlord Tuluva Narasa Nayaka', 'color': '#92400e'},
          {'n': 2, 'label': 'A new dynasty at Vijayanagara', 'sub': 'his father seizes real power over the empire', 'color': '#a16207'},
          {'n': 3, 'label': 'Half-brother Vira Narasimha rules', 'sub': 'the Tuluva dynasty is founded, 1505', 'color': '#166534'},
      ], takeaway='He was born to a family that had already climbed to the throne by war — the empire was his inheritance and his test.', accent=AC),
      bg='By the late 1400s the old Sangama and Saluva lines of <b>Vijayanagara</b> were spent. Power passed to the Tuluva warlord Narasa Nayaka, Krishnadevaraya’s father.',
      people='<b>Tuluva Narasa Nayaka</b>, his father and empire-builder; his half-brother <b>Vira Narasimha</b>, the first Tuluva king; the fading Saluva dynasty.',
      what='Krishnadevaraya was born in <b>1471</b> into the <b>Tuluva family</b> that had taken control of Vijayanagara. His half-brother Vira Narasimha formally founded the Tuluva dynasty in 1505, ruling until his death in 1509.',
      crux='His was a house that had risen <b>by force and merit, not ancient blood</b> — legitimacy would have to be won on the battlefield.',
      conseq='On Vira Narasimha’s death in 1509, Krishnadevaraya inherited a rich but threatened empire ringed by enemies.',
      matters='Great reigns often begin in usurpation — the Tuluva sword that seized Vijayanagara handed Krishnadevaraya both a crown and a fight.'),

    E('accession', '1509', 'Crowned amid enemies on every frontier', ['RISE', 'TURNING POINT'],
      'Krishnadevaraya takes the throne of Vijayanagara at a moment of danger — the Deccan Sultanates press from the north, the Gajapatis of Odisha hold the east, and rebel chiefs test the young king — but with the shrewd old minister Timmarusu at his side he means to master them all.',
      svg_row('An empire ringed by foes', [
          {'n': 1, 'label': 'Accession, 1509', 'sub': 'crowned king of Vijayanagara', 'color': '#92400e'},
          {'n': 2, 'label': 'Enemies on every side', 'sub': 'Deccan Sultanates, Gajapatis, rebel chiefs', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Timmarusu at his side', 'sub': 'his veteran minister and mentor', 'color': '#166534'},
      ], edge_labels=['faces', 'aided by'], takeaway='He inherited a throne surrounded by threats — and set out to turn defence into conquest.', accent=AC),
      bg='Krishnadevaraya came to power in <b>1509</b> as the Bahmani successor sultanates raided from the north and the Gajapati kings of Odisha held territory in the east.',
      people='the young emperor; his prime minister and mentor <b>Saluva Timmarusu</b>; the Deccan Sultans and the Gajapati ruler <b>Prataparudra</b>.',
      what='At his <b>accession in 1509</b>, Krishnadevaraya faced pressure from the Deccan Sultanates and the Gajapatis, and restless vassals. Guided by the able minister <b>Timmarusu</b>, he prepared to secure and expand the empire.',
      crux='He treated a ring of enemies not as a siege but as an <b>opportunity for conquest</b> — the best defence was to march out and win.',
      conseq='Within a year he was on campaign, opening two decades of near-continuous and largely victorious war.',
      matters='A crown inherited in danger tests a ruler at once — Krishnadevaraya answered by taking the offensive from his first year.'),

    E('early', '1509–1510', 'First blood — and a Portuguese card', ['RISE', 'BATTLE'],
      'The young king proves himself early, throwing back a Bahmani-sultanate invasion and defeating the Sultan of Bijapur near the Raichur Doab — while striking an alliance with the newly-arrived Portuguese at Goa that gives Vijayanagara guns, war-horses and a foothold on the sea.',
      svg_stack('Proving himself, and finding an ally', [
          {'n': 1, 'label': 'Repels the invaders, 1509', 'sub': 'throws back a Deccan-sultanate attack', 'color': '#92400e'},
          {'n': 2, 'label': 'Victory near the Raichur Doab', 'sub': 'beats the Sultan of Bijapur’s forces', 'color': '#166534'},
          {'n': 3, 'label': 'Alliance with the Portuguese', 'sub': 'Goa, 1510 — guns and Arabian horses', 'color': '#0e7490'},
      ], takeaway='His first campaigns won respect abroad and a valuable new partner — the Portuguese at Goa.', accent=AC),
      bg='Soon after his accession the Bahmani-successor sultanates tested the new king; at the same time the Portuguese under Albuquerque seized <b>Goa (1510)</b>.',
      people='the invading Deccan sultans; the <b>Portuguese</b> of Goa, suppliers of guns and horses; Krishnadevaraya’s war-captains.',
      what='Krishnadevaraya <b>repelled an early invasion and defeated Bijapuri forces</b> near the contested Raichur Doab, and cultivated the <b>Portuguese at Goa</b> for firearms and prized Arabian cavalry mounts.',
      crux='He saw that <b>trade and technology were weapons</b> — the Portuguese link gave his armies the horses and guns the Deccan lacked.',
      conseq='Secure at home and newly armed, he turned to the long campaigns that would define his reign.',
      matters='The wise ruler courts new powers on his coast — Krishnadevaraya turned the Portuguese arrival into an arms advantage.'),
]

# ==================================================================  PHASE 2 — THE DECCAN WARS
PHASE_DECCAN = [
    E('sultanates', '1510–1519', 'Turning the tables on the Deccan Sultanates', ['BATTLE', 'POLITICS'],
      'For a decade Krishnadevaraya reverses the balance of the Deccan, driving back the successor states of the old Bahmani kingdom — Bijapur, Golconda, Bidar and Ahmadnagar — and making Vijayanagara, not the sultans, the master of the contested northern frontier.',
      svg_row('Mastering the northern frontier', [
          {'n': 1, 'label': 'The Deccan Sultanates', 'sub': 'Bijapur, Golconda, Bidar, Ahmadnagar', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Vijayanagara pushes north', 'sub': 'raids answered, frontier forts taken', 'color': '#92400e'},
          {'n': 3, 'label': 'Balance reversed', 'sub': 'the empire, not the sultans, dominates', 'color': '#166534'},
      ], edge_labels=['met by', 'so'], takeaway='He turned a defensive frontier into an offensive one — Vijayanagara now dictated terms in the Deccan.', accent=AC),
      bg='The Deccan Sultanates — Bijapur, Golconda, Ahmadnagar, Bidar and Berar — had fractured from the Bahmani kingdom and long raided Vijayanagara’s north.',
      people='the rival <b>Deccan Sultans</b>, chiefly <b>Ismail Adil Shah</b> of Bijapur; the Bahmani figurehead; Krishnadevaraya’s commanders.',
      what='Through the 1510s Krishnadevaraya <b>took the offensive against the Deccan Sultanates</b>, answering their raids and seizing the initiative on the northern frontier that had long threatened the empire.',
      crux='He refused to remain on the defensive, <b>carrying the war into the sultans’ lands</b> and reversing the strategic balance.',
      conseq='The rivalry with Bijapur over the fertile Raichur Doab built toward a decisive clash in 1520.',
      matters='A frontier is held by attacking, not waiting — Krishnadevaraya made the aggressor the defender.'),

    E('raichur', '1520', 'The Battle of Raichur — his masterpiece of war', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'At Raichur in 1520 Krishnadevaraya wins the greatest victory of his reign — smashing the army of Ismail Adil Shah of Bijapur in a hard-fought battle where his infantry, cavalry and Portuguese-supplied gunners crush the Sultan and seize the rich fortress of Raichur.',
      svg_compare('Raichur, 1520 — the decisive clash',
          {'head': 'Vijayanagara', 'color': '#92400e', 'items': [
              'Krishnadevaraya commands in person',
              'Huge infantry and cavalry host',
              'Portuguese musketeers and guns',
              'Storms the fortress of Raichur']},
          {'head': 'Bijapur', 'color': '#b91c1c', 'items': [
              'Sultan Ismail Adil Shah',
              'Strong artillery and cavalry',
              'Defends the Raichur Doab',
              'Routed with heavy losses']},
          verdict='A crushing Vijayanagara victory — the Doab and the frontier secured.',
          takeaway='Raichur was the crowning military triumph of his reign — the Deccan’s balance decisively tipped.', accent=AC),
      bg='The fertile <b>Raichur Doab</b>, between the Krishna and Tungabhadra rivers, was long fought over. In 1520 Krishnadevaraya marched to take it from Bijapur.',
      people='<b>Ismail Adil Shah</b>, Sultan of Bijapur; the Portuguese gunners in Vijayanagara service; the emperor commanding in person.',
      what='At the <b>Battle of Raichur (1520)</b> Krishnadevaraya defeated Sultan <b>Ismail Adil Shah</b> of Bijapur in a bloody, close-run fight, then stormed the fortress of Raichur — the decisive victory of his reign, aided by Portuguese firearms.',
      crux='He committed everything to a <b>set-piece battle</b> and won it by combining massed troops with the new firepower of Portuguese guns.',
      conseq='Bijapur was humbled; Krishnadevaraya even marched on and briefly took its capital before withdrawing on generous terms.',
      matters='One decisive victory can define an age — Raichur made Vijayanagara the paramount power of the Deccan.'),

    E('gulbarga', '1520–1523', 'Kingmaker of the Deccan', ['POLITICS', 'TRIUMPH'],
      'After Raichur, Krishnadevaraya presses his advantage deep into sultanate territory, taking Gulbarga and restoring a Bahmani prince to his throne — an act of dominance that earns him the proud title "establisher of the Yavana kingdom" and marks him as the arbiter of the whole Deccan.',
      svg_stack('Arbiter of his enemies’ thrones', [
          {'n': 1, 'label': 'Pursues the beaten sultans', 'sub': 'marches into Bijapur territory', 'color': '#92400e'},
          {'n': 2, 'label': 'Takes Gulbarga', 'sub': 'the old Bahmani capital falls', 'color': '#166534'},
          {'n': 3, 'label': '“Establisher of the Yavana kingdom”', 'sub': 'restores a Bahmani prince to power', 'color': '#a16207'},
      ], takeaway='He grew so dominant he could seat and unseat the sultans himself — a Hindu emperor as kingmaker of the Deccan.', accent=AC),
      bg='With Bijapur broken after Raichur, the shattered Bahmani-successor politics of the Deccan lay open to Vijayanagara’s influence.',
      people='the deposed and restored <b>Bahmani prince</b>; the humbled Deccan Sultans; Krishnadevaraya as overlord.',
      what='Krishnadevaraya pushed on to <b>take Gulbarga</b> and <b>restored a Bahmani prince</b> to nominal rule, earning the boastful title <b>“establisher of the Yavana kingdom”</b> and asserting mastery over the Deccan.',
      crux='He turned military victory into <b>political supremacy</b>, dictating who ruled among his defeated rivals.',
      conseq='Vijayanagara stood at the height of its power in the Deccan, its northern frontier more secure than ever.',
      matters='Supremacy is proven when you seat your enemies’ kings — Krishnadevaraya became the Deccan’s arbiter.'),
]

# ==================================================================  PHASE 3 — THE EASTERN CONQUESTS
PHASE_EAST = [
    E('udayagiri', '1512–1514', 'Breaking the Gajapatis at Udayagiri', ['BATTLE', 'POLITICS'],
      'Krishnadevaraya turns east against the powerful Gajapati kings of Odisha, laying siege to the great hill-fortress of Udayagiri — a campaign so hard that the siege drags on for a year before the fort falls, opening the road into Gajapati country.',
      svg_stack('The long siege of a hill-fortress', [
          {'n': 1, 'label': 'War with the Gajapatis', 'sub': 'the Odishan kings hold the east', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Siege of Udayagiri', 'sub': 'a year-long blockade of the hill-fort', 'color': '#92400e'},
          {'n': 3, 'label': 'The fortress falls, 1514', 'sub': 'the road into Gajapati lands opens', 'color': '#166534'},
      ], takeaway='Patience and grinding siege-craft cracked the Gajapati defences and opened the whole eastern front.', accent=AC),
      bg='The <b>Gajapati kings of Odisha</b>, under <b>Prataparudra Deva</b>, held forts and territory in the eastern Deccan and Andhra that Krishnadevaraya set out to reclaim.',
      people='the Gajapati king <b>Prataparudra</b>; the fortress garrison of Udayagiri; Krishnadevaraya and his besieging army.',
      what='Krishnadevaraya besieged the formidable hill-fortress of <b>Udayagiri</b> from around 1512; after roughly a <b>year-long siege it fell (1514)</b>, breaking Gajapati power in the region.',
      crux='He met a fortress that could not be stormed with the <b>patience to starve it out</b> — a slow, methodical reduction.',
      conseq='With Udayagiri taken, the way lay open to the Gajapati strongholds of Kondavidu and beyond.',
      matters='Some victories are won by endurance — the year at Udayagiri showed the emperor’s persistence, not just his dash.'),

    E('kondavidu', '1515', 'Kondavidu — a fortress taken by cunning', ['BATTLE', 'POLITICS'],
      'The mighty fort of Kondavidu resists direct assault until Krishnadevaraya’s minister Timmarusu discovers a secret way in — a hidden approach that lets the Vijayanagara troops storm the stronghold, capture the Gajapati garrison, and take a royal prince prisoner.',
      svg_row('Guile cracks an impregnable fort', [
          {'n': 1, 'label': 'Kondavidu resists assault', 'sub': 'a Gajapati fortress holds firm', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Timmarusu finds a secret path', 'sub': 'a hidden approach into the fort', 'color': '#a16207'},
          {'n': 3, 'label': 'Stormed and captured, 1515', 'sub': 'the garrison and a prince taken', 'color': '#166534'},
      ], edge_labels=['until', 'so'], takeaway='Where force stalled, the minister’s cunning prevailed — Kondavidu fell to a hidden path.', accent=AC),
      bg='After Udayagiri, Krishnadevaraya besieged <b>Kondavidu</b>, another key Gajapati fortress guarding the Andhra country.',
      people='the shrewd minister <b>Saluva Timmarusu</b>; the Gajapati defenders and a captured prince; the emperor.',
      what='When <b>Kondavidu</b> withstood assault, the minister <b>Timmarusu</b> reportedly found a <b>secret entrance</b>; the fort was stormed and taken in <b>1515</b>, with the garrison and a Gajapati prince captured.',
      crux='He paired brute siege with <b>intelligence and stratagem</b> — a hidden way in succeeded where the walls defied him.',
      conseq='The fall of Kondavidu carried Vijayanagara’s power deep into the Gajapati heartland.',
      matters='Cunning multiplies force — Timmarusu’s secret path shows a great minister can be worth an army.'),

    E('gajapati', '1516–1518', 'Peace sealed by a royal marriage', ['POLITICS', 'TRIUMPH'],
      'Driving on into Odisha, Krishnadevaraya brings the Gajapati king Prataparudra to terms — and, victorious, makes a magnanimous peace: he returns conquered lands north of the Krishna River, fixes that river as the boundary, and marries Prataparudra’s daughter to seal the settlement.',
      svg_stack('Victory crowned with a generous peace', [
          {'n': 1, 'label': 'Campaign deep into Odisha', 'sub': 'the Gajapati king is forced to terms', 'color': '#92400e'},
          {'n': 2, 'label': 'The Krishna River as boundary', 'sub': 'lands north of it returned to Prataparudra', 'color': '#166534'},
          {'n': 3, 'label': 'Sealed by marriage', 'sub': 'weds the Gajapati princess Jaganmohini', 'color': '#a16207'},
      ], takeaway='He won the war then made a wise, generous peace — securing his eastern frontier by treaty and marriage.', accent=AC),
      bg='Krishnadevaraya carried the war into Odisha itself, pressing the Gajapati king <b>Prataparudra Deva</b> until he sought terms.',
      people='the Gajapati king <b>Prataparudra</b>; his daughter, the princess <b>Jaganmohini</b>; Krishnadevaraya, the magnanimous victor.',
      what='Victorious over the Gajapatis, Krishnadevaraya made a <b>generous settlement</b> — returning lands north of the <b>Krishna River</b>, fixing it as the boundary, and <b>marrying Prataparudra’s daughter</b> to seal the peace.',
      crux='He understood that <b>a lasting peace is not vindictive</b> — restraint in victory turned a beaten enemy into a stable neighbour.',
      conseq='His eastern frontier secure, Krishnadevaraya could turn from war to the arts of peace and rule.',
      matters='The greatest conquerors know when to stop — Krishnadevaraya’s magnanimity at the Krishna won a durable peace.'),
]

# ==================================================================  PHASE 4 — THE GOLDEN CAPITAL
PHASE_CAPITAL = [
    E('hampi', '1509–1529', 'Vijayanagara — a city of wonders', ['CULTURE', 'TRIUMPH'],
      'At the height of his reign Krishnadevaraya’s capital, Vijayanagara at Hampi, is one of the largest and richest cities in the world — a vast metropolis of temples, palaces, bazaars and gardens spread among granite hills, humming with trade in diamonds, textiles and horses.',
      svg_stack('The grandest city of its age', [
          {'n': 1, 'label': 'Vijayanagara at Hampi', 'sub': 'the imperial capital among granite hills', 'color': '#92400e'},
          {'n': 2, 'label': 'Temples, palaces, bazaars', 'sub': 'a sprawling city of markets and gardens', 'color': '#a16207'},
          {'n': 3, 'label': 'A hub of world trade', 'sub': 'diamonds, textiles, spices and horses', 'color': '#0e7490'},
      ], takeaway='His capital was among the greatest cities on earth — the shining face of the empire at its zenith.', accent=AC),
      bg='<b>Vijayanagara</b>, the “City of Victory” at <b>Hampi</b> on the Tungabhadra, had grown for nearly two centuries into a vast fortified metropolis.',
      people='the merchants, artisans and pilgrims who thronged it; foreign traders from Persia and Portugal; the imperial court.',
      what='Under Krishnadevaraya the capital <b>Vijayanagara (Hampi)</b> reached its peak — an immense city of temples, palaces, markets and water-works, and a great centre of trade in <b>diamonds, textiles, spices and war-horses</b>.',
      crux='The city was the <b>visible proof of the empire’s wealth and order</b> — grandeur as an instrument of prestige and power.',
      conseq='Its fame drew foreign visitors whose written accounts preserve its splendour for history.',
      matters='A capital can embody a civilisation — Hampi at its height showed South India’s power, wealth and artistry to the world.'),

    E('paesnunes', '1520–1522', 'Seen through Portuguese eyes', ['CULTURE', 'SOURCES'],
      'Two Portuguese visitors, Domingo Paes and Fernão Nunes, come to Vijayanagara and leave astonished accounts — Paes calling it "as large as Rome and very beautiful to the sight," describing crowded bazaars, a vast army, glittering festivals and a king of tireless energy.',
      svg_row('Foreign witnesses to a golden age', [
          {'n': 1, 'label': 'Domingo Paes', 'sub': 'Portuguese visitor, c. 1520', 'color': '#0e7490'},
          {'n': 2, 'label': '“As large as Rome”', 'sub': 'awestruck at the city and its wealth', 'color': '#92400e'},
          {'n': 3, 'label': 'Fernão Nunes', 'sub': 'chronicles the court and army', 'color': '#a16207'},
      ], edge_labels=['records', 'as does'], takeaway='Outside eyes confirm the legend — the Portuguese accounts are our vivid window onto Vijayanagara’s peak.', accent=AC),
      bg='Portuguese traders and travellers reached Vijayanagara in Krishnadevaraya’s reign; two, <b>Domingo Paes</b> and <b>Fernão Nunes</b>, left detailed written accounts.',
      people='<b>Domingo Paes</b> and <b>Fernão Nunes</b>, Portuguese chroniclers; the crowds, soldiers and courtiers they described; the emperor himself.',
      what='<b>Domingo Paes</b> (c. 1520) described Vijayanagara as <b>“as large as Rome and very beautiful,”</b> with vast bazaars, festivals and armies, and praised the king; <b>Fernão Nunes</b> chronicled the dynasty, court and military.',
      crux='Their <b>outsider testimony</b> corroborates the empire’s splendour — independent proof of its scale and wealth.',
      conseq='These accounts became a chief source for historians reconstructing Vijayanagara’s golden age.',
      matters='History remembers what witnesses record — the Portuguese chronicles keep Krishnadevaraya’s capital alive to us.'),

    E('governance', '1509–1529', 'Prosperity by good government', ['POLITICS', 'REFORM'],
      'Behind the splendour lies careful rule — Krishnadevaraya builds irrigation tanks and canals, promotes agriculture and trade, eases burdensome taxes, and governs through the nayaka military-chief system, giving his empire the prosperity that made its golden age possible.',
      svg_stack('The order beneath the grandeur', [
          {'n': 1, 'label': 'Water-works and farming', 'sub': 'tanks, canals and expanded cultivation', 'color': '#166534'},
          {'n': 2, 'label': 'Trade and lighter taxes', 'sub': 'encourages commerce; eases levies', 'color': '#0e7490'},
          {'n': 3, 'label': 'The nayaka system', 'sub': 'rules through military-chief governors', 'color': '#92400e'},
      ], takeaway='Splendour rested on sound administration — irrigation, trade and taxation carefully managed.', accent=AC),
      bg='A wealthy capital and standing armies required a productive, well-run realm across the Deccan and South India.',
      people='the peasants and merchants who prospered; the <b>nayakas</b> (military governors); the ministers who administered the empire.',
      what='Krishnadevaraya promoted <b>irrigation</b> (tanks and canals), <b>agriculture and trade</b>, and <b>eased certain taxes</b>, governing partly through the <b>nayaka</b> system of military-chief landholders — the foundation of the empire’s prosperity.',
      crux='He grasped that <b>power grows from a prosperous, well-watered land</b>, not from conquest alone.',
      conseq='This wealth funded his wars, his building and his lavish patronage of the arts.',
      matters='Golden ages rest on plumbing and taxes — Krishnadevaraya’s glory was built on careful, practical government.'),
]

# ==================================================================  PHASE 5 — POET-KING & LEGACY
PHASE_LEGACY = [
    E('ashtadiggajas', '1509–1529', 'The Ashtadiggajas — eight poets of a golden court', ['CULTURE', 'TRIUMPH'],
      'Krishnadevaraya makes his court a shrine of Telugu literature, gathering the "Ashtadiggajas" — the eight great poets who are the "eight elephants" holding up the corners of his literary world — with Allasani Peddana, the "grandfather of Telugu poetry," foremost among them.',
      svg_row('A court that crowned the poets', [
          {'n': 1, 'label': 'The Bhuvana Vijaya court', 'sub': 'his hall of poets and scholars', 'color': '#92400e'},
          {'n': 2, 'label': 'The Ashtadiggajas', 'sub': 'the “eight elephants” — eight great poets', 'color': '#a16207'},
          {'n': 3, 'label': 'Allasani Peddana foremost', 'sub': 'the “grandfather of Telugu poetry”', 'color': '#166534'},
      ], edge_labels=['holds', 'led by'], takeaway='He turned his court into the golden age of Telugu letters — poetry patronised as a glory of the state.', accent=AC),
      bg='Krishnadevaraya, himself a poet, presided over a court celebrated for scholarship in Telugu, Sanskrit, Kannada and Tamil.',
      people='the <b>Ashtadiggajas</b>, the eight court poets; <b>Allasani Peddana</b>, the chief among them; the jester-poet <b>Tenali Ramakrishna</b>.',
      what='Krishnadevaraya’s court hosted the <b>“Ashtadiggajas”</b> — eight celebrated Telugu poets likened to the eight elephants bearing the world — led by <b>Allasani Peddana</b>, hailed as the <b>grandfather of Telugu poetry</b>.',
      crux='He made <b>literary patronage a pillar of imperial glory</b>, elevating poets as ornaments of the throne.',
      conseq='His reign is remembered as a golden age of Telugu literature and a high point of South Indian culture.',
      matters='Empires are remembered for their poets as much as their battles — Krishnadevaraya’s court gilded an age of letters.'),

    E('amuktamalyada', '1509–1529', 'The poet-king and the temple-builder', ['CULTURE', 'REFORM'],
      'Krishnadevaraya is no mere patron but a scholar-king in his own right — author of the Telugu classic Amuktamalyada, a devotional epic on the saint Andal — and a great builder who raises temples and gopurams across the south, adorning Hampi with the Krishna and Vittala shrines and endowing Tirupati.',
      svg_stack('A king who wrote and who built', [
          {'n': 1, 'label': 'Author of the Amuktamalyada', 'sub': 'his own Telugu devotional classic', 'color': '#92400e'},
          {'n': 2, 'label': 'Temple-builder of the south', 'sub': 'gopurams and shrines across the realm', 'color': '#a16207'},
          {'n': 3, 'label': 'Hampi and Tirupati adorned', 'sub': 'Krishna and Vittala temples; rich endowments', 'color': '#166534'},
      ], takeaway='He wrote a Telugu masterwork and covered the south in temples — a rare king who was also an artist.', accent=AC),
      bg='A devout Vaishnava and a learned man, Krishnadevaraya combined the roles of scholar, poet and pious temple-patron.',
      people='the poet-king himself; the saint <b>Andal</b>, subject of his epic; the temple priests and architects he patronised.',
      what='Krishnadevaraya wrote the Telugu classic <b>Amuktamalyada</b> (on the saint Andal), and was a prolific <b>temple-builder</b> — raising towering gopurams, adding the <b>Krishna and Vittala temples</b> at Hampi and richly endowing <b>Tirupati</b>.',
      crux='He fused <b>power, piety and art</b> in one person — ruler, warrior, poet and builder all at once.',
      conseq='His temples and verse outlived his empire, shaping South Indian devotion and letters for centuries.',
      matters='The ideal of the scholar-king found rare form in Krishnadevaraya — a conqueror who also created enduring art.'),

    E('death', '1529', 'Death at the summit — and the shadow after', ['DEATH', 'DEFEAT'],
      'Krishnadevaraya dies in 1529 at the height of his power, his hoped-for succession already darkened by the death of his young son and the tragic fall of his old minister Timmarusu — and though his brother Achyuta succeeds him, the empire he raised to its zenith would be shattered a generation later at Talikota.',
      svg_stack('The zenith, and the long dusk', [
          {'n': 1, 'label': 'Death of Krishnadevaraya, 1529', 'sub': 'the empire at its greatest extent', 'color': '#78350f'},
          {'n': 2, 'label': 'A darkened succession', 'sub': 'his son dead; Timmarusu fallen; Achyuta follows', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Talikota, 1565', 'sub': 'the empire broken a generation later', 'color': '#334155'},
      ], takeaway='He died at the summit — but the golden age proved hard to sustain, and Vijayanagara fell within forty years.', accent=AC),
      bg='By 1529 Krishnadevaraya had raised Vijayanagara to its greatest power, but the death of his crown-prince son and a rift with Timmarusu clouded his last years.',
      people='his brother and successor <b>Achyuta Deva Raya</b>; the fallen minister <b>Timmarusu</b>; the later kings who lost at Talikota.',
      what='Krishnadevaraya <b>died in 1529</b> at the height of the empire; his son had predeceased him and Timmarusu had fallen from favour. His brother <b>Achyuta Deva Raya</b> succeeded, but Vijayanagara was crushed by a Deccan-sultanate alliance at <b>Talikota (1565)</b>.',
      crux='He left an empire at its <b>zenith but without a secure heir</b> — greatness that depended too much on one extraordinary man.',
      conseq='Vijayanagara declined after him and was shattered at Talikota, its capital sacked, ending the golden age.',
      matters='A golden age tied to one ruler is fragile — Krishnadevaraya’s death began the slow end of imperial Vijayanagara.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Krishnadevaraya was the greatest emperor of Vijayanagara, the Tuluva-dynasty ruler who between 1509 and 1529 raised the South Indian empire to its golden zenith. A tireless warrior, he mastered the Deccan Sultanates — winning his crowning victory at Raichur in 1520 — and humbled the Gajapatis of Odisha, then made a generous peace. His capital at Hampi grew into one of the richest cities on earth, praised by Portuguese visitors as “as large as Rome.” Himself a Telugu poet and patron of the eight “Ashtadiggajas,” he made his reign a high point of South Indian power and culture. He is the study in <b>the warrior-scholar king, the golden age, and greatness that outshone the empire it could not outlast.</b></p>
<div class="ov-quote">“The land is best that has little water and much people; the crowned king should always rule with an eye to Dharma.”<span>— from the Amuktamalyada, attributed to Krishnadevaraya</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born to the Tuluva warlords who seized Vijayanagara → crowned in 1509 amid enemies on every frontier → turns the tables on the Deccan Sultanates and wins his masterpiece at Raichur in 1520 → breaks the Gajapatis of Odisha and seals peace at the Krishna River → raises his capital Hampi into a wonder of the world → crowns his court with the eight Ashtadiggajas poets and writes the Amuktamalyada → and dies in 1529 at the summit of a golden age.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⚔️</div><h4>Master of the Deccan</h4><p>Reversed the balance against the sultanates; won the great victory at Raichur.</p></div>
  <div class="ov-card"><div class="i">🏛️</div><h4>The golden capital</h4><p>Made Hampi one of the richest, grandest cities of its age.</p></div>
  <div class="ov-card"><div class="i">📜</div><h4>The poet-king</h4><p>Wrote the Amuktamalyada and crowned a golden age of Telugu letters.</p></div>
  <div class="ov-card"><div class="i">🌊</div><h4>Greatness and fragility</h4><p>An empire raised to its zenith, shattered a generation after his death.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Rise</b><small> 1471–1510</small><p>Tuluva heir, crowned amid enemies, first victories.</p></div>
  <div><b>2 · The Deccan Wars</b><small> 1510–1523</small><p>Mastering the sultanates; the triumph at Raichur.</p></div>
  <div><b>3 · The Eastern Conquests</b><small> 1512–1518</small><p>Breaking the Gajapatis; peace at the Krishna.</p></div>
  <div><b>4 · The Golden Capital</b><small> 1509–1529</small><p>Hampi’s splendour and sound government.</p></div>
  <div><b>5 · Poet-King & Legacy</b><small> 1509–1529</small><p>The Ashtadiggajas, the Amuktamalyada, and death.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Saluva Timmarusu', 'role': 'prime minister & mentor', 'color': '#166534',
     'bio': 'The veteran statesman who guided Krishnadevaraya from his accession, engineered the fall of Kondavidu, and served as the empire’s chief administrator until a tragic late rupture.',
     'rel': 'His trusted minister and the architect of many of his campaigns.'},
    {'name': 'Ismail Adil Shah', 'role': 'rival — Sultan of Bijapur', 'color': '#b91c1c',
     'bio': 'The Sultan of Bijapur whom Krishnadevaraya defeated decisively at the Battle of Raichur in 1520, the crowning military triumph of the reign.',
     'rel': 'The Deccan rival he crushed at Raichur.'},
    {'name': 'Prataparudra Deva', 'role': 'rival — Gajapati king', 'color': '#7e22ce',
     'bio': 'The Gajapati ruler of Odisha whom Krishnadevaraya defeated at Udayagiri and Kondavidu, before making a magnanimous peace sealed by marriage to his daughter.',
     'rel': 'The eastern king he beat and then befriended.'},
    {'name': 'Allasani Peddana', 'role': 'chief court poet', 'color': '#92400e',
     'bio': 'The foremost of the Ashtadiggajas, the eight poets of the court, honoured as the “grandfather of Telugu poetry” and a jewel of Krishnadevaraya’s literary golden age.',
     'rel': 'The greatest poet of his celebrated court.'},
    {'name': 'Domingo Paes', 'role': 'Portuguese chronicler', 'color': '#0e7490',
     'bio': 'The Portuguese visitor who described Vijayanagara around 1520 as “as large as Rome and very beautiful,” leaving one of the vivid eyewitness accounts of the empire at its peak.',
     'rel': 'The foreign witness to his capital’s splendour.'},
]

KEY_EVENTS = [
    ('1471', 'Krishnadevaraya born', 'Into the Tuluva line at Vijayanagara.'),
    ('1509', 'Accession to the throne', 'Crowned amid enemies on every frontier.'),
    ('1510', 'Portuguese alliance at Goa', 'Guns and Arabian war-horses secured.'),
    ('1514', 'Fall of Udayagiri', 'Year-long siege breaks the Gajapatis.'),
    ('1515', 'Capture of Kondavidu', 'Timmarusu’s secret path takes the fort.'),
    ('1518', 'Peace with the Gajapatis', 'Krishna River boundary; a royal marriage.'),
    ('1520', 'Battle of Raichur', 'Crushing victory over Bijapur.'),
    ('1520s', 'Hampi at its zenith', 'Portuguese praise a city “as large as Rome.”'),
    ('1529', 'Death of Krishnadevaraya', 'Dies at the summit of a golden age.'),
]

MASTER = [
    {'year': '1471', 'age': 'born', 'phase': 'The Rise', 'title': 'Born of the Tuluva line', 'desc': 'Heir to warlords who seized Vijayanagara.'},
    {'year': '1509', 'age': 'age 38', 'phase': 'The Rise', 'title': 'Accession', 'desc': 'Crowned amid enemies.'},
    {'year': '1514', 'age': 'age 43', 'phase': 'Eastern Conquests', 'title': 'Udayagiri falls', 'desc': 'Gajapati power broken.'},
    {'year': '1520', 'age': 'age 49', 'phase': 'The Deccan Wars', 'title': 'Battle of Raichur', 'desc': 'His masterpiece of war.'},
    {'year': '1520s', 'age': 'peak', 'phase': 'The Golden Capital', 'title': 'Hampi at its zenith', 'desc': '“As large as Rome.”'},
    {'year': '1529', 'age': 'age 58', 'phase': 'Legacy', 'title': 'Death at the summit', 'desc': 'The golden age ends.'},
]

SOURCES = [
    ('Britannica — Krishna Deva Raya', 'https://www.britannica.com/biography/Krishna-Deva-Raya'),
    ('Wikipedia — Krishnadevaraya', 'https://en.wikipedia.org/wiki/Krishnadevaraya'),
    ('Wikipedia — Battle of Raichur', 'https://en.wikipedia.org/wiki/Battle_of_Raichur'),
    ('World History Encyclopedia — Vijayanagara Empire', 'https://www.worldhistory.org/Vijayanagara_Empire/'),
    ('Wikipedia — Vijayanagara Empire', 'https://en.wikipedia.org/wiki/Vijayanagara_Empire'),
]

def build_meta():
    return {
        'pid': 'gm-krishnadevaraya.html', 'kind': 'man', 'emoji': '👑', 'accent': AC,
        'name': 'Krishnadevaraya', 'years': '1471–1529', 'group': 'Indian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Tuluva emperor who raised Vijayanagara to its golden zenith — master of the Deccan, victor of Raichur, builder of Hampi, and a warrior-poet whose court crowned a golden age of South Indian power and culture.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Rise', 'type': 'timeline',
             'intro': 'Born to the Tuluva warlords who had seized Vijayanagara, he is crowned in 1509 amid enemies on every frontier — and proves himself at once, winning early victories and courting the Portuguese at Goa.', 'events': PHASE_RISE},
            {'id': 'deccan', 'label': '2 · The Deccan Wars', 'type': 'timeline',
             'intro': 'He reverses the balance against the Deccan Sultanates, wins his crowning victory at Raichur in 1520, and grows so dominant he can seat and unseat the sultans himself.', 'events': PHASE_DECCAN},
            {'id': 'east', 'label': '3 · The Eastern Conquests', 'type': 'timeline',
             'intro': 'He turns east against the Gajapatis of Odisha — breaking them at Udayagiri and Kondavidu, then making a magnanimous peace fixed at the Krishna River and sealed by a royal marriage.', 'events': PHASE_EAST},
            {'id': 'capital', 'label': '4 · The Golden Capital', 'type': 'timeline',
             'intro': 'His capital Hampi becomes one of the richest, grandest cities on earth — praised by Portuguese visitors as “as large as Rome” — and its splendour rests on careful irrigation, trade and government.', 'events': PHASE_CAPITAL},
            {'id': 'legacy', 'label': '5 · Poet-King & Legacy', 'type': 'timeline',
             'intro': 'He crowns his court with the eight Ashtadiggajas poets, writes the Telugu classic Amuktamalyada, builds temples across the south — and dies in 1529 at the summit of a golden age his empire could not sustain.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies, encyclopaedic sources and the eyewitness accounts of the Portuguese visitors Domingo Paes and Fernão Nunes; dates for the campaigns follow the commonly cited chronology.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
