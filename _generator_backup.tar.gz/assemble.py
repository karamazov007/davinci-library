# -*- coding: utf-8 -*-
"""Assemble: inject the 3 new assets + 2 sidebar pages into knowledge-hub.html."""
import re, json, hashlib, base64
import engine as E
from landings import GREAT_MEN, GREAT_ERAS
from content_napoleon import build_meta as build_napoleon
from content_caesar import build_meta as build_caesar
from content_alexander import build_meta as build_alexander
from content_hannibal import build_meta as build_hannibal
from content_augustus import build_meta as build_augustus
from content_cleopatra import build_meta as build_cleopatra
from content_nobunaga import build_meta as build_nobunaga
from content_hideyoshi import build_meta as build_hideyoshi
from content_subutai import build_meta as build_subutai
from content_qinshihuang import build_meta as build_qinshihuang
from content_bismarck import build_meta as build_bismarck
from content_richelieu import build_meta as build_richelieu
from content_talleyrand import build_meta as build_talleyrand
from content_metternich import build_meta as build_metternich
from content_marcopolo import build_meta as build_marcopolo
from content_musashi import build_meta as build_musashi
from content_zhugeliang import build_meta as build_zhugeliang
from content_chandraguptamaurya import build_meta as build_chandraguptamaurya
from content_chanakya import build_meta as build_chanakya
from content_wuofhan import build_meta as build_wuofhan
from content_tangtaizong import build_meta as build_tangtaizong
from content_kangxi import build_meta as build_kangxi
from content_buddha import build_meta as build_buddha
from content_muhammad import build_meta as build_muhammad
from content_jesus import build_meta as build_jesus
from content_gurugobindsingh import build_meta as build_gurugobindsingh
from content_mahavira import build_meta as build_mahavira
from content_casanova import build_meta as build_casanova
from content_borgia import build_meta as build_borgia
from content_leox import build_meta as build_leox
from content_jomini import build_meta as build_jomini
from content_liddellhart import build_meta as build_liddellhart
from content_deng import build_meta as build_deng
from content_kissinger import build_meta as build_kissinger
from content_lbj import build_meta as build_lbj
from content_robertmoses import build_meta as build_robertmoses
from content_rockefeller import build_meta as build_rockefeller
from content_buffettmunger import build_meta as build_buffettmunger
from content_arnault import build_meta as build_arnault
from content_mj import build_meta as build_mj
from content_gandhi import build_meta as build_gandhi
from content_jinnah import build_meta as build_jinnah
from content_nehru import build_meta as build_nehru
from content_patel import build_meta as build_patel
from content_ambedkar import build_meta as build_ambedkar
from content_bose import build_meta as build_bose
from content_bhagatsingh import build_meta as build_bhagatsingh
from content_babur import build_meta as build_babur
from content_shahjahan import build_meta as build_shahjahan
from content_aurangzeb import build_meta as build_aurangzeb
from content_shivaji import build_meta as build_shivaji
from content_maharanapratap import build_meta as build_maharanapratap
from content_krishnadevaraya import build_meta as build_krishnadevaraya
from content_rajarajachola import build_meta as build_rajarajachola
from content_nagarjuna import build_meta as build_nagarjuna
from content_patanjali import build_meta as build_patanjali
from content_kalidasa import build_meta as build_kalidasa
from content_vivekananda import build_meta as build_vivekananda
from content_tagore import build_meta as build_tagore
from content_satyajitray import build_meta as build_satyajitray
from content_kurosawa import build_meta as build_kurosawa
from content_spielberg import build_meta as build_spielberg
from content_tarkovsky import build_meta as build_tarkovsky
from content_jrdtata import build_meta as build_jrdtata
from content_ratantata import build_meta as build_ratantata
from content_dhirubhai import build_meta as build_dhirubhai
from content_premji import build_meta as build_premji
from content_mountbatten import build_meta as build_mountbatten
from content_kalam import build_meta as build_kalam
from content_modi import build_meta as build_modi
from content_skorzeny import build_meta as build_skorzeny
from content_churchill import build_meta as build_churchill
from content_lenin import build_meta as build_lenin
from content_stalin import build_meta as build_stalin
from content_genghis import build_meta as build_genghis
from content_ieyasu import build_meta as build_ieyasu
from content_tamerlane import build_meta as build_tamerlane
from content_mehmed2 import build_meta as build_mehmed2
from content_selim1 import build_meta as build_selim1
from content_suleiman import build_meta as build_suleiman
from content_ashoka import build_meta as build_ashoka
from content_akbar import build_meta as build_akbar
from content_lincoln import build_meta as build_lincoln
from content_carnegie import build_meta as build_carnegie
from content_musk import build_meta as build_musk
from content_jobs import build_meta as build_jobs
from content_lky import build_meta as build_lky
from content_arnold import build_meta as build_arnold
from content_liubang import build_meta as build_liubang
from content_sengoku import build_meta as build_sengoku

SRC = 'hub_original.html'
OUT = 'knowledge-hub.new.html'

src = open(SRC, encoding='utf-8').read()

def block(src, sid):
    m = re.search(r'(<script[^>]*id="%s"[^>]*>)(.*?)(</script>)' % re.escape(sid), src, re.S)
    if not m:
        raise SystemExit('block not found: ' + sid)
    return m

pm_m = block(src, 'pages-meta')
ad_m = block(src, 'assets-data')
pages = json.loads(pm_m.group(2))
assets = json.loads(ad_m.group(2))

orig_pages_ids = [p['id'] for p in pages]
orig_assets_keys = set(assets.keys())
print('before: pages=%d assets=%d' % (len(pages), len(assets)))

# ---- build pages (boilerplate + self-contained nav). Navigation is driven by the hub
#      top window (postMessage {__dvhNav}), so pages carry NO embedded page-map and stay lean.
#      This scales to any number of guides without bloating the file. ----
GUIDES = {
    'gm-napoleon.html':  build_napoleon(),
    'gm-caesar.html':    build_caesar(),
    'gm-alexander.html': build_alexander(),
    'gm-hannibal.html':  build_hannibal(),
    'gm-augustus.html':  build_augustus(),
    'gm-cleopatra.html': build_cleopatra(),
    'gm-nobunaga.html':  build_nobunaga(),
    'gm-hideyoshi.html': build_hideyoshi(),
    'gm-subutai.html':   build_subutai(),
    'gm-qinshihuang.html': build_qinshihuang(),
    'gm-bismarck.html':  build_bismarck(),
    'gm-richelieu.html': build_richelieu(),
    'gm-talleyrand.html': build_talleyrand(),
    'gm-metternich.html': build_metternich(),
    'gm-marcopolo.html': build_marcopolo(),
    'gm-musashi.html':   build_musashi(),
    'gm-zhugeliang.html': build_zhugeliang(),
    'gm-chandraguptamaurya.html': build_chandraguptamaurya(),
    'gm-chanakya.html':  build_chanakya(),
    'gm-wuofhan.html':   build_wuofhan(),
    'gm-tangtaizong.html': build_tangtaizong(),
    'gm-kangxi.html':    build_kangxi(),
    'gm-buddha.html':    build_buddha(),
    'gm-muhammad.html':  build_muhammad(),
    'gm-jesus.html':     build_jesus(),
    'gm-gurugobindsingh.html': build_gurugobindsingh(),
    'gm-mahavira.html':  build_mahavira(),
    'gm-casanova.html':  build_casanova(),
    'gm-borgia.html':    build_borgia(),
    'gm-leox.html':      build_leox(),
    'gm-jomini.html':    build_jomini(),
    'gm-liddellhart.html': build_liddellhart(),
    'gm-deng.html':      build_deng(),
    'gm-kissinger.html': build_kissinger(),
    'gm-lbj.html':       build_lbj(),
    'gm-robertmoses.html': build_robertmoses(),
    'gm-rockefeller.html': build_rockefeller(),
    'gm-buffettmunger.html': build_buffettmunger(),
    'gm-arnault.html':   build_arnault(),
    'gm-mj.html':        build_mj(),
    'gm-gandhi.html':    build_gandhi(),
    'gm-jinnah.html':    build_jinnah(),
    'gm-nehru.html':     build_nehru(),
    'gm-patel.html':     build_patel(),
    'gm-ambedkar.html':  build_ambedkar(),
    'gm-bose.html':      build_bose(),
    'gm-bhagatsingh.html': build_bhagatsingh(),
    'gm-babur.html':     build_babur(),
    'gm-shahjahan.html': build_shahjahan(),
    'gm-aurangzeb.html': build_aurangzeb(),
    'gm-shivaji.html':   build_shivaji(),
    'gm-maharanapratap.html': build_maharanapratap(),
    'gm-krishnadevaraya.html': build_krishnadevaraya(),
    'gm-rajarajachola.html': build_rajarajachola(),
    'gm-nagarjuna.html': build_nagarjuna(),
    'gm-patanjali.html': build_patanjali(),
    'gm-kalidasa.html':  build_kalidasa(),
    'gm-vivekananda.html': build_vivekananda(),
    'gm-tagore.html':    build_tagore(),
    'gm-satyajitray.html': build_satyajitray(),
    'gm-kurosawa.html':  build_kurosawa(),
    'gm-spielberg.html': build_spielberg(),
    'gm-tarkovsky.html': build_tarkovsky(),
    'gm-jrdtata.html':   build_jrdtata(),
    'gm-ratantata.html': build_ratantata(),
    'gm-dhirubhai.html': build_dhirubhai(),
    'gm-premji.html':    build_premji(),
    'gm-mountbatten.html': build_mountbatten(),
    'gm-kalam.html':     build_kalam(),
    'gm-modi.html':      build_modi(),
    'gm-skorzeny.html':  build_skorzeny(),
    'gm-churchill.html': build_churchill(),
    'gm-lenin.html':    build_lenin(),
    'gm-stalin.html':   build_stalin(),
    'gm-genghis.html':  build_genghis(),
    'gm-ieyasu.html':   build_ieyasu(),
    'gm-tamerlane.html': build_tamerlane(),
    'gm-mehmed2.html':  build_mehmed2(),
    'gm-selim1.html':   build_selim1(),
    'gm-suleiman.html': build_suleiman(),
    'gm-ashoka.html':   build_ashoka(),
    'gm-akbar.html':    build_akbar(),
    'gm-lincoln.html':  build_lincoln(),
    'gm-carnegie.html': build_carnegie(),
    'gm-musk.html':     build_musk(),
    'gm-jobs.html':     build_jobs(),
    'gm-lky.html':      build_lky(),
    'gm-arnold.html':   build_arnold(),
    'gm-liubang.html':  build_liubang(),
    'era-sengoku.html': build_sengoku(),
}
new_assets = {
    'great-men.html':  E.inject_boilerplate(E.render_landing(GREAT_MEN),  'great-men.html'),
    'great-eras.html': E.inject_boilerplate(E.render_landing(GREAT_ERAS), 'great-eras.html'),
}
for fn, meta in GUIDES.items():
    new_assets[fn] = E.inject_boilerplate(E.render_guide(meta), fn)

# ---- COMPRESSION: recompress every asset (originals + new) with raw-DEFLATE ('RAW:'+b64).
#      The hub resolver is monkey-patched (see DVH_GZ below) to inflate these via pako.
#      This keeps the file small enough to grow across many deepening rounds. ----
orig_html_bytes = {k: base64.b64decode(assets[k]) for k in orig_assets_keys}
for k in orig_assets_keys:
    assets[k] = E.b64gz_bytes(orig_html_bytes[k])       # recompress originals (lossless)
for k, v in new_assets.items():
    assets[k] = E.b64gz(v)                               # compress new guides/landings

# ---- register the 2 sidebar pages (idempotent) ----
pages = [p for p in pages if p['id'] not in ('greatmen', 'greateras')]
pages.append({'id': 'greatmen', 'name': 'Great Men', 'icon': '👑',
              'blurb': 'Deep, visual life-guides of the people who bent history — birth to death, as clickable concept maps you can quiz yourself from.',
              'featured': False, 'file': 'great-men.html'})
pages.append({'id': 'greateras', 'name': 'Great Eras', 'icon': '🏛️',
              'blurb': 'Whole periods told as one story — the forces, players and turning points of an age, in the same clickable format.',
              'featured': False, 'file': 'great-eras.html'})

pm_json = json.dumps(pages, ensure_ascii=False)
ad_json = json.dumps(assets, ensure_ascii=False, separators=(',', ':'))

# ---- splice back: replace the LATER block (assets) first to keep earlier offsets valid ----
pm_s, pm_e = pm_m.span(2)
ad_s, ad_e = ad_m.span(2)
assert pm_s < ad_s
# rebuild from original with both block replacements in one pass
out = src[:pm_s] + pm_json + src[pm_e:ad_s] + ad_json + src[ad_e:]

# ---- inject (1) pako inflate lib, (2) a resolver override that inflates 'RAW:' assets,
#      and (3) the top-window navigation listener. All assets are now raw-DEFLATE compressed;
#      the override re-reads assets-data from the DOM and inflates on demand, so it works for
#      BOTH the original pages and the new guides, and needs no change to the hub's own code. ----
PAKO = open('node_modules/pako/dist/pako_inflate.min.js', encoding='utf-8').read()
assert '</script' not in PAKO.lower(), 'pako contains a script-closing sequence'
DVH_GZ = (
    "<script>/*__dvhpako__*/" + PAKO + "</script>"
    "<script>/*__dvhgz__*/(function(){var A=null;"
    "function assets(){if(A)return A;try{A=JSON.parse(document.getElementById('assets-data').textContent);}catch(e){A={};}return A;}"
    "var cache={};"
    "window.__HUB_RESOLVE__=function(name){"
    "if(!name)return null; if(cache[name])return cache[name];"
    "var val=assets()[name]; if(!val)return null;"
    "try{var bytes;"
    "if(val.slice(0,4)==='RAW:'){var s=atob(val.slice(4)),n=s.length,c=new Uint8Array(n);for(var i=0;i<n;i++)c[i]=s.charCodeAt(i);bytes=window.pako.inflateRaw(c);}"
    "else{var s2=atob(val),n2=s2.length;bytes=new Uint8Array(n2);for(var j=0;j<n2;j++)bytes[j]=s2.charCodeAt(j);}"
    "cache[name]=URL.createObjectURL(new Blob([bytes],{type:'text/html'}));return cache[name];"
    "}catch(e){return null;}};"
    "})();</script>")
DVH_NAV = ("<script>/*__dvhnav__*/window.addEventListener('message',function(ev){try{"
           "var d=ev&&ev.data; if(!d||typeof d.__dvhNav!=='string')return;"
           "var v=document.getElementById('viewer'); if(!v)return;"
           "var u=window.__HUB_RESOLVE__&&window.__HUB_RESOLVE__(d.__dvhNav); if(!u)return;"
           "try{localStorage.setItem('khub.viewer',JSON.stringify({k:'deep',n:d.__dvhNav}));}catch(e){}"
           "try{v.contentWindow.location.replace(u);}catch(e){v.src=u;}"
           "}catch(e){}});</script>")
# ---- (4) refresh persistence: remember exactly which page the viewer shows — including guide
#      pages reached via the __dvhNav bridge — and restore it on reload, so a refresh keeps you
#      where you were instead of dropping you back at the home dashboard. ----
DVH_DEEP = ("<script>/*__dvhdeep__*/(function(){try{"
            "var K='khub.viewer';"
            "function vf(){return document.getElementById('viewer');}"
            "function wrap(){ if(window.__dvhWrapped)return;"
            " if(typeof window.openPage==='function'){ var op=window.openPage; window.__dvhOpenOrig=op;"
            "   window.openPage=function(id){ if(!window.__dvhRestoring){try{localStorage.setItem(K,JSON.stringify({k:'page',id:id}));}catch(e){}} return op.apply(this,arguments); }; }"
            " if(typeof window.showHome==='function'){ var sh=window.showHome;"
            "   window.showHome=function(){ try{localStorage.removeItem(K);}catch(e){} return sh.apply(this,arguments); }; }"
            " window.__dvhWrapped=true; }"
            "wrap();"
            "function restore(){ wrap(); var raw=null; try{raw=localStorage.getItem(K);}catch(e){} if(!raw)return;"
            " var s=null; try{s=JSON.parse(raw);}catch(e){} if(!s)return; var op=window.__dvhOpenOrig||window.openPage;"
            " window.__dvhRestoring=true; try{"
            "  if(s.k==='page'){ if(op)op(s.id); }"
            "  else if(s.k==='deep'&&s.n){ var u=window.__HUB_RESOLVE__&&window.__HUB_RESOLVE__(s.n);"
            "    if(u){ var parent=(String(s.n).indexOf('era-')===0)?'greateras':'greatmen'; if(op)op(parent);"
            "      var v=vf(); if(v){ setTimeout(function(){ try{v.contentWindow.location.replace(u);}catch(e){v.src=u;} v.style.display='block'; },50); } } }"
            " }catch(e){} setTimeout(function(){window.__dvhRestoring=false;},700); }"
            "if(document.readyState==='complete')setTimeout(restore,90);"
            "else window.addEventListener('load',function(){setTimeout(restore,90);});"
            "}catch(e){}})();</script>")
INJECT = DVH_GZ + DVH_NAV + DVH_DEEP
if '/*__dvhnav__*/' not in out:
    i = out.lower().rfind('</body>')
    if i == -1:
        i = out.lower().rfind('</html>')
    out = out[:i] + INJECT + out[i:]

open(OUT, 'w', encoding='utf-8').write(out)
print('wrote %s (%d bytes)' % (OUT, len(out.encode('utf-8'))))

# =====================================================================  VERIFY
v = open(OUT, encoding='utf-8').read()
vp = json.loads(block(v, 'pages-meta').group(2))
va = json.loads(block(v, 'assets-data').group(2))
print('after:  pages=%d assets=%d' % (len(vp), len(va)))

# 1) all original pages preserved, in order, + 2 appended
assert [p['id'] for p in vp][:len(orig_pages_ids)] == orig_pages_ids, 'original page order changed!'
assert [p['id'] for p in vp][-2:] == ['greatmen', 'greateras'], 'new pages not appended'
# 2) every original asset LOSSLESSLY preserved (inflate(stored) == original decoded bytes)
for k in orig_assets_keys:
    assert E.unraw(va[k]) == orig_html_bytes[k], 'asset content changed: ' + k
assert orig_assets_keys.issubset(set(va.keys())), 'lost an original asset'
# 3) new assets present and inflate to valid HTML
for k in new_assets:
    dec = E.unraw(va[k]).decode('utf-8')
    assert dec.strip().lower().startswith('<!doctype html'), 'bad html: ' + k
    assert '</html>' in dec.lower(), 'no </html>: ' + k
    assert 'khub.deep.' in dec, 'boilerplate missing in ' + k
    assert 'data-nav' in dec, 'nav links missing in ' + k
# 3b) every stored asset is 'RAW:' compressed and inflates without error
for k in va:
    assert va[k].startswith('RAW:'), 'asset not compressed: ' + k
    E.unraw(va[k])
# 4) the injected scripts appear exactly once each
assert v.count('/*__dvhnav__*/') == 1, 'nav listener missing/duplicated'
assert v.count('/*__dvhgz__*/') == 1, 'gz resolver missing/duplicated'
assert v.count('/*__dvhpako__*/') == 1, 'pako lib missing/duplicated'
# 5) every page.file has a matching asset
for p in vp:
    assert p['file'] in va, 'page references missing asset: ' + p['file']
# 6) the file is unchanged outside our edits: head before pages-meta is byte-identical,
#    and the tail after assets-data equals the original tail with ONLY the injected scripts.
assert v[:pm_s] == src[:pm_s], 'head changed'
_tail_wo_inject = v[len(v) - len(src[ad_e:]) - len(INJECT):].replace(INJECT, '', 1)
assert _tail_wo_inject == src[ad_e:], 'tail changed beyond the injected scripts'
print('VERIFY OK — originals losslessly preserved (compressed), %d new assets inflate, 2 pages appended, resolver+nav injected.' % len(new_assets))
print('new file grew by %d KB' % ((len(out.encode()) - len(src.encode()))//1024))
