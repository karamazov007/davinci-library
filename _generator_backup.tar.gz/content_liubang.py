# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Liu Bang (Emperor Gaozu of Han).
The peasant who became First Emperor of the Han — founder of a dynasty that named a people."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc
from content_liubang_p1 import EVENTS as LB1
from content_liubang_p2 import EVENTS as LB2
from content_liubang_p3 import EVENTS as LB3
from content_liubang_p4 import EVENTS as LB4
from content_liubang_p5 import EVENTS as LB5
from content_liubang_p6 import EVENTS as LB6

AC = '#b91c1c'  # Han red

WHO = [
    {'name': 'Xiang Yu', 'role': 'the great rival', 'color': '#7f1d1d',
     'bio': 'The aristocratic Hegemon-King of Western Chu and the finest warrior of the age — brave, brilliant and merciless, but politically clumsy. He spared Liu Bang at Hongmen and paid with the empire.',
     'rel': 'The rival he could never beat in a single battle — and defeated in the only one that counted.'},
    {'name': 'Zhang Liang', 'role': 'the strategist', 'color': '#3730a3',
     'bio': 'A ruined nobleman of Han who became Liu Bang’s master strategist — the mind behind Hongmen, the burning of the roads, and the breaking of Xiang Yu.',
     'rel': 'The counselor whose plans Liu Bang trusted above his own instincts.'},
    {'name': 'Xiao He', 'role': 'the administrator', 'color': '#166534',
     'bio': 'The Pei county clerk who seized the Qin records, kept Liu Bang’s armies fed and manned from the rear, and drafted the Han legal code. Ranked first of all the founding ministers.',
     'rel': 'The friend from Pei who built the state behind the war.'},
    {'name': 'Han Xin', 'role': 'the peerless general', 'color': '#a16207',
     'bio': 'A destitute youth who once begged meals and suffered the “crawl between the legs,” raised by Xiao He to supreme command — the general who won the north and sealed Gaixia, then was destroyed by the throne he made.',
     'rel': 'The military genius Liu Bang used, feared, demoted, and let die.'},
    {'name': 'Fan Kuai', 'role': 'the bodyguard', 'color': '#b45309',
     'bio': 'A dog-butcher of Pei and Liu Bang’s brother-in-law, whose reckless courage — bursting armed into the Feast at Hongmen — saved his lord’s life.',
     'rel': 'The blunt, fearless friend who guarded his body and spoke hard truths.'},
    {'name': 'Empress Lü (Lü Zhi)', 'role': 'wife & empress', 'color': '#9d174d',
     'bio': 'The wife given to a poor pavilion chief who became the iron empress — captured by Chu, later the hand that executed Han Xin and Peng Yue and dominated the court after his death.',
     'rel': 'His formidable consort and political partner in the purge of the over-mighty.'},
    {'name': 'Fan Zeng', 'role': 'Xiang Yu’s adviser', 'color': '#6d28d9',
     'bio': 'Xiang Yu’s aged counselor, who saw Liu Bang’s threat clearly and urged the kill at Hongmen — ignored, then driven away by Chen Ping’s cunning.',
     'rel': 'The one mind that might have destroyed him, wasted by his rival.'},
    {'name': 'Ziying', 'role': 'last Qin ruler', 'color': '#57534e',
     'bio': 'The last ruler of Qin, who killed the eunuch Zhao Gao and surrendered to Liu Bang with a cord round his neck — spared by Liu Bang, killed by Xiang Yu.',
     'rel': 'The fallen king whose surrender Liu Bang answered with mercy.'},
]

KEY_EVENTS = [
    ('c. 256 BC', 'Born a peasant in Pei', 'A commoner’s son, later pavilion chief of Sishui.'),
    ('209 BC', 'The Pei uprising', 'Made “Lord of Pei” as revolt engulfs Qin.'),
    ('206 BC', 'First into Guanzhong', 'Ziying surrenders; the “Three Articles” win the people.'),
    ('206 BC', 'The Feast at Hongmen', 'He escapes Xiang Yu’s banquet with his life.'),
    ('206 BC', 'King of Han', 'Exiled west; burns the gallery roads behind him.'),
    ('205 BC', 'Disaster at Pengcheng', '30,000 Chu rout his vast coalition.'),
    ('203 BC', 'Treaty of the Hong Canal', 'The realm split; his family returned.'),
    ('202 BC', 'Gaixia & the Han', 'Xiang Yu falls; Liu Bang becomes Emperor Gaozu.'),
    ('200 BC', 'The Baideng siege', 'Trapped by the Xiongnu; the heqin peace begins.'),
    ('195 BC', 'Song of the Great Wind', 'He sings at home, then dies of an old wound.'),
]

MASTER = [
    {'year': 'c. 256 BC', 'age': 'commoner', 'phase': 'Origins', 'title': 'Born in Pei', 'desc': 'A peasant’s son with a gift for men.'},
    {'year': 'c. 209 BC', 'age': 'Lord of Pei', 'phase': 'Origins', 'title': 'Outlaw to rebel', 'desc': 'Frees convicts; the Pei revolt raises him.'},
    {'year': '208 BC', 'age': 'Lord of Pei', 'phase': 'The Uprising', 'title': 'Joins Chu', 'desc': 'The pact: first into the passes is king.'},
    {'year': '206 BC', 'age': 'King of Han', 'phase': 'Fall of Qin', 'title': 'Xianyang & Hongmen', 'desc': 'Spares Qin; survives Xiang Yu’s feast.'},
    {'year': '206 BC', 'age': 'King of Han', 'phase': 'Chu–Han War', 'title': 'Chencang & Pengcheng', 'desc': 'Storms back east; is crushed, recovers.'},
    {'year': '203 BC', 'age': 'King of Han', 'phase': 'Chu–Han War', 'title': 'The Hong Canal', 'desc': 'A truce he breaks to finish Chu.'},
    {'year': '202 BC', 'age': 'Emperor', 'phase': 'Empire', 'title': 'Gaixia & the throne', 'desc': 'Xiang Yu dies; the Han is founded.'},
    {'year': '200 BC', 'age': 'Emperor', 'phase': 'Empire', 'title': 'Baideng', 'desc': 'The Xiongnu trap; heqin appeasement.'},
    {'year': '196 BC', 'age': 'Emperor', 'phase': 'Empire', 'title': 'The purge', 'desc': 'Han Xin, Peng Yue and Ying Bu destroyed.'},
    {'year': '195 BC', 'age': 'Emperor', 'phase': 'Empire', 'title': 'The Great Wind', 'desc': 'Sings at Pei; dies of the arrow wound.'},
]

SOURCES = [
    ('Wikipedia — Emperor Gaozu of Han', 'https://en.wikipedia.org/wiki/Emperor_Gaozu_of_Han'),
    ('Wikipedia — Chu–Han Contention', 'https://en.wikipedia.org/wiki/Chu%E2%80%93Han_Contention'),
    ('Wikipedia — Feast at Hong Gate', 'https://en.wikipedia.org/wiki/Feast_at_Hong_Gate'),
    ('Wikipedia — Battle of Gaixia', 'https://en.wikipedia.org/wiki/Battle_of_Gaixia'),
    ('Wikipedia — Han Xin', 'https://en.wikipedia.org/wiki/Han_Xin'),
    ('Wikipedia — Battle of Baideng', 'https://en.wikipedia.org/wiki/Battle_of_Baideng'),
    ('Britannica — Liu Bang (Gaozu)', 'https://www.britannica.com/biography/Gaozu-emperor-of-Han-dynasty'),
    ('Records of the Grand Historian (Shiji), Sima Qian — Basic Annals of Gaozu', 'https://en.wikipedia.org/wiki/Records_of_the_Grand_Historian'),
]

OVERVIEW_HTML = """
<p class="ov-lead">Liu Bang was the peasant who founded the Han dynasty — the man who rose from a village pavilion chief in Pei to First Emperor of a realm so enduring that the majority Chinese people still call themselves “Han.” He had no noble blood, no learning, and no gift for war; what he had was an uncanny talent for winning and using men better than himself. Beaten in almost every battle by the brilliant aristocrat Xiang Yu, he lost and lost until the one battle that mattered, at Gaixia, where he won everything. He is the classic study in <b>how the man who cannot do everything himself can still command those who can.</b></p>
<div class="ov-quote">“In the tent I am no match for Zhang Liang; in supply, none for Xiao He; in the field, none for Han Xin. But I can use all three — and that is why I hold the empire.”<span>— Liu Bang, at the victory banquet</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A hard-drinking commoner of Pei becomes an outlaw as Qin cracks → the Pei revolt makes him a lord and he races west to take the Qin capital first → he spares Xianyang, wins the people with three simple laws, and escapes death at the Feast at Hongmen → exiled to Hanzhong, he raises the peerless Han Xin and fights the long Chu–Han war → and at Gaixia he destroys Xiang Yu, founds the Han as Emperor Gaozu, and spends his last years dismantling the allies who made him.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">👥</div><h4>Talent over talent</h4><p>He won by recruiting and trusting men greater than himself.</p></div>
  <div class="ov-card"><div class="i">📜</div><h4>Rule by restraint</h4><p>The “Three Articles” — mercy after Qin’s cruelty — won a war for hearts.</p></div>
  <div class="ov-card"><div class="i">🏯</div><h4>Founder of the Han</h4><p>Four centuries of empire, and the name of a people.</p></div>
  <div class="ov-card"><div class="i">🗡️</div><h4>The founder’s dilemma</h4><p>How a new throne devours the very heroes who built it.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Origins</b><small> to 209 BC</small><p>A peasant of Pei, a pavilion chief, an outlaw as Qin cracks.</p></div>
  <div><b>2 · The Uprising</b><small> 209–207 BC</small><p>Lord of Pei; the pact; the race west for Guanzhong.</p></div>
  <div><b>3 · Fall of Qin</b><small> 207–206 BC</small><p>Xianyang spared, the Three Articles, the Feast at Hongmen.</p></div>
  <div><b>4 · Chu–Han War</b><small> 206–203 BC</small><p>King of Han, Han Xin, Pengcheng, and the tide turning.</p></div>
  <div><b>5 · Empire</b><small> 202–195 BC</small><p>Gaixia, the throne, the purge, and the Great Wind.</p></div>
</div>
"""


def build_meta():
    return {
        'pid': 'gm-liubang.html', 'kind': 'man', 'emoji': '🐉', 'accent': AC,
        'name': 'Liu Bang', 'years': 'c. 256–195 BC', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The peasant who founded the Han — beaten in every battle but the last by the brilliant Xiang Yu, he out-used better men to win the empire, spared the Qin capital with three simple laws, and gave his name to a people.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'origins', 'label': '1 · Origins', 'type': 'timeline',
             'intro': 'A peasant of Pei — a generous, hard-drinking pavilion chief with a rare gift for friendship — drifts into outlawry as the harsh Qin order begins to crack.', 'events': LB1},
            {'id': 'uprising', 'label': '2 · The Pei Uprising', 'type': 'timeline',
             'intro': 'When Chen Sheng’s revolt lights the empire, the men of Pei make Liu Bang their lord; he joins the Chu cause and races west for the great prize of Guanzhong.', 'events': LB2},
            {'id': 'qin', 'label': '3 · Fall of Qin & Hongmen', 'type': 'timeline',
             'intro': 'First into the passes, he spares the Qin capital and wins the people with three simple laws — then barely escapes death at Xiang Yu’s banquet at Hongmen.', 'events': LB3},
            {'id': 'chuhan', 'label': '4 · The Chu–Han War', 'type': 'timeline',
             'intro': 'Exiled to Hanzhong, he raises the peerless Han Xin, storms back through Chencang, survives the catastrophe of Pengcheng, and slowly turns a losing war.', 'events': LB4},
            {'id': 'empire', 'label': '5 · Empire & Reckoning', 'type': 'timeline',
             'intro': 'Encircling Xiang Yu at Gaixia, he wins the world and founds the Han — then spends his last years breaking the very allies who won it for him, and dies singing at home.', 'events': LB5},
            {'id': 'order', 'label': '6 · The Han Order', 'type': 'timeline',
             'intro': 'Behind the wars, the founder builds a state: a compromise between Qin centralism and old feudalism, the grudging embrace of Confucian ritual, and a light-handed recovery that let a broken China heal — the foundation of four Han centuries.', 'events': LB6,
             'sources': SOURCES, 'srcnote': 'Chiefly Sima Qian’s Records of the Grand Historian (Shiji) and the Book of Han; several episodes (omens, the white serpent, set speeches) are traditional and are read as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER, 'auto': True},
        ],
    }
