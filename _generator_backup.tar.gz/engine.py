# -*- coding: utf-8 -*-
"""Engine for Da Vinci 'Great Men / Great Eras' guides.
Renders self-contained guide pages + grouped landing pages that match the hub's
design language, plus SVG diagram helpers and the hub inject-boilerplate.
"""
import html as ihtml, json, base64, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
INJECT = open(os.path.join(HERE, "inject_template.txt"), encoding="utf-8").read()

def esc(s):
    return ihtml.escape(str(s), quote=True)

def inject_boilerplate(html_str, pid):
    """Append the hub link-rewrite + deep-state boilerplate (FAMILY/ENTRY off)."""
    snip = (INJECT.replace('__PID__', json.dumps(pid))
                  .replace('__FAMILY__', 'null')
                  .replace('__ENTRY__', 'false'))
    low = html_str.lower()
    i = low.rfind('</body>')
    if i == -1:
        i = low.rfind('</html>')
    return (html_str + snip) if i == -1 else (html_str[:i] + snip + html_str[i:])

def b64(html_str):
    return base64.b64encode(html_str.encode('utf-8')).decode('ascii')

import zlib
def b64gz(html_str):
    """Raw-DEFLATE + base64, tagged 'RAW:' so the hub resolver inflates it via pako."""
    raw = html_str.encode('utf-8')
    co = zlib.compressobj(9, zlib.DEFLATED, -15)
    comp = co.compress(raw) + co.flush()
    return 'RAW:' + base64.b64encode(comp).decode('ascii')

def b64gz_bytes(raw_bytes):
    """Same as b64gz but for already-encoded bytes (e.g. an original asset's decoded HTML)."""
    co = zlib.compressobj(9, zlib.DEFLATED, -15)
    comp = co.compress(raw_bytes) + co.flush()
    return 'RAW:' + base64.b64encode(comp).decode('ascii')

def unraw(v):
    """Inverse of b64gz for verification: returns decoded bytes for 'RAW:'-tagged or plain base64."""
    if v.startswith('RAW:'):
        return zlib.decompress(base64.b64decode(v[4:]), -15)
    return base64.b64decode(v)

# ---------------------------------------------------------------- tag palette
TAGS = {
    'RISE':          '#16a34a',
    'BATTLE':        '#dc2626',
    'POLITICS':      '#4f46e5',
    'REFORM':        '#0891b2',
    'TURNING POINT': '#d97706',
    'TRIUMPH':       '#7c3aed',
    'DEFEAT':        '#475569',
    'TRAGEDY':       '#9f1239',
    'LOVE':          '#db2777',
    'EXILE':         '#57534e',
    'DEATH':         '#111827',
}

# six concept-map branches (number, heading, color, key)
BRANCHES = [
    ('①', 'Background — why it happened', '#64748b', 'bg'),
    ('②', 'Key people',                   '#4f46e5', 'people'),
    ('③', 'What happened',                '#2563eb', 'what'),
    ('④', 'The crux — the mechanism',     '#d97706', 'crux'),
    ('⑤', 'Consequences',                 '#e11d48', 'conseq'),
    ('⑥', 'Why it matters (remember this)','#16a34a', 'matters'),
]

# =====================================================================  SVG
# A tiny diagram grammar producing genuinely explanatory, labelled diagrams:
# titled panel, numbered boxes, cause->effect arrows carrying text, takeaway strip.

def _defs():
    return ('<defs>'
            '<marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
            '<path d="M0,0 L10,5 L0,10 z" fill="#94a3b8"/></marker>'
            '<marker id="ahA" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
            '<path d="M0,0 L10,5 L0,10 z" fill="#d97706"/></marker>'
            '</defs>')

def _wrap(vb_w, vb_h, title, body, takeaway, accent):
    tk = ''
    if takeaway:
        ty = vb_h - 30
        tk = (f'<rect x="16" y="{ty}" width="{vb_w-32}" height="30" rx="8" fill="{accent}"/>'
              f'<text x="30" y="{ty+19}" font-size="12.5" font-weight="800" fill="#fff">★ {esc(takeaway)}</text>')
    ttl = (f'<text x="20" y="26" font-size="14.5" font-weight="800" fill="#1c2431">{esc(title)}</text>'
           if title else '')
    return (f'<svg class="dg" viewBox="0 0 {vb_w} {vb_h}" xmlns="http://www.w3.org/2000/svg" '
            f'font-family="-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif" role="img">'
            f'{_defs()}{ttl}{body}{tk}</svg>')

def _tspans(x, y, text, size, color, weight, lh, maxc):
    """word-wrap into <text>/<tspan> lines. returns (svg, lines_used)."""
    words = str(text).split()
    lines, cur = [], ''
    for w in words:
        if len(cur) + len(w) + 1 <= maxc:
            cur = (cur + ' ' + w).strip()
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    if not lines:
        lines = ['']
    out = f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}">'
    for i, ln in enumerate(lines):
        dy = 0 if i == 0 else lh
        out += f'<tspan x="{x}" dy="{dy}">{esc(ln)}</tspan>'
    out += '</text>'
    return out, len(lines)

def svg_row(title, boxes, edge_labels=None, takeaway='', accent='#4f46e5'):
    """Horizontal pipeline: numbered boxes L->R joined by labelled cause arrows."""
    n = len(boxes)
    W = 720
    pad = 20
    gap = 36
    bw = int((W - 2*pad - gap*(n-1)) / n)
    top = 52
    bh = 96
    body = ''
    for i, b in enumerate(boxes):
        x = pad + i*(bw+gap)
        col = b.get('color', accent)
        body += f'<rect x="{x}" y="{top}" width="{bw}" height="{bh}" rx="12" fill="#fff" stroke="{col}" stroke-width="1.8"/>'
        body += f'<circle cx="{x+16}" cy="{top+16}" r="10" fill="{col}"/><text x="{x+16}" y="{top+20}" font-size="11" font-weight="800" fill="#fff" text-anchor="middle">{b.get("n", i+1)}</text>'
        s1, _ = _tspans(x+32, top+20, b.get('label', ''), 12, col, 800, 13, max(6, int((bw-38)/6.6)))
        body += s1
        s2, _ = _tspans(x+12, top+52, b.get('sub', ''), 10.5, '#5b6472', 500, 12, max(8, int((bw-20)/5.4)))
        body += s2
        if i < n-1:
            ax = x+bw
            ax2 = x+bw+gap
            my = top+bh/2
            body += f'<line x1="{ax+2}" y1="{my}" x2="{ax2-2}" y2="{my}" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
            if edge_labels and i < len(edge_labels) and edge_labels[i]:
                el, _ = _tspans((ax+ax2)/2, my-8, edge_labels[i], 8.5, '#94a3b8', 700, 9, 7)
                # center the small edge label
                el = f'<g text-anchor="middle">{el}</g>'
                body += el
    H = top+bh+ (46 if takeaway else 16)
    return _wrap(W, H, title, body, takeaway, accent)

def svg_stack(title, boxes, takeaway='', accent='#4f46e5'):
    """Vertical flow: numbered boxes top->down joined by down-arrows."""
    W = 720
    pad = 20
    bw = W - 2*pad
    top = 46
    bh = 56
    vg = 20
    body = ''
    y = top
    for i, b in enumerate(boxes):
        col = b.get('color', accent)
        body += f'<rect x="{pad}" y="{y}" width="{bw}" height="{bh}" rx="12" fill="#fff" stroke="{col}" stroke-width="1.8"/>'
        body += f'<circle cx="{pad+18}" cy="{y+bh/2}" r="12" fill="{col}"/><text x="{pad+18}" y="{y+bh/2+4}" font-size="12" font-weight="800" fill="#fff" text-anchor="middle">{b.get("n", i+1)}</text>'
        lab, _ = _tspans(pad+40, y+22, b.get('label',''), 12.5, col, 800, 13, 88)
        body += lab
        sub, _ = _tspans(pad+40, y+40, b.get('sub',''), 10.5, '#5b6472', 500, 12, 108)
        body += sub
        if i < len(boxes)-1:
            cx = pad+bw/2
            body += f'<line x1="{cx}" y1="{y+bh}" x2="{cx}" y2="{y+bh+vg}" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
        y += bh+vg
    H = y + (34 if takeaway else 6)
    return _wrap(W, H, title, body, takeaway, accent)

def svg_compare(title, left, right, verdict='', takeaway='', accent='#4f46e5'):
    """Two-column force comparison. left/right = {head,color,items:[...]}"""
    W = 720
    pad = 20
    colw = 300
    top = 50
    def col(x, d):
        c = d.get('color', accent)
        rows = d.get('items', [])
        h = 44 + len(rows)*22 + 12
        s = f'<rect x="{x}" y="{top}" width="{colw}" height="{h}" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        s += f'<rect x="{x}" y="{top}" width="{colw}" height="30" rx="12" fill="{c}"/><rect x="{x}" y="{top+16}" width="{colw}" height="14" fill="{c}"/>'
        s += f'<text x="{x+14}" y="{top+20}" font-size="12.5" font-weight="800" fill="#fff">{esc(d.get("head",""))}</text>'
        yy = top+48
        for it in rows:
            s += f'<circle cx="{x+16}" cy="{yy-4}" r="3" fill="{c}"/>'
            ln, _ = _tspans(x+26, yy, it, 10.6, '#334155', 500, 12, 46)
            s += ln
            yy += 22
        return s, h
    ls, lh = col(pad, left)
    rs, rh = col(pad+colw+40, right)
    body = ls+rs
    midx = pad+colw+20
    body += f'<text x="{midx}" y="{top+ max(lh,rh)/2}" font-size="16" font-weight="800" fill="#94a3b8" text-anchor="middle">vs</text>'
    H = top+max(lh, rh)
    if verdict:
        vy = H+8
        body += f'<rect x="{pad}" y="{vy}" width="{W-2*pad}" height="26" rx="8" fill="#eef0fb"/>'
        body += f'<text x="{W/2}" y="{vy+17}" font-size="11.5" font-weight="700" fill="#4f46e5" text-anchor="middle">{esc(verdict)}</text>'
        H = vy+26
    H += (40 if takeaway else 10)
    return _wrap(W, H, title, body, takeaway, accent)

# ============================================================  PAGE CSS / JS
GUIDE_CSS = r"""
*{box-sizing:border-box}
html,body{margin:0}
body{--ac:#4f46e5;--ink:#1c2431;--dim:#6b7280;--line:#e7e9ee;--line2:#dcdfe6;--bg:#f6f7f9;--panel:#fff;
  background:var(--bg);color:var(--ink);
  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,Helvetica,Arial,sans-serif;
  -webkit-font-smoothing:antialiased;line-height:1.6}
a{color:inherit}
.gp{max-width:1080px;margin:0 auto;padding:0 20px 90px}
.ghd{padding:26px 2px 6px}
.gback{display:inline-flex;align-items:center;gap:7px;font-size:12.5px;font-weight:700;letter-spacing:.02em;
  color:var(--ac);text-decoration:none;padding:6px 12px;border:1px solid var(--line2);border-radius:999px;background:var(--panel);transition:.15s}
.gback:hover{transform:translateX(-2px);border-color:var(--ac)}
.gtitrow{display:flex;align-items:baseline;gap:12px;flex-wrap:wrap;margin:16px 0 0}
.gemoji{font-size:30px;line-height:1}
.gtitrow h1{font-size:clamp(26px,4.4vw,40px);line-height:1.04;letter-spacing:-.02em;margin:0;font-weight:820;
  background:linear-gradient(120deg,var(--ink),var(--ac));-webkit-background-clip:text;background-clip:text;color:transparent}
.gyears{font-size:14px;font-weight:700;color:var(--dim);letter-spacing:.02em}
.ggroup{font-size:11px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);margin:14px 0 0}
.gepi{font-size:16.5px;line-height:1.55;color:#43506a;max-width:720px;margin:8px 0 0}
.gtabs{position:sticky;top:0;z-index:40;display:flex;gap:2px;overflow-x:auto;scrollbar-width:none;
  margin:20px -20px 0;padding:6px 20px;background:rgba(246,247,249,.92);-webkit-backdrop-filter:blur(9px);backdrop-filter:blur(9px);
  border-bottom:1px solid var(--line)}
.gtabs::-webkit-scrollbar{display:none}
.gtab{flex:0 0 auto;cursor:pointer;border:0;background:transparent;font:inherit;font-size:13px;font-weight:650;color:var(--dim);
  padding:9px 13px;border-radius:9px 9px 0 0;position:relative;white-space:nowrap;transition:.12s}
.gtab:hover{color:var(--ink);background:rgba(79,70,229,.06)}
.gtab.active{color:var(--ac);font-weight:800}
.gtab.active::after{content:"";position:absolute;left:10px;right:10px;bottom:-1px;height:2.5px;border-radius:3px;background:var(--ac)}
.gbody{display:grid;grid-template-columns:1fr 216px;gap:28px;margin-top:22px;align-items:start}
.gtoc{position:sticky;top:60px;font-size:12.5px}
.gtoc .toc-k{font-size:10.5px;font-weight:800;letter-spacing:.13em;text-transform:uppercase;color:var(--dim);margin:0 0 10px}
.gtoc a{display:block;color:var(--dim);text-decoration:none;padding:5px 10px;border-left:2px solid var(--line);
  margin-bottom:2px;line-height:1.35;transition:.12s}
.gtoc a:hover{color:var(--ink);border-left-color:var(--line2)}
.gtoc a.on{color:var(--ac);border-left-color:var(--ac);font-weight:700;background:rgba(79,70,229,.05)}
.gpane{display:none;animation:gfade .25s ease}
.gpane.active{display:block}
@keyframes gfade{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}

/* ---- overview blocks ---- */
.ov-lead{font-size:17px;line-height:1.7;color:#2b3444;max-width:760px}
.ov-lbl{font-size:11.5px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--ac);margin:32px 0 12px;display:flex;align-items:center;gap:10px}
.ov-lbl::after{content:"";flex:1;height:1px;background:var(--line)}
.ov-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:13px}
.ov-card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:16px 17px;box-shadow:0 1px 2px rgba(20,25,40,.04),0 7px 20px rgba(20,25,40,.045)}
.ov-card .i{font-size:21px;line-height:1}
.ov-card h4{margin:9px 0 4px;font-size:14.5px;font-weight:760}
.ov-card p{margin:0;font-size:13px;line-height:1.5;color:#5b6472}
.ov-quote{border-left:3px solid var(--ac);padding:6px 0 6px 18px;margin:20px 0;font-size:16px;font-style:italic;color:#3a465c;max-width:720px}
.ov-quote span{display:block;font-style:normal;font-size:12.5px;font-weight:700;color:var(--dim);margin-top:6px}
.ov-arc{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-top:6px}
.ov-arc div{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:12px 13px}
.ov-arc b{display:block;font-size:12.5px;color:var(--ac)}
.ov-arc small{color:var(--dim);font-size:11.5px}
.ov-arc p{margin:5px 0 0;font-size:12.5px;color:#43506a;line-height:1.45}

/* ---- timeline ---- */
.tl{position:relative;margin:6px 0 0;padding-left:26px}
.tl::before{content:"";position:absolute;left:7px;top:8px;bottom:8px;width:2px;background:linear-gradient(var(--line2),var(--line))}
.ev{position:relative;margin:0 0 16px}
.ev-h{display:block;width:100%;text-align:left;cursor:pointer;border:1px solid var(--line);background:var(--panel);
  border-radius:14px;padding:15px 17px 14px;font:inherit;color:inherit;box-shadow:0 1px 2px rgba(20,25,40,.04);transition:.15s;position:relative}
.ev-h:hover{border-color:var(--line2);box-shadow:0 6px 18px rgba(20,25,40,.07);transform:translateY(-1px)}
.ev-dot{position:absolute;left:-26px;top:20px;width:15px;height:15px;border-radius:50%;border:3px solid var(--bg);box-shadow:0 0 0 2px currentColor}
.ev-time{font-size:11.5px;font-weight:800;letter-spacing:.03em;color:var(--dim)}
.tags{display:inline-flex;gap:6px;flex-wrap:wrap;margin-left:10px;vertical-align:middle}
.tag{font-size:9.5px;font-weight:800;letter-spacing:.05em;color:#fff;padding:2.5px 7px;border-radius:999px}
.ev-t{margin:8px 0 3px;font-size:16.5px;font-weight:780;line-height:1.25}
.ev-s{margin:0;font-size:13.5px;color:#4a5568;line-height:1.5}
.ev-exp{display:inline-block;margin-top:9px;font-size:11.5px;font-weight:750;color:var(--ac)}
.ev-exp .car{display:inline-block;transition:transform .2s}
.ev.open .ev-h{border-color:var(--ac);border-bottom-left-radius:0;border-bottom-right-radius:0}
.ev.open .ev-exp .car{transform:rotate(90deg)}
.ev-map{display:none;border:1px solid var(--ac);border-top:0;border-radius:0 0 14px 14px;background:linear-gradient(#fff,#fbfbfe);padding:6px 17px 18px}
.ev.open .ev-map{display:block;animation:gfade .25s ease}
.hub{display:inline-flex;align-items:center;gap:9px;margin:12px 0 2px;padding:9px 16px;border-radius:999px;
  color:#fff;font-weight:800;font-size:14px;box-shadow:0 4px 14px rgba(20,25,40,.14)}
.hub::before{content:"◆";opacity:.85;font-size:11px}
.dgwrap{margin:12px 0 4px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:8px 10px;overflow:hidden}
.dg{display:block;width:100%;height:auto}
.branches{display:grid;grid-template-columns:1fr 1fr;gap:11px;margin-top:14px}
.br{border:1px solid var(--line);border-left:4px solid var(--bc);border-radius:11px;background:#fff;padding:12px 14px}
.br-h{font-size:12.5px;font-weight:800;color:var(--bc);margin-bottom:6px;display:flex;align-items:center;gap:7px;letter-spacing:.01em}
.br-n{font-size:14px}
.br-b{font-size:13px;line-height:1.62;color:#37425a}
.br-b b{color:#1c2431}
.br-b ul{margin:6px 0 0;padding-left:17px}
.br-b li{margin:3px 0}

/* ---- who's who ---- */
.who{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:13px}
.wc{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:15px 16px;box-shadow:0 1px 2px rgba(20,25,40,.04)}
.wc .wt{display:flex;align-items:baseline;gap:8px}
.wc h4{margin:0;font-size:15px;font-weight:770}
.wc .wr{font-size:10.5px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;padding:2px 7px;border-radius:999px;color:#fff}
.wc p{margin:8px 0 0;font-size:12.8px;line-height:1.5;color:#4a5568}
.wc .rel{margin-top:8px;font-size:11.5px;color:var(--dim);border-top:1px dashed var(--line2);padding-top:7px}
.wc .rel b{color:var(--ink)}

/* ---- key events reference ---- */
.kev{border:1px solid var(--line);border-radius:14px;overflow:hidden;background:#fff}
.kev table{border-collapse:collapse;width:100%;font-size:13px}
.kev th{background:#f1f3f6;text-align:left;padding:10px 13px;font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--dim);font-weight:800}
.kev td{padding:11px 13px;border-top:1px solid var(--line);vertical-align:top;line-height:1.45}
.kev tr:hover td{background:#fafbff}
.kev .kd{white-space:nowrap;font-weight:800;color:var(--ac);font-size:12px}
.kev .kn{font-weight:750}
.kev .ko{color:#4a5568}

/* ---- master timeline ---- */
.mt{position:relative;padding-left:130px}
.mt::before{content:"";position:absolute;left:118px;top:6px;bottom:6px;width:2px;background:var(--line2)}
.mtr{position:relative;margin-bottom:15px}
.mtr .yr{position:absolute;left:-130px;width:104px;text-align:right;font-size:12.5px;font-weight:800;color:var(--ac)}
.mtr .yr small{display:block;font-size:10.5px;color:var(--dim);font-weight:600}
.mtr .dot{position:absolute;left:-18px;top:4px;width:11px;height:11px;border-radius:50%;background:var(--ac);border:2.5px solid var(--bg);box-shadow:0 0 0 1.5px var(--ac)}
.mtr h4{margin:0;font-size:14px;font-weight:750}
.mtr p{margin:3px 0 0;font-size:12.7px;color:#4a5568;line-height:1.5;max-width:640px}
.mtr .ph{font-size:10px;font-weight:800;letter-spacing:.05em;text-transform:uppercase;color:#94a3b8}

/* ---- sources ---- */
.srcs{margin-top:26px;border-top:1px solid var(--line);padding-top:16px}
.srcs h4{font-size:11.5px;letter-spacing:.13em;text-transform:uppercase;color:var(--dim);margin:0 0 10px}
.srcs a{display:inline-block;font-size:12px;color:var(--ac);text-decoration:none;background:#eef0fb;border-radius:999px;padding:5px 11px;margin:0 7px 7px 0}
.srcs a:hover{text-decoration:underline}
.note{font-size:12px;color:var(--dim);font-style:italic;margin-top:10px}

@media(max-width:820px){
  .gbody{grid-template-columns:1fr}
  .gtoc{display:none}
  .branches{grid-template-columns:1fr}
}
"""

GUIDE_JS = r"""
(function(){
  var main=document.getElementById('gmain');
  function panes(){return Array.prototype.slice.call(document.querySelectorAll('.gpane'));}
  function tabs(){return Array.prototype.slice.call(document.querySelectorAll('.gtab'));}
  function buildTOC(pid){
    var toc=document.getElementById('gtoc'); if(!toc)return;
    var pane=document.querySelector('.gpane[data-pane="'+pid+'"]'); if(!pane){toc.innerHTML='';return;}
    var items=pane.querySelectorAll('[data-toc]');
    if(!items.length){toc.innerHTML='';return;}
    var h='<div class="toc-k">On this tab</div>';
    Array.prototype.forEach.call(items,function(el){
      h+='<a href="#'+el.id+'" data-to="'+el.id+'">'+el.getAttribute('data-toc')+'</a>';
    });
    toc.innerHTML=h;
    Array.prototype.forEach.call(toc.querySelectorAll('a'),function(a){
      a.addEventListener('click',function(e){e.preventDefault();var t=document.getElementById(a.getAttribute('data-to'));
        if(t){var ev=t.closest('.ev'); if(ev&&!ev.classList.contains('open')){openEv(ev.querySelector('.ev-h'));}
          var y=t.getBoundingClientRect().top+window.pageYOffset-58; window.scrollTo({top:y,behavior:'smooth'});}
      });
    });
  }
  window.gtab=function(name,noscroll){
    tabs().forEach(function(t){t.classList.toggle('active',t.getAttribute('data-pane')===name);});
    panes().forEach(function(p){p.classList.toggle('active',p.getAttribute('data-pane')===name);});
    buildTOC(name);
    try{location.hash=name;}catch(e){}
    if(!noscroll)window.scrollTo({top:0});
    var at=document.querySelector('.gtab.active'); if(at&&at.scrollIntoView)at.scrollIntoView({block:'nearest',inline:'center'});
  };
  function openEv(btn){ if(!btn)return; var ev=btn.closest('.ev'); if(!ev)return;
    var willOpen=!ev.classList.contains('open'); ev.classList.toggle('open',willOpen); btn.classList.toggle('active',willOpen);
  }
  window.gEv=openEv;
  // scroll-spy
  var spyT=null;
  window.addEventListener('scroll',function(){ if(spyT)return; spyT=setTimeout(function(){spyT=null;
    var toc=document.getElementById('gtoc'); if(!toc)return; var links=toc.querySelectorAll('a'); if(!links.length)return;
    var best=null,bd=1e9;
    Array.prototype.forEach.call(links,function(a){var t=document.getElementById(a.getAttribute('data-to'));if(!t)return;
      var d=Math.abs(t.getBoundingClientRect().top-70); if(d<bd){bd=d;best=a;}});
    links.forEach(function(a){a.classList.remove('on');}); if(best)best.classList.add('on');
  },120); },{passive:true});
  // init from hash
  var start=(location.hash||'').replace('#',''); var ok=false;
  if(start){tabs().forEach(function(t){if(t.getAttribute('data-pane')===start)ok=true;});}
  var first=tabs()[0];
  window.gtab(ok?start:(first?first.getAttribute('data-pane'):''),true);
})();
"""

def _branch_body(v):
    if isinstance(v, (list, tuple)):
        return '<ul>' + ''.join('<li>%s</li>' % x for x in v) + '</ul>'
    return str(v)

def render_event(ev, accent):
    tags = ''.join('<span class="tag" style="background:%s">%s</span>' % (TAGS.get(t, accent), esc(t)) for t in ev.get('tags', []))
    hubcol = TAGS.get(ev['tags'][0], accent) if ev.get('tags') else accent
    br = ''
    for num, head, col, key in BRANCHES:
        val = ev['branches'].get(key, '')
        br += ('<div class="br" style="--bc:%s"><div class="br-h"><span class="br-n">%s</span>%s</div>'
               '<div class="br-b">%s</div></div>') % (col, num, esc(head), _branch_body(val))
    toc = esc(ev.get('toc', ev['title']))
    return ('<article class="ev" id="ev-{id}" data-toc="{toc}">'
            '<button class="ev-h" onclick="gEv(this)">'
            '<span class="ev-dot" style="color:{dot}"></span>'
            '<span class="ev-time">{time}</span><span class="tags">{tags}</span>'
            '<h3 class="ev-t">{title}</h3><p class="ev-s">{summary}</p>'
            '<span class="ev-exp"><span class="car">▸</span> expand the concept map</span>'
            '</button>'
            '<div class="ev-map">'
            '<span class="hub" style="background:{dot}">{title}</span>'
            '<div class="dgwrap">{svg}</div>'
            '<div class="branches">{br}</div>'
            '</div></article>').format(
        id=ev['id'], toc=toc, dot=hubcol, time=esc(ev.get('time', '')), tags=tags,
        title=esc(ev['title']), summary=esc(ev.get('summary', '')), svg=ev.get('svg', ''), br=br)

def render_guide(meta):
    accent = meta.get('accent', '#4f46e5')
    tabs_html, panes_html = '', ''
    for t in meta['tabs']:
        tabs_html += '<button class="gtab" data-pane="%s" onclick="gtab(\'%s\')">%s</button>' % (t['id'], t['id'], esc(t['label']))
        inner = ''
        typ = t.get('type')
        if typ == 'timeline':
            if t.get('intro'):
                inner += '<p class="ov-lead" style="margin-bottom:18px">%s</p>' % t['intro']
            inner += '<div class="tl">' + ''.join(render_event(e, accent) for e in t['events']) + '</div>'
        elif typ == 'html':
            inner += t['html']
        elif typ == 'who':
            inner += '<div class="who">'
            for p in t['people']:
                inner += ('<div class="wc"><div class="wt"><h4>%s</h4><span class="wr" style="background:%s">%s</span></div>'
                          '<p>%s</p><div class="rel"><b>Link to %s:</b> %s</div></div>') % (
                    esc(p['name']), p.get('color', accent), esc(p.get('role', '')), esc(p['bio']),
                    esc(meta['name'].split()[0]), esc(p.get('rel', '')))
            inner += '</div>'
        elif typ == 'events':
            rows = ''.join('<tr><td class="kd">%s</td><td class="kn">%s</td><td class="ko">%s</td></tr>' % (
                esc(r[0]), esc(r[1]), esc(r[2])) for r in t['rows'])
            inner += '<div class="kev"><table><thead><tr><th>Date</th><th>Event</th><th>Why it mattered</th></tr></thead><tbody>%s</tbody></table></div>' % rows
        elif typ == 'master':
            rows = t.get('rows')
            if t.get('auto') or not rows:
                rows = []
                for tab in meta['tabs']:
                    if tab.get('type') == 'timeline':
                        plabel = re.sub(r'^\s*\d+\s*·\s*', '', tab.get('label', ''))
                        for e in tab['events']:
                            rows.append({'year': e.get('time', ''), 'phase': plabel,
                                         'title': e.get('title', ''), 'desc': e.get('summary', '')})
            inner += '<div class="mt">'
            for r in rows:
                inner += ('<div class="mtr"><div class="yr">%s<small>%s</small></div><div class="dot"></div>'
                          '<div class="ph">%s</div><h4>%s</h4><p>%s</p></div>') % (
                    esc(r.get('year', '')), esc(r.get('age', '')), esc(r.get('phase', '')), esc(r['title']), esc(r.get('desc', '')))
            inner += '</div>'
        if t.get('sources'):
            src = ''.join('<a href="%s" target="_blank" rel="noopener">%s ↗</a>' % (esc(u), esc(n)) for n, u in t['sources'])
            note = ('<p class="note">%s</p>' % esc(t['srcnote'])) if t.get('srcnote') else ''
            inner += '<div class="srcs"><h4>Sources</h4>%s%s</div>' % (src, note)
        panes_html += '<section class="gpane" data-pane="%s">%s</section>' % (t['id'], inner)

    back_file, back_lbl = meta['back']
    doc = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
           '<meta name="viewport" content="width=device-width,initial-scale=1">'
           '<title>%s — Da Vinci</title><style>%s</style></head><body style="--ac:%s">'
           '<div class="gp"><header class="ghd">'
           '<a class="gback" href="#" data-nav="%s">← %s</a>'
           '<div class="ggroup">%s</div>'
           '<div class="gtitrow"><span class="gemoji">%s</span><h1>%s</h1><span class="gyears">%s</span></div>'
           '<p class="gepi">%s</p>'
           '<nav class="gtabs" id="gtabs">%s</nav></header>'
           '<div class="gbody"><main class="gmain" id="gmain">%s</main>'
           '<aside class="gtoc" id="gtoc"></aside></div></div>'
           '<script>%s</script>'+NAV_JS+'</body></html>') % (
        esc(meta['name']), GUIDE_CSS, accent, esc(back_file), esc(back_lbl), esc(meta.get('group', '')),
        meta.get('emoji', '👑'), esc(meta['name']), esc(meta.get('years', '')), meta.get('epithet', ''),
        tabs_html, panes_html, GUIDE_JS)
    return doc

# ============================================================  LANDING PAGE
LANDING_CSS = r"""
*{box-sizing:border-box}html,body{margin:0}
body{--ac:#4f46e5;--ink:#1c2431;--dim:#6b7280;--line:#e7e9ee;--line2:#dcdfe6;--bg:#f6f7f9;--panel:#fff;
  background:radial-gradient(1100px 520px at 12% -12%,rgba(79,70,229,.07),transparent 60%),radial-gradient(900px 480px at 100% 0%,rgba(124,108,255,.07),transparent 55%),var(--bg);
  color:var(--ink);min-height:100vh;
  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,Helvetica,Arial,sans-serif;-webkit-font-smoothing:antialiased}
.lw{max-width:1040px;margin:0 auto;padding:46px 24px 90px}
.lkick{font-size:12px;letter-spacing:.16em;text-transform:uppercase;color:var(--ac);font-weight:800}
.lh1{font-size:clamp(32px,5vw,50px);line-height:1.05;letter-spacing:-.02em;margin:12px 0 0;font-weight:840;
  background:linear-gradient(120deg,var(--ink),var(--ac));-webkit-background-clip:text;background-clip:text;color:transparent}
.ltag{font-size:18px;line-height:1.6;color:#43506a;max-width:680px;margin:16px 0 0}
.lsearch{position:sticky;top:0;z-index:9;display:flex;align-items:center;gap:12px;margin:26px 0 0;padding:12px 0;
  background:linear-gradient(var(--bg) 72%,rgba(246,247,249,0))}
.lsearch .ico{position:absolute;margin-left:16px;font-size:15px;opacity:.5;pointer-events:none}
.lsearch input{flex:1;font-size:15.5px;padding:13px 16px 13px 42px;border:1.5px solid var(--line2);border-radius:13px;
  background:var(--panel);color:var(--ink);outline:none;transition:border-color .15s,box-shadow .15s;
  box-shadow:0 1px 2px rgba(20,25,40,.04)}
.lsearch input:focus{border-color:var(--ac);box-shadow:0 0 0 3px rgba(79,70,229,.13)}
.lsearch .ct2{font-size:12px;font-weight:800;color:var(--dim);white-space:nowrap}
.lnomatch{display:none;margin:34px 2px;font-size:14.5px;color:var(--dim)}
.lgrp{margin:44px 0 0}
.lgrp-h{display:flex;align-items:baseline;gap:12px;margin:0 0 4px}
.lgrp-h h2{font-size:19px;font-weight:800;margin:0;letter-spacing:-.01em}
.lgrp-h .ct{font-size:11.5px;font-weight:800;color:var(--dim);background:var(--panel);border:1px solid var(--line);border-radius:999px;padding:3px 9px}
.lgrp-b{font-size:13.5px;color:var(--dim);margin:0 0 16px}
.lgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(244px,1fr));gap:15px}
.pc{position:relative;display:flex;flex-direction:column;background:var(--panel);border:1px solid var(--line);border-radius:16px;
  padding:18px 19px;box-shadow:0 1px 2px rgba(20,25,40,.05),0 8px 22px rgba(20,25,40,.05);text-decoration:none;color:inherit;
  transition:transform .15s,border-color .15s,box-shadow .15s;min-height:150px}
.pc.live:hover{transform:translateY(-4px);border-color:var(--ac);box-shadow:0 14px 32px rgba(40,45,90,.13)}
.pc .em{font-size:27px;line-height:1}
.pc .nm{font-size:17.5px;font-weight:800;margin:11px 0 0;letter-spacing:-.01em}
.pc .yr{font-size:12px;font-weight:700;color:var(--dim);margin-top:2px}
.pc .bl{font-size:13px;color:#4a5568;line-height:1.5;margin:9px 0 0;flex:1}
.pc .go{margin-top:12px;font-size:12px;font-weight:800;color:var(--ac)}
.pc .badge{position:absolute;top:14px;right:14px;font-size:9.5px;font-weight:800;letter-spacing:.05em;text-transform:uppercase;
  padding:3px 9px;border-radius:999px}
.pc.live .badge{color:#166534;background:#dcfce7}
.pc.soon{opacity:.72;cursor:default}
.pc.soon .badge{color:#92600e;background:#fef3c7}
.pc.soon .go{color:var(--dim)}
.lfoot{margin-top:52px;border-top:1px solid var(--line);padding-top:16px;font-size:12.5px;color:var(--dim);max-width:720px;line-height:1.6}
"""


NAV_JS = r"""<script>(function(){
  function iblob(name){
    var LA={}; try{LA=window.__DVH_LOCAL__||{};}catch(e){}
    var b64=LA[name];
    if(b64){ try{
      var raw=atob(b64), n=raw.length, arr=new Uint8Array(n);
      for(var i=0;i<n;i++)arr[i]=raw.charCodeAt(i);
      var boot='<scr'+'ipt>window.__DVH_LOCAL__='+JSON.stringify(LA)+';<\/scr'+'ipt>';
      return URL.createObjectURL(new Blob([boot,arr],{type:'text/html'}));
    }catch(e){} }
    try{ if(window.top&&window.top.__HUB_RESOLVE__){var u=window.top.__HUB_RESOLVE__(name); if(u)return u;} }catch(e){}
    return null;
  }
  document.addEventListener('click',function(e){
    var a=e.target&&e.target.closest?e.target.closest('[data-nav]'):null; if(!a)return;
    var name=a.getAttribute('data-nav'); if(!name)return;
    e.preventDefault();
    // primary: ask the hub top window to navigate the viewer (works locally via file:// and hosted; scales to any number of pages)
    try{ if(window.top && window.top!==window){ window.top.postMessage({__dvhNav:name},'*'); return; } }catch(err){}
    // fallback (standalone / embedded map present): build the next blob in THIS iframe
    var u=iblob(name); if(u){ location.href=u; }
  });
})();</script>"""

def render_landing(meta):
    groups = ''
    for g in meta['groups']:
        cards = ''
        live = 0
        for p in g['people']:
            ready = p.get('ready', False)
            sattr = esc(' '.join([p.get('name', ''), p.get('years', ''), p.get('tag', ''),
                                  p.get('blurb', ''), g['name']]).lower())
            if ready:
                live += 1
                cards += ('<a class="pc live" href="#" data-nav="%s" data-s="%s"><span class="badge">Guide</span>'
                          '<span class="em">%s</span><div class="nm">%s</div><div class="yr">%s · %s</div>'
                          '<div class="bl">%s</div><div class="go">Open the complete story →</div></a>') % (
                    esc(p['file']), sattr, p.get('emoji', '👑'), esc(p['name']), esc(p.get('years', '')),
                    esc(p.get('tag', '')), esc(p.get('blurb', '')))
            else:
                cards += ('<div class="pc soon" data-s="%s"><span class="badge">Coming soon</span>'
                          '<span class="em">%s</span><div class="nm">%s</div><div class="yr">%s · %s</div>'
                          '<div class="bl">%s</div><div class="go">Queued</div></div>') % (
                    sattr, p.get('emoji', '👑'), esc(p['name']), esc(p.get('years', '')),
                    esc(p.get('tag', '')), esc(p.get('blurb', '')))
        total = len(g['people'])
        groups += ('<section class="lgrp"><div class="lgrp-h"><h2>%s</h2><span class="ct">%d guide%s · %d queued</span></div>'
                   '<p class="lgrp-b">%s</p><div class="lgrid">%s</div></section>') % (
            esc(g['name']), live, '' if live == 1 else 's', total-live, esc(g.get('blurb', '')), cards)
    search = ('<div class="lsearch"><span class="ico">🔎</span>'
              '<input id="psearch" type="search" autocomplete="off" spellcheck="false" '
              'placeholder="Search %d people by name, place, era or role…">'
              '<span class="ct2" id="pscount"></span></div>'
              '<div class="lnomatch" id="pnomatch">No matches — try another name, place or era.</div>') % _live_count(meta)
    doc = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
           '<meta name="viewport" content="width=device-width,initial-scale=1"><title>%s — Da Vinci</title>'
           '<style>%s</style></head><body><div class="lw">'
           '<div class="lkick">%s</div><h1 class="lh1">%s</h1><p class="ltag">%s</p>'
           '%s%s<div class="lfoot">%s</div></div>'+SEARCH_JS+NAV_JS+'</body></html>') % (
        esc(meta['title']), LANDING_CSS, esc(meta.get('kicker', '')), esc(meta['title']),
        esc(meta.get('tagline', '')), search, groups, meta.get('foot', ''))
    return doc


def _live_count(meta):
    return sum(1 for g in meta['groups'] for p in g['people'] if p.get('ready'))


SEARCH_JS = r"""<script>(function(){
  function norm(s){return (s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');}
  var inp=document.getElementById('psearch'), cnt=document.getElementById('pscount'),
      nom=document.getElementById('pnomatch');
  if(!inp)return;
  var cards=[].slice.call(document.querySelectorAll('.pc')),
      groups=[].slice.call(document.querySelectorAll('.lgrp'));
  cards.forEach(function(c){c.__s=norm(c.getAttribute('data-s')||c.textContent);});
  function apply(){
    var q=norm(inp.value.trim()), shown=0;
    cards.forEach(function(c){var ok=!q||c.__s.indexOf(q)>=0;c.style.display=ok?'':'none';if(ok)shown++;});
    groups.forEach(function(g){
      var any=g.querySelectorAll('.pc').length && [].some.call(g.querySelectorAll('.pc'),function(c){return c.style.display!=='none';});
      g.style.display=any?'':'none';
    });
    if(cnt)cnt.textContent=q?(shown+' match'+(shown===1?'':'es')):'';
    if(nom)nom.style.display=(q&&shown===0)?'block':'none';
  }
  inp.addEventListener('input',apply);
  inp.addEventListener('keydown',function(e){if(e.key==='Escape'){inp.value='';apply();}});
})();</script>"""
