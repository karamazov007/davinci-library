# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Tokugawa Ieyasu."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#166534'  # pine green

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_cuckoo():
    """The three unifiers, via the famous hototogisu (cuckoo) proverb."""
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the proverb of the silent cuckoo — three men, three temperaments</text>'
    men = [(40,'#dc2626','Nobunaga','“Kill it.”','the ruthless destroyer — smashes the old order'),
           (270,'#b45309','Hideyoshi','“Make it want to sing.”','the charmer — wins men by cunning & reward'),
           (500,'#166534','Ieyasu','“Wait until it sings.”','the patient one — outlives them both')]
    for x,c,name,quote,desc in men:
        b += f'<rect x="{x}" y="60" width="180" height="96" rx="12" fill="#fff" stroke="{c}" stroke-width="1.9"/>'
        b += f'<text x="{x+14}" y="82" font-size="12.5" font-weight="800" fill="{c}">{name}</text>'
        b += f'<text x="{x+14}" y="100" font-size="10" font-style="italic" fill="#334155">{esc(quote)}</text>'
        dd,_=_tspans(x+14,120,desc,9.5,'#5b6472',500,11,30); b+=dd
    b += '<text x="360" y="182" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">“Nobunaga made the rice-cake, Hideyoshi baked it — and Ieyasu ate it.”</text>'
    return _wrap(W, H, 'The three unifiers of Japan', _tk(b, W, H, 'Patience is a strategy: outlive the bold and the brilliant, and the prize falls to you.'), '', AC)

def svg_edo():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1590 · a “demotion” he turned into the foundation of power</text>'
    b += '<rect x="40" y="60" width="300" height="80" rx="12" fill="#fdecec" stroke="#b45309" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#b45309">Hideyoshi “rewards” him</text>'
    s1,_=_tspans(54,100,'move from his rich home provinces to the remote, marshy Kanto plain',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="80" rx="12" fill="#dcfce7" stroke="#166534" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#166534">Ieyasu builds Edo</text>'
    s2,_=_tspans(394,100,'a huge, defensible, fertile base far from rivals → the future Tokyo',10,'#166534',600,12,44); b+=s2
    b += '<line x1="340" y1="100" x2="378" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="168" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">The “exile” gave him a rich, self-contained power base out of everyone’s reach.</text>'
    return _wrap(W, H, 'The Kanto transfer — a demotion made a springboard', _tk(b, W, H, 'A setback on someone else’s terms can be a foundation if you build patiently on it.'), '', AC)

def svg_sekigahara():
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">21 OCT 1600 · the battle for all Japan — decided by a betrayal</text>'
    b += '<rect x="40" y="60" width="200" height="70" rx="12" fill="#dcfce7" stroke="#166534" stroke-width="1.8"/>'
    b += '<text x="52" y="82" font-size="11" font-weight="800" fill="#166534">EASTERN Army (Ieyasu)</text>'
    s1,_=_tspans(52,100,'outnumbered on the field at dawn',9.6,'#5b6472',500,11,32); b+=s1
    b += '<rect x="480" y="60" width="200" height="70" rx="12" fill="#fee2e2" stroke="#dc2626" stroke-width="1.8"/>'
    b += '<text x="492" y="82" font-size="11" font-weight="800" fill="#dc2626">WESTERN Army (Ishida)</text>'
    s2,_=_tspans(492,100,'larger — but riddled with secret deals',9.6,'#5b6472',500,11,32); b+=s2
    b += '<rect x="270" y="150" width="180" height="56" rx="12" fill="#fef9c3" stroke="#b45309" stroke-width="1.9"/>'
    b += '<text x="360" y="172" font-size="10.5" font-weight="800" fill="#b45309" text-anchor="middle">Kobayakawa defects</text>'
    b += '<text x="360" y="188" font-size="9.3" fill="#5b6472" text-anchor="middle">secretly bribed, he switches mid-battle</text>'
    b += '<line x1="360" y1="150" x2="200" y2="132" stroke="#166534" stroke-width="2" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="178" x2="540" y2="132" stroke="#dc2626" stroke-width="2" stroke-dasharray="5 4" marker-end="url(#ah)"/>'
    b += '<text x="360" y="132" font-size="10" fill="#334155" font-weight="700" text-anchor="middle">his turncoats fall on the Western flank → collapse</text>'
    return _wrap(W, H, 'Sekigahara — won before it was fought', _tk(b, W, H, 'He won the battle in the months before it, by secretly buying the enemy’s own generals.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE HOSTAGE
PHASE_HOSTAGE = [
    E('matsudaira', '1543', 'Born into a doomed little clan', ['RISE', 'TRAGEDY'],
      'Ieyasu was born the heir of the Matsudaira, a small, weak clan in Mikawa caught between two giants — the Imagawa to the east and the Oda to the west — so feeble that his own father had to pawn his infant son as a hostage just to survive.',
      svg_row('A weakling clan between two predators', [
          {'n': 1, 'label': 'The Matsudaira of Mikawa', 'sub': 'a minor clan with little land and less power', 'color': '#166534'},
          {'n': 2, 'label': 'Squeezed by two giants', 'sub': 'the Imagawa and Oda clans loom on either side', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A child pawned for survival', 'sub': 'the baby heir sent away as a hostage-guarantee', 'color': '#a16207'},
      ], edge_labels=['between', 'so'], takeaway='He started with nothing but a weak name and a hostage’s future — the lowest base of any of the unifiers.', accent=AC),
      bg='Sixteenth-century Japan was fractured among warring domains. The <b>Matsudaira</b> of Mikawa were minor players, too weak to stand alone against their powerful neighbours.',
      people='His father <b>Matsudaira Hirotada</b>, who ruled a shaky domain; the mighty <b>Imagawa</b> and <b>Oda</b> clans; the infant Takechiyo (the future Ieyasu).',
      what='Born <b>Matsudaira Takechiyo</b> in 1543, he was heir to a clan so weak that his father <b>sent him away as a hostage</b> — and he was even briefly seized by the rival Oda en route.',
      crux='He began at the very <b>bottom of the warlord ladder</b> — the opposite of Nobunaga’s or Hideyoshi’s launching points in their own ways.',
      conseq='This precariousness forced on him the patience and caution that became his signature, and eventually his advantage.',
      matters='A weak starting hand can teach patience that a strong one never does — early powerlessness can be a school for endurance.'),

    E('hostage', '1543–1560', 'A childhood as a hostage — the school of patience', ['RISE', 'TRAGEDY'],
      'Born to a weak clan crushed between two giants, he spends his childhood as a political hostage, passed between rival warlords — learning the endurance, self-control, and reading of power that will define him.',
      svg_stack('How captivity forged the patient man', [
          {'n': 1, 'label': 'Born to the weak Matsudaira clan', 'sub': 'a small domain (Mikawa) squeezed by giants', 'color': '#166534'},
          {'n': 2, 'label': 'Handed over as a hostage', 'sub': 'a child pawn between the Oda and Imagawa clans', 'color': '#b45309'},
          {'n': 3, 'label': 'Learns to endure & observe', 'sub': 'survival by patience, self-control, reading power', 'color': '#0891b2'},
      ], takeaway='Powerlessness taught him patience and observation — the very traits that would outlast stronger men.', accent=AC),
      bg='Japan’s <b>Sengoku (“Warring States”) period</b> was a century of civil war among feuding <b>daimyō</b> (warlords). Ieyasu was born in 1543 into the small, vulnerable <b>Matsudaira</b> clan.',
      people='The <b>Imagawa</b> and <b>Oda</b> clans, between whom the boy was passed as a hostage; his own precarious family.',
      what='As a child, the future Ieyasu was sent as a <b>political hostage</b> — even seized and traded between rival powers — spending his formative years as a pawn dependent on others’ goodwill.',
      crux='Utter powerlessness in youth taught him <b>patience, emotional control, and the careful reading of stronger men</b> — the opposite of reckless ambition, and the core of his life’s method.',
      conseq='He emerged disciplined, watchful, and skilled at survival — a young lord who understood that timing and endurance beat bravado.',
      matters='Early powerlessness can teach the most valuable strategic skill of all: patience. Ieyasu learned to wait, and waiting made him ruler of Japan.'),
]

# ==================================================================  PHASE 2 — THE ALLY
PHASE_ALLY = [
    E('firstbattles', '1558–1560', 'First blood — the Imagawa’s useful vassal', ['BATTLE', 'RISE'],
      'Released to fight as a front-line vassal of the Imagawa, the young Ieyasu proves himself in his first campaigns — capably supplying a fort and storming enemy positions — a promising captain still entirely in another lord’s service.',
      svg_stack('Proving himself in someone else’s war', [
          {'n': 1, 'label': 'Serves the Imagawa', 'sub': 'the hostage grown into a fighting vassal', 'color': '#166534'},
          {'n': 2, 'label': 'First commands, 1558–60', 'sub': 'relieves the fort of Terabe; storms Marune', 'color': '#a16207'},
          {'n': 3, 'label': 'Talent, but no freedom', 'sub': 'a capable young general — still nobody’s master', 'color': '#78716c'},
      ], takeaway='He showed real skill early — but as a tool of a greater lord, waiting for the chance to be his own.', accent=AC),
      bg='As he came of age, the Imagawa put their Matsudaira hostage-vassal to work leading troops on the front line of their wars against the Oda.',
      people='<b>Imagawa Yoshimoto</b>, his overlord; the Oda garrisons he attacked; his own loyal Mikawa retainers, who had waited for his return.',
      what='In his first campaigns (1558–60) Ieyasu <b>relieved the besieged fort of Terabe</b> and helped take the fortress of <b>Marune</b> — early proof of competence in the Imagawa cause, on the eve of Okehazama.',
      crux='He built a reputation for reliability <b>while still unfree</b> — banking credibility for the day independence became possible.',
      conseq='When Yoshimoto was killed at Okehazama months later, this proven young captain was ready to seize his own domain.',
      matters='Talent shown in service is not wasted — it is the reputation you cash the moment you get your freedom.'),

    E('okehazama', '1560', 'Freedom at Okehazama — hitching to a rising star', ['BATTLE', 'TURNING POINT'],
      'When the upstart Oda Nobunaga stuns Japan by destroying the great Imagawa clan in a surprise attack, Ieyasu seizes the moment to break free, reclaim his home domain, and ally with the winner.',
      svg_row('Reading the moment and switching sides', [
          {'n': 1, 'label': 'Nobunaga ambushes Imagawa', 'sub': 'Okehazama (1560): a huge army destroyed by a small one', 'color': '#dc2626'},
          {'n': 2, 'label': 'Ieyasu breaks free', 'sub': 'his overlord dead, he reclaims Mikawa', 'color': '#166534'},
          {'n': 3, 'label': 'Allies with Nobunaga', 'sub': 'a loyal, patient alliance with the rising power', 'color': '#16a34a'},
      ], edge_labels=['so', 'then'], takeaway='He read a sudden shift in power instantly and attached himself to the winning side — early, and for good.', accent=AC),
      bg='In <b>1560</b>, the warlord <b>Oda Nobunaga</b> destroyed the far larger army of the <b>Imagawa</b> — Ieyasu’s overlords — in a shock surprise attack at <b>Okehazama</b>.',
      people='<b>Oda Nobunaga</b>, the ruthless, brilliant unifier whose rise Ieyasu backed; the fallen Imagawa clan.',
      what='With the Imagawa shattered, Ieyasu <b>broke free</b>, secured his home province of <b>Mikawa</b>, and forged a lasting <b>alliance with Nobunaga</b> — one he kept loyally for over 20 years.',
      crux='He grasped the new balance of power immediately and <b>committed early to the rising man</b> — then, unusually, stayed loyal, building a reputation for reliability.',
      conseq='As Nobunaga’s trusted ally, Ieyasu consolidated his own base and grew steadily stronger while the giants fought.',
      matters='Spotting a decisive shift in power early — and backing the winner reliably — is how a small player survives and grows among giants.'),

    E('odaalliance', '1562', 'The Kiyosu Alliance — the bond that never broke', ['POLITICS', 'TURNING POINT'],
      'Freed by Okehazama, Ieyasu makes the defining choice of his early career: instead of fighting the rising Oda Nobunaga, he allies with him — and, almost uniquely in that age of betrayal, keeps that alliance faithfully for twenty years.',
      svg_row('A rare alliance kept to the end', [
          {'n': 1, 'label': 'Free after Okehazama', 'sub': 'the Imagawa broken; Ieyasu can choose his path', 'color': '#166534'},
          {'n': 2, 'label': 'Allies with Nobunaga, 1562', 'sub': 'the Kiyosu pact — junior partner to a rising power', 'color': '#a16207'},
          {'n': 3, 'label': 'Loyal for 20 years', 'sub': 'never betrays it — extraordinary in the Warring States', 'color': '#16a34a'},
      ], edge_labels=['then', 'and'], takeaway='In an age of endless treachery, his choice was consistency — reliability itself became a strategy.', accent=AC),
      bg='After Okehazama shattered the Imagawa, the young lords of central Japan scrambled to align. Nobunaga was the most dangerous rising power on Ieyasu’s western border.',
      people='<b>Oda Nobunaga</b>, the ruthless rising warlord; Ieyasu, the junior but trusted partner; the retainers on both sides who honoured the pact.',
      what='In 1562 Ieyasu concluded the <b>Kiyosu Alliance</b> with Nobunaga and secured his eastern flank — then held to it <b>faithfully for two decades</b>, until Nobunaga’s death, an almost unheard-of constancy for the era.',
      crux='He understood that a <b>reputation for reliability</b> was itself power — allies and enemies alike could predict and trust him.',
      conseq='The stable western border let him expand elsewhere, and his loyalty earned Nobunaga’s trust — and, later, everyone’s.',
      matters='In a world of betrayal, the person who can actually be relied upon holds a rare and compounding advantage.'),

    E('ikko', '1563–1564', 'The revolt within — the Ikkō-ikki', ['BATTLE', 'TRAGEDY', 'TURNING POINT'],
      'His deadliest early crisis comes not from a rival warlord but from within: a religious uprising of militant Buddhist leagues splits his own domain and even his own retainers, some of whom take up arms against him. Crushing it — and then reconciling with the rebels — teaches him how to bind men’s loyalty for good.',
      svg_row('A rebellion that split his own men', [
          {'n': 1, 'label': 'The Ikkō-ikki rise', 'sub': 'militant Buddhist leagues revolt in Mikawa', 'color': '#dc2626'},
          {'n': 2, 'label': 'His own vassals divide', 'sub': 'some retainers join the rebels against him', 'color': '#b45309'},
          {'n': 3, 'label': 'Crush, then reconcile', 'sub': 'he wins — then pardons and re-binds them', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He learned to defeat men and then win them back — turning rebels into loyal retainers rather than corpses.', accent=AC),
      bg='The <b>Ikkō-ikki</b> — fiercely independent leagues of militant True Pure Land Buddhists — were a major power in Ieyasu’s home province of <b>Mikawa</b>.',
      people='The Ikkō-ikki leagues and temples; the Ieyasu retainers torn between loyalty to their lord and their faith.',
      what='In <b>1563–64</b> the <b>Ikkō-ikki</b> of Mikawa rose against Ieyasu, and the revolt cut through his own vassal band, some of whom joined the rebels. Ieyasu <b>suppressed the uprising</b>, then largely <b>pardoned and reintegrated</b> the defectors rather than destroying them.',
      crux='He learned that <b>loyalty is rebuilt as much as enforced</b>: mercy toward beaten opponents could turn deadly enemies back into devoted followers.',
      conseq='He unified Mikawa firmly under his control and forged an unusually loyal, cohesive band of retainers — a core strength for the rest of his career.',
      matters='How you treat the defeated shapes your future. Ieyasu’s blend of force and reconciliation built the loyal following that carried him to the top.'),

    E('mikatagahara', '1573', 'Mikatagahara — a defeat he never forgot', ['BATTLE', 'DEFEAT'],
      'Rashly marching out to face the brilliant Takeda cavalry, he is crushed and barely escapes with his life — then commissions a portrait of himself in defeat to remember the lesson forever.',
      svg_row('Learning from a near-fatal humiliation', [
          {'n': 1, 'label': 'Faces the Takeda', 'sub': 'Takeda Shingen’s feared cavalry invades', 'color': '#dc2626'},
          {'n': 2, 'label': 'Rash battle → crushing loss', 'sub': 'marches out against advice; routed at Mikatagahara', 'color': '#b45309'},
          {'n': 3, 'label': 'Keeps a portrait of his shame', 'sub': 'commissions a picture of himself defeated — a lesson', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He turned a humiliating defeat into a permanent lesson in caution — literally hanging it on his wall.', accent=AC),
      bg='The <b>Takeda</b> clan under <b>Takeda Shingen</b> fielded perhaps the finest cavalry in Japan. In 1573 they invaded Ieyasu’s territory.',
      people='<b>Takeda Shingen</b>, the formidable rival warlord; Ieyasu’s retainers who begged him not to give battle.',
      what='Against advice, the young Ieyasu marched out and was <b>badly beaten at Mikatagahara</b>, escaping only by luck. Afterward he reportedly commissioned a <b>portrait of himself in his defeated, fearful state</b> to remind him never to be so rash again.',
      crux='He treated defeat as <b>data</b>: rather than hide the humiliation, he memorialised it to burn the lesson of caution into himself permanently.',
      conseq='He became markedly more careful and calculating — the patient, risk-averse strategist history remembers.',
      matters='The wisest response to failure is to extract and remember its lesson. Ieyasu made his worst defeat a lifelong teacher.'),

    E('takeda', '1575–1582', 'Outlasting the Takeda — patience rewarded', ['BATTLE', 'TRIUMPH'],
      'The rival who once crushed him dies, and his heir overreaches; alongside Nobunaga, Ieyasu grinds the once-mighty Takeda down and finally destroys them — absorbing their famed warriors and their eastern lands, and turning his greatest early enemy into a source of strength.',
      svg_row('Turning an old enemy into an asset', [
          {'n': 1, 'label': 'Nagashino, 1575', 'sub': 'with Nobunaga’s guns, the Takeda cavalry is broken', 'color': '#dc2626'},
          {'n': 2, 'label': 'The Takeda destroyed', 'sub': 'their overreaching heir is finished off by 1582', 'color': '#b45309'},
          {'n': 3, 'label': 'He absorbs their strength', 'sub': 'gains eastern provinces and famed Takeda retainers', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He outlived the rival who once humiliated him — and folded that rival’s best men into his own army.', accent=AC),
      bg='After Mikatagahara, the death of <b>Takeda Shingen</b> and the rashness of his son <b>Katsuyori</b> reversed the balance between Ieyasu and the Takeda.',
      people='<b>Takeda Katsuyori</b>, the overreaching heir; <b>Nobunaga</b>, Ieyasu’s ally; the veteran Takeda retainers Ieyasu later took into his own service.',
      what='At <b>Nagashino (1575)</b>, Ieyasu and Nobunaga shattered the Takeda cavalry with massed guns; by <b>1582</b> the Takeda were destroyed, and Ieyasu absorbed much of their <b>territory and their renowned warriors</b>.',
      crux='His <b>patience turned defeat into gain</b>: by outlasting a stronger enemy and then absorbing its people, he grew steadily rather than gambling.',
      conseq='Ieyasu emerged from the Takeda wars markedly stronger, with new lands and some of Japan’s finest soldiers in his service.',
      matters='Patience compounds. Ieyasu’s knack for outlasting rivals and absorbing their strength, rather than merely destroying them, is central to his rise.'),
]

# ==================================================================  PHASE 3 — SERVING HIDEYOSHI
PHASE_HIDEYOSHI = [
    E('nobuyasu', '1579', 'The terrible price of the alliance — a son ordered to die', ['POLITICS', 'TRAGEDY'],
      'The Oda alliance demands the cruellest sacrifice of Ieyasu’s life: on Nobunaga’s suspicion of disloyalty, Ieyasu forces his own first wife to be killed and orders his eldest son and heir, Nobuyasu, to commit ritual suicide — obedience bought with his own family’s blood.',
      svg_stack('Loyalty paid in a son’s life', [
          {'n': 1, 'label': 'Suspicion from Nobunaga', 'sub': 'Ieyasu’s wife and heir accused of Takeda collusion', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Lady Tsukiyama killed', 'sub': 'his estranged first wife is put to death', 'color': '#78716c'},
          {'n': 3, 'label': 'Nobuyasu ordered to seppuku', 'sub': 'his own heir made to take his life to satisfy his ally', 'color': '#166534'},
      ], takeaway='He kept the alliance by sacrificing the people closest to him — the coldest measure of his patience.', accent=AC),
      bg='By 1579 Ieyasu’s heir, <b>Matsudaira Nobuyasu</b>, and Ieyasu’s wife, <b>Lady Tsukiyama</b>, were suspected by Nobunaga of secret dealings with the enemy Takeda clan.',
      people='<b>Nobunaga</b>, who demanded action; <b>Lady Tsukiyama</b>, Ieyasu’s first wife; <b>Nobuyasu</b>, his talented eldest son and heir.',
      what='To preserve the vital alliance, Ieyasu <b>had his wife killed</b> and <b>ordered Nobuyasu to commit seppuku</b> — sacrificing his own family rather than break with the far stronger Nobunaga.',
      crux='He calculated that the <b>alliance was worth more than his heir</b> — a chillingly patient subordination of feeling to survival.',
      conseq='The loss haunted him, but it kept Nobunaga’s trust intact; his third son, the future Hidetada, would eventually inherit the shogunate.',
      matters='The patient long game can demand appalling short-term sacrifices — endurance sometimes means paying in what you love most.'),

    E('honnoji', '1582', 'Nobunaga betrayed — chaos and opportunity', ['POLITICS', 'TURNING POINT'],
      'Nobunaga is suddenly murdered by a treacherous general, throwing Japan into a scramble for power. A low-born officer, Hideyoshi, seizes the initiative — and Ieyasu bides his time.',
      svg_row('The board is upended overnight', [
          {'n': 1, 'label': 'Nobunaga assassinated (1582)', 'sub': 'betrayed by his general Akechi Mitsuhide at Honnō-ji', 'color': '#dc2626'},
          {'n': 2, 'label': 'Hideyoshi strikes fast', 'sub': 'avenges Nobunaga; grabs the succession', 'color': '#b45309'},
          {'n': 3, 'label': 'Ieyasu waits and watches', 'sub': 'consolidates his own lands; avoids overreach', 'color': '#166534'},
      ], edge_labels=['then', 'meanwhile'], takeaway='When chaos erupts, the bold grab first — but the patient position themselves for later.', accent=AC),
      bg='In <b>1582</b>, Nobunaga was betrayed and killed by his own general <b>Akechi Mitsuhide</b> at the temple of <b>Honnō-ji</b> — a sudden vacuum at the top of the unification project.',
      people='<b>Akechi Mitsuhide</b>, the traitor (crushed within days); <b>Toyotomi Hideyoshi</b>, Nobunaga’s brilliant low-born general who avenged him and seized power.',
      what='<b>Hideyoshi</b> moved with stunning speed to destroy Mitsuhide and outmanoeuvre rivals for Nobunaga’s legacy. Ieyasu, rather than gamble everything, <b>consolidated his own domains and waited</b>.',
      crux='Two temperaments on display: Hideyoshi’s <b>seize-the-moment</b> brilliance versus Ieyasu’s <b>patient positioning</b>. Ieyasu knew it was not yet his time.',
      conseq='Hideyoshi became the dominant power in Japan; Ieyasu became his most powerful — and most carefully watched — vassal.',
      matters='Not every opening is yours to take. Knowing when it is not your moment, and simply getting stronger, is its own decisive skill.'),

    E('igacrossing', '1582', 'The Iga crossing — a race through hostile country', ['BATTLE', 'TRAGEDY', 'TURNING POINT'],
      'Caught deep in enemy territory with only a handful of men when Nobunaga is murdered, Ieyasu makes a desperate dash home across the bandit-ridden Iga mountains — a near-death escape, guided by the legendary Hattori Hanzō and his ninja, that he never forgot.',
      svg_row('Escaping the trap of Honnō-ji', [
          {'n': 1, 'label': 'Stranded when Nobunaga dies', 'sub': 'far from home, tiny escort, enemies everywhere', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The dash across Iga', 'sub': 'through bandit country, evading hostile locals', 'color': '#166534'},
          {'n': 3, 'label': 'Guided by Hattori Hanzō', 'sub': 'Iga ninja shepherd him safely back to Mikawa', 'color': '#a16207'},
      ], edge_labels=['so', 'via'], takeaway='He survived the most dangerous days of his life by luck, nerve and the loyalty of ninja guides.', accent=AC),
      bg='When Nobunaga was killed at <b>Honnō-ji</b> in 1582, Ieyasu was travelling near Kyoto with only a small party — suddenly exposed in dangerous country amid the chaos.',
      people='<b>Hattori Hanzō</b>, his famed retainer with ties to the Iga ninja; the local warriors and bandits who threatened the route; his handful of companions.',
      what='Ieyasu made the perilous <b>Iga crossing</b>, slipping through hostile mountains back to his own domain with ninja assistance — one of the closest brushes with death in his long career.',
      crux='His survival hinged on <b>trusted, unconventional allies</b> and cool nerve under mortal threat — and taught him the value of such networks.',
      conseq='Safely home, he mobilised his forces to contest the post-Nobunaga scramble; he later rewarded the Iga men in his service.',
      matters='Fortunes turn on surviving the single worst day — and on having loyal, unlikely allies for exactly such moments.'),

    E('komaki', '1584–1590', 'Fighting Hideyoshi to a draw — then bowing', ['BATTLE', 'POLITICS'],
      'He fights the mighty Hideyoshi to a stalemate on the battlefield, then — recognising he cannot win outright — submits and becomes his loyal vassal, trading pride for survival and a future chance.',
      svg_row('When you can’t win, submit — on the best terms', [
          {'n': 1, 'label': 'Komaki–Nagakute (1584)', 'sub': 'fights Hideyoshi to a costly draw', 'color': '#166534'},
          {'n': 2, 'label': 'Can’t win outright', 'sub': 'Hideyoshi is too strong to defeat', 'color': '#b45309'},
          {'n': 3, 'label': 'Submits as a vassal', 'sub': 'bows, keeps his lands & army, waits again', 'color': '#16a34a'},
      ], edge_labels=['so', 'then'], takeaway='He swallowed his pride to preserve his strength — living to fight another, better day.', accent=AC),
      bg='After Nobunaga’s death, Ieyasu and Hideyoshi tested each other in the <b>Komaki–Nagakute</b> campaign (1584), which ended inconclusively.',
      people='<b>Toyotomi Hideyoshi</b>, now Japan’s dominant figure and eventual regent (kampaku).',
      what='Having fought Hideyoshi to a <b>draw</b>, Ieyasu judged he could not win a full war and <b>submitted as a vassal</b> — preserving his army and domains intact rather than risking everything.',
      crux='He chose <b>strategic submission over ruinous pride</b>: better to bow and keep his strength than fight on and lose it. His power survived, waiting.',
      conseq='He became Hideyoshi’s greatest vassal — and, crucially, kept his army and organisation intact for the day Hideyoshi would be gone.',
      matters='Submission can be a strategy. When you can’t win, bending — while keeping your strength — beats breaking.'),
]

# ==================================================================  PHASE 4 — SEIZING POWER
PHASE_SEIZE = [
    E('odawara', '1590', 'The Siege of Odawara — bringing down the Hōjō', ['BATTLE', 'POLITICS', 'TRIUMPH'],
      'As Hideyoshi’s vassal, Ieyasu helps crush the last great independent power in the east — the Hōjō clan — in a vast, almost bloodless siege of their fortress at Odawara, a campaign that ends the wars of unification and reshapes Ieyasu’s own fortunes.',
      svg_stack('The war that unified Japan — and moved Ieyasu', [
          {'n': 1, 'label': 'The Hōjō defy Hideyoshi', 'sub': 'the last major clan to resist the unifier', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Odawara besieged, 1590', 'sub': 'a huge, patient investment starves the fortress out', 'color': '#166534'},
          {'n': 3, 'label': 'The Hōjō fall', 'sub': 'unification completed; their vast Kantō lands come free', 'color': '#a16207'},
      ], takeaway='Helping end the last resistance also set up the “reward” that would make Ieyasu master of the east.', accent=AC),
      bg='By 1590 only the powerful <b>Hōjō</b> clan, in their great fortress of <b>Odawara</b>, still defied Hideyoshi’s unification of Japan.',
      people='<b>Toyotomi Hideyoshi</b>, the overlord; the <b>Hōjō</b> defenders; Ieyasu, a leading vassal in the besieging army.',
      what='Ieyasu joined Hideyoshi’s enormous <b>Siege of Odawara</b>, which reduced the Hōjō largely by encirclement and patience rather than slaughter. Their fall completed the unification of Japan.',
      crux='He watched Hideyoshi win by <b>overwhelming preparation and patience</b> — lessons he absorbed for his own later campaigns.',
      conseq='Hideyoshi then transferred Ieyasu to the newly-conquered <b>Kantō</b> — a move meant to weaken him that Ieyasu turned into his greatest asset.',
      matters='Serving loyally in another’s triumph can position you for your own — the reward you are handed may become your power base.'),

    E('edo', '1590', 'The Kanto transfer — a demotion made a springboard', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'Hideyoshi “rewards” him by moving him far from his home provinces to the remote, marshy Kanto plain — a subtle demotion. Ieyasu turns the swamp into Edo, the richest, most defensible base in Japan.',
      svg_edo(),
      bg='After the Siege of Odawara (1590), Hideyoshi offered Ieyasu the conquered <b>Kanto</b> region in exchange for his rich ancestral provinces — moving his most dangerous vassal <b>far from the capital</b>.',
      people='<b>Hideyoshi</b>, who intended the move to weaken Ieyasu; the fishing village of <b>Edo</b>, which Ieyasu chose as his base.',
      what='Ieyasu accepted and made the marshy Kanto his own: he chose <b>Edo</b> (later <b>Tokyo</b>) as his seat, drained and developed the land, and built a vast, fertile, defensible power base far from rivals.',
      crux='He turned an intended <b>demotion into an asset</b> — a large, self-contained domain, out of everyone’s reach, that he organised superbly while others fought near the capital.',
      conseq='Edo became the richest base in Japan and the future capital; Ieyasu grew quietly stronger than any rival while appearing to have been sidelined.',
      matters='A setback imposed on you can become a springboard if you build patiently on it. What looked like exile made Ieyasu untouchable.'),

    E('korea', '1592–1598', 'Husbanding strength while others bleed', ['POLITICS', 'TURNING POINT'],
      'While Hideyoshi pours Japan’s armies into the ruinous invasions of Korea, Ieyasu quietly keeps his own forces at home, developing his rich Kanto base and preserving his strength — so that when Hideyoshi dies, the great western lords are exhausted and Ieyasu is stronger than ever.',
      svg_row('Winning by not fighting', [
          {'n': 1, 'label': 'Hideyoshi invades Korea', 'sub': 'two vast, draining campaigns, 1592–98', 'color': '#dc2626'},
          {'n': 2, 'label': 'Ieyasu stays home', 'sub': 'commits little; builds up the Kanto instead', 'color': '#166534'},
          {'n': 3, 'label': 'Emerges relatively strong', 'sub': 'rivals bled white; his army intact', 'color': '#16a34a'},
      ], edge_labels=['while', 'so'], takeaway='He let his rivals waste themselves abroad while he grew richer and stronger at home — patience as strategy.', accent=AC),
      bg='From <b>1592</b> Hideyoshi launched two enormous <b>invasions of Korea</b>, which bled the western daimyō who bore the fighting.',
      people='<b>Hideyoshi</b>, whose obsession drained Japan; the western lords (like the Shimazu) worn down in Korea; Ieyasu, conspicuously spared the worst of it.',
      what='Positioned far to the east, Ieyasu <b>contributed relatively little to the Korean campaigns</b>, instead developing his <b>Kanto domain</b> and conserving his army, while many rival lords were <b>exhausted and impoverished</b> by the war.',
      crux='He practised <b>strategic patience</b>: letting a costly, doomed adventure weaken his competitors while he grew stronger by staying out of it.',
      conseq='When Hideyoshi died in 1598, Ieyasu was the strongest, freshest power in Japan — perfectly placed for the showdown at Sekigahara.',
      matters='Sometimes the winning move is to sit out the fight. Ieyasu’s restraint during the Korean wars set up his seizure of all Japan.'),

    E('gotairo', '1598–1600', 'The regent who broke the rules', ['POLITICS', 'TURNING POINT'],
      'When Hideyoshi dies leaving a five-year-old heir, he binds his five greatest lords by oath to protect the child — but Ieyasu, the strongest of them, immediately begins forging forbidden marriage alliances and building a faction, patiently pulling the coalition apart.',
      svg_stack('Undermining the trust he swore to keep', [
          {'n': 1, 'label': 'Hideyoshi dies, 1598', 'sub': 'leaves a boy heir, Hideyori, and five sworn regents', 'color': '#a16207'},
          {'n': 2, 'label': 'Ieyasu, first among the Five Elders', 'sub': 'the most powerful of the guardians of the child', 'color': '#166534'},
          {'n': 3, 'label': 'Breaks the marriage bans', 'sub': 'builds his own alliances, splitting the regency', 'color': '#b91c1c'},
      ], takeaway='He used the very position of trusted guardian to gather the strength to seize everything.', accent=AC),
      bg='Dying in 1598, Hideyoshi created a council of <b>Five Elders (Go-Tairō)</b> to rule until his son <b>Hideyori</b> came of age, forbidding them from private alliances.',
      people='the child <b>Hideyori</b>; rival regent <b>Ishida Mitsunari</b>, guardian of the Toyotomi loyalists; the other Elders, divided and outmanoeuvred.',
      what='As the strongest Elder, Ieyasu <b>deliberately broke the rules</b> — arranging marriages and courting daimyō to build his own bloc — provoking a split between his supporters and the loyalists around Mitsunari.',
      crux='He weaponised his role as <b>protector of the heir</b> to accumulate the alliances that would let him fight for the whole realm.',
      conseq='The manoeuvring polarised Japan into two camps, setting up the showdown at Sekigahara in 1600.',
      matters='The guardian of a weak heir is perfectly placed to usurp — trusted access is the ambitious person’s greatest opening.'),

    E('defections', '1600', 'Winning before the battle — the bought betrayal', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'Ieyasu’s greatest victory is arranged in secret before a sword is drawn: through months of letters and promises he suborns key enemy commanders — above all the young lord Kobayakawa Hideaki — so that at the decisive moment they will turn their coats and shatter the opposing army from within.',
      svg_row('The diplomacy that decided Sekigahara', [
          {'n': 1, 'label': 'Secret letters to the enemy', 'sub': 'promises of land and pardon to waverers before the battle', 'color': '#166534'},
          {'n': 2, 'label': 'Kobayakawa is turned', 'sub': 'the young lord agrees, secretly, to switch sides', 'color': '#a16207'},
          {'n': 3, 'label': 'Betrayal mid-battle', 'sub': 'his defection collapses the western army', 'color': '#b91c1c'},
      ], edge_labels=['wins', 'triggers'], takeaway='He fought the real battle with ink and promises weeks before the armies ever met.', accent=AC),
      bg='Both coalitions gathered huge armies for the showdown of 1600. Ieyasu, distrusting pitched battle to chance, worked to corrupt the enemy’s ranks in advance.',
      people='<b>Kobayakawa Hideaki</b>, the pivotal turncoat; other secretly-suborned western lords; <b>Ishida Mitsunari</b>, whose army they betrayed.',
      what='Through extensive secret correspondence, Ieyasu <b>arranged the defection of Kobayakawa and others</b>. When Kobayakawa turned his troops on his own side at the crisis of the battle, the western army disintegrated.',
      crux='He treated battle as the <b>last resort of a contest already half-won by intrigue</b> — engineering the outcome before the clash.',
      conseq='Sekigahara was decided in hours; the pre-arranged treachery made Ieyasu master of Japan at minimal risk to himself.',
      matters='The surest victories are arranged beforehand — by the time swords meet, the outcome may already be bought.'),

    E('sekigahara', '1600', 'Sekigahara — the battle for all Japan', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'When Hideyoshi dies leaving a small child as heir, Ieyasu makes his move. At Sekigahara he faces a larger coalition — but wins by secretly bribing enemy generals to betray their own side mid-battle.',
      svg_sekigahara(),
      bg='<b>Hideyoshi died in 1598</b>, leaving a five-year-old heir, <b>Hideyori</b>, under a council of regents. Ieyasu, the most powerful regent, manoeuvred to take control, provoking a war with loyalists led by <b>Ishida Mitsunari</b>.',
      people='<b>Ishida Mitsunari</b>, leader of the Western (loyalist) coalition; <b>Kobayakawa Hideaki</b> and other lords Ieyasu <b>secretly turned</b> before the battle.',
      what='At <b>Sekigahara (21 Oct 1600)</b>, Ieyasu’s Eastern army faced a larger Western coalition — but he had <b>secretly bought the loyalty of several Western commanders</b>. When <b>Kobayakawa defected</b> mid-battle and fell on his own side, the Western army collapsed.',
      crux='He won the decisive battle largely <b>before it began</b>, through months of secret diplomacy and bribery that turned the enemy’s own generals — battlefield victory was the confirmation of political groundwork.',
      conseq='Sekigahara made Ieyasu the master of Japan. In <b>1603</b> the Emperor named him <b>shōgun</b>.',
      matters='The biggest battles are often decided beforehand, by patient political work. Ieyasu fought Sekigahara with bribes and letters as much as swords.'),
]

# ==================================================================  PHASE 5 — SECURING THE DYNASTY
PHASE_DYNASTY = [
    E('osaka', '1603–1615', 'Shōgun — and destroying the last rival', ['POLITICS', 'BATTLE', 'TRIUMPH'],
      'Made shōgun, he quickly hands the title to his son to make the succession permanent — then, years later, manufactures a pretext to besiege Osaka Castle and wipe out Hideyoshi’s heir, removing the last threat.',
      svg_stack('Locking in the dynasty', [
          {'n': 1, 'label': 'Shōgun (1603)', 'sub': 'the Emperor confirms his rule', 'color': '#166534'},
          {'n': 2, 'label': 'Abdicates to his son (1605)', 'sub': 'proves the title is hereditary Tokugawa property', 'color': '#0891b2'},
          {'n': 3, 'label': 'Siege of Osaka (1614–15)', 'sub': 'a pretext to destroy Hideyori & the Toyotomi', 'color': '#dc2626'},
          {'n': 4, 'label': 'The last rival gone', 'sub': 'no one left to challenge the Tokugawa', 'color': '#b45309'},
      ], takeaway='He secured the dynasty by two moves: making the title hereditary at once, then erasing the only alternative claimant.', accent=AC),
      bg='Ieyasu was named <b>shōgun in 1603</b>. But Hideyoshi’s son <b>Hideyori</b>, now grown, remained a rallying point for anti-Tokugawa loyalists at <b>Osaka Castle</b>.',
      people='<b>Tokugawa Hidetada</b>, his son and heir; <b>Toyotomi Hideyori</b>, Hideyoshi’s son, destroyed at Osaka.',
      what='In <b>1605</b> Ieyasu quickly <b>abdicated the shogunate to his son Hidetada</b> (while keeping real power) to prove the title was hereditary. Then, on a manufactured pretext, he besieged and destroyed <b>Osaka Castle (1614–15)</b>, killing Hideyori and ending the Toyotomi line.',
      crux='He thought beyond his own reign: <b>institutionalising hereditary succession immediately</b>, then <b>eliminating the last alternative</b>, so the Tokugawa had no rival left.',
      conseq='With the Toyotomi gone and the succession secured, Tokugawa rule was unchallengeable.',
      matters='Founding a lasting dynasty means securing the succession while you live — and removing anyone who could become a rival banner after you die.'),

    E('ogosho', '1605–1616', 'Ruling from behind — the retired shōgun', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'His masterstroke of succession is to give up the title but keep the power: as “Ōgosho,” the retired shōgun, he installs his son as the figurehead while he himself governs from behind the curtain — grooming the dynasty, testing his heir, and ensuring the transition is complete and unshakable before he dies.',
      svg_row('Handing over the title, keeping the reins', [
          {'n': 1, 'label': 'Abdicates the title, 1605', 'sub': 'his son Hidetada becomes shōgun in name', 'color': '#166534'},
          {'n': 2, 'label': 'Rules as Ōgosho', 'sub': 'the “retired” shōgun holds the real power', 'color': '#0891b2'},
          {'n': 3, 'label': 'A seamless succession', 'sub': 'the transition proven before his death', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='He perfected the succession by ruling from retirement — passing the title early while keeping control until it was safe.', accent=AC),
      bg='Having made the shogunate hereditary in 1605, Ieyasu faced the delicate task of ensuring a <b>smooth, secure transition</b> to his son.',
      people='His son and nominal successor <b>Hidetada</b>; the retired-emperor tradition Ieyasu adapted for the shogunate.',
      what='Ieyasu ruled as <b>Ōgosho (retired shōgun)</b> from 1605 to 1616, letting <b>Hidetada</b> hold the title while he kept <b>real power</b>, groomed his heir, and completed the institutional transition before his death.',
      crux='He solved the classic succession problem by <b>transferring the title early but not the power</b> — proving and stabilising the handover while he could still oversee it.',
      conseq='When Ieyasu died in 1616, the succession was already tested and secure; the dynasty held for generations.',
      matters='The hardest part of founding a dynasty is the first handover. Ieyasu’s "rule from retirement" is a model of managing succession while still alive.'),

    E('gold', '1600–1616', 'The foundations of wealth — mines, cities and coin', ['REFORM', 'POLITICS', 'TRIUMPH'],
      'Ieyasu grounds his dynasty not just in armies but in money: he seizes Japan’s great gold and silver mines, the key ports and cities, and the right to mint the realm’s coinage — an economic base that made the Tokugawa unassailably the richest power in the land.',
      svg_stack('Power built on a treasury', [
          {'n': 1, 'label': 'Seizes the great mines', 'sub': 'the Sado gold and other mines become Tokugawa lands', 'color': '#a16207'},
          {'n': 2, 'label': 'Controls key cities & ports', 'sub': 'Edo, Osaka, Nagasaki and the trade they command', 'color': '#166534'},
          {'n': 3, 'label': 'Mints the coinage', 'sub': 'standard gold and silver coin under Tokugawa authority', 'color': '#78350f'},
      ], takeaway='He made sure the dynasty was not only the strongest but by far the wealthiest — the deepest root of its power.', accent=AC),
      bg='Lasting rule required money as much as swords. Ieyasu set about monopolising the realm’s richest economic assets for the Tokugawa house.',
      people='the mining engineers and magistrates who ran the mines; the merchants of Edo, Osaka and Nagasaki; the rival daimyō kept comparatively poor.',
      what='He took direct control of the major <b>gold and silver mines</b> (notably <b>Sado</b>), of key cities and ports, and of <b>coinage</b> — giving the shogunate an unmatched revenue base (the tenryō lands).',
      crux='He understood that <b>durable power rests on economic dominance</b> — an enemy who cannot out-spend you cannot long out-fight you.',
      conseq='The Tokugawa treasury underwrote 250 years of rule, funding the administration and dwarfing every daimyō’s resources.',
      matters='Enduring regimes are built on money as much as force — control the wealth and the swords eventually follow.'),

    E('bakufu', '1600–1616', 'The machine of control — the Tokugawa system', ['REFORM', 'TRIUMPH'],
      'He engineers a system designed to make rebellion structurally impossible: he redistributes the whole map of fiefs to reward loyalists and hem in potential enemies, and lays the groundwork for the alternate-attendance system that will keep every lord’s family hostage in his capital — governing not by constant war but by a self-enforcing design.',
      svg_stack('Engineering peace into the structure of the state', [
          {'n': 1, 'label': 'Redraw the map of fiefs', 'sub': 'loyalists rewarded; rivals boxed in and moved', 'color': '#166534'},
          {'n': 2, 'label': 'Hostages and attendance', 'sub': 'the seeds of sankin-kōtai keep lords in check', 'color': '#0891b2'},
          {'n': 3, 'label': 'Rebellion made impossible', 'sub': 'the structure itself deters revolt', 'color': '#b45309'},
      ], takeaway='He built a system in which rebellion was structurally near-impossible — peace engineered into the design of the state.', accent=AC),
      bg='To end the cycle of civil war for good, Ieyasu redesigned the political structure of Japan so that no coalition of lords could easily threaten the Tokugawa.',
      people='The <b>daimyō</b> reshuffled across the map; the “outside lords” (tozama) kept at a distance from power.',
      what='Ieyasu <b>redistributed fiefs</b> nationwide to reward allies and isolate potential enemies, positioned loyal lords at strategic points, and laid the basis for the <b>alternate-attendance (sankin-kōtai)</b> system that kept lords’ families effectively hostage in Edo.',
      crux='He made stability <b>structural rather than personal</b>: the very arrangement of the realm deterred rebellion, so peace did not depend on constant vigilance or war.',
      conseq='The system he designed kept the daimyō in check and Japan at peace for over 250 years.',
      matters='The deepest statecraft designs conflict out of the system. Ieyasu built a structure in which the causes of civil war could barely arise.'),

    E('buke', '1615', 'Law for the samurai — the Buke Shohatto', ['REFORM', 'POLITICS'],
      'The same year he destroys his last rival, he issues the code that will govern the warrior class for centuries: the Laws for the Military Houses, which restrict castle-building, control marriages between lords, and bind the samurai into a disciplined, obedient order — turning warlords into subjects of the law.',
      svg_row('Binding the warriors with law', [
          {'n': 1, 'label': 'The Buke Shohatto, 1615', 'sub': 'Laws for the Military Houses issued', 'color': '#166534'},
          {'n': 2, 'label': 'Curb the lords', 'sub': 'limits on castles, alliances and marriages', 'color': '#0891b2'},
          {'n': 3, 'label': 'Warlords into subjects', 'sub': 'the samurai bound into a lawful order', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='He replaced the sword-law of the warring states with a written code that bound even the warlords.', accent=AC),
      bg='A lasting peace needed <b>law</b>, not just force. In 1615 Ieyasu issued codes to regulate the warrior aristocracy and the imperial court.',
      people='The <b>daimyō</b> bound by the code; the imperial court, also regulated by parallel laws.',
      what='The <b>Buke Shohatto (Laws for the Military Houses, 1615)</b> restricted <b>castle-building</b>, controlled <b>marriages and alliances</b> among lords, and imposed norms of conduct — binding the once-independent warlords into a <b>disciplined, law-governed order</b>.',
      crux='He converted the warlords from <b>independent powers into regulated subjects</b>, replacing the sword-law of the Sengoku with written, enforceable rules.',
      conseq='The codes framed the samurai order for the whole Tokugawa era, entrenching stability and hierarchy.',
      matters='Peace is written into law. Ieyasu’s codes turned the warriors who had torn Japan apart into an ordered, obedient estate.'),

    E('anjin', '1600–1616', 'Opening a window — William Adams and foreign trade', ['POLITICS', 'REFORM'],
      'A shipwrecked English pilot, Will Adams, becomes his trusted advisor on the wider world — helping Ieyasu build ships, understand European rivalries, and pursue foreign trade through licensed "red-seal" ships, even as the seeds of later suspicion toward Christianity and the West begin to grow.',
      svg_row('A cautious opening to the world', [
          {'n': 1, 'label': 'William Adams (Anjin)', 'sub': 'an English pilot becomes Ieyasu’s advisor', 'color': '#166534'},
          {'n': 2, 'label': 'Trade and shipbuilding', 'sub': 'licensed “red-seal” ships; European contact', 'color': '#0891b2'},
          {'n': 3, 'label': 'Growing wariness', 'sub': 'suspicion of Christianity and the West rises', 'color': '#b45309'},
      ], edge_labels=['then', 'yet'], takeaway='He engaged the wider world pragmatically — trade and knowledge — while sowing the caution that later closed Japan.', accent=AC),
      bg='At the turn of the 17th century, European traders and missionaries were active in Japan; Ieyasu engaged them pragmatically.',
      people='<b>William Adams (Miura Anjin)</b>, the English pilot and advisor; Dutch, Portuguese and Spanish traders and missionaries.',
      what='The shipwrecked English pilot <b>William Adams</b> became Ieyasu’s <b>trusted advisor</b> on Europe and shipbuilding. Ieyasu promoted foreign <b>trade (the "red-seal" ship licenses)</b> and knowledge, while growing increasingly <b>wary of Christianity</b> as a potential source of subversion.',
      crux='He treated the outside world <b>pragmatically</b> — valuing its trade and knowledge — but with a rising <b>suspicion</b> that would lead his heirs to seal Japan.',
      conseq='Ieyasu’s cautious engagement set the stage for both a period of trade and the later Tokugawa policy of isolation (sakoku).',
      matters='Openness and control were in tension even under Ieyasu. His pragmatic curiosity, and his growing wariness, both shaped Japan’s path.'),

    E('frugal', '1543–1616', 'The patient man’s habits — self-discipline and survival', ['POLITICS'],
      'His famous patience is rooted in a lifetime of iron self-discipline: frugal, cautious, health-obsessed, mixing his own medicines and outliving nearly every rival, he embodies the truth that his greatest weapon was simply endurance — the willingness to wait, and to survive, longer than anyone else.',
      svg_row('Endurance as a way of life', [
          {'n': 1, 'label': 'Frugal and disciplined', 'sub': 'plain living; caution; iron self-control', 'color': '#166534'},
          {'n': 2, 'label': 'Obsessed with health', 'sub': 'mixes his own medicines; guards his longevity', 'color': '#0891b2'},
          {'n': 3, 'label': 'Outlives them all', 'sub': 'survives every greater rival to win in the end', 'color': '#b45309'},
      ], edge_labels=['plus', 'so'], takeaway='His deepest weapon was endurance — the discipline to wait, stay healthy, and simply outlast everyone.', accent=AC),
      bg='Ieyasu’s patience was not passive but a product of deliberate <b>self-discipline</b> in body and temperament.',
      people='His rivals Nobunaga and Hideyoshi, both of whom he outlived; the retainers who noted his frugal, cautious habits.',
      what='Ieyasu was famously <b>frugal, cautious and self-controlled</b>, deeply interested in <b>health and medicine</b> (reputedly mixing his own remedies), and <b>outlived nearly all his rivals</b> — endurance itself becoming a decisive advantage.',
      crux='His success rested on <b>disciplined survival</b>: by living carefully and long, he simply outlasted more brilliant but shorter-lived competitors.',
      conseq='Longevity let him seize the opportunities that opened only after Nobunaga and Hideyoshi were gone.',
      matters='Sometimes the winning strategy is simply to endure. Ieyasu’s discipline and longevity were as decisive as any battle he fought.'),

    E('christianity', '1612–1616', 'Turning against the cross', ['POLITICS', 'TRAGEDY'],
      'What began as tolerance hardens into fear: seeing Christianity as a foreign loyalty that could subvert his hard-won order — and a possible bridgehead for European powers — Ieyasu moves to ban the faith and expel missionaries, setting Japan on the road to the brutal persecution and the closed country of his heirs.',
      svg_row('From tolerance to prohibition', [
          {'n': 1, 'label': 'Christianity spreads', 'sub': 'converts grow; foreign missionaries active', 'color': '#166534'},
          {'n': 2, 'label': 'Seen as subversion', 'sub': 'a rival loyalty and a foreign bridgehead', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Banned and suppressed', 'sub': 'edicts against the faith; missionaries expelled', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='He came to see Christianity as a threat to his order — beginning the road to persecution and a closed Japan.', accent=AC),
      bg='Christianity had won many converts in Japan, but Ieyasu increasingly saw it as a <b>competing loyalty</b> and a potential <b>opening for European interference</b>.',
      people='The Japanese Christian converts; the Jesuit and Franciscan missionaries; the European powers behind them.',
      what='From around <b>1612</b>, Ieyasu moved from tolerance to <b>prohibition</b>, issuing edicts <b>banning Christianity</b> and beginning the <b>expulsion of missionaries</b> — the start of the harsh anti-Christian policy his successors would intensify.',
      crux='He subordinated religious freedom to <b>the security of his order</b>, judging that a faith with foreign loyalties could threaten the stability he had built.',
      conseq='His policy led to the brutal persecution of Christians and fed into the later closing of Japan (sakoku).',
      matters='Ieyasu prized order above all, even over tolerance. His turn against Christianity shows the hard, defensive edge of his quest for stability.'),

    E('classes', '1600–1616', 'Freezing society — a place for everyone', ['REFORM', 'POLITICS'],
      'To lock in stability, he entrenches a rigid social order inherited and hardened from Hideyoshi: samurai, farmers, artisans and merchants each fixed in their place, mobility between them sharply curtailed — a frozen hierarchy that would give Japan two and a half centuries of order at the cost of a rigid, closed society.',
      svg_stack('A society fixed in place', [
          {'n': 1, 'label': 'Four estates, fixed', 'sub': 'samurai, farmers, artisans, merchants', 'color': '#166534'},
          {'n': 2, 'label': 'Mobility curtailed', 'sub': 'birth largely determines station', 'color': '#0891b2'},
          {'n': 3, 'label': 'Order at a price', 'sub': 'stability bought with rigidity', 'color': '#b45309'},
      ], takeaway='He froze society into fixed estates — buying long peace at the cost of a rigid, closed order.', accent=AC),
      bg='Building on Hideyoshi’s measures, Ieyasu entrenched a <b>rigid, four-estate social hierarchy</b> to remove the fluidity that had fed the Sengoku wars.',
      people='The <b>samurai</b> elite; the farmers, artisans and merchants fixed beneath them.',
      what='Ieyasu hardened a <b>rigid class system</b> — samurai, farmers, artisans, merchants — with sharply <b>limited mobility</b> between them, freezing the social order that had been so fluid during the wars.',
      crux='He traded <b>social fluidity for stability</b>, judging that a fixed hierarchy would remove a key cause of civil strife.',
      conseq='The frozen order gave Japan long stability but also rigidity — strains that would show when the modern world arrived in the 1850s.',
      matters='Ieyasu chose order over opportunity. The frozen society he built kept the peace for centuries, but at the cost of the mobility that had let men like Hideyoshi rise.'),

    E('deification', '1616–1617', 'Becoming a god — the Shining Deity of the East', ['POLITICS', 'REFORM', 'DEATH'],
      'In death Ieyasu is not merely buried but deified: enshrined as Tōshō Daigongen, the “Great Avatar Illuminating the East,” at a magnificent shrine at Nikkō — turning the dynasty’s founder into a divine guardian whose sanctity underwrites his heirs’ right to rule.',
      svg_stack('The founder made divine', [
          {'n': 1, 'label': 'Dies at Sunpu, 1616', 'sub': 'the retired shōgun leaves a secured realm', 'color': '#166534'},
          {'n': 2, 'label': 'Deified as Tōshō Daigongen', 'sub': 'proclaimed a Shinto-Buddhist avatar, guardian of the realm', 'color': '#a16207'},
          {'n': 3, 'label': 'Enshrined at Nikkō', 'sub': 'the lavish Tōshō-gū shrine sanctifies the dynasty', 'color': '#78350f'},
      ], takeaway='He made himself the sacred foundation of his line — legitimacy secured by divinity, not just by arms.', accent=AC),
      bg='Founding a dynasty required more than power; it required <b>legitimacy</b> that could outlast the founder. Ieyasu and his heirs turned to religion to supply it.',
      people='his son <b>Hidetada</b> and grandson <b>Iemitsu</b>, who built the cult; the priest <b>Tenkai</b>, who devised his deification; later shōguns who venerated him.',
      what='After his death in 1616, Ieyasu was <b>deified as Tōshō Daigongen</b> and enshrined at the sumptuous <b>Tōshō-gū</b> at Nikkō — a divine ancestor whose worship reinforced the Tokugawa mandate.',
      crux='He converted personal achievement into <b>sacred, inheritable legitimacy</b> — the founder as protective god of the state.',
      conseq='The Nikkō shrine and the imperial-sanctioned cult helped anchor Tokugawa authority through two and a half centuries.',
      matters='Dynasties endure by sacralising their origins — a founder remembered as a god is far harder to overthrow.'),

    E('legacy', '1616', 'Death — and 250 years of peace', ['DEATH', 'REFORM', 'TRIUMPH'],
      'He dies in 1616 having built a system so stable it keeps Japan at peace for over 250 years — the longest era of peace in its history — sealed off from the world under Tokugawa control.',
      svg_cuckoo(),
      bg='Ieyasu died in <b>1616</b>, but the system he designed — a tightly controlled order of daimyō under Tokugawa supervision — would govern Japan until 1868.',
      people='The <b>daimyō</b> bound by his controls (later the <b>sankin-kōtai</b> alternate-residence system); his heirs, who completed the closing of Japan (<b>sakoku</b>).',
      what='The <b>Tokugawa (Edo) shogunate</b> he founded imposed rigid social order, controlled the warlords (hostage families and forced attendance in Edo), and increasingly <b>sealed Japan off from the outside world</b> — producing the <b>Pax Tokugawa</b>, ~250 years of internal peace.',
      crux='His genius was <b>systemic and patient</b>: he built institutions that removed the causes of civil war, prioritising <b>stability over glory or expansion</b> — the opposite of a conqueror’s restlessness.',
      conseq='Japan enjoyed its longest era of peace and rising prosperity and culture — though isolation also left it technologically behind, a reckoning that came in 1853–68.',
      matters='The rarest achievement is not winning power but building a system that keeps the peace long after you’re gone. Ieyasu chose durable order over personal glory — and got 250 years of it.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Tokugawa Ieyasu was the great survivor of Japan’s century of civil war: a hostage child from a weak clan who, through patience, self-control and ruthless timing, outlasted two greater rivals to become shōgun — and then built a system of government so stable it kept Japan at peace for over 250 years. His life is the definitive study in <b>patience as strategy, turning setbacks into foundations, and building an order that outlives its founder.</b></p>
<div class="ov-quote">“Nobunaga made the rice-cake, Hideyoshi baked it — and Ieyasu ate it.”<span>— the Japanese proverb on the three unifiers</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Hostage child of a weak clan → freed by Nobunaga’s rise, becomes his loyal ally → learns caution from a crushing defeat → survives Nobunaga’s murder and submits to Hideyoshi → turns a “demotion” to the Kanto into the mighty base of Edo → after Hideyoshi dies, wins all Japan at Sekigahara by turning the enemy’s generals → becomes shōgun, destroys the last rival at Osaka, and founds a dynasty that rules in peace for 250 years.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⏳</div><h4>Patience as power</h4><p>He out-waited bolder, more brilliant men — proof that endurance and timing can beat dash and genius.</p></div>
  <div class="ov-card"><div class="i">🏯</div><h4>Turning setbacks into bases</h4><p>He made an intended exile — the Kanto — into Edo, the richest, safest power base in Japan.</p></div>
  <div class="ov-card"><div class="i">🕊️</div><h4>Building lasting order</h4><p>He chose durable stability over glory, engineering ~250 years of peace after a century of war.</p></div>
  <div class="ov-card"><div class="i">♟️</div><h4>Winning before the battle</h4><p>Sekigahara shows how patient diplomacy and secret deals decide wars before a sword is drawn.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Hostage</b><small> 1543–60</small><p>A childhood as a pawn teaches patience.</p></div>
  <div><b>2 · The Ally</b><small> 1560–82</small><p>Freedom, alliance with Nobunaga, a defeat that teaches.</p></div>
  <div><b>3 · Serving Hideyoshi</b><small> 1582–90</small><p>Chaos, a draw, and strategic submission.</p></div>
  <div><b>4 · Seizing Power</b><small> 1590–1603</small><p>Edo, Hideyoshi’s death, and Sekigahara.</p></div>
  <div><b>5 · The Dynasty</b><small> 1603–1616</small><p>Shōgun, Osaka, and 250 years of peace.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Oda Nobunaga', 'role': 'first unifier / ally', 'color': '#dc2626',
     'bio': 'The ruthless, innovative warlord who began the unification of Japan by force and firearms. Ieyasu’s long-time ally, murdered by his own general in 1582.',
     'rel': 'The rising star Ieyasu backed and loyally served for 20 years.'},
    {'name': 'Toyotomi Hideyoshi', 'role': 'second unifier / overlord', 'color': '#b45309',
     'bio': 'A peasant-born genius who rose to complete Nobunaga’s unification and rule Japan. Ieyasu fought him to a draw, then served him — and outlived him.',
     'rel': 'The overlord he submitted to, then supplanted after his death.'},
    {'name': 'Toyotomi Hideyori', 'role': 'the heir he destroyed', 'color': '#57534e',
     'bio': 'Hideyoshi’s son and intended successor, a rallying point for anti-Tokugawa loyalists. Ieyasu destroyed him and the Toyotomi at the Siege of Osaka (1615).',
     'rel': 'The last rival, eliminated to secure the Tokugawa dynasty.'},
    {'name': 'Ishida Mitsunari', 'role': 'rival at Sekigahara', 'color': '#991b1b',
     'bio': 'The loyalist administrator who organised the Western coalition against Ieyasu after Hideyoshi’s death, and lost at Sekigahara. Executed afterward.',
     'rel': 'His chief opponent in the war for Japan.'},
    {'name': 'Kobayakawa Hideaki', 'role': 'the traitor', 'color': '#166534',
     'bio': 'A Western-army commander whom Ieyasu secretly turned before Sekigahara. His mid-battle defection collapsed the Western army and decided the day.',
     'rel': 'The bribed turncoat who handed Ieyasu the decisive battle.'},
    {'name': 'Takeda Shingen', 'role': 'early nemesis', 'color': '#7c2d12',
     'bio': 'One of the most feared warlords of the age, whose cavalry crushed a young, rash Ieyasu at Mikatagahara (1573) — a defeat that taught him lifelong caution.',
     'rel': 'The rival who gave him his most valuable lesson in humility.'},
    {'name': 'Tokugawa Hidetada', 'role': 'son & heir', 'color': '#0891b2',
     'bio': 'Ieyasu’s son, to whom he handed the shogunate in 1605 to prove the title hereditary, while keeping real power himself. Continued and hardened the Tokugawa system.',
     'rel': 'The heir through whom he made the dynasty permanent.'},
]

KEY_EVENTS = [
    ('1543', 'Born into the Matsudaira clan', 'A weak domain squeezed between giants.'),
    ('1540s–50s', 'Held as a hostage', 'A childhood as a political pawn teaches patience.'),
    ('1560', 'Okehazama', 'Nobunaga destroys the Imagawa; Ieyasu breaks free.'),
    ('1560s', 'Allies with Oda Nobunaga', 'A loyal 20-year alliance with the rising power.'),
    ('1573', 'Mikatagahara', 'Crushed by the Takeda; a lesson in caution.'),
    ('1582', 'Nobunaga assassinated', 'Honnō-ji; Hideyoshi seizes the succession.'),
    ('1584', 'Komaki–Nagakute', 'Fights Hideyoshi to a draw, then submits.'),
    ('1590', 'Transfer to the Kanto', 'Turns a “demotion” into the base of Edo.'),
    ('1598', 'Hideyoshi dies', 'Leaves a child heir; Ieyasu manoeuvres.'),
    ('1600', 'Sekigahara', 'Wins all Japan by turning the enemy’s generals.'),
    ('1603', 'Named shōgun', 'The Emperor confirms Tokugawa rule.'),
    ('1605', 'Abdicates to Hidetada', 'Makes the shogunate hereditary at once.'),
    ('1614–15', 'Siege of Osaka', 'Destroys Hideyori and the last Toyotomi.'),
    ('1616', 'Death', 'Leaves a system that keeps peace for 250 years.'),
]

MASTER = [
    {'year': '1543', 'age': 'born', 'phase': 'Hostage', 'title': 'Born a Matsudaira', 'desc': 'A weak clan in the age of war.'},
    {'year': '1560', 'age': 'age 17', 'phase': 'The Ally', 'title': 'Okehazama', 'desc': 'Freed by Nobunaga’s upset victory.'},
    {'year': '1573', 'age': 'age 30', 'phase': 'The Ally', 'title': 'Mikatagahara', 'desc': 'A crushing defeat teaches caution.'},
    {'year': '1582', 'age': 'age 39', 'phase': 'Hideyoshi', 'title': 'Nobunaga murdered', 'desc': 'Chaos; Ieyasu waits.'},
    {'year': '1584', 'age': 'age 41', 'phase': 'Hideyoshi', 'title': 'Submits to Hideyoshi', 'desc': 'A draw, then strategic submission.'},
    {'year': '1590', 'age': 'age 47', 'phase': 'Seizing Power', 'title': 'Moves to Edo', 'desc': 'A demotion becomes a power base.'},
    {'year': '1600', 'age': 'age 57', 'phase': 'Seizing Power', 'title': 'Sekigahara', 'desc': 'Wins all Japan by betrayal-diplomacy.'},
    {'year': '1603', 'age': 'age 60', 'phase': 'The Dynasty', 'title': 'Shōgun', 'desc': 'Founds the Tokugawa shogunate.'},
    {'year': '1615', 'age': 'age 72', 'phase': 'The Dynasty', 'title': 'Siege of Osaka', 'desc': 'Destroys the last rival.'},
    {'year': '1616', 'age': 'age 73', 'phase': 'The Dynasty', 'title': 'Death', 'desc': '250 years of peace to follow.'},
]

SOURCES = [
    ('Britannica — Tokugawa Ieyasu', 'https://www.britannica.com/biography/Tokugawa-Ieyasu'),
    ('World History Encyclopedia — Tokugawa Ieyasu', 'https://www.worldhistory.org/Tokugawa_Ieyasu/'),
    ('Britannica — Battle of Sekigahara', 'https://www.britannica.com/event/Battle-of-Sekigahara'),
    ('Wikipedia — Tokugawa Ieyasu', 'https://en.wikipedia.org/wiki/Tokugawa_Ieyasu'),
]

def build_meta():
    return {
        'pid': 'gm-ieyasu.html', 'kind': 'man', 'emoji': '🏯', 'accent': AC,
        'name': 'Tokugawa Ieyasu', 'years': '1543–1616', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The great survivor — a hostage child who out-waited two greater rivals to win all Japan and found a shogunate that ruled in peace for 250 years.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'hostage', 'label': '1 · The Hostage', 'type': 'timeline',
             'intro': 'Born to a weak clan and passed between warlords as a child pawn, he learns the patience and self-control that will one day make him ruler of Japan.', 'events': PHASE_HOSTAGE},
            {'id': 'ally', 'label': '2 · The Ally', 'type': 'timeline',
             'intro': 'Freed by Nobunaga’s rise, he becomes a loyal ally and builds his base — and a crushing defeat at Mikatagahara teaches him lifelong caution.', 'events': PHASE_ALLY},
            {'id': 'hideyoshi', 'label': '3 · Serving Hideyoshi', 'type': 'timeline',
             'intro': 'Nobunaga’s murder throws Japan into chaos; Ieyasu fights the new master Hideyoshi to a draw, then submits — keeping his strength for later.', 'events': PHASE_HIDEYOSHI},
            {'id': 'seize', 'label': '4 · Seizing Power', 'type': 'timeline',
             'intro': 'He turns an intended demotion into the base of Edo, then — when Hideyoshi dies leaving a child — wins all Japan at Sekigahara by turning the enemy’s own generals.', 'events': PHASE_SEIZE},
            {'id': 'dynasty', 'label': '5 · The Dynasty', 'type': 'timeline',
             'intro': 'As shōgun he makes the title hereditary at once, destroys the last rival at Osaka, and builds a system that keeps Japan at peace for two and a half centuries.', 'events': PHASE_DYNASTY,
             'sources': SOURCES, 'srcnote': 'Some famous details (the cuckoo proverb, the “defeat portrait” at Mikatagahara) are traditional and possibly apocryphal; this guide flags them as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
