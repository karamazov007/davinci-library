# -*- coding: utf-8 -*-
"""Birth-to-present guide content for Arnold Schwarzenegger (living figure)."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#9a3412'  # terracotta

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_dream():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the method behind every reinvention: a vivid, total goal</text>'
    boxes=[(40,'#9a3412','Picture the goal exactly','sees himself as champion, star, leader — in detail'),
           (270,'#b45309','Reverse-engineer the path','works backward to the daily reps that get there'),
           (500,'#166534','Out-work everyone','relentless, cheerful, total effort toward the picture')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He used the same formula three times — a clear vivid vision, then obsessive work — to conquer three worlds.</text>'
    return _wrap(W, H, 'The vision-and-grind method', _tk(b, W, H, 'A crystal-clear picture of the goal, then relentless work backward from it — the engine of every one of his lives.'), '', AC)

def svg_terminator():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1984 · turning every supposed handicap into the asset</text>'
    b += '<rect x="40" y="60" width="300" height="82" rx="12" fill="#fef2f2" stroke="#b45309" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#b45309">“You can’t be a star”</text>'
    s1,_=_tspans(54,100,'too big, too muscle-bound, a thick accent, an unpronounceable name',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="82" rx="12" fill="#fff7ed" stroke="#9a3412" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#9a3412">The perfect machine-man</text>'
    s2,_=_tspans(394,100,'the exact traits that make him the ideal, unstoppable Terminator',10,'#9a3412',600,12,44); b+=s2
    b += '<line x1="340" y1="101" x2="378" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">“I’ll be back” — six words in that accent, from that body, made him a global icon.</text>'
    return _wrap(W, H, 'The Terminator — weakness as weapon', _tk(b, W, H, 'The very things Hollywood said disqualified him became exactly what made him unforgettable.'), '', AC)

def svg_governor():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">2003 · a bodybuilder-actor becomes governor of California</text>'
    boxes=[(40,'#9a3412','A recall election','California votes to remove its sitting governor'),
           (270,'#b45309','The celebrity outsider','Arnold runs as a moderate Republican reformer'),
           (500,'#166534','Wins and governs','elected governor; later a climate-policy leader')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">The immigrant who once had nothing ran the world’s fifth-largest economy for seven years.</text>'
    return _wrap(W, H, 'The Governator — the third reinvention', _tk(b, W, H, 'He turned global fame into political power, governing California and championing landmark climate law.'), '', AC)

def svg_reinvention():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">one man, three complete careers at the very top</text>'
    rows=[('#9a3412','Champion','7× Mr. Olympia — the greatest bodybuilder of all time'),
          ('#b45309','Icon','the world’s biggest action-movie star of his era'),
          ('#166534','Leader','two-term governor of California and climate voice')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="42" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+21}" r="9" fill="{c}"/><text x="62" y="{y+25}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+18}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+34,s,9.3,'#5b6472',500,11,78); b+=ss
        y+=50
    return _wrap(W, H, 'Three lives, each at the summit', _tk(b, W, H, 'Most people would be proud of any one of his careers; he reached the very top of three in a row.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE AUSTRIAN DREAMER
PHASE_RISE = [
    E('austria', '1947–1965', 'A hard boyhood in postwar Austria', ['RISE', 'TRAGEDY'],
      'He grows up in a poor, strict household in a small Austrian village under a domineering, sometimes harsh former-policeman father — and, feeling trapped, fixes on a single burning idea: he will get to America and become somebody great.',
      svg_stack('A boy determined to escape', [
          {'n': 1, 'label': 'Postwar Austrian village', 'sub': 'poverty; no plumbing in early childhood', 'color': '#9a3412'},
          {'n': 2, 'label': 'A domineering father', 'sub': 'strict, disciplinarian, hard to please', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Dreams of America', 'sub': 'fixes early on escape and greatness', 'color': '#166534'},
      ], takeaway='A constrained, difficult childhood lit an almost desperate hunger to escape and prove himself.', accent=AC),
      bg='Schwarzenegger was born in <b>1947</b> in <b>Thal, Austria</b>, into a poor family recovering from the war, under a strict father, <b>Gustav</b>.',
      people='His father <b>Gustav</b>, a former policeman; his mother <b>Aurelia</b>; his brother <b>Meinhard</b>.',
      what='Arnold grew up in hardship and under a <b>demanding, disciplinarian father</b>. Feeling stifled, he developed an intense determination to <b>leave for America</b> and achieve something extraordinary.',
      crux='His difficult upbringing forged a <b>ferocious drive and a hunger to escape</b> — the emotional engine behind a lifetime of relentless ambition.',
      conseq='As a teenager he found the vehicle for that drive in the gym.',
      matters='Adversity often plants ambition. Arnold’s constrained boyhood set the desperate, escape-driven energy that powered his whole life.'),

    E('barbell', '1961–1968', 'The barbell and a total obsession', ['RISE', 'TURNING POINT'],
      'At about fifteen he discovers weight training and it becomes an all-consuming obsession — he trains fanatically, even breaking into the gym on days it is closed — and, crucially, he learns to picture in vivid detail the champion he intends to become.',
      svg_dream(),
      bg='In his mid-teens, Arnold discovered <b>bodybuilding</b> and weightlifting, and it gave his restless drive a focus and a path.',
      people='His early training partners and mentors in Austrian and German gyms; the bodybuilding idols he studied.',
      what='From about age fifteen Arnold trained with <b>total obsession</b> — reportedly breaking into the gym when it was closed — and developed his signature practice of <b>vividly visualising his goals</b>, seeing himself as champion before he was one.',
      crux='He fused <b>relentless work with disciplined visualisation</b>: picturing the exact outcome in detail, then grinding toward it — a method he would reuse for the rest of his life.',
      conseq='His rapid progress made him a rising star of European bodybuilding and won him a route to America.',
      matters='A clear picture of the goal plus obsessive work is Arnold’s core formula — and it took him from a village gym to global fame.'),

    E('family', '1947–1971', 'The hard family — and a complicated grief', ['TRAGEDY', 'RISE'],
      'His drive is shadowed by a difficult, sometimes painful family story: a strict, distant father who reportedly favored his elder brother, the early death of that brother Meinhard in a car crash, and his father’s death soon after — losses Arnold notoriously did not attend the funerals for, a coldness he has spent much of his life reckoning with.',
      svg_row('The painful roots of his drive', [
          {'n': 1, 'label': 'A strict, distant father', 'sub': 'Gustav; reportedly favored the elder son', 'color': '#9a3412'},
          {'n': 2, 'label': 'Brother Meinhard dies', 'sub': 'killed in a car crash in 1971', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Absent from the funerals', 'sub': 'a coldness he later reckoned with', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='His ferocious ambition grew partly from a hard, wounding family — a grief he handled with a coldness he later regretted.', accent=AC),
      bg='Arnold’s family life was marked by a harsh, disciplinarian father and, in these years, by loss.',
      people='His father <b>Gustav</b>; his elder brother <b>Meinhard</b>, who died young; his mother <b>Aurelia</b>.',
      what='Arnold grew up under a <b>strict father</b> who reportedly favored his elder brother <b>Meinhard</b>. Meinhard <b>died in a car crash in 1971</b>, and his father died soon after; Arnold, focused relentlessly on his career, <b>did not attend either funeral</b> — a coldness he has since reflected on.',
      crux='His <b>ferocious drive was entangled with a painful family history</b> — and with an early, self-protective hardness he later came to question.',
      conseq='These losses and his single-minded focus shaped both his relentlessness and his complicated relationship with his roots.',
      matters='Ambition can carry a cost in warmth. Arnold’s hard family and his coldness in grief are part of the fuller, more human story.'),
]

# ==================================================================  PHASE 2 — THE GREATEST BODYBUILDER
PHASE_BODY = [
    E('marnul', '1960–1964', 'The gym at Graz — Marnul and the muscle magazines', ['RISE', 'TURNING POINT'],
      'At about fifteen, taken to a Graz gym by his football coach, Arnold meets Kurt Marnul — a reigning Mr. Austria — who lets the skinny teenager train with the men at the Athletik Union, while cheap American muscle magazines feed him a specific dream built around two idols: Reg Park and Steve Reeves.',
      svg_stack('Finding the sport — and the heroes', [
          {'n': 1, 'label': 'Coach takes the team to a gym, 1960', 'sub': 'the 15-year-old is hooked on weights over football', 'color': '#9a3412'},
          {'n': 2, 'label': 'Kurt Marnul, Mr. Austria', 'sub': 'lets Arnold train with the men at the Graz Athletik Union', 'color': '#a16207'},
          {'n': 3, 'label': 'Reg Park & Steve Reeves', 'sub': 'muscle magazines give him idols who became movie Herculeses', 'color': '#166534'},
      ], takeaway='He found not just a sport but a precise template — bodybuilders who became Hercules on screen.', accent=AC),
      bg='In postwar <b>Graz, Austria</b>, a teenage Arnold was taken to a local gym and fell for weight training, quickly making it his obsession over football.',
      people='<b>Kurt Marnul</b>, a Mr. Austria who mentored him; the older lifters at the <b>Graz Athletik Union</b>; his distant idols <b>Reg Park</b> and <b>Steve Reeves</b>.',
      what='From about 1960, Arnold trained obsessively — at the gym, at the <b>Thalersee</b> lake, and at home — under the eye of <b>Kurt Marnul</b>, devouring American muscle magazines that showed him bodybuilders like <b>Reg Park</b> (a Mr. Universe who played Hercules in films).',
      crux='He didn’t just want muscles — he absorbed a <b>concrete life-plan</b> from the magazines: win Mr. Universe, then become a movie star, exactly as Reg Park had.',
      conseq='By his mid-teens he had chosen bodybuilding as a career and a route out of Austria — with a step-by-step model to copy.',
      matters='A vivid, specific role model turns a vague ambition into a concrete plan — Arnold could see the exact path because someone had walked it.'),

    E('army', '1965', 'AWOL to win — the Austrian Army and Junior Mr. Europe', ['RISE', 'BATTLE', 'TURNING POINT'],
      'Conscripted into the Austrian Army at eighteen and trained as a tank driver, Arnold is so desperate to compete that he goes AWOL from basic training to enter the Junior Mr. Europe contest in Stuttgart — wins it — and is thrown in military prison for a week when he gets back.',
      svg_row('Breaking the rules for the first title', [
          {'n': 1, 'label': 'Drafted as a tank driver, 1965', 'sub': 'compulsory Austrian Army service at 18', 'color': '#9a3412'},
          {'n': 2, 'label': 'Goes AWOL to compete', 'sub': 'sneaks to Stuttgart for Junior Mr. Europe', 'color': '#a16207'},
          {'n': 3, 'label': 'Wins — then jailed a week', 'sub': 'takes the title; punished on his return', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He decided a title was worth a week in the brig — the first sign of an all-consuming will to win.', accent=AC),
      bg='Austria required <b>military service</b>; the 18-year-old Arnold was conscripted in 1965 and trained to drive tanks — but a bodybuilding contest was coming.',
      people='his army superiors; the rivals at the <b>Junior Mr. Europe</b> contest in Stuttgart; Arnold, willing to be punished to compete.',
      what='Arnold <b>went AWOL from basic training</b> to enter the <b>1965 Junior Mr. Europe</b> in Stuttgart, <b>won the title</b>, and was <b>jailed for about a week</b> for absence when he returned to base.',
      crux='He weighed a title against military punishment and <b>chose the title</b> — an early, telling glimpse of his ruthlessness about winning.',
      conseq='The win confirmed his path; he soon left the army to pursue bodybuilding full-time in Germany.',
      matters='Extraordinary drive often means breaking the rules that hold ordinary people back — he paid the price to seize the opportunity.'),

    E('regpark', '1961–1966', 'The blueprint — idolizing Reg Park', ['RISE', 'POLITICS'],
      'Arnold’s whole life-plan is copied, consciously and in detail, from one man: Reg Park, the British three-time Mr. Universe who parlayed his physique into a movie career playing Hercules — the exact sequence Arnold intends to repeat, and when they finally meet in London, Park becomes his mentor.',
      svg_stack('A hero turned into a plan', [
          {'n': 1, 'label': 'Reg Park — 3× Mr. Universe', 'sub': 'the British champion Arnold worshipped from magazines', 'color': '#9a3412'},
          {'n': 2, 'label': 'Mr. Universe → Hercules films', 'sub': 'Park turned muscles into a movie career', 'color': '#a16207'},
          {'n': 3, 'label': 'Arnold copies the path exactly', 'sub': 'the same sequence becomes his master plan', 'color': '#166534'},
      ], takeaway='He chose a hero whose whole career was a map — and set out to walk the identical road.', accent=AC),
      bg='<b>Reg Park</b> was a British bodybuilder who won <b>Mr. Universe three times</b> and then starred as <b>Hercules</b> in Italian films — the complete physique-to-fame journey Arnold dreamed of.',
      people='<b>Reg Park</b>, his idol and later mentor; <b>Charles “Wag” Bennett</b>, the London trainer at whose home they met in 1966.',
      what='Arnold modeled his ambitions <b>precisely on Reg Park</b>: win Mr. Universe, then use fame to become a movie star. When they <b>met at Wag Bennett’s home in London in 1966</b>, the awe-struck young Arnold gained his hero as a mentor.',
      crux='He didn’t improvise a career — he <b>reverse-engineered one from a hero’s example</b>, giving his ambition a concrete, proven template.',
      conseq='The Park blueprint drove everything Arnold did next — and Park would soon personally open a door for him.',
      matters='Modelling yourself in detail on someone who has already done what you want turns a dream into an executable plan.'),

    E('london1966', '1966', 'Second in London — the loss that taught him conditioning', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'At the 1966 NABBA Mr. Universe in London, the huge 19-year-old Arnold is beaten into second place by the smaller, more defined American Chet Yorton — a defeat over leg development and conditioning that teaches him a lasting lesson, as the trainer Wag Bennett takes him in to fix his weaknesses and teach him to pose to music.',
      svg_row('The defeat that sharpened him', [
          {'n': 1, 'label': 'Mr. Universe, London 1966', 'sub': 'Arnold, 19, competes against seasoned pros', 'color': '#9a3412'},
          {'n': 2, 'label': 'Beaten by Chet Yorton', 'sub': 'loses on definition and leg development', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Wag Bennett rebuilds him', 'sub': 'fixes weak points; teaches posing to music', 'color': '#166534'},
      ], edge_labels=['loses to', 'then'], takeaway='He learned that size alone loses — conditioning, weak-point training and presentation win.', accent=AC),
      bg='The <b>NABBA Mr. Universe</b> in London was the sport’s top amateur stage. In 1966 the massive but raw 19-year-old Arnold entered against experienced competitors.',
      people='<b>Chester “Chet” Yorton</b>, the American who beat him; <b>Wag Bennett</b>, the London trainer who mentored him afterward; the London bodybuilding scene.',
      what='Arnold placed <b>second to Chet Yorton</b>, out-pointed on <b>conditioning and leg development</b>. Impressed anyway, <b>Wag Bennett took him in</b>, worked on his weak points, sharpened his diet, and taught him to <b>pose to music</b> for showmanship.',
      crux='He absorbed a precise lesson — that <b>details of conditioning and presentation</b>, not raw mass, separate winners — and set out to master them.',
      conseq='Bennett’s coaching helped Arnold return the next year far more polished — and win.',
      matters='A well-analysed defeat is the best teacher — Arnold turned a specific loss into a specific, correctable lesson.'),

    E('munich', '1966–1968', 'Munich — the gym, the stone-lift, and the first business', ['RISE', 'REFORM'],
      'Based in Munich, Arnold works at and then effectively runs a gym, attends business school, wins a famous stone-lifting contest, and launches his first venture — a mail-order course selling bodybuilding instruction — teaching himself the marketing and salesmanship that will matter as much as his muscles.',
      svg_stack('Muscle, and the first taste of business', [
          {'n': 1, 'label': 'Runs a Munich gym', 'sub': 'works at Rolf Putziger’s gym; attends business school', 'color': '#9a3412'},
          {'n': 2, 'label': 'Wins the Munich stone-lift, 1967', 'sub': 'lifts a stone of ~254 kg in a public contest', 'color': '#a16207'},
          {'n': 3, 'label': 'A mail-order course business', 'sub': 'sells bodybuilding instruction — his first venture', 'color': '#166534'},
      ], takeaway='In Munich he learned that promotion and business were as trainable as biceps — a lifelong theme.', accent=AC),
      bg='After his London loss, Arnold based himself in <b>Munich</b>, at the center of European bodybuilding, working in a gym and studying business.',
      people='gym owner <b>Rolf Putziger</b>; the Munich lifting crowd; his future partners in the mail-order and bodybuilding businesses.',
      what='Arnold worked at (and largely ran) <b>Putziger’s gym</b>, attended <b>business school</b>, won a <b>Munich stone-lifting contest (~254 kg)</b> in 1967, and started a <b>mail-order bodybuilding course</b> — his first business.',
      crux='He treated <b>promotion and enterprise as skills to master</b>, not afterthoughts — building the commercial instincts that later made him rich.',
      conseq='The marketing savvy he developed in Munich would carry through his mail-order courses, real estate, films and politics.',
      matters='The most durable careers pair a core talent with business skill — Arnold trained both from the start.'),

    E('universe1967', '1967', 'Youngest Mr. Universe — and Reg Park’s call', ['TRIUMPH', 'TURNING POINT'],
      'In 1967, at just twenty, Arnold returns to London and wins the NABBA Mr. Universe — the youngest ever to do so — and the victory prompts his idol Reg Park to personally invite him to South Africa, to train together and give exhibitions, letting the boy from Graz live and train alongside his hero.',
      svg_row('The title, and the hero’s invitation', [
          {'n': 1, 'label': 'Wins Mr. Universe, 1967', 'sub': 'youngest-ever NABBA Mr. Universe, at 20, in London', 'color': '#9a3412'},
          {'n': 2, 'label': 'Reg Park invites him', 'sub': 'his idol calls him to South Africa to train and exhibit', 'color': '#a16207'},
          {'n': 3, 'label': 'Living with his hero', 'sub': 'trains alongside Park in Johannesburg', 'color': '#166534'},
      ], edge_labels=['prompts', 'so'], takeaway='Winning the title didn’t just crown him — it brought his idol to him, turning a hero into a host and mentor.', accent=AC),
      bg='A year after his defeat, a far more polished Arnold returned to the <b>NABBA Mr. Universe</b> in London in 1967.',
      people='his idol-turned-mentor <b>Reg Park</b>; the NABBA judges; the bodybuilding press that began to notice the “Austrian Oak.”',
      what='Arnold <b>won the 1967 Mr. Universe</b> at age 20 — the <b>youngest ever</b> — and the victory led <b>Reg Park to invite him to South Africa (Johannesburg)</b> to train together and perform exhibitions, a dream realised for the young fan.',
      crux='Success <b>opened the door to his hero</b> — proof that winning creates access, and that his Reg Park blueprint was working exactly as planned.',
      conseq='The title and the growing buzz around him caught the eye of the man who would take him to America: Joe Weider.',
      matters='Achievement brings you into the orbit of the people you admire — winning is how you meet your heroes as equals.'),

    E('america', '1968–1970', 'America, and conquering bodybuilding', ['RISE', 'TRIUMPH'],
      'He arrives in the United States in 1968 with almost nothing but ambition, and within a few years dominates his sport — winning the Mr. Olympia title and, in time, taking it a record seven times to become the greatest bodybuilder in history.',
      svg_row('Arriving with nothing, winning everything', [
          {'n': 1, 'label': 'Lands in the US, 1968', 'sub': 'little money, little English, huge ambition', 'color': '#9a3412'},
          {'n': 2, 'label': 'Dominates the sport', 'sub': 'wins Mr. Universe and Mr. Olympia', 'color': '#b45309'},
          {'n': 3, 'label': '7× Mr. Olympia', 'sub': 'the greatest bodybuilder of all time', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He crossed an ocean with almost nothing and, within a few years, was the best in the world at his sport.', accent=AC),
      bg='In <b>1968</b> Arnold moved to the United States to pursue bodybuilding at its highest level.',
      people='His mentor and promoter <b>Joe Weider</b>; his great rivals on the posing stage.',
      what='Arriving with little money or English, Arnold <b>dominated competitive bodybuilding</b>, winning <b>Mr. Universe</b> and a record <b>seven Mr. Olympia titles</b>, redefining the sport with his size, symmetry and stage presence.',
      crux='He combined <b>physical dedication with psychological mastery</b> — famously using mind games to unsettle rivals — treating competition as much mental as physical.',
      conseq='He became the face of bodybuilding just as it entered the mainstream — and looked for the next mountain to climb.',
      matters='Arnold showed the immigrant’s classic path — arrive with nothing, out-work everyone — taken to the very summit of a sport.'),

    E('weider', '1968', 'Joe Weider’s call — and a humbling in Miami', ['RISE', 'DEFEAT', 'TURNING POINT'],
      'The publishing tycoon of bodybuilding, Joe Weider, spots Arnold’s potential and brings him to America in 1968 — paying him a weekly stipend to train and promote Weider’s magazines — but Arnold’s American debut is a humiliation: jet-lagged and rawly conditioned, he loses the IFBB Mr. Universe in Miami to the smaller, sharper Frank Zane, and cries alone in his hotel.',
      svg_stack('The door to America — and a hard landing', [
          {'n': 1, 'label': 'Joe Weider brings him over, 1968', 'sub': 'a stipend to train in California and promote his magazines', 'color': '#9a3412'},
          {'n': 2, 'label': 'Loses in Miami to Frank Zane', 'sub': 'jet-lagged and smooth, out-pointed on conditioning again', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Cries — then commits', 'sub': 'humiliated, he resolves to master the American game', 'color': '#166534'},
      ], takeaway='America opened via Weider’s patronage — but Arnold had to be humbled a second time to learn to win there.', accent=AC),
      bg='<b>Joe Weider</b>, the “Master Blaster” who published the sport’s magazines and ran the IFBB, invited the young European star to <b>America</b> to build him — and his brand — up.',
      people='<b>Joe Weider</b>, his American patron; <b>Frank Zane</b>, who beat him in Miami; the Gold’s Gym crowd in Venice, California.',
      what='In 1968 Weider brought Arnold to the US on a <b>weekly stipend</b> to train and appear in his magazines. Arnold’s first American contest, the <b>IFBB Mr. Universe in Miami</b>, ended in <b>defeat to Frank Zane</b> — jet-lagged and under-conditioned — and he reportedly wept in his hotel room.',
      crux='Weider’s patronage gave him the platform; the Miami loss taught him that <b>American conditioning standards</b> were higher still — a lesson he attacked at Gold’s Gym.',
      conseq='Arnold stayed, trained relentlessly in Venice, and within two years would be unbeatable.',
      matters='A powerful patron opens the door — but you still have to survive the humbling that comes with a bigger stage.'),

    E('oliva', '1969', 'Beaten by the Myth — losing to Sergio Oliva', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'In 1969 Arnold wins the IFBB Mr. Universe but, entering his first Mr. Olympia, runs into Sergio Oliva — “the Myth,” the reigning champion and perhaps the most genetically gifted bodybuilder alive — and loses, one of the very few defeats of his career and the one that fixes his target.',
      svg_row('The rival who set the bar', [
          {'n': 1, 'label': 'Wins IFBB Mr. Universe, 1969', 'sub': 'dominates the amateur ranks in America', 'color': '#9a3412'},
          {'n': 2, 'label': 'First Mr. Olympia, 1969', 'sub': 'faces the reigning champion Sergio Oliva', 'color': '#a16207'},
          {'n': 3, 'label': 'Beaten by “the Myth”', 'sub': 'Oliva keeps his crown; Arnold vows to take it', 'color': '#b91c1c'},
      ], edge_labels=['then', 'loses'], takeaway='He found the one man standing between him and the top — and made beating Oliva his whole focus.', accent=AC),
      bg='The <b>Mr. Olympia</b> was the sport’s ultimate title. Its holder, <b>Sergio Oliva</b> — “the Myth” — was a Cuban-American of extraordinary genetics who seemed unbeatable.',
      people='<b>Sergio Oliva</b>, the reigning champion; Joe Weider, promoting the rivalry; Arnold, hungry and improving fast.',
      what='Arnold won the <b>1969 IFBB Mr. Universe</b>, then entered his <b>first Mr. Olympia in 1969 and lost to Sergio Oliva</b> — a rare defeat that gave him a single, clear objective.',
      crux='He now had a <b>named target at the very top</b> — and channeled everything into surpassing the one man ahead of him.',
      conseq='A year later, transformed, Arnold would beat Oliva and begin an era of total dominance.',
      matters='Nothing focuses a competitor like a specific rival at the summit — the defeat gave Arnold his mission.'),

    E('olympia1970', '1970', 'Surpassing his heroes — first Mr. Olympia', ['TRIUMPH', 'TURNING POINT'],
      'In a remarkable 1970, Arnold beats his own boyhood idol Reg Park at the pro Mr. Universe, then dethrones Sergio Oliva to win his first Mr. Olympia at just 23 — the youngest champion ever, a record that still stands — having surpassed, in a single year, both the hero who inspired him and the rival who had beaten him.',
      svg_stack('Passing the hero and the rival at once', [
          {'n': 1, 'label': 'Beats Reg Park', 'sub': 'defeats his own idol at the pro Mr. Universe, 1970', 'color': '#a16207'},
          {'n': 2, 'label': 'Beats Sergio Oliva', 'sub': 'dethrones “the Myth” at the Mr. Olympia', 'color': '#9a3412'},
          {'n': 3, 'label': 'Youngest-ever Olympia, at 23', 'sub': 'a record that still stands', 'color': '#166534'},
      ], takeaway='In one year he overtook the man he worshipped and the man he feared — and reached the top of the sport.', accent=AC),
      bg='By 1970 Arnold, refined by two years at Gold’s Gym under Weider, was ready to challenge for everything at once.',
      people='his idol <b>Reg Park</b>, whom he now beat; his rival <b>Sergio Oliva</b>, whom he dethroned; Joe Weider, his promoter.',
      what='In 1970 Arnold <b>defeated Reg Park</b> at the professional Mr. Universe and then <b>beat Sergio Oliva to win his first Mr. Olympia</b>, becoming the <b>youngest Mr. Olympia ever at 23</b> — surpassing both his hero and his nemesis in a single season.',
      crux='He had <b>executed his Reg Park blueprint completely</b> — and then gone past its author to the very top.',
      conseq='It began an unbroken reign; Arnold would hold the Mr. Olympia title through 1975.',
      matters='The final step of following a hero is surpassing them — Arnold did it to both his model and his rival at once.'),

    E('psychwar', '1970–1980', 'Mind games and brotherhood — the politics of the sport', ['POLITICS', 'BATTLE'],
      'Arnold wins with his mind as much as his body — a master of psychological warfare who plants doubt in rivals before they ever pose, works the room and the judges, and knows the sport’s politics cold — while fiercely loyal to allies like his best friend Franco Columbu, with whom he even ran a bricklaying business.',
      svg_stack('Winning the game behind the contest', [
          {'n': 1, 'label': 'Psychological warfare', 'sub': 'sows doubt in rivals; unsettles them backstage', 'color': '#9a3412'},
          {'n': 2, 'label': 'Works the judges and politics', 'sub': 'masters the relationships and scoring of the sport', 'color': '#a16207'},
          {'n': 3, 'label': 'Loyalty to Franco', 'sub': 'backs his friend Franco Columbu; a bricklaying business together', 'color': '#166534'},
      ], takeaway='He treated bodybuilding as a total game — body, mind, politics and alliances — and mastered every layer.', accent=AC),
      bg='Posing contests are judged and political. Arnold understood that <b>confidence, presentation and relationships</b> swayed outcomes as much as muscle.',
      people='rivals he psyched out (from Sergio Oliva to, later, contenders in 1980); his best friend and training partner <b>Franco Columbu</b>; the judges and promoters.',
      what='Arnold became famous for <b>getting into opponents’ heads</b> — undermining their confidence before they stepped on stage — and for mastering the <b>judging and politics</b> of the sport, while remaining intensely loyal to allies like <b>Franco Columbu</b>, with whom he ran a <b>bricklaying and masonry business</b> in California.',
      crux='He grasped that the contest was <b>psychological and political</b>, not just physical — and worked every angle, for himself and his friends.',
      conseq='These mind-games and alliances shaped his reign and would explode into controversy at his 1980 comeback.',
      matters='In any competitive arena, the game is bigger than the visible contest — mastering the psychology and politics is its own skill.'),

    E('pumpingiron', '1977', 'Pumping Iron makes him famous', ['TRIUMPH', 'TURNING POINT'],
      'The documentary Pumping Iron turns him from a niche sports champion into a charismatic public personality, showcasing his wit, showmanship and outsized confidence — and opening the door to the movies.',
      svg_row('From gym champion to public personality', [
          {'n': 1, 'label': 'Pumping Iron (1977)', 'sub': 'a documentary on bodybuilding’s stars', 'color': '#9a3412'},
          {'n': 2, 'label': 'His charisma steals it', 'sub': 'wit, confidence and showmanship shine', 'color': '#b45309'},
          {'n': 3, 'label': 'Hollywood notices', 'sub': 'the personality, not just the physique', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='The film revealed the real weapon behind the muscles — an irresistible, media-ready personality.', accent=AC),
      bg='By the mid-1970s Arnold was a bodybuilding legend, but still largely unknown to the wider public.',
      people='The filmmakers behind <b>Pumping Iron</b>; the audiences it introduced him to.',
      what='The 1977 documentary <b>Pumping Iron</b> made Arnold a <b>public personality</b>, spotlighting his charm, humour and confidence as much as his body — and revealing a natural screen presence.',
      crux='It showed that his real asset was a <b>magnetic, quotable personality</b>, not just his physique — the quality that would carry him into film and politics.',
      conseq='Hollywood took interest, and Arnold set his sights on the next reinvention: movie stardom. (By this point, shrewd bricklaying and real-estate ventures had already made him a millionaire.)',
      matters='Charisma is a transferable asset. Pumping Iron proved Arnold could hold an audience — the skill that unlocked every later career.'),

    E('comeback1980', '1980', 'The controversial seventh — the 1980 comeback', ['BATTLE', 'TRIUMPH', 'POLITICS'],
      'Retired for five years, Arnold shocks the bodybuilding world by entering the 1980 Mr. Olympia in Sydney on a few weeks’ notice — bulked and training for Conan, not contest-sharp — and wins a seventh title so disputed that Mike Mentzer quits the sport in fury and rivals cry foul, a victory many still call a masterclass in psychological warfare over an unprepared field.',
      svg_stack('A comeback that split the sport', [
          {'n': 1, 'label': 'Enters at the last minute', 'sub': 'retired since 1975; announces late, unsettling everyone', 'color': '#9a3412'},
          {'n': 2, 'label': 'Only ~7–8 weeks of prep', 'sub': 'training for Conan, not in his best contest shape', 'color': '#a16207'},
          {'n': 3, 'label': 'Wins a disputed 7th title', 'sub': 'Mentzer rages and quits; rivals protest the result', 'color': '#b91c1c'},
      ], takeaway='He won as much by disrupting and out-psyching the field as by his physique — the ultimate mind-game victory.', accent=AC),
      bg='Arnold had retired after his sixth Mr. Olympia in 1975. In 1980, filming <b>Conan the Barbarian</b>, he was big but not contest-conditioned when he entered the Olympia in <b>Sydney</b>.',
      people='<b>Mike Mentzer</b>, the favourite who felt cheated and left competition; rivals like <b>Frank Zane</b> and <b>Boyer Coe</b> who protested; the judges at the center of the storm.',
      what='Announcing his entry late, Arnold competed at the <b>1980 Mr. Olympia in Sydney</b> after only <b>weeks of preparation</b> and <b>won a seventh title</b> amid uproar — <b>Mike Mentzer</b> was so incensed he <b>retired from competitive bodybuilding</b>, and several rivals cried foul.',
      crux='Whatever the judging, his late entry and gamesmanship <b>psychologically wrecked the field</b> before the posing began — a controversial capstone to his mind-game mastery.',
      conseq='It was his final competition; the controversy became one of bodybuilding’s most debated results, and he left as a seven-time champion.',
      matters='The line between competitive genius and gamesmanship is thin — Arnold’s last win showed both, and how much the mental game decides.'),

    E('realestate', '1968–1970s', 'A millionaire before Hollywood — the bricklayer businessman', ['RISE', 'TRIUMPH'],
      'Long before a single film, he is already rich — and not from bodybuilding: he runs a bricklaying business with a fellow bodybuilder, reinvests every dollar into Los Angeles apartment buildings during a real-estate boom, and becomes a self-made millionaire in his twenties, giving him the financial freedom to be choosy about his movie career.',
      svg_row('Wealth before fame', [
          {'n': 1, 'label': 'A bricklaying business', 'sub': 'with fellow bodybuilder Franco Columbu', 'color': '#9a3412'},
          {'n': 2, 'label': 'Reinvests in real estate', 'sub': 'LA apartment buildings in a rising market', 'color': '#b45309'},
          {'n': 3, 'label': 'A millionaire in his 20s', 'sub': 'financially free before his first big film', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He got rich in real estate before Hollywood — so he could pursue stardom on his own terms.', accent=AC),
      bg='While competing in bodybuilding, Arnold was quietly building wealth through business and property in Los Angeles.',
      people='His business partner and fellow bodybuilder <b>Franco Columbu</b>; the LA real-estate market of the 1970s.',
      what='Arnold ran a <b>bricklaying and business partnership</b>, then aggressively <b>reinvested in Los Angeles apartment buildings</b> during a boom, becoming a <b>self-made millionaire in his twenties</b> — before his film career had even begun.',
      crux='He achieved <b>financial independence early through shrewd investment</b>, which let him pursue acting selectively rather than desperately.',
      conseq='His wealth gave him the freedom to hold out for the right roles and terms as he broke into film.',
      matters='Arnold’s business acumen is often overlooked. He was a self-made millionaire investor before he was ever a movie star.'),

    E('mind', '1960s–present', 'The philosophy of reps — visualization, education, and self-making', ['REFORM', 'POLITICS'],
      'Underneath every reinvention is a coherent, teachable philosophy he has preached his whole life: see the goal with total clarity, break it into daily "reps," out-work everyone, never see yourself as a victim, and give back — a self-made-man creed, reinforced by his belief in education, that he has turned into a second career as one of the world’s most followed motivators.',
      svg_stack('A creed for building any life', [
          {'n': 1, 'label': 'Vision and daily reps', 'sub': 'a clear goal, then relentless repetition', 'color': '#9a3412'},
          {'n': 2, 'label': 'No victimhood; give back', 'sub': 'take responsibility; help others up', 'color': '#166534'},
          {'n': 3, 'label': 'Education matters', 'sub': 'studies business; values learning alongside effort', 'color': '#b45309'},
      ], takeaway='He turned his method into a teachable creed — vision, reps, responsibility, and giving back — now a whole second career.', accent=AC),
      bg='Arnold has always articulated an explicit <b>philosophy of success</b>, and pursued education (studying business) alongside his physical career.',
      people='The millions who follow his motivational messages; the students and young people he addresses.',
      what='Arnold preaches a consistent <b>self-made creed</b> — <b>vivid goals, daily "reps," relentless work, refusing victimhood, and giving back</b> — and, valuing <b>education</b>, studied business; in recent years this has made him one of the world’s most-followed <b>motivators</b>.',
      crux='He distilled his own method into a <b>transferable philosophy</b>, treating success as a repeatable process anyone can learn.',
      conseq='His motivational voice became a genuine second (or fourth) career and a core part of his public identity.',
      matters='Arnold’s deepest legacy may be a method: a clear, teachable philosophy of self-making that reaches far beyond bodybuilding or film.'),
]

# ==================================================================  PHASE 3 — THE MOVIE ICON
PHASE_FILM = [
    E('conan', '1982', 'Conan and the impossible movie dream', ['TRIUMPH', 'RISE'],
      'Everyone tells him his huge body, thick accent and unpronounceable name make stardom impossible — so he picks roles where all three are strengths, and Conan the Barbarian turns him into a bankable leading man.',
      svg_row('Choosing roles that fit his "flaws"', [
          {'n': 1, 'label': '“You can’t be a star”', 'sub': 'too big, thick accent, hard name', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Pick the right roles', 'sub': 'parts where size and intensity are the point', 'color': '#9a3412'},
          {'n': 3, 'label': 'Conan the Barbarian (1982)', 'sub': 'a hit that makes him a leading man', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='He didn’t fight his supposed flaws — he found the roles where they were exactly right.', accent=AC),
      bg='In the late 1970s Arnold pursued acting despite being told his body, accent and name were fatal obstacles to stardom.',
      people='The directors and producers who took a chance on him; the audiences who embraced Conan.',
      what='Arnold sought roles where his attributes were <b>assets, not liabilities</b>. <b>Conan the Barbarian (1982)</b> — a hulking, near-silent warrior — was a hit that established him as a <b>bankable leading man</b>.',
      crux='He <b>reframed his weaknesses as his brand</b>, choosing parts that demanded exactly his size, intensity and exotic presence.',
      conseq='Conan’s success set up the role that would make him a global icon: a relentless killing machine from the future.',
      matters='Play to your unfair advantages. Arnold built stardom by matching roles to the very traits others called handicaps.'),

    E('terminator', '1984', 'The Terminator — an icon is born', ['TRIUMPH', 'TURNING POINT'],
      'Cast as an unstoppable cyborg with barely a dozen lines, he delivers three words — "I’ll be back" — that make him a worldwide icon, proving that his accent and machine-like physique are the perfect fit for the role of a lifetime.',
      svg_terminator(),
      bg='In <b>1984</b>, director James Cameron cast Arnold as the villain-cyborg in a low-budget science-fiction film, <b>The Terminator</b>.',
      people='Director <b>James Cameron</b>; the audiences who made the film a phenomenon.',
      what='As the near-silent, relentless cyborg in <b>The Terminator (1984)</b>, Arnold turned minimal dialogue — above all <b>"I’ll be back"</b> — into an <b>iconic performance</b>; his accent and physique were perfect for the machine-man.',
      crux='The role <b>weaponised everything unusual about him</b>: the flat delivery, the accent, the enormous body all served the character exactly.',
      conseq='Arnold became one of the biggest action stars in the world, headlining hit after hit through the 1980s and 90s.',
      matters='The right role can immortalise you. The Terminator made Arnold a global icon and gave cinema one of its most quoted lines.'),

    E('boxoffice', '1985–1994', 'The biggest action star in the world', ['TRIUMPH'],
      'Through the 1980s and early 90s he becomes the definitive action star — Predator, Total Recall, Terminator 2, True Lies — and even proves he can do comedy in Twins and Kindergarten Cop, becoming one of the highest-paid actors on earth.',
      svg_stack('A decade at the top of Hollywood', [
          {'n': 1, 'label': 'Action blockbusters', 'sub': 'Predator, Total Recall, Terminator 2, True Lies', 'color': '#9a3412'},
          {'n': 2, 'label': 'Comedy too', 'sub': 'Twins and Kindergarten Cop show his range', 'color': '#b45309'},
          {'n': 3, 'label': 'Among the highest-paid', 'sub': 'a global box-office powerhouse', 'color': '#166534'},
      ], takeaway='For a decade he was the biggest action star alive — and shrewd enough to send up his own image in comedy.', accent=AC),
      bg='After the Terminator, Arnold headlined a string of the era’s biggest action films and expanded into comedy.',
      people='Directors like <b>James Cameron</b> and <b>Ivan Reitman</b>; his action-star rivals of the era.',
      what='Arnold starred in <b>Predator, Total Recall, Terminator 2: Judgment Day (1991), True Lies</b> and more, and showed comic range in <b>Twins</b> and <b>Kindergarten Cop</b> — becoming one of the <b>highest-paid actors in the world</b>.',
      crux='He built a <b>durable global brand</b> around spectacle and self-aware humour, dominating the action genre while cannily broadening his appeal.',
      conseq='Fabulously wealthy and world-famous, Arnold began eyeing an even more improbable reinvention: politics.',
      matters='Sustained stardom takes range and self-awareness. Arnold stayed on top by both embodying and gently mocking his own myth.'),

    E('business', '1980s–1990s', 'The mogul — Planet Hollywood and the businessman-star', ['TRIUMPH', 'POLITICS'],
      'Even at the height of his acting fame he never stops being a businessman: he becomes a celebrity partner and promoter of the Planet Hollywood restaurant chain, keeps building his investments, and cultivates the deal-making, brand-building instincts that make him wealthy several times over and prefigure his move into public life.',
      svg_row('The star who was always an entrepreneur', [
          {'n': 1, 'label': 'Planet Hollywood', 'sub': 'a celebrity restaurant chain he helps front', 'color': '#9a3412'},
          {'n': 2, 'label': 'Keeps investing', 'sub': 'grows his wealth across ventures', 'color': '#b45309'},
          {'n': 3, 'label': 'Brand and deal-making', 'sub': 'instincts that prefigure his political rise', 'color': '#166534'},
      ], edge_labels=['plus', 'so'], takeaway='He was a mogul as much as a movie star — the businessman’s instincts that later carried him into politics.', accent=AC),
      bg='Throughout his film career Arnold remained an active entrepreneur, lending his fame to ventures and managing his growing wealth.',
      people='His business partners; the fellow celebrities in ventures like <b>Planet Hollywood</b>.',
      what='Arnold became a celebrity partner and promoter of the <b>Planet Hollywood</b> restaurant chain and continued to grow his <b>investments</b>, honing the <b>brand-building and deal-making instincts</b> that made him wealthy and prefigured his political career.',
      crux='He never stopped being an <b>entrepreneur</b>, treating his fame as a business asset and building the public-facing skills politics would require.',
      conseq='His business success reinforced his wealth, independence, and public profile ahead of his run for office.',
      matters='Arnold’s through-line is enterprise. The businessman behind the star was always building toward the next reinvention.'),
]

# ==================================================================  PHASE 4 — THE GOVERNATOR
PHASE_GOV = [
    E('awakening', '1968–2003', 'Becoming an American Republican', ['POLITICS', 'RISE'],
      'His politics form early and deliberately: dazzled by the freedom and capitalism of his adopted country, inspired by figures like Nixon and the economist Milton Friedman, and proud of his self-made rise, he becomes a Republican — a pro-business, socially moderate immigrant conservative whose optimistic Americanism will define his political brand.',
      svg_row('The making of his political identity', [
          {'n': 1, 'label': 'Dazzled by America', 'sub': 'embraces its freedom, capitalism and opportunity', 'color': '#9a3412'},
          {'n': 2, 'label': 'Nixon and Friedman', 'sub': 'inspired toward pro-market Republicanism', 'color': '#b45309'},
          {'n': 3, 'label': 'A moderate immigrant conservative', 'sub': 'pro-business, socially moderate, optimistic', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='His self-made immigrant story made him a proud, optimistic, pro-business Republican — the core of his political brand.', accent=AC),
      bg='Arnold’s political views were shaped by his experience of America as a land of opportunity after postwar, occupied Austria.',
      people='Political influences like <b>Richard Nixon</b> and the economist <b>Milton Friedman</b>; the Kennedy in-laws who were his Democratic counterpoint.',
      what='Arnold became a <b>Republican</b> — inspired by American capitalism, figures like <b>Nixon</b> and <b>Milton Friedman</b>, and his own self-made rise — developing a <b>pro-business, socially moderate, optimistic immigrant conservatism</b>.',
      crux='His politics flowed directly from his <b>self-made immigrant experience</b>: gratitude to America and faith in opportunity and enterprise.',
      conseq='This moderate, optimistic Republicanism became the platform for his eventual run for governor.',
      matters='Arnold’s political identity was rooted in his immigrant gratitude — a distinctive, optimistic conservatism that shaped his public life.'),

    E('service', '1990–2003', 'Public service before office — fitness and after-school', ['REFORM', 'POLITICS'],
      'He eases into public life through causes, not campaigns: appointed by President George H. W. Bush to chair the President’s Council on Physical Fitness, deeply involved with the Special Olympics through his Shriver in-laws, and championing after-school programs for kids in California — building a record of civic service that lays the groundwork for his run.',
      svg_row('Building a civic record', [
          {'n': 1, 'label': 'Fitness Council chair', 'sub': 'appointed by President G.H.W. Bush', 'color': '#9a3412'},
          {'n': 2, 'label': 'Special Olympics', 'sub': 'deep involvement via the Shriver family', 'color': '#166534'},
          {'n': 3, 'label': 'After-school programs', 'sub': 'champions a California ballot initiative', 'color': '#b45309'},
      ], edge_labels=['plus', 'plus'], takeaway='He built a genuine record of public service through health and youth causes before ever running for office.', accent=AC),
      bg='Before running for governor, Arnold engaged in public life through health, fitness and youth causes.',
      people='President <b>George H. W. Bush</b>, who appointed him; the <b>Shriver</b> family and the Special Olympics; California’s schoolchildren.',
      what='Arnold chaired the <b>President’s Council on Physical Fitness</b> under <b>George H. W. Bush</b>, worked extensively with the <b>Special Olympics</b> through his in-laws, and championed <b>after-school programs</b> for California children via a ballot initiative.',
      crux='He built a <b>real record of civic service</b> through causes he cared about, giving substance to his later political image.',
      conseq='This service established him as more than a celebrity, smoothing his path to the governorship.',
      matters='Arnold entered politics through service, not just fame — a foundation of causes that made his candidacy credible.'),
    E('kennedy', '1986', 'Marrying into American royalty', ['POLITICS', 'RISE'],
      'A conservative-leaning Republican, he marries Maria Shriver — a broadcast journalist and member of the Democratic Kennedy dynasty — a union that both deepens his fame and connects him to the heart of American political life.',
      svg_row('Into the Kennedy orbit', [
          {'n': 1, 'label': 'Marries Maria Shriver', 'sub': 'journalist and Kennedy-family member, 1986', 'color': '#9a3412'},
          {'n': 2, 'label': 'A bipartisan marriage', 'sub': 'a Republican wed into Democratic royalty', 'color': '#b45309'},
          {'n': 3, 'label': 'Closer to politics', 'sub': 'immersed in American public life', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='His marriage bridged Hollywood and the Kennedys — and drew him toward political life.', accent=AC),
      bg='In <b>1986</b> Arnold married <b>Maria Shriver</b>, a television journalist and niece of President John F. Kennedy.',
      people='His wife <b>Maria Shriver</b>; the <b>Kennedy family</b>, into whose famous Democratic dynasty he married.',
      what='The Republican-leaning Arnold married <b>Maria Shriver</b>, of the <b>Kennedy dynasty</b> — a high-profile, cross-partisan union that deepened his celebrity and drew him into the world of American politics.',
      crux='The marriage placed him at a <b>unique crossroads of Hollywood fame and political dynasty</b>, unusual for a Republican and useful to his later ambitions.',
      conseq='Over the following years Arnold grew more publicly engaged in civic and political causes, setting up his run for office.',
      matters='Networks shape destinies. Arnold’s marriage connected him to the machinery of American politics he would soon enter.'),

    E('governor', '2003–2011', 'The Governator', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'In a chaotic 2003 recall election he runs for Governor of California — and the immigrant bodybuilder-turned-movie-star wins, governing the world’s fifth-largest economy for seven years and becoming a leading voice on climate policy.',
      svg_governor(),
      bg='In <b>2003</b>, California held a <b>recall election</b> to remove its sitting governor, creating an opening for an outsider candidate.',
      people='California’s voters; the legislature he battled and bargained with; environmental allies of his climate agenda.',
      what='Arnold ran in the 2003 recall and was <b>elected Governor of California</b> as a moderate Republican, serving until <b>2011</b>. He championed landmark <b>climate and clean-energy policy</b> (notably a major emissions law) while wrestling with the state’s finances.',
      crux='He converted <b>global celebrity into real political power</b>, governing a vast, complex economy and staking out a distinctive, environmentally engaged brand of Republicanism.',
      conseq='He completed his third great reinvention — champion, icon, and now statesman — and became an influential voice on climate.',
      matters='Arnold’s governorship is the capstone of his reinvention story: proof that celebrity, used deliberately, can become genuine public leadership.'),

    E('governing', '2003–2011', 'Governing California — triumphs, defeats, and “girlie men”', ['POLITICS', 'DEFEAT', 'REFORM'],
      'Governing the vast, ungovernable state is harder than winning it: he wrangles a chronic budget crisis, taunts opponents as "girlie men," suffers a humiliating defeat when voters reject his 2005 reform initiatives, then reinvents himself as a bipartisan dealmaker — passing landmark climate law and redistricting reform while battling a broken state finance system to the end.',
      svg_row('The hard reality of the job', [
          {'n': 1, 'label': 'Budget wars and “girlie men”', 'sub': 'battles a chronic deficit; taunts his rivals', 'color': '#9a3412'},
          {'n': 2, 'label': '2005 reforms rejected', 'sub': 'voters defeat his ballot initiatives — a humbling', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Bipartisan comeback', 'sub': 'landmark climate law; redistricting reform', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He learned governing the hard way — humbled by defeat, then reinvented as a bipartisan reformer.', accent=AC),
      bg='As governor, Arnold confronted California’s chronic <b>budget crises</b> and a deeply divided legislature.',
      people='The California legislature he battled and bargained with; the voters who rejected his 2005 initiatives.',
      what='Arnold wrestled with California’s <b>budget crisis</b>, taunted opponents as <b>“girlie men,”</b> and was <b>humbled when voters rejected his 2005 special-election reforms</b> — then pivoted to <b>bipartisan dealmaking</b>, passing a landmark <b>climate-change law (AB 32)</b> and redistricting reform.',
      crux='He discovered that <b>celebrity and will were not enough</b> to govern a fractured state, and adapted — from combative populist to pragmatic, bipartisan reformer.',
      conseq='He left office with major achievements (especially on climate) but California’s structural budget problems unsolved.',
      matters='Governing is harder than campaigning. Arnold’s term shows a celebrity outsider learning, painfully, the limits and craft of real power.'),
]

# ==================================================================  PHASE 5 — SCANDAL, COMEBACK, LEGACY
PHASE_END = [
    E('heart', '1997–2018', 'A hereditary heart — the body’s own limits', ['TRAGEDY', 'REFORM'],
      'The man who built the world’s most famous body carries a hidden vulnerability: a hereditary heart-valve condition that requires open-heart surgery in 1997 and again in 2018, when a routine procedure goes wrong and nearly kills him — a sobering reminder that even the ultimate self-made physique is subject to forces no discipline can fully master.',
      svg_row('The one thing willpower couldn’t fix', [
          {'n': 1, 'label': 'A hereditary heart condition', 'sub': 'a valve problem runs in his family', 'color': '#9a3412'},
          {'n': 2, 'label': 'Heart surgeries (1997, 2018)', 'sub': 'open-heart operations to replace valves', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'A near-death in 2018', 'sub': 'a procedure goes wrong; he barely survives', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='Even the world’s most disciplined body met a limit it could not train away — his own inherited heart.', accent=AC),
      bg='Arnold has a <b>hereditary heart-valve condition</b> that required surgery despite his lifelong fitness.',
      people='His surgeons; his family, who share the hereditary condition.',
      what='Arnold underwent <b>open-heart surgery in 1997</b> to address a hereditary valve condition, and again in <b>2018</b>, when a procedure <b>went wrong and nearly killed him</b>, requiring emergency surgery.',
      crux='It was a humbling encounter with <b>limits no discipline could overcome</b> — the inherited frailty of the very body he had perfected.',
      conseq='He recovered and returned to work, but the episodes underscored his mortality.',
      matters='Even Arnold’s body had limits he could not train away. His heart condition is a sober counterpoint to the invincible image.'),

    E('comeback', '2011–present', 'Back on screen — the return to film', ['TRIUMPH'],
      'After leaving office and weathering scandal, he does what he has always done — reinvents again, returning to acting in films like the Expendables and Terminator sequels, playing knowingly with his own aging legend, and proving that the icon still has box-office draw decades after "I’ll be back."',
      svg_row('The icon returns', [
          {'n': 1, 'label': 'Returns to acting', 'sub': 'the Expendables, Terminator sequels and more', 'color': '#9a3412'},
          {'n': 2, 'label': 'Plays his own legend', 'sub': 'knowing, self-aware roles about aging', 'color': '#b45309'},
          {'n': 3, 'label': 'Still draws crowds', 'sub': 'proves his star power endures', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He came back to film once more — playing his own myth, and proving the icon still sold tickets.', accent=AC),
      bg='After his governorship and personal scandal, Arnold returned to his film career.',
      people='His co-stars in ensemble action films; the audiences who remained loyal to the icon.',
      what='Arnold <b>returned to acting</b> in films such as the <b>Expendables</b> series and <b>Terminator</b> sequels, often <b>playing knowingly with his own aging legend</b> — demonstrating enduring box-office appeal decades into his career.',
      crux='He applied his lifelong pattern of <b>reinvention once more</b>, re-entering film on new terms after politics and scandal.',
      conseq='He re-established himself as a working actor and beloved pop-culture figure in his later years.',
      matters='Reinvention never stops for Arnold. His film comeback is another chapter in a life defined by starting over and enduring.'),

    E('climate', '2011–present', 'The elder statesman — climate and democracy', ['REFORM', 'POLITICS'],
      'His fourth act is as a global advocate: building on his California climate law, he becomes an international champion of climate action outside the party-political fray, and — as an immigrant who loves his adopted democracy — an outspoken defender of democratic values, using his enormous platform for causes larger than himself.',
      svg_row('Fame turned to public causes', [
          {'n': 1, 'label': 'Global climate advocate', 'sub': 'builds on his California climate leadership', 'color': '#166534'},
          {'n': 2, 'label': 'Defender of democracy', 'sub': 'speaks out for democratic values', 'color': '#9a3412'},
          {'n': 3, 'label': 'A platform for causes', 'sub': 'uses his fame for aims beyond himself', 'color': '#b45309'},
      ], edge_labels=['plus', 'so'], takeaway='He turned his global fame into advocacy — for the climate and for the democracy he embraced as an immigrant.', accent=AC),
      bg='In his later years Arnold has used his fame as a platform for advocacy, especially on climate and democracy.',
      people='The global audiences for his climate and pro-democracy messages; his environmental and civic partners.',
      what='Arnold became a leading <b>international advocate for climate action</b> (building on California’s AB 32) and, as a proud immigrant, an outspoken <b>defender of democratic values</b>, deploying his vast platform for causes beyond his own career.',
      crux='He converted <b>celebrity into sustained public advocacy</b>, championing causes larger than himself in a genuine fourth reinvention.',
      conseq='He remains, into his late seventies, a widely admired global voice on the environment and civic values.',
      matters='Arnold’s final reinvention is as an advocate. His climate and democracy work show fame turned deliberately toward the public good.'),
    E('scandal', '2011', 'Scandal and a very public fall', ['TRAGEDY', 'POLITICS'],
      'As he leaves office, it emerges that he fathered a child years earlier with a household employee — a revelation that ends his marriage to Maria Shriver and badly tarnishes the carefully built image, a self-inflicted wound he has openly called a great failure.',
      svg_row('A self-inflicted wound', [
          {'n': 1, 'label': 'A hidden child revealed', 'sub': 'fathered years earlier with a housekeeper', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'His marriage ends', 'sub': 'Maria Shriver files for divorce', 'color': '#b45309'},
          {'n': 3, 'label': 'He owns the failure', 'sub': 'publicly calls it a serious personal wrong', 'color': '#9a3412'},
      ], edge_labels=['then', 'then'], takeaway='At the height of his public life, a private betrayal cost him his family — a failure he has not tried to hide.', accent=AC),
      bg='As Arnold’s term as governor ended in <b>2011</b>, a damaging personal scandal became public.',
      people='His wife <b>Maria Shriver</b>; his family, deeply affected by the revelation.',
      what='It emerged in <b>2011</b> that Arnold had <b>fathered a child years earlier with a member of his household staff</b>; the revelation ended his marriage to <b>Maria Shriver</b> and damaged his public image.',
      crux='It was a <b>serious, self-inflicted failure</b> that stood in stark contrast to his disciplined public persona — one he has since openly acknowledged as a grave personal wrong.',
      conseq='Arnold stepped out of office and public favour under a cloud, facing the task of rebuilding both his family relationships and his reputation.',
      matters='Even the most disciplined public figures have private failings. Arnold’s scandal is a sobering counterpoint to his success story.'),

    E('legacy', '2011–present', 'Comeback, elder statesman, and legacy', ['TRIUMPH', 'REFORM'],
      'He returns to acting, undergoes serious heart surgery, and reinvents himself yet again as a widely respected elder statesman and outspoken advocate for democracy and climate action — his life a repeated proof that you can always begin again.',
      svg_reinvention(),
      bg='After leaving office and weathering scandal, Arnold rebuilt his life and public role in a new key.',
      people='His children and family, with whom he worked to reconcile; the global audiences for his climate and pro-democracy advocacy.',
      what='Arnold <b>returned to film</b>, survived serious <b>heart surgery</b>, and became a respected <b>elder statesman</b> — a prominent voice for <b>climate action and democratic values</b>, and a widely followed motivator preaching hard work and reinvention.',
      crux='His life embodies a single powerful idea — <b>continual reinvention</b> — reaching the summit of bodybuilding, film and politics, and then a fourth act as a public sage.',
      conseq='He remains, into his late seventies, a globally admired figure whose story is a byword for self-made ambition and resilience.',
      matters='Arnold’s deepest lesson is reinvention itself: with a clear vision and relentless work, you can build not one great life but several in a row.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Arnold Schwarzenegger reinvented himself three times over — the greatest bodybuilder in history, the biggest action-movie star of his era, and a two-term governor of California — a poor Austrian boy who willed himself to the summit of three separate worlds. He is a study in <b>vivid goal-setting and relentless work, turning weaknesses into assets, and continual reinvention.</b></p>
<div class="ov-quote">“The mind is the limit. As long as the mind can envision that you can do something, you can do it.”<span>— Arnold Schwarzenegger</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A poor Austrian boy under a hard father dreams of America → conquers bodybuilding with vision and obsessive work, winning seven Mr. Olympias → Pumping Iron reveals his charisma → he turns his "flaws" into stardom with Conan and the Terminator → dominates Hollywood for a decade → marries into the Kennedys → wins the California governorship in the 2003 recall → falls in a personal scandal → and reinvents himself yet again as an elder statesman and advocate.</p>
<div class="ov-lbl">Why he matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🎯</div><h4>Vision plus grind</h4><p>Picture the goal in vivid detail, then out-work everyone toward it.</p></div>
  <div class="ov-card"><div class="i">🔄</div><h4>Serial reinvention</h4><p>He reached the very top of three separate careers, in turn.</p></div>
  <div class="ov-card"><div class="i">💪</div><h4>Weakness as weapon</h4><p>His accent, body and name became his brand, not his obstacles.</p></div>
  <div class="ov-card"><div class="i">🌱</div><h4>Resilience</h4><p>After public scandal and heart surgery, he began again.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Austrian Dreamer</b><small> 1947–68</small><p>A hard boyhood and an all-consuming goal.</p></div>
  <div><b>2 · The Greatest Bodybuilder</b><small> 1968–77</small><p>Seven Mr. Olympias and Pumping Iron.</p></div>
  <div><b>3 · The Movie Icon</b><small> 1982–94</small><p>Conan, the Terminator, and a decade on top.</p></div>
  <div><b>4 · The Governator</b><small> 1986–2011</small><p>The Kennedys and the California governorship.</p></div>
  <div><b>5 · Scandal and Comeback</b><small> 2011–now</small><p>A fall, and yet another reinvention.</p></div>
</div>
<div class="ov-lbl">A note on a living figure</div>
<p class="ov-lead" style="font-size:15px">Arnold is alive and active into his late seventies; the recent items here are a snapshot. His bodybuilding, film and political careers are all well documented.</p>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Gustav Schwarzenegger', 'role': 'father', 'color': '#7f1d1d',
     'bio': 'Arnold’s strict, disciplinarian father, a former policeman, whose demanding parenting Arnold has credited with both scarring and driving him.',
     'rel': 'The hard father whose demands helped forge his drive.'},
    {'name': 'Joe Weider', 'role': 'bodybuilding mentor', 'color': '#9a3412',
     'bio': 'The bodybuilding promoter and publisher who brought Arnold to America and helped make him and the sport famous.',
     'rel': 'The mentor who brought him to America.'},
    {'name': 'James Cameron', 'role': 'director', 'color': '#166534',
     'bio': 'The director who cast Arnold as the Terminator and later made Terminator 2 and True Lies, central to his stardom.',
     'rel': 'The director who made him a screen icon.'},
    {'name': 'Maria Shriver', 'role': 'wife', 'color': '#7c3aed',
     'bio': 'The broadcast journalist and Kennedy-family member Arnold married in 1986; their marriage ended in 2011 after the revelation of his hidden child.',
     'rel': 'His wife of 25 years and link to the Kennedys.'},
]

KEY_EVENTS = [
    ('1947', 'Born in Thal, Austria', 'A poor, strict postwar household.'),
    ('~1962', 'Discovers bodybuilding', 'An all-consuming teenage obsession.'),
    ('1968', 'Moves to the United States', 'Arrives with little but ambition.'),
    ('1970s', '7× Mr. Olympia', 'The greatest bodybuilder of all time.'),
    ('1977', 'Pumping Iron', 'His charisma makes him a public figure.'),
    ('1982', 'Conan the Barbarian', 'Becomes a bankable leading man.'),
    ('1984', 'The Terminator', '“I’ll be back”; a global icon is born.'),
    ('1986', 'Marries Maria Shriver', 'Into the Kennedy dynasty.'),
    ('2003', 'Elected Governor of California', 'The improbable third reinvention.'),
    ('2011', 'Scandal and divorce', 'A hidden child ends his marriage.'),
    ('2011–now', 'Comeback and advocacy', 'Elder statesman for climate and democracy.'),
]

MASTER = [
    {'year': '1947', 'age': 'born', 'phase': 'Dreamer', 'title': 'Born in Austria', 'desc': 'A hard boyhood.'},
    {'year': '1968', 'age': 'age 21', 'phase': 'Bodybuilder', 'title': 'Moves to America', 'desc': 'Arrives with ambition.'},
    {'year': '1970s', 'age': '20s', 'phase': 'Bodybuilder', 'title': '7× Mr. Olympia', 'desc': 'The greatest ever.'},
    {'year': '1984', 'age': 'age 37', 'phase': 'Icon', 'title': 'The Terminator', 'desc': 'A global icon.'},
    {'year': '1991', 'age': 'age 44', 'phase': 'Icon', 'title': 'Terminator 2', 'desc': 'Peak box-office power.'},
    {'year': '2003', 'age': 'age 56', 'phase': 'Governator', 'title': 'Elected governor', 'desc': 'The third reinvention.'},
    {'year': '2011', 'age': 'age 63', 'phase': 'Comeback', 'title': 'Scandal and divorce', 'desc': 'A self-inflicted fall.'},
    {'year': 'now', 'age': '70s', 'phase': 'Comeback', 'title': 'Elder statesman', 'desc': 'Climate and democracy advocate.'},
]

SOURCES = [
    ('Britannica — Arnold Schwarzenegger', 'https://www.britannica.com/biography/Arnold-Schwarzenegger'),
    ('Encyclopædia Britannica — Mr. Olympia / bodybuilding', 'https://www.britannica.com/sports/bodybuilding'),
    ('Official site — Arnold Schwarzenegger', 'https://www.schwarzenegger.com/'),
    ('Wikipedia — Arnold Schwarzenegger', 'https://en.wikipedia.org/wiki/Arnold_Schwarzenegger'),
]

def build_meta():
    return {
        'pid': 'gm-arnold.html', 'kind': 'man', 'emoji': '💪', 'accent': AC,
        'name': 'Arnold Schwarzenegger', 'years': 'b. 1947', 'group': 'Modern Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'A poor Austrian boy who reinvented himself three times — greatest bodybuilder, biggest movie star, governor of California — by the same formula: a vivid vision and relentless work.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Austrian Dreamer', 'type': 'timeline',
             'intro': 'A poor boy under a hard father in postwar Austria fixes on escape and greatness — and finds his vehicle in the barbell, training with total obsession and learning to vividly picture the champion he means to become.', 'events': PHASE_RISE},
            {'id': 'body', 'label': '2 · The Greatest Bodybuilder', 'type': 'timeline',
             'intro': 'He arrives in America with almost nothing and conquers his sport — seven Mr. Olympia titles — before Pumping Iron reveals the charisma that will carry him far beyond the gym.', 'events': PHASE_BODY},
            {'id': 'film', 'label': '3 · The Movie Icon', 'type': 'timeline',
             'intro': 'Told his body, accent and name make stardom impossible, he picks roles where all three are strengths — Conan, then the Terminator — and dominates Hollywood for a decade.', 'events': PHASE_FILM},
            {'id': 'gov', 'label': '4 · The Governator', 'type': 'timeline',
             'intro': 'He marries into the Kennedy dynasty and, in the chaotic 2003 recall, wins the governorship of California — turning global fame into real political power and climate leadership.', 'events': PHASE_GOV},
            {'id': 'end', 'label': '5 · Scandal and Comeback', 'type': 'timeline',
             'intro': 'A self-inflicted scandal ends his marriage and tarnishes his image — before he reinvents himself once more as an elder statesman and advocate, proving you can always begin again.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Arnold is a living figure; his bodybuilding, film and political careers are extensively documented, and this guide follows the mainstream account.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
