# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Azim Premji.
The engineer-heir who turned a cooking-oil company into an IT giant — and gave most of his fortune away."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#1d4ed8'  # IT-industry blue

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — OIL, SOAP AND STANFORD
PHASE_ROOTS = [
    E('birth', '1945', 'Born into a trading family', ['RISE', 'ORIGINS'],
      'Azim Hashim Premji is born on 24 July 1945 in Bombay, into a prosperous Gujarati Ismaili Khoja Muslim trading family — his father a rice merchant so successful he was known as the “Rice King of Burma” — a household of commerce that chose, at Partition, to stay in India rather than migrate to Pakistan.',
      svg_row('A merchant family that chose India', [
          {'n': 1, 'label': 'Born in Bombay, 24 July 1945', 'sub': 'a Gujarati Ismaili Khoja Muslim family', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'A family of traders', 'sub': 'his father the “Rice King of Burma”', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Stays in India at Partition', 'sub': 'roots planted, not uprooted, in 1947', 'color': '#166534'},
      ], edge_labels=['into', 'and'], takeaway='He was born to commerce and to India — a trading household that put down roots as a new nation was born.', accent=AC),
      bg='<b>Azim Hashim Premji</b> was born on 24 July 1945 in Bombay (Mumbai) into a well-off Gujarati Ismaili Khoja Muslim family with a long history in trade.',
      people='his father <b>Muhammad Hashim Premji (M.H. Hasham Premji)</b>, a rice merchant known as the “Rice King of Burma”; the mercantile community into which he was born.',
      what='Premji was raised in a <b>prosperous business family</b> that, unlike many Muslim traders, chose to <b>remain in India after Partition in 1947</b> rather than move to the new state of Pakistan.',
      crux='His inheritance was <b>commerce and country</b> — an entrepreneurial ethos, and a deliberate stake in India’s future.',
      conseq='The family’s decision to stay tied its fortunes to the young Indian republic that Premji would later help transform.',
      matters='Great business dynasties often begin with a choice of loyalty — the Premjis bet on India, and that bet framed everything Azim built.'),

    E('wivp', '1945', 'His father founds Western India Vegetable Products', ['ORIGINS', 'BUSINESS'],
      'The same year Azim is born, his father incorporates Western India Vegetable Products Ltd at Amalner in Maharashtra — a modest maker of hydrogenated cooking oil, its “Sunflower Vanaspati” and “787” laundry soap sold to Indian households — the humble seed from which, decades later, the acronym “Wipro” would grow.',
      svg_stack('From cooking oil to a household name', [
          {'n': 1, 'label': 'Western India Vegetable Products, 1945', 'sub': 'incorporated at Amalner, Maharashtra', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Vanaspati and soap', 'sub': '“Sunflower” cooking oil; “787” laundry soap', 'color': '#a16207'},
          {'n': 3, 'label': 'The seed of “Wipro”', 'sub': 'an acronym waiting to be earned', 'color': '#166534'},
      ], takeaway='The IT colossus began as a vegetable-oil mill — an origin as unlikely as any in modern business.', accent=AC),
      bg='In <b>1945</b>, M.H. Hasham Premji incorporated <b>Western India Vegetable Products Ltd</b> in the small town of <b>Amalner</b>, in the Khandesh region of Maharashtra.',
      people='<b>M.H. Hasham Premji</b>, founder; the Amalner workforce; the Indian households who bought its oil and soap.',
      what='The company manufactured <b>hydrogenated vegetable oil (vanaspati)</b> — sold as “Sunflower Vanaspati” — and laundry soap under the <b>“787”</b> brand, a bread-and-butter consumer business.',
      crux='It was an <b>ordinary consumer-goods firm</b> — nothing about vegetable ghee foretold minicomputers or global software.',
      conseq='This oil-and-soap company was the vessel Azim Premji would inherit and, unrecognisably, remake.',
      matters='Empires can start small and mundane — the story is not the starting point but the transformation that follows.'),

    E('stanford', '1963–1966', 'Engineering at Stanford', ['RISE', 'EDUCATION'],
      'Sent abroad for a first-rate education, the young Premji enrols at Stanford University in California to study electrical engineering — soaking up the technical grounding and the culture of a place beside the valley that would become the world’s silicon heartland — when a phone call in 1966 abruptly ends his studies.',
      svg_row('An engineer in the making', [
          {'n': 1, 'label': 'Stanford University, California', 'sub': 'reads electrical engineering', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Beside the future Silicon Valley', 'sub': 'a technical culture in the making', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'Studies cut short in 1966', 'sub': 'he leaves before completing his degree', 'color': '#b91c1c'},
      ], edge_labels=['and', 'until'], takeaway='He was trained as an engineer at the doorstep of Silicon Valley — a grounding he would draw on decades later.', accent=AC),
      bg='As a young man Premji went to the United States to study at <b>Stanford University</b>, enrolling in <b>electrical engineering</b>.',
      people='Premji as a student; the Stanford faculty; the emerging Californian technology culture around the university.',
      what='He immersed himself in an <b>engineering education</b> at one of the world’s leading technical universities, on the edge of what would become <b>Silicon Valley</b> — but had to leave in 1966 <b>before finishing his degree</b> when his father suddenly died.',
      crux='He gained a <b>technical worldview</b> few Indian businessmen of his generation possessed — even if he left the degree incomplete.',
      conseq='Recalled home by his father’s death, he would return to Stanford in spirit only decades later, after building an IT empire. (He formally completed the degree many years afterward.)',
      matters='Formation outlasts the diploma — the engineer’s instinct he acquired at Stanford shaped the technology bets of his career.'),
]

# ==================================================================  PHASE 2 — THE SUDDEN INHERITANCE
PHASE_INHERIT = [
    E('return', '1966', 'A phone call, and a company at twenty-one', ['TURNING POINT', 'RISE'],
      'In 1966 M.H. Hasham Premji dies suddenly, and the 21-year-old Azim flies home from Stanford to take charge of the family firm — facing a shareholders’ meeting where one investor openly urges him to sell out to a more experienced hand, a slight the young chairman answers not with words but with results.',
      svg_stack('Thrown into command at twenty-one', [
          {'n': 1, 'label': 'His father dies, 1966', 'sub': 'Azim flies home from Stanford', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Chairman at 21', 'sub': 'takes charge of the oil-and-soap firm', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'A shareholder tells him to sell', 'sub': 'doubted for his youth — he stays and proves it', 'color': '#166534'},
      ], takeaway='Grief handed him a company overnight — and open doubt about his youth became the fuel for a lifetime of proving people wrong.', accent=AC),
      bg='In <b>1966</b>, while Premji was still a student at Stanford, his father <b>M.H. Hasham Premji died suddenly</b>, leaving the family business without a leader.',
      people='the young <b>Azim Premji</b>, age 21; the sceptical shareholders; the managers and workers of Western India Vegetable Products.',
      what='Premji <b>returned to India and took over as chairman at the age of 21</b>. At a shareholders’ meeting, an investor reportedly advised him to <b>sell the company to more seasoned management</b>, doubting a young man could run it.',
      crux='He <b>refused to be pushed aside</b> — choosing to lead the firm himself rather than hand it to others.',
      conseq='That decision kept the company in his hands and set him on a five-decade run at its helm.',
      matters='Adversity early can define a leader — being underestimated at 21 gave Premji a durable drive to build something undeniable.'),

    E('diversify', '1966–1970s', 'Beyond oil — consumer goods and discipline', ['REFORM', 'BUSINESS'],
      'Rather than let the firm drift, Premji professionalises it and pushes beyond vanaspati into a spread of consumer products — toiletries and soaps, bakery fats, lighting, and later hydraulic cylinders — installing rigorous management and a reputation for integrity that would become the company’s signature.',
      svg_row('Widening the base', [
          {'n': 1, 'label': 'Professionalises the family firm', 'sub': 'rigorous management, strict integrity', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Diversifies the product line', 'sub': 'toiletries, soaps, bakery fats, lighting', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Adds engineering products', 'sub': 'hydraulic cylinders and more', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='He turned a one-product mill into a diversified, professionally run consumer company — laying a platform for bigger leaps.', accent=AC),
      bg='Taking over a single-product oil business, Premji set about <b>modernising and broadening</b> it through the late 1960s and 1970s.',
      people='the professional managers he recruited; the consumers of the new product lines; a company culture built on ethics.',
      what='He moved the firm <b>beyond vanaspati into consumer products</b> — soaps and toiletries, bakery shortenings, lighting products — and into <b>engineering goods such as hydraulic cylinders</b>, while enforcing tight management and a hard line on honesty.',
      crux='He built a <b>professionalised, diversified company</b> with a culture of integrity — capabilities far beyond making cooking oil.',
      conseq='This broadened, disciplined base gave him the organisation and credibility to seize a far larger opportunity when it came.',
      matters='Transformation is usually gradual before it is dramatic — Premji built the muscle for reinvention long before the famous pivot.'),

    E('rename', '1977', 'Western India Vegetable Products becomes Wipro', ['BUSINESS', 'TURNING POINT'],
      'As the company grows past its origins, the mouthful “Western India Vegetable Products” is compressed into a crisp modern acronym — Wipro — a rebranding that signals ambitions beyond oil and soap, arriving in the very year that a political earthquake would open the door to computing.',
      svg_stack('A new name for new ambitions', [
          {'n': 1, 'label': 'The old name outgrown', 'sub': '“Western India Vegetable Products”', 'color': '#a16207'},
          {'n': 2, 'label': 'Rebranded “Wipro”, 1977', 'sub': 'an acronym of the founding name', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'Signalling reinvention', 'sub': 'no longer just a maker of oil and soap', 'color': '#166534'},
      ], takeaway='The name change was more than cosmetic — it announced a company ready to become something entirely new.', accent=AC),
      bg='By the mid-1970s the diversified firm had far outgrown its cumbersome original name.',
      people='Premji and his management, who steered the rebranding; a market beginning to notice the company’s widening scope.',
      what='The company was <b>renamed “Wipro”</b>, a compact acronym drawn from <b>Western India Vegetable Products</b>, marking its evolution into a modern, multi-product enterprise.',
      crux='The new name captured a firm <b>shedding its single-commodity identity</b> and reaching for broader horizons.',
      conseq='“Wipro” would soon become synonymous not with vegetable oil but with Indian information technology.',
      matters='Rebranding can prefigure reinvention — the Wipro name arrived just as the company’s greatest opportunity did.'),
]

# ==================================================================  PHASE 3 — THE PIVOT TO COMPUTING
PHASE_PIVOT = [
    E('ibm', '1977–1980', 'IBM leaves India — and Premji seizes the gap', ['TURNING POINT', 'TRIUMPH'],
      'When Indira Gandhi’s government forces IBM out of India in 1977 over foreign-ownership rules, it strands thousands of Indian computer users with no supplier — and Premji, the trained engineer, seizes the vacuum, moving Wipro into making minicomputers and building an information-technology business from scratch.',
      svg_row('A political shock becomes an opening', [
          {'n': 1, 'label': 'IBM expelled from India, 1977', 'sub': 'foreign-ownership rules force it out', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A supplier vacuum opens', 'sub': 'Indian computer users left stranded', 'color': '#a16207'},
          {'n': 3, 'label': 'Wipro enters computing', 'sub': 'the engineer-chairman moves into hardware', 'color': '#1d4ed8'},
      ], edge_labels=['so', 'and'], takeaway='He read a policy earthquake as an opportunity — walking a soap company straight into the computer business.', accent=AC),
      bg='In <b>1977</b>, under the Foreign Exchange Regulation Act, the Indian government demanded majority local ownership, and rather than comply <b>IBM withdrew from India</b>, leaving a large gap in the computer market.',
      people='Premji, the engineer at the helm; the Indian firms and institutions suddenly without IBM support; new domestic technology entrants.',
      what='Premji recognised the <b>opening created by IBM’s exit</b> and steered Wipro into <b>manufacturing minicomputers and hardware</b>, launching the company’s move into <b>information technology</b> around the turn of the 1980s.',
      crux='His <b>Stanford engineering background met a market vacuum</b> — and he pivoted a consumer-goods company into high technology.',
      conseq='This bet on computing became the foundation of everything Wipro would later be famous for.',
      matters='Fortunes turn on reading the moment — a regulatory shock that dismayed others, Premji turned into the launch pad of an IT empire.'),

    E('itservices', '1980s–1990s', 'Building an IT-services powerhouse', ['RISE', 'BUSINESS'],
      'From hardware Wipro moves up the value chain into software and IT services — writing code and running technology projects for the world’s corporations, obsessing over quality and process, and riding India’s software boom to become one of the country’s big three IT-services exporters alongside TCS and Infosys.',
      svg_stack('Up the value chain', [
          {'n': 1, 'label': 'From hardware to software', 'sub': 'code and services, not just machines', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Global IT services', 'sub': 'projects for the world’s corporations', 'color': '#7c3aed'},
          {'n': 3, 'label': 'India’s IT big three', 'sub': 'Wipro beside TCS and Infosys', 'color': '#166534'},
      ], takeaway='He climbed from minicomputers to global software services — turning Wipro into a pillar of India’s IT revolution.', accent=AC),
      bg='Through the 1980s and 1990s, as India opened its economy and its software industry took off, Wipro shifted its weight from hardware to <b>software and IT services</b>.',
      people='Wipro’s engineers and managers; global corporate clients; rival Indian IT majors <b>TCS</b> and <b>Infosys</b>.',
      what='Wipro built a <b>global IT-services business</b> — software development, systems integration and outsourced technology work — with a heavy emphasis on <b>quality and process discipline</b>, becoming one of India’s leading technology exporters.',
      crux='He moved Wipro <b>up the value chain into high-margin services</b>, where India’s engineering talent gave it a global edge.',
      conseq='Wipro grew into a multibillion-dollar company employing vast numbers of engineers and serving clients worldwide.',
      matters='The durable winners in tech climb the value chain — Premji pushed Wipro from boxes to brains, where the real growth lay.'),

    E('richest', '1999–2005', 'India’s richest man', ['TRIUMPH', 'WEALTH'],
      'As the technology boom sends Wipro’s share price soaring and the company lists its stock on the New York Stock Exchange in 2000, Premji’s controlling stake makes him for a time the richest man in India — and one of the wealthiest people in the world — an oil-and-soap heir turned IT billionaire.',
      svg_row('An oil heir becomes an IT billionaire', [
          {'n': 1, 'label': 'The tech boom lifts Wipro', 'sub': 'shares soar; NYSE listing in 2000', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'A vast controlling stake', 'sub': 'Premji owns the bulk of the company', 'color': '#7c3aed'},
          {'n': 3, 'label': 'India’s richest man', 'sub': 'among the world’s wealthiest for years', 'color': '#166534'},
      ], edge_labels=['and', 'so'], takeaway='The bet on computing paid off spectacularly — the man who inherited a soap firm became India’s richest.', accent=AC),
      bg='During the late-1990s technology boom, Wipro’s valuation surged, and in <b>2000 the company listed on the New York Stock Exchange</b>.',
      people='Premji as majority owner; global investors; the Indian public witnessing a home-grown IT giant.',
      what='Premji’s <b>large controlling stake in Wipro</b> made him, for a period in the early 2000s, the <b>richest person in India</b> and one of the wealthiest in the world.',
      crux='His fortune was <b>built, not inherited in that form</b> — created by transforming a modest firm into a global technology company.',
      conseq='That immense wealth would later become the raw material for one of the world’s greatest philanthropic gifts.',
      matters='Wealth is a means, not the story — how Premji built it, and what he chose to do with it, is what set him apart.'),
]

# ==================================================================  PHASE 4 — THE UNLIKELY BILLIONAIRE
PHASE_LEADER = [
    E('quality', '1990s–2000s', 'Quality, ethics and process', ['REFORM', 'BUSINESS'],
      'Premji makes rigour and integrity Wipro’s trademark — driving quality methods like Six Sigma deep into the company, refusing to pay bribes even when it costs contracts, and building a reputation so clean that “a Wipro man” becomes shorthand for probity in Indian business.',
      svg_stack('The discipline of a clean company', [
          {'n': 1, 'label': 'Quality made a religion', 'sub': 'Six Sigma and process discipline', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'A refusal to pay bribes', 'sub': 'clean deals even at the cost of contracts', 'color': '#a16207'},
          {'n': 3, 'label': 'A byword for integrity', 'sub': 'trust as a competitive asset', 'color': '#166534'},
      ], takeaway='He proved a big Indian company could be run cleanly and win — making integrity itself a source of advantage.', accent=AC),
      bg='As Wipro globalised, Premji built its brand on <b>quality and ethics</b> as much as on technology.',
      people='Wipro’s quality engineers and managers; clients who valued its reliability; a business culture often tolerant of corruption.',
      what='He drove <b>quality-management methods such as Six Sigma</b> deep into Wipro and enforced an <b>uncompromising anti-corruption stance</b>, reputedly forgoing business rather than paying bribes.',
      crux='He treated <b>integrity and quality as strategy</b>, not slogans — trust that clients and employees could bank on.',
      conseq='Wipro’s reputation for probity became one of its most valuable, and most imitated, assets.',
      matters='Clean, disciplined execution can be a moat — Premji showed that ethics and excellence are commercial strengths, not costs.'),

    E('frugal', '2000s', 'The billionaire who flew economy', ['CHARACTER', 'IDEAS'],
      'For all his billions, Premji becomes famous for personal frugality — flying economy class, driving modest cars for years, switching off office lights, tracking toilet-paper use in the canteen — a plainness that is not miserliness but a settled conviction that wealth is a responsibility, not a licence to indulge.',
      svg_row('Riches without extravagance', [
          {'n': 1, 'label': 'One of India’s richest men', 'sub': 'billions in Wipro stock', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Lives with striking plainness', 'sub': 'economy flights, modest cars, thrift', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'Wealth as responsibility', 'sub': 'not a licence to indulge', 'color': '#166534'},
      ], edge_labels=['yet', 'because'], takeaway='His frugality was a philosophy — money held in trust, not spent on show — and it foreshadowed his giving.', accent=AC),
      bg='Even as his fortune grew into the billions, Premji became known for an <b>austere personal style</b> unusual among the super-rich.',
      people='Premji himself; Wipro employees who observed his habits; a public that contrasted him with more flamboyant tycoons.',
      what='Stories abound of his <b>frugality</b> — travelling <b>economy class</b>, driving <b>ordinary cars</b> for years, insisting on thrift in the office — reflecting a belief that <b>wealth carries obligations</b> rather than entitlements.',
      crux='His restraint expressed a <b>moral view of money</b> — that great wealth is held in trust for larger ends.',
      conseq='This mindset made his later decision to give away most of his fortune feel less like a departure than a fulfilment.',
      matters='Character shapes what wealth becomes — Premji’s frugality was the seedbed of his extraordinary generosity.'),

    E('honours', '2005–2011', 'The Czar of Indian IT, honoured', ['LEGACY', 'TRIUMPH'],
      'His stature is formally recognised — India awards him the Padma Bhushan in 2005 and the Padma Vibhushan, its second-highest civilian honour, in 2011, while Time magazine twice names him among the world’s hundred most influential people, and the press dubs him the “Czar of the Indian IT industry.”',
      svg_stack('A career crowned with honours', [
          {'n': 1, 'label': 'Padma Bhushan, 2005', 'sub': 'a high Indian civilian honour', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Padma Vibhushan, 2011', 'sub': 'India’s second-highest civilian award', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Twice on the Time 100', 'sub': '“Czar of the Indian IT industry”', 'color': '#166534'},
      ], takeaway='The state and the world acknowledged what he had built — a global reputation as the elder statesman of Indian IT.', accent=AC),
      bg='By the 2000s Premji was one of the most respected figures in Indian business, and formal recognition followed.',
      people='the Government of India, which conferred the honours; Time magazine; the Indian technology industry he came to symbolise.',
      what='He was awarded the <b>Padma Bhushan (2005)</b> and the <b>Padma Vibhushan (2011)</b>, was named twice to <b>Time’s list of the 100 most influential people</b>, and was widely called the <b>“Czar of the Indian IT industry.”</b>',
      crux='The honours marked him as a <b>national institution</b>, not merely a successful businessman.',
      conseq='His prestige gave added weight to the philanthropic mission that would define his final chapter.',
      matters='Reputation is a platform — the standing Premji earned amplified the impact of the giving he was about to unleash.'),
]

# ==================================================================  PHASE 5 — THE GREAT GIVING
PHASE_GIVING = [
    E('foundation', '2001', 'The Azim Premji Foundation', ['REFORM', 'LEGACY'],
      'At the height of his wealth Premji founds the Azim Premji Foundation in 2001, aimed squarely at improving India’s government school education for the poorest children — not glamour projects but the unglamorous work of teacher training and system reform in India’s neediest districts.',
      svg_row('Turning fortune toward schools', [
          {'n': 1, 'label': 'Azim Premji Foundation, 2001', 'sub': 'philanthropy for school education', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'India’s government schools', 'sub': 'the poorest children, neediest districts', 'color': '#7c3aed'},
          {'n': 3, 'label': 'The unglamorous work', 'sub': 'teacher training and system reform', 'color': '#166534'},
      ], edge_labels=['for', 'through'], takeaway='He aimed his giving at the hardest, least glamorous problem — the quality of public schooling for the poor.', accent=AC),
      bg='In <b>2001</b>, Premji established the <b>Azim Premji Foundation</b>, a not-for-profit devoted to Indian education.',
      people='the Foundation’s educators and field teams; government schoolteachers; the disadvantaged children it serves.',
      what='The Foundation focused on <b>improving quality and equity in India’s public (government) school system</b>, working on <b>teacher education and systemic reform</b> in some of the country’s poorest regions rather than on high-visibility showpieces.',
      crux='He chose the <b>deepest structural problem</b> — the schooling of the poor — over easier, more visible causes.',
      conseq='The Foundation became the vehicle through which he would eventually channel tens of billions of dollars.',
      matters='Serious philanthropy tackles root causes — Premji bet his fortune on education as the lever of a fairer India.'),

    E('university', '2010', 'Azim Premji University', ['REFORM', 'LEGACY'],
      'In 2010 the Foundation establishes Azim Premji University in Bangalore — a not-for-profit institution devoted to education, development and the public good, training teachers and professionals for the social sector, and giving his mission an enduring academic home.',
      svg_stack('An institution for the public good', [
          {'n': 1, 'label': 'Azim Premji University, 2010', 'sub': 'established in Bangalore', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Education and development', 'sub': 'training for teaching and the social sector', 'color': '#7c3aed'},
          {'n': 3, 'label': 'A permanent home', 'sub': 'the mission institutionalised', 'color': '#166534'},
      ], takeaway='He built a lasting institution — turning a philanthropic programme into a university that would outlive him.', accent=AC),
      bg='To deepen and sustain the Foundation’s work, Premji moved to create a dedicated academic institution.',
      people='the university’s faculty and students; the teachers and social-sector professionals it trains; the Foundation behind it.',
      what='In <b>2010</b> the Foundation founded <b>Azim Premji University</b> in Bangalore, a <b>not-for-profit university</b> focused on <b>education, development and public-service professions</b>.',
      crux='He <b>institutionalised his mission</b> — embedding it in a university built to endure beyond any one gift or lifetime.',
      conseq='The university anchored a growing philanthropic ecosystem in education and the social sciences.',
      matters='Lasting change needs institutions, not just donations — Premji built one to carry his purpose forward.'),

    E('givingpledge', '2010–2013', 'The Giving Pledge and the first gifts', ['TRIUMPH', 'LEGACY'],
      'Premji becomes the first Indian to sign the Giving Pledge in 2013, promising to give away the bulk of his wealth — having already begun in December 2010 by handing an 8.7% stake in Wipro, then worth about two billion dollars, to his foundation, an act then among the largest gifts in Indian history.',
      svg_row('A public promise to give', [
          {'n': 1, 'label': 'First major gift, Dec 2010', 'sub': '8.7% of Wipro, about $2 billion', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Signs the Giving Pledge, 2013', 'sub': 'first Indian to join Gates and Buffett’s pledge', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Promises the bulk of his wealth', 'sub': 'to be given away in his lifetime', 'color': '#166534'},
      ], edge_labels=['then', 'to'], takeaway='He publicly bound himself to give — the first Indian on the Giving Pledge, backing words with billions.', accent=AC),
      bg='The <b>Giving Pledge</b>, launched by Bill Gates and Warren Buffett in 2010, invites the world’s richest to commit most of their wealth to philanthropy.',
      people='<b>Bill Gates</b> and <b>Warren Buffett</b>, the Pledge’s founders; Premji, its first Indian signatory; the Foundation receiving the gifts.',
      what='In <b>December 2010</b> Premji transferred an <b>8.7% stake in Wipro (about $2 billion)</b> to his foundation, and in <b>2013 became the first Indian to sign the Giving Pledge</b>, vowing to give away most of his fortune, with a further 12% stake transferred that year.',
      crux='He made his intention <b>public and binding</b> — a formal, irreversible commitment to large-scale giving.',
      conseq='These early transfers were the opening moves of a far larger endowment to come.',
      matters='Public pledges create accountability — by naming his commitment, Premji set a standard for Indian philanthropy.'),

    E('megagift', '2015–2019', 'One of the world’s greatest gifts', ['TRIUMPH', 'LEGACY'],
      'Premji keeps transferring vast blocks of Wipro shares to his foundation — 18% more in 2015 and a further 34% in 2019 — until the endowment behind his philanthropy reaches roughly 21 billion dollars and about two-thirds of Wipro’s economic ownership, ranking his commitment among the largest in the world.',
      svg_stack('Giving away a fortune', [
          {'n': 1, 'label': 'Another 18% transferred, 2015', 'sub': 'the endowment swells', 'color': '#1d4ed8'},
          {'n': 2, 'label': '34% more pledged, 2019', 'sub': 'about two-thirds of Wipro’s economic value', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Roughly $21 billion endowment', 'sub': 'among the world’s greatest gifts', 'color': '#166534'},
      ], takeaway='He gave away the vast majority of his life’s work — a philanthropic commitment on a global scale, from an Indian industrialist.', accent=AC),
      bg='Having begun transferring shares in 2010, Premji vastly enlarged his giving over the following decade.',
      people='the Azim Premji Foundation and its endowment; the beneficiaries in Indian education; a global philanthropic community taking note.',
      what='He transferred a further <b>18% of Wipro in 2015</b> and <b>34% more in 2019</b>, bringing the resources behind his philanthropy to about <b>$21 billion</b> — representing roughly <b>two-thirds of Wipro’s economic ownership</b> — one of the <b>largest philanthropic commitments in the world</b>.',
      crux='He gave away <b>the great majority of his fortune</b> — not a token slice, but the bulk of what he had built.',
      conseq='His name became synonymous with philanthropy on a scale rarely seen outside the United States.',
      matters='Giving on this scale redefines a life’s meaning — Premji chose to be remembered less as a tycoon than as a benefactor.'),

    E('legacy', '2019–', 'Stepping down, and the enduring model', ['DEATH', 'LEGACY'],
      'In July 2019 Premji retires as executive chairman of Wipro, handing the company to his son Rishad while keeping his focus on the Foundation — leaving a double legacy: proof that an Indian firm could compete globally in technology, and a model of the businessman as steward of wealth for the public good.',
      svg_row('A steward’s legacy', [
          {'n': 1, 'label': 'Retires as chairman, 2019', 'sub': 'hands Wipro to his son Rishad', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Focus turns fully to giving', 'sub': 'the Foundation as his life’s work', 'color': '#7c3aed'},
          {'n': 3, 'label': 'A double legacy', 'sub': 'global IT, and the ethic of giving', 'color': '#166534'},
      ], edge_labels=['to', 'leaving'], takeaway='He leaves two things behind — a world-class Indian IT company, and a template for how the rich might give.', accent=AC),
      bg='In <b>July 2019</b>, after more than five decades, Premji stepped down as <b>executive chairman of Wipro</b>.',
      people='his son <b>Rishad Premji</b>, who succeeded him as chairman; the Foundation he continued to lead; the wider world of Indian business and philanthropy.',
      what='Premji <b>handed executive leadership of Wipro to Rishad</b> and devoted himself to the Foundation, leaving behind both a <b>globally competitive Indian technology company</b> and a <b>landmark example of large-scale philanthropy</b>.',
      crux='His legacy is <b>twofold</b> — the builder who globalised Indian IT, and the giver who set a new standard for stewardship of wealth.',
      conseq='He remains one of India’s most admired figures, cited as a model of ethical enterprise and generosity.',
      matters='The measure of a fortune is finally what it is used for — Premji’s answer, giving most of it away, is his most lasting statement.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Azim Premji is the engineer-heir who turned a small cooking-oil and soap company into a global information-technology giant — and then gave most of the resulting fortune away. Called home from Stanford at twenty-one in 1966 to run his late father’s vegetable-products firm, he professionalised and diversified it, renamed it Wipro, and seized the vacuum left by IBM’s 1977 exit from India to march into computing and IT services. The bet made him India’s richest man. In his final chapter he became one of the world’s foremost philanthropists, transferring tens of billions of dollars in Wipro shares to the Azim Premji Foundation. He is the ultimate study in <b>disciplined reinvention, ethical enterprise, and wealth as responsibility.</b></p>
<div class="ov-quote">“If one has got much more than what one needs, one should give it back to society.”<span>— Azim Premji</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born to a trading family and sent to Stanford → called home at 21 in 1966 to run a cooking-oil firm → diversifies it and renames it Wipro → seizes IBM’s 1977 exit to pivot into computing and IT services → builds a global IT powerhouse and becomes India’s richest man → and gives away the bulk of his fortune, tens of billions, to education and the Azim Premji Foundation.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🔄</div><h4>Disciplined reinvention</h4><p>Turned an oil-and-soap firm into a global IT giant.</p></div>
  <div class="ov-card"><div class="i">🤝</div><h4>Ethical enterprise</h4><p>Made integrity and quality Wipro’s competitive edge.</p></div>
  <div class="ov-card"><div class="i">🎁</div><h4>Wealth as responsibility</h4><p>Gave away the majority of a multibillion-dollar fortune.</p></div>
  <div class="ov-card"><div class="i">📚</div><h4>Education first</h4><p>Aimed his philanthropy at India’s poorest schools.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Oil &amp; Stanford</b><small> 1945–1966</small><p>A trading family, a vegetable-products firm, an engineer’s education.</p></div>
  <div><b>2 · The Inheritance</b><small> 1966–1977</small><p>Chairman at 21, diversification, and the Wipro name.</p></div>
  <div><b>3 · The Pivot</b><small> 1977–2005</small><p>IBM’s exit, computing, IT services, and immense wealth.</p></div>
  <div><b>4 · The Billionaire</b><small> 1990s–2011</small><p>Quality, ethics, frugality, and national honours.</p></div>
  <div><b>5 · The Great Giving</b><small> 2001–</small><p>The Foundation, the University, and a historic gift.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'M.H. Hasham Premji', 'role': 'father & founder', 'color': '#1d4ed8',
     'bio': 'A rice merchant known as the “Rice King of Burma” who founded Western India Vegetable Products in 1945; his sudden death in 1966 thrust Azim into command at 21.',
     'rel': 'The father whose company — and whose death — set Azim’s course.'},
    {'name': 'Rishad Premji', 'role': 'son & successor', 'color': '#7c3aed',
     'bio': 'Azim Premji’s son, who succeeded him as chairman of Wipro when Azim stepped down as executive chairman in July 2019.',
     'rel': 'The son to whom he handed leadership of Wipro.'},
    {'name': 'Bill Gates & Warren Buffett', 'role': 'Giving Pledge founders', 'color': '#166534',
     'bio': 'The founders of the Giving Pledge, the campaign urging the world’s richest to give away most of their wealth; Premji became its first Indian signatory in 2013.',
     'rel': 'The philanthropists whose pledge Premji was first in India to join.'},
    {'name': 'IBM', 'role': 'departed rival', 'color': '#b91c1c',
     'bio': 'The American computing giant forced out of India in 1977 over ownership rules, leaving a market vacuum that Premji seized to move Wipro into computing.',
     'rel': 'The exit that opened Wipro’s path into information technology.'},
    {'name': 'TCS & Infosys', 'role': 'IT rivals', 'color': '#a16207',
     'bio': 'India’s other leading IT-services companies, alongside which Wipro became one of the “big three” exporters powering India’s software boom.',
     'rel': 'The peers against whom Wipro built India’s IT industry.'},
]

KEY_EVENTS = [
    ('1945', 'Azim Premji born', 'Bombay, into a Gujarati trading family.'),
    ('1945', 'Western India Vegetable Products', 'His father’s vanaspati-and-soap firm.'),
    ('1966', 'Takes over at 21', 'Returns from Stanford after his father’s death.'),
    ('1977', 'Renamed Wipro', 'The company sheds its oil-and-soap identity.'),
    ('1977', 'IBM leaves India', 'Premji pivots Wipro into computing.'),
    ('2000', 'NYSE listing', 'Wipro’s stock lists in New York.'),
    ('2001', 'Azim Premji Foundation', 'Philanthropy for school education.'),
    ('2010', 'Azim Premji University', 'Founded in Bangalore.'),
    ('2013', 'Signs the Giving Pledge', 'First Indian to join; gives away the bulk.'),
    ('2019', 'Steps down; $21bn endowment', 'Son Rishad succeeds; a historic gift.'),
]

MASTER = [
    {'year': '1945', 'age': 'born', 'phase': 'Oil & Stanford', 'title': 'Born in Bombay', 'desc': 'A Gujarati trading family.'},
    {'year': '1966', 'age': 'age 21', 'phase': 'The Inheritance', 'title': 'Takes over Wipro', 'desc': 'Father dies; leaves Stanford.'},
    {'year': '1977', 'age': 'age 32', 'phase': 'The Pivot', 'title': 'IBM exits; renamed Wipro', 'desc': 'Enters computing.'},
    {'year': '2000', 'age': 'age 55', 'phase': 'The Billionaire', 'title': 'India’s richest man', 'desc': 'Wipro lists on the NYSE.'},
    {'year': '2001', 'age': 'age 56', 'phase': 'The Great Giving', 'title': 'Azim Premji Foundation', 'desc': 'Philanthropy for schools.'},
    {'year': '2013', 'age': 'age 68', 'phase': 'The Great Giving', 'title': 'Giving Pledge', 'desc': 'First Indian signatory.'},
    {'year': '2019', 'age': 'age 74', 'phase': 'The Great Giving', 'title': 'Steps down', 'desc': '~$21bn endowment; Rishad succeeds.'},
]

SOURCES = [
    ('Wikipedia — Azim Premji', 'https://en.wikipedia.org/wiki/Azim_Premji'),
    ('Britannica — Azim Premji', 'https://www.britannica.com/money/Azim-Premji'),
    ('The Giving Pledge — Azim Premji', 'https://givingpledge.org/pledger?pledgerId=177'),
    ('Wipro — About / History', 'https://www.wipro.com/about-us/'),
    ('Azim Premji Foundation', 'https://azimpremjifoundation.org/'),
    ('Azim Premji University', 'https://azimpremjiuniversity.edu.in/'),
    ('Forbes — Azim Premji', 'https://www.forbes.com/profile/azim-premji/'),
]

def build_meta():
    return {
        'pid': 'gm-premji.html', 'kind': 'man', 'emoji': '💻', 'accent': AC,
        'name': 'Azim Premji', 'years': 'b. 1945', 'group': 'Business & Industry',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The engineer-heir who transformed a cooking-oil company into the IT giant Wipro, became India’s richest man, and then gave away tens of billions — one of the world’s foremost philanthropists.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'roots', 'label': '1 · Oil & Stanford', 'type': 'timeline',
             'intro': 'Born in 1945 into a Gujarati trading family, Azim Premji is sent to Stanford to study engineering while his father runs a modest maker of vegetable oil and soap.', 'events': PHASE_ROOTS},
            {'id': 'inherit', 'label': '2 · The Inheritance', 'type': 'timeline',
             'intro': 'His father’s sudden death in 1966 hands him the company at twenty-one; he professionalises and diversifies it, and renames it Wipro.', 'events': PHASE_INHERIT},
            {'id': 'pivot', 'label': '3 · The Pivot', 'type': 'timeline',
             'intro': 'When IBM is forced out of India in 1977, Premji seizes the opening — moving Wipro into computing and IT services, and becoming India’s richest man.', 'events': PHASE_PIVOT},
            {'id': 'leader', 'label': '4 · The Billionaire', 'type': 'timeline',
             'intro': 'He builds Wipro on quality and integrity, lives with famous frugality despite his billions, and is honoured as the elder statesman of Indian IT.', 'events': PHASE_LEADER},
            {'id': 'giving', 'label': '5 · The Great Giving', 'type': 'timeline',
             'intro': 'In his final chapter Premji founds a foundation and a university for education, signs the Giving Pledge, and transfers tens of billions to philanthropy before stepping down.', 'events': PHASE_GIVING,
             'sources': SOURCES, 'srcnote': 'Encyclopaedic and corporate sources; share-transfer figures and valuations are as reported at the time and fluctuate with markets.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
