# -*- coding: utf-8 -*-
"""Full, DEEP guide content for the Kangxi Emperor.
The boy who seized power at fifteen and reigned sixty-one years to consolidate the Qing empire."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#9a6a00'  # Qing imperial gold

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE BOY EMPEROR
PHASE_RISE = [
    E('accession', '1654–1661', 'A child on the Dragon Throne', ['RISE', 'TURNING POINT'],
      'Born Aisin Gioro Xuanye in 1654, the third son of the Shunzhi Emperor, the boy is enthroned at just seven years old when smallpox kills his father — chosen in part because he had already survived the disease — inheriting a fragile Manchu conquest of China barely a generation old.',
      svg_row('A seven-year-old inherits an empire', [
          {'n': 1, 'label': 'Born Xuanye, 1654', 'sub': 'third son of the Shunzhi Emperor', 'color': '#9a6a00'},
          {'n': 2, 'label': 'Shunzhi dies of smallpox, 1661', 'sub': 'the throne falls to a child', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Enthroned at age seven', 'sub': 'a smallpox survivor, era name Kangxi', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='A boy of seven inherited a Manchu conquest barely a generation old — the reign that followed would last sixty-one years.', accent=AC),
      bg='<b>Aisin Gioro Xuanye</b> was born in 1654, the third son of the <b>Shunzhi Emperor</b>, the first Qing ruler to sit in Beijing after the Manchu conquest of 1644.',
      people='his father the <b>Shunzhi Emperor</b>; his formidable grandmother the <b>Grand Empress Dowager Xiaozhuang</b>; the Manchu court of a young dynasty.',
      what='When Shunzhi died of <b>smallpox in 1661</b>, the seven-year-old Xuanye was enthroned — chosen partly because he had <b>already survived smallpox</b> — and given the era name <b>Kangxi</b>, meaning “peaceful harmony.”',
      crux='He came to power as a <b>child ruler of a conquest dynasty</b>, the Manchu grip on Han China still new and far from secure.',
      conseq='Real power lay with a council of regents until the boy could come of age.',
      matters='The longest reign in Chinese history began with a child on a shaky throne — everything he built, he had to build from that vulnerability.'),

    E('regency', '1661–1669', 'The four regents and the tyranny of Oboi', ['RISE', 'POLITICS'],
      'The child emperor is governed by four Manchu regents appointed by his father — but one of them, the powerful general Oboi, ruthlessly outmanoeuvres and destroys his colleagues, monopolising power, defying the young emperor, and threatening to reduce the boy Kangxi to a figurehead in his own court.',
      svg_stack('Power seized by an overmighty regent', [
          {'n': 1, 'label': 'Four regents rule for the boy', 'sub': 'Sonin, Suksaha, Ebilun and Oboi', 'color': '#9a6a00'},
          {'n': 2, 'label': 'Oboi crushes his rivals', 'sub': 'engineers the death of Suksaha, 1667', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A general above the throne', 'sub': 'Oboi defies the young emperor', 'color': '#78350f'},
      ], takeaway='One regent turned a shared trust into a personal tyranny — the boy emperor was a sovereign in name only.', accent=AC),
      bg='Shunzhi had named four regents to govern during Kangxi’s minority: <b>Sonin, Suksaha, Ebilun and Oboi</b>, all senior Manchu officers.',
      people='the four regents; above all the general <b>Oboi</b>; the Grand Empress Dowager <b>Xiaozhuang</b>, watching over her grandson.',
      what='The ambitious <b>Oboi</b> outmanoeuvred the others — forcing the execution of <b>Suksaha in 1667</b> — and monopolised authority, treating the teenage emperor with open contempt.',
      crux='A regency meant to protect the boy had become a <b>vehicle for one man’s domination</b>, endangering the throne itself.',
      conseq='Kangxi, coming of age, resolved to break Oboi’s grip before it became permanent.',
      matters='Regencies are the danger years of any minority reign — the ruler who cannot reclaim his own power is a ruler only in name.'),

    E('seizepower', '1669', 'Seizing power at fifteen — the fall of Oboi', ['RISE', 'TRIUMPH', 'TURNING POINT'],
      'At just fifteen, Kangxi springs a daring trap — training a band of young wrestlers as his personal guard, he summons Oboi to an audience and has the astonished general seized bare-handed, stripping him of power and taking personal control of the empire in a bloodless coup.',
      svg_row('A teenage emperor outwits a warlord', [
          {'n': 1, 'label': 'Trains a guard of wrestlers', 'sub': 'young companions drilled in secret', 'color': '#9a6a00'},
          {'n': 2, 'label': 'Oboi seized at audience, 1669', 'sub': 'arrested bare-handed by the boys', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Kangxi takes personal rule', 'sub': 'the emperor governs at last, age 15', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='At fifteen he outwitted the strongest man in the empire without a battle — and became emperor in fact as well as name.', accent=AC),
      bg='By 1669 Kangxi was fifteen and determined to rule in his own right, but Oboi commanded the loyalty of much of the Manchu establishment.',
      people='the emperor <b>Kangxi</b>; the general <b>Oboi</b>; the band of young wrestlers who served as Kangxi’s trusted guard.',
      what='Kangxi secretly trained a corps of youthful <b>wrestlers</b>, then summoned Oboi to an audience where the boys <b>seized him bare-handed (1669)</b>. Convicted of numerous crimes, Oboi was imprisoned, and Kangxi <b>assumed personal control of the empire</b>.',
      crux='He removed an overmighty subject by <b>surprise and nerve rather than civil war</b> — a bloodless masterstroke by a teenager.',
      conseq='Now truly in command, Kangxi faced the far greater task of securing the whole Qing conquest.',
      matters='Reclaiming power is the first test of a boy king — Kangxi passed it at fifteen, with cunning instead of bloodshed.'),
]

# ==================================================================  PHASE 2 — SECURING THE REALM
PHASE_SECURE = [
    E('feudatories', '1673–1681', 'The Revolt of the Three Feudatories', ['BATTLE', 'POLITICS', 'TURNING POINT'],
      'When Kangxi moves to abolish the vast semi-independent southern fiefs, their warlords rise in revolt under Wu Sangui — the very general who had opened the gates to the Manchus — plunging the empire into an eight-year civil war that Kangxi, against his advisors’ caution, presses to total victory.',
      svg_stack('The great southern rebellion crushed', [
          {'n': 1, 'label': 'Kangxi revokes the fiefs', 'sub': 'moves against three overmighty warlords', 'color': '#9a6a00'},
          {'n': 2, 'label': 'Wu Sangui leads the revolt, 1673', 'sub': 'the south erupts in eight-year war', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Total victory, 1681', 'sub': 'the feudatories destroyed, unity restored', 'color': '#166534'},
      ], takeaway='He gambled the dynasty on breaking the warlords rather than tolerating them — and won an empire truly under central rule.', accent=AC),
      bg='Three powerful generals — chief among them <b>Wu Sangui</b> — held quasi-independent fiefs in the south as reward for helping the Manchu conquest. Their power rivalled the throne’s.',
      people='<b>Wu Sangui</b>, the leading rebel; <b>Geng Jingzhong</b> and <b>Shang Zhixin</b>, his fellow feudatories; the young emperor who chose confrontation.',
      what='Kangxi’s decision to <b>abolish the fiefs</b> sparked the <b>Revolt of the Three Feudatories (1673–1681)</b>, an eight-year civil war across southern China. Rejecting calls to compromise, Kangxi pressed the fight to <b>complete victory in 1681</b>.',
      crux='He refused to let <b>overmighty subjects</b> carve the empire into private domains, staking everything on central authority.',
      conseq='Victory made the Qing masters of all China south of the Great Wall and freed Kangxi to look outward.',
      matters='A unified state cannot tolerate rival power centres — Kangxi risked his throne to prove the point, and secured the dynasty for centuries.'),

    E('taiwan', '1683', 'Annexing Taiwan — the last Ming resistance falls', ['BATTLE', 'TRIUMPH'],
      'Kangxi turns to the island of Taiwan, the last redoubt of Ming loyalism held by the sea-lord dynasty founded by Koxinga — dispatching the defector admiral Shi Lang, who shatters the Zheng fleet at the Penghu islands and brings Taiwan under imperial rule for the first time in Chinese history.',
      svg_row('The Ming loyalist stronghold conquered', [
          {'n': 1, 'label': 'Taiwan holds out under the Zheng', 'sub': 'the sea-realm founded by Koxinga', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Admiral Shi Lang sails, 1683', 'sub': 'a defector leads the Qing fleet', 'color': '#9a6a00'},
          {'n': 3, 'label': 'Victory at Penghu', 'sub': 'the Zheng surrender; Taiwan annexed', 'color': '#166534'},
      ], edge_labels=['met by', 'so'], takeaway='He extinguished the last Ming resistance and brought Taiwan into the empire — a maritime conquest a continental dynasty had never made.', accent=AC),
      bg='The <b>Zheng regime</b>, founded by the pirate-admiral <b>Koxinga</b> (Zheng Chenggong), ruled Taiwan as a base of <b>Ming loyalist resistance</b> after driving out the Dutch in 1662.',
      people='the emperor <b>Kangxi</b>; the Qing admiral <b>Shi Lang</b>, himself a former Zheng officer; the last Zheng ruler <b>Zheng Keshuang</b>.',
      what='Kangxi sent <b>Admiral Shi Lang</b>, who destroyed the Zheng fleet at the <b>Battle of Penghu (1683)</b>. Zheng Keshuang surrendered, and Taiwan was <b>incorporated into the Qing empire</b> — the first time it came under a Chinese state.',
      crux='He erased the <b>last organised Ming loyalism</b> and extended imperial power across the sea, a rare maritime venture for a land empire.',
      conseq='With the south and Taiwan pacified, the Ming cause was finally dead and the Qing throne unchallenged within China.',
      matters='Conquest is not complete while a rival banner still flies — Kangxi pursued the last holdouts to the sea to finish the work.'),

    E('nerchinsk', '1689', 'The Treaty of Nerchinsk — China’s first modern treaty', ['POLITICS', 'REFORM'],
      'On the Amur frontier, Kangxi checks the advance of Tsarist Russia and negotiates the Treaty of Nerchinsk — China’s first treaty with a European power, drafted with Jesuit interpreters in Latin, fixing the northern border, halting Russian expansion, and treating the two empires as diplomatic equals.',
      svg_stack('A settled border with an advancing empire', [
          {'n': 1, 'label': 'Russia presses the Amur frontier', 'sub': 'Cossacks clash with the Qing in the north', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Treaty of Nerchinsk, 1689', 'sub': 'negotiated in Latin via Jesuit interpreters', 'color': '#9a6a00'},
          {'n': 3, 'label': 'A fixed and stable border', 'sub': 'two empires treat as equals', 'color': '#166534'},
      ], takeaway='He met a European power on equal terms and secured the north by treaty — a diplomatic settlement that held for over a century.', accent=AC),
      bg='Russian expansion east had reached the <b>Amur River</b>, bringing Cossack settlers into collision with the Qing frontier.',
      people='the emperor <b>Kangxi</b>; the Russian negotiators; the <b>Jesuit interpreters</b> who translated the terms into Latin.',
      what='After frontier clashes, Kangxi concluded the <b>Treaty of Nerchinsk (1689)</b> — <b>China’s first treaty with a European state</b> — fixing the Sino-Russian border along the Amur watershed, halting Russian expansion, and regulating trade between equals.',
      crux='He handled a rising European empire not by war alone but by <b>negotiated settlement</b>, using Jesuit expertise to bridge two worlds.',
      conseq='The northern border held for over 150 years, freeing Kangxi to concentrate on the Mongol threat to the west.',
      matters='Diplomacy can secure what force cannot hold — Nerchinsk showed a Chinese empire dealing with the West as a peer, not a supplicant.'),
]

# ==================================================================  PHASE 3 — THE NORTHERN FRONTIER
PHASE_FRONTIER = [
    E('dzungars', '1690–1697', 'Breaking the Dzungars — the emperor takes the field', ['BATTLE', 'TRIUMPH'],
      'To the northwest rises Galdan, khan of the Dzungar Mongols, threatening to rebuild a steppe empire on the Qing frontier — and Kangxi personally leads his armies deep into Mongolia across three gruelling campaigns, shattering Galdan at the Battle of Jao Modo and driving the last great nomad threat from the field.',
      svg_row('The last steppe empire shattered', [
          {'n': 1, 'label': 'Galdan builds a Mongol power', 'sub': 'the Dzungar khan menaces the frontier', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Kangxi leads in person', 'sub': 'three campaigns into Mongolia, 1690–96', 'color': '#9a6a00'},
          {'n': 3, 'label': 'Victory at Jao Modo, 1696', 'sub': 'Galdan crushed; he dies in 1697', 'color': '#166534'},
      ], edge_labels=['met by', 'so'], takeaway='He rode out at the head of his own armies to break the last great nomad power — securing the steppe frontier by personal command.', accent=AC),
      bg='<b>Galdan</b>, khan of the <b>Dzungar Mongols</b>, sought to forge a new steppe empire and drew the Khalkha Mongols and the Qing into war.',
      people='the emperor <b>Kangxi</b>, campaigning in person; the Dzungar khan <b>Galdan</b>; the Khalkha Mongols who submitted to Qing protection.',
      what='Kangxi <b>personally led three campaigns (1690–1696)</b> across the Gobi, defeating Galdan decisively at the <b>Battle of Jao Modo (1696)</b>. Galdan died the following year, breaking Dzungar power for a generation.',
      crux='He met the ancient <b>nomad menace</b> not from the palace but on the steppe itself, leading his own troops through hardship and famine.',
      conseq='Outer Mongolia was bound firmly to the Qing, though the Dzungar problem would flare again under his successors.',
      matters='A frontier is held by the ruler willing to ride out and defend it — Kangxi’s personal campaigns tied the steppe to the throne.'),

    E('manchuhan', '1670s–1700s', 'Ruling Han China — conquest turned into legitimacy', ['POLITICS', 'REFORM'],
      'A Manchu ruling a vast Han majority, Kangxi masters the hardest art of the conquest dynasty — upholding Manchu military identity through the banner system while embracing Confucian governance, retaining Han officials, and presenting himself as a legitimate Son of Heaven rather than a foreign occupier.',
      svg_compare('Balancing two peoples under one throne', {
          'head': 'Manchu foundation', 'color': '#78350f', 'items': [
              'the Eight Banners as military backbone',
              'Manchu identity and language preserved',
              'a conquest elite kept distinct',
              'the queue imposed as a mark of submission',
          ]}, {
          'head': 'Confucian legitimacy', 'color': '#9a6a00', 'items': [
              'the examination system and Han scholar-officials',
              'rule as a Confucian Son of Heaven',
              'patronage of Chinese learning and ritual',
              'governing through existing institutions',
          ]},
      verdict='Kangxi fused Manchu power with Confucian legitimacy — a foreign dynasty that ruled as a Chinese one.',
      takeaway='He held down a vast Han majority by becoming, in style and substance, a legitimate Confucian emperor — not merely a conqueror.', accent=AC),
      bg='The Manchus were a tiny minority ruling tens of millions of Han Chinese, a conquest still resented a generation after 1644.',
      people='the <b>Han scholar-officials</b> he cultivated; the <b>Manchu banner elite</b> he preserved; the Confucian gentry whose loyalty he courted.',
      what='Kangxi upheld the <b>Eight Banners</b> and Manchu identity while ruling through <b>Confucian institutions</b> — retaining the examination system, employing Han officials, and presenting himself as a virtuous <b>Son of Heaven</b> rather than an alien overlord.',
      crux='He solved the conquest dynasty’s central problem by <b>winning legitimacy</b>, not just enforcing submission.',
      conseq='His synthesis stabilised Qing rule and became the model for the dynasty’s long dominance over China.',
      matters='Lasting rule over a conquered majority comes from legitimacy, not force alone — Kangxi ruled as a Chinese emperor while remaining a Manchu one.'),

    E('tours', '1680s–1700s', 'The Southern Inspection Tours', ['POLITICS', 'REFORM'],
      'Kangxi leaves the palace to tour the empire, especially the wealthy and once-rebellious south — inspecting the great flood-control works on the Yellow River, courting the Han gentry face to face, honouring Confucius and the Ming tombs, and binding the realm to himself through personal presence rather than distant decree.',
      svg_stack('An emperor who rules by showing himself', [
          {'n': 1, 'label': 'Six great southern tours', 'sub': 'the emperor travels the Yangzi heartland', 'color': '#9a6a00'},
          {'n': 2, 'label': 'Inspects rivers and courts gentry', 'sub': 'oversees flood works; honours Confucius', 'color': '#1d4e89'},
          {'n': 3, 'label': 'Wins the loyal south', 'sub': 'personal rule binds the once-rebel region', 'color': '#166534'},
      ], takeaway='He governed by travelling among his people — turning the rich, wary south into a loyal heartland through his own presence.', accent=AC),
      bg='The prosperous Yangzi south had backed Ming loyalism and the feudatory revolt; its gentry and its rivers both needed the emperor’s attention.',
      people='the emperor <b>Kangxi</b>; the <b>Han gentry</b> of the south he wooed; the river engineers managing the <b>Yellow River</b> works.',
      what='Kangxi made <b>six grand Southern Inspection Tours</b>, personally overseeing the vital <b>flood-control and grain-transport works</b>, meeting Han elites, and paying public homage at the tomb of the Ming founder and the shrine of Confucius.',
      crux='He understood rule as <b>presence and patronage</b> — an emperor seen among his people, honouring their traditions.',
      conseq='The tours cemented southern loyalty and burnished his image as a diligent, legitimate Confucian sovereign.',
      matters='Authority is renewed by contact, not distance — Kangxi bound his richest region to the throne by governing it in person.'),
]

# ==================================================================  PHASE 4 — SCHOLARSHIP AND THE WEST
PHASE_CULTURE = [
    E('dictionary', '1700s–1716', 'Patron of learning — the Kangxi Dictionary', ['REFORM', 'TRIUMPH'],
      'Kangxi makes himself the great patron of Chinese scholarship — commissioning vast encyclopaedic projects that culminate in the Kangxi Dictionary, a monumental compilation of some 47,000 characters that becomes the standard reference for two centuries and signals the Manchu throne’s guardianship of Confucian civilisation.',
      svg_row('The throne as patron of civilisation', [
          {'n': 1, 'label': 'Commissions great compilations', 'sub': 'gathers Han scholars for imperial projects', 'color': '#9a6a00'},
          {'n': 2, 'label': 'The Kangxi Dictionary, 1716', 'sub': 'some 47,000 characters catalogued', 'color': '#1d4e89'},
          {'n': 3, 'label': 'The standard for two centuries', 'sub': 'Manchu rule as guardian of learning', 'color': '#166534'},
      ], edge_labels=['yields', 'so'], takeaway='He made the Qing the patron of Chinese learning — a foreign dynasty cast as the guardian of Confucian civilisation.', accent=AC),
      bg='A conquest dynasty could win the loyalty of the scholar class by championing the very culture it had overrun.',
      people='the emperor <b>Kangxi</b>; the assembled <b>Han scholars and lexicographers</b>; the Confucian literati whose world he honoured.',
      what='Kangxi sponsored monumental scholarly works, above all the <b>Kangxi Dictionary (completed 1716)</b>, cataloguing roughly <b>47,000 characters</b>. It became the <b>authoritative reference</b> for Chinese script into the twentieth century.',
      crux='He turned <b>cultural patronage into political legitimacy</b>, binding the scholar-gentry to a Manchu throne.',
      conseq='The projects employed and co-opted the literati, and cast the Qing as protectors, not destroyers, of Chinese learning.',
      matters='Rulers legitimise themselves by championing culture — the dictionary that bears his name made Kangxi the guardian of a civilisation he had conquered.'),

    E('prosperity', '1700s–1712', 'Prosperity and the frozen poll tax', ['REFORM', 'TRIUMPH'],
      'After decades of war, Kangxi turns to the arts of peace — repairing the war-torn economy, keeping taxes light, and in a famous act of benevolence permanently freezing the head tax at its 1711 level, so that a growing population would never be taxed more, launching the long boom of the High Qing.',
      svg_stack('The war-torn realm restored to plenty', [
          {'n': 1, 'label': 'Rebuild after the wars', 'sub': 'recovery from rebellion and famine', 'color': '#9a6a00'},
          {'n': 2, 'label': 'Poll tax frozen, 1712', 'sub': 'the head tax fixed at its 1711 level forever', 'color': '#1d4e89'},
          {'n': 3, 'label': 'The High Qing boom', 'sub': 'population and prosperity surge', 'color': '#166534'},
      ], takeaway='He crowned the conquest with prosperity — a light-tax peace that launched a century of Qing abundance.', accent=AC),
      bg='After the feudatory war and frontier campaigns, the empire needed recovery; the emperor’s legitimacy now rested on prosperity, not just victory.',
      people='the emperor <b>Kangxi</b>; the peasant taxpayers he relieved; the officials who administered the fiscal reform.',
      what='Kangxi promoted recovery and, in a celebrated act, <b>permanently froze the poll (head) tax at its 1711 quota in 1712</b> — so a rising population would owe no more — while keeping the fiscal burden light.',
      crux='He governed the peace with a policy of <b>benevolence and restraint</b>, easing the burden on the people to build lasting stability.',
      conseq='The reform and the peace ushered in the <b>High Qing</b>, a long era of population growth and prosperity across three reigns.',
      matters='The hardest test of a conqueror is to govern well in peace — Kangxi’s light-handed prosperity became the foundation of the High Qing golden age.'),

    E('jesuits', '1670s–1715', 'The Jesuits, Western science, and the Rites Controversy', ['POLITICS', 'REFORM', 'TRAGEDY'],
      'Endlessly curious, Kangxi welcomes Jesuit missionaries to his court — learning mathematics, astronomy and geometry from them, employing them to cast cannon and map the empire, and tolerating their faith — until Rome’s ban on Confucian ancestor rites forces a rupture, and the openness to the West sours into the Chinese Rites Controversy.',
      svg_compare('Curiosity and its limits at court', {
          'head': 'Openness to the West', 'color': '#166534', 'items': [
              'studies mathematics and astronomy with Jesuits',
              'Verbiest reforms the calendar and casts cannon',
              'Jesuits map the empire for the throne',
              'the 1692 Edict of Toleration for Catholicism',
          ]}, {
          'head': 'The rupture', 'color': '#b91c1c', 'items': [
              'Rome bans Confucian ancestor rites',
              'the Pope claims authority over Chinese converts',
              'Kangxi rejects foreign interference in ritual',
              'the Rites Controversy chills the mission',
          ]},
      verdict='He embraced Western science freely, but drew the line where Rome challenged Confucian rites and imperial authority.',
      takeaway='He took what the West offered in learning, then closed the door when Rome demanded control over his subjects’ deepest rites.', accent=AC),
      bg='<b>Jesuit missionaries</b> had won a foothold at the Ming and Qing courts through their mastery of astronomy, mathematics and cartography.',
      people='the emperor <b>Kangxi</b>, an avid student; the Jesuit <b>Ferdinand Verbiest</b> and his colleagues; the <b>Pope</b>, whose decrees ended the détente.',
      what='Kangxi studied <b>mathematics and astronomy</b> under the Jesuits, employed <b>Ferdinand Verbiest</b> to reform the calendar and cast cannon, had them <b>map the empire</b>, and issued a <b>1692 Edict of Toleration</b> — until Rome’s ban on <b>Confucian ancestor rites</b> triggered the <b>Chinese Rites Controversy</b> and cooled his favour.',
      crux='He welcomed Western <b>knowledge</b> but would not accept a foreign church’s authority over <b>Chinese rites and his own subjects</b>.',
      conseq='The controversy curbed the Christian mission in China and hardened later Qing suspicion of the West.',
      matters='Openness has limits set by sovereignty — Kangxi absorbed Western science but refused to let Rome govern his people’s traditions.'),
]

# ==================================================================  PHASE 5 — THE BITTER SUCCESSION
PHASE_END = [
    E('yinreng', '1708–1712', 'The heir apparent deposed — twice', ['POLITICS', 'TRAGEDY'],
      'Kangxi breaks with Manchu custom to name a formal heir, his beloved son Yinreng — but the crown prince’s cruelty, intrigue and instability drive the anguished emperor to depose him, restore him, and depose him again, leaving the succession fatally open and the aging ruler wracked with grief.',
      svg_stack('A cherished heir who cannot be trusted', [
          {'n': 1, 'label': 'Yinreng named crown prince', 'sub': 'a rare formal heir, favoured from infancy', 'color': '#9a6a00'},
          {'n': 2, 'label': 'Deposed in 1708', 'sub': 'cruelty and intrigue force his fall', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Restored, then deposed again, 1712', 'sub': 'the succession left dangerously open', 'color': '#78350f'},
      ], takeaway='The one son he raised to rule proved unfit — and the twice-broken heir left the succession a wound that would not close.', accent=AC),
      bg='Breaking Manchu tradition, Kangxi had named his second son <b>Yinreng</b> heir apparent as a small child, lavishing hopes on him.',
      people='the emperor <b>Kangxi</b>; the crown prince <b>Yinreng</b>; the rival princes watching the heir stumble.',
      what='Yinreng’s <b>misconduct and instability</b> led Kangxi to <b>depose him in 1708</b>, restore him in 1709 amid doubts of a plot, and <b>depose him for good in 1712</b> — after which the emperor refused to name any successor openly.',
      crux='His attempt to fix the succession in advance <b>collapsed</b>, leaving the greatest question of his reign unresolved.',
      conseq='With no acknowledged heir, his many sons manoeuvred for the throne in the emperor’s final years.',
      matters='Even the ablest ruler can fail at the succession — Kangxi’s heartbreak over Yinreng opened the door to a war among his sons.'),

    E('princes', '1712–1722', 'The war of the princes', ['POLITICS', 'TRAGEDY'],
      'With the heir cast down and no successor named, Kangxi’s numerous sons split into rival factions in a bitter, years-long struggle for the throne — a poisonous contest of intrigue and suspicion that shadows the emperor’s last decade and would end only with the disputed accession of his fourth son as the Yongzheng Emperor.',
      svg_row('A dynasty at war with itself', [
          {'n': 1, 'label': 'No heir named after 1712', 'sub': 'the throne left open among the sons', 'color': '#78350f'},
          {'n': 2, 'label': 'The princes form factions', 'sub': 'years of intrigue for the succession', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Yongzheng prevails, 1722', 'sub': 'the fourth son takes a disputed throne', 'color': '#9a6a00'},
      ], edge_labels=['so', 'until'], takeaway='The open succession turned his sons into rivals — the reign’s glory ended amid a poisonous struggle for the throne.', accent=AC),
      bg='After Yinreng’s final fall, Kangxi named no heir, and his many capable sons each saw a path to the throne.',
      people='the aging <b>Kangxi</b>; the contending princes; the fourth son, the future <b>Yongzheng Emperor</b>, who would win.',
      what='Kangxi’s sons split into <b>rival factions</b> in a prolonged succession struggle. It was resolved only at his death in 1722, when his <b>fourth son took the throne as the Yongzheng Emperor</b> amid lasting rumours that the succession was manipulated.',
      crux='The failure to settle the succession turned the imperial family into a <b>nest of rivalries</b> that clouded the reign’s end.',
      conseq='Yongzheng, once secure, purged his rival brothers and later devised a secret system to avoid such a crisis again.',
      matters='An unsettled succession corrodes even a great reign from within — Kangxi’s triumphs ended in a bitter contest among his own children.'),

    E('death', '1722', 'Death and the shadow of the longest reign', ['DEATH', 'TRIUMPH'],
      'Kangxi dies in 1722 after sixty-one years on the throne — the longest reign in Chinese history — leaving a Qing empire vastly expanded, prosperous and secure, the foundation of the High Qing golden age, even as the manner of his succession would be whispered about for generations.',
      svg_stack('The end of the longest reign', [
          {'n': 1, 'label': 'Dies in 1722, aged 68', 'sub': 'after 61 years, the longest reign in China', 'color': '#9a6a00'},
          {'n': 2, 'label': 'An empire secured and enriched', 'sub': 'expanded borders and lasting prosperity', 'color': '#166534'},
          {'n': 3, 'label': 'Foundation of the High Qing', 'sub': 'a golden age across three reigns', 'color': '#1d4e89'},
      ], takeaway='He left the empire larger, richer and more secure than he found it — the bedrock of the Qing golden age, whatever the doubts about his heir.', accent=AC),
      bg='By 1722 Kangxi had ruled for sixty-one years, having taken a fragile conquest and forged it into a consolidated empire.',
      people='the dying emperor <b>Kangxi</b>; his successor the <b>Yongzheng Emperor</b>; the dynasty and people he left behind.',
      what='Kangxi <b>died in 1722 after a 61-year reign</b>, the <b>longest in Chinese history</b>, bequeathing an empire that was territorially vast, fiscally sound and at peace — the <b>foundation of the High Qing era</b> — though rumours long surrounded his succession.',
      crux='He left a <b>consolidated and prosperous Qing</b>, transforming a young conquest into an enduring imperial order.',
      conseq='The stability and expansion he built carried the dynasty to its zenith under Yongzheng and Qianlong.',
      matters='Greatness is measured by what endures — Kangxi turned a shaky conquest into a golden age that outlived him by a century.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">The Kangxi Emperor took the throne of China as a boy of seven and held it for sixty-one years — the longest reign in Chinese history. Seizing power from his overmighty regent at fifteen, he crushed the great southern revolt, annexed Taiwan, checked Russia by treaty, and rode out in person to shatter the last Mongol steppe empire. A Manchu ruling a vast Han majority, he won legitimacy by governing as a Confucian sage-emperor — patron of the great dictionary that bears his name — while embracing Jesuit science with a curious mind. He is the ultimate study in <b>consolidating a conquest, ruling a foreign majority, and turning war into a golden age.</b></p>
<div class="ov-quote">“The longest-reigning emperor in Chinese history — architect of the High Qing.”<span>— on the Kangxi Emperor</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A child is enthroned at seven and seizes real power at fifteen by trapping his regent → he crushes the Revolt of the Three Feudatories and annexes Taiwan → settles the Russian frontier at Nerchinsk and breaks the Dzungars in person → rules the Han majority as a Confucian emperor, patronising scholarship and welcoming Jesuit science → froze taxes to launch a prosperous peace → but the bitter struggle among his sons over the succession shadows his final years and his death in 1722.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🀄</div><h4>The longest reign</h4><p>Sixty-one years that consolidated the Qing conquest into an empire.</p></div>
  <div class="ov-card"><div class="i">⚔️</div><h4>Securing the realm</h4><p>Feudatories crushed, Taiwan annexed, the steppe and the north secured.</p></div>
  <div class="ov-card"><div class="i">📜</div><h4>Confucian legitimacy</h4><p>A Manchu who ruled a Han majority as a legitimate sage-emperor.</p></div>
  <div class="ov-card"><div class="i">🌏</div><h4>Openness and its limits</h4><p>Jesuit science embraced, until Rome challenged Confucian rites.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Boy Emperor</b><small> 1654–1669</small><p>Enthroned at seven; seizes power at fifteen.</p></div>
  <div><b>2 · Securing the Realm</b><small> 1673–1689</small><p>Feudatories, Taiwan, and the Russian treaty.</p></div>
  <div><b>3 · The Northern Frontier</b><small> 1690–1700s</small><p>Breaking the Dzungars; ruling Han China.</p></div>
  <div><b>4 · Scholarship & the West</b><small> 1700s–1715</small><p>The dictionary, prosperity, and the Jesuits.</p></div>
  <div><b>5 · The Bitter Succession</b><small> 1708–1722</small><p>The heir deposed; the war of the princes.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Oboi', 'role': 'overmighty regent', 'color': '#b91c1c',
     'bio': 'The dominant Manchu regent who monopolised power during Kangxi’s minority and was arrested by the fifteen-year-old emperor’s wrestlers in 1669.',
     'rel': 'The tyrant-regent he overthrew to take personal rule.'},
    {'name': 'Wu Sangui', 'role': 'rebel warlord', 'color': '#78350f',
     'bio': 'The general who had opened the gates to the Manchus, then led the Revolt of the Three Feudatories against Kangxi from 1673.',
     'rel': 'The great rebel whose revolt Kangxi crushed to unify China.'},
    {'name': 'Shi Lang', 'role': 'admiral', 'color': '#166534',
     'bio': 'A former Zheng officer turned Qing admiral who destroyed the Zheng fleet at Penghu and won Taiwan for the empire in 1683.',
     'rel': 'The commander who conquered Taiwan in his name.'},
    {'name': 'Galdan', 'role': 'Dzungar khan', 'color': '#1d4e89',
     'bio': 'The Dzungar Mongol khan who sought to build a steppe empire and was defeated by Kangxi in person at Jao Modo in 1696.',
     'rel': 'The nomad adversary he broke on the steppe.'},
    {'name': 'Ferdinand Verbiest', 'role': 'Jesuit at court', 'color': '#9a6a00',
     'bio': 'The Flemish Jesuit who reformed the calendar, cast cannon and tutored Kangxi in Western astronomy and mathematics.',
     'rel': 'The Jesuit who taught him Western science.'},
]

KEY_EVENTS = [
    ('1654', 'Xuanye born', 'Third son of the Shunzhi Emperor.'),
    ('1661', 'Enthroned at seven', 'Era name Kangxi; four regents rule.'),
    ('1669', 'Oboi overthrown', 'Seizes personal power at fifteen.'),
    ('1673–81', 'Three Feudatories', 'Southern revolt crushed by 1681.'),
    ('1683', 'Taiwan annexed', 'Shi Lang defeats the Zheng regime.'),
    ('1689', 'Treaty of Nerchinsk', 'The Russian frontier settled.'),
    ('1696', 'Battle of Jao Modo', 'Galdan and the Dzungars broken.'),
    ('1712', 'Poll tax frozen', 'A light-tax peace; the High Qing.'),
    ('1716', 'Kangxi Dictionary', 'The standard reference for two centuries.'),
    ('1722', 'Death of Kangxi', 'The longest reign in Chinese history ends.'),
]

MASTER = [
    {'year': '1654', 'age': 'born', 'phase': 'The Boy Emperor', 'title': 'Born Xuanye', 'desc': 'Son of the Shunzhi Emperor.'},
    {'year': '1661', 'age': 'age 7', 'phase': 'The Boy Emperor', 'title': 'Enthroned', 'desc': 'A child under four regents.'},
    {'year': '1669', 'age': 'age 15', 'phase': 'The Boy Emperor', 'title': 'Oboi overthrown', 'desc': 'Takes personal rule.'},
    {'year': '1681', 'age': 'age 27', 'phase': 'Securing the Realm', 'title': 'Feudatories crushed', 'desc': 'The south reunified.'},
    {'year': '1683', 'age': 'age 29', 'phase': 'Securing the Realm', 'title': 'Taiwan annexed', 'desc': 'The last Ming resistance falls.'},
    {'year': '1689', 'age': 'age 35', 'phase': 'Securing the Realm', 'title': 'Treaty of Nerchinsk', 'desc': 'The Russian border fixed.'},
    {'year': '1696', 'age': 'age 42', 'phase': 'The Northern Frontier', 'title': 'Jao Modo', 'desc': 'Galdan defeated in person.'},
    {'year': '1712', 'age': 'age 58', 'phase': 'Scholarship & the West', 'title': 'Poll tax frozen', 'desc': 'The High Qing prosperity.'},
    {'year': '1722', 'age': 'age 68', 'phase': 'The Bitter Succession', 'title': 'Death', 'desc': 'The longest reign ends.'},
]

SOURCES = [
    ('Britannica — Kangxi', 'https://www.britannica.com/biography/Kangxi'),
    ('World History Encyclopedia — Kangxi Emperor', 'https://www.worldhistory.org/Kangxi_Emperor/'),
    ('Britannica — Treaty of Nerchinsk', 'https://www.britannica.com/event/Treaty-of-Nerchinsk'),
    ('Britannica — Qing dynasty', 'https://www.britannica.com/topic/Qing-dynasty'),
    ('Wikipedia — Kangxi Emperor', 'https://en.wikipedia.org/wiki/Kangxi_Emperor'),
]

def build_meta():
    return {
        'pid': 'gm-kangxi.html', 'kind': 'man', 'emoji': '🀄', 'accent': AC,
        'name': 'Kangxi Emperor', 'years': '1654–1722', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Qing emperor who took the throne at seven and reigned sixty-one years — the longest in Chinese history — crushing revolts, annexing Taiwan, breaking the Mongols, and ruling a Han majority as a Confucian sage-emperor.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Boy Emperor', 'type': 'timeline',
             'intro': 'Enthroned at seven when smallpox kills his father, the child is ruled by regents until the overmighty Oboi threatens the throne — and at fifteen Kangxi springs a trap and seizes power for himself.', 'events': PHASE_RISE},
            {'id': 'secure', 'label': '2 · Securing the Realm', 'type': 'timeline',
             'intro': 'The young emperor crushes the vast Revolt of the Three Feudatories, annexes Taiwan from the last Ming loyalists, and settles the northern frontier with Russia by the Treaty of Nerchinsk.', 'events': PHASE_SECURE},
            {'id': 'frontier', 'label': '3 · The Northern Frontier', 'type': 'timeline',
             'intro': 'Kangxi rides out in person to shatter the Dzungar Mongols under Galdan, and masters the conquest dynasty’s hardest art — ruling a vast Han majority as a legitimate Confucian emperor.', 'events': PHASE_FRONTIER},
            {'id': 'culture', 'label': '4 · Scholarship & the West', 'type': 'timeline',
             'intro': 'The emperor makes himself patron of Chinese learning through the great dictionary that bears his name, launches a light-tax prosperity, and welcomes Jesuit science — until Rome’s ban on Confucian rites forces a rupture.', 'events': PHASE_CULTURE},
            {'id': 'end', 'label': '5 · The Bitter Succession', 'type': 'timeline',
             'intro': 'His attempt to name an heir collapses as the crown prince is deposed twice, and his many sons fall into a poisonous struggle for the throne that shadows his final years and his death in 1722.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; datings of the campaigns and reforms follow the mainstream scholarly consensus.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
