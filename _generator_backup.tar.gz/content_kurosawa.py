# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Akira Kurosawa.
The Japanese master whose Rashomon opened the West to Japanese cinema and whose Seven Samurai, Yojimbo and Ran reshaped world film."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b91c1c'  # a deep cinematic crimson

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE APPRENTICE
PHASE_APPRENTICE = [
    E('origins', '1910', 'A samurai’s son in Tokyo', ['RISE', 'ORIGINS'],
      'Akira Kurosawa is born on 23 March 1910 in the Ōmori district of Tokyo, the youngest of eight children in a family of samurai descent — his strict father Isamu, a former army officer who runs a school, prizes both traditional discipline and, unusually, Western movies, taking the children to the cinema and shaping a boy who will bridge East and West.',
      svg_row('A childhood between two worlds', [
          {'n': 1, 'label': 'Born in Tokyo, 23 March 1910', 'sub': 'youngest of eight, of samurai lineage', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A father who loved the cinema', 'sub': 'Isamu takes the children to Western films', 'color': '#3730a3'},
          {'n': 3, 'label': 'Tradition meets the modern West', 'sub': 'discipline and calligraphy beside Hollywood', 'color': '#166534'},
      ], edge_labels=['and', 'so'], takeaway='He grew up straddling the samurai past and the modern West — the very tension his films would later fuse.', accent=AC),
      bg='<b>Akira Kurosawa</b> was born on 23 March 1910 in the Ōmori district of Tokyo, the youngest of eight children in a middle-class family that traced its roots to the samurai class.',
      people='his father <b>Isamu Kurosawa</b>, a stern ex-military educator; his mother <b>Shima</b>; his artistically gifted elder brother <b>Heigo</b>.',
      what='Kurosawa was raised amid <b>traditional discipline</b> — calligraphy, kendo, Japanese classics — yet his father embraced Western culture and regularly took the family to <b>see foreign films</b>, so the boy absorbed both worlds at once.',
      crux='His upbringing planted the <b>fusion at the heart of his art</b> — the samurai ethos of old Japan expressed through the techniques and stories of the West.',
      conseq='A dreamy, artistic child, he first trained as a painter before finding his way into film.',
      matters='Great synthesizers are often raised at a crossroads — Kurosawa’s childhood between tradition and the West prefigured a body of work that belonged to both.'),

    E('heigo', '1920s–1933', 'Heigo, the benshi brother', ['TRAGEDY', 'TURNING POINT'],
      'Kurosawa’s beloved elder brother Heigo works as a benshi — a live narrator who voices and interprets silent films for Japanese audiences — and becomes the boy’s guide to art and cinema; but when the talkies arrive and destroy the benshi’s profession, Heigo takes his own life in 1933, a devastation Kurosawa carries all his life.',
      svg_stack('A mentor lost to the coming of sound', [
          {'n': 1, 'label': 'Heigo, a star benshi narrator', 'sub': 'voices silent films; young Akira’s guide', 'color': '#3730a3'},
          {'n': 2, 'label': 'Talkies destroy the benshi trade', 'sub': 'sound film makes live narration obsolete', 'color': '#78350f'},
          {'n': 3, 'label': 'Heigo’s suicide, 1933', 'sub': 'a wound Kurosawa never forgets', 'color': '#b91c1c'},
      ], takeaway='The brother who opened cinema to him was destroyed by cinema’s own progress — a loss that shadowed Kurosawa forever.', accent=AC),
      bg='In the silent era, Japanese films were accompanied by a <b>benshi</b>, a performer who stood beside the screen narrating the action and voicing the characters; it was a prestigious profession.',
      people='<b>Heigo Kurosawa</b>, Akira’s charismatic elder brother and a leading benshi; the younger Akira, who idolised him.',
      what='Heigo introduced Kurosawa to <b>literature, painting and film</b>, but the arrival of <b>sound cinema (the “talkies”)</b> wiped out the benshi’s livelihood; despairing, Heigo <b>took his own life in 1933</b>.',
      crux='The loss taught Kurosawa the <b>fragility of art and life</b> — and, some say, planted the streak of melancholy that runs beneath his most humane films.',
      conseq='Within a few years, and already drawn to painting and cinema, Kurosawa entered the film industry himself.',
      matters='Inspiration and grief can share a source — the brother who made Kurosawa love cinema was the first casualty of its transformation.'),

    E('apprentice', '1936–1942', 'Apprentice to Yamamoto at PCL', ['RISE', 'CRAFT'],
      'In 1936 Kurosawa answers a newspaper advertisement and joins the PCL film studio (soon absorbed into Toho), where he spends years as an assistant director under the genial master Kajiro Yamamoto — learning every craft of filmmaking, from editing to screenwriting, and calling this apprenticeship the finest schooling a director could have.',
      svg_row('Learning every craft on the studio floor', [
          {'n': 1, 'label': 'Joins PCL / Toho, 1936', 'sub': 'answers an ad; enters as assistant director', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Trains under Kajiro Yamamoto', 'sub': 'a mentor who let him write and edit', 'color': '#3730a3'},
          {'n': 3, 'label': 'Masters the whole toolkit', 'sub': 'screenwriting, editing, directing units', 'color': '#166534'},
      ], edge_labels=['under', 'so'], takeaway='He learned filmmaking whole — not one department but all of it — a total command that defined his later control.', accent=AC),
      bg='In 1936 the <b>Photo Chemical Laboratories (PCL) studio</b>, soon folded into <b>Toho</b>, advertised for assistant directors; Kurosawa applied and was hired.',
      people='<b>Kajiro Yamamoto</b>, the veteran director who became his mentor; fellow apprentices and screenwriters at Toho.',
      what='For several years Kurosawa was an <b>assistant director to Yamamoto</b>, who encouraged him to write scripts and edit; he later said this apprenticeship was the <b>ideal training</b> and called Yamamoto his best teacher.',
      crux='He absorbed the principle that a director must <b>understand every craft</b> — writing, editing, staging — and answer for the whole film.',
      conseq='By the early 1940s he was writing screenplays and ready to direct his own picture.',
      matters='Mastery is built in the trenches — Kurosawa’s total command of film began with years of doing every job on the set.'),

    E('sanshiro', '1943', 'Debut — Sanshiro Sugata', ['TRIUMPH', 'CRAFT'],
      'In 1943, in the midst of wartime, Kurosawa directs his first film, "Sanshiro Sugata," the story of a headstrong young judo student who learns discipline of spirit — an assured, kinetic debut that already displays his gift for movement, character and moral seriousness, and marks the arrival of a major new director.',
      svg_stack('A first film that announces a master', [
          {'n': 1, 'label': 'Sanshiro Sugata, 1943', 'sub': 'his directorial debut, made in wartime', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A judo student learns the spirit', 'sub': 'physical skill tempered by moral discipline', 'color': '#a16207'},
          {'n': 3, 'label': 'A bold new voice emerges', 'sub': 'dynamic editing, strong characters', 'color': '#166534'},
      ], takeaway='His very first film showed the trademark energy and moral gravity that would run through his whole career.', accent=AC),
      bg='By 1943 Japan was at war, and film production was tightly controlled; Kurosawa was nonetheless allowed to direct his first feature.',
      people='Kurosawa as first-time director; the studio Toho; actor <b>Susumu Fujita</b> in the title role.',
      what='<b>“Sanshiro Sugata” (1943)</b>, adapted from a popular novel, followed a hot-headed <b>judo student who matures through discipline</b>; its dynamic action and clear moral arc made it a success and an impressive debut.',
      crux='It revealed his instinct for <b>movement married to meaning</b> — action that dramatises inner growth, not mere spectacle.',
      conseq='The film’s success established him as a promising director within Toho, launching his career.',
      matters='Some artists arrive fully formed — Kurosawa’s debut already carried the signature of the master to come.'),

    E('wartime', '1944–1945', 'Filming under the war and occupation', ['POLITICS', 'CRAFT'],
      'Through the last years of the war Kurosawa makes films under strict state control — "The Most Beautiful" (1944), a semi-documentary about women factory workers, and "The Men Who Tread on the Tiger’s Tail" (1945) — chafing against censorship from both the militarist regime and, after Japan’s defeat, the American occupation authorities.',
      svg_row('Working under two sets of censors', [
          {'n': 1, 'label': 'The Most Beautiful, 1944', 'sub': 'women in a wartime optics factory', 'color': '#3730a3'},
          {'n': 2, 'label': 'Tiger’s Tail, 1945', 'sub': 'a kabuki-derived tale, then shelved', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Censored coming and going', 'sub': 'militarist rules, then Allied occupation', 'color': '#78350f'},
      ], edge_labels=['then', 'and'], takeaway='He learned to make personal art inside a cage of censorship — a discipline that sharpened his craft.', accent=AC),
      bg='In wartime and the immediate aftermath of Japan’s 1945 surrender, filmmaking was policed first by the militarist government and then by the <b>Allied occupation (SCAP)</b>.',
      people='Kurosawa; his crews at Toho; the censors of both the wartime state and the occupation; his wife-to-be, actress <b>Yōko Yaguchi</b>, whom he met on <b>The Most Beautiful</b>.',
      what='He directed <b>“The Most Beautiful” (1944)</b>, a propaganda-tinged story of female factory workers, and <b>“The Men Who Tread on the Tiger’s Tail” (1945)</b>, a short jidaigeki that occupation censors briefly banned.',
      crux='He learned to <b>smuggle humanity and craft past the censor</b> — to make something true within tight political limits.',
      conseq='With the occupation’s new freedoms, he soon turned to more openly personal and democratic themes.',
      matters='Constraint can school an artist — Kurosawa’s wartime work honed the discipline behind his later freedom.'),
]

# ==================================================================  PHASE 2 — THE BREAKTHROUGH
PHASE_BREAKTHROUGH = [
    E('noregrets', '1946', 'Democracy and No Regrets for Our Youth', ['POLITICS', 'RISE'],
      'In the liberated air of the occupation, Kurosawa makes "No Regrets for Our Youth" (1946), the story of a woman who defies militarist repression — his most overtly political film, embracing the new democratic ideals — as he begins to shape the humanist voice that will define his mature work.',
      svg_stack('A new Japan, a new theme', [
          {'n': 1, 'label': 'No Regrets for Our Youth, 1946', 'sub': 'a woman defies the militarist state', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Embracing democratic ideals', 'sub': 'individual conscience over blind obedience', 'color': '#3730a3'},
          {'n': 3, 'label': 'A humanist voice emerges', 'sub': 'the dignity of the individual', 'color': '#166534'},
      ], takeaway='He seized post-war freedom to make his most political film — and found the humanist theme that would run through his life’s work.', accent=AC),
      bg='After 1945 the American occupation encouraged films promoting democracy and individual rights, opening subjects long forbidden.',
      people='Kurosawa; actress <b>Setsuko Hara</b> in the lead; the occupation authorities who now favoured such themes.',
      what='<b>“No Regrets for Our Youth” (1946)</b> followed a privileged young woman who, through love and loss, comes to <b>resist militarist oppression</b> — Kurosawa’s most explicitly political picture.',
      crux='It affirmed the <b>worth and moral responsibility of the individual</b> against the crushing weight of the state.',
      conseq='The film confirmed his stature and pointed toward the deeply humane cinema of his coming masterpieces.',
      matters='Freedom lets an artist speak plainly — given liberty, Kurosawa chose to champion the individual conscience.'),

    E('drunkenangel', '1948', 'Drunken Angel — meeting Mifune', ['RISE', 'TURNING POINT'],
      'For "Drunken Angel" (1948), the tale of an alcoholic doctor and a tubercular young gangster in the ruins of post-war Tokyo, Kurosawa casts an explosive unknown named Toshiro Mifune — igniting the most celebrated director-actor partnership in cinema, sixteen films across seventeen years.',
      svg_row('The partnership that would define an era', [
          {'n': 1, 'label': 'Drunken Angel, 1948', 'sub': 'a doctor and a dying gangster in the ruins', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Discovers Toshiro Mifune', 'sub': 'a raw, feral screen presence', 'color': '#a16207'},
          {'n': 3, 'label': 'A 16-film collaboration begins', 'sub': 'director and star, 1948–1965', 'color': '#166534'},
      ], edge_labels=['casts', 'and'], takeaway='A single casting choice began the greatest actor-director partnership in film — Kurosawa and Mifune, sixteen films strong.', accent=AC),
      bg='Set in a black-market slum around a fetid sump in occupied Tokyo, <b>“Drunken Angel”</b> was Kurosawa’s first fully personal post-war statement.',
      people='<b>Toshiro Mifune</b>, the young actor cast as the gangster; <b>Takashi Shimura</b>, as the doctor — the two poles of Kurosawa’s stock company.',
      what='In <b>“Drunken Angel” (1948)</b> Kurosawa first directed <b>Toshiro Mifune</b>, whose volcanic energy so galvanised the film that the two would make <b>16 films together</b> over the next 17 years.',
      crux='He had found his <b>on-screen alter ego</b> — Mifune’s raw dynamism gave flesh to Kurosawa’s heroes and outcasts.',
      conseq='The Kurosawa–Mifune partnership produced Rashomon, Seven Samurai, Yojimbo and more, defining a golden age of Japanese film.',
      matters='Some collaborations are historic — Kurosawa’s camera and Mifune’s presence together made images the world remembers.'),

    E('rashomon', '1950–1951', 'Rashomon and the Golden Lion', ['TRIUMPH', 'TURNING POINT'],
      'In 1950 Kurosawa releases "Rashomon," in which a rape and murder are recounted in four irreconcilable versions, questioning the very nature of truth; entered at Venice, it wins the Golden Lion in 1951 and an honorary Oscar — stunning the West and single-handedly opening the world’s eyes to Japanese cinema.',
      svg_stack('The film that opened Japan to the world', [
          {'n': 1, 'label': 'Rashomon, 1950', 'sub': 'one crime, four contradictory tellings', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Golden Lion at Venice, 1951', 'sub': 'the West discovers Japanese cinema', 'color': '#a16207'},
          {'n': 3, 'label': 'Honorary Academy Award', 'sub': 'and a new global audience for Japan', 'color': '#166534'},
      ], takeaway='One film redrew the map of world cinema — Rashomon made Japanese film a global force overnight.', accent=AC),
      bg='By 1950 Japanese cinema was little known abroad; Kurosawa adapted two stories by <b>Ryūnosuke Akutagawa</b> into an experimental drama on the unreliability of truth.',
      people='<b>Toshiro Mifune</b> as the bandit; <b>Machiko Kyō</b> and <b>Takashi Shimura</b>; the Venice jurors who awarded it; Western critics and audiences.',
      what='<b>“Rashomon” (1950)</b> tells of a rape and killing in <b>four mutually contradictory accounts</b>; entered at Venice, it won the <b>Golden Lion (1951)</b> and an <b>honorary Academy Award</b>, astonishing the West.',
      crux='It proved that <b>Japanese cinema could speak to the whole world</b> — and gave the language a term, the “Rashomon effect,” for conflicting subjective truth.',
      conseq='Rashomon launched a wave of Japanese films onto Western screens and made Kurosawa an international name.',
      matters='A single work can open a door for a whole culture — Rashomon carried Japanese cinema onto the world stage.'),

    E('ikiru', '1952', 'Ikiru — a life redeemed', ['TRIUMPH', 'IDEAS'],
      'Kurosawa follows global fame with an intimate masterpiece, "Ikiru" (1952): a petty bureaucrat, told he is dying of cancer, spends his last months forcing a children’s playground into being — a profound meditation on how to live, and for many the most humane film Kurosawa ever made.',
      svg_row('How should a man live before he dies?', [
          {'n': 1, 'label': 'Ikiru (“To Live”), 1952', 'sub': 'a dying bureaucrat seeks meaning', 'color': '#3730a3'},
          {'n': 2, 'label': 'He builds a children’s playground', 'sub': 'one true act against decades of waste', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A meditation on how to live', 'sub': 'purpose redeems a wasted life', 'color': '#166534'},
      ], edge_labels=['so', 'as'], takeaway='After conquering the world stage he turned inward — asking, through one dying clerk, what makes a human life worthwhile.', accent=AC),
      bg='Fresh from international acclaim, Kurosawa turned from spectacle to a quiet contemporary story of mortality and meaning.',
      people='<b>Takashi Shimura</b> in a career-defining lead as the clerk Watanabe; the ensemble of hollow bureaucrats around him.',
      what='In <b>“Ikiru” (1952)</b>, a lifelong paper-shuffler, learning he has terminal cancer, defies bureaucratic inertia to <b>get a playground built</b>, finding meaning in a single selfless act.',
      crux='It argued that <b>a life gains worth through purposeful action</b> — that even at the end, one true deed can redeem it.',
      conseq='Widely regarded as one of his finest films, Ikiru showed his equal command of intimate human drama.',
      matters='Kurosawa was never only the master of the epic — Ikiru remains one of cinema’s great statements on the meaning of a life.'),
]

# ==================================================================  PHASE 3 — THE MASTERWORKS
PHASE_MASTERWORKS = [
    E('sevensamurai', '1954', 'Seven Samurai', ['TRIUMPH', 'CRAFT', 'TURNING POINT'],
      'In 1954 Kurosawa completes "Seven Samurai," his three-and-a-half-hour epic in which a poor village hires seven masterless samurai to defend it from bandits — an unprecedentedly ambitious production whose kinetic action, deep characters and multi-camera staging influence action cinema across the world for generations.',
      svg_stack('The template for the modern action epic', [
          {'n': 1, 'label': 'Seven Samurai, 1954', 'sub': 'a village hires seven rōnin for its defence', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Epic scale, deep characters', 'sub': '3½ hours; multi-camera, telephoto action', 'color': '#a16207'},
          {'n': 3, 'label': 'A worldwide template', 'sub': 'the “team assembled for a mission” story', 'color': '#166534'},
      ], takeaway='He invented the grammar of the modern action epic — and the “gathering a team for a mission” story film has told ever since.', accent=AC),
      bg='Kurosawa mounted the most ambitious and expensive Japanese production of its day, researching samurai life in exhaustive detail.',
      people='<b>Toshiro Mifune</b> as the wild would-be samurai Kikuchiyo; <b>Takashi Shimura</b> as the wise leader Kambei; the village and the seven.',
      what='<b>“Seven Samurai” (1954)</b> follows seven <b>masterless samurai (rōnin)</b> who defend a farming village from bandits; its <b>multi-camera action, slow-motion and telephoto lenses</b> revolutionised how movement was filmed.',
      crux='It fused <b>spectacle with humanity</b> — every warrior a full character — and codified the ensemble-mission structure of countless films after.',
      conseq='It was remade in Hollywood as <b>“The Magnificent Seven” (1960)</b> and remains among the most influential films ever made.',
      matters='Some films become the blueprint others follow — Seven Samurai is a foundation stone of world action cinema.'),

    E('throne', '1957', 'Throne of Blood — Shakespeare as Noh', ['CRAFT', 'IDEAS'],
      'Kurosawa transposes Shakespeare’s "Macbeth" to feudal Japan in "Throne of Blood" (1957), rendering the tragedy through the stylised gestures of Noh theatre and fog-wrapped landscapes — a bold cross-cultural adaptation that critics rank among the finest films ever made from Shakespeare.',
      svg_row('Macbeth reborn in feudal Japan', [
          {'n': 1, 'label': 'Throne of Blood, 1957', 'sub': 'Macbeth moved to a warlord’s Japan', 'color': '#3730a3'},
          {'n': 2, 'label': 'Told in the style of Noh', 'sub': 'masklike faces, ritual movement, fog', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Shakespeare made wholly Japanese', 'sub': 'a hail of arrows for the final murder', 'color': '#166534'},
      ], edge_labels=['via', 'so'], takeaway='He proved a Western tragedy could be reborn in a Japanese idiom — and surpass most literal adaptations.', accent=AC),
      bg='A lifelong reader of Western literature, Kurosawa adapted Shakespeare’s <b>“Macbeth”</b> into the world of Japan’s warring states.',
      people='<b>Toshiro Mifune</b> as the doomed warlord Washizu; <b>Isuzu Yamada</b> as his Lady Macbeth; the traditions of <b>Noh</b> drama.',
      what='<b>“Throne of Blood” (1957)</b> retells Macbeth through <b>Noh-influenced performance</b> and a famous climax in which the traitor is cut down by a storm of arrows, transposing the tragedy entirely into Japanese form.',
      crux='It showed adaptation as <b>transformation, not translation</b> — the play remade in a native idiom rather than merely copied.',
      conseq='It is often called one of the greatest Shakespeare films, and cemented his reputation as a cross-cultural artist.',
      matters='True adaptation reinvents — Kurosawa turned an English tragedy into a Japanese masterpiece and enriched both.'),

    E('hiddenfortress', '1958', 'The Hidden Fortress', ['TRIUMPH', 'LEGACY'],
      'Kurosawa’s adventure "The Hidden Fortress" (1958) — a general and a princess smuggled through enemy lines, the tale told from the viewpoint of two bickering peasants — becomes an international hit and, two decades later, a direct inspiration for George Lucas’s "Star Wars," from its droid-like duo to its wipe transitions.',
      svg_stack('The adventure that helped shape Star Wars', [
          {'n': 1, 'label': 'The Hidden Fortress, 1958', 'sub': 'a princess and general run the gauntlet', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Seen through two lowly peasants', 'sub': 'the story told from the bottom up', 'color': '#a16207'},
          {'n': 3, 'label': 'George Lucas borrows it, 1977', 'sub': 'the two bickerers become R2-D2 and C-3PO', 'color': '#166534'},
      ], takeaway='A Kurosawa adventure rippled across the world — its peasants and its perspective seeded the biggest saga in modern film.', accent=AC),
      bg='Kurosawa made <b>“The Hidden Fortress” (1958)</b> as a widescreen entertainment, his first film in the anamorphic Tohoscope format.',
      people='<b>Toshiro Mifune</b> as the loyal general; <b>Misa Uehara</b> as the princess; the two comic peasants; later admirer <b>George Lucas</b>.',
      what='The film follows a <b>general escorting a princess and hidden gold</b> across hostile territory, seen largely through <b>two squabbling peasants</b>; Lucas cited it as a key influence on <b>“Star Wars” (1977)</b>, from the two droids to its wipe cuts.',
      crux='It demonstrated the power of telling a grand story <b>from the point of view of its humblest characters</b>.',
      conseq='Its DNA runs through Star Wars and much of modern adventure cinema, spreading Kurosawa’s influence to Hollywood’s blockbusters.',
      matters='Influence travels far — a 1958 samurai romp helped shape the mythology of a galaxy far, far away.'),

    E('yojimbo', '1961', 'Yojimbo — the wandering rōnin', ['TRIUMPH', 'LEGACY'],
      'In "Yojimbo" (1961) Kurosawa unleashes Mifune as a masterless samurai who plays two rival gangs against each other in a lawless town — a wry, ferociously stylish film whose plot Sergio Leone lifts almost wholesale for "A Fistful of Dollars," founding the Spaghetti Western and the archetype of the lone drifter.',
      svg_row('A lone drifter who births a genre', [
          {'n': 1, 'label': 'Yojimbo, 1961', 'sub': 'a rōnin sets two gangs against each other', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Mifune’s scratching, laconic hero', 'sub': 'the cynical, invincible wanderer', 'color': '#a16207'},
          {'n': 3, 'label': 'Leone remakes it, 1964', 'sub': '“A Fistful of Dollars” launches the Spaghetti Western', 'color': '#166534'},
      ], edge_labels=['whose', 'so'], takeaway='He created the archetypal lone gunman — and Leone’s unauthorised remake carried it into the Western forever.', accent=AC),
      bg='Kurosawa set <b>“Yojimbo” (1961)</b> in a decaying 19th-century town torn between two criminal factions, blending the samurai film with the American Western he loved.',
      people='<b>Toshiro Mifune</b> as the nameless rōnin; director <b>Sergio Leone</b>, who remade it; <b>Clint Eastwood</b>, made a star by the remake.',
      what='In <b>“Yojimbo”</b> a wandering swordsman <b>pits two rival gangs against each other</b> and destroys both; <b>Sergio Leone</b> reworked it, uncredited, as <b>“A Fistful of Dollars” (1964)</b> — the film that founded the Spaghetti Western.',
      crux='It distilled the <b>myth of the cynical, invincible loner</b> who cleans up a corrupt town — an archetype cinema still uses.',
      conseq='Toho sued and won a settlement over the remake; the influence flowed both ways between samurai film and Western.',
      matters='Genres cross-pollinate — Kurosawa borrowed the Western and gave it back transformed, reshaping both traditions.'),

    E('redbeard', '1965', 'Red Beard and the break with Mifune', ['TRAGEDY', 'TURNING POINT'],
      'The epic "Red Beard" (1965) — Mifune as a gruff clinic doctor teaching a young intern compassion — is a critical triumph but a grueling two-year shoot, and it proves the sixteenth and last collaboration of Kurosawa and Mifune; the two men, after a falling-out, never work together again.',
      svg_stack('The end of a legendary partnership', [
          {'n': 1, 'label': 'Red Beard, 1965', 'sub': 'a stern doctor schools a young intern', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A two-year shoot exhausts both', 'sub': 'Mifune’s beard barred him from other work', 'color': '#78350f'},
          {'n': 3, 'label': 'Their 16th film — and last', 'sub': 'director and star never reunite', 'color': '#3730a3'},
      ], takeaway='Their crowning collaboration was also their final one — after Red Beard, Kurosawa and Mifune parted for good.', accent=AC),
      bg='<b>“Red Beard” (1965)</b>, a humane epic set in a charity clinic, took two years to shoot in exacting black-and-white detail.',
      people='<b>Toshiro Mifune</b> as the doctor “Red Beard”; <b>Yūzō Kayama</b> as the intern; the two collaborators nearing a rupture.',
      what='The demanding production kept Mifune bound to the role for years and strained the relationship; <b>“Red Beard”</b> became the <b>16th and final film</b> Kurosawa and Mifune made together, and they never reconciled professionally.',
      crux='The break marked the <b>end of an era</b> — the actor who had embodied Kurosawa’s heroes would appear in his films no more.',
      conseq='Kurosawa entered a difficult period; his next films would be made without his greatest star, and success grew harder to find.',
      matters='Even the closest partnerships can fracture — the Kurosawa–Mifune split closed the most fertile chapter of both careers.'),
]

# ==================================================================  PHASE 4 — THE CRISIS YEARS
PHASE_CRISIS = [
    E('dodeskaden', '1968–1970', 'Hollywood collapse and Dodeskaden', ['TRAGEDY', 'CRISIS'],
      'Kurosawa’s first colour film, "Dodeskaden" (1970) — a mosaic of the poor in a Tokyo slum — is a box-office failure, coming after the humiliating collapse of his American projects: fired from the epic "Tora! Tora! Tora!" in 1968, his Hollywood ambitions in ruins, he now seems, at sixty, a director the industry has left behind.',
      svg_row('A master out of step with his industry', [
          {'n': 1, 'label': 'Fired from Tora! Tora! Tora!, 1968', 'sub': 'his Hollywood war epic falls apart', 'color': '#78350f'},
          {'n': 2, 'label': 'Dodeskaden, 1970', 'sub': 'his first colour film — a slum mosaic', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A box-office failure', 'sub': 'Japanese studios turn away from him', 'color': '#3730a3'},
      ], edge_labels=['then', 'so'], takeaway='At sixty, after the Hollywood debacle and a flop, the world’s most honoured director could not get films financed.', accent=AC),
      bg='As Japan’s studio system declined, Kurosawa’s big, costly methods fell out of favour; he pinned hopes on Hollywood.',
      people='the producers of <b>“Tora! Tora! Tora!”</b> who removed him; his fellow directors in the “Four Knights” group behind Dodeskaden; wary Japanese studios.',
      what='After being <b>fired from the U.S.–Japanese epic “Tora! Tora! Tora!” (1968)</b>, Kurosawa made <b>“Dodeskaden” (1970)</b>, his first film in colour; it <b>failed at the box office</b>, deepening his professional isolation.',
      crux='He appeared to be a <b>director the industry had outgrown</b> — too expensive, too uncompromising, unable to find backing.',
      conseq='The double blow of the Hollywood collapse and Dodeskaden’s failure pushed him into a personal crisis.',
      matters='Even genius can fall out of fashion — Kurosawa’s lowest point shows how precarious an artist’s standing can be.'),

    E('suicide', '1971', 'The suicide attempt', ['TRAGEDY', 'CRISIS'],
      'In despair over his stalled career, believing himself finished as a filmmaker, Kurosawa attempts suicide in December 1971, slashing himself at his home; he survives, and the darkness slowly lifts — but the episode marks the nadir of his life, a great artist brought to the edge by professional ruin.',
      svg_stack('The lowest point of a great life', [
          {'n': 1, 'label': 'Career stalled, films unfunded', 'sub': 'he believes he is finished', 'color': '#78350f'},
          {'n': 2, 'label': 'Suicide attempt, December 1971', 'sub': 'he survives his injuries', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A slow recovery begins', 'sub': 'the darkness gradually lifts', 'color': '#166534'},
      ], takeaway='The crisis nearly took his life — that he recovered and directed for two more decades makes the comeback all the more striking.', accent=AC),
      bg='Isolated after Dodeskaden’s failure and unable to mount new projects, Kurosawa fell into deep depression.',
      people='Kurosawa himself; his family who cared for him; the admirers abroad who would soon help revive his career.',
      what='In <b>December 1971</b>, convinced his filmmaking days were over, Kurosawa <b>attempted to take his own life</b>; he survived, and over the following period his health and spirits slowly recovered.',
      crux='It was the <b>nadir of his life</b> — professional despair driving one of the century’s great artists to the brink.',
      conseq='His recovery set the stage for an extraordinary late-career resurgence, aided by foreign admirers and funding.',
      matters='The depth of the fall measures the height of the return — Kurosawa’s greatest films still lay ahead of this dark hour.'),

    E('dersu', '1975', 'Dersu Uzala and an Oscar from Siberia', ['TRIUMPH', 'RISE'],
      'Rescued by an invitation from the Soviet Union, Kurosawa shoots "Dersu Uzala" (1975) in the Siberian wilderness — the story of a Russian surveyor and an aging native hunter — a sweeping meditation on man and nature that wins the Academy Award for Best Foreign Language Film and resurrects his career.',
      svg_row('A comeback filmed in the Siberian wild', [
          {'n': 1, 'label': 'Invited by Mosfilm, USSR', 'sub': 'a lifeline when Japan would not fund him', 'color': '#3730a3'},
          {'n': 2, 'label': 'Dersu Uzala, 1975', 'sub': 'a surveyor and a native hunter in the taiga', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Wins the Foreign Film Oscar', 'sub': 'his career is reborn', 'color': '#166534'},
      ], edge_labels=['makes', 'and'], takeaway='A Soviet lifeline turned his darkest years into an Oscar — the master was back, and the world knew it.', accent=AC),
      bg='Unable to work in Japan, Kurosawa accepted an offer from the Soviet studio <b>Mosfilm</b> to make a film in Russia, on a subject he had cherished for decades.',
      people='the Soviet studio Mosfilm; actor <b>Maxim Munzuk</b> as the hunter Dersu; the naturalist author <b>Vladimir Arsenyev</b>, whose memoir it adapts.',
      what='<b>“Dersu Uzala” (1975)</b>, shot in <b>70mm in the Siberian taiga</b>, tells of the bond between a Russian explorer and an aging indigenous hunter; it won the <b>Academy Award for Best Foreign Language Film</b>.',
      crux='It reaffirmed his central themes — <b>human dignity and harmony with nature</b> — and proved his powers undimmed.',
      conseq='The Oscar restored his standing and helped him attract the international backing for his final epics.',
      matters='A great artist can be saved from the unlikeliest quarter — a Soviet commission handed Kurosawa his second act.'),
]

# ==================================================================  PHASE 5 — THE LATE MASTER
PHASE_LATE = [
    E('kagemusha', '1980', 'Kagemusha — Coppola and Lucas step in', ['TRIUMPH', 'LEGACY'],
      'For his long-dreamed epic "Kagemusha" (1980) — a petty thief made the double of a dying warlord — Kurosawa cannot raise the money in Japan until admirers George Lucas and Francis Ford Coppola persuade a Hollywood studio to back it; the vast, painterly film shares the Palme d’Or at Cannes.',
      svg_stack('Hollywood’s new masters repay a debt', [
          {'n': 1, 'label': 'Kagemusha, 1980', 'sub': 'a thief impersonates a dead warlord', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Lucas & Coppola secure funding', 'sub': 'they persuade 20th Century-Fox to back it', 'color': '#a16207'},
          {'n': 3, 'label': 'Shares the Palme d’Or, Cannes 1980', 'sub': 'a triumphant return to the epic', 'color': '#166534'},
      ], takeaway='The directors he had inspired now rescued him — Lucas and Coppola funded the epic Japan would not, and it won the Palme d’Or.', accent=AC),
      bg='Kurosawa had painted elaborate storyboards for <b>“Kagemusha”</b> but could not finance the huge production at home.',
      people='<b>George Lucas</b> and <b>Francis Ford Coppola</b>, who arranged foreign backing through 20th Century-Fox; actor <b>Tatsuya Nakadai</b> in the dual lead.',
      what='<b>“Kagemusha” (“The Shadow Warrior,” 1980)</b> follows a thief who <b>doubles for a dead warlord</b> to hold a clan together; with Lucas and Coppola’s help it was financed, and it <b>shared the Palme d’Or at Cannes</b>.',
      crux='The younger masters he had influenced <b>repaid the debt</b>, restoring him to the scale of filmmaking he was born for.',
      conseq='Its success opened the way to the even grander Ran, the culmination of his career.',
      matters='Influence can come full circle — the disciples Kurosawa shaped ensured the master could make his final epics.'),

    E('ran', '1985', 'Ran — the crowning epic', ['TRIUMPH', 'CRAFT'],
      'In 1985 Kurosawa realises "Ran," his monumental reworking of "King Lear" among warring feudal lords — a film of overwhelming colour, scale and tragic grandeur that many hail as his masterpiece and the crowning achievement of a career that had spanned four decades.',
      svg_row('King Lear on a field of blood', [
          {'n': 1, 'label': 'Ran (“Chaos”), 1985', 'sub': 'King Lear among warring warlords', 'color': '#3730a3'},
          {'n': 2, 'label': 'Colour, scale, tragic grandeur', 'sub': 'thousands of extras; painterly battle', 'color': '#b91c1c'},
          {'n': 3, 'label': 'His crowning masterpiece', 'sub': 'the summit of a 40-year career', 'color': '#166534'},
      ], edge_labels=['in', 'as'], takeaway='He capped his career with a tragedy of overwhelming grandeur — Ran, his King Lear, is for many his supreme achievement.', accent=AC),
      bg='Kurosawa spent a decade planning <b>“Ran”</b>, painting its images in advance; at the time it was the most expensive Japanese film ever made.',
      people='<b>Tatsuya Nakadai</b> as the aged lord Hidetora; the vast crews and armies of extras; his long-time collaborators in design and music.',
      what='<b>“Ran” (1985)</b> transposes Shakespeare’s <b>“King Lear”</b> to feudal Japan, a lord destroyed by dividing his realm among treacherous sons; its <b>epic battles and saturated colour</b> made it a landmark of world cinema.',
      crux='It fused his lifelong themes — <b>chaos, folly, and the human cost of power</b> — into a single overwhelming tragedy.',
      conseq='Widely acclaimed as his masterpiece, Ran won international awards and confirmed his standing among cinema’s greatest.',
      matters='A career can end at its peak — Ran is the towering summit of Kurosawa’s art and one of film’s great tragedies.'),

    E('honoraryoscar', '1990', 'The honorary Academy Award', ['LEGACY', 'TRIUMPH'],
      'In 1990 the Academy awards Kurosawa an honorary Oscar for lifetime achievement, presented by his admirers George Lucas and Steven Spielberg; the same year he releases the personal, dreamlike anthology "Dreams," a filmmaker in his eighties still turning his inner visions into images.',
      svg_stack('The world honours a lifetime of work', [
          {'n': 1, 'label': 'Honorary Academy Award, 1990', 'sub': 'presented by Lucas and Spielberg', 'color': '#a16207'},
          {'n': 2, 'label': 'Dreams, 1990', 'sub': 'eight of his own dreams, filmed', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A master still creating at 80', 'sub': 'personal, poetic late work', 'color': '#166534'},
      ], takeaway='Hollywood’s reigning directors crowned the man who taught them — and at eighty he was still filming his own dreams.', accent=AC),
      bg='By 1990 Kurosawa was universally recognised as one of cinema’s supreme artists, revered especially by the American directors he had influenced.',
      people='<b>George Lucas</b> and <b>Steven Spielberg</b>, who presented his honorary Oscar; the Academy; the admirers gathered to salute him.',
      what='Kurosawa received an <b>honorary Academy Award for lifetime achievement in 1990</b>, presented by Lucas and Spielberg; that year he also released <b>“Dreams” (1990)</b>, an anthology of eight of his own dreams.',
      crux='The tribute confirmed his place as a <b>founding master of world cinema</b>, honoured by the industry’s new generation.',
      conseq='He made two more films — “Rhapsody in August” (1991) and “Madadayo” (1993) — reflective works of old age.',
      matters='The highest honour is to be revered by those you inspired — Kurosawa was crowned by the very directors he had shaped.'),

    E('death', '1993–1998', 'Madadayo, death, and immortality', ['DEATH', 'LEGACY'],
      'Kurosawa directs his last film, "Madadayo," in 1993 — a gentle meditation on age whose title means "not yet" — and dies of a stroke on 6 September 1998 in Tokyo at eighty-eight; he leaves thirty films and a stature, as perhaps the most influential director in history, that only grows with time.',
      svg_row('“Not yet” — a final bow', [
          {'n': 1, 'label': 'Madadayo, 1993', 'sub': 'his last film; the title means “not yet”', 'color': '#3730a3'},
          {'n': 2, 'label': 'Dies in Tokyo, 6 Sept 1998', 'sub': 'a stroke, at the age of 88', 'color': '#b91c1c'},
          {'n': 3, 'label': 'An immortal influence', 'sub': '30 films; a giant of world cinema', 'color': '#166534'},
      ], edge_labels=['then', 'yet'], takeaway='He worked almost to the end and left a body of work whose influence, far from fading, keeps growing.', accent=AC),
      bg='In his eighties Kurosawa continued to write and direct, closing his career with quiet, valedictory films about age and memory.',
      people='the actors and crews of his final films; the directors worldwide — Scorsese, Lucas, Spielberg and many more — who claim him as a master.',
      what='His last film as director, <b>“Madadayo” (1993)</b>, meditated on aging and gratitude; Kurosawa <b>died of a stroke on 6 September 1998</b> in Tokyo, <b>aged 88</b>, having directed some <b>30 films</b> across 50 years.',
      crux='He left a body of work of <b>unmatched range and influence</b> — from intimate dramas to the grandest epics.',
      conseq='He is routinely ranked among the greatest and most influential filmmakers who ever lived, his films endlessly studied and remade.',
      matters='Some artists grow larger after death — Kurosawa’s shadow lengthens over cinema with every generation of filmmakers he shapes.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Akira Kurosawa was the Japanese master whose films carried Japanese cinema to the world and reshaped filmmaking everywhere. Trained as a painter and apprenticed on the studio floor, he broke through with <b>Rashomon</b>, whose Golden Lion at Venice opened Western eyes to Japanese film — then built an incomparable run of masterpieces: <b>Ikiru</b>, <b>Seven Samurai</b>, <b>Throne of Blood</b>, <b>Yojimbo</b>, <b>Ran</b>. He survived a devastating crisis and a suicide attempt to make late epics backed by the very directors he had inspired. He is the ultimate study in <b>craft, humanism, and the transmission of artistic influence across cultures.</b></p>
<div class="ov-quote">“In a mad world, only the mad are sane.”<span>— Akira Kurosawa</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A painter’s son apprenticed under Yamamoto at Toho → debuts with Sanshiro Sugata and finds Mifune in Drunken Angel → stuns the West with Rashomon’s Golden Lion → builds a golden age with Seven Samurai, Yojimbo and Throne of Blood → collapses into failure and a suicide attempt → is reborn with the Oscar-winning Dersu Uzala → and, backed by Lucas and Coppola, crowns his career with Kagemusha and Ran before dying an acknowledged giant of world cinema.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🎬</div><h4>Total command of craft</h4><p>Multi-camera action, telephoto lenses, deep humanism — techniques the world copied.</p></div>
  <div class="ov-card"><div class="i">🌏</div><h4>A bridge between cultures</h4><p>Rashomon opened the West to Japanese film; he made Shakespeare Japanese.</p></div>
  <div class="ov-card"><div class="i">⚔️</div><h4>The blueprint for action</h4><p>Seven Samurai and Yojimbo seeded The Magnificent Seven, the Western and Star Wars.</p></div>
  <div class="ov-card"><div class="i">🔥</div><h4>Comeback from the brink</h4><p>Survived ruin and a suicide attempt to make his grandest late epics.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Apprentice</b><small> 1910–1945</small><p>Tokyo childhood, Heigo’s death, training under Yamamoto, his debut.</p></div>
  <div><b>2 · Breakthrough</b><small> 1946–1952</small><p>Mifune, Rashomon’s Golden Lion, and Ikiru.</p></div>
  <div><b>3 · Masterworks</b><small> 1954–1965</small><p>Seven Samurai, Yojimbo, Throne of Blood, the Mifune break.</p></div>
  <div><b>4 · Crisis</b><small> 1968–1975</small><p>Hollywood collapse, a suicide attempt, and Dersu Uzala.</p></div>
  <div><b>5 · Late Master</b><small> 1980–1998</small><p>Kagemusha, Ran, the honorary Oscar, and death.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Toshiro Mifune', 'role': 'his greatest star', 'color': '#b91c1c',
     'bio': 'The volcanic actor Kurosawa discovered in Drunken Angel (1948), star of Rashomon, Seven Samurai, Yojimbo and more — 16 films together before their falling-out on Red Beard (1965).',
     'rel': 'His on-screen alter ego and closest collaborator for seventeen years.'},
    {'name': 'Takashi Shimura', 'role': 'the other lead', 'color': '#3730a3',
     'bio': 'The subtle, humane actor who anchored Ikiru as the dying clerk and led the samurai in Seven Samurai — a fixture of Kurosawa’s stock company.',
     'rel': 'The quiet counterweight to Mifune across his classic films.'},
    {'name': 'Kajiro Yamamoto', 'role': 'his mentor', 'color': '#166534',
     'bio': 'The genial Toho director who took Kurosawa as an assistant in 1936 and taught him screenwriting and editing; Kurosawa called him his finest teacher.',
     'rel': 'The master who trained him in every craft of filmmaking.'},
    {'name': 'Heigo Kurosawa', 'role': 'his brother', 'color': '#78350f',
     'bio': 'Akira’s charismatic elder brother, a leading benshi silent-film narrator who introduced him to art and cinema, and whose 1933 suicide devastated him.',
     'rel': 'The brother who opened cinema to him and whose loss shadowed his life.'},
    {'name': 'Lucas & Coppola', 'role': 'admirers & patrons', 'color': '#a16207',
     'bio': 'George Lucas and Francis Ford Coppola, directors he had inspired, who secured the Hollywood funding for Kagemusha (1980) when Japan would not back it.',
     'rel': 'The disciples who repaid their debt by financing his late epics.'},
]

KEY_EVENTS = [
    ('1910', 'Kurosawa born in Tokyo', 'Youngest of eight, of samurai descent.'),
    ('1933', 'Brother Heigo’s suicide', 'The benshi trade destroyed by the talkies.'),
    ('1936', 'Joins PCL / Toho', 'Assistant director under Kajiro Yamamoto.'),
    ('1943', 'Debut: Sanshiro Sugata', 'A kinetic, assured first film.'),
    ('1948', 'Drunken Angel', 'First film with Toshiro Mifune.'),
    ('1950', 'Rashomon', 'Golden Lion at Venice, 1951; opens Japan to the West.'),
    ('1954', 'Seven Samurai', 'The template for the modern action epic.'),
    ('1961', 'Yojimbo', 'Remade as A Fistful of Dollars.'),
    ('1971', 'Suicide attempt', 'The nadir after Dodeskaden’s failure.'),
    ('1975', 'Dersu Uzala', 'Soviet-made; wins the Foreign Film Oscar.'),
    ('1985', 'Ran', 'His King Lear; the crowning masterpiece.'),
    ('1990', 'Honorary Academy Award', 'Presented by Lucas and Spielberg.'),
    ('1998', 'Death in Tokyo', 'A giant of world cinema, aged 88.'),
]

MASTER = [
    {'year': '1910', 'age': 'born', 'phase': 'Apprentice', 'title': 'Born in Tokyo', 'desc': 'A family of samurai descent.'},
    {'year': '1933', 'age': 'age 23', 'phase': 'Apprentice', 'title': 'Heigo’s suicide', 'desc': 'His mentor-brother lost.'},
    {'year': '1936', 'age': 'age 26', 'phase': 'Apprentice', 'title': 'Joins Toho', 'desc': 'Assistant to Yamamoto.'},
    {'year': '1943', 'age': 'age 33', 'phase': 'Apprentice', 'title': 'Sanshiro Sugata', 'desc': 'His directorial debut.'},
    {'year': '1948', 'age': 'age 38', 'phase': 'Breakthrough', 'title': 'Drunken Angel', 'desc': 'Meets Toshiro Mifune.'},
    {'year': '1950', 'age': 'age 40', 'phase': 'Breakthrough', 'title': 'Rashomon', 'desc': 'Golden Lion; global fame.'},
    {'year': '1952', 'age': 'age 42', 'phase': 'Breakthrough', 'title': 'Ikiru', 'desc': 'A dying clerk finds meaning.'},
    {'year': '1954', 'age': 'age 44', 'phase': 'Masterworks', 'title': 'Seven Samurai', 'desc': 'The action epic redefined.'},
    {'year': '1961', 'age': 'age 51', 'phase': 'Masterworks', 'title': 'Yojimbo', 'desc': 'Remade as A Fistful of Dollars.'},
    {'year': '1965', 'age': 'age 55', 'phase': 'Masterworks', 'title': 'Red Beard', 'desc': 'Last film with Mifune.'},
    {'year': '1971', 'age': 'age 61', 'phase': 'Crisis', 'title': 'Suicide attempt', 'desc': 'The lowest point.'},
    {'year': '1975', 'age': 'age 65', 'phase': 'Crisis', 'title': 'Dersu Uzala', 'desc': 'Oscar-winning comeback.'},
    {'year': '1980', 'age': 'age 70', 'phase': 'Late Master', 'title': 'Kagemusha', 'desc': 'Palme d’Or; Lucas & Coppola.'},
    {'year': '1985', 'age': 'age 75', 'phase': 'Late Master', 'title': 'Ran', 'desc': 'His crowning masterpiece.'},
    {'year': '1998', 'age': 'age 88', 'phase': 'Late Master', 'title': 'Death in Tokyo', 'desc': 'A giant of world cinema.'},
]

SOURCES = [
    ('Britannica — Kurosawa Akira', 'https://www.britannica.com/biography/Kurosawa-Akira'),
    ('Wikipedia — Akira Kurosawa', 'https://en.wikipedia.org/wiki/Akira_Kurosawa'),
    ('The Criterion Collection — Akira Kurosawa', 'https://www.criterion.com/directors/akira-kurosawa'),
    ('Senses of Cinema — Akira Kurosawa', 'https://www.sensesofcinema.com/2002/great-directors/kurosawa/'),
    ('AkiraKurosawa.info — Biography', 'https://akirakurosawa.info/biography/'),
    ('Wikipedia — Dersu Uzala (1975 film)', 'https://en.wikipedia.org/wiki/Dersu_Uzala_(1975_film)'),
]

def build_meta():
    return {
        'pid': 'gm-kurosawa.html', 'kind': 'man', 'emoji': '🎬', 'accent': AC,
        'name': 'Akira Kurosawa', 'years': '1910–1998', 'group': 'Artists & Filmmakers',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Japanese master whose Rashomon opened the West to Japanese cinema and whose Seven Samurai, Yojimbo and Ran reshaped filmmaking across the world.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'apprentice', 'label': '1 · Apprentice', 'type': 'timeline',
             'intro': 'A painter’s son of samurai descent, scarred by his benshi brother’s suicide, apprentices under Kajiro Yamamoto at Toho and debuts with Sanshiro Sugata amid the war.', 'events': PHASE_APPRENTICE},
            {'id': 'breakthrough', 'label': '2 · Breakthrough', 'type': 'timeline',
             'intro': 'He finds Toshiro Mifune in Drunken Angel, stuns the world with Rashomon’s Golden Lion, and turns inward for the humane masterpiece Ikiru.', 'events': PHASE_BREAKTHROUGH},
            {'id': 'masterworks', 'label': '3 · Masterworks', 'type': 'timeline',
             'intro': 'The golden age — Seven Samurai, Throne of Blood, The Hidden Fortress and Yojimbo — until the grueling Red Beard ends the Mifune partnership.', 'events': PHASE_MASTERWORKS},
            {'id': 'crisis', 'label': '4 · Crisis', 'type': 'timeline',
             'intro': 'Fired from Hollywood and failing at the box office, he attempts suicide in 1971 — then is reborn in the Siberian wilderness with the Oscar-winning Dersu Uzala.', 'events': PHASE_CRISIS},
            {'id': 'late', 'label': '5 · Late Master', 'type': 'timeline',
             'intro': 'Backed by Lucas and Coppola, he crowns his career with Kagemusha and Ran, receives an honorary Oscar, and works to the end before his death in 1998.', 'events': PHASE_LATE,
             'sources': SOURCES, 'srcnote': 'Drawn from standard biographies and encyclopaedic and archival film sources; dates follow the major reference works on Kurosawa.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
