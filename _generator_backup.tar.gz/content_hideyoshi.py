# -*- coding: utf-8 -*-
"""Full, DEEP birth-to-death guide content for Toyotomi Hideyoshi.
The peasant who rose to unify Japan — and overreached into Korea."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc
from content_hideyoshi_p1 import EVENTS as HY1
from content_hideyoshi_p2 import EVENTS as HY2
from content_hideyoshi_p3 import EVENTS as HY3
from content_hideyoshi_p4 import EVENTS as HY4
from content_hideyoshi_p5 import EVENTS as HY5
from content_hideyoshi_p6 import EVENTS as HY6

AC = '#ca8a04'  # Hideyoshi gold

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MONKEY
PHASE_RISE = [
    E('peasant', '1537–1558', 'Born with nothing — a peasant’s son', ['RISE', 'TRAGEDY'],
      'Hideyoshi is born a peasant, without a surname or samurai birth, in an age where such an origin should have doomed him to obscurity — the most unlikely starting point of any of Japan’s unifiers, and the source of both his genius and his insecurity.',
      svg_row('The lowest possible start', [
          {'n': 1, 'label': 'Peasant birth in Owari', 'sub': 'no samurai lineage, no surname, no land', 'color': '#ca8a04'},
          {'n': 2, 'label': 'Nicknamed “the Monkey”', 'sub': 'small, homely, dismissed by his betters', 'color': '#a16207'},
          {'n': 3, 'label': 'Nowhere to go but up', 'sub': 'only wits and energy to rise on', 'color': '#166534'},
      ], edge_labels=['so', 'so'], takeaway='He began lower than any rival — everything he became, he built from nothing.', accent=AC),
      bg='In rigidly hierarchical Sengoku Japan, birth normally fixed one’s station for life. <b>Hideyoshi</b> was born a <b>peasant</b> in Owari around 1537, with no samurai status.',
      people='his humble family; the class-bound society that should have kept him down; <b>Oda Nobunaga</b>, whom he would come to serve.',
      what='Hideyoshi was born of <b>peasant stock</b>, without a surname, and was reportedly small and homely — nicknamed <b>“Saru” (the Monkey)</b>. By every convention of his age, he should never have risen at all.',
      crux='His origin was <b>as low as possible</b> — making his ascent to ruler of Japan perhaps the greatest rise in the nation’s history.',
      conseq='That same low birth would later drive him to freeze the class system so no one could repeat his climb.',
      matters='The most extraordinary rises start from the lowest places — and often leave their author anxious to shut the door behind him.'),

    E('sandal', '1558–1573', 'Sandal-bearer to samurai — rising by wits', ['RISE', 'POLITICS'],
      'Hideyoshi enters Nobunaga’s service at the very bottom — reputedly as a lowly sandal-bearer — and climbs relentlessly by sheer cleverness, energy and charm, making himself indispensable until the peasant is a trusted retainer of the most powerful lord in central Japan.',
      svg_stack('Making himself indispensable', [
          {'n': 1, 'label': 'Joins Nobunaga at the bottom', 'sub': 'a lowly servant / sandal-bearer', 'color': '#ca8a04'},
          {'n': 2, 'label': 'Endless energy and cleverness', 'sub': 'anticipates needs, solves problems, charms superiors', 'color': '#a16207'},
          {'n': 3, 'label': 'Rises to trusted retainer', 'sub': 'promoted on merit under Nobunaga’s eye', 'color': '#166534'},
      ], takeaway='Where birth barred him, relentless usefulness and charm carried him upward under a master who valued merit.', accent=AC),
      bg='<b>Nobunaga</b> was unusual in promoting men by ability, not birth — the perfect master for a talented peasant with no lineage.',
      people='<b>Oda Nobunaga</b>, the meritocratic lord; the highborn retainers Hideyoshi outshone; the men he won over with charm.',
      what='Entering Nobunaga’s service at the bottom (by legend as a <b>sandal-bearer</b>), Hideyoshi rose steadily through <b>ingenuity, tireless work and personal charm</b>, becoming one of Nobunaga’s most valued officers.',
      crux='He turned <b>usefulness and likability into advancement</b>, thriving under a lord who rewarded results over pedigree.',
      conseq='By the 1570s the former peasant was a general commanding armies for Nobunaga.',
      matters='Under a system that rewards merit, relentless usefulness can carry the low-born past their highborn rivals.'),

    E('sunomata', '1560s–1580', 'The castle built overnight — and the master of siege', ['BATTLE', 'REFORM'],
      'Hideyoshi makes his name as a brilliant, resourceful commander — famed by legend for erecting a fort at Sunomata almost overnight, and in reality a master of engineering-driven siege warfare who takes fortresses by flooding them rather than storming them.',
      svg_row('Winning by engineering, not just fighting', [
          {'n': 1, 'label': 'The “one-night castle”', 'sub': 'legend of Sunomata fort built almost overnight', 'color': '#ca8a04'},
          {'n': 2, 'label': 'Master of the siege', 'sub': 'takes forts by engineering, logistics and guile', 'color': '#a16207'},
          {'n': 3, 'label': 'Water sieges', 'sub': 'floods castles like Takamatsu into surrender', 'color': '#0891b2'},
      ], edge_labels=['then', 'incl.'], takeaway='He preferred to out-think a fortress than storm it — winning with rivers, spades and patience.', accent=AC),
      bg='Hideyoshi’s military reputation rested less on brute force than on <b>ingenuity, engineering and logistics</b> — and a talent for winning without ruinous casualties.',
      people='the garrisons he besieged; his engineers and labourers; the enemy lords he out-manoeuvred.',
      what='Legend credits him with building the fort of <b>Sunomata almost overnight</b>; in fact he became a renowned <b>siege master</b>, notably <b>flooding Takamatsu castle</b> (1582) by damming a river to force surrender.',
      crux='He grasped that <b>engineering and logistics</b> could take a fortress more cheaply than assault — brains over blood.',
      conseq='His reputation as a resourceful, winning general made him one of Nobunaga’s foremost commanders in the west.',
      matters='The cleverest commanders win by reshaping the problem — engineering and patience can beat any wall.'),
]

# ==================================================================  PHASE 2 — THE SUCCESSOR
PHASE_UNIFY = [
    E('yamazaki', '1582', 'The lightning return — avenging Nobunaga', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'When Nobunaga is murdered at Honnō-ji, Hideyoshi reacts with astonishing speed — instantly making peace with his enemy, force-marching his army back across Japan, and crushing the traitor Akechi Mitsuhide at Yamazaki within days, positioning himself as Nobunaga’s avenger and heir.',
      svg_stack('Speed that decided the succession', [
          {'n': 1, 'label': 'Nobunaga killed at Honnō-ji', 'sub': 'the realm suddenly leaderless', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Instant peace, forced march', 'sub': 'makes peace with the Mōri; races back ~200 km', 'color': '#ca8a04'},
          {'n': 3, 'label': 'Beats Akechi at Yamazaki', 'sub': 'destroys the traitor within days — the avenger', 'color': '#166534'},
      ], takeaway='He won the succession by sheer speed — reaching and destroying the betrayer before any rival could react.', accent=AC),
      bg='In June 1582 Nobunaga was betrayed and killed by <b>Akechi Mitsuhide</b>. Hideyoshi was far away, besieging a Mōri castle, when the news arrived.',
      people='<b>Akechi Mitsuhide</b>, the betrayer, defeated within days; the <b>Mōri</b>, with whom Hideyoshi swiftly made peace; his rival Oda generals.',
      what='Hideyoshi <b>instantly made peace with the Mōri</b>, <b>force-marched his army back</b> across the country (the famous “Chūgoku Return”), and <b>crushed Akechi at Yamazaki</b> within about eleven days — becoming Nobunaga’s avenger.',
      crux='He understood that in a power vacuum, <b>speed is everything</b> — the first to act as avenger seized the moral and political initiative.',
      conseq='As the man who avenged Nobunaga, Hideyoshi vaulted ahead of senior rivals in the contest to inherit his master’s power.',
      matters='In a sudden power vacuum, decisive speed beats seniority — the first mover claims the legitimacy others hesitate to grab.'),

    E('shizugatake', '1583', 'Beating the rivals — becoming the heir', ['BATTLE', 'POLITICS', 'TURNING POINT'],
      'Hideyoshi outmanoeuvres and defeats the senior Oda general Shibata Katsuie at Shizugatake, and sidelines Nobunaga’s heirs — emerging within a year of his master’s death as the undisputed successor and the most powerful man in Japan.',
      svg_row('From avenger to master', [
          {'n': 1, 'label': 'Rival: Shibata Katsuie', 'sub': 'the senior Oda general contests the succession', 'color': '#a16207'},
          {'n': 2, 'label': 'Victory at Shizugatake, 1583', 'sub': 'Hideyoshi defeats Shibata, who takes his own life', 'color': '#ca8a04'},
          {'n': 3, 'label': 'Undisputed successor', 'sub': 'Nobunaga’s heirs sidelined; Hideyoshi supreme', 'color': '#166534'},
      ], edge_labels=['beaten at', 'yields'], takeaway='Within a year he outfought and out-schemed every rival to inherit Nobunaga’s power.', accent=AC),
      bg='After avenging Nobunaga, Hideyoshi faced senior Oda generals — chiefly <b>Shibata Katsuie</b> — and Nobunaga’s own heirs, all with claims to lead.',
      people='<b>Shibata Katsuie</b>, defeated and dead by his own hand; Nobunaga’s sons, outmanoeuvred; the Oda retainers who submitted.',
      what='Hideyoshi <b>defeated Shibata Katsuie at Shizugatake</b> (1583) and politically <b>sidelined Nobunaga’s heirs</b>, becoming the acknowledged successor and building his great <b>Osaka Castle</b> as his seat.',
      crux='He combined <b>military victory with political maneuver</b> to convert the role of avenger into supreme power.',
      conseq='Master of central Japan, Hideyoshi now set about completing the unification Nobunaga had begun.',
      matters='Seizing a succession takes both the sword and the deal — beating rivals in the field and outmaneuvering them in politics.'),

    E('unification', '1585–1590', 'Completing the unification of Japan', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'Hideyoshi finishes what Nobunaga started — subduing Shikoku, conquering Kyushu, and finally crushing the last great holdout, the Hōjō, at the vast siege of Odawara in 1590 — uniting all Japan under one ruler for the first time in over a century.',
      svg_stack('The last pieces of the map', [
          {'n': 1, 'label': 'Shikoku & Kyushu subdued', 'sub': 'the southern and western islands brought to heel', 'color': '#ca8a04'},
          {'n': 2, 'label': 'Odawara, 1590', 'sub': 'the great siege destroys the last holdout, the Hōjō', 'color': '#a16207'},
          {'n': 3, 'label': 'Japan unified', 'sub': 'one ruler over all Japan for the first time in a century', 'color': '#166534'},
      ], takeaway='He completed the unification — ending a century of civil war and making himself master of all Japan.', accent=AC),
      bg='By the mid-1580s only outlying regions and the powerful <b>Hōjō</b> in the east remained outside Hideyoshi’s control.',
      people='the <b>Chōsokabe</b> of Shikoku and <b>Shimazu</b> of Kyushu, subdued; the <b>Hōjō</b>, destroyed at Odawara; <b>Ieyasu</b>, a key vassal.',
      what='Hideyoshi <b>subdued Shikoku (1585) and Kyushu (1587)</b>, then <b>besieged and destroyed the Hōjō at Odawara in 1590</b> — completing the <b>unification of Japan</b> after over a century of civil war.',
      crux='He finished the <b>unification of the realm</b>, uniting under one ruler what Nobunaga had only begun to assemble.',
      conseq='For the first time in generations Japan was at peace under a single authority — which Hideyoshi now had to organise and hold.',
      matters='Completing a predecessor’s vision is its own achievement — the finisher secures what the pioneer could only start.'),
]

# ==================================================================  PHASE 3 — THE TAIKO
PHASE_RULER = [
    E('kampaku', '1585–1591', 'The peasant who became regent of Japan', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'Unable to become shogun because he lacks noble lineage, Hideyoshi instead has himself made Kampaku — imperial regent — and later Taikō, taking the new surname Toyotomi and ruling Japan through the ancient prestige of the imperial court rather than the samurai title birth denies him.',
      svg_row('Power through the court, not the sword-title', [
          {'n': 1, 'label': 'Cannot be shogun', 'sub': 'the title requires Minamoto lineage he lacks', 'color': '#a16207'},
          {'n': 2, 'label': 'Becomes Kampaku, 1585', 'sub': 'imperial regent — supreme civil authority', 'color': '#ca8a04'},
          {'n': 3, 'label': 'Taikō & the Toyotomi name', 'sub': 'a new surname and title legitimise his rule', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='Barred from the samurai’s highest title, he borrowed the emperor’s oldest one instead.', accent=AC),
      bg='The title of <b>shogun</b> traditionally required descent from the <b>Minamoto</b> clan — impossible for a peasant. Hideyoshi found another route to legitimacy.',
      people='the <b>imperial court</b>, which granted him titles; the aristocrats whose prestige he borrowed; his rival lords, now his subjects.',
      what='Hideyoshi had himself appointed <b>Kampaku (imperial regent)</b> in 1585 and later <b>Taikō</b>, and was granted the new surname <b>Toyotomi</b> — ruling Japan through court office since his birth barred him from being shogun.',
      crux='He <b>improvised legitimacy</b> from the imperial court when the conventional samurai path was closed to him by birth.',
      conseq='His reliance on personal court titles, rather than a hereditary shogunate, left his dynasty’s legitimacy fragile after his death.',
      matters='When one path to legitimacy is closed, the resourceful find another — but borrowed authority can be harder to pass on.'),

    E('swordhunt', '1588–1591', 'The Sword Hunt — freezing society in place', ['REFORM', 'POLITICS', 'TURNING POINT'],
      'Hideyoshi, the peasant who rose to rule, deliberately slams the door behind him — disarming the peasantry in the Sword Hunt and legally freezing the boundary between samurai and commoner, so that no one can ever again climb from the fields to power as he did.',
      svg_stack('Shutting the ladder he climbed', [
          {'n': 1, 'label': 'The Sword Hunt, 1588', 'sub': 'peasants stripped of weapons', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Classes legally separated', 'sub': 'samurai and farmer fixed as distinct hereditary orders', 'color': '#ca8a04'},
          {'n': 3, 'label': 'No more rises like his', 'sub': 'the peasant-to-ruler path is closed forever', 'color': '#166534'},
      ], takeaway='Having risen from nothing, he made sure no one else could — freezing the very fluidity that had made him.', accent=AC),
      bg='Hideyoshi’s own rise had been possible because Sengoku chaos let talent cross class lines. To ensure stability — and his dynasty’s safety — he ended that fluidity.',
      people='the disarmed <b>peasantry</b>; the <b>samurai</b> class fixed above them; future would-be climbers denied his own path.',
      what='The <b>Sword Hunt (katanagari, 1588)</b> confiscated peasants’ weapons, and edicts <b>legally separated samurai from commoners</b>, freezing the class structure and preventing social mobility.',
      crux='He deliberately <b>ended the social fluidity that had made him</b>, trading dynamism for order and security.',
      conseq='The rigid class system he imposed underpinned two and a half centuries of Tokugawa stability — at the cost of mobility.',
      matters='Those who rise through disorder often impose order to prevent their own kind of rise — stability can mean closing the door behind you.'),

    E('kenchi', '1582–1598', 'Surveying the land — the machinery of a state', ['REFORM', 'TRIUMPH'],
      'Hideyoshi builds the administrative foundations of a unified Japan — a nationwide cadastral survey measuring every field’s yield, standardised in a single measure of rice, creating a rational tax base and a template of governance his successors will use for centuries.',
      svg_row('Measuring a nation into order', [
          {'n': 1, 'label': 'Nationwide land survey', 'sub': 'the taikō kenchi measures every field’s productivity', 'color': '#ca8a04'},
          {'n': 2, 'label': 'Standardised in koku of rice', 'sub': 'one measure of value across all Japan', 'color': '#a16207'},
          {'n': 3, 'label': 'A rational tax base', 'sub': 'fair, predictable revenue; domains ranked by yield', 'color': '#166534'},
      ], edge_labels=['then', 'yields'], takeaway='He turned a patchwork of conquered lands into a measured, taxable, governable state.', accent=AC),
      bg='A unified Japan needed unified administration. Hideyoshi undertook the vast <b>taikō kenchi</b> — a cadastral survey of the entire country.',
      people='the surveyors and officials who measured the land; the daimyō whose domains were ranked by yield; the peasants assessed for tax.',
      what='The <b>taikō kenchi</b> surveyed landholdings across Japan, expressing each domain’s productivity in <b>koku (measures of rice)</b> — creating a standardised tax base and the administrative framework of the early-modern Japanese state.',
      crux='He built the <b>rational, measured machinery of government</b> — turning conquest into a governable, taxable realm.',
      conseq='The koku system and cadastral framework underpinned Tokugawa governance for over 250 years.',
      matters='Lasting states rest on measurement — you cannot govern or tax what you have not counted.'),

    E('culture', '1583–1598', 'Gold and tea — the splendour and the shadow', ['REFORM', 'TRIUMPH', 'TRAGEDY'],
      'The former peasant becomes the grandest patron in Japan — building mighty Osaka Castle, staging vast tea gatherings, even a portable golden tea room — while his relationship with the great tea master Rikyū ends darkly, in an order to take his own life.',
      svg_stack('The magnificence — and the menace', [
          {'n': 1, 'label': 'Osaka Castle & golden splendour', 'sub': 'a mighty fortress; a portable gold tea room', 'color': '#ca8a04'},
          {'n': 2, 'label': 'Patron of the tea ceremony', 'sub': 'grand gatherings under the master Sen no Rikyū', 'color': '#a16207'},
          {'n': 3, 'label': 'Rikyū ordered to die, 1591', 'sub': 'the tea master forced to commit seppuku', 'color': '#b91c1c'},
      ], takeaway='His love of splendour and culture ran alongside a growing, deadly capriciousness in his later years.', accent=AC),
      bg='Wealthy and supreme, Hideyoshi became a lavish patron of architecture and the arts, especially the <b>tea ceremony</b> — but grew increasingly wilful and paranoid.',
      people='the tea master <b>Sen no Rikyū</b>, ordered to kill himself; the artists and builders he patronised; the courtiers around him.',
      what='Hideyoshi built <b>Osaka Castle</b>, staged enormous tea gatherings, and commissioned a <b>portable golden tea room</b> — yet in 1591 <b>ordered Rikyū, the age’s greatest tea master, to commit seppuku</b>, a sign of his darkening later temper.',
      crux='His reign fused <b>cultural magnificence with rising capriciousness</b> — the generous patron and the deadly autocrat in one.',
      conseq='The Momoyama cultural flowering he sponsored was dazzling; his growing paranoia foreshadowed the tragedies of his final years.',
      matters='Absolute power can nurture great culture and terrible cruelty at once — magnificence and menace often share a court.'),
]

# ==================================================================  PHASE 4 — OVERREACH
PHASE_FALL = [
    E('christians', '1587–1597', 'Turning on the Christians', ['POLITICS', 'TRAGEDY'],
      'Once tolerant like Nobunaga, Hideyoshi comes to see the growing Christian church and its European backers as a threat to his authority — issuing edicts expelling the missionaries and, in 1597, crucifying twenty-six Christians at Nagasaki, opening Japan’s long persecution of the faith.',
      svg_stack('From tolerance to persecution', [
          {'n': 1, 'label': 'Christianity spreads', 'sub': 'missionaries and converts grow under early tolerance', 'color': '#a16207'},
          {'n': 2, 'label': 'Expulsion edict, 1587', 'sub': 'sees a foreign-backed rival loyalty; orders missionaries out', 'color': '#ca8a04'},
          {'n': 3, 'label': '26 Martyrs of Nagasaki, 1597', 'sub': 'crucifixions begin the long persecution', 'color': '#b91c1c'},
      ], takeaway='He turned on a religion whose foreign ties and rival loyalty he came to see as a danger to his rule.', accent=AC),
      bg='Christianity, welcomed under Nobunaga, had spread in Japan under European (especially Jesuit) missionaries and Portuguese trade.',
      people='the Jesuit and Franciscan missionaries; the Japanese Christian converts (kirishitan); the <b>26 Martyrs</b> executed at Nagasaki.',
      what='Hideyoshi issued an <b>edict expelling missionaries in 1587</b> and, in 1597, had <b>26 Christians crucified at Nagasaki</b> — fearing the church as a foreign-backed challenge to his authority and beginning Japan’s persecution of Christianity.',
      crux='He came to view the faith’s <b>foreign ties and rival loyalty</b> as incompatible with his absolute authority.',
      conseq='His persecution foreshadowed the Tokugawa’s total ban on Christianity and near-closure of Japan.',
      matters='Rulers who demand undivided loyalty often turn on faiths with foreign ties — a rival allegiance is a threat to absolute power.'),

    E('korea', '1592–1598', 'The Korean disaster — overreach into the mainland', ['BATTLE', 'DEFEAT', 'TRAGEDY'],
      'At the height of his power, Hideyoshi launches an extravagant, catastrophic dream — to conquer Korea and then China itself — but his armies bog down against Korean resistance, Admiral Yi’s navy, and Chinese intervention, in a ruinous war that drains Japan and dies only when he does.',
      svg_stack('Ambition that ran off the map', [
          {'n': 1, 'label': 'Invades Korea, 1592', 'sub': 'the first step toward conquering Ming China', 'color': '#ca8a04'},
          {'n': 2, 'label': 'Bogged down and beaten back', 'sub': 'Korean resistance, Admiral Yi’s fleet, Ming armies', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A ruinous stalemate', 'sub': 'a second invasion (1597) also fails; Japan is drained', 'color': '#78350f'},
      ], takeaway='His boundless ambition finally overreached — a war that bled Japan for nothing and ended only with his death.', accent=AC),
      bg='Having unified Japan, Hideyoshi turned his ambition outward, aiming to <b>conquer Korea and then Ming China</b> — a vast overreach.',
      people='the Korean defenders and Admiral <b>Yi Sun-sin</b>, whose fleet devastated Japanese supply lines; the intervening <b>Ming</b> armies; the suffering soldiers and civilians.',
      what='Hideyoshi <b>invaded Korea in 1592 and again in 1597</b>. Both campaigns bogged down against fierce Korean resistance, <b>Yi Sun-sin’s navy</b>, and Ming Chinese intervention — a bloody, futile war that drained Japan.',
      crux='His ambition <b>outran all reason and logistics</b> — a war of pure overreach with no achievable end.',
      conseq='The failed invasions devastated Korea, exhausted Japan, and weakened the Toyotomi cause just as the succession loomed.',
      matters='Unchecked ambition eventually overreaches — the conqueror who cannot stop finally attempts the impossible.'),

    E('succession', '1591–1598', 'A father’s desperation — the succession trap', ['POLITICS', 'TRAGEDY', 'DEATH'],
      'Childless for most of his life, then blessed late with a son, Hideyoshi grows desperate to secure the boy’s inheritance — brutally purging his own adopted heir Hidetsugu and his family, then binding his greatest lords by oath to protect the child, a fragile arrangement Ieyasu will soon exploit.',
      svg_stack('Everything staked on a small child', [
          {'n': 1, 'label': 'A late, longed-for son', 'sub': 'Hideyori born; the succession suddenly matters', 'color': '#ca8a04'},
          {'n': 2, 'label': 'Purges his heir Hidetsugu', 'sub': 'the adopted nephew and his family executed, 1595', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Regents sworn to the boy', 'sub': 'the Five Elders — incl. Ieyasu — bound by oath', 'color': '#78350f'},
      ], takeaway='His desperation to secure a child heir led to atrocity — and to a guardianship the strongest lord would betray.', accent=AC),
      bg='Long without a surviving heir, Hideyoshi had adopted his nephew <b>Hidetsugu</b>. Then, late in life, his son <b>Hideyori</b> was born, upending everything.',
      people='<b>Hidetsugu</b>, the purged adopted heir; the infant <b>Hideyori</b>; the <b>Five Elders (Go-Tairō)</b>, chiefly <b>Tokugawa Ieyasu</b>.',
      what='To clear the way for Hideyori, Hideyoshi <b>forced Hidetsugu to commit suicide and had his family executed (1595)</b>, then bound the <b>Five Elders</b> — including the powerful <b>Ieyasu</b> — by oath to protect the boy.',
      crux='His <b>desperation for his son’s succession</b> drove him to atrocity and to a fragile regency dependent on rivals’ good faith.',
      conseq='Hideyoshi died in 1598 with his heir a small child; within two years Ieyasu had seized power, and by 1615 the Toyotomi were destroyed.',
      matters='Power built on one person rarely passes safely to a child — securing a dynasty is the hardest task a founder faces.'),

    E('death', '1598', 'Death — and the empire that slipped away', ['DEATH', 'TRAGEDY', 'TURNING POINT'],
      'Hideyoshi dies in 1598 with his Korean war collapsing and his heir a five-year-old — and the elaborate safeguards he built cannot hold; within two years Tokugawa Ieyasu seizes supremacy, and the peasant’s dynasty, so brilliantly won, is gone within a generation.',
      svg_row('A lifetime’s work, lost in a generation', [
          {'n': 1, 'label': 'Dies with a child heir, 1598', 'sub': 'Hideyori is only five; the regency fragile', 'color': '#ca8a04'},
          {'n': 2, 'label': 'Korea abandoned', 'sub': 'the failed war wound down after his death', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Ieyasu takes it all', 'sub': 'Sekigahara (1600) and the fall of Osaka (1615)', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He won everything from nothing — and lost it all within a generation of his death.', accent=AC),
      bg='Hideyoshi died in 1598 as the second Korean invasion failed and with his dynasty resting on a small child and the loyalty of ambitious rivals.',
      people='the boy <b>Hideyori</b>; his mother <b>Yodo-dono</b>; <b>Tokugawa Ieyasu</b>, who would supplant them.',
      what='Hideyoshi <b>died in 1598</b>; the Korean campaign was abandoned, and the regency collapsed. <b>Ieyasu</b> won supremacy at <b>Sekigahara (1600)</b> and destroyed the Toyotomi at the <b>Siege of Osaka (1615)</b>.',
      crux='The greatest self-made rise in Japanese history <b>could not be passed on</b> — personal power died with the person.',
      conseq='Ieyasu inherited the unified Japan Hideyoshi had built and founded the 250-year Tokugawa peace.',
      matters='The hardest test of achievement is whether it outlives you — Hideyoshi’s did not, but the unified Japan he made endured.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Toyotomi Hideyoshi achieved perhaps the greatest rise in Japanese history — from a landless peasant to the ruler of all Japan. Rising through Nobunaga’s meritocracy by sheer wit and energy, he avenged his murdered master, out-schemed every rival, and completed the unification of a country shattered by a century of war. Then, having climbed from the fields, he froze society so no one could follow him — and overreached fatally into Korea. He is the ultimate study in <b>merit over birth, the self-made rise, and the near-impossibility of passing on personal power.</b></p>
<div class="ov-quote">“Nobunaga pounded the rice cake, Hideyoshi shaped it, Ieyasu ate it.”<span>— a famous verse on Japan’s three unifiers</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A landless peasant joins Nobunaga at the bottom → rises by wit and tireless usefulness → makes his name as a master of siege → on Nobunaga’s murder, races back to crush the traitor at Yamazaki → beats his rivals at Shizugatake to become the heir → completes the unification of Japan at Odawara → rules as Kampaku and Taikō since birth bars him from shogun → disarms the peasants and freezes the classes behind him → dazzles with gold and tea, then darkens → persecutes Christians, overreaches into Korea → and dies leaving a child heir whose inheritance Ieyasu takes.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🧗</div><h4>The ultimate rise</h4><p>From landless peasant to ruler of Japan — merit over birth taken to its limit.</p></div>
  <div class="ov-card"><div class="i">🏯</div><h4>The unifier</h4><p>He completed the unification of Japan and built the machinery of its early-modern state.</p></div>
  <div class="ov-card"><div class="i">🚪</div><h4>Shutting the ladder</h4><p>The Sword Hunt froze the very social mobility that had made him.</p></div>
  <div class="ov-card"><div class="i">🌊</div><h4>Overreach</h4><p>The Korean invasions show ambition running past all reason — and dying with him.</p></div>
</div>
<div class="ov-lbl">The four chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Monkey</b><small> 1537–1580</small><p>A peasant rises through Nobunaga’s ranks by wits.</p></div>
  <div><b>2 · The Successor</b><small> 1582–1590</small><p>Avenging Nobunaga and unifying Japan.</p></div>
  <div><b>3 · The Taikō</b><small> 1585–1598</small><p>Regent of Japan; the Sword Hunt, surveys and splendour.</p></div>
  <div><b>4 · Overreach</b><small> 1587–1598</small><p>Christians, Korea, the succession, and death.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Oda Nobunaga', 'role': 'master', 'color': '#b91c1c',
     'bio': 'The warlord whose meritocratic service let the peasant Hideyoshi rise; his murder opened the way for Hideyoshi to inherit his unification project.',
     'rel': 'The master who gave him his chance — and whose death he avenged.'},
    {'name': 'Tokugawa Ieyasu', 'role': 'vassal and successor', 'color': '#166534',
     'bio': 'Hideyoshi’s most powerful vassal and one of the regents sworn to protect his heir — who instead seized power after his death and founded the Tokugawa shogunate.',
     'rel': 'The great rival who inherited what Hideyoshi built.'},
    {'name': 'Akechi Mitsuhide', 'role': 'target of vengeance', 'color': '#a16207',
     'bio': 'The general who murdered Nobunaga, only to be crushed by Hideyoshi’s lightning return at Yamazaki within days.',
     'rel': 'The traitor whose defeat launched Hideyoshi’s bid for power.'},
    {'name': 'Sen no Rikyū', 'role': 'tea master', 'color': '#78350f',
     'bio': 'The greatest master of the Japanese tea ceremony, Hideyoshi’s cultural adviser — whom Hideyoshi ultimately ordered to commit suicide in 1591.',
     'rel': 'The cultural genius at his side, and a victim of his darkening temper.'},
    {'name': 'Toyotomi Hideyori', 'role': 'son and heir', 'color': '#ca8a04',
     'bio': 'Hideyoshi’s longed-for son, born late; left as a small child at his father’s death, his inheritance was taken by Ieyasu and the Toyotomi destroyed in 1615.',
     'rel': 'The child heir whose fragile succession his father could not secure.'},
]

KEY_EVENTS = [
    ('1537', 'Hideyoshi born', 'A peasant’s son in Owari.'),
    ('1558', 'Enters Nobunaga’s service', 'Rises from the bottom by merit.'),
    ('1582', 'Yamazaki', 'Avenges Nobunaga; defeats Akechi.'),
    ('1583', 'Shizugatake', 'Beats Shibata; becomes the successor.'),
    ('1585', 'Becomes Kampaku', 'Imperial regent; rules Japan.'),
    ('1588', 'The Sword Hunt', 'Disarms peasants; freezes the classes.'),
    ('1590', 'Odawara', 'Completes the unification of Japan.'),
    ('1592', 'Invades Korea', 'The disastrous overreach begins.'),
    ('1598', 'Death of Hideyoshi', 'Leaves a child heir; Ieyasu rises.'),
]

MASTER = [
    {'year': '1537', 'age': 'born', 'phase': 'The Monkey', 'title': 'Born a peasant', 'desc': 'The lowest possible start.'},
    {'year': '1582', 'age': 'age 45', 'phase': 'The Successor', 'title': 'Yamazaki', 'desc': 'Avenges Nobunaga.'},
    {'year': '1585', 'age': 'age 48', 'phase': 'The Taikō', 'title': 'Becomes Kampaku', 'desc': 'Regent of Japan.'},
    {'year': '1590', 'age': 'age 53', 'phase': 'The Taikō', 'title': 'Unifies Japan', 'desc': 'Odawara falls.'},
    {'year': '1592', 'age': 'age 55', 'phase': 'Overreach', 'title': 'Invades Korea', 'desc': 'The great overreach.'},
    {'year': '1598', 'age': 'age 61', 'phase': 'Overreach', 'title': 'Death', 'desc': 'Leaves a child heir.'},
]

SOURCES = [
    ('Britannica — Toyotomi Hideyoshi', 'https://www.britannica.com/biography/Toyotomi-Hideyoshi'),
    ('World History Encyclopedia — Toyotomi Hideyoshi', 'https://www.worldhistory.org/Toyotomi_Hideyoshi/'),
    ('Britannica — Sword Hunt / unification of Japan', 'https://www.britannica.com/place/Japan/The-unification-of-Japan'),
    ('World History Encyclopedia — Japanese invasions of Korea', 'https://www.worldhistory.org/article/1398/'),
    ('Wikipedia — Toyotomi Hideyoshi', 'https://en.wikipedia.org/wiki/Toyotomi_Hideyoshi'),
]

def build_meta():
    return {
        'pid': 'gm-hideyoshi.html', 'kind': 'man', 'emoji': '🐒', 'accent': AC,
        'name': 'Toyotomi Hideyoshi', 'years': '1537–1598', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The landless peasant who rose through merit to unify Japan — then froze the society that made him possible and overreached fatally into Korea.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Monkey', 'type': 'timeline',
             'intro': 'Born a landless peasant, he joins Nobunaga at the very bottom and rises by sheer wit, energy and charm — making his name as a master of engineering-driven siege warfare.', 'events': PHASE_RISE + HY1 + HY2},
            {'id': 'unify', 'label': '2 · The Successor', 'type': 'timeline',
             'intro': 'When Nobunaga is murdered, Hideyoshi reacts with astonishing speed to avenge him at Yamazaki, out-schemes his rivals at Shizugatake, and completes the unification of Japan at Odawara.', 'events': PHASE_UNIFY + HY3 + HY4},
            {'id': 'ruler', 'label': '3 · The Taikō', 'type': 'timeline',
             'intro': 'Barred by birth from being shogun, he rules as imperial regent — disarming the peasants and freezing the classes behind him, surveying the land into a state, and dazzling with gold and tea.', 'events': PHASE_RULER + HY5},
            {'id': 'fall', 'label': '4 · Overreach', 'type': 'timeline',
             'intro': 'His later years darken into persecution and overreach — turning on the Christians, launching the ruinous Korean invasions, and destroying his own heir’s rivals in a doomed bid to secure a child successor.', 'events': PHASE_FALL + HY6,
             'sources': SOURCES, 'srcnote': 'Some famous episodes (the sandal-bearer story, the “one-night castle”) blend historical record and legend; sources include Ōta Gyūichi and Jesuit accounts.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER, 'auto': True},
        ],
    }
