# -*- coding: utf-8 -*-
"""Full, DEEP birth-to-death guide content for Oda Nobunaga.
The ruthless innovator who began the unification of Japan — and was betrayed at its threshold."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b91c1c'  # Oda vermilion

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE FOOL OF OWARI
PHASE_RISE = [
    E('fool', '1534–1551', 'The Fool of Owari', ['RISE', 'TRAGEDY'],
      'The young Nobunaga is a scandal — dressing wildly, brawling with commoners, flouting every convention — earning the nickname “the Fool of Owari,” until his devoted mentor kills himself in protest to shock the heir into seriousness.',
      svg_stack('A wild youth with hidden depths', [
          {'n': 1, 'label': '“The Fool of Owari”', 'sub': 'eccentric, unruly, contemptuous of custom', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A mentor’s suicide-protest', 'sub': 'Hirate Masahide kills himself to remonstrate', 'color': '#78350f'},
          {'n': 3, 'label': 'Underestimated by all', 'sub': 'rivals and elders write him off — wrongly', 'color': '#a16207'},
      ], takeaway='Everyone dismissed him as a clown — a fatal error, for beneath the eccentricity was a revolutionary mind.', accent=AC),
      bg='<b>Oda Nobunaga</b> was born in 1534 into a minor warlord family in <b>Owari</b> province during the Sengoku (“Warring States”) chaos, when Japan had fractured into feuding domains.',
      people='his father <b>Oda Nobuhide</b>; his exasperated tutor <b>Hirate Masahide</b>, who took his own life in protest; the elders who scorned the heir.',
      what='As a youth Nobunaga behaved so outrageously — odd dress, rough company, disdain for ceremony — that he was mocked as the <b>“Fool of Owari.”</b> His loyal tutor <b>Hirate Masahide</b> reportedly committed <b>seppuku</b> to shock him into responsibility.',
      crux='He was consistently <b>underestimated</b> — the eccentric exterior hid a ruthless, original strategist.',
      conseq='Those who dismissed him, from his own relatives to great neighbours, would pay dearly for the mistake.',
      matters='Being underestimated is an advantage — the rival everyone dismisses is the one who catches them unprepared.'),

    E('owari', '1551–1559', 'Uniting Owari — over his own family’s bodies', ['BATTLE', 'POLITICS', 'RISE'],
      'On his father’s death Nobunaga fights a brutal internal war to unify his own clan and province — defeating and killing rivals including his own brother — emerging as sole master of Owari and ready to face far greater powers.',
      svg_row('Securing the home base by force', [
          {'n': 1, 'label': 'Father dies; clan divided', 'sub': 'rivals and relatives contest the succession', 'color': '#a16207'},
          {'n': 2, 'label': 'Crushes his rivals', 'sub': 'defeats and kills opponents, including his brother', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Master of Owari', 'sub': 'unifies the province under his sole rule', 'color': '#166534'},
      ], edge_labels=['then', 'yields'], takeaway='He secured his base ruthlessly first — you cannot conquer others until you own your own house.', accent=AC),
      bg='Nobunaga inherited a <b>divided clan</b> and province. Rival branches of the Oda and even his own family disputed his leadership.',
      people='his brother <b>Nobuyuki</b>, whom he had killed; rival Oda kinsmen; the retainers he won or crushed.',
      what='Over several years Nobunaga <b>defeated his internal rivals</b>, including having his brother <b>Nobuyuki</b> killed after a rebellion, and <b>unified Owari</b> under his sole command.',
      crux='He grasped that <b>a secure, unified base</b> came before any wider ambition — and pursued it with family-blind ruthlessness.',
      conseq='With Owari behind him, he was ready when a vastly larger enemy invaded — the moment that made his name.',
      matters='Conquest begins at home — the leader who cannot control his own faction cannot command a realm.'),

    E('okehazama', '1560', 'Okehazama — the impossible victory', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'The great warlord Imagawa Yoshimoto marches on Owari with tens of thousands — but Nobunaga, hopelessly outnumbered, launches a surprise attack in a thunderstorm on Imagawa’s resting camp, kills him, and shatters an army ten times his size in a single stroke.',
      svg_stack('Ten-to-one odds overturned', [
          {'n': 1, 'label': 'Imagawa invades with ~25,000', 'sub': 'a huge army against Nobunaga’s few thousand', 'color': '#a16207'},
          {'n': 2, 'label': 'Surprise attack in a storm', 'sub': 'strikes the resting enemy camp under cover of thunder', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Yoshimoto killed; army routed', 'sub': 'the enemy leader dead, his host collapses', 'color': '#166534'},
      ], takeaway='He beat impossible odds by intelligence, daring and surprise — aiming the whole battle at one man.', accent=AC),
      bg='In 1560 the powerful <b>Imagawa Yoshimoto</b> invaded Owari with a huge army on his way to Kyoto, expecting to crush the young Nobunaga easily.',
      people='<b>Imagawa Yoshimoto</b>, killed in the attack; the young <b>Tokugawa Ieyasu</b>, then an Imagawa vassal; Nobunaga’s tiny force.',
      what='Rather than defend passively, Nobunaga used <b>scouts and surprise</b> to locate Imagawa’s resting main camp and <b>attacked in a sudden storm</b>, killing Yoshimoto and routing the far larger army in a lightning stroke.',
      crux='He staked everything on a <b>bold, intelligence-led surprise aimed at the enemy commander</b> — decapitation over attrition.',
      conseq='The victory made Nobunaga famous, freed Ieyasu to become his ally, and launched his rise from provincial lord toward national power.',
      matters='Audacity plus good intelligence can overturn overwhelming odds — strike the one point whose fall ends everything.'),

    E('alliances', '1562–1567', 'Alliances and the conquest of Mino', ['POLITICS', 'BATTLE', 'REFORM'],
      'Nobunaga secures his flanks with shrewd alliances — notably a lasting bond with Tokugawa Ieyasu — and takes the rich province of Mino, adopting a seal that proclaims his audacious ambition: “Tenka Fubu,” to bring the realm under military rule.',
      svg_row('Securing flanks, declaring ambition', [
          {'n': 1, 'label': 'Alliance with Ieyasu', 'sub': 'the durable Kiyosu pact secures his east', 'color': '#166534'},
          {'n': 2, 'label': 'Conquers Mino, 1567', 'sub': 'takes Inabayama castle; renames his seat Gifu', 'color': '#b91c1c'},
          {'n': 3, 'label': '“Tenka Fubu” seal', 'sub': '“rule the realm by force” — his stated ambition', 'color': '#78350f'},
      ], edge_labels=['plus', 'declares'], takeaway='He combined safe alliances with bold expansion — and openly proclaimed a goal no one else dared name.', accent=AC),
      bg='To expand safely, Nobunaga needed secure borders and richer lands. He allied with neighbours and targeted the wealthy province of <b>Mino</b>.',
      people='<b>Tokugawa Ieyasu</b>, his loyal ally; the <b>Saitō</b> clan of Mino, whom he defeated; his rising retainers, including a peasant-born <b>Hideyoshi</b>.',
      what='Nobunaga forged a lasting <b>alliance with Ieyasu</b>, <b>conquered Mino</b> (taking Inabayama castle, renamed Gifu) by 1567, and adopted the seal <b>“Tenka Fubu”</b> — declaring his intent to unify “the realm” by force.',
      crux='He paired <b>reliable alliances with aggressive expansion</b>, and uniquely <b>announced a national ambition</b> when others thought only of their province.',
      conseq='With Mino’s wealth and secure flanks, he was positioned to march on the capital, Kyoto, and the wider stage.',
      matters='Great ambition is served by securing your borders first — and stating a bold goal can itself rally followers to it.'),
]

# ==================================================================  PHASE 2 — THE MARCH TO KYOTO
PHASE_KYOTO = [
    E('kyoto', '1568', 'Marching on Kyoto — a shogun as puppet', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'Nobunaga seizes the great prize of legitimacy — he marches to Kyoto, installs a claimant, Ashikaga Yoshiaki, as shogun, and rules the realm’s heart in his name, gaining national authority while keeping real power for himself.',
      svg_stack('Legitimacy captured, not claimed', [
          {'n': 1, 'label': 'Marches to Kyoto, 1568', 'sub': 'takes the imperial capital and its prestige', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Installs Yoshiaki as shogun', 'sub': 'a legitimate Ashikaga figurehead', 'color': '#a16207'},
          {'n': 3, 'label': 'Rules in the shogun’s name', 'sub': 'national authority, real power kept by Nobunaga', 'color': '#166534'},
      ], takeaway='He borrowed a legitimate shogun as a front — ruling the realm without yet claiming its highest title.', accent=AC),
      bg='Legitimacy in Japan flowed from the <b>Emperor</b> and the <b>Ashikaga shogunate</b>, both powerless but prestigious. Nobunaga saw their value as instruments.',
      people='<b>Ashikaga Yoshiaki</b>, the shogun-claimant he installed; the powerless Emperor; the Kyoto elite Nobunaga now dominated.',
      what='In 1568 Nobunaga <b>marched to Kyoto</b> and installed <b>Ashikaga Yoshiaki</b> as shogun, ruling the capital and the realm’s affairs in Yoshiaki’s name while holding the real power himself.',
      crux='He grasped that <b>controlling the symbols of legitimacy</b> — a shogun, the capital — multiplied his power without provoking every rival at once.',
      conseq='But Yoshiaki soon chafed at being a puppet and began plotting Nobunaga’s downfall with his many enemies.',
      matters='Power is amplified by capturing the symbols of legitimacy — rule through a figurehead before you rule in your own name.'),

    E('coalition', '1570–1573', 'The whole realm against him', ['BATTLE', 'POLITICS', 'DEFEAT'],
      'Nobunaga’s ambition provokes a vast encirclement — the puppet shogun secretly orchestrates a coalition of rival warlords and militant Buddhist sects to destroy him — plunging him into years of desperate, multi-front war for survival.',
      svg_row('Encircled on every side', [
          {'n': 1, 'label': 'Yoshiaki turns against him', 'sub': 'the shogun secretly rallies Nobunaga’s enemies', 'color': '#a16207'},
          {'n': 2, 'label': 'A coalition of warlords & monks', 'sub': 'Takeda, Asakura, Azai, and the militant Ikkō-ikki', 'color': '#b91c1c'},
          {'n': 3, 'label': 'War on many fronts', 'sub': 'Nobunaga fights for survival, 1570–73', 'color': '#78350f'},
      ], edge_labels=['forms', 'means'], takeaway='His success united everyone against him — and he had to beat a whole realm to survive.', accent=AC),
      bg='Nobunaga’s rapid rise alarmed every rival. The frustrated puppet shogun <b>Yoshiaki</b> covertly organised a broad <b>anti-Nobunaga coalition</b>.',
      people='<b>Yoshiaki</b>, the plotting shogun; the <b>Takeda, Asakura and Azai</b> clans; the militant <b>Ikkō-ikki</b> Buddhist leagues.',
      what='From 1570 Nobunaga faced an <b>encirclement</b> of warlords and warrior-monks orchestrated partly by Yoshiaki. He fought them off one by one, and in <b>1573 expelled Yoshiaki, ending the Ashikaga shogunate</b>.',
      crux='His very success <b>united his enemies</b> — the price of dominance was war against nearly everyone at once.',
      conseq='Breaking the coalition, and ending the 240-year Ashikaga shogunate, left Nobunaga the paramount power in central Japan.',
      matters='Rapid rise breeds coalitions of the threatened — the successful must be able to fight the many they alarm.'),
]

# ==================================================================  PHASE 3 — THE RUTHLESS WARS
PHASE_WARS = [
    E('hiei', '1571', 'Burning Mount Hiei — war on the warrior-monks', ['BATTLE', 'TRAGEDY', 'TURNING POINT'],
      'To break the political-military power of the great Buddhist monasteries, Nobunaga does the unthinkable — he burns the ancient, revered temple complex of Mount Hiei to the ground and massacres thousands, a ruthless act that shatters the monks’ armies and shocks the age.',
      svg_stack('Breaking a militarised religion', [
          {'n': 1, 'label': 'Warrior-monasteries as powers', 'sub': 'armed Buddhist temples wield real military force', 'color': '#a16207'},
          {'n': 2, 'label': 'Enryaku-ji burned, 1571', 'sub': 'the revered Mt Hiei complex destroyed', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Thousands massacred', 'sub': 'monks, women and children killed; power broken', 'color': '#111827'},
      ], takeaway='He treated militant religion as a military enemy — and destroyed it with a ruthlessness that horrified even his own age.', accent=AC),
      bg='Great Buddhist monasteries like <b>Enryaku-ji</b> on <b>Mount Hiei</b> were armed political powers that had sheltered his enemies and defied secular rule for centuries.',
      people='the warrior-monks (sōhei) of Mt Hiei; the enemies they sheltered; the thousands killed in the assault.',
      what='In 1571 Nobunaga <b>attacked and burned the entire Enryaku-ji complex</b> on Mount Hiei, <b>massacring thousands</b> — monks and civilians alike — permanently breaking the monastery’s military power.',
      crux='He recognised the monasteries as <b>rival armed powers</b>, not sacred exceptions, and destroyed them by pure force.',
      conseq='The atrocity cowed the other militant temples and removed a major obstacle to unification — while cementing his fearsome reputation.',
      matters='Ruthless leaders refuse to exempt any power — even a sacred one — from the logic of force; the moral cost is immense.'),

    E('ikko', '1570–1580', 'The ten-year war with the Ikkō-ikki', ['BATTLE', 'TRAGEDY'],
      'Nobunaga’s longest, hardest struggle is against the Ikkō-ikki — vast leagues of militant Buddhist peasants and warriors fighting for their faith — whom he besieges, starves and massacres over a decade, including tens of thousands burned at Nagashima.',
      svg_stack('A decade against a religious insurgency', [
          {'n': 1, 'label': 'The Ikkō-ikki leagues', 'sub': 'militant Buddhist peasant-warrior movements', 'color': '#a16207'},
          {'n': 2, 'label': 'Nagashima massacre, 1574', 'sub': 'tens of thousands burned in a besieged fortress', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Hongan-ji subdued, 1580', 'sub': 'the great Ishiyama fortress-temple finally surrenders', 'color': '#78350f'},
      ], takeaway='He crushed a mass religious movement with siege, fire and massacre over ten relentless years.', accent=AC),
      bg='The <b>Ikkō-ikki</b> were powerful leagues of the True Pure Land sect — peasants, monks and samurai who ruled provinces and fielded huge armies against secular lords.',
      people='the Ikkō-ikki fighters and their families; the abbot of the <b>Ishiyama Hongan-ji</b>; the tens of thousands killed at Nagashima.',
      what='Over a decade Nobunaga waged brutal war on the Ikkō-ikki, <b>burning tens of thousands at Nagashima (1574)</b> and finally forcing the surrender of their great fortress-temple <b>Ishiyama Hongan-ji in 1580</b>.',
      crux='He was determined to destroy any <b>independent armed power</b>, however popular or holy — the unification could brook no rivals.',
      conseq='Breaking the Ikkō-ikki removed the last great non-samurai military force and cleared the path toward unifying Japan.',
      matters='Consolidating power often means crushing every alternative centre of force — a long, merciless business.'),

    E('nagashino', '1575', 'Nagashino — guns destroy the cavalry age', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'At Nagashino, Nobunaga meets the feared Takeda cavalry — the finest horsemen in Japan — with massed ranks of gunners behind palisades, cutting them down in disciplined volleys and inaugurating a new age of gunpowder warfare.',
      svg_stack('Firepower breaks the horsemen', [
          {'n': 1, 'label': 'The famed Takeda cavalry', 'sub': 'Japan’s most feared mounted force charges', 'color': '#a16207'},
          {'n': 2, 'label': 'Massed guns behind palisades', 'sub': 'ranks of arquebusiers fire in rotating volleys', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The cavalry annihilated', 'sub': 'the charge is cut down; the Takeda broken', 'color': '#166534'},
      ], takeaway='He turned the peasant-fired gun into the master weapon — ending the dominance of the mounted samurai.', accent=AC),
      bg='The <b>Takeda</b> clan’s cavalry was the most feared force in Japan. Nobunaga, an early enthusiast for firearms, prepared a defensive killing-ground at <b>Nagashino</b>.',
      people='<b>Takeda Katsuyori</b>, whose cavalry charged; Nobunaga and his ally <b>Ieyasu</b>; the ranks of gunners.',
      what='At <b>Nagashino (1575)</b> Nobunaga deployed large numbers of <b>arquebusiers behind wooden palisades</b>, firing in <b>disciplined volleys</b> that <b>shattered the charging Takeda cavalry</b> — a landmark in the use of firearms.',
      crux='He grasped that <b>massed, disciplined firepower</b> could defeat the finest traditional cavalry — a tactical revolution.',
      conseq='The Takeda were crippled (destroyed by 1582); gunpowder warfare and infantry now dominated Japanese battle.',
      matters='The leader who masters a new technology can overturn the reigning military order — firepower ended the age of the horse.'),
]

# ==================================================================  PHASE 4 — THE NEW ORDER
PHASE_ORDER = [
    E('rakuichi', '1570s', 'Free markets — dismantling the old economy', ['REFORM', 'TRIUMPH'],
      'Nobunaga is as revolutionary in economics as in war — abolishing the monopolistic guilds and toll-barriers that strangled trade, opening free markets (rakuichi-rakuza), and standardising the conditions for a booming commercial economy.',
      svg_row('Tearing down the old economic order', [
          {'n': 1, 'label': 'Abolish guild monopolies', 'sub': 'rakuza — end the cartels that throttled trade', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Open free markets', 'sub': 'rakuichi — markets open to all, low barriers', 'color': '#166534'},
          {'n': 3, 'label': 'Remove toll barriers', 'sub': 'scrap the road tolls that choked commerce', 'color': '#78350f'},
      ], edge_labels=['plus', 'plus'], takeaway='He grasped that prosperity is engineered — free trade and open markets fund armies and stabilise rule.', accent=AC),
      bg='Medieval Japan’s economy was strangled by <b>guild monopolies (za)</b> and countless <b>toll barriers</b> that taxed and obstructed trade.',
      people='the merchants freed to trade; the old guilds and barrier-holders whose privileges he abolished; the towns that boomed.',
      what='Nobunaga instituted <b>rakuichi-rakuza</b> — <b>abolishing guild monopolies and opening free markets</b> — and <b>removed toll barriers</b>, unleashing commerce in the lands he controlled.',
      crux='He understood that <b>economic freedom generated wealth and revenue</b> — the sinews of military and political power.',
      conseq='His domains prospered, funding his armies and his ambitions, and the reforms spread across unified Japan.',
      matters='Power rests on economics as much as arms — freeing trade can be as revolutionary as any battlefield victory.'),

    E('azuchi', '1576–1579', 'Azuchi Castle — a monument to the new age', ['REFORM', 'TRIUMPH'],
      'Nobunaga builds Azuchi Castle, a soaring, gorgeously decorated tower castle unlike anything Japan has seen — a statement in stone and gold of a new kind of centralised, magnificent power, and the model for every great castle that follows.',
      svg_stack('Power made magnificent', [
          {'n': 1, 'label': 'A revolutionary tower castle', 'sub': 'Azuchi’s towering, decorated keep, 1576–79', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Splendour as statement', 'sub': 'gold and art proclaim a new central authority', 'color': '#a16207'},
          {'n': 3, 'label': 'The model for the age', 'sub': 'inspires the great castles of unified Japan', 'color': '#166534'},
      ], takeaway='He made his new order visible — a magnificent castle announcing a centralised power the old order lacked.', accent=AC),
      bg='Earlier fortresses were austere and military. Nobunaga wanted a seat that expressed his <b>unprecedented, centralised power and cultural ambition</b>.',
      people='the architects and artists of Azuchi; the Jesuits and lords who marvelled at it; the townsfolk of the castle town below.',
      what='Between 1576 and 1579 Nobunaga built <b>Azuchi Castle</b>, a lavishly decorated multi-storey <b>tower keep</b> overlooking Lake Biwa — a revolutionary symbol of centralised authority that set the pattern for Japanese castle architecture.',
      crux='He used <b>architecture as propaganda</b> — a magnificent seat proclaiming a new, superior order of power.',
      conseq='Azuchi gave its name to the era and inspired the great castles of Hideyoshi and Ieyasu; it burned after Nobunaga’s death.',
      matters='The powerful build to be seen — grand architecture announces and legitimises a new order.'),

    E('meritocracy', '1570s–1582', 'Talent over birth — and a peasant made general', ['REFORM', 'POLITICS'],
      'Nobunaga breaks the rigid rules of samurai society by promoting men on ability, not birth — most spectacularly raising the peasant-born Hideyoshi to be one of his top generals, seeding a meritocratic revolution that outlives him.',
      svg_row('Promotion by merit, not blood', [
          {'n': 1, 'label': 'Rigid hereditary ranks', 'sub': 'samurai society bound by birth and lineage', 'color': '#a16207'},
          {'n': 2, 'label': 'Nobunaga promotes by talent', 'sub': 'ability, results and loyalty win advancement', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A peasant becomes a general', 'sub': 'Hideyoshi rises from nothing to the top ranks', 'color': '#166534'},
      ], edge_labels=['broken by', 'so'], takeaway='He rewarded ability over pedigree — unlocking talents like Hideyoshi that the old order would have wasted.', accent=AC),
      bg='Samurai advancement was normally fixed by <b>birth</b>. Nobunaga, needing the best men, was willing to ignore lineage entirely.',
      people='<b>Toyotomi Hideyoshi</b>, the peasant-born general who rose to the top; <b>Akechi Mitsuhide</b>, another talented outsider; the traditional retainers displaced.',
      what='Nobunaga <b>promoted men on merit</b>, most famously raising the low-born <b>Hideyoshi</b> to senior command — a radical breach of hereditary norms that drew exceptional talent to his service.',
      crux='He valued <b>results over pedigree</b>, tapping ability the rigid class system suppressed — a source of dynamic strength.',
      conseq='Hideyoshi would complete the unification of Japan; but ambitious outsiders also carried risk, as his own end would show.',
      matters='Rewarding merit over birth unlocks hidden talent — the greatest organisations promote ability regardless of origin.'),

    E('jesuits', '1569–1582', 'The West at his court — guns, God and curiosity', ['POLITICS', 'REFORM'],
      'Endlessly curious and coldly practical, Nobunaga welcomes European Jesuits and their goods — fascinated by Western technology, arms and novelty, and happy to patronise Christianity partly as a counterweight to the militant Buddhism he is destroying.',
      svg_stack('An open mind — and a shrewd calculation', [
          {'n': 1, 'label': 'Welcomes the Jesuits', 'sub': 'grants missionaries freedom and favour', 'color': '#166534'},
          {'n': 2, 'label': 'Fascinated by the West', 'sub': 'guns, clocks, maps, armour and novelties', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A counter to the monks', 'sub': 'Christianity useful against militant Buddhism', 'color': '#78350f'},
      ], takeaway='His openness to the West was both genuine curiosity and cold strategy against his Buddhist enemies.', accent=AC),
      bg='European traders and <b>Jesuit missionaries</b> had reached Japan, bringing firearms, goods and a new religion. Most lords were wary; Nobunaga was intrigued.',
      people='the Jesuit <b>Luís Fróis</b> and other missionaries; the European traders; the Christian converts (kirishitan) he tolerated.',
      what='Nobunaga <b>welcomed the Jesuits</b>, showed keen interest in <b>Western technology, arms and culture</b>, and favoured Christianity in part as a <b>counterweight</b> to the militant Buddhist establishment he was crushing.',
      crux='He combined <b>genuine curiosity</b> with <b>cold strategic calculation</b> — using the foreign faith and its goods for his own ends.',
      conseq='His patronage let Christianity take root in Japan (later brutally suppressed under the Tokugawa), and spread Western arms and ideas.',
      matters='Openness to the new can be both intellectual and strategic — the innovator embraces what others fear, and turns it to use.'),
]

# ==================================================================  PHASE 5 — BETRAYAL
PHASE_FALL = [
    E('supremacy', '1580–1582', 'On the threshold of a unified Japan', ['BATTLE', 'TRIUMPH'],
      'By 1582 Nobunaga has destroyed the Takeda, subdued the monks, and dominates central Japan — his generals driving into the west and east, the unification of the country seemingly within his grasp at last.',
      svg_row('The realm almost in his hand', [
          {'n': 1, 'label': 'Takeda destroyed, 1582', 'sub': 'his greatest rival clan annihilated', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Generals sweep outward', 'sub': 'Hideyoshi west against the Mōri; others east and north', 'color': '#a16207'},
          {'n': 3, 'label': 'Unification in sight', 'sub': 'Nobunaga dominates central Japan', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He stood at the summit — the unification of a century-fractured Japan seemingly within reach.', accent=AC),
      bg='After a decade of relentless war, Nobunaga had broken his major rivals and militant sects and commanded the most powerful forces in Japan.',
      people='his generals <b>Hideyoshi</b> (campaigning west against the Mōri) and <b>Akechi Mitsuhide</b>; the remaining rival clans being ground down.',
      what='By 1582 Nobunaga had <b>destroyed the Takeda</b> and dominated central Japan, his armies pushing outward on every front. The <b>unification of Japan</b> appeared close at hand.',
      crux='He had reached the <b>threshold of total success</b> — the goal of “Tenka Fubu” nearly achieved.',
      conseq='At this very height, betrayal came from within his own ranks.',
      matters='The moment of near-total triumph is often the moment of greatest danger — success breeds the ambition that undoes it.'),

    E('honnoji', 'Jun 1582', 'The Honnō-ji Incident — betrayed at the summit', ['POLITICS', 'DEATH', 'TURNING POINT'],
      'At the peak of his power, Nobunaga is betrayed by his own general Akechi Mitsuhide, who surrounds him with an army while he rests, nearly unguarded, in a Kyoto temple — and Nobunaga, trapped, dies in the flames, his body never found.',
      svg_stack('Undone by his own general', [
          {'n': 1, 'label': 'Nearly unguarded in Kyoto', 'sub': 'rests at the Honnō-ji temple with few men', 'color': '#a16207'},
          {'n': 2, 'label': 'Akechi Mitsuhide turns', 'sub': 'his own general surrounds the temple with an army', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Death in the flames', 'sub': 'trapped, Nobunaga dies; his body is never found', 'color': '#111827'},
      ], takeaway='The man who beat whole coalitions was destroyed by a single trusted subordinate’s treachery.', accent=AC),
      bg='In June 1582 Nobunaga stopped, lightly guarded, at the <b>Honnō-ji</b> temple in Kyoto, while his armies campaigned far away. His general <b>Akechi Mitsuhide</b> was sent to reinforce Hideyoshi.',
      people='<b>Akechi Mitsuhide</b>, the betrayer; Nobunaga, trapped with a handful of men; his heir, killed nearby.',
      what='Instead of marching to the front, <b>Mitsuhide turned his army on Nobunaga</b>, surrounding the Honnō-ji. Trapped and overwhelmed, <b>Nobunaga died</b> (by tradition committing seppuku as the temple burned); his <b>body was never recovered</b>.',
      crux='All his power could not protect him from <b>betrayal by a trusted subordinate</b> at a moment of carelessness.',
      conseq='Mitsuhide’s coup lasted only days: Hideyoshi rushed back and destroyed him, then rose to complete the unification.',
      matters='The greatest external strength cannot guard against internal treachery — trust misplaced can undo everything.'),

    E('legacy', '1582 onward', 'The rice cake — Nobunaga’s unfinished revolution', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'Nobunaga did not live to unify Japan — but he broke the old order that made unification impossible, and his successors Hideyoshi and Ieyasu built on his foundation, as the famous saying captures: Nobunaga pounded the rice cake, Hideyoshi shaped it, Ieyasu ate it.',
      svg_row('The unifier who started it all', [
          {'n': 1, 'label': 'Nobunaga pounds the cake', 'sub': 'breaks the old order; starts unification', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Hideyoshi shapes it', 'sub': 'completes the unification of Japan', 'color': '#a16207'},
          {'n': 3, 'label': 'Ieyasu eats it', 'sub': 'founds the 250-year Tokugawa peace', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He was the revolutionary first mover — smashing the old world so others could build the new.', accent=AC),
      bg='Nobunaga died with Japan not yet unified, but with the greatest obstacles — the militant monks, the strongest rival clans, the old economic order — broken.',
      people='<b>Toyotomi Hideyoshi</b>, who avenged him and unified Japan; <b>Tokugawa Ieyasu</b>, who founded the lasting peace; the successors who built on his work.',
      what='Though betrayed before finishing, Nobunaga had <b>shattered the medieval order</b> — militant Buddhism, the strongest rivals, the guild economy — and pioneered the guns, castles and meritocracy his successors used. A famous verse says <b>Nobunaga pounded the rice cake, Hideyoshi shaped it, and Ieyasu ate it.</b>',
      crux='He was the <b>revolutionary first mover</b> whose destruction of the old order made the unification of Japan finally possible.',
      conseq='Within 20 years Japan was unified and at peace under the Tokugawa — on the foundations Nobunaga had violently laid.',
      matters='History’s great changes often need a ruthless first mover to break the old order — even if others reap the reward.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Oda Nobunaga was the ruthless, revolutionary warlord who began the unification of a Japan shattered by a century of civil war. Dismissed as a fool, he overturned overwhelming odds at Okehazama, mastered gunpowder warfare, burned the militant monasteries, tore down the guild economy, and drove toward a unified realm — only to be betrayed and killed by his own general at the very threshold of victory. He is the ultimate study in <b>the underestimated innovator, ruthlessness in service of a vision, and being the first mover who breaks an old order for others to inherit.</b></p>
<div class="ov-quote">“Tenka Fubu” — to bring the realm under military rule.<span>— the motto on Nobunaga’s personal seal</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">The mocked “Fool of Owari” unifies his province by force → shatters a ten-times-larger army at Okehazama → allies with Ieyasu, takes Mino, and declares his ambition to rule the realm → seizes Kyoto and rules through a puppet shogun → beats a coalition of the whole realm → burns Mount Hiei and grinds down the Ikkō-ikki → destroys the Takeda cavalry with massed guns at Nagashino → tears down guilds and toll-barriers, builds Azuchi, and promotes a peasant to general → stands on the threshold of a unified Japan → and is betrayed and killed at Honnō-ji.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🔫</div><h4>The gunpowder revolution</h4><p>Nagashino’s massed volleys ended the age of the cavalry samurai.</p></div>
  <div class="ov-card"><div class="i">⛩️</div><h4>Breaking the old order</h4><p>He smashed the militant monasteries and guilds that blocked unification.</p></div>
  <div class="ov-card"><div class="i">📈</div><h4>Economic revolution</h4><p>Free markets and open trade — power built on prosperity, not just arms.</p></div>
  <div class="ov-card"><div class="i">🍡</div><h4>The first mover</h4><p>He pounded the rice cake others would shape and eat — the founder of unification.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Fool of Owari</b><small> 1534–67</small><p>An underestimated heir unifies his province and wins at Okehazama.</p></div>
  <div><b>2 · The March to Kyoto</b><small> 1568–73</small><p>A puppet shogun, and a whole realm turned against him.</p></div>
  <div><b>3 · The Ruthless Wars</b><small> 1571–80</small><p>Burning Mount Hiei, the Ikkō-ikki, and guns at Nagashino.</p></div>
  <div><b>4 · The New Order</b><small> 1570s–82</small><p>Free markets, Azuchi Castle, meritocracy and the West.</p></div>
  <div><b>5 · Betrayal</b><small> 1582</small><p>On the threshold of unification — and Honnō-ji.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Toyotomi Hideyoshi', 'role': 'general and successor', 'color': '#a16207',
     'bio': 'The peasant-born general whom Nobunaga raised to high command; he avenged Nobunaga’s murder and completed the unification of Japan.',
     'rel': 'The talent Nobunaga’s meritocracy unleashed — who finished his work.'},
    {'name': 'Tokugawa Ieyasu', 'role': 'ally', 'color': '#166534',
     'bio': 'Nobunaga’s steadfast ally for two decades, who later founded the Tokugawa shogunate and 250 years of peace on the foundation Nobunaga laid.',
     'rel': 'The loyal ally who ultimately inherited the unified realm.'},
    {'name': 'Akechi Mitsuhide', 'role': 'general and betrayer', 'color': '#b91c1c',
     'bio': 'A cultured, capable general who suddenly turned on Nobunaga at Honnō-ji, causing his death — then was destroyed by Hideyoshi within days.',
     'rel': 'The trusted subordinate whose betrayal killed him.'},
    {'name': 'Imagawa Yoshimoto', 'role': 'early rival', 'color': '#7c3aed',
     'bio': 'The powerful warlord who invaded Owari with a huge army in 1560, only to be killed by Nobunaga’s surprise attack at Okehazama.',
     'rel': 'The great rival whose fall at Okehazama made Nobunaga’s name.'},
    {'name': 'Takeda Katsuyori', 'role': 'rival', 'color': '#78350f',
     'bio': 'Leader of the feared Takeda cavalry, whose charge was destroyed by Nobunaga’s massed gunners at Nagashino in 1575; the clan was annihilated by 1582.',
     'rel': 'The cavalry lord broken by Nobunaga’s firepower.'},
]

KEY_EVENTS = [
    ('1534', 'Nobunaga born', 'Into a minor Owari warlord family.'),
    ('1560', 'Okehazama', 'Destroys Imagawa’s huge army by surprise.'),
    ('1567', 'Conquers Mino', 'Adopts the “Tenka Fubu” seal.'),
    ('1568', 'Marches on Kyoto', 'Installs Yoshiaki as puppet shogun.'),
    ('1571', 'Burns Mount Hiei', 'Breaks the warrior-monasteries.'),
    ('1573', 'Ends the Ashikaga shogunate', 'Expels Yoshiaki.'),
    ('1575', 'Nagashino', 'Massed guns destroy the Takeda cavalry.'),
    ('1576', 'Builds Azuchi Castle', 'Symbol of the new centralised order.'),
    ('1582', 'Honnō-ji Incident', 'Betrayed and killed by Akechi Mitsuhide.'),
]

MASTER = [
    {'year': '1534', 'age': 'born', 'phase': 'Fool of Owari', 'title': 'Born in Owari', 'desc': 'A minor warlord family.'},
    {'year': '1560', 'age': 'age 26', 'phase': 'Fool of Owari', 'title': 'Okehazama', 'desc': 'The impossible victory.'},
    {'year': '1568', 'age': 'age 34', 'phase': 'March to Kyoto', 'title': 'Seizes Kyoto', 'desc': 'Rules through a puppet shogun.'},
    {'year': '1575', 'age': 'age 41', 'phase': 'Ruthless Wars', 'title': 'Nagashino', 'desc': 'The gunpowder revolution.'},
    {'year': '1576', 'age': 'age 42', 'phase': 'The New Order', 'title': 'Azuchi Castle', 'desc': 'A new centralised power.'},
    {'year': '1582', 'age': 'age 48', 'phase': 'Betrayal', 'title': 'Honnō-ji', 'desc': 'Betrayed and killed.'},
]

SOURCES = [
    ('Britannica — Oda Nobunaga', 'https://www.britannica.com/biography/Oda-Nobunaga'),
    ('World History Encyclopedia — Oda Nobunaga', 'https://www.worldhistory.org/Oda_Nobunaga/'),
    ('Britannica — Battle of Nagashino', 'https://www.britannica.com/event/Battle-of-Nagashino'),
    ('World History Encyclopedia — Sengoku Period', 'https://www.worldhistory.org/Sengoku_Period/'),
    ('Wikipedia — Oda Nobunaga', 'https://en.wikipedia.org/wiki/Oda_Nobunaga'),
]

def build_meta():
    return {
        'pid': 'gm-nobunaga.html', 'kind': 'man', 'emoji': '🔥', 'accent': AC,
        'name': 'Oda Nobunaga', 'years': '1534–1582', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The ruthless innovator who began the unification of Japan — master of the gun, destroyer of the militant monasteries — betrayed and killed by his own general at the threshold of victory.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Fool of Owari', 'type': 'timeline',
             'intro': 'Mocked as an eccentric fool, an underestimated heir unifies his own province by force, shatters a ten-times-larger army at Okehazama, and — uniquely — declares his ambition to rule the whole realm.', 'events': PHASE_RISE},
            {'id': 'kyoto', 'label': '2 · The March to Kyoto', 'type': 'timeline',
             'intro': 'He seizes the capital and rules the realm through a puppet shogun — until the frustrated shogun rallies a coalition of the whole country against him, and Nobunaga fights for survival on every front.', 'events': PHASE_KYOTO},
            {'id': 'wars', 'label': '3 · The Ruthless Wars', 'type': 'timeline',
             'intro': 'He breaks the age’s armed religions and rivals with shocking ruthlessness — burning Mount Hiei, grinding down the Ikkō-ikki over a decade, and destroying the feared Takeda cavalry with massed guns at Nagashino.', 'events': PHASE_WARS},
            {'id': 'order', 'label': '4 · The New Order', 'type': 'timeline',
             'intro': 'He is as revolutionary in peace as in war — tearing down guild monopolies and toll-barriers, building the magnificent Azuchi Castle, promoting a peasant to general, and welcoming the West.', 'events': PHASE_ORDER},
            {'id': 'fall', 'label': '5 · Betrayal', 'type': 'timeline',
             'intro': 'On the very threshold of a unified Japan, at the height of his power, Nobunaga is betrayed by his own general at the Honnō-ji — leaving his revolution for Hideyoshi and Ieyasu to complete.', 'events': PHASE_FALL,
             'sources': SOURCES, 'srcnote': 'Sources include Ōta Gyūichi’s chronicle and Jesuit accounts (Luís Fróis); some famous episodes (the “Fool of Owari,” Hirate’s suicide) blend record and tradition.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
