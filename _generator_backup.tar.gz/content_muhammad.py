# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Muhammad, the Prophet and founder of Islam.
Presented with the utmost respect: the Islamic tradition’s account and the historical
context are given neutrally and reverently, and this guide uses ONLY abstract
concept-map diagrams — never any figurative depiction of the Prophet."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#0a7d3c'  # Islamic green

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE ORPHAN OF MECCA
PHASE_ORPHAN = [
    E('birth', 'c. 570 CE', 'Born in Mecca, orphaned in childhood', ['RISE', 'TRAGEDY'],
      'Muhammad is born around 570 CE into the clan of Hashim of the Quraysh, the tribe that guards Mecca and its sanctuary, the Kaaba. His father Abdullah dies before his birth and his mother Amina when he is about six, leaving him an orphan in a society where kinship is everything.',
      svg_stack('An orphan of the Quraysh', [
          {'n': 1, 'label': 'Born in Mecca, c. 570', 'sub': 'into the clan of Hashim of the Quraysh', 'color': '#0a7d3c'},
          {'n': 2, 'label': 'Father, then mother, die', 'sub': 'Abdullah before his birth; Amina when he is about six', 'color': '#78716c'},
          {'n': 3, 'label': 'An orphan in a tribal world', 'sub': 'safety depends wholly on one’s kin', 'color': '#a16207'},
      ], takeaway='He entered life without father or mother, in a world where a person was only as safe as their family — a hard beginning.', accent=AC),
      bg='Mecca was a caravan city and pilgrimage centre built around the <b>Kaaba</b>; its leading tribe, the <b>Quraysh</b>, guarded the sanctuary. Muhammad was born into its clan of Hashim around 570 CE.',
      people='his father <b>Abdullah</b>, who died before his birth; his mother <b>Amina</b>, who died when he was about six; the <b>Quraysh</b> tribe of Mecca.',
      what='Muhammad was born in Mecca around <b>570 CE</b>. His father had already died; his mother Amina died when he was roughly six, leaving him an <b>orphan</b> while still a small child.',
      crux='In tribal Arabia a person’s security rested on <b>kinship</b> — an orphan without parents was uniquely vulnerable, and these early losses marked him deeply.',
      conseq='Responsibility for the orphaned boy passed first to his grandfather, and then to his uncle.',
      matters='Islamic tradition remembers his orphanhood as formative — the Quran itself enjoins <b>care for the orphan</b>, and his own beginnings gave that command weight.'),

    E('guardians', 'c. 576–595', 'Raised by his grandfather, then his uncle Abu Talib', ['RISE'],
      'Care of the orphan passes first to his grandfather Abd al-Muttalib, a respected Meccan elder, and after his death to his uncle Abu Talib, head of the Hashim clan. Abu Talib takes the boy on trading journeys, and Muhammad grows up learning the caravan trade that is Mecca’s lifeblood.',
      svg_row('A chain of guardians', [
          {'n': 1, 'label': 'Grandfather Abd al-Muttalib', 'sub': 'a respected elder takes in the boy', 'color': '#a16207'},
          {'n': 2, 'label': 'Uncle Abu Talib', 'sub': 'the clan chief becomes his protector', 'color': '#0a7d3c'},
          {'n': 3, 'label': 'The caravan trade', 'sub': 'he travels with the merchant caravans of Mecca', 'color': '#0369a1'},
      ], edge_labels=['then', 'into'], takeaway='Passed from guardian to guardian, he learned the trade and the ways of Mecca under his uncle’s protection.', accent=AC),
      bg='With both parents gone, the boy needed a protector within Mecca’s clan society.',
      people='his grandfather <b>Abd al-Muttalib</b>; his uncle <b>Abu Talib</b>, chief of the Hashim clan and his lifelong protector; the Meccan merchants.',
      what='Muhammad was raised first by his grandfather <b>Abd al-Muttalib</b> and, after the old man’s death, by his uncle <b>Abu Talib</b>, who became his guardian and took him on trading journeys.',
      crux='Under Abu Talib’s protection he was drawn into the <b>caravan commerce</b> that was Mecca’s lifeblood, gaining a trade and a settled place in the clan.',
      conseq='His growing reputation for honesty in that trade would soon reach a wealthy widow named Khadija.',
      matters='Abu Talib’s protection would prove crucial for decades — while the uncle lived, the Quraysh could not easily move against his nephew.'),

    E('alamin', 'c. 595', 'Al-Amin, the trustworthy — and marriage to Khadija', ['RISE', 'LOVE'],
      'Muhammad earns a reputation across Mecca for honesty and fair dealing, gaining the epithet al-Amin, “the trustworthy.” Employed to lead the caravans of Khadija, a respected widow and merchant, he wins her trust and then her hand; by tradition he is about twenty-five and she about forty. She becomes his closest support and, later, the first to believe in him.',
      svg_stack('A reputation, and a marriage', [
          {'n': 1, 'label': 'Known as al-Amin', 'sub': 'the trustworthy; famed for honest dealing', 'color': '#0a7d3c'},
          {'n': 2, 'label': 'Leads Khadija’s caravans', 'sub': 'the widow-merchant employs him for her trade', 'color': '#a16207'},
          {'n': 3, 'label': 'Marriage to Khadija', 'sub': 'by tradition he about 25, she about 40', 'color': '#be185d'},
      ], takeaway='His honesty won him a name and a wife — and in Khadija, the partner who would first believe his message.', accent=AC),
      bg='Mecca’s economy ran on trade, and a merchant’s word was their fortune. <b>Khadija</b> was a wealthy widow who hired agents to manage her caravans.',
      people='<b>Khadija bint Khuwaylid</b>, the merchant he married and his first supporter; the Meccans who called him <b>al-Amin</b>.',
      what='Muhammad became known as <b>al-Amin</b>, “the trustworthy,” for his honesty. Managing the trade caravans of the widow <b>Khadija</b>, he earned her regard and married her — tradition holds he was about twenty-five and she about forty.',
      crux='His name for <b>integrity</b> set him apart in a commercial city, and his marriage to Khadija gave him security and a devoted partner.',
      conseq='When revelation came, Khadija would be the first to accept it and to steady him.',
      matters='The trust he earned as a man — <b>al-Amin</b> — is inseparable from how his contemporaries weighed his later claim to be a messenger.'),
]

# ==================================================================  PHASE 2 — THE REVELATION
PHASE_REVELATION = [
    E('hira', '610 CE', 'The first revelation in the cave of Hira', ['TURNING POINT', 'REFORM'],
      'In the Islamic account, while withdrawn in prayer in the cave of Hira on a mountain outside Mecca, Muhammad receives the first revelation of the Quran — the angel Gabriel commanding him to “Recite.” Shaken, he returns to Khadija, who becomes the first to believe. Muslims date the beginning of his prophethood to this event, around 610 CE.',
      svg_stack('The call to prophethood', [
          {'n': 1, 'label': 'Retreat to the cave of Hira', 'sub': 'withdrawn in prayer on a mountain outside Mecca', 'color': '#0369a1'},
          {'n': 2, 'label': 'The angel Gabriel: “Recite”', 'sub': 'the first words of the Quran, c. 610', 'color': '#0a7d3c'},
          {'n': 3, 'label': 'Khadija believes first', 'sub': 'she affirms his account and steadies him', 'color': '#be185d'},
      ], takeaway='In the Islamic account the revelation began at Hira — the first verses of the Quran, and the start of his mission.', accent=AC),
      bg='Muhammad was given to periods of solitary reflection, retreating to a cave on <b>Mount Hira</b> near Mecca.',
      people='the angel <b>Gabriel</b> (Jibril), who brings the revelation in Islamic belief; <b>Khadija</b>, the first to believe; <b>God</b> (Allah), the source of the revelation in Islamic teaching.',
      what='Islamic tradition holds that around <b>610 CE</b>, in the cave of Hira, the angel <b>Gabriel</b> appeared to Muhammad and commanded him to “Recite,” delivering the first verses of the <b>Quran</b>. Overwhelmed, he confided in Khadija, who accepted his account and became the first Muslim.',
      crux='For Muslims this event marks the beginning of the <b>Quran’s revelation</b> and of Muhammad’s prophethood — the founding moment of Islam.',
      conseq='Revelations would continue over some twenty-two years and, gathered together, form the Quran.',
      matters='The <b>Quran</b> is the central revelation of Islam — believed by Muslims to be the literal word of God conveyed through Muhammad; historians mark Hira as the traditional start of the movement.'),

    E('monotheism', '613–615', 'Preaching the one God', ['REFORM', 'POLITICS'],
      'After private beginnings, Muhammad begins to preach openly in Mecca, calling its people from the worship of many idols to submission to the one God, warning of a coming judgement, and demanding care for the poor and the orphan. A small community of believers gathers — early converts drawn from kin, friends, and the vulnerable.',
      svg_row('A message of one God', [
          {'n': 1, 'label': 'Idolatry at the Kaaba', 'sub': 'Mecca venerates many deities', 'color': '#78716c'},
          {'n': 2, 'label': 'Call to the one God', 'sub': 'submission to God; judgement; care for the poor', 'color': '#0a7d3c'},
          {'n': 3, 'label': 'A small band of believers', 'sub': 'early converts gather, quietly then openly', 'color': '#a16207'},
      ], edge_labels=['answered by', 'draws'], takeaway='He called Mecca from many gods to one — a message of monotheism, judgement, and justice for the weak.', accent=AC),
      bg='The <b>Kaaba</b> housed many idols and Mecca profited from the pilgrimage to them. Muhammad began preaching first privately, then publicly around 613.',
      people='the first believers — including <b>Khadija</b>, his young cousin <b>Ali</b>, his friend <b>Abu Bakr</b>, and the freedman <b>Zayd</b>; the Meccans he called to the faith.',
      what='Muhammad preached the <b>oneness of God</b> (tawhid), the coming judgement, and the duties of charity and justice, rejecting the idols of the Kaaba. A small community of <b>Muslims</b> — “those who submit” — formed around him.',
      crux='His monotheism struck directly at the idols and the <b>pilgrimage trade</b> that gave Mecca its wealth and standing.',
      conseq='The message won devoted followers but alarmed the Quraysh leadership, who saw their gods and their livelihood threatened.',
      matters='The core of Islam — <b>submission to the one God</b> — was proclaimed here; its social demands for the poor and the orphan were as radical as its theology.'),

    E('persecution', '615–622', 'Persecution by the Quraysh, and the year of sorrow', ['TRAGEDY', 'POLITICS'],
      'The Quraysh turn on Muhammad and his followers, mocking, boycotting and persecuting them; some believers flee to Abyssinia for refuge. Around 619 he loses both Khadija and his uncle Abu Talib — the “year of sorrow” — stripping him of his protector. As danger mounts, men from the city of Yathrib accept his message and invite him to come.',
      svg_stack('Pressure mounts in Mecca', [
          {'n': 1, 'label': 'Quraysh persecute the believers', 'sub': 'mockery, boycott and abuse; some flee to Abyssinia', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The year of sorrow, c. 619', 'sub': 'Khadija and Abu Talib die; his protection gone', 'color': '#78716c'},
          {'n': 3, 'label': 'Yathrib invites him', 'sub': 'men of the northern city pledge to receive him', 'color': '#0a7d3c'},
      ], takeaway='Loss and persecution closed in — until a distant city offered the fledgling community a refuge.', accent=AC),
      bg='The Quraysh leaders saw the new faith as a threat to their gods, their trade and their authority, and moved to crush it.',
      people='the hostile <b>Quraysh</b> notables; the believers who emigrated to Christian <b>Abyssinia</b>; <b>Khadija</b> and <b>Abu Talib</b>, both lost around 619; the delegates of <b>Yathrib</b> (Medina).',
      what='The Quraysh subjected the Muslims to mockery, a social and economic <b>boycott</b>, and outright persecution; some sought refuge in Abyssinia. Around 619 Muhammad lost both Khadija and Abu Talib. Then men from <b>Yathrib</b> accepted his message and invited him to their city.',
      crux='With his chief protector Abu Talib gone, Muhammad was newly exposed in Mecca — and the invitation from Yathrib offered both escape and a base.',
      conseq='This opening set the stage for the <b>Hijra</b>, the migration that would remake the movement.',
      matters='Persecution turned a Meccan preacher into the leader of a community seeking a homeland — the hinge on which his mission turned.'),
]

# ==================================================================  PHASE 3 — THE HIJRA AND THE UMMA
PHASE_HIJRA = [
    E('hijra', '622 CE', 'The Hijra — migration to Medina', ['TURNING POINT', 'TRIUMPH'],
      'In 622 Muhammad and his followers emigrate from Mecca to Yathrib, thereafter called Medina, “the City” of the Prophet. The migration — the Hijra — is so pivotal that Muslims later date their calendar from this year. In Medina he is welcomed not merely as a preacher but as a leader and arbiter.',
      svg_stack('The migration that starts an era', [
          {'n': 1, 'label': 'Believers leave Mecca, 622', 'sub': 'emigrating in secret to escape the Quraysh', 'color': '#0a7d3c'},
          {'n': 2, 'label': 'Welcomed at Yathrib / Medina', 'sub': 'received as leader and arbiter of the city', 'color': '#a16207'},
          {'n': 3, 'label': 'Year 1 of the Islamic calendar', 'sub': 'the Hijra dates the Muslim era (AH)', 'color': '#0369a1'},
      ], takeaway='The Hijra of 622 was so decisive that the Islamic calendar itself begins with it.', accent=AC),
      bg='Persecution in Mecca and the invitation from Yathrib made migration both necessary and possible.',
      people='the emigrants (<b>Muhajirun</b>) who left Mecca; the Medinan “helpers” (<b>Ansar</b>) who received them; <b>Abu Bakr</b>, his companion on the journey.',
      what='In <b>622 CE</b> Muhammad led the <b>Hijra</b>, the emigration from Mecca to Yathrib — renamed <b>Medina</b>. There he became the community’s leader and judge. The Muslim calendar counts its years from this migration (AH, anno Hegirae).',
      crux='The move transformed a persecuted minority into a <b>self-governing community</b> with Muhammad at its head.',
      conseq='In Medina he would build the first Muslim polity — its mosque, its brotherhood, and its founding compact.',
      matters='The Hijra, not his birth or the first revelation, marks <b>year one of Islam</b> — a sign of how decisively the move from preaching to community shaped the faith.'),

    E('umma', '622–624', 'Building the umma — the Prophet’s Mosque and the brotherhood', ['REFORM', 'POLITICS'],
      'In Medina Muhammad forges a single community, the umma, bound by faith above the old tribal ties. He builds the Prophet’s Mosque as its centre and pairs each Meccan emigrant with a Medinan helper in a bond of brotherhood, knitting newcomers and hosts into one people.',
      svg_row('Faith above tribe', [
          {'n': 1, 'label': 'Muhajirun and Ansar', 'sub': 'Meccan emigrants and Medinan helpers', 'color': '#a16207'},
          {'n': 2, 'label': 'Bonds of brotherhood', 'sub': 'each emigrant paired with a host', 'color': '#0a7d3c'},
          {'n': 3, 'label': 'One umma, one mosque', 'sub': 'a community of faith centred on the Prophet’s Mosque', 'color': '#0369a1'},
      ], edge_labels=['joined as', 'into'], takeaway='He bound emigrants and hosts into a single community of faith — the umma — transcending tribe.', accent=AC),
      bg='Arabian society was organised by tribe and clan, and Medina itself had been divided by feud. Muhammad set faith as a new basis for unity.',
      people='the <b>Muhajirun</b> (emigrants) and <b>Ansar</b> (helpers); the tribes of Medina; the new converts.',
      what='Muhammad established the <b>umma</b>, a community defined by shared faith rather than blood. He built the <b>Prophet’s Mosque</b> as its centre and instituted bonds of <b>brotherhood</b> pairing emigrants with helpers to bind the community together.',
      crux='By making <b>faith, not tribe</b>, the organising bond, he created a new kind of community that could absorb people across clan lines.',
      conseq='This community needed a framework of rights and duties — supplied by the Constitution of Medina.',
      matters='The idea of the <b>umma</b>, a single community of believers above tribe and nation, remains central to Islam.'),

    E('constitution', 'c. 622', 'The Constitution of Medina', ['REFORM', 'POLITICS'],
      'Muhammad draws up an agreement, often called the Constitution of Medina, binding the Muslim emigrants, the Medinan Muslims, and the city’s Jewish and other tribes into a single mutual-defence community. It sets out rights and obligations, makes Muhammad the arbiter of disputes, and is regarded as one of the earliest documents of its kind.',
      svg_stack('A compact for a mixed city', [
          {'n': 1, 'label': 'Many groups, one pact', 'sub': 'Muslims and Medina’s Jewish and pagan tribes', 'color': '#a16207'},
          {'n': 2, 'label': 'Mutual defence and rights', 'sub': 'duties, protections, and Muhammad as arbiter', 'color': '#0a7d3c'},
          {'n': 3, 'label': 'One community of the pact', 'sub': 'an early written charter of a polity', 'color': '#0369a1'},
      ], takeaway='The compact bound Medina’s diverse groups into one community of mutual defence, with the Prophet as judge.', accent=AC),
      bg='Medina was home to feuding Arab tribes and several Jewish clans. A framework was needed to hold this mixed city together.',
      people='the Muslim <b>Muhajirun</b> and <b>Ansar</b>; the <b>Jewish tribes</b> of Medina; the remaining pagan clans; <b>Muhammad</b> as arbiter.',
      what='The agreement known as the <b>Constitution of Medina</b> bound the Muslims and the city’s other tribes, including its Jewish clans, into a single community for <b>mutual defence</b>, guaranteed certain rights, and made Muhammad the final arbiter of disputes.',
      crux='It turned a fractured city into a coordinated polity and gave Muhammad recognised <b>authority</b> as its judge and leader.',
      conseq='This fragile unity would be tested almost at once by conflict with Mecca.',
      matters='Historians regard the document as a remarkable early charter of a plural community; for the tradition it shows the Prophet as <b>statesman</b> as well as messenger.'),
]

# ==================================================================  PHASE 4 — THE STRUGGLE
PHASE_STRUGGLE = [
    E('badr', '624 CE', 'The Battle of Badr', ['BATTLE', 'TRIUMPH'],
      'War comes with Mecca. At Badr in 624 a small Muslim force of about three hundred meets a much larger Meccan army and wins a decisive, unexpected victory. For the young community the triumph is read as divine vindication, and it establishes Medina as a power the Quraysh must reckon with.',
      svg_row('An outnumbered victory', [
          {'n': 1, 'label': 'A Meccan army marches', 'sub': 'a larger Quraysh force, roughly a thousand', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Some 300 Muslims at Badr', 'sub': 'the outnumbered community stands, 624', 'color': '#0a7d3c'},
          {'n': 3, 'label': 'A decisive victory', 'sub': 'understood as divine vindication', 'color': '#a16207'},
      ], edge_labels=['met by', 'yields'], takeaway='Against the odds the Muslims won at Badr — a victory that steeled the community and its faith.', accent=AC),
      bg='Conflict with Mecca escalated after the Hijra, with raids and rising hostility between the two cities.',
      people='the Muslim fighters under <b>Muhammad</b>; the <b>Quraysh</b> army of Mecca; the companions who fought at Badr, long honoured in tradition.',
      what='At the wells of <b>Badr</b> in 624 CE, a Muslim force of roughly <b>three hundred</b> defeated a substantially larger Meccan army. The unexpected victory was understood by the community as a sign of God’s favour.',
      crux='Winning while heavily <b>outnumbered</b> gave the community confidence, prestige, and a conviction that God was with them.',
      conseq='The defeat enraged the Quraysh, who returned the next year to avenge it.',
      matters='Badr is remembered as a defining early triumph of Islam — proof, to the believers, that faith could prevail against the odds.'),

    E('uhud', '625 CE', 'The Battle of Uhud — a costly setback', ['BATTLE', 'TRAGEDY'],
      'The Quraysh return in 625 to avenge Badr, meeting the Muslims at Mount Uhud near Medina. When some fighters abandon their post to seize the spoils, the Meccan cavalry counterattacks; the Muslims are badly bloodied and Muhammad himself is wounded. The reverse is a hard lesson in discipline, but Medina survives.',
      svg_stack('Victory lost to indiscipline', [
          {'n': 1, 'label': 'Quraysh return for revenge, 625', 'sub': 'a large army marches on Medina', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A post abandoned for spoils', 'sub': 'archers leave their position; the cavalry strikes', 'color': '#78716c'},
          {'n': 3, 'label': 'A costly reverse — but survival', 'sub': 'the Muslims bloodied, Muhammad wounded; Medina holds', 'color': '#a16207'},
      ], takeaway='Uhud turned near-victory into a bloody setback — a hard lesson in discipline that the community nonetheless survived.', accent=AC),
      bg='Determined to avenge Badr, the Meccans marched on Medina the following year.',
      people='the <b>Quraysh</b> army and its cavalry, led by <b>Khalid ibn al-Walid</b> (then still an opponent); the Muslim defenders; <b>Muhammad</b>, wounded in the fighting.',
      what='At <b>Uhud</b> in 625 CE the Muslims initially held, but when archers left their assigned position to collect spoils, the Meccan <b>cavalry</b> counterattacked and inflicted heavy losses; Muhammad was wounded. The Meccans withdrew without taking Medina.',
      crux='Disobedience in the field turned a likely victory into a painful defeat — a lesson the tradition draws on <b>discipline and obedience</b>.',
      conseq='Emboldened, the Quraysh would return a third time to try to destroy Medina outright.',
      matters='Uhud is remembered as a sobering counterpoint to Badr — showing that faith did not exempt the community from the consequences of error.'),

    E('trench', '627 CE', 'The Battle of the Trench', ['BATTLE', 'TURNING POINT'],
      'In 627 a great Quraysh-led confederacy besieges Medina, hoping to finish the community for good. On advice, the Muslims dig a trench to block the cavalry — a tactic new to Arabian warfare. The siege stalls and fails, the confederacy breaks up, and Mecca’s last great offensive is turned back.',
      svg_stack('A siege defeated by a ditch', [
          {'n': 1, 'label': 'A great confederacy besieges Medina, 627', 'sub': 'the Quraysh and allied tribes mass to destroy it', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The Muslims dig a trench', 'sub': 'a ditch blocks the cavalry — new to Arabia', 'color': '#0a7d3c'},
          {'n': 3, 'label': 'The siege collapses', 'sub': 'the coalition loses heart and withdraws', 'color': '#a16207'},
      ], takeaway='A defensive trench broke the greatest assault on Medina — and with it Mecca’s hope of destroying the community.', accent=AC),
      bg='The Quraysh assembled a broad coalition of tribes for a decisive blow against Medina.',
      people='the besieging <b>confederacy</b>; <b>Muhammad</b> and the defenders; <b>Salman the Persian</b>, credited in tradition with proposing the trench.',
      what='In 627 CE a large confederate army besieged Medina. On the counsel to dig a defensive <b>trench</b> — a tactic unfamiliar in Arabia — the Muslims blocked the enemy cavalry. Unable to cross, and weakened by discord and weather, the coalition dispersed.',
      crux='An unconventional defence neutralised the enemy’s advantage in cavalry and numbers, turning back the largest threat Medina had faced.',
      conseq='With Mecca’s offensive spent, the initiative passed to Muhammad and the Muslims.',
      matters='The Trench marked the turning of the tide — after it, the momentum in the struggle with Mecca shifted decisively toward Medina.'),
]

# ==================================================================  PHASE 5 — TRIUMPH AND FAREWELL
PHASE_TRIUMPH = [
    E('hudaybiyya', '628 CE', 'The Treaty of Hudaybiyya', ['POLITICS', 'TURNING POINT'],
      'Setting out for the pilgrimage in 628, the Muslims are stopped short of Mecca and negotiate the Treaty of Hudaybiyya, a ten-year truce. Its terms seem a humiliating concession, and some followers are dismayed — yet the peace lets the faith spread rapidly, and within two years the truce collapses to Muhammad’s advantage.',
      svg_compare('A setback that became a triumph',
          {'head': 'How it seemed — a defeat', 'color': '#b45309',
           'items': ['turned back short of the pilgrimage', 'a truce on seemingly one-sided terms', 'some companions dismayed and angered']},
          {'head': 'What it became — a victory', 'color': '#166534',
           'items': ['a ten-year peace with the Quraysh', 'Islam spreads rapidly in the calm', 'the truce soon breaks in Muhammad’s favour']},
          verdict='A bitter-seeming truce opened the way to the peaceful spread of the faith, and soon to Mecca itself.',
          takeaway='Hudaybiyya looked like a concession but proved a decisive opening — peace did what battle could not.', accent=AC),
      bg='In 628 Muhammad led followers toward Mecca to perform the pilgrimage; the Quraysh barred their way at <b>Hudaybiyya</b>.',
      people='the <b>Quraysh</b> negotiators; <b>Muhammad</b>; the companions, some of whom bridled at the terms.',
      what='At <b>Hudaybiyya</b> in 628 CE, blocked from the pilgrimage, Muhammad concluded a <b>ten-year truce</b> with the Quraysh on terms that struck many followers as a humiliating concession. In practice the peace let Islam spread widely; when the truce was later broken, the advantage lay with Muhammad.',
      crux='Accepting apparent humiliation for peace bought the conditions in which the movement grew fastest — <b>patience over pride</b>.',
      conseq='When the Quraysh violated the truce, Muhammad marched on Mecca itself.',
      matters='Hudaybiyya is remembered in the tradition as a “clear victory” — a lesson that a patient peace can achieve more than a battle.'),

    E('mecca', '630 CE', 'The conquest of Mecca and the cleansing of the Kaaba', ['TRIUMPH', 'TURNING POINT'],
      'After the Quraysh break the truce, Muhammad marches on Mecca in 630 with a large force, and the city surrenders almost without bloodshed. He grants a general amnesty to his former persecutors, then cleanses the Kaaba of its idols, rededicating the ancient sanctuary to the worship of the one God.',
      svg_stack('The city won, the sanctuary purified', [
          {'n': 1, 'label': 'March on Mecca, 630', 'sub': 'the truce broken; the city surrenders', 'color': '#0a7d3c'},
          {'n': 2, 'label': 'A general amnesty', 'sub': 'former enemies spared, not put to the sword', 'color': '#a16207'},
          {'n': 3, 'label': 'The Kaaba cleansed of idols', 'sub': 'the sanctuary rededicated to the one God', 'color': '#0369a1'},
      ], takeaway='Mecca fell almost bloodlessly; mercy to his enemies and the cleansing of the Kaaba crowned his mission.', accent=AC),
      bg='The Quraysh broke the Hudaybiyya truce, giving Muhammad cause to move against Mecca.',
      people='the <b>Quraysh</b> of Mecca, now largely submitting; the Muslim army; the Meccans granted <b>amnesty</b>.',
      what='In 630 CE Muhammad led a large force to <b>Mecca</b>, which surrendered with little resistance. He proclaimed a <b>general amnesty</b> rather than taking revenge, and cleansed the <b>Kaaba</b> of its idols, rededicating it to the worship of God alone.',
      crux='<b>Clemency</b> toward former persecutors won over the city, while purifying the Kaaba turned Mecca’s central shrine to the new faith.',
      conseq='With Mecca won, most of Arabia’s tribes came into Islam over the following years.',
      matters='The near-bloodless conquest and the amnesty are remembered as a model of magnanimity, and the cleansing of the Kaaba restored it, in Muslim belief, to the pure monotheism of Abraham.'),

    E('farewell', '632 CE', 'The Farewell Sermon and his death', ['DEATH', 'TRIUMPH'],
      'In 632 Muhammad leads the pilgrimage to Mecca a final time and delivers the Farewell Sermon, summing up his teaching — the brotherhood and equality of believers, the sanctity of life and property, and the duties of the faith. Shortly after returning to Medina he falls ill and dies, leaving behind a united Arabia and, for Muslims, a completed message.',
      svg_stack('A message completed', [
          {'n': 1, 'label': 'The Farewell Pilgrimage, 632', 'sub': 'his final pilgrimage to Mecca', 'color': '#0a7d3c'},
          {'n': 2, 'label': 'The Farewell Sermon', 'sub': 'equality of believers; sanctity of life; the duties of faith', 'color': '#a16207'},
          {'n': 3, 'label': 'Death in Medina, 632', 'sub': 'he dies after a brief illness', 'color': '#374151'},
      ], takeaway='His farewell words distilled the faith; his death left a united Arabia and, for Muslims, a completed revelation.', accent=AC),
      bg='By 632 much of Arabia had accepted Islam, and Muhammad returned to Mecca for the pilgrimage a final time.',
      people='the assembled <b>pilgrims</b> who heard the sermon; <b>Abu Bakr</b>, who would succeed him as the first caliph; the community he left behind.',
      what='On the <b>Farewell Pilgrimage</b> in 632 CE, Muhammad delivered the <b>Farewell Sermon</b>, restating the core of his message — the equality and brotherhood of believers, the sanctity of life and property, and the obligations of the faith. Soon after, he fell ill and died in <b>Medina</b>.',
      crux='The sermon served as a summation of his teaching, and his death closed the age of revelation, leaving the <b>Quran</b> and his example as the community’s guide.',
      conseq='Leadership passed to <b>Abu Bakr</b> as caliph, and within a century the faith spread across three continents.',
      matters='Muhammad died having united much of Arabia under one faith; for Muslims, his life and the Quran revealed through him remain the enduring foundation of Islam.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Muhammad (c. 570–632 CE) is revered by Muslims as the final prophet of God and is the founder of Islam. Born an orphan in Mecca and known in youth as <b>al-Amin</b>, “the trustworthy,” he received — in the Islamic account — the first revelation of the Quran in the cave of Hira around 610, and began to call his people from the worship of many idols to the one God. Persecuted by the Quraysh, he led the <b>Hijra</b> to Medina in 622, where he built the first Muslim community, the <b>umma</b>. Through struggle and, finally, the peaceful conquest of Mecca, he united much of Arabia under a single faith before his death in 632. This guide presents both the <b>Islamic tradition’s account</b> and the historical context with respect, noting evenly where tradition and modern scholarship differ.</p>
<div class="ov-quote">“All mankind is from Adam and Eve; none has superiority over another except by piety and good action.”<span>— from the Farewell Sermon, as preserved in the Islamic tradition</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">An orphan of Mecca earns a name for honesty → in the Islamic account receives the first revelation of the Quran at Hira → preaches the one God and is persecuted by the Quraysh → leads the Hijra to Medina and builds the umma → survives the battles of Badr, Uhud and the Trench → wins a truce at Hudaybiyya, then Mecca itself, cleansing the Kaaba → and delivers the Farewell Sermon before his death in 632.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">☪️</div><h4>The message of one God</h4><p>Proclaimed an uncompromising monotheism, with the Quran as its central revelation.</p></div>
  <div class="ov-card"><div class="i">🕌</div><h4>The umma</h4><p>Founded a community of faith above tribe — a model that reshaped Arabia and beyond.</p></div>
  <div class="ov-card"><div class="i">📜</div><h4>Prophet and statesman</h4><p>Lawgiver, arbiter and leader, from the Constitution of Medina to the conquest of Mecca.</p></div>
  <div class="ov-card"><div class="i">🌍</div><h4>A world faith</h4><p>The faith he founded would within a century reach across three continents.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Orphan of Mecca</b><small> c. 570–610</small><p>An orphan of the Quraysh becomes al-Amin, the trustworthy.</p></div>
  <div><b>2 · The Revelation</b><small> 610–622</small><p>Hira, the one God, and persecution.</p></div>
  <div><b>3 · The Hijra</b><small> 622</small><p>Medina, the umma, and the Constitution.</p></div>
  <div><b>4 · The Struggle</b><small> 624–627</small><p>Badr, Uhud and the Trench.</p></div>
  <div><b>5 · Triumph &amp; Farewell</b><small> 628–632</small><p>Hudaybiyya, Mecca, and the Farewell Sermon.</p></div>
</div>
<div class="ov-lbl">A note on approach</div>
<p class="ov-lead" style="font-size:15px">This guide is written with reverence. In keeping with Islamic tradition it contains <b>no figurative depiction of the Prophet</b> — its diagrams are purely abstract concept maps of ideas and events. Where the tradition’s account and historical scholarship differ, both are noted evenly, without adjudicating between them.</p>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Khadija bint Khuwaylid', 'role': 'first wife & first believer', 'color': '#be185d',
     'bio': 'The respected Meccan widow and merchant who employed Muhammad, then married him; she was the first to accept his message and his steadfast support through the early years.',
     'rel': 'His wife and the first person to believe in his prophethood.'},
    {'name': 'Abu Talib', 'role': 'uncle & protector', 'color': '#a16207',
     'bio': 'The chief of the Hashim clan who raised the orphaned Muhammad and shielded him from the Quraysh; while he lived, his enemies could not easily strike.',
     'rel': 'The uncle who raised and protected him for decades.'},
    {'name': 'Abu Bakr', 'role': 'closest companion', 'color': '#3730a3',
     'bio': 'An early convert and Muhammad’s closest companion, who shared the Hijra with him and, after his death, became the first caliph of the Muslim community.',
     'rel': 'His closest companion and first successor as caliph.'},
    {'name': 'Ali ibn Abi Talib', 'role': 'cousin & son-in-law', 'color': '#7c3aed',
     'bio': 'Muhammad’s young cousin, among the first to believe, who married his daughter Fatima and later became the fourth caliph — a figure of central importance in Islamic tradition.',
     'rel': 'His cousin, son-in-law, and one of the earliest believers.'},
    {'name': 'The angel Gabriel (Jibril)', 'role': 'bearer of revelation', 'color': '#0369a1',
     'bio': 'In Islamic belief, the angel through whom the revelations of the Quran were conveyed to Muhammad, beginning in the cave of Hira with the command to “Recite.”',
     'rel': 'In Islamic belief, the angel who brought him the revelation of the Quran.'},
]

KEY_EVENTS = [
    ('c. 570', 'Born in Mecca', 'Orphaned young; raised by his kin.'),
    ('c. 595', 'Marries Khadija', 'Al-Amin, the trustworthy merchant.'),
    ('610', 'First revelation at Hira', 'Prophethood begins; the Quran.'),
    ('613', 'Public preaching', 'Calls Mecca to the one God.'),
    ('622', 'The Hijra to Medina', 'Year 1 of the Islamic calendar.'),
    ('624', 'Battle of Badr', 'An outnumbered victory over Mecca.'),
    ('627', 'Battle of the Trench', 'Mecca’s great siege turned back.'),
    ('628', 'Treaty of Hudaybiyya', 'A truce that opens the way.'),
    ('630', 'Conquest of Mecca', 'The Kaaba cleansed of idols.'),
    ('632', 'Farewell Sermon & death', 'A united Arabia; the message complete.'),
]

MASTER = [
    {'year': 'c. 570', 'age': 'born', 'phase': 'Orphan of Mecca', 'title': 'Born in Mecca', 'desc': 'Orphaned young among the Quraysh.'},
    {'year': '610', 'age': 'age ~40', 'phase': 'The Revelation', 'title': 'First revelation at Hira', 'desc': 'Prophethood and the Quran begin.'},
    {'year': '622', 'age': 'age ~52', 'phase': 'The Hijra', 'title': 'Migration to Medina', 'desc': 'The umma and the Islamic calendar.'},
    {'year': '624', 'age': 'age ~54', 'phase': 'The Struggle', 'title': 'Battle of Badr', 'desc': 'An outnumbered victory over Mecca.'},
    {'year': '630', 'age': 'age ~60', 'phase': 'Triumph', 'title': 'Conquest of Mecca', 'desc': 'The Kaaba cleansed; amnesty granted.'},
    {'year': '632', 'age': 'age ~62', 'phase': 'The Farewell', 'title': 'Farewell Sermon & death', 'desc': 'A united Arabia; the message complete.'},
]

SOURCES = [
    ('Britannica — Muhammad', 'https://www.britannica.com/biography/Muhammad'),
    ('World History Encyclopedia — Prophet Muhammad', 'https://www.worldhistory.org/Prophet_Muhammad/'),
    ('Britannica — Hijrah', 'https://www.britannica.com/event/Hijrah-Islam'),
    ('Britannica — Islam', 'https://www.britannica.com/topic/Islam'),
    ('Wikipedia — Muhammad', 'https://en.wikipedia.org/wiki/Muhammad'),
]

def build_meta():
    return {
        'pid': 'gm-muhammad.html', 'kind': 'man', 'emoji': '☪️', 'accent': AC,
        'name': 'Muhammad', 'years': 'c. 570–632', 'group': 'Religious Founders',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Prophet of Islam — revered by Muslims as the final messenger of God — who proclaimed the worship of the one God in Mecca, led the Hijra to Medina, and united Arabia under a single faith, through whom Muslims believe the Quran was revealed.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'orphan', 'label': '1 · The Orphan of Mecca', 'type': 'timeline',
             'intro': 'Born around 570 into the Quraysh of Mecca and orphaned young, he is raised by his grandfather and then his uncle, and grows into a merchant famed for honesty — al-Amin, the trustworthy.', 'events': PHASE_ORPHAN},
            {'id': 'revelation', 'label': '2 · The Revelation', 'type': 'timeline',
             'intro': 'In the cave of Hira the Islamic tradition places the first revelation of the Quran; he begins to preach the one God, and the Quraysh turn against him and his small band of believers.', 'events': PHASE_REVELATION},
            {'id': 'hijra', 'label': '3 · The Hijra', 'type': 'timeline',
             'intro': 'The migration to Medina in 622 begins the Islamic calendar; there he forges the umma, builds the Prophet’s Mosque, and binds a divided city together under the Constitution of Medina.', 'events': PHASE_HIJRA},
            {'id': 'struggle', 'label': '4 · The Struggle', 'type': 'timeline',
             'intro': 'War with Mecca brings the outnumbered victory of Badr, the costly reverse at Uhud, and the great siege turned back at the Trench — the tide slowly shifting toward Medina.', 'events': PHASE_STRUGGLE},
            {'id': 'triumph', 'label': '5 · Triumph & Farewell', 'type': 'timeline',
             'intro': 'A truce at Hudaybiyya opens the way; Mecca falls almost without bloodshed and the Kaaba is cleansed of idols; and with the Farewell Sermon his message is complete before his death in 632.', 'events': PHASE_TRIUMPH,
             'sources': SOURCES, 'srcnote': 'Drawn from standard encyclopaedic and scholarly sources alongside the Islamic biographical tradition (the sira and hadith). Where the tradition’s account and modern historical scholarship differ, this guide notes both without adjudicating between them, and treats the Quran and the memory of the Prophet with respect.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
