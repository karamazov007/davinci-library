# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Shah Jahan.
The Mughal emperor of the golden age of architecture — builder of the Taj Mahal — whose splendour and ruinous cost ran side by side."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#0f766e'  # Mughal jade-teal

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — PRINCE KHURRAM
PHASE_PRINCE = [
    E('khurram', '1592–1605', 'Born Khurram — Akbar’s cherished grandson', ['RISE'],
      'Born at Lahore in 1592 as Prince Khurram, third son of the future emperor Jahangir, the boy is taken to be raised by his grandfather Akbar the Great, who dotes on him and grooms him — a favourite grandson steeped from birth in the wealth and majesty of the Mughal court at its very zenith.',
      svg_row('A prince groomed at the Mughal zenith', [
          {'n': 1, 'label': 'Born Khurram, Lahore 1592', 'sub': 'third son of Prince Salim (Jahangir)', 'color': '#0f766e'},
          {'n': 2, 'label': 'Raised by Akbar the Great', 'sub': 'the emperor dotes on the boy', 'color': '#a16207'},
          {'n': 3, 'label': 'Groomed for greatness', 'sub': 'steeped in the court at its height', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='The favourite grandson of the greatest Mughal grew up inside the richest court on earth — majesty was his birthright.', accent=AC),
      bg='<b>Khurram</b> was born in 1592 at Lahore, the third son of Prince Salim — the future emperor <b>Jahangir</b> — and grandson of <b>Akbar the Great</b>, whose empire was then the mightiest in the world.',
      people='<b>Akbar</b>, his doting grandfather; <b>Jahangir</b>, his father; <b>Ruqaiya Sultan Begum</b>, Akbar’s chief wife, who raised the boy.',
      what='Akbar, delighted with the child, had Khurram <b>raised in his own household</b> and lavished attention on him, immersing the prince in statecraft, war and the arts at the peak of Mughal power.',
      crux='He was formed as a <b>favoured insider</b> of the imperial court — never an outsider clawing his way up, but a prince bred to rule and to build.',
      conseq='The refined, ambitious tastes planted in his youth would flower into the most magnificent building programme in Mughal history.',
      matters='Genius is nurtured as well as born — the boy steeped in Akbar’s golden court became the emperor of the golden age.'),

    E('warriorprince', '1607–1617', 'The warrior prince and the title Shah Jahan', ['RISE', 'BATTLE', 'LOVE'],
      'Khurram proves himself the ablest of Jahangir’s sons — betrothed in 1607 and married in 1612 to Arjumand Banu, whom he adores and names Mumtaz Mahal — and wins brilliant victories in the Deccan and against Mewar, earning from his father in 1617 the exalted title Shah Jahan, “King of the World.”',
      svg_stack('Proving himself the ablest son', [
          {'n': 1, 'label': 'Marries Arjumand Banu, 1612', 'sub': 'his beloved, renamed Mumtaz Mahal', 'color': '#0f766e'},
          {'n': 2, 'label': 'Victories in the Deccan & Mewar', 'sub': 'the empire’s ablest general', 'color': '#a16207'},
          {'n': 3, 'label': 'Titled Shah Jahan, 1617', 'sub': '“King of the World”', 'color': '#166534'},
      ], takeaway='He earned his throne-name in the field and found his life’s love at court — the warrior and the devoted husband in one.', accent=AC),
      bg='As Jahangir’s reign unfolded, Khurram emerged as the most capable of the royal princes, trusted with the empire’s hardest campaigns.',
      people='<b>Arjumand Banu (Mumtaz Mahal)</b>, his adored wife; <b>Jahangir</b>, who honoured him; the sultans of the Deccan and the Rana of Mewar, his foes.',
      what='Khurram <b>married Arjumand Banu in 1612</b>, naming her <b>Mumtaz Mahal</b>, and won major victories subduing <b>Mewar and the Deccan sultanates</b>, for which Jahangir granted him the title <b>Shah Jahan (“King of the World”) in 1617</b>.',
      crux='He was both <b>soldier and aesthete</b>, and his marriage to Mumtaz became the great emotional centre of his life.',
      conseq='His success bred both his father’s favour and, later, dangerous suspicion — and his love for Mumtaz would one day raise the Taj Mahal.',
      matters='The two poles of his story appear here at once — the conquering prince and the devoted husband whose love outlived them both.'),

    E('rebellion', '1622–1626', 'Rebellion against his father', ['RISE', 'TRAGEDY', 'TURNING POINT'],
      'As Jahangir ages and the empress Nur Jahan schemes to advance her own favourite, Khurram — fearing he will be passed over — rises in open revolt against his father in 1622; the rebellion fails, and after years as a hunted fugitive across the empire he submits, surrendering his sons as hostages and biding his time.',
      svg_row('A son in revolt', [
          {'n': 1, 'label': 'Nur Jahan’s faction rises', 'sub': 'the empress backs a rival prince', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Khurram rebels, 1622', 'sub': 'open revolt against Jahangir', 'color': '#0f766e'},
          {'n': 3, 'label': 'Defeated, then submits', 'sub': 'a fugitive who surrenders and waits', 'color': '#78350f'},
      ], edge_labels=['so', 'but'], takeaway='He gambled everything against his father and lost — then swallowed his pride and waited for the throne to fall to him instead.', accent=AC),
      bg='The powerful empress <b>Nur Jahan</b> sought to secure the succession for her son-in-law Shahryar, sidelining the ambitious Khurram.',
      people='<b>Jahangir</b>, his father and emperor; <b>Nur Jahan</b>, the scheming empress; <b>Asaf Khan</b>, Mumtaz’s father and Khurram’s ally; the loyalist general Mahabat Khan.',
      what='Fearing disinheritance, Khurram <b>rose in revolt against Jahangir in 1622</b>. Defeated in battle, he wandered as a fugitive across the Deccan and Bengal before <b>submitting in 1626</b>, handing over two sons as hostages.',
      crux='He learned that <b>a premature grab for power invites ruin</b> — that patience, not open defiance, would win him the crown.',
      conseq='His submission kept him alive; when Jahangir died soon after, Khurram was poised — with Asaf Khan’s help — to seize the throne.',
      matters='Ambition must be married to timing — the rebel who failed by moving too soon triumphed by learning to wait.'),
]

# ==================================================================  PHASE 2 — THE THRONE
PHASE_THRONE = [
    E('succession', '1627', 'The race for the throne', ['POLITICS', 'TURNING POINT'],
      'When Jahangir dies in 1627, Khurram is far off in the Deccan; with the help of his father-in-law Asaf Khan he races north, outmanoeuvres the empress Nur Jahan and her puppet claimant Dawar Bakhsh, and clears his path to the throne by the ruthless elimination of rival princes.',
      svg_stack('A dash for the crown', [
          {'n': 1, 'label': 'Jahangir dies, 1627', 'sub': 'Khurram far away in the Deccan', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Asaf Khan secures the way', 'sub': 'outmanoeuvres Nur Jahan’s faction', 'color': '#0f766e'},
          {'n': 3, 'label': 'Rivals eliminated', 'sub': 'the path to the throne cleared', 'color': '#78350f'},
      ], takeaway='He won the throne by speed and ruthlessness — allies moving fast while rival princes were swept aside.', accent=AC),
      bg='<b>Jahangir died in October 1627</b> while Khurram commanded in the Deccan, hundreds of miles from the capital and the levers of power.',
      people='<b>Asaf Khan</b>, his father-in-law and kingmaker; <b>Nur Jahan</b>, outmanoeuvred at last; the stopgap claimant <b>Dawar Bakhsh</b>; the rival princes.',
      what='Asaf Khan held the capital and neutralised Nur Jahan while Khurram <b>marched north</b>. To secure his claim, the surviving male rivals of the dynasty were <b>put to death</b>, a customary Mughal ruthlessness in succession.',
      crux='The Mughal throne passed not by law but by <b>whoever could seize and hold it</b> — and Khurram, well-placed and well-allied, prevailed.',
      conseq='The path was clear for his coronation as emperor in 1628, at the head of an intact and immensely rich empire.',
      matters='In a dynasty without fixed succession, power went to the boldest — and the price of the throne was paid in the blood of kinsmen.'),

    E('accession', '1628', 'Crowned Shah Jahan', ['TRIUMPH', 'POLITICS'],
      'In 1628 Khurram is crowned at Agra as the fifth Mughal emperor, taking the throne-name Shah Jahan; he inherits the richest and most powerful state in the world and sets out to make his reign its most magnificent — an age of gold, marble and unrivalled imperial splendour.',
      svg_row('The fifth Mughal emperor', [
          {'n': 1, 'label': 'Crowned at Agra, 1628', 'sub': 'takes the name Shah Jahan', 'color': '#0f766e'},
          {'n': 2, 'label': 'Inherits a colossal empire', 'sub': 'the richest state on earth', 'color': '#a16207'},
          {'n': 3, 'label': 'An age of splendour begins', 'sub': 'gold, marble and majesty', 'color': '#166534'},
      ], edge_labels=['and', 'so'], takeaway='He took the throne of the wealthiest empire alive — and resolved to make its magnificence eternal in stone.', accent=AC),
      bg='In <b>1628</b> Khurram was enthroned at Agra as <b>Shah Jahan</b>, the fifth ruler of an empire spanning most of the Indian subcontinent.',
      people='the assembled Mughal nobility; <b>Mumtaz Mahal</b>, now his empress; <b>Asaf Khan</b>, raised to the highest office.',
      what='Shah Jahan inherited a treasury and a realm of <b>staggering wealth</b>, and deliberately cultivated a court of unmatched ceremony, luxury and artistic ambition — the flowering of the <b>Mughal golden age</b>.',
      crux='He conceived of empire as <b>magnificence made visible</b> — power expressed through architecture, jewels and courtly grandeur.',
      conseq='That vision produced the Taj Mahal, Shahjahanabad and the Peacock Throne — and a steadily mounting strain on the empire’s finances.',
      matters='An age is defined by what its ruler values — Shah Jahan valued beauty and majesty, and left the world its most beautiful buildings.'),

    E('consolidation', '1628–1632', 'Securing the empire', ['POLITICS', 'BATTLE'],
      'Shah Jahan swiftly stamps his authority on the empire — crushing the revolt of the Afghan noble Khan Jahan Lodi, storming the Portuguese trading settlement at Hooghly in 1632, and imposing a stricter Islamic tone at court — proving that the aesthete emperor is also a hard and capable ruler.',
      svg_stack('The aesthete who could strike hard', [
          {'n': 1, 'label': 'Crushes Khan Jahan Lodi', 'sub': 'a rebel Afghan noble destroyed', 'color': '#0f766e'},
          {'n': 2, 'label': 'Storms Portuguese Hooghly, 1632', 'sub': 'the Bengal trading post taken', 'color': '#a16207'},
          {'n': 3, 'label': 'Authority firmly imposed', 'sub': 'a hard ruler behind the splendour', 'color': '#166534'},
      ], takeaway='Behind the patron of marble stood a firm and sometimes harsh sovereign — beauty and force were both his instruments.', accent=AC),
      bg='A new reign always faced revolt; Shah Jahan moved early to assert control and to signal a more orthodox tone than his father’s.',
      people='the rebel <b>Khan Jahan Lodi</b>; the <b>Portuguese</b> merchants of Hooghly; the orthodox ulama he cultivated.',
      what='He <b>defeated Khan Jahan Lodi’s rebellion</b>, <b>stormed the Portuguese settlement at Hooghly in 1632</b> for its abuses, and adopted a more austere Islamic public policy — dismantling some Hindu temples built under his predecessors.',
      crux='He balanced the <b>patron of the arts</b> with the <b>enforcer of imperial authority</b> — magnificence resting on a foundation of firm, at times ruthless, control.',
      conseq='With the empire secured, he could turn his energies to war in the Deccan and to the great building projects that define his name.',
      matters='Splendour needs a spine of iron — the emperor of marble palaces first proved he could hold his empire by force.'),
]

# ==================================================================  PHASE 3 — THE GOLDEN AGE OF ARCHITECTURE
PHASE_GOLDEN = [
    E('taj', '1631–1653', 'Mumtaz Mahal and the Taj Mahal', ['TRAGEDY', 'TRIUMPH', 'LOVE'],
      'In 1631 Mumtaz Mahal dies at Burhanpur giving birth to their fourteenth child; the grief-stricken emperor pours his loss into the Taj Mahal — a tomb of white marble raised beside the Yamuna at Agra between 1632 and 1653 under the architect Ustad Ahmad Lahauri — the supreme monument of Mughal art and the world’s greatest testament of love.',
      svg_row('Grief turned to marble', [
          {'n': 1, 'label': 'Mumtaz dies, 1631', 'sub': 'in childbirth at Burhanpur', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The Taj Mahal, 1632–53', 'sub': 'white marble tomb on the Yamuna', 'color': '#0f766e'},
          {'n': 3, 'label': 'A monument to love', 'sub': 'built by Ustad Ahmad Lahauri', 'color': '#a16207'},
      ], edge_labels=['so', 'becomes'], takeaway='The deepest grief of his life became the most beautiful building in the world — love made eternal in stone.', accent=AC),
      bg='<b>Mumtaz Mahal</b>, his empress and closest companion, died on <b>7 June 1631</b> at Burhanpur while giving birth to their fourteenth child.',
      people='<b>Mumtaz Mahal</b>, the beloved dead; <b>Ustad Ahmad Lahauri</b>, the chief architect; the tens of thousands of craftsmen and labourers.',
      what='Shattered by grief, Shah Jahan ordered the <b>Taj Mahal</b> — a domed white-marble mausoleum inlaid with precious stones, set in a formal garden on the Yamuna at Agra, built <b>from 1632 to about 1653</b> at colossal expense.',
      crux='He transmuted <b>private grief into public immortality</b> — a tomb so perfect it became the emblem of an entire civilisation.',
      conseq='The Taj crowned the Mughal golden age of architecture — but its cost, in money and labour, was immense, one strain among many on the treasury.',
      matters='The Taj Mahal endures as the world’s supreme monument to love and loss — proof that beauty born of sorrow can outlast empires.'),

    E('shahjahanabad', '1638–1656', 'Shahjahanabad — the Red Fort and Jama Masjid', ['REFORM', 'TRIUMPH'],
      'Shah Jahan founds a new capital, Shahjahanabad, in Delhi — raising the vast Red Fort (Lal Qila, 1639–1648) as his palace-citadel and the towering Jama Masjid (1650–1656), the largest mosque in India — a walled city of red sandstone and marble that crowns the golden age of Mughal architecture.',
      svg_stack('A new imperial capital', [
          {'n': 1, 'label': 'Founds Shahjahanabad, Delhi', 'sub': 'a new walled capital, from 1638', 'color': '#0f766e'},
          {'n': 2, 'label': 'The Red Fort, 1639–48', 'sub': 'his palace-citadel of red sandstone', 'color': '#a16207'},
          {'n': 3, 'label': 'The Jama Masjid, 1650–56', 'sub': 'the largest mosque in India', 'color': '#166534'},
      ], takeaway='He built not just a tomb but a whole capital — a city, a citadel and a great mosque that still crown Old Delhi.', accent=AC),
      bg='Seeking a grander seat than Agra, Shah Jahan laid out a new capital city at <b>Delhi</b>, named <b>Shahjahanabad</b> after himself.',
      people='the architects and masons of the imperial workshops; the citizens of the new capital; the courtiers housed within the fort.',
      what='He built the <b>Red Fort (Lal Qila)</b> as his palace-fortress between <b>1639 and 1648</b>, its halls set with the Peacock Throne, and the great <b>Jama Masjid</b> between <b>1650 and 1656</b> — India’s largest mosque — anchoring the walled city of Shahjahanabad.',
      crux='He expressed imperial power through <b>urban grandeur</b> — a purpose-built capital of sandstone and marble to house the throne of the world.',
      conseq='Shahjahanabad remained the Mughal capital and heart of Delhi for centuries, its monuments among the most visited in India today.',
      matters='Great rulers build cities, not just buildings — Shah Jahan’s Delhi still stands as the physical shape of Mughal ambition.'),

    E('peacockthrone', '1635', 'The Peacock Throne — splendour and its cost', ['POLITICS', 'TRAGEDY'],
      'After seven years’ work the jewelled Peacock Throne is unveiled in 1635 — encrusted with diamonds, rubies and emeralds, including the Koh-i-Noor and the Timur ruby — the dazzling symbol of an empire of unmatched wealth; yet the marble, the jewels and the endless campaigns drained the treasury and rested on the taxed labour of millions of peasants.',
      svg_compare('Splendour and its price',
          {'head': 'The splendour', 'color': '#a16207', 'items': [
              'Peacock Throne unveiled 1635',
              'Diamonds, rubies and emeralds',
              'Set with the Koh-i-Noor and Timur ruby',
              'The symbol of boundless wealth']},
          {'head': 'The price', 'color': '#b91c1c', 'items': [
              'Treasury drained by marble and war',
              'Ever-heavier land revenue demands',
              'Borne by millions of peasants',
              'Magnificence built on their toil']},
          verdict='An empire of dazzling wealth, sustained by the taxed labour of the people who never saw its jewels.',
          takeaway='The Peacock Throne blazed with the empire’s riches — but that glitter was wrung from the fields, and the cost mounted unseen.', accent=AC),
      bg='At his accession Shah Jahan commissioned a throne worthy of his majesty; after about seven years it was completed as the <b>Peacock Throne</b>.',
      people='the imperial jewellers and goldsmiths; the peasantry whose land revenue funded the court; later plunderers who would carry the throne away.',
      what='The <b>Peacock Throne (Takht-i-Taus)</b>, unveiled around <b>1635</b>, was encrusted with fabulous gems including the <b>Koh-i-Noor</b> and the <b>Timur ruby</b> — but the reign’s marble, jewels and wars pressed ever-heavier <b>taxes on the peasantry</b>.',
      crux='His reign was <b>magnificence and burden inseparably joined</b> — the golden age of the court was an age of rising exaction for those who paid for it.',
      conseq='The strain fed rural distress and famine, and left a treasury less resilient than its glitter suggested; the throne itself was looted by Nadir Shah in 1739.',
      matters='Splendour has a bill — the golden age dazzles in hindsight, but it was financed by the labour and hardship of the many.'),
]

# ==================================================================  PHASE 4 — THE SWORD AND ITS COST
PHASE_SWORD = [
    E('deccan', '1633–1636', 'The Deccan brought to heel', ['BATTLE', 'POLITICS'],
      'Shah Jahan renews the drive into the Deccan — extinguishing the Ahmadnagar sultanate in 1636 and forcing Bijapur and Golconda to submit as tributaries — appointing his son Aurangzeb as viceroy of the south and pushing Mughal power to its greatest southern extent.',
      svg_row('Mughal power reaches south', [
          {'n': 1, 'label': 'Ahmadnagar extinguished, 1636', 'sub': 'the sultanate annexed', 'color': '#0f766e'},
          {'n': 2, 'label': 'Bijapur & Golconda submit', 'sub': 'forced into vassal treaties', 'color': '#a16207'},
          {'n': 3, 'label': 'Aurangzeb made viceroy', 'sub': 'the Deccan under Mughal sway', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He pushed the empire to its southern peak — and gave the young Aurangzeb the Deccan command that would shape the future.', accent=AC),
      bg='The rich sultanates of the Deccan had long resisted full Mughal control; Shah Jahan resolved to subdue them.',
      people='<b>Aurangzeb</b>, appointed viceroy of the Deccan; the sultans of <b>Bijapur and Golconda</b>; the Ahmadnagar minister-general.',
      what='By <b>1636</b> Shah Jahan had <b>annexed Ahmadnagar</b> and compelled <b>Bijapur and Golconda</b> into tributary submission, and installed his son <b>Aurangzeb as viceroy</b> of the newly dominant south.',
      crux='He extended the empire to its <b>widest southern reach</b> — but the endless Deccan wars would prove a bottomless drain on men and money.',
      conseq='Aurangzeb’s years governing the Deccan formed the hard, ambitious prince who would one day depose his father.',
      matters='Conquest can overreach — the southern expansion that marked the empire’s height also sowed the costs and rivalries that undid it.'),

    E('balkh', '1646–1647', 'The Balkh disaster', ['BATTLE', 'DEFEAT', 'TRAGEDY'],
      'Dreaming of recovering the Timurid ancestral homeland, Shah Jahan launches a vast campaign into Central Asia, seizing Balkh and Badakhshan in 1646; but a huge army, harried by fierce Uzbek raiders through a brutal Hindu Kush winter, cannot hold barren lands so far from India — the retreat of 1647 costs thousands of lives and a fortune, all for nothing.',
      svg_compare('The dream of the homeland, dashed',
          {'head': 'The ambition', 'color': '#a16207', 'items': [
              'Reclaim the Timurid homeland',
              'Balkh & Badakhshan seized, 1646',
              'A huge, richly-equipped army',
              'Prince Aurangzeb in command']},
          {'head': 'The catastrophe', 'color': '#b91c1c', 'items': [
              'Barren lands far beyond supply',
              'Relentless Uzbek raids',
              'A brutal Hindu Kush winter',
              'Retreat 1647; thousands dead, treasury drained']},
          verdict='Vast blood and treasure spent to seize lands that could never be held — the great vanity campaign of the reign.',
          takeaway='Ancestral nostalgia lured the empire into a ruinous adventure — a fortune and thousands of lives thrown away for barren ground.', accent=AC),
      bg='The Mughals traced their line to Timur and Central Asia; Shah Jahan dreamed of recovering the dynasty’s ancestral homeland around Samarkand.',
      people='<b>Aurangzeb</b> and Prince Murad, the commanders; the <b>Uzbek</b> tribes who harried the army; the soldiers who perished in the mountains.',
      what='In <b>1646</b> a great Mughal army occupied <b>Balkh and Badakhshan</b>, but found the lands poor, hostile and impossible to supply; the <b>1647 retreat</b> across the Hindu Kush destroyed much of the force and consumed an enormous sum.',
      crux='It was <b>ambition detached from reality</b> — a costly campaign driven by dynastic sentiment rather than strategic sense.',
      conseq='The failure exposed the limits of Mughal power beyond the mountains and marked the beginning of the reign’s costly overreach.',
      matters='Even the mightiest empire has limits — the Balkh disaster shows how prestige and nostalgia can bleed a state for nothing.'),

    E('kandahar', '1649–1653', 'The walls of Kandahar', ['BATTLE', 'DEFEAT'],
      'The fortress of Kandahar, gateway between India and Persia, falls to the Safavids in 1649; Shah Jahan hurls three great sieges against it over four years, sending Aurangzeb and then Dara Shikoh with huge armies and heavy guns — and each fails, draining the treasury further and exposing the limits of even Mughal might.',
      svg_stack('Three sieges, three failures', [
          {'n': 1, 'label': 'Persians take Kandahar, 1649', 'sub': 'the western gateway lost', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Three great sieges, 1649–53', 'sub': 'Aurangzeb, then Dara, hurled at its walls', 'color': '#0f766e'},
          {'n': 3, 'label': 'All three fail', 'sub': 'treasure spent, the fortress unrecovered', 'color': '#78350f'},
      ], takeaway='The empire battered a single fortress three times and could not take it — a costly lesson in the limits of Mughal power.', accent=AC),
      bg='<b>Kandahar</b>, the strategic fortress controlling the road between India and Persia, was seized by the <b>Safavids of Persia in 1649</b>.',
      people='<b>Aurangzeb</b> and <b>Dara Shikoh</b>, the rival princely commanders; the Persian defenders; the Mughal siege artillery.',
      what='Between <b>1649 and 1653</b> Shah Jahan launched <b>three massive sieges</b> to retake Kandahar, entrusting them to Aurangzeb and then Dara Shikoh — <b>every one failed</b>, at vast expense in men and money.',
      crux='He poured resources into a prize that lay <b>beyond the empire’s effective reach</b> — persistence became waste.',
      conseq='The repeated failures dented Mughal prestige, further strained the finances, and sharpened the rivalry between his sons.',
      matters='Knowing when to stop is a mark of statecraft — three failed sieges show the cost of chasing a prize you cannot hold.'),
]

# ==================================================================  PHASE 5 — THE FALL
PHASE_FALL = [
    E('warofsuccession', '1657–1658', 'The war of the sons', ['POLITICS', 'BATTLE', 'TRAGEDY'],
      'When Shah Jahan falls gravely ill in 1657, his four sons plunge the empire into civil war; the emperor favours his eldest, the liberal Dara Shikoh, but the austere and ruthless Aurangzeb crushes Dara at the Battle of Samugarh in 1658 and outmanoeuvres his other brothers to seize the throne.',
      svg_compare('Two visions fight for the throne',
          {'head': 'Dara Shikoh', 'color': '#0f766e', 'items': [
              'The emperor’s chosen heir',
              'Liberal, mystical, syncretic',
              'Backed by Shah Jahan',
              'Defeated at Samugarh, 1658']},
          {'head': 'Aurangzeb', 'color': '#78350f', 'items': [
              'The austere, orthodox prince',
              'Ruthless and calculating',
              'Wins the Battle of Samugarh',
              'Seizes the throne, 1658']},
          verdict='The ruthless younger son destroyed the favoured heir and took the empire — Dara was captured and executed.',
          takeaway='The succession pitted tolerance against orthodoxy — and the harder, colder brother won, changing the empire’s course.', accent=AC),
      bg='Shah Jahan’s <b>grave illness in 1657</b> triggered the customary Mughal war of succession among his four sons.',
      people='<b>Dara Shikoh</b>, the favoured eldest; <b>Aurangzeb</b>, the victor; <b>Shah Shuja</b> and <b>Murad Bakhsh</b>, the other contenders.',
      what='Against his father’s wishes, <b>Aurangzeb</b> allied with Murad, defeated <b>Dara Shikoh at the Battle of Samugarh in 1658</b>, and destroyed his brothers one by one — Dara was captured and <b>executed</b>.',
      crux='It was a clash of <b>two futures for the empire</b> — Dara’s tolerant syncretism against Aurangzeb’s stern orthodoxy — decided by the sword.',
      conseq='Aurangzeb’s victory set the empire on a harder, more orthodox path and left the aged Shah Jahan a prisoner of his own son.',
      matters='A dynasty without a rule of succession devours itself — the war of the sons shows power passing by fratricide, not law.'),

    E('imprisonment', '1658–1666', 'Deposed and imprisoned in Agra Fort', ['DEFEAT', 'TRAGEDY'],
      'Victorious, Aurangzeb declares his father unfit to rule and confines the still-living emperor in the Agra Fort; there Shah Jahan spends eight years a prisoner in gilded apartments, tended by his devoted daughter Jahanara, deposed by the son he never chose.',
      svg_stack('A living emperor, made a prisoner', [
          {'n': 1, 'label': 'Aurangzeb crowns himself, 1658', 'sub': 'declares his father unfit to rule', 'color': '#78350f'},
          {'n': 2, 'label': 'Confined in the Agra Fort', 'sub': 'a prisoner in his own palace', 'color': '#0f766e'},
          {'n': 3, 'label': 'Eight years of captivity', 'sub': 'tended by his daughter Jahanara', 'color': '#b91c1c'},
      ], takeaway='The builder of palaces ended a captive within one — deposed and confined by the son who out-fought all the rest.', accent=AC),
      bg='Having beaten his brothers, Aurangzeb had no wish to yield to his recovering father, whom he now held in his power.',
      people='<b>Aurangzeb</b>, the usurping son and new emperor; <b>Shah Jahan</b>, the deposed emperor; <b>Jahanara Begum</b>, his devoted daughter.',
      what='Aurangzeb <b>declared Shah Jahan incompetent</b> and placed him under <b>house arrest in the Agra Fort from 1658</b>, where the old emperor lived out <b>eight years</b> in comfortable but powerless confinement, nursed by his daughter Jahanara.',
      crux='He was <b>stripped of power yet kept alive</b> — a fallen sovereign left to contemplate his own monuments as a captive.',
      conseq='The golden age of the builder-emperor ended in impotence, while Aurangzeb’s long, austere reign reshaped the empire.',
      matters='The mightiest can be brought utterly low — the emperor of the world spent his last years a prisoner of his own child.'),

    E('death', '1666', 'Death gazing at the Taj', ['DEATH', 'TRAGEDY'],
      'Shah Jahan dies in the Agra Fort in January 1666, aged 74, having spent his last years gazing across the Yamuna at the Taj Mahal, the tomb of his beloved Mumtaz; he is buried there beside her, the builder of the world’s most beautiful monument laid to rest within it.',
      svg_row('The builder joins his monument', [
          {'n': 1, 'label': 'Dies in the Agra Fort, 1666', 'sub': 'aged 74, after eight years captive', 'color': '#0f766e'},
          {'n': 2, 'label': 'Last days facing the Taj', 'sub': 'gazing at Mumtaz’s tomb', 'color': '#a16207'},
          {'n': 3, 'label': 'Buried beside Mumtaz', 'sub': 'laid to rest within his masterpiece', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He ended his life gazing at the tomb his love had built — and was laid to rest inside it, beside her, at last.', accent=AC),
      bg='After eight years of captivity, the aged and ailing Shah Jahan approached the end of his life within the Agra Fort.',
      people='<b>Shah Jahan</b>, dying; <b>Jahanara</b>, at his side; <b>Mumtaz Mahal</b>, awaiting him in the Taj; <b>Aurangzeb</b>, the distant emperor.',
      what='Shah Jahan <b>died on 22 January 1666</b>, aged 74, reportedly with his gaze fixed on the <b>Taj Mahal</b> across the river; he was <b>buried within it, beside Mumtaz Mahal</b>, his cenotaph the only asymmetry in that perfect building.',
      crux='His story closed with a <b>fusion of love and loss</b> — the builder reunited in death with the wife whose memory he had immortalised.',
      conseq='He left the golden age of Mughal architecture as his monument, and a treasury and dynasty already strained by its cost.',
      matters='A life is judged by what it leaves — Shah Jahan bequeathed the Taj Mahal, a beauty so complete it redeems even a reign of ruinous cost.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Shah Jahan was the fifth Mughal emperor and the master of its golden age of architecture — the builder of the Taj Mahal. Born Prince Khurram, he clawed his way to the throne through rebellion, ruthlessness and a dash across an empire, then ruled the richest state on earth as a spectacle of gold, jewels and white marble. He raised the Taj for his beloved Mumtaz Mahal, built the city of Shahjahanabad and sat upon the jewelled Peacock Throne — yet the splendour was paid for in heavy taxes and ruinous wars, from the Deccan to the disaster at Balkh. He is the ultimate study in <b>magnificence and its cost, love made eternal in stone, and the tragic fall of the mightiest of men.</b></p>
<div class="ov-quote">“If there is a paradise on earth, it is this, it is this, it is this.”<span>— inscription associated with Shah Jahan’s Delhi</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born Khurram, favourite grandson of Akbar → proves himself the ablest prince and rebels against his father → seizes the throne in 1628 as Shah Jahan → loses Mumtaz and pours his grief into the Taj Mahal → builds Shahjahanabad and the Peacock Throne at colossal cost → wages draining wars in the Deccan, Balkh and Kandahar → is deposed by his son Aurangzeb → and dies a prisoner in Agra Fort, gazing at the Taj.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🕌</div><h4>The Taj Mahal</h4><p>Raised the world’s supreme monument of love and Mughal art.</p></div>
  <div class="ov-card"><div class="i">🏛️</div><h4>The golden age</h4><p>Crowned Mughal architecture with Shahjahanabad and the Red Fort.</p></div>
  <div class="ov-card"><div class="i">💎</div><h4>Splendour and cost</h4><p>An empire of jewels and marble, funded by the taxed peasantry.</p></div>
  <div class="ov-card"><div class="i">⛓️</div><h4>The tragic fall</h4><p>Deposed by his son, he died a prisoner facing the Taj.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Prince Khurram</b><small> 1592–1627</small><p>Akbar’s favourite, warrior prince, rebel son.</p></div>
  <div><b>2 · The Throne</b><small> 1627–1632</small><p>The race for the crown and its securing.</p></div>
  <div><b>3 · The Golden Age</b><small> 1631–1656</small><p>The Taj, Shahjahanabad, the Peacock Throne.</p></div>
  <div><b>4 · The Sword & Its Cost</b><small> 1633–1653</small><p>Deccan triumph, Balkh and Kandahar disasters.</p></div>
  <div><b>5 · The Fall</b><small> 1657–1666</small><p>The war of the sons; deposed and imprisoned.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Mumtaz Mahal', 'role': 'his beloved empress', 'color': '#b91c1c',
     'bio': 'Arjumand Banu Begum, whom Khurram married in 1612 and adored above all; her death in 1631 in childbirth drove him to build the Taj Mahal as her tomb.',
     'rel': 'The love of his life, whose memory he immortalised in marble.'},
    {'name': 'Aurangzeb', 'role': 'son and usurper', 'color': '#78350f',
     'bio': 'His austere, orthodox and ruthless son, who won the war of succession, executed his brother Dara, deposed his father, and reigned as the last great Mughal emperor.',
     'rel': 'The son who defeated his brothers and imprisoned his own father.'},
    {'name': 'Dara Shikoh', 'role': 'favoured heir', 'color': '#0f766e',
     'bio': 'His eldest son and chosen successor, a liberal mystic and scholar of comparative religion, defeated by Aurangzeb at Samugarh in 1658 and put to death.',
     'rel': 'The tolerant heir he wanted on the throne, destroyed by Aurangzeb.'},
    {'name': 'Jahangir', 'role': 'his father', 'color': '#a16207',
     'bio': 'The fourth Mughal emperor, against whom Khurram rebelled in 1622, and whose death in 1627 opened the young prince’s path to the throne.',
     'rel': 'The father he served, rebelled against, and finally succeeded.'},
    {'name': 'Jahanara Begum', 'role': 'devoted daughter', 'color': '#5b21b6',
     'bio': 'His eldest daughter and, after Mumtaz’s death, the first lady of the empire, who chose to share her father’s eight years of captivity and nursed him to the end.',
     'rel': 'The daughter who stood by him through deposition and imprisonment.'},
]

KEY_EVENTS = [
    ('1592', 'Khurram born at Lahore', 'Akbar’s cherished grandson.'),
    ('1612', 'Marries Mumtaz Mahal', 'The love that would build the Taj.'),
    ('1617', 'Titled Shah Jahan', '“King of the World” for his victories.'),
    ('1628', 'Crowned emperor', 'Fifth Mughal ruler; the golden age begins.'),
    ('1631', 'Mumtaz Mahal dies', 'In childbirth at Burhanpur.'),
    ('1632–53', 'The Taj Mahal built', 'Grief turned to white marble.'),
    ('1635', 'The Peacock Throne', 'Jewelled symbol of imperial wealth.'),
    ('1647', 'The Balkh disaster', 'A ruinous Central Asian retreat.'),
    ('1657–58', 'War of the sons', 'Aurangzeb defeats Dara Shikoh.'),
    ('1666', 'Death in Agra Fort', 'A prisoner, gazing at the Taj.'),
]

MASTER = [
    {'year': '1592', 'age': 'born', 'phase': 'Prince Khurram', 'title': 'Born at Lahore', 'desc': 'Akbar’s favourite grandson.'},
    {'year': '1628', 'age': 'age 36', 'phase': 'The Throne', 'title': 'Crowned Shah Jahan', 'desc': 'Seizes the richest empire on earth.'},
    {'year': '1631', 'age': 'age 39', 'phase': 'The Golden Age', 'title': 'Mumtaz dies; Taj begun', 'desc': 'Grief turned to marble.'},
    {'year': '1648', 'age': 'age 56', 'phase': 'The Golden Age', 'title': 'Shahjahanabad', 'desc': 'A new capital and the Red Fort.'},
    {'year': '1658', 'age': 'age 66', 'phase': 'The Fall', 'title': 'Deposed by Aurangzeb', 'desc': 'Imprisoned in the Agra Fort.'},
    {'year': '1666', 'age': 'age 74', 'phase': 'The Fall', 'title': 'Death gazing at the Taj', 'desc': 'Buried beside Mumtaz.'},
]

SOURCES = [
    ('Britannica — Shah Jahan', 'https://www.britannica.com/biography/Shah-Jahan'),
    ('World History Encyclopedia — Shah Jahan', 'https://www.worldhistory.org/Shah_Jahan/'),
    ('Britannica — Taj Mahal', 'https://www.britannica.com/topic/Taj-Mahal'),
    ('Britannica — Mumtaz Mahal', 'https://www.britannica.com/biography/Mumtaz-Mahal'),
    ('Wikipedia — Shah Jahan', 'https://en.wikipedia.org/wiki/Shah_Jahan'),
]

def build_meta():
    return {
        'pid': 'gm-shahjahan.html', 'kind': 'man', 'emoji': '🕌', 'accent': AC,
        'name': 'Shah Jahan', 'years': '1592–1666', 'group': 'Indian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The fifth Mughal emperor and master of the golden age of architecture — builder of the Taj Mahal, Shahjahanabad and the Peacock Throne — whose splendour and ruinous cost ran side by side, and who died a prisoner of his own son.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'prince', 'label': '1 · Prince Khurram', 'type': 'timeline',
             'intro': 'Born the favourite grandson of Akbar, Khurram proves himself the ablest of Jahangir’s sons and wins his love-match with Mumtaz — then gambles on rebellion against his father and learns to wait.', 'events': PHASE_PRINCE},
            {'id': 'throne', 'label': '2 · The Throne', 'type': 'timeline',
             'intro': 'When Jahangir dies, Khurram races for the crown, eliminates his rivals, and is enthroned as Shah Jahan — swiftly securing the empire and opening its most magnificent age.', 'events': PHASE_THRONE},
            {'id': 'golden', 'label': '3 · The Golden Age', 'type': 'timeline',
             'intro': 'Grief at Mumtaz’s death raises the Taj Mahal; he builds the new capital of Shahjahanabad and sits upon the jewelled Peacock Throne — magnificence and its mounting cost inseparably joined.', 'events': PHASE_GOLDEN},
            {'id': 'sword', 'label': '4 · The Sword & Its Cost', 'type': 'timeline',
             'intro': 'His armies push Mughal power to its southern peak in the Deccan — but the vain campaign into Balkh and the failed sieges of Kandahar drain the treasury and expose the limits of empire.', 'events': PHASE_SWORD},
            {'id': 'fall', 'label': '5 · The Fall', 'type': 'timeline',
             'intro': 'His illness triggers a war among his sons; the ruthless Aurangzeb destroys the favoured Dara Shikoh, deposes his father, and confines him in the Agra Fort, where he dies gazing at the Taj.', 'events': PHASE_FALL,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; construction dates for the great monuments follow the conventional ranges given by these authorities.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
