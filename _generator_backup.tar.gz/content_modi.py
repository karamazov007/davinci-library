# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Narendra Modi.
The Gujarat organiser who became India’s 14th Prime Minister — a consequential and
polarising figure, presented here strictly factually with contested episodes attributed to all sides."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#ea580c'  # saffron

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — EARLY LIFE & THE RSS
PHASE_ROOTS = [
    E('origins', '1950', 'Born in Vadnagar, a tea-seller’s son', ['ORIGINS'],
      'Narendra Damodardas Modi is born on 17 September 1950 in Vadnagar, a small town in the Mehsana district of what is now Gujarat, the third of six children in a family of the Ghanchi (oil-presser) community — a background of modest means in which, by his own account, he helped his father sell tea at the local railway station as a boy.',
      svg_row('Modest beginnings in small-town Gujarat', [
          {'n': 1, 'label': 'Born in Vadnagar, 17 Sept 1950', 'sub': 'Mehsana district, then Bombay State', 'color': '#ea580c'},
          {'n': 2, 'label': 'A family of modest means', 'sub': 'the Ghanchi community; six children', 'color': '#3730a3'},
          {'n': 3, 'label': 'The tea-seller narrative', 'sub': 'by his account, helped sell chai as a boy', 'color': '#166534'},
      ], edge_labels=['into', 'and'], takeaway='His humble origins later became a central part of his political self-presentation as a man of the people.', accent=AC),
      bg='<b>Narendra Modi</b> was born on 17 September 1950 in <b>Vadnagar</b>, Mehsana district, in present-day Gujarat, into a family of the Ghanchi (traditionally oil-pressers) community classified among the Other Backward Classes.',
      people='his father <b>Damodardas Mulchand Modi</b>; his mother <b>Hiraben</b>; his five siblings; the townspeople of Vadnagar.',
      what='Modi grew up in <b>modest circumstances</b>; he has said he helped his father run a tea stall at the Vadnagar railway station — a detail (the "chaiwala" story) that supporters cite as evidence of his ordinary roots and that some critics have questioned in its details.',
      crux='His origins mattered chiefly for <b>what they became in politics</b> — a symbol of humble beginnings deployed against a political establishment often drawn from elite families.',
      conseq='He entered adolescence in a provincial town, drawn early toward the Hindu-nationalist movement rather than a conventional career.',
      matters='Biography becomes narrative: the tea-seller story, whatever its precise details, framed decades of his political appeal.'),

    E('rss', '1958–1970s', 'The RSS and the making of a pracharak', ['ORIGINS', 'IDEAS'],
      'From childhood Modi is drawn into the Rashtriya Swayamsevak Sangh (RSS), the Hindu-nationalist volunteer organisation; after leaving home as a young man, he becomes in the early 1970s a full-time pracharak (propagator), the disciplined cadre life that would shape his politics and provide his route into public life.',
      svg_stack('From volunteer to full-time cadre', [
          {'n': 1, 'label': 'Joins RSS shakhas as a boy', 'sub': 'the Hindu-nationalist volunteer body', 'color': '#ea580c'},
          {'n': 2, 'label': 'Becomes a pracharak, early 1970s', 'sub': 'a full-time, unmarried organiser', 'color': '#3730a3'},
          {'n': 3, 'label': 'A lifelong ideological formation', 'sub': 'discipline, organisation, Hindu nationalism', 'color': '#166534'},
      ], takeaway='The RSS gave him his worldview, his organisational training, and the network that carried him into party politics.', accent=AC),
      bg='The <b>RSS</b>, founded in 1925, is a Hindu-nationalist volunteer organisation and the ideological parent of a family of groups (the Sangh Parivar) including the political party Modi would later lead.',
      people='RSS mentors and organisers who trained him; the wider Sangh Parivar; his family, whom he largely left to pursue cadre work.',
      what='Modi was involved with the RSS from boyhood and became a <b>full-time pracharak</b> in the early 1970s — an itinerant organiser sworn to the movement — a formation supporters credit for his discipline and critics link to a majoritarian ideology.',
      crux='Understanding Modi means understanding the RSS: it supplied his <b>ideology, work ethic and network</b>, and his rise is inseparable from the Sangh.',
      conseq='His cadre record won him assignment to the Bharatiya Janata Party (BJP), where he built a reputation as an organiser.',
      matters='He is the first Indian PM to rise wholly through the RSS-BJP machine — a fact central to both admiration and alarm about his tenure.'),

    E('bjp-rise', '1985–2001', 'Organiser: the climb through the BJP', ['RISE', 'POLITICS'],
      'Assigned by the RSS to the BJP in 1985, Modi proves a formidable backroom strategist — organising Gujarat campaigns, helping stage L. K. Advani’s 1990 Ram Rath Yatra, and rising to national general secretary (organisation) — a technocratic apparatchik far more than a public orator in these years.',
      svg_row('The backroom strategist rises', [
          {'n': 1, 'label': 'Assigned to the BJP, 1985', 'sub': 'the RSS deputes him to the party', 'color': '#3730a3'},
          {'n': 2, 'label': 'Organises Gujarat & the Rath Yatra', 'sub': 'a key manager of 1990s campaigns', 'color': '#ea580c'},
          {'n': 3, 'label': 'National general secretary', 'sub': 'organisation post, 1998–2001', 'color': '#166534'},
      ], edge_labels=['then', 'to'], takeaway='For nearly two decades he built the machine rather than led from the front — mastery of organisation preceded mass appeal.', accent=AC),
      bg='The <b>BJP</b>, formed in 1980, grew rapidly in the late 1980s and 1990s on a platform of Hindutva (Hindu nationalism); Modi was one of its rising organisers in Gujarat.',
      people='<b>L. K. Advani</b>, the BJP leader whose 1990 Ram Rath Yatra Modi helped organise; <b>Atal Bihari Vajpayee</b>; Gujarat party colleagues.',
      what='From 1985 Modi worked as a <b>party organiser</b>, managing state campaigns, and by 1998 was <b>national general secretary (organisation)</b> — an influential but largely behind-the-scenes role, not yet an elected office.',
      crux='His early strength was <b>organisational, not electoral</b> — he had never won a popular election before 2001, a fact his rivals sometimes noted.',
      conseq='When the Gujarat BJP faltered under Keshubhai Patel in 2001, the leadership turned to Modi to take charge of the state.',
      matters='He reached high office first as an appointed organiser, not a vote-winner — the electoral persona came later, and transformed him.'),
]

# ==================================================================  PHASE 2 — GUJARAT CHIEF MINISTER
PHASE_GUJARAT = [
    E('cm2001', '2001', 'Chief Minister of Gujarat', ['RISE', 'POLITICS', 'TURNING POINT'],
      'On 7 October 2001, with the Gujarat BJP struggling and its government criticised over relief after the January 2001 Bhuj earthquake, the party installs Modi — who had never held elected office — as Chief Minister, launching the thirteen-year state tenure on which his national rise would be built.',
      svg_stack('An appointed leader takes charge', [
          {'n': 1, 'label': 'Gujarat BJP falters, 2001', 'sub': 'criticism over post-earthquake relief', 'color': '#3730a3'},
          {'n': 2, 'label': 'Modi sworn in as CM, 7 Oct 2001', 'sub': 'replacing Keshubhai Patel', 'color': '#ea580c'},
          {'n': 3, 'label': 'His first elected office', 'sub': 'wins a by-election months later', 'color': '#166534'},
      ], takeaway='He entered executive power almost by appointment — and would go on to win four straight Gujarat elections.', accent=AC),
      bg='In January 2001 a devastating <b>earthquake struck Bhuj</b> in Gujarat; the incumbent BJP government drew criticism over relief, and the party leadership sought a change.',
      people='<b>Keshubhai Patel</b>, the CM he replaced; BJP central leaders who chose him; the Gujarat electorate he had yet to face.',
      what='Modi became <b>Chief Minister of Gujarat on 7 October 2001</b> without having previously held elected office, entering the state assembly through a by-election shortly afterward.',
      crux='He arrived in power as a <b>party appointee</b>, needing quickly to prove himself both as an administrator and at the ballot box.',
      conseq='Within months his tenure would be overshadowed by the communal violence of 2002 — the defining controversy of his career.',
      matters='The Gujarat chief ministership was the launchpad; everything national about Modi begins with these thirteen years.'),

    E('riots2002', '2002', 'The 2002 Gujarat riots', ['TRAGEDY', 'CONTESTED', 'TURNING POINT'],
      'In late February 2002, after 59 Hindu pilgrims die in a fire on a train at Godhra, Gujarat erupts in communal violence in which official figures record over 1,000 killed — around three-quarters of them Muslim — with independent estimates near 2,000; Modi’s handling becomes the most bitterly contested question of his public life, judged very differently by his critics and his defenders.',
      svg_compare('A contested episode: two readings', {
          'head': 'Critics / rights groups say', 'color': '#b91c1c',
          'items': ['State did too little to stop the killing', 'Alleged police inaction and complicity', 'Modi bore moral/administrative responsibility', 'Estimates near 2,000 dead, mostly Muslim'],
      }, {
          'head': 'Modi & supporters say', 'color': '#3730a3',
          'items': ['Government acted to restore order', 'Army called in; violence was contained', 'No evidence of orchestration by the CM', 'Later cleared by SIT and the courts'],
      }, verdict='Official toll: 1,000+ killed, roughly three-quarters Muslim; independent estimates ~2,000. Responsibility remains fiercely disputed.',
         takeaway='One of independent India’s worst communal episodes — and the single most contested chapter of Modi’s record.', accent=AC),
      bg='On <b>27 February 2002</b> a fire on the Sabarmati Express at <b>Godhra</b> killed 59 people, many of them Hindu pilgrims (kar sevaks); the cause was itself later disputed. Communal violence then swept Gujarat for weeks.',
      people='the victims of Godhra and of the subsequent riots; <b>Zakia Jafri</b>, widow of ex-MP Ehsan Jafri killed at Gulberg Society; human-rights groups; the Gujarat police and administration.',
      what='Over <b>1,000 people were killed</b> according to official figures — about three-quarters of them Muslim — with independent tallies near 2,000. <b>Critics</b>, including rights organisations, alleged state inaction or complicity; <b>Modi and the government</b> said they acted to restore order and denied any orchestration.',
      crux='The dispute is not over whether atrocities occurred — they did — but over <b>the state’s and Modi’s responsibility</b>: negligence and complicity, say critics; a government overwhelmed but acting in good faith, say defenders.',
      conseq='The riots drew international condemnation; the United States denied Modi a visa in 2005, a bar lifted only after he became PM. Legal proceedings ran for two decades.',
      matters='This episode divides assessments of Modi more than any other; the library presents the documented facts and leaves the moral judgment to the reader.'),

    E('sit-sc', '2008–2022', 'Investigation, SIT report and the Supreme Court', ['POLITICS', 'CONTESTED'],
      'The Supreme Court appoints a Special Investigation Team (SIT) in 2008 to probe major riot cases and complaints against Modi; in 2012 the SIT files a closure report finding no prosecutable evidence against him, and in June 2022 the Supreme Court dismisses Zakia Jafri’s challenge to that finding — outcomes his supporters call vindication and his critics call inadequate.',
      svg_row('The legal process, step by step', [
          {'n': 1, 'label': 'SIT appointed, 2008', 'sub': 'Supreme Court orders investigation', 'color': '#3730a3'},
          {'n': 2, 'label': 'SIT closure report, 2012', 'sub': 'no prosecutable evidence vs. Modi', 'color': '#ea580c'},
          {'n': 3, 'label': 'Supreme Court dismisses plea, 2022', 'sub': 'Zakia Jafri challenge rejected, 24 June', 'color': '#166534'},
      ], edge_labels=['finds', 'upheld'], takeaway='The courts found no prosecutable case against Modi — a conclusion his defenders stress and his critics contest as a matter of process, not full exoneration.', accent=AC),
      bg='Amid persistent allegations, the <b>Supreme Court set up a Special Investigation Team (SIT)</b> in 2008 to re-examine major riot cases, including a complaint by Zakia Jafri naming Modi and others.',
      people='the SIT and its chief <b>R. K. Raghavan</b>; petitioner <b>Zakia Jafri</b>; the activist <b>Teesta Setalvad</b>, who supported the litigation; the Supreme Court bench.',
      what='In <b>2012 the SIT filed a closure report</b> stating it found <b>no prosecutable evidence</b> against Modi. On <b>24 June 2022 the Supreme Court dismissed</b> Zakia Jafri’s petition challenging that report.',
      crux='Supporters read these findings as <b>legal exoneration</b>; critics argue the SIT’s remit and conclusions were <b>too narrow</b> and note the day after the 2022 ruling, activist Teesta Setalvad was arrested — which rights groups called intimidation.',
      conseq='The rulings removed the immediate legal cloud over Modi and are routinely cited by his party; controversy over the process nonetheless persists.',
      matters='"The courts cleared him" and "the process was inadequate" are both real positions — attributing each, rather than adjudicating, is the honest course.'),

    E('gujaratmodel', '2003–2013', 'The "Gujarat model" debate', ['REFORM', 'CONTESTED'],
      'Re-elected repeatedly, Modi rebrands himself as a pro-business moderniser, courting investment through "Vibrant Gujarat" summits and pointing to high state growth, roads and power — the celebrated "Gujarat model," which supporters hail as a development template and critics say masked weak human-development indicators and uneven benefits.',
      svg_compare('The "Gujarat model": two verdicts', {
          'head': 'Supporters emphasise', 'color': '#166534',
          'items': ['Rapid GDP growth and investment', '24-hour power, roads, industry', 'Business-friendly, low-friction governance', 'A replicable development template'],
      }, {
          'head': 'Critics emphasise', 'color': '#b91c1c',
          'items': ['Lagging health, nutrition, education', 'Uneven gains; growth pre-dated Modi', 'Crony-capitalism concerns', 'Social indicators below the hype'],
      }, verdict='Economists disputed the model even at the time; Gujarat grew fast, but human-development metrics lagged the growth story.',
         takeaway='The "Gujarat model" was as much a political brand as an economic fact — powerful in campaigns, contested by data.', accent=AC),
      bg='After 2002, Modi won Gujarat elections in <b>2002, 2007 and 2012</b> and increasingly emphasised <b>economic development</b>, hosting biennial "Vibrant Gujarat" investor summits from 2003.',
      people='big industrialists who invested in the state; economists on both sides (e.g. the Bhagwati–Sen debate over growth vs. human development); Gujarat’s voters.',
      what='The <b>"Gujarat model"</b> highlighted <b>high growth, infrastructure and investment</b>; supporters called it a template for India, while critics noted <b>weaker human-development indicators</b> and argued gains were uneven and partly predated Modi.',
      crux='The debate turned on <b>what "development" measures</b> — headline GDP and industry, or health, nutrition and education, where Gujarat’s record was more mixed.',
      conseq='The model, contested or not, became the <b>core of his 2014 national pitch</b> — Modi as the man who could deliver growth and jobs.',
      matters='It shows how a governance record becomes a brand — and why economic claims about Modi need to be read with the counter-evidence.'),
]

# ==================================================================  PHASE 3 — POWER AND THE FIRST TERM
PHASE_FIRSTTERM = [
    E('election2014', '2014', 'The 2014 landslide', ['TRIUMPH', 'TURNING POINT'],
      'Campaigning on development, anti-corruption and change after a decade of Congress-led rule, Modi leads the BJP to a sweeping victory in the 2014 general election — 282 seats, the first single-party majority in the Lok Sabha since 1984 — and is sworn in as India’s 14th Prime Minister on 26 May 2014.',
      svg_row('A decisive mandate', [
          {'n': 1, 'label': 'Runs on growth & change', 'sub': 'a presidential-style national campaign', 'color': '#3730a3'},
          {'n': 2, 'label': 'BJP wins 282 seats', 'sub': 'first single-party majority since 1984', 'color': '#ea580c'},
          {'n': 3, 'label': 'Sworn in PM, 26 May 2014', 'sub': 'the 14th Prime Minister of India', 'color': '#166534'},
      ], edge_labels=['delivers', 'and'], takeaway='He turned a state record and a formidable campaign machine into the strongest national mandate in thirty years.', accent=AC),
      bg='By 2014 the Congress-led UPA government was beset by <b>corruption scandals and slowing growth</b>; the BJP projected Modi as its prime-ministerial candidate — a break from its usual practice.',
      people='<b>Rahul Gandhi</b> and the Congress; BJP strategist <b>Amit Shah</b>, who ran the Uttar Pradesh campaign; the vast first-time and youth electorate.',
      what='In the <b>2014 general election</b> the BJP won <b>282 of 543 seats</b> (the NDA over 330), the first outright single-party majority since 1984; Modi became <b>Prime Minister on 26 May 2014</b>.',
      crux='The win reflected both <b>a rejection of the incumbent</b> and an <b>unusually personalised campaign</b> built around Modi as decisive moderniser.',
      conseq='With a clear majority he could pursue an ambitious agenda; expectations of rapid economic transformation ran high.',
      matters='2014 realigned Indian politics around a dominant BJP and a presidential-style leadership — a shift still defining the country.'),

    E('schemes', '2014–2016', 'Swachh Bharat, Jan Dhan and the flagship schemes', ['REFORM', 'POLITICS'],
      'Modi’s first term is marked by high-visibility national programmes — the Swachh Bharat sanitation drive launched on 2 October 2014, the Jan Dhan financial-inclusion push opening hundreds of millions of bank accounts, and later Ujjwala cooking-gas connections — welfare-and-branding initiatives supporters credit with real delivery and critics say were unevenly implemented.',
      svg_stack('Governance as branded mission', [
          {'n': 1, 'label': 'Swachh Bharat, 2 Oct 2014', 'sub': 'nationwide sanitation & toilets drive', 'color': '#ea580c'},
          {'n': 2, 'label': 'Jan Dhan Yojana, Aug 2014', 'sub': 'bank accounts for the unbanked', 'color': '#3730a3'},
          {'n': 3, 'label': 'Ujjwala & digital delivery', 'sub': 'LPG, Aadhaar-linked direct benefits', 'color': '#166534'},
      ], takeaway='He fused welfare delivery with mass branding — a signature style admirers call effective and skeptics call marketing.', accent=AC),
      bg='Modi launched a series of <b>mission-mode national schemes</b>, each with strong branding, targets and his personal association.',
      people='the tens of millions of new bank-account holders; rural households targeted for toilets and gas; the bureaucrats tasked with delivery.',
      what='Flagships included <b>Swachh Bharat</b> (sanitation, from 2 Oct 2014), <b>Pradhan Mantri Jan Dhan Yojana</b> (financial inclusion, opening hundreds of millions of accounts), and <b>Ujjwala</b> (LPG connections) — supporters cite scale and reach; critics question quality, usage and data.',
      crux='The pattern was <b>direct-benefit welfare wrapped in strong messaging</b> — expanding access while building political capital.',
      conseq='These programmes broadened the BJP’s support among poorer voters and reshaped how welfare is delivered and advertised in India.',
      matters='They exemplify Modi’s governing style — measurable missions plus relentless communication — for better and, critics argue, for optics.'),

    E('demonetisation', '2016', 'Demonetisation', ['REFORM', 'CONTESTED'],
      'On the night of 8 November 2016 Modi announces on television that ₹500 and ₹1,000 notes — some 86% of India’s currency by value — will cease to be legal tender within hours, aiming to strike at black money, counterfeiting and terror financing; the abrupt move triggers months of cash shortages and long queues, and its economic verdict remains sharply disputed.',
      svg_compare('Demonetisation: aims vs. outcomes', {
          'head': 'Government’s stated aims', 'color': '#3730a3',
          'items': ['Destroy hoarded "black money"', 'Curb counterfeiting & terror finance', 'Push India toward digital payments', 'Widen the tax base'],
      }, {
          'head': 'Critics point to', 'color': '#b91c1c',
          'items': ['~99% of notes returned to banks', 'Cash crunch hit informal economy hard', 'GDP growth dip; job losses reported', 'Deaths in queues; poor execution'],
      }, verdict='RBI later reported nearly all demonetised cash was deposited; economists widely judged the disruption large and the anti-black-money gains modest.',
         takeaway='A dramatic shock policy whose bold intent and disruptive costs are both well documented — and still argued over.', accent=AC),
      bg='India’s economy ran heavily on <b>cash</b>, and the government said undeclared "black money" was widespread; on <b>8 November 2016</b> Modi made a surprise national address.',
      people='ordinary citizens who queued for weeks to exchange notes; small traders and daily-wage workers hit hardest; the Reserve Bank of India (RBI).',
      what='<b>₹500 and ₹1,000 notes</b> (about <b>86% of currency by value</b>) were voided almost overnight. The government cited black money, counterfeiting and terror funding; critics noted the RBI later found <b>~99% of the cash returned</b>, questioning the payoff.',
      crux='The dispute is whether the <b>large short-term disruption</b> to a cash-based, informal economy was justified by <b>hard-to-verify long-term gains</b> in formalisation and digital payments.',
      conseq='Digital payments rose sharply thereafter; growth slowed and informal-sector distress was widely reported. It remains a byword for bold — or reckless — economic action.',
      matters='It is a case study in high-risk executive decisiveness: the same facts read as courage or as costly overreach depending on the observer.'),

    E('gst', '2017', 'The Goods and Services Tax', ['REFORM'],
      'On 1 July 2017 the Modi government launches the Goods and Services Tax, a nationwide indirect tax replacing a tangle of central and state levies — a long-discussed reform meant to create "one nation, one tax," hailed as historic but also criticised for a complex multi-rate structure and a difficult rollout for small businesses.',
      svg_row('Unifying India’s indirect taxes', [
          {'n': 1, 'label': 'A patchwork of state & central taxes', 'sub': 'decades of fragmented indirect tax', 'color': '#3730a3'},
          {'n': 2, 'label': 'GST launched, 1 July 2017', 'sub': '"one nation, one tax" via a midnight session', 'color': '#ea580c'},
          {'n': 3, 'label': 'Historic but contested rollout', 'sub': 'multiple slabs; strain on small firms', 'color': '#a16207'},
      ], edge_labels=['replaced by', 'yet'], takeaway='A structural reform decades in the making — landmark in ambition, uneven in early execution.', accent=AC),
      bg='A unified <b>GST</b> had been debated across governments for years; it required a constitutional amendment and agreement between the centre and the states via the GST Council.',
      people='Finance Minister <b>Arun Jaitley</b>; state finance ministers on the GST Council; businesses large and small adapting to the new system.',
      what='The <b>GST took effect on 1 July 2017</b>, subsuming many central and state taxes into a common framework with a shared council; supporters called it a historic simplification, while critics cited <b>multiple rate slabs and compliance burdens</b> on small enterprises.',
      crux='The reform’s value lay in <b>integrating a fragmented market</b>; its problems lay in <b>complexity and a bumpy transition</b>, especially close after demonetisation.',
      conseq='GST reshaped Indian taxation and boosted formalisation over time, though rates and procedures were repeatedly revised.',
      matters='It shows Modi delivering a genuinely structural reform — one long sought and cross-party in origin — alongside the execution debates typical of his tenure.'),
]

# ==================================================================  PHASE 4 — THE SECOND TERM
PHASE_SECONDTERM = [
    E('election2019', '2019', 'Re-election with a larger mandate', ['TRIUMPH'],
      'After a term marked by both flagship schemes and controversy, and amid heightened nationalism following the Pulwama attack and the Balakot air strike, Modi leads the BJP to an even bigger win in 2019 — 303 seats, with the NDA around 353 — a rare feat of a government increasing its majority.',
      svg_row('A bigger second mandate', [
          {'n': 1, 'label': 'Pulwama & Balakot, early 2019', 'sub': 'security crisis sharpens the campaign', 'color': '#b91c1c'},
          {'n': 2, 'label': 'BJP wins 303 seats', 'sub': 'NDA around 353 of 543', 'color': '#ea580c'},
          {'n': 3, 'label': 'A strengthened government', 'sub': 'increases its majority — a rarity', 'color': '#166534'},
      ], edge_labels=['amid', 'to'], takeaway='He defied the usual anti-incumbency and expanded his majority — cementing BJP dominance.', accent=AC),
      bg='In February 2019 a <b>suicide bombing at Pulwama</b> killed 40 Indian paramilitaries; India responded with an air strike at <b>Balakot</b> in Pakistan, and national-security themes ran strong into the election.',
      people='opposition leader <b>Rahul Gandhi</b>; BJP president <b>Amit Shah</b>; the security establishment; a broad cross-section of voters.',
      what='In the <b>2019 general election</b> the BJP won <b>303 seats</b> (NDA ~353), an increase on 2014 — a striking result for a sitting government, powered by welfare delivery, Modi’s personal appeal and nationalist sentiment.',
      crux='The scale of the win gave Modi <b>a freer hand</b> for a more assertive second-term agenda on long-standing ideological goals.',
      conseq='Within months the government moved on Article 370 and citizenship — the most consequential and contested actions of his premiership.',
      matters='2019 confirmed 2014 was no fluke; India had entered an era of BJP electoral dominance centred on Modi.'),

    E('article370', '2019', 'Abrogation of Article 370', ['POLITICS', 'CONTESTED', 'TURNING POINT'],
      'On 5 August 2019 the government moves to strip Jammu and Kashmir of the special autonomy it held under Article 370 of the constitution, splitting the state into two union territories — a long-held BJP goal supporters call national integration, imposed alongside a security lockdown and communications blackout that critics call a suspension of rights.',
      svg_compare('Article 370: integration or overreach?', {
          'head': 'Government & supporters say', 'color': '#3730a3',
          'items': ['Fulfils a decades-old BJP pledge', 'Integrates J&K fully into India', 'Aims at development & ending separatism', 'Upheld by the Supreme Court in 2023'],
      }, {
          'head': 'Critics & opposition say', 'color': '#b91c1c',
          'items': ['Done without Kashmiri consent', 'Lockdown, detentions, comms blackout', 'Erodes federalism and autonomy', 'Rights concerns raised internationally'],
      }, verdict='In December 2023 the Supreme Court upheld the abrogation as constitutional; the manner and the human-rights impact remained disputed.',
         takeaway='A defining ideological act of the second term — celebrated as integration by supporters, criticised as coercive by opponents.', accent=AC),
      bg='<b>Article 370</b> gave Jammu and Kashmir special autonomous status within India; its removal had long been a core BJP demand.',
      people='Home Minister <b>Amit Shah</b>, who moved the measure; Kashmiri political leaders placed under detention; the region’s residents.',
      what='On <b>5 August 2019</b> the government revoked J&K’s special status and <b>reorganised the state into two union territories</b>, imposing a heavy security clampdown, detentions of local leaders, and a prolonged <b>communications blackout</b>.',
      crux='The clash is between <b>"national integration"</b> as the stated aim and the <b>means used</b> — unilateral action, mass detentions and information shutdown — that critics say denied Kashmiris a voice.',
      conseq='The Supreme Court <b>upheld the abrogation in December 2023</b>; normal politics and statehood restoration remained partial and contested for years.',
      matters='It marked the boldest execution of the BJP’s ideological programme — and a stress-test of Indian federalism and civil liberties.'),

    E('caa', '2019–2020', 'The Citizenship Amendment Act and the protests', ['POLITICS', 'CONTESTED'],
      'In December 2019 Parliament passes the Citizenship Amendment Act (CAA), fast-tracking naturalisation for certain non-Muslim migrants from three neighbouring countries — which the government calls a humanitarian shelter for persecuted minorities, and which critics say discriminates by religion and, with a proposed citizens’ register, threatens Muslims; nationwide protests and deadly Delhi riots follow.',
      svg_compare('The CAA: refuge or discrimination?', {
          'head': 'Government’s position', 'color': '#3730a3',
          'items': ['Shelters persecuted religious minorities', 'Covers Hindus, Sikhs, Christians, others', 'Does not take away any citizen’s rights', 'A humanitarian, not anti-Muslim, law'],
      }, {
          'head': 'Critics’ position', 'color': '#b91c1c',
          'items': ['First faith-based citizenship criterion', 'Excludes Muslims explicitly', 'Feared with NRC to target Muslims', 'Called unconstitutional (Article 14)'],
      }, verdict='The law made religion a criterion for citizenship for the first time; protests spread nationwide and Delhi saw deadly riots in Feb 2020.',
         takeaway='Framed as compassion by the government and as exclusion by critics — the CAA became a flashpoint over India’s secular identity.', accent=AC),
      bg='The <b>CAA</b>, passed in December 2019, amended citizenship rules for migrants who entered India before 2015 from Pakistan, Afghanistan and Bangladesh.',
      people='protesters (notably the women of Shaheen Bagh); the victims of the February 2020 Delhi riots; Home Minister Amit Shah; the courts hearing challenges.',
      what='The Act <b>fast-tracks citizenship for Hindus, Sikhs, Buddhists, Jains, Parsis and Christians</b> — but not Muslims — from the three countries. The government called it humanitarian; critics said it made <b>religion a citizenship test</b> for the first time and, paired with a proposed <b>National Register of Citizens</b>, endangered Muslims.',
      crux='The core question is whether a law that <b>excludes one religion</b> can be humanitarian rather than discriminatory — a dispute now before the courts and unresolved in public opinion.',
      conseq='Mass protests ran for months; <b>Delhi riots in February 2020</b> killed dozens. Implementation rules were notified only in 2024.',
      matters='The CAA crystallised the debate over whether Modi-era India was upholding or eroding its secular constitutional promise.'),

    E('covid', '2020–2021', 'The COVID-19 pandemic', ['TRAGEDY', 'CONTESTED'],
      'India faces the pandemic with one of the world’s strictest early lockdowns in March 2020 — which triggered a vast migrant-worker crisis — followed by a massive vaccination drive, but a catastrophic Delta second wave in April–May 2021 overwhelms hospitals and crematoria, with official deaths of over half a million and independent estimates far higher; the government’s handling is both credited and heavily criticised.',
      svg_row('A pandemic of two waves', [
          {'n': 1, 'label': 'Strict lockdown, March 2020', 'sub': 'sudden; a migrant-worker exodus follows', 'color': '#a16207'},
          {'n': 2, 'label': 'Devastating second wave, 2021', 'sub': 'oxygen shortages; hospitals overwhelmed', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Mass vaccination drive', 'sub': 'billions of doses; domestic manufacture', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='A response of extremes — early severity and later mass vaccination, split by a deadly second-wave collapse.', accent=AC),
      bg='COVID-19 reached India in early 2020; on <b>24 March 2020</b> Modi announced a near-total national lockdown with only hours’ notice.',
      people='millions of stranded migrant workers who walked home; overwhelmed doctors in 2021; vaccine makers (Serum Institute, Bharat Biotech); grieving families.',
      what='The <b>2020 lockdown</b> was among the world’s strictest and caused a <b>humanitarian migrant crisis</b>; the <b>April–May 2021 Delta wave</b> brought oxygen shortages and mass deaths — <b>officially 500,000+</b>, with independent estimates (including WHO excess-mortality) running into the millions. India then ran one of the largest <b>vaccination campaigns</b> in history.',
      crux='Supporters cite the <b>vaccine drive and self-reliant production</b>; critics cite the <b>lockdown’s human cost</b> and the <b>2021 collapse</b>, including large gatherings allowed before the second wave.',
      conseq='The pandemic caused severe economic contraction and immense loss of life, then a strong recovery; excess-mortality figures remain disputed with the government.',
      matters='COVID showcased the whole range of Modi-era governance — decisive scale and communication alongside serious gaps and contested data.'),

    E('farmlaws', '2020–2021', 'The farm laws and their repeal', ['POLITICS', 'CONTESTED', 'REFORM'],
      'In September 2020 the government passes three laws to deregulate agricultural markets — which it calls a historic reform to free farmers, and which many farmers, especially in Punjab and Haryana, see as a threat to guaranteed prices; a year-long protest camped at Delhi’s borders follows, and in November 2021 Modi announces a rare reversal, repealing the laws.',
      svg_compare('The farm laws: reform vs. repeal', {
          'head': 'Government said', 'color': '#3730a3',
          'items': ['Frees farmers to sell anywhere', 'Attracts private investment', 'Ends middleman monopolies', 'A long-overdue market reform'],
      }, {
          'head': 'Protesting farmers said', 'color': '#b91c1c',
          'items': ['Threatens minimum support prices', 'Favours big corporate buyers', 'Passed without consultation', 'Endangers small-farmer livelihoods'],
      }, verdict='After a year of protests and over 700 reported protester deaths, Modi repealed the laws in Nov 2021 — one of his rare policy reversals.',
         takeaway='Framed by the government as bold reform and by farmers as an existential threat — and, unusually, withdrawn under sustained pressure.', accent=AC),
      bg='In <b>September 2020</b> Parliament passed <b>three farm laws</b> deregulating the sale, pricing and storage of agricultural produce, bypassing extended debate.',
      people='the protesting farmers’ unions (Samyukt Kisan Morcha); Punjab and Haryana farming communities; the government and opposition.',
      what='The laws aimed to <b>liberalise agricultural markets</b>. Farmers, fearing an end to the <b>minimum support price</b> system and dominance by large buyers, launched a <b>year-long protest</b> at Delhi’s borders; over 700 protesters reportedly died. In <b>November 2021 Modi announced repeal</b>.',
      crux='The dispute pitted <b>market efficiency</b> against <b>price security for small farmers</b> — and the process, laws passed with little consultation, deepened the distrust.',
      conseq='The repeal was a <b>rare retreat</b> for Modi, widely read as a response to farmer power ahead of state elections.',
      matters='It demonstrated the limits of even a dominant government — sustained civil mobilisation forced a reversal.'),
]

# ==================================================================  PHASE 5 — THIRD TERM & LEGACY
PHASE_LEGACY = [
    E('g20', '2023', 'India’s G20 presidency', ['TRIUMPH', 'POLITICS'],
      'In 2023 India holds the rotating presidency of the G20, culminating in a New Delhi summit in September at which Modi presides over the admission of the African Union and a consensus declaration — a diplomatic showcase his government promotes as India’s arrival as a leading voice of the "Global South," staged with heavy domestic branding.',
      svg_stack('India on the world stage', [
          {'n': 1, 'label': 'G20 presidency, 2023', 'sub': 'a year of meetings across India', 'color': '#3730a3'},
          {'n': 2, 'label': 'New Delhi summit, Sept 2023', 'sub': 'African Union admitted; joint declaration', 'color': '#ea580c'},
          {'n': 3, 'label': 'Voice of the "Global South"', 'sub': 'branded as India’s diplomatic arrival', 'color': '#166534'},
      ], takeaway='A high-profile stage for Modi’s foreign policy — projecting India as a bridge-builder and leader among developing nations.', accent=AC),
      bg='The <b>G20</b> presidency rotates annually; India held it in <b>2023</b>, using it to host hundreds of meetings nationwide and to raise its global profile.',
      people='visiting world leaders; India’s diplomatic corps; the developing nations Modi positioned India to represent.',
      what='India’s presidency produced a <b>consensus New Delhi declaration</b> despite tensions over Ukraine and secured the <b>African Union’s admission</b> to the G20; the government showcased it as evidence of India’s rising stature and Modi’s statesmanship.',
      crux='The presidency was partly <b>substantive diplomacy</b> and partly <b>domestic political messaging</b>, with Modi’s image prominent throughout the branding.',
      conseq='It reinforced India’s self-image as a leading power and Modi’s standing as an international statesman heading into the 2024 election.',
      matters='It reflects a defining ambition of his tenure — elevating India’s global weight while tying that rise closely to his own leadership.'),

    E('election2024', '2024', 'The 2024 election and coalition government', ['POLITICS', 'TURNING POINT'],
      'Seeking a third term with the slogan of crossing 400 seats, Modi and the BJP fall well short in the 2024 general election — the BJP winning 240 seats, below the 272-seat majority — so that for the first time since 2014 Modi governs at the head of an NDA coalition rather than on a single-party majority, returning as PM on 9 June 2024.',
      svg_row('A third term — but on a coalition', [
          {'n': 1, 'label': 'Aims for a supermajority', 'sub': 'the "Abki baar, 400 paar" slogan', 'color': '#3730a3'},
          {'n': 2, 'label': 'BJP wins 240 seats', 'sub': 'below the 272 majority mark', 'color': '#ea580c'},
          {'n': 3, 'label': 'Governs via NDA coalition', 'sub': 'sworn in for a third term, 9 June 2024', 'color': '#a16207'},
      ], edge_labels=['but', 'so'], takeaway='A third consecutive term — but a chastened one, dependent for the first time on coalition allies.', accent=AC),
      bg='Modi sought a <b>third consecutive term</b> in the 2024 general election, with the BJP openly targeting a supermajority ("400 paar").',
      people='a re-energised opposition <b>INDIA bloc</b> led by the Congress and Rahul Gandhi; NDA allies like the TDP and JD(U), now pivotal; the electorate.',
      what='The BJP won <b>240 seats — short of the 272 majority</b> — with the NDA at around <b>293</b> and the opposition INDIA bloc gaining strongly (Congress rose to 99). Modi returned as PM on <b>9 June 2024</b>, now <b>reliant on coalition partners</b>.',
      crux='The result was read as a <b>partial check</b> on Modi’s dominance — voters returned him but denied the BJP its own majority, restoring coalition constraints.',
      conseq='Modi became only the second PM (after Nehru) to win three straight terms, but in a weaker position, with allies and a louder opposition.',
      matters='2024 tested whether the Modi model could absorb a setback — showing both his durability and the limits voters placed on it.'),

    E('assessment', '2014–', 'A consequential and contested legacy', ['LEGACY', 'CONTESTED'],
      'By his third term Modi stands among the most consequential and polarising figures in India’s history — credited by supporters with decisive governance, welfare delivery, infrastructure and global stature, and charged by critics with democratic backsliding, pressure on institutions and the media, and a majoritarian turn; both readings rest on a substantial documented record.',
      svg_compare('How his record is judged', {
          'head': 'Supporters credit him with', 'color': '#166534',
          'items': ['Decisive governance & welfare at scale', 'Infrastructure, digital economy, growth', 'Elevated global standing for India', 'Three consecutive electoral mandates'],
      }, {
          'head': 'Critics charge him with', 'color': '#b91c1c',
          'items': ['Democratic backsliding, weaker checks', 'Pressure on press, courts, opposition', 'Majoritarian politics; minority anxiety', 'Concentration of power around one leader'],
      }, verdict='International democracy indices logged declines in his tenure; supporters dispute their framing. The library reports both and adjudicates neither.',
         takeaway='A leader whose scale of impact is undisputed and whose meaning is deeply disputed — the reader is left to weigh the evidence.', accent=AC),
      bg='Across a decade in national power, Modi reshaped India’s politics, economy and international posture, drawing intense support and intense criticism.',
      people='his admirers across India and the diaspora; his critics among the opposition, civil society, journalists and some scholars; international observers.',
      what='Supporters point to <b>welfare delivery, infrastructure, digital public goods and global stature</b>; critics point to <b>declines on press freedom and democracy indices, pressure on institutions, and majoritarian politics</b> that they say unsettles minorities. Both cite an extensive record.',
      crux='The central dispute is not about <b>whether he mattered</b> — plainly he did — but about <b>whether his impact strengthened or weakened Indian democracy and pluralism</b>.',
      conseq='He remains, as of 2026, a sitting Prime Minister whose full legacy is still unfolding and will be argued over for decades.',
      matters='On a living, polarising figure, the honest task is to lay out the documented facts and the competing interpretations — and leave the verdict to the reader.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Narendra Modi is India’s 14th Prime Minister and one of the most consequential — and most polarising — figures in the country’s modern history. Born in 1950 to a family of modest means in small-town Gujarat, he rose through the RSS and the BJP as an organiser, became Chief Minister of Gujarat in 2001, and led his party to sweeping national victories in 2014 and 2019 before returning for a third term at the head of a coalition in 2024. His record spans landmark reforms and welfare programmes on one hand and bitterly contested episodes — the 2002 Gujarat riots, demonetisation, Article 370, the CAA — on the other. This guide presents the documented facts and <b>attributes the competing interpretations to their sources, leaving judgment to the reader.</b></p>
<div class="ov-quote">A living, polarising head of government — reported here strictly factually.<span>— the library’s neutrality note</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A tea-seller’s son shaped by the RSS → rises as a BJP organiser and becomes Gujarat CM in 2001 → his tenure defined by the contested 2002 riots and the debated "Gujarat model" → sweeps to national power in 2014 and again in 2019 → pursues demonetisation, GST, Article 370, the CAA and a strict COVID response → hosts the 2023 G20 → and returns in 2024 for a third term, now governing in coalition after the BJP falls short of a majority.</p>
<div class="ov-lbl">Why he matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🗳️</div><h4>Electoral dominance</h4><p>Two single-party majorities and a third term reshaped Indian politics.</p></div>
  <div class="ov-card"><div class="i">🏗️</div><h4>Reform and welfare</h4><p>GST, Jan Dhan, Swachh Bharat — plus demonetisation’s disruption.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>Deep controversy</h4><p>2002, Article 370, CAA — episodes read very differently by each side.</p></div>
  <div class="ov-card"><div class="i">🌐</div><h4>Global posture</h4><p>Raised India’s international weight; hosted the 2023 G20 summit.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Early Life</b><small> 1950–2001</small><p>Vadnagar, the RSS, and the climb through the BJP.</p></div>
  <div><b>2 · Gujarat</b><small> 2001–2014</small><p>Chief Minister, the 2002 riots, and the "Gujarat model."</p></div>
  <div><b>3 · First Term</b><small> 2014–2019</small><p>The 2014 landslide, flagship schemes, demonetisation, GST.</p></div>
  <div><b>4 · Second Term</b><small> 2019–2024</small><p>Article 370, the CAA, COVID-19, the farm laws.</p></div>
  <div><b>5 · Third Term</b><small> 2023–</small><p>The G20, the 2024 coalition, and a contested legacy.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the episode, then six branches (background, key people, what happened, the crux, consequences, why it matters). For contested items, the diagram and the "crux"/"why it matters" branches <b>present the major perspectives side by side</b> rather than a verdict. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Amit Shah', 'role': 'closest lieutenant', 'color': '#ea580c',
     'bio': 'Modi’s longtime strategist from Gujarat, BJP president during its national dominance and Union Home Minister who moved the Article 370 and CAA measures.',
     'rel': 'His most trusted political ally and chief operational strategist.'},
    {'name': 'L. K. Advani', 'role': 'BJP mentor', 'color': '#3730a3',
     'bio': 'The BJP veteran whose 1990 Ram Rath Yatra Modi helped organise; a senior patron of the party Modi later eclipsed.',
     'rel': 'The elder leader who shaped the BJP Modi rose through.'},
    {'name': 'Rahul Gandhi', 'role': 'chief rival', 'color': '#166534',
     'bio': 'The Congress leader and scion of the Nehru–Gandhi family, Modi’s principal national opponent across the 2014, 2019 and 2024 elections.',
     'rel': 'His main electoral adversary and face of the opposition.'},
    {'name': 'Zakia Jafri', 'role': '2002 petitioner', 'color': '#b91c1c',
     'bio': 'Widow of former MP Ehsan Jafri, killed in the 2002 riots; she pursued a two-decade legal challenge naming Modi, dismissed by the Supreme Court in 2022.',
     'rel': 'The petitioner at the centre of the long 2002 litigation.'},
    {'name': 'The RSS', 'role': 'ideological parent', 'color': '#a16207',
     'bio': 'The Hindu-nationalist volunteer organisation that shaped Modi from boyhood, trained him as a pracharak, and remains the ideological base of his politics.',
     'rel': 'The movement that formed him and underpins his party.'},
]

KEY_EVENTS = [
    ('1950', 'Born in Vadnagar', 'A family of modest means in Gujarat.'),
    ('2001', 'Chief Minister of Gujarat', 'Sworn in 7 October, without prior elected office.'),
    ('2002', 'Gujarat riots', 'Over 1,000 killed; his role fiercely contested.'),
    ('2012', 'SIT closure report', 'No prosecutable evidence found against him.'),
    ('2014', 'Becomes Prime Minister', 'BJP wins 282 seats — first majority since 1984.'),
    ('2016', 'Demonetisation', '86% of currency voided overnight; disputed effects.'),
    ('2017', 'GST launched', '"One nation, one tax," from 1 July.'),
    ('2019', 'Re-elected; Article 370', '303 seats; J&K special status revoked in August.'),
    ('2019', 'CAA passed', 'Citizenship law; nationwide protests follow.'),
    ('2020', 'COVID lockdown', 'Strict lockdown; deadly 2021 second wave.'),
    ('2021', 'Farm laws repealed', 'Rare reversal after a year-long protest.'),
    ('2022', 'Supreme Court on 2002', 'Zakia Jafri plea against Modi dismissed.'),
    ('2023', 'G20 presidency', 'New Delhi summit; African Union admitted.'),
    ('2024', 'Third term, coalition', 'BJP wins 240 — short of a majority.'),
]

MASTER = [
    {'year': '1950', 'age': 'born', 'phase': 'Early Life', 'title': 'Born in Vadnagar', 'desc': 'A tea-seller’s son in Gujarat.'},
    {'year': '1971', 'age': 'age 21', 'phase': 'Early Life', 'title': 'RSS pracharak', 'desc': 'Full-time cadre of the Sangh.'},
    {'year': '2001', 'age': 'age 51', 'phase': 'Gujarat', 'title': 'Gujarat CM', 'desc': 'Takes charge on 7 October.'},
    {'year': '2002', 'age': 'age 51', 'phase': 'Gujarat', 'title': 'Gujarat riots', 'desc': 'The defining controversy.'},
    {'year': '2014', 'age': 'age 63', 'phase': 'First Term', 'title': 'Prime Minister', 'desc': '282 seats; sworn in 26 May.'},
    {'year': '2016', 'age': 'age 66', 'phase': 'First Term', 'title': 'Demonetisation', 'desc': 'Currency voided overnight.'},
    {'year': '2019', 'age': 'age 68', 'phase': 'Second Term', 'title': 'Re-elected; Art. 370', 'desc': '303 seats; J&K reorganised.'},
    {'year': '2020', 'age': 'age 69', 'phase': 'Second Term', 'title': 'COVID-19', 'desc': 'Lockdown and second wave.'},
    {'year': '2023', 'age': 'age 72', 'phase': 'Third Term', 'title': 'G20 presidency', 'desc': 'New Delhi summit.'},
    {'year': '2024', 'age': 'age 73', 'phase': 'Third Term', 'title': 'Third term, coalition', 'desc': 'BJP short of a majority.'},
]

SOURCES = [
    ('Wikipedia — Narendra Modi', 'https://en.wikipedia.org/wiki/Narendra_Modi'),
    ('Britannica — Narendra Modi', 'https://www.britannica.com/biography/Narendra-Modi'),
    ('Wikipedia — 2002 Gujarat riots', 'https://en.wikipedia.org/wiki/2002_Gujarat_riots'),
    ('BBC — Zakia Jafri riots plea against Modi rejected (2022)', 'https://www.bbc.com/news/world-asia-india-61920218'),
    ('Britannica — Indian Lok Sabha elections of 2024', 'https://www.britannica.com/event/Indian-Lok-Sabha-elections-of-2024'),
    ('Reuters — Modi returns for third term with coalition (2024)', 'https://www.reuters.com/world/india/'),
    ('AP — India G20 summit New Delhi declaration (2023)', 'https://apnews.com/hub/g20-summit'),
]

def build_meta():
    return {
        'pid': 'gm-modi.html', 'kind': 'man', 'emoji': '🪷', 'accent': AC,
        'name': 'Narendra Modi', 'years': 'b. 1950', 'group': 'Independence & Nation-Building',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'India’s 14th Prime Minister — a Gujarat organiser turned dominant and polarising national leader, whose decade in power spans landmark reforms and bitterly contested episodes, presented here strictly factually with all sides attributed.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'roots', 'label': '1 · Early Life', 'type': 'timeline',
             'intro': 'Born in 1950 to a family of modest means in Vadnagar, Modi is shaped from boyhood by the RSS and rises through the BJP as a backroom organiser rather than an elected leader.', 'events': PHASE_ROOTS},
            {'id': 'gujarat', 'label': '2 · Gujarat', 'type': 'timeline',
             'intro': 'Made Chief Minister in 2001, his thirteen years in Gujarat are defined by the fiercely contested 2002 riots, the long legal process that followed, and the debated "Gujarat model" of development.', 'events': PHASE_GUJARAT},
            {'id': 'firstterm', 'label': '3 · First Term', 'type': 'timeline',
             'intro': 'The 2014 landslide brings him to national power, where flagship welfare schemes sit alongside the disruptive shock of demonetisation and the structural reform of GST.', 'events': PHASE_FIRSTTERM},
            {'id': 'secondterm', 'label': '4 · Second Term', 'type': 'timeline',
             'intro': 'Re-elected with a larger mandate in 2019, he pursues the BJP’s core goals — Article 370 and the CAA — while facing the COVID-19 pandemic and a year-long farmers’ revolt that forces a rare reversal.', 'events': PHASE_SECONDTERM},
            {'id': 'legacy', 'label': '5 · Third Term', 'type': 'timeline',
             'intro': 'A high-profile G20 presidency precedes the 2024 election, in which the BJP falls short of a majority and Modi governs in coalition — his consequential, contested legacy still unfolding.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Encyclopaedic and major-news sources (Wikipedia, Britannica, BBC, Reuters, AP). On contested episodes the guide attributes claims to the government, supporters, critics and courts rather than adjudicating between them.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
