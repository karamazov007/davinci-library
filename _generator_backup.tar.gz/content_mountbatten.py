# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Louis Mountbatten, 1st Earl Mountbatten of Burma.
Royal-blooded sailor, wartime Supreme Commander, and the last Viceroy who presided over the birth — and the bloody partition — of independent India."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#1e3a8a'  # naval navy blue

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — ROYAL BLOOD, YOUNG SAILOR
PHASE_ROOTS = [
    E('origins', '1900', 'Born a prince, great-grandson of Queen Victoria', ['RISE', 'ORIGINS'],
      'Prince Louis of Battenberg is born on 25 June 1900 at Frogmore House, Windsor — a great-grandson of Queen Victoria through his mother Princess Victoria of Hesse — into the tight web of Europe’s royal houses, and grows up expecting a career in the Royal Navy that his father already commands.',
      svg_row('Born into Europe’s royal web', [
          {'n': 1, 'label': 'Born at Windsor, 25 June 1900', 'sub': 'Prince Louis of Battenberg', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Great-grandson of Queen Victoria', 'sub': 'through his mother, Princess Victoria of Hesse', 'color': '#7c3aed'},
          {'n': 3, 'label': 'A naval destiny assumed', 'sub': 'his father is a rising admiral', 'color': '#166534'},
      ], edge_labels=['as', 'so'], takeaway='He was born at the heart of royal Europe — kinship to kings and a naval calling were his inheritance.', accent=AC),
      bg='<b>Prince Louis of Battenberg</b> — later Louis Mountbatten — was born on <b>25 June 1900</b> at Frogmore House, Windsor, into the German-descended Battenberg branch of Europe’s royalty.',
      people='his father <b>Prince Louis of Battenberg</b>, a senior Royal Navy officer; his mother <b>Princess Victoria of Hesse</b>, a granddaughter of Queen Victoria; his royal cousins across Europe.',
      what='He was a <b>great-grandson of Queen Victoria</b>, cousin to the British and other European royal families, and grew up in a household steeped in the traditions of the <b>Royal Navy</b>.',
      crux='His life began at the <b>intersection of royalty and the sea</b> — both would define his ambitions and his opportunities.',
      conseq='Family connection and the naval profession gave him a path to power that few could match.',
      matters='Privilege opens doors — but Mountbatten would spend a lifetime proving he was more than a well-born name.'),

    E('namechange', '1914–1917', 'His father’s fall and the name “Mountbatten”', ['TRAGEDY', 'TURNING POINT'],
      'When war with Germany erupts in 1914, anti-German feeling forces his father — then First Sea Lord — to resign in disgrace over his Battenberg name, and in 1917 the family anglicises to "Mountbatten"; the boy vows to redeem the family honour by rising to the very post his father was hounded from.',
      svg_stack('A wound that set an ambition', [
          {'n': 1, 'label': 'War brings anti-German suspicion, 1914', 'sub': 'the Battenberg name becomes a liability', 'color': '#78350f'},
          {'n': 2, 'label': 'Father resigns as First Sea Lord', 'sub': 'hounded out despite loyal service', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Family anglicises to “Mountbatten”, 1917', 'sub': 'the son vows to redeem the honour', 'color': '#1e3a8a'},
      ], takeaway='His father’s humiliation planted a driving ambition — to reclaim the family’s standing at the Navy’s summit.', accent=AC),
      bg='His father, <b>Prince Louis of Battenberg</b>, rose to be <b>First Sea Lord</b>, the professional head of the Royal Navy, before the First World War.',
      people='his father, forced from office; King <b>George V</b>, who in 1917 renamed the royal house Windsor; the young Louis, watching it all.',
      what='In <b>1914</b> anti-German hysteria drove his father to <b>resign as First Sea Lord</b>; in <b>1917</b>, as the royal family shed German titles, the Battenbergs took the anglicised surname <b>“Mountbatten.”</b>',
      crux='The episode taught him how <b>fragile even royal standing could be</b> — and lit a lifelong drive to restore the family name.',
      conseq='He entered the Navy determined to reach the office his father had lost — a goal he would ultimately achieve.',
      matters='Humiliation can forge ambition — his father’s fall gave Mountbatten a personal mission that shaped his whole career.'),

    E('navycareer', '1916–1939', 'The making of a naval officer', ['RISE', 'CAREER'],
      'Mountbatten enters the Navy in the last years of the Great War, then spends the interwar decades mastering his profession — a specialist in signals and communications, ambitious, glamorous and superbly connected — steadily climbing toward the command that will make his name.',
      svg_row('Climbing the naval ladder', [
          {'n': 1, 'label': 'Joins the Royal Navy, 1916', 'sub': 'serves in the final year of the Great War', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Specialist in signals', 'sub': 'masters naval communications between the wars', 'color': '#0e7490'},
          {'n': 3, 'label': 'Ambitious and well-connected', 'sub': 'a rising, glamorous officer', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='He built real professional expertise on top of royal connection — a technician as well as a courtier.', accent=AC),
      bg='Mountbatten trained at the Royal Naval College and joined the fleet, seeing brief service at the close of the <b>First World War</b>.',
      people='his fellow officers; his wife <b>Edwina Ashley</b>, a wealthy heiress he married in 1922; the naval establishment he climbed.',
      what='Through the 1920s and 1930s he specialised in <b>naval signals and communications</b>, earning a reputation as an <b>able, driven and ambitious officer</b> with unrivalled social connections.',
      crux='He combined <b>genuine professional skill with royal glamour</b> — not merely a prince at sea, but a serious naval technician.',
      conseq='By the outbreak of the Second World War he was ready for the destroyer command that would make him famous.',
      matters='Talent plus connection is a potent mix — Mountbatten cultivated both and rose faster than either alone would allow.'),
]

# ==================================================================  PHASE 2 — WAR AT SEA AND COMBINED OPERATIONS
PHASE_WAR = [
    E('kelly', '1941', 'HMS Kelly and the making of a legend', ['BATTLE', 'TRAGEDY', 'TURNING POINT'],
      'Commanding the destroyer HMS Kelly, Mountbatten is sunk by German dive-bombers off Crete on 23 May 1941 with heavy loss of life — his conduct in the disaster, retold in Noël Coward’s film "In Which We Serve," turns a naval defeat into a national symbol of pluck and endurance.',
      svg_stack('Defeat turned into legend', [
          {'n': 1, 'label': 'Commands HMS Kelly', 'sub': 'captain of the Fifth Destroyer Flotilla', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Sunk off Crete, 23 May 1941', 'sub': 'German dive-bombers; heavy loss of life', 'color': '#b91c1c'},
          {'n': 3, 'label': '“In Which We Serve”, 1942', 'sub': 'Noël Coward’s film makes him a symbol', 'color': '#166534'},
      ], takeaway='He lost his ship but won a legend — the Kelly disaster became a celebrated tale of British grit at sea.', accent=AC),
      bg='In the war’s early years Mountbatten commanded the destroyer <b>HMS Kelly</b> and the Fifth Destroyer Flotilla in some of the fiercest fighting in home and Mediterranean waters.',
      people='the crew of the <b>Kelly</b>, many of whom died; the film-maker <b>Noël Coward</b>, who dramatised the story; the British wartime public.',
      what='On <b>23 May 1941</b>, during the <b>Battle of Crete</b>, German dive-bombers sank the Kelly; Mountbatten survived, and his conduct inspired Coward’s celebrated 1942 film <b>“In Which We Serve.”</b>',
      crux='The sinking showed his flair for <b>turning misfortune into morale</b> — a defeat reframed as a story of courage.',
      conseq='His fame soared, marking him out to Churchill for far larger responsibilities.',
      matters='Reputation is built in adversity — Mountbatten emerged from a sunk ship more celebrated than many victors.'),

    E('combinedops', '1941–1943', 'Chief of Combined Operations', ['POLITICS', 'CAREER'],
      'In October 1941 Churchill leaps Mountbatten over more senior men to lead Combined Operations — the command charged with raids and, above all, with inventing the techniques of amphibious assault that will one day put Allied armies back onto the beaches of Europe.',
      svg_row('Inventing the art of invasion', [
          {'n': 1, 'label': 'Chief of Combined Operations, Oct 1941', 'sub': 'Churchill promotes him over seniors', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Raids on occupied Europe', 'sub': 'commandos strike the enemy coast', 'color': '#a16207'},
          {'n': 3, 'label': 'Amphibious warfare pioneered', 'sub': 'techniques that will enable D-Day', 'color': '#166534'},
      ], edge_labels=['to', 'so'], takeaway='He was handed the job of learning how to invade a defended coast — the groundwork for the great landings to come.', accent=AC),
      bg='After the fall of Europe, Britain needed both to harass the occupied coast and to prepare for an eventual return in force by sea.',
      people='<b>Winston Churchill</b>, his patron; the commandos and planners of Combined Operations; the Chiefs of Staff, on whom he now sat.',
      what='In <b>October 1941</b> Churchill appointed Mountbatten <b>Chief of Combined Operations</b> — over the heads of more senior officers — to direct raids and to <b>develop the doctrine and equipment of amphibious assault</b>.',
      crux='His command was a <b>laboratory for the invasion of Europe</b> — every raid a test of how to land armies against defended shores.',
      conseq='Lessons learned under him fed directly into the planning for the Normandy landings of 1944.',
      matters='Sometimes the outsider is promoted precisely to break the mould — Mountbatten’s job was to invent, not to conserve.'),

    E('dieppe', '1942', 'The Dieppe raid — a bloody lesson', ['BATTLE', 'TRAGEDY'],
      'On 19 August 1942, Combined Operations mounts a large raid on the French port of Dieppe that ends in disaster, with catastrophic Canadian casualties — a debacle that stains Mountbatten’s record, though its defenders argue the hard lessons it taught made the later Normandy landings possible.',
      svg_compare('Dieppe — debacle or costly lesson?', {
          'head': 'The case against', 'color': '#b91c1c',
          'items': ['Nearly 60% of the raiders killed, wounded or captured', 'Canadian troops slaughtered on the beach', 'Poor planning and intelligence', 'A avoidable catastrophe on his watch'],
      }, {
          'head': 'The case for', 'color': '#166534',
          'items': ['Exposed the folly of assaulting a defended port', 'Shaped Allied amphibious doctrine', 'Fed directly into D-Day planning', 'A grim but instructive rehearsal'],
      }, verdict='Dieppe was a bloody failure — but one whose lessons, its defenders insist, saved lives on the beaches of Normandy two years later.',
         takeaway='The raid was a catastrophe; historians still argue whether its lessons justified the price paid in blood.', accent=AC),
      bg='Combined Operations planned a major daylight raid on the German-held port of <b>Dieppe</b> to test the feasibility of seizing a defended harbour.',
      people='the <b>Canadian troops</b> who bore the brunt; the planners of Combined Operations; Mountbatten, whose command mounted the raid.',
      what='On <b>19 August 1942</b> the <b>Dieppe raid</b> ended in disaster, with roughly <b>60% of the assaulting force killed, wounded or captured</b> — most of them Canadians.',
      crux='It laid bare the <b>near-impossibility of storming a defended port head-on</b> — a lesson bought at a terrible cost.',
      conseq='The failure haunted Mountbatten’s reputation, even as its findings reshaped later invasion planning.',
      matters='War learns through catastrophe — Dieppe’s dead taught the Allies how, and how not, to invade a continent.'),
]

# ==================================================================  PHASE 3 — SUPREME COMMANDER, SOUTH EAST ASIA
PHASE_SEAC = [
    E('seac', '1943', 'Supreme Allied Commander, South East Asia', ['RISE', 'TRIUMPH'],
      'In August 1943 the Allied leaders appoint the still-junior Mountbatten Supreme Allied Commander of the new South East Asia Command — a vast theatre spanning Burma, Ceylon and beyond — leapfrogging him to a role of extraordinary scope at the age of just forty-three.',
      svg_row('A young admiral, a vast command', [
          {'n': 1, 'label': 'SACSEA appointed, Aug 1943', 'sub': 'Supreme Allied Commander, South East Asia', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'A theatre from India to Burma', 'sub': 'land, sea and air under one command', 'color': '#0e7490'},
          {'n': 3, 'label': 'Charged with beating Japan', 'sub': 'reconquer Burma, reopen the road to China', 'color': '#166534'},
      ], edge_labels=['over', 'to'], takeaway='At 43 he held one of the war’s great commands — a leap that owed as much to drive and charm as to seniority.', accent=AC),
      bg='By 1943 the Allies created a unified <b>South East Asia Command (SEAC)</b> to coordinate the war against Japan across Burma and the Indian Ocean.',
      people='<b>Churchill</b> and <b>Roosevelt</b>, who backed his appointment; General <b>William Slim</b>, who commanded the fighting Fourteenth Army under him.',
      what='In <b>August 1943</b> Mountbatten became <b>Supreme Allied Commander, South East Asia</b>, responsible for a huge theatre and the reconquest of Japanese-held Burma.',
      crux='It was a command of <b>enormous scope and complexity</b> — coordinating British, Indian, American and Chinese forces across land, sea and air.',
      conseq='Under his overall command the tide in Burma turned decisively against Japan.',
      matters='Great responsibility can be thrust on the ambitious young — Mountbatten seized a command many thought beyond his years.'),

    E('burma', '1944–1945', 'The reconquest of Burma', ['BATTLE', 'TRIUMPH'],
      'Under Mountbatten’s command, Slim’s Fourteenth Army halts the Japanese at Imphal and Kohima and then drives them out of Burma, recapturing Rangoon in 1945 — a grinding campaign in some of the war’s harshest terrain that becomes one of Britain’s great land victories.',
      svg_stack('Turning the tide in the jungle', [
          {'n': 1, 'label': 'Japan halted at Imphal & Kohima', 'sub': 'the invasion of India is broken, 1944', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'The Fourteenth Army advances', 'sub': 'Slim drives the enemy back through Burma', 'color': '#0e7490'},
          {'n': 3, 'label': 'Rangoon recaptured, 1945', 'sub': 'Burma reconquered', 'color': '#166534'},
      ], takeaway='The “Forgotten Army” won a hard victory in Burma under his command — one of Britain’s finest of the war.', accent=AC),
      bg='Japan had overrun Burma in 1942 and threatened India itself; retaking it meant fighting through jungle, mountain and monsoon.',
      people='General <b>William Slim</b> and his <b>Fourteenth Army</b>; the Indian, British, African and Gurkha troops; the Japanese defenders.',
      what='Under Mountbatten’s theatre command, Japanese offensives were smashed at <b>Imphal and Kohima (1944)</b>, and the Fourteenth Army reconquered Burma, taking <b>Rangoon in 1945</b>.',
      crux='Victory came through <b>logistics, air supply and relentless pressure</b> in appalling conditions — a triumph of organisation as much as arms.',
      conseq='Burma was cleared of Japanese forces, and Mountbatten’s standing as a war leader was secured.',
      matters='The Burma campaign showed what Allied cooperation and endurance could achieve — and burnished Mountbatten’s name.'),

    E('surrender', '1945', 'The Japanese surrender at Singapore', ['TRIUMPH', 'TURNING POINT'],
      'On 12 September 1945, in the wake of Japan’s capitulation, Mountbatten presides over the formal surrender of Japanese forces in South East Asia at Singapore — a ceremony of enormous symbolic weight, reversing the humiliating British loss of the fortress in 1942.',
      svg_row('The war in the East ends', [
          {'n': 1, 'label': 'Japan capitulates, Aug 1945', 'sub': 'after the atomic bombs and Soviet entry', 'color': '#a16207'},
          {'n': 2, 'label': 'Surrender at Singapore, 12 Sep 1945', 'sub': 'Mountbatten receives the formal submission', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'A humiliation reversed', 'sub': 'the fortress lost in 1942 is regained', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='He accepted the enemy’s surrender at Singapore — the very fortress whose 1942 fall had shamed Britain.', accent=AC),
      bg='Japan surrendered in August 1945; across South East Asia its forces had to lay down their arms formally to the Allied command.',
      people='the Japanese commanders who surrendered; the Allied forces present; Mountbatten, presiding as Supreme Commander.',
      what='On <b>12 September 1945</b> at <b>Singapore</b>, Mountbatten took the <b>formal surrender of Japanese forces in South East Asia</b>, reversing the shattering British defeat there in 1942.',
      crux='The ceremony was heavy with <b>symbolism</b> — the recovery of imperial prestige lost three years earlier.',
      conseq='Mountbatten ended the war a celebrated commander, poised for the greatest and most fraught task of his life.',
      matters='Symbols matter in history — the Singapore surrender closed a circle of humiliation and vindication for Britain.'),
]

# ==================================================================  PHASE 4 — THE LAST VICEROY
PHASE_VICEROY = [
    E('viceroy', '1947', 'Appointed the last Viceroy of India', ['POLITICS', 'RISE'],
      'In February 1947 the Labour government sends Mountbatten to India as its last Viceroy, with a mandate to transfer power and extract Britain quickly from a subcontinent sliding toward chaos — arriving in Delhi in March to find Hindu–Muslim tensions at breaking point.',
      svg_row('Sent to end the Raj', [
          {'n': 1, 'label': 'Appointed Viceroy, Feb 1947', 'sub': 'the last to hold the office', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'A mandate to leave quickly', 'sub': 'Attlee wants power transferred by mid-1948', 'color': '#a16207'},
          {'n': 3, 'label': 'Arrives to a subcontinent on edge', 'sub': 'Hindu–Muslim tension near breaking point', 'color': '#b91c1c'},
      ], edge_labels=['with', 'into'], takeaway='He was sent not to hold India but to leave it — fast — as communal violence loomed.', accent=AC),
      bg='By 1947 Britain, exhausted by war, resolved to quit India; Prime Minister <b>Clement Attlee</b> set a deadline and chose Mountbatten to execute the withdrawal.',
      people='PM <b>Clement Attlee</b>, who appointed him; <b>Jawaharlal Nehru</b> and the Congress; <b>Muhammad Ali Jinnah</b> and the Muslim League.',
      what='In <b>February 1947</b> Mountbatten was named the <b>last Viceroy of India</b>, arriving in March with authority to <b>negotiate and effect the transfer of power</b> before Britain’s planned departure.',
      crux='His brief was <b>disengagement under pressure</b> — to end nearly two centuries of British rule before the situation collapsed into civil war.',
      conseq='Within months he would decide the fate of the subcontinent, its borders and its peoples.',
      matters='He inherited an almost impossible task — to dismantle an empire gracefully while communal violence gathered.'),

    E('partitionplan', '1947', 'The decision to partition — and to hurry', ['POLITICS', 'TURNING POINT'],
      'Concluding that a united India is unattainable given the Congress–League deadlock, Mountbatten adopts partition into India and Pakistan, and — in his fateful "3 June Plan" — dramatically advances independence to 15 August 1947, a timetable critics say left far too little time to manage the consequences.',
      svg_stack('Partition, at breakneck speed', [
          {'n': 1, 'label': 'A united India judged impossible', 'sub': 'Congress and the League cannot agree', 'color': '#78350f'},
          {'n': 2, 'label': 'The 3 June Plan, 1947', 'sub': 'partition into India and Pakistan', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'Independence advanced to 15 Aug 1947', 'sub': 'the timetable slashed by nearly a year', 'color': '#b91c1c'},
      ], takeaway='He chose partition and then rushed it — a speed that admirers call decisive and critics call reckless.', accent=AC),
      bg='Talks between the Congress and the Muslim League had deadlocked over whether India should remain united or be divided.',
      people='<b>Nehru</b> and <b>Patel</b> for Congress; <b>Jinnah</b> for the League, insisting on Pakistan; <b>Gandhi</b>, who opposed partition to the last.',
      what='Mountbatten accepted <b>partition into two dominions</b> and, in the <b>3 June 1947 plan</b>, brought the date of independence forward to <b>15 August 1947</b> — far sooner than the June 1948 deadline he had been given.',
      crux='He gambled that <b>speed would forestall wider collapse</b> — that a quick, clean break was safer than a slow, contested one.',
      conseq='The compressed timetable left administrators, armies and populations desperately little time to prepare.',
      matters='Timing can be as fateful as the decision itself — the haste of partition remains one of history’s most debated calls.'),

    E('radcliffe', '1947', 'The Radcliffe line', ['POLITICS', 'TRAGEDY'],
      'To divide Punjab and Bengal, a boundary commission under the London barrister Cyril Radcliffe — who had never before set foot in India — is given just weeks to draw the border, and its award, kept secret until after independence day, will slice through villages, farms and communities.',
      svg_row('A border drawn in haste', [
          {'n': 1, 'label': 'Cyril Radcliffe appointed', 'sub': 'a barrister who had never seen India', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Weeks to divide Punjab & Bengal', 'sub': 'the “Radcliffe line” is drawn on maps', 'color': '#a16207'},
          {'n': 3, 'label': 'Award withheld until after 15 Aug', 'sub': 'millions learn their fate only afterward', 'color': '#b91c1c'},
      ], edge_labels=['given', 'and'], takeaway='A stranger drew a border through a subcontinent in weeks — and its lines cut straight through living communities.', accent=AC),
      bg='Partition required a physical boundary through the mixed provinces of <b>Punjab</b> and <b>Bengal</b>, home to intermingled Hindu, Muslim and Sikh populations.',
      people='<b>Sir Cyril Radcliffe</b>, chair of the boundary commissions; the commissioners; the countless people the line would displace.',
      what='<b>Radcliffe</b>, with no prior knowledge of India, was given only <b>weeks to fix the border</b>; the <b>award was announced only after 15 August</b>, so that many awoke to find themselves on the wrong side of a new frontier.',
      crux='The boundary was drawn with <b>haste and secrecy</b>, dividing lands and peoples with a stroke that ignored the human reality on the ground.',
      conseq='Confusion over the line fed the panic and violence that engulfed Punjab in particular.',
      matters='Borders drawn on paper cut through real lives — the Radcliffe line’s haste amplified the tragedy that followed.'),
]

# ==================================================================  PHASE 5 — PARTITION, VIOLENCE AND THE DEBATE
PHASE_PARTITION = [
    E('independence', '1947', 'Freedom at midnight — and Governor-General', ['TRIUMPH', 'TURNING POINT'],
      'At the stroke of midnight on 15 August 1947, British India ends and the two dominions of India and Pakistan are born; Mountbatten stays on as independent India’s first Governor-General, a British sailor now the constitutional head of a free nation at Nehru’s invitation.',
      svg_stack('The Raj ends, two nations rise', [
          {'n': 1, 'label': 'Midnight, 15 August 1947', 'sub': 'British India ceases to exist', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'India and Pakistan are born', 'sub': 'two new dominions take their place', 'color': '#166534'},
          {'n': 3, 'label': 'First Governor-General of India', 'sub': 'Mountbatten stays on at Nehru’s request', 'color': '#7c3aed'},
      ], takeaway='He presided over the birth of two nations — and, uniquely, stayed as free India’s first head of state.', accent=AC),
      bg='The transfer of power was fixed for <b>15 August 1947</b>, ending nearly two centuries of British dominion over India.',
      people='<b>Jawaharlal Nehru</b>, India’s first Prime Minister; <b>Jinnah</b>, Pakistan’s first Governor-General; the millions celebrating freedom.',
      what='At <b>midnight on 15 August 1947</b> the dominions of <b>India and Pakistan</b> came into being, and Mountbatten became <b>independent India’s first Governor-General</b> — its constitutional head — invited by Nehru to stay.',
      crux='The moment married <b>jubilation and dread</b> — the triumph of independence shadowed by the violence already unfolding.',
      conseq='India began its life as a free nation with a former Viceroy as its ceremonial head of state.',
      matters='Endings and beginnings collided at midnight — the end of empire and the birth of two states in a single stroke.'),

    E('violence', '1947', 'The bloodshed of partition — the great debate', ['TRAGEDY', 'DEBATE'],
      'Partition unleashes one of the largest and bloodiest migrations in history — up to fifteen million uprooted and hundreds of thousands to a million or more killed in communal massacres, above all in Punjab — and historians remain sharply divided over how much blame Mountbatten’s haste deserves.',
      svg_compare('Was Mountbatten’s haste to blame?', {
          'head': 'The critics', 'color': '#b91c1c',
          'items': ['His rushed timetable left no time to plan an orderly transfer', 'Troops and administration were unready to keep order', 'The secret, hurried Radcliffe line spread panic', 'Wolpert, Roberts and others call it a “shameful flight”'],
      }, {
          'head': 'The defenders', 'color': '#166534',
          'items': ['Communal violence was already raging before he arrived', 'Any delay might have meant outright civil war', 'Nehru, Patel and even Jinnah praised his fairness', 'Ziegler and others argue no one could have avoided bloodshed'],
      }, verdict='Historians divide sharply: critics blame his haste for compounding the carnage; defenders hold that partition’s violence was largely beyond any viceroy’s power to prevent.',
         takeaway='The verdict on Mountbatten turns on one question — whether speed caused the bloodshed, or merely failed to stop what was already coming.', accent=AC),
      bg='The division of Punjab and Bengal set off a vast, panicked exchange of populations across the new borders amid communal terror.',
      people='the uprooted Hindus, Muslims and Sikhs; critics such as <b>Stanley Wolpert</b> and <b>Andrew Roberts</b>; defenders such as his biographer <b>Philip Ziegler</b>; contemporaries like <b>V.P. Menon</b>.',
      what='Partition displaced perhaps <b>10–15 million people</b> and killed <b>hundreds of thousands — by some estimates up to a million</b> — in massacres concentrated in Punjab; historians still <b>fiercely debate Mountbatten’s share of responsibility</b>.',
      crux='The dispute is over <b>causation</b>: did his rushed timetable ignite the slaughter, or was communal fury already beyond containment?',
      conseq='The trauma of 1947 scarred the subcontinent for generations and shaped India–Pakistan relations ever after.',
      matters='History rarely delivers a clean verdict — Mountbatten’s partition is a case study in weighing decision against circumstance.'),

    E('departure', '1948', 'Leaving India', ['POLITICS', 'CAREER'],
      'His work done, Mountbatten steps down as Governor-General in June 1948, having grown genuinely close to Nehru and the new Indian leadership — and departs a subcontinent transformed, admired by many Indians even as the wounds of partition still bleed.',
      svg_row('The last Viceroy departs', [
          {'n': 1, 'label': 'Steps down, June 1948', 'sub': 'India gets its own Governor-General', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Close to Nehru and the new India', 'sub': 'warm ties with the leadership he handed to', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Leaves a transformed subcontinent', 'sub': 'admired by many, blamed by some', 'color': '#166534'},
      ], edge_labels=['as', 'and'], takeaway='He left India on warm terms with its new rulers — his legacy there both cherished and contested.', accent=AC),
      bg='With independent India established and its government functioning, the need for a British Governor-General passed.',
      people='<b>Nehru</b>, his close friend; <b>C. Rajagopalachari</b>, who succeeded him as Governor-General; his wife <b>Edwina</b>, herself beloved for her relief work.',
      what='Mountbatten <b>relinquished the office in June 1948</b>, having forged a genuine bond with Nehru’s government, and returned to Britain and his naval career.',
      crux='He left with <b>unusual goodwill</b> from the leaders of the nation he had helped set free — a rare closeness for a departing imperial official.',
      conseq='He resumed his climb in the Royal Navy, still pursuing the office his father had lost.',
      matters='Departures reveal relationships — that free India’s leaders held him in affection speaks to more than partition’s bitterness.'),
]

# ==================================================================  PHASE 6 — HEIGHTS, LEGACY AND A VIOLENT END
PHASE_END = [
    E('firstsealord', '1955', 'First Sea Lord — redeeming his father', ['TRIUMPH', 'CAREER'],
      'In 1955 Mountbatten reaches the summit of the Royal Navy as First Sea Lord — the very post from which his father had been driven in disgrace forty years before — closing a circle of family honour that had shaped his ambition since boyhood.',
      svg_stack('The summit, and a family debt paid', [
          {'n': 1, 'label': 'First Sea Lord, 1955', 'sub': 'professional head of the Royal Navy', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'His father’s lost office regained', 'sub': 'the post taken from him in 1914', 'color': '#7c3aed'},
          {'n': 3, 'label': 'A boyhood vow fulfilled', 'sub': 'the family honour restored', 'color': '#166534'},
      ], takeaway='He achieved the goal that had driven him for decades — the very office his father was forced to surrender.', accent=AC),
      bg='After India, Mountbatten resumed a distinguished naval career, rising through the fleet’s senior commands.',
      people='his father’s memory, which had inspired the ambition; the naval establishment; the political leaders he served.',
      what='In <b>1955</b> he became <b>First Sea Lord and Chief of the Naval Staff</b> — the post his father had been hounded from in 1914 — serving until 1959.',
      crux='It was a deeply <b>personal vindication</b> — the fulfilment of the vow made when his father fell.',
      conseq='From there he rose to the newly powerful role of Chief of the Defence Staff.',
      matters='Some ambitions are inherited debts — Mountbatten spent a career repaying his father’s humiliation.'),

    E('cds', '1959–1965', 'Chief of the Defence Staff', ['POLITICS', 'REFORM'],
      'From 1959 Mountbatten serves as Chief of the Defence Staff, the professional head of all Britain’s armed forces, using the role to press through a controversial unification of the separate service ministries into a single Ministry of Defence.',
      svg_row('Reshaping Britain’s military', [
          {'n': 1, 'label': 'Chief of the Defence Staff, 1959', 'sub': 'head of all three armed services', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Pushes unification of the services', 'sub': 'one Ministry of Defence, not three', 'color': '#a16207'},
          {'n': 3, 'label': 'Reform against resistance', 'sub': 'controversial, but largely achieved', 'color': '#166534'},
      ], edge_labels=['to', 'and'], takeaway='At the top of Britain’s military he forced through a lasting reorganisation of its defence machinery.', accent=AC),
      bg='Britain’s armed forces were run by separate service departments, and reformers pressed for a more unified command structure.',
      people='the government ministers he worked with; the service chiefs, some resistant to change; his own driving personality.',
      what='As <b>Chief of the Defence Staff (1959–1965)</b>, Mountbatten championed the <b>unification of the service ministries into a single Ministry of Defence</b>, a major and contested reform.',
      crux='He used the post to <b>modernise and centralise</b> Britain’s defence organisation, overriding entrenched service rivalries.',
      conseq='The reformed structure shaped British defence administration for decades afterward.',
      matters='Institutions resist reform — Mountbatten’s force of will pushed through a reorganisation others had shirked.'),

    E('assassination', '1979', 'Murdered by the IRA at Mullaghmore', ['DEATH', 'TRAGEDY', 'TURNING POINT'],
      'On 27 August 1979, on holiday in Ireland, Mountbatten is killed when the Provisional IRA detonates a bomb hidden aboard his boat Shadow V off Mullaghmore, County Sligo — a murder that also claims his young grandson and two others, and shocks Britain and the world.',
      svg_stack('A violent end off the Irish coast', [
          {'n': 1, 'label': 'Holidaying at Mullaghmore', 'sub': 'County Sligo, Ireland, August 1979', 'color': '#0e7490'},
          {'n': 2, 'label': 'IRA bomb aboard Shadow V', 'sub': 'detonated by radio, 27 Aug 1979', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Mountbatten and three others killed', 'sub': 'including his 14-year-old grandson', 'color': '#78350f'},
      ], takeaway='The Provisional IRA killed him with a bomb on his own boat — a war hero murdered on a summer holiday.', accent=AC),
      bg='Mountbatten holidayed each summer at Classiebawn Castle near <b>Mullaghmore</b>, in the Republic of Ireland, amid the violence of the Northern Ireland Troubles.',
      people='the <b>Provisional IRA</b>, which claimed the killing; his grandson <b>Nicholas Knatchbull (14)</b>, boat-hand <b>Paul Maxwell (15)</b> and the <b>Dowager Lady Brabourne</b>, also killed.',
      what='On <b>27 August 1979</b> the IRA detonated a <b>radio-controlled bomb aboard his boat “Shadow V”</b>; Mountbatten, then 79, was <b>killed along with three others</b>, including a grandson.',
      crux='The murder was a <b>deliberate strike at the Crown</b> — killing a member of the royal family to shock and to publicise the IRA’s cause.',
      conseq='He was given a ceremonial funeral he had planned himself; the killing hardened attitudes in the Troubles.',
      matters='Terror seeks symbols — the IRA murdered an old man and a boy to strike at the British state through its royal blood.'),

    E('legacy', '1979–', 'The measure of Mountbatten', ['LEGACY', 'DEBATE'],
      'Mountbatten leaves a contested legacy — royal sailor, wartime commander, and the man who ended the British Raj — celebrated for his energy, charm and vision, and criticised for vanity, self-promotion and above all the haste of partition, remembered as one of the twentieth century’s most consequential Britons.',
      svg_compare('A divided verdict', {
          'head': 'The admiring view', 'color': '#166534',
          'items': ['A brave and inventive wartime commander', 'Ended the Raj with speed and skill', 'Warmly trusted by India’s new leaders', 'Energetic reformer of Britain’s defences'],
      }, {
          'head': 'The critical view', 'color': '#b91c1c',
          'items': ['Vain, ambitious and a relentless self-promoter', 'Dieppe and partition mar his record', 'Rushed a boundary that cost countless lives', 'Charm sometimes outran competence'],
      }, verdict='Few careers are so celebrated and so criticised at once — Mountbatten was at once a hero of his age and a byword for the perils of haste.',
         takeaway='He remains a study in contrasts — dazzling gifts and glaring flaws, triumph and tragedy bound together.', accent=AC),
      bg='Mountbatten’s life spanned the height and the dismantling of the British Empire, and few figures were so central to both.',
      people='the historians who praise and damn him; the Indians who remember him warmly; the critics of empire and partition.',
      what='His legacy is <b>fiercely contested</b> — hailed as a <b>bold commander and skilful liquidator of empire</b>, condemned as <b>vain and dangerously hasty</b>, above all over partition.',
      crux='The debate captures a <b>genuine duality</b> — real gifts of leadership and vision, alongside real flaws of vanity and haste.',
      conseq='He endures as one of the most discussed and divisive Britons of the twentieth century.',
      matters='Great lives resist simple verdicts — Mountbatten’s force and flaws alike shaped the century he lived through.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Louis Mountbatten was a royal-blooded sailor who became one of the twentieth century’s most consequential — and most argued-over — Britons. A great-grandson of Queen Victoria, he redeemed his father’s wartime disgrace by rising to command the destroyer HMS Kelly, then Combined Operations, then a vast Allied theatre in South East Asia. As the last Viceroy of India he ended the British Raj and presided over the birth — and the bloody partition — of India and Pakistan, before crowning his naval career as First Sea Lord and dying at the hands of an IRA bomb. He is the ultimate study in <b>dazzling gifts, driving ambition, and the perils of haste.</b></p>
<div class="ov-quote">“I am not by nature a modest man.”<span>— a remark attributed to Mountbatten</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born a prince and great-grandson of Victoria → redeems his father’s fall by winning fame on HMS Kelly and leading Combined Operations → becomes Supreme Commander in South East Asia and takes Japan’s surrender at Singapore → is sent as the last Viceroy to end the Raj → chooses partition and rushes independence to 15 August 1947 → presides over freedom and appalling communal bloodshed as first Governor-General → reaches the summit of the Navy and is finally murdered by the IRA in 1979.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⚓</div><h4>A fighting sailor</h4><p>HMS Kelly, Combined Operations and victory in Burma made his name.</p></div>
  <div class="ov-card"><div class="i">🏛️</div><h4>Liquidator of empire</h4><p>The last Viceroy who ended nearly two centuries of British rule.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>The partition debate</h4><p>Did his haste cause the bloodshed, or merely fail to stop it?</p></div>
  <div class="ov-card"><div class="i">💥</div><h4>A violent end</h4><p>Murdered by an IRA bomb — a symbol struck down in 1979.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Royal Sailor</b><small> 1900–1939</small><p>Royal birth, his father’s fall, and the making of an officer.</p></div>
  <div><b>2 · War at Sea</b><small> 1939–1943</small><p>HMS Kelly, Combined Operations, and the Dieppe raid.</p></div>
  <div><b>3 · Supreme Commander</b><small> 1943–1945</small><p>SEAC, the reconquest of Burma, Japan’s surrender.</p></div>
  <div><b>4 · The Last Viceroy</b><small> 1947</small><p>Partition, the rushed timetable, and the Radcliffe line.</p></div>
  <div><b>5 · Freedom &amp; Blood</b><small> 1947–1948</small><p>Independence, the massacres, and the great debate.</p></div>
  <div><b>6 · Heights &amp; End</b><small> 1948–1979</small><p>First Sea Lord, defence reform, and murder in Ireland.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references. The partition chapters present the historians’ debate <b>even-handedly</b>, laying out both the case against Mountbatten and the case for him.</p>
"""

WHO = [
    {'name': 'Edwina Mountbatten', 'role': 'wife & partner', 'color': '#7c3aed',
     'bio': 'The wealthy heiress Mountbatten married in 1922, who became Vicereine and won admiration in India for her tireless relief and welfare work during partition.',
     'rel': 'His wife, whose own standing in India strengthened his bond with its leaders.'},
    {'name': 'Winston Churchill', 'role': 'wartime patron', 'color': '#1e3a8a',
     'bio': 'The Prime Minister who leapt Mountbatten over senior officers to lead Combined Operations and then South East Asia Command.',
     'rel': 'The patron who gave him his great wartime commands.'},
    {'name': 'Jawaharlal Nehru', 'role': "India's first PM", 'color': '#166534',
     'bio': 'The Congress leader and first Prime Minister of India, who became a close friend and invited Mountbatten to stay as free India’s first Governor-General.',
     'rel': 'The Indian leader he handed power to — and grew genuinely close to.'},
    {'name': 'Muhammad Ali Jinnah', 'role': 'League leader', 'color': '#a16207',
     'bio': 'The founder of Pakistan, whose insistence on a separate Muslim state made partition, in Mountbatten’s judgement, unavoidable.',
     'rel': 'The leader whose demand for Pakistan drove the decision to partition.'},
    {'name': 'Sir Cyril Radcliffe', 'role': 'boundary chairman', 'color': '#b91c1c',
     'bio': 'The London barrister with no prior knowledge of India who was given weeks to draw the border dividing Punjab and Bengal.',
     'rel': 'The man who drew the fateful partition line under Mountbatten’s timetable.'},
    {'name': 'General William Slim', 'role': 'field commander', 'color': '#0e7490',
     'bio': 'The commander of the Fourteenth Army, the “Forgotten Army,” which under Mountbatten’s theatre command reconquered Burma from Japan.',
     'rel': 'The general who won the Burma campaign beneath his command.'},
]

KEY_EVENTS = [
    ('1900', 'Born at Windsor', 'A great-grandson of Queen Victoria.'),
    ('1917', 'Family renamed Mountbatten', 'After his father’s wartime fall.'),
    ('1941', 'HMS Kelly sunk off Crete', 'The basis of “In Which We Serve.”'),
    ('1942', 'Dieppe raid', 'A bloody debacle, and a costly lesson.'),
    ('1943', 'Supreme Commander, SEAC', 'The vast South East Asia theatre.'),
    ('1945', 'Japanese surrender at Singapore', 'A 1942 humiliation reversed.'),
    ('1947', 'Last Viceroy of India', 'Sent to end the British Raj.'),
    ('1947', 'Partition; independence 15 Aug', 'The date advanced by nearly a year.'),
    ('1947', 'First Governor-General of India', 'At Nehru’s invitation.'),
    ('1955', 'First Sea Lord', 'His father’s lost office regained.'),
    ('1979', 'Murdered by the IRA', 'A bomb on his boat at Mullaghmore.'),
]

MASTER = [
    {'year': '1900', 'age': 'born', 'phase': 'Royal Sailor', 'title': 'Born at Windsor', 'desc': 'Great-grandson of Victoria.'},
    {'year': '1917', 'age': 'age 17', 'phase': 'Royal Sailor', 'title': 'Name “Mountbatten”', 'desc': 'After his father’s fall.'},
    {'year': '1941', 'age': 'age 40', 'phase': 'War at Sea', 'title': 'HMS Kelly sunk', 'desc': 'A defeat becomes a legend.'},
    {'year': '1942', 'age': 'age 42', 'phase': 'War at Sea', 'title': 'Dieppe raid', 'desc': 'A bloody, instructive failure.'},
    {'year': '1943', 'age': 'age 43', 'phase': 'Supreme Commander', 'title': 'SACSEA', 'desc': 'A vast Allied command.'},
    {'year': '1945', 'age': 'age 45', 'phase': 'Supreme Commander', 'title': 'Singapore surrender', 'desc': 'Japan capitulates in the East.'},
    {'year': '1947', 'age': 'age 46', 'phase': 'Last Viceroy', 'title': 'Viceroy & partition', 'desc': 'Independence set for 15 August.'},
    {'year': '1947', 'age': 'age 47', 'phase': 'Freedom & Blood', 'title': 'Governor-General', 'desc': 'Freedom amid mass bloodshed.'},
    {'year': '1955', 'age': 'age 54', 'phase': 'Heights & End', 'title': 'First Sea Lord', 'desc': 'His father’s office regained.'},
    {'year': '1979', 'age': 'age 79', 'phase': 'Heights & End', 'title': 'Killed by the IRA', 'desc': 'A bomb at Mullaghmore.'},
]

SOURCES = [
    ('Wikipedia — Louis Mountbatten, 1st Earl Mountbatten of Burma', 'https://en.wikipedia.org/wiki/Louis_Mountbatten,_1st_Earl_Mountbatten_of_Burma'),
    ('Britannica — Louis Mountbatten', 'https://www.britannica.com/biography/Louis-Mountbatten-1st-Earl-Mountbatten-of-Burma'),
    ('Royal Navy — 80 years since the loss of HMS Kelly off Crete', 'https://www.royalnavy.mod.uk/news/2021/may/23/20210523-hms-kelly'),
    ('National Army Museum — Independence and Partition, 1947', 'https://www.nam.ac.uk/explore/independence-and-partition-1947'),
    ('Wikipedia — In Which We Serve', 'https://en.wikipedia.org/wiki/In_Which_We_Serve'),
    ('The Conversation — How a British royal’s errors made partition more painful', 'https://theconversation.com/how-a-british-royals-monumental-errors-made-indias-partition-more-painful-81657'),
    ('History Reclaimed — Mountbatten and Indian Independence: The Verdict of 1947', 'https://historyreclaimed.co.uk/mountbatten-indian-independence/'),
]

def build_meta():
    return {
        'pid': 'gm-mountbatten.html', 'kind': 'man', 'emoji': '⚓', 'accent': AC,
        'name': 'Louis Mountbatten', 'years': '1900–1979', 'group': 'Independence & Nation-Building',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The royal-blooded sailor and wartime Supreme Commander who, as the last Viceroy of India, ended the British Raj and presided over the birth — and the bloody partition — of India and Pakistan, before dying at the hands of an IRA bomb.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'roots', 'label': '1 · Royal Sailor', 'type': 'timeline',
             'intro': 'A great-grandson of Queen Victoria, born to the sea, who is shaped by his father’s wartime disgrace and the family’s renaming to “Mountbatten.”', 'events': PHASE_ROOTS},
            {'id': 'war', 'label': '2 · War at Sea', 'type': 'timeline',
             'intro': 'On HMS Kelly he turns a sinking into a legend, then as Chief of Combined Operations invents the art of amphibious assault — at a terrible cost at Dieppe.', 'events': PHASE_WAR},
            {'id': 'seac', 'label': '3 · Supreme Commander', 'type': 'timeline',
             'intro': 'As Supreme Allied Commander in South East Asia he oversees the reconquest of Burma and takes the Japanese surrender at Singapore.', 'events': PHASE_SEAC},
            {'id': 'viceroy', 'label': '4 · The Last Viceroy', 'type': 'timeline',
             'intro': 'Sent to end the Raj, he chooses partition, advances independence to 15 August 1947, and sets a stranger to draw the border in weeks.', 'events': PHASE_VICEROY},
            {'id': 'partition', 'label': '5 · Freedom & Blood', 'type': 'timeline',
             'intro': 'Two nations are born at midnight — and drowned in communal bloodshed. This chapter lays out, even-handedly, the historians’ debate over his haste.', 'events': PHASE_PARTITION},
            {'id': 'end', 'label': '6 · Heights & End', 'type': 'timeline',
             'intro': 'He crowns his naval career as First Sea Lord and reshapes Britain’s defences — before an IRA bomb ends his life on an Irish holiday in 1979.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; the partition chapters present both the critical and the defending readings of Mountbatten’s role, as the historiography remains genuinely divided.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
