# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Patanjali.
The ancient sage credited with the Yoga Sūtras — foundational text of classical yoga — and, by tradition, a great grammar commentary and a medical work."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b45309'  # deep saffron / turmeric gold

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAN & THE MYSTERY
PHASE_MYSTERY = [
    E('who', 'antiquity', 'A name, a text, and almost no biography', ['ORIGINS', 'IDEAS'],
      'Patanjali is one of the most influential figures in Indian thought and one of the most shadowy — a name attached to the Yoga Sūtras and, by tradition, to a grammar commentary and a medical work, yet with virtually no reliable biography, so that the man survives almost entirely through the texts that bear his name.',
      svg_stack('The sage we know only through his books', [
          {'n': 1, 'label': 'A revered but faceless author', 'sub': 'no reliable life-story survives', 'color': '#b45309'},
          {'n': 2, 'label': 'Known through attributed texts', 'sub': 'Yoga Sūtras, a grammar commentary, a medical work', 'color': '#3730a3'},
          {'n': 3, 'label': 'The work outlives the man', 'sub': 'his ideas shape yoga to the present day', 'color': '#166534'},
      ], takeaway='Patanjali is less a documented person than a name that carries a body of foundational thought.', accent=AC),
      bg='<b>Patanjali</b> is traditionally credited as the author of the <b>Yoga Sūtras</b>, the foundational text of the Yoga school (darśana) of Hindu philosophy — but almost nothing about his life is historically certain.',
      people='the later commentators (above all <b>Vyāsa</b>) who preserved and interpreted him; the traditional lineages that revere him as a founding sage.',
      what='The name Patanjali is attached to as many as <b>three great works</b> — the Yoga Sūtras, the <b>Mahābhāṣya</b> grammar commentary, and a lost medical text — yet the biographical record is essentially <b>blank</b>, and even his dates are fiercely disputed.',
      crux='What we call "Patanjali" is <b>a textual tradition more than a knowable man</b> — reputation reconstructed backward from surviving books.',
      conseq='This near-total absence of biography left room for legend to fill the void, and for scholars to argue over how many people the name conceals.',
      matters='It is a striking case of influence without biography — the ideas mattered so much that the author almost disappeared behind them.'),

    E('dating', 'c. 2nd c. BCE / 2nd–4th c. CE', 'The dating debate', ['IDEAS', 'DEBATE'],
      'Two very different Patanjalis compete in the sources — a grammarian firmly dated to the mid-2nd century BCE, author of the Mahābhāṣya, and the author of the Yoga Sūtras, whom most scholars place centuries later, around the 2nd to 4th century CE — a gap of hundreds of years that lies at the heart of the puzzle of his identity.',
      svg_compare('Two Patanjalis, centuries apart', {
          'head': 'The grammarian', 'color': '#3730a3',
          'items': ['Author of the Mahābhāṣya', 'Firmly dated to mid-2nd century BCE', 'Comments on Pāṇini and Kātyāyana', 'Well anchored in the record'],
      }, {
          'head': 'The Yoga Sūtra author', 'color': '#b45309',
          'items': ['Author of the Yoga Sūtras', 'Dated c. 2nd–4th century CE', 'Draws on Sāṃkhya and Buddhist ideas', 'Maas proposes c. 400 CE'],
      }, verdict='The grammarian is securely 2nd c. BCE; the yoga author is generally placed centuries later — hence the debate.',
         takeaway='The "when" of Patanjali splits into two very different answers depending on which work you mean.', accent=AC),
      bg='Dates offered for the Yoga Sūtras range widely — from the 2nd century BCE to the 5th century CE — while the grammarian Patanjali of the <b>Mahābhāṣya</b> is dated with confidence to the <b>mid-2nd century BCE</b>.',
      people='the scholar <b>Philipp A. Maas</b>, who places the Yoga Sūtras around 400 CE by synchronism with the Buddhist philosopher Vasubandhu; earlier Indologists such as Louis Renou.',
      what='Most modern scholars narrow the Yoga Sūtras to <b>the 2nd–4th century CE</b>, centuries after the securely 2nd-century-BCE grammarian — a chronological gap that makes it hard to see them as one man.',
      crux='The evidence points to <b>two separated moments</b> — an early grammarian and a later yoga author — not a single lifetime.',
      conseq='This gap became the central argument that the two great "Patanjali" texts were written by different people.',
      matters='Precise dating turns a devotional certainty ("the sage Patanjali") into a genuine historical problem.'),

    E('oneormany', 'scholarly debate', 'One Patanjali, or several?', ['IDEAS', 'DEBATE'],
      'Tradition treats Patanjali as a single polymath sage who mastered grammar, yoga, and medicine — but modern scholarship, noting sharp differences of language and centuries of distance, generally holds that at least two different authors share the name, even as traditional yoga culture continues to celebrate one all-encompassing Patanjali.',
      svg_row('Did one man write it all?', [
          {'n': 1, 'label': 'The traditional view', 'sub': 'one sage — grammar, yoga and medicine', 'color': '#b45309'},
          {'n': 2, 'label': 'The scholarly objection', 'sub': 'different language, grammar and dates', 'color': '#3730a3'},
          {'n': 3, 'label': 'Likely several authors', 'sub': 'a shared name, not a shared man', 'color': '#166534'},
      ], edge_labels=['but', 'so'], takeaway='Devotion sees one Patanjali; scholarship sees a name reused across centuries and subjects.', accent=AC),
      bg='By tradition the same Patanjali is said to have "purified" three domains — <b>speech</b> (grammar), <b>mind</b> (yoga) and <b>body</b> (medicine) — a neat symbolic claim of one all-mastering sage.',
      people='<b>Louis Renou</b>, who demonstrated significant differences in language, grammar and vocabulary between the works; the 11th-century king <b>Bhoja</b>, among the first to conflate the authors.',
      what='Scholars note that <b>no known text merged the identities before about the 11th century</b>, and that the Yoga Sūtras and Mahābhāṣya differ markedly — so the modern consensus is that they were <b>likely different authors</b>, though some still argue for one.',
      crux='The single-genius Patanjali is largely a <b>later devotional synthesis</b>, not an established historical fact.',
      conseq='"Patanjali" is best read as a revered name that gathered several distinct works and reputations over time.',
      matters='It shows how tradition tidies messy history into a single luminous figure — and how scholarship gently unpicks it.'),

    E('serpent', 'tradition / legend', 'The legend of the fallen serpent', ['LEGEND', 'ORIGINS'],
      'Where history is silent, myth speaks — tradition holds that Patanjali was an incarnation of Ādiśeṣa, the thousand-headed cosmic serpent on whom Vishnu reclines, who fell from the heavens as a tiny snake into the cupped palms of a yogini named Gonikā; from "pata" (fallen) and "añjali" (joined palms) comes his very name.',
      svg_stack('A myth to fill the silence (tradition)', [
          {'n': 1, 'label': 'Ādiśeṣa, the cosmic serpent', 'sub': 'the thousand-headed naga on whom Vishnu rests', 'color': '#3730a3'},
          {'n': 2, 'label': 'Falls into Gonikā’s cupped palms', 'sub': 'a tiny snake descends as she prays (añjali mudrā)', 'color': '#b45309'},
          {'n': 3, 'label': '"Pata" (fallen) + "añjali" (palms)', 'sub': 'the name Patañjali — sacred knowledge descended', 'color': '#166534'},
      ], takeaway='The legend reads his name as a story — divine wisdom "falling" from heaven into human hands.', accent=AC),
      bg='Because no biography survives, later tradition supplied a <b>mythic origin</b> for Patanjali, tying his name to a story of divine descent. This is <b>legend, not history</b>.',
      people='<b>Ādiśeṣa (Ananta)</b>, the cosmic serpent of Vishnu; the yogini <b>Gonikā</b>, who prays for a worthy disciple; iconographers who depict Patanjali as half-human, half-serpent.',
      what='In the tale, Ādiśeṣa is granted a human birth to teach yoga; he descends as a small snake into <b>Gonikā’s palms</b> as she offers prayer, and is named <b>Patañjali</b> — "the one who fell (pata) into the joined palms (añjali)." He is often shown with a <b>coiled serpent’s lower body and a hood of snakes</b>.',
      crux='The myth encodes a claim about the <b>Sūtras themselves</b> — that they are revealed, cosmic knowledge, not mere human invention.',
      conseq='The serpent imagery became Patanjali’s standard iconography, recited before yoga practice in a traditional invocation.',
      matters='Legends often do the work biography cannot — dignifying a text by giving its author a divine origin.'),
]

# ==================================================================  PHASE 2 — THE GRAMMARIAN
PHASE_GRAMMAR = [
    E('mahabhashya', 'c. 150 BCE', 'The Mahābhāṣya — the "Great Commentary"', ['IDEAS', 'TEXT'],
      'The Patanjali of the 2nd century BCE wrote the Mahābhāṣya, the "Great Commentary" on Pāṇini’s grammar — defending the master against his critic Kātyāyana while probing the deep questions of language, a work so authoritative that with it, as scholars say, the Indian science of language reached its definitive form.',
      svg_row('Grammar reaches its classical form', [
          {'n': 1, 'label': 'Pāṇini’s Aṣṭādhyāyī', 'sub': 'the great rule-grammar of Sanskrit', 'color': '#3730a3'},
          {'n': 2, 'label': 'Kātyāyana’s Vārttikas', 'sub': 'critical notes on Pāṇini’s rules', 'color': '#a16207'},
          {'n': 3, 'label': 'Patanjali’s Mahābhāṣya', 'sub': 'the "Great Commentary" that settles the field', 'color': '#b45309'},
      ], edge_labels=['queried by', 'answered by'], takeaway='Patanjali the grammarian crowned a three-sage tradition — Pāṇini, Kātyāyana, Patanjali.', accent=AC),
      bg='The <b>Mahābhāṣya</b> is a commentary on selected rules of Pāṇini’s grammar, the <b>Aṣṭādhyāyī</b>, together with the <b>Vārttikas</b> (critical notes) of <b>Kātyāyana</b>. It is dated to about the 2nd century BCE.',
      people='<b>Pāṇini</b>, the founding grammarian; <b>Kātyāyana</b>, whose critical notes survive largely through Patanjali; the tradition that ranks these three as Sanskrit’s greatest grammarians.',
      what='Patanjali’s work both <b>defends Pāṇini against Kātyāyana’s objections</b> and refines the grammar itself; the surviving text covers <b>1,228 of the Aṣṭādhyāyī’s 3,981 sūtras</b>, arranged in eighty-five daily lessons.',
      crux='It is <b>as much a philosophy of language as a grammar</b> — treating meaning, the eternity of the word, and the nature of speech.',
      conseq='It fixed the standard of Sanskrit scholarship and preserved Kātyāyana’s otherwise-lost work.',
      matters='A commentary can outweigh what it comments on — the Mahābhāṣya became a monument of world linguistics.'),

    E('language', 'c. 2nd c. BCE', 'A philosophy of the word', ['IDEAS', 'REFORM'],
      'The Mahābhāṣya is more than technical grammar — through it Patanjali the grammarian explores what language is: how words carry meaning, whether the word is eternal, how usage and correctness relate — so that Indian language scholarship reached, in one scholar’s phrase, its definitive form in his hands.',
      svg_stack('Grammar as inquiry into meaning', [
          {'n': 1, 'label': 'Not just rules, but reflection', 'sub': 'why words mean what they mean', 'color': '#b45309'},
          {'n': 2, 'label': 'The eternal, correct word', 'sub': 'speech, usage and the nature of language', 'color': '#3730a3'},
          {'n': 3, 'label': 'Language scholarship comes of age', 'sub': 'the tradition reaches its "definitive form"', 'color': '#166534'},
      ], takeaway='Patanjali turned grammar into a philosophy of language that shaped Indian thought for two millennia.', accent=AC),
      bg='Ancient Indian grammar (<b>vyākaraṇa</b>) was regarded not as a dry discipline but as a limb of sacred learning, guarding the correct speech needed for ritual and thought.',
      people='the long line of Sanskrit grammarians and philosophers of language who built on Patanjali; later thinkers such as Bhartṛhari who developed his hints into full theories.',
      what='In discussing Pāṇini’s rules, Patanjali raised and debated <b>foundational questions</b> — the relation of word and meaning, the permanence of the word, correctness versus usage — mixing grammar proper with the <b>philosophy of grammar</b>.',
      crux='He treated language as a <b>window onto reality and mind</b>, not merely a set of forms to be catalogued.',
      conseq='His work seeded a rich Indian tradition of linguistic philosophy centuries ahead of comparable Western inquiry.',
      matters='It shows the same instinct as the yoga tradition — disciplining a faculty (speech, or mind) to reach clarity and truth.'),
]

# ==================================================================  PHASE 3 — THE YOGA SŪTRAS
PHASE_SUTRAS = [
    E('structure', 'c. 2nd–4th c. CE', 'The Yoga Sūtras — four books, ~195 aphorisms', ['TEXT', 'IDEAS'],
      'The Yoga Sūtras compress the whole science of yoga into some 195 or 196 terse aphorisms across four short books — Samādhi, Sādhana, Vibhūti, and Kaivalya — a text so condensed that almost every word is a seed needing a commentary to unfold, yet complete enough to found an entire school of philosophy.',
      svg_row('The architecture of the text', [
          {'n': 1, 'label': 'Samādhi Pāda (51)', 'sub': 'what yoga is; the states of absorption', 'color': '#b45309'},
          {'n': 2, 'label': 'Sādhana Pāda (55)', 'sub': 'the practice; kriyā and the eight limbs', 'color': '#3730a3'},
          {'n': 3, 'label': 'Vibhūti Pāda (56)', 'sub': 'the powers gained through deep discipline', 'color': '#a16207'},
          {'n': 4, 'label': 'Kaivalya Pāda (34)', 'sub': 'liberation; the isolation of the Seer', 'color': '#166534'},
      ], edge_labels=['then', 'then', 'then'], takeaway='Four short books move from what yoga is, to how to do it, to its fruits, to final freedom.', accent=AC),
      bg='The <b>Yoga Sūtras</b> (Yogasūtra) are the foundational scripture of the Yoga darśana. "Sūtra" means "thread" — each is a compressed aphorism meant to be memorised and expanded by a teacher.',
      people='the commentators who unpack the aphorisms, above all <b>Vyāsa</b>; modern teachers such as B.K.S. Iyengar who count 196, versus Vyāsa and Krishnamacharya who count 195.',
      what='The text is organised into <b>four pādas (books)</b>: <b>Samādhi</b> (51 sūtras), <b>Sādhana</b> (55), <b>Vibhūti</b> (56) and <b>Kaivalya</b> (34) — <b>195 sūtras</b> by one traditional count, <b>196</b> by another.',
      crux='Its power lies in <b>radical compression</b> — a complete system stated in a few pages of aphorisms.',
      conseq='Its brevity made it endlessly commentable, and let it be carried, memorised, across the centuries.',
      matters='The Sūtras are the skeleton on which the whole living body of classical yoga is built.'),

    E('nirodha', 'Samādhi Pāda 1.2', '"Yogaś citta-vṛtti-nirodhaḥ"', ['IDEAS', 'DEFINITION'],
      'In its second aphorism the text gives yoga its classic definition — "yogaś citta-vṛtti-nirodhaḥ," yoga is the stilling of the fluctuations of the mind — and states its whole aim: when the churning of consciousness ceases, the Seer, pure awareness itself, rests at last in its own true nature.',
      svg_stack('The definition that founds a discipline', [
          {'n': 1, 'label': 'Citta — the "mind-stuff"', 'sub': 'the restless field of consciousness', 'color': '#3730a3'},
          {'n': 2, 'label': 'Vṛtti-nirodha — stilling the waves', 'sub': 'quieting its fluctuations and turnings', 'color': '#b45309'},
          {'n': 3, 'label': 'The Seer abides in itself', 'sub': 'pure awareness (puruṣa) shines forth', 'color': '#166534'},
      ], takeaway='Yoga is defined not as posture but as the quieting of the mind so that pure awareness is revealed.', accent=AC),
      bg='The most quoted line in all yoga is sūtra <b>1.2</b>, immediately after the opening "now, the teaching of yoga" — it defines the entire enterprise.',
      people='generations of practitioners and commentators for whom this one line is the seed of the whole path; teachers who render "citta" as mind, "vṛtti" as fluctuation, "nirodha" as cessation.',
      what='<b>"Yogaś citta-vṛtti-nirodhaḥ"</b> — "yoga is the restriction (nirodha) of the fluctuations (vṛtti) of the mind (citta)." Sūtra 1.3 adds that then <b>"the Seer abides in its own nature."</b>',
      crux='Yoga is here <b>a discipline of consciousness</b> — the goal is a still mind in which the true self is no longer distorted.',
      conseq='Everything else in the text — the ethics, the breath, the postures, the meditation — serves this single aim.',
      matters='It reframes yoga at its root: not primarily exercise, but the training of attention toward liberation.'),

    E('samkhya', 'Kaivalya Pāda', 'Puruṣa and prakṛti — the Sāṃkhya frame', ['IDEAS', 'PHILOSOPHY'],
      'Patanjali’s yoga rests on the dualist metaphysics of the Sāṃkhya school — reality divided between puruṣa, pure witnessing consciousness, and prakṛti, all of nature and mind; bondage is their entanglement, and liberation is the clear discernment that the ever-free Seer was never really the changing world it took itself to be.',
      svg_compare('Two realities, one liberation', {
          'head': 'Puruṣa', 'color': '#b45309',
          'items': ['Pure consciousness / witness', 'Changeless, uninvolved awareness', 'The true Self, the "Seer"', 'Always already free'],
      }, {
          'head': 'Prakṛti', 'color': '#3730a3',
          'items': ['Nature and matter', 'Mind, intellect, ego, senses', 'Ever-changing, the "seen"', 'The field of experience'],
      }, verdict='Suffering is puruṣa mistaking itself for prakṛti; freedom is discerning the two clearly.',
         takeaway='Yoga is the practical method for a Sāṃkhya insight — separating pure awareness from all that it merely observes.', accent=AC),
      bg='Yoga is the practical twin of the older <b>Sāṃkhya</b> philosophy; where Sāṃkhya analyses reality, yoga supplies the <b>method</b> to realise it experientially.',
      people='the Sāṃkhya thinkers whose dualism Patanjali adopts; commentators who map the mind (citta) onto prakṛti and the Seer onto puruṣa.',
      what='Reality is split between <b>puruṣa</b> (pure consciousness, the witness) and <b>prakṛti</b> (nature — including the whole mental apparatus). A living being arises when puruṣa seems <b>bound up with</b> prakṛti; <b>discriminating them</b> is the key to freedom.',
      crux='The mind itself belongs to <b>nature, not to the Self</b> — so stilling the mind lets the true Self stand clear.',
      conseq='This frame gives the eight limbs their goal: to purify and quiet prakṛti until puruṣa is disentangled.',
      matters='It is one of the world’s great analyses of the difference between awareness and its contents.'),
]

# ==================================================================  PHASE 4 — THE EIGHT LIMBS
PHASE_LIMBS = [
    E('ashtanga', 'Sādhana Pāda 2.29', 'Ashtāṅga — the eight limbs of yoga', ['PRACTICE', 'IDEAS'],
      'The heart of the practical teaching is aṣṭāṅga, the "eight limbs" — a graded ladder from outer conduct to inner absorption: yama, niyama, āsana, prāṇāyāma, pratyāhāra, dhāraṇā, dhyāna, and samādhi — each limb preparing the next, carrying the practitioner from how one treats the world to the stilling of the mind itself.',
      svg_stack('Eight limbs, outer to inner', [
          {'n': 1, 'label': 'Yama & Niyama', 'sub': 'ethical restraints and observances', 'color': '#166534'},
          {'n': 2, 'label': 'Āsana & Prāṇāyāma', 'sub': 'steady posture and breath control', 'color': '#a16207'},
          {'n': 3, 'label': 'Pratyāhāra', 'sub': 'withdrawal of the senses inward', 'color': '#b45309'},
          {'n': 4, 'label': 'Dhāraṇā, Dhyāna, Samādhi', 'sub': 'concentration, meditation, absorption', 'color': '#3730a3'},
      ], takeaway='Yoga is a staircase — master conduct and body first, then breath and senses, then the mind.', accent=AC),
      bg='In the Sādhana Pāda Patanjali lays out <b>aṣṭāṅga yoga</b> ("eight-limbed yoga") as the practical path — the framework most people mean today by "the eight limbs."',
      people='the countless teachers and schools who have organised practice around these eight stages; note this "ashtanga" is the classical scheme, distinct from the modern Ashtanga Vinyasa style.',
      what='The eight limbs are <b>yama</b> (restraints), <b>niyama</b> (observances), <b>āsana</b> (posture), <b>prāṇāyāma</b> (breath), <b>pratyāhāra</b> (sense-withdrawal), <b>dhāraṇā</b> (concentration), <b>dhyāna</b> (meditation) and <b>samādhi</b> (absorption).',
      crux='The order is <b>developmental</b> — outer discipline builds the stability that inner meditation requires.',
      conseq='This ladder became the master-map of classical yoga and of much modern yoga teaching.',
      matters='It is a complete curriculum of self-transformation, from everyday ethics to the summit of consciousness.'),

    E('yamaniyama', 'Sādhana Pāda 2.30–2.45', 'Yama and niyama — the ethical ground', ['PRACTICE', 'IDEAS'],
      'The first two limbs are moral, not physical — five yamas of restraint (non-violence, truth, non-stealing, continence, non-possession) and five niyamas of observance (purity, contentment, austerity, self-study, surrender to God) — laying the ethical foundation without which, Patanjali holds, no deeper yoga can stand.',
      svg_compare('The ten ethical disciplines', {
          'head': 'Yama — restraints', 'color': '#166534',
          'items': ['Ahiṃsā — non-violence', 'Satya — truthfulness', 'Asteya — non-stealing', 'Brahmacarya — continence', 'Aparigraha — non-possessiveness'],
      }, {
          'head': 'Niyama — observances', 'color': '#b45309',
          'items': ['Śauca — purity', 'Santoṣa — contentment', 'Tapas — austerity', 'Svādhyāya — self-study', 'Īśvara-praṇidhāna — surrender to God'],
      }, verdict='Yoga begins with character — how one lives and what one cultivates — before any posture or breath.',
         takeaway='The foundation of yoga is ethical: five things to refrain from, five to practise.', accent=AC),
      bg='Before body and breath, Patanjali sets <b>conduct</b> — the yamas govern one’s relation to others, the niyamas one’s relation to oneself.',
      people='later ethical traditions across Hindu, Buddhist and Jain thought that share these values (especially <b>ahiṃsā</b>); teachers who insist the yamas come first.',
      what='The five <b>yamas</b> are ahiṃsā, satya, asteya, brahmacarya, aparigraha; the five <b>niyamas</b> are śauca, santoṣa, tapas, svādhyāya and īśvara-praṇidhāna — ten disciplines forming the base of the ladder.',
      crux='Yoga is <b>an ethical project first</b> — the mind cannot be stilled while the life around it is disordered.',
      conseq='These ten principles became a widely shared ethical charter, quoted far beyond formal yoga practice.',
      matters='It grounds a spiritual technology in ordinary moral life — no shortcut past how you treat the world.'),

    E('samyama', 'Vibhūti Pāda 3.1–3.6', 'Samyama and the powers (vibhūti)', ['PRACTICE', 'IDEAS'],
      'The last three inner limbs — concentration, meditation, and absorption — when trained on a single object fuse into "samyama," and from this deep integration Patanjali says extraordinary powers (vibhūti / siddhi) can arise; yet he warns that these very powers are obstacles to the true goal, which is liberation, not display.',
      svg_row('The inner limbs and their fruit', [
          {'n': 1, 'label': 'Dhāraṇā → Dhyāna → Samādhi', 'sub': 'concentration deepens into absorption', 'color': '#3730a3'},
          {'n': 2, 'label': 'Samyama on one object', 'sub': 'the three fuse into total focus', 'color': '#b45309'},
          {'n': 3, 'label': 'Vibhūti — powers arise', 'sub': 'but they are traps, not the goal', 'color': '#b91c1c'},
      ], edge_labels=['fuse into', 'yield'], takeaway='The deepest concentration bears fruit in "powers" — which Patanjali flags as a distraction from freedom.', accent=AC),
      bg='The third book, <b>Vibhūti Pāda</b>, treats the fruits of the last three limbs — <b>dhāraṇā, dhyāna and samādhi</b> — when applied together.',
      people='commentators who catalogue the siddhis; sceptics and mystics alike who have debated the powers Patanjali lists.',
      what='The union of the three inner limbs on one object is <b>samyama</b>; sustained samyama is said to yield <b>vibhūti</b> or <b>siddhi</b> — extraordinary faculties — yet Patanjali <b>warns these are obstacles</b> (3.37) to samādhi.',
      crux='The powers are a <b>by-product, and a temptation</b> — the point is liberation, not the acquisition of abilities.',
      conseq='This teaching shaped Indian ideas of yogic attainment while cautioning against confusing means with end.',
      matters='It is a sober warning built into a mystical system — do not mistake spectacular side-effects for the goal.'),
]

# ==================================================================  PHASE 5 — THE PHILOSOPHY OF LIBERATION
PHASE_PHILOSOPHY = [
    E('kleshas', 'Sādhana Pāda 2.3–2.11', 'The five kleshas and kriyā yoga', ['IDEAS', 'PRACTICE'],
      'Patanjali diagnoses suffering before prescribing its cure — five "kleshas" or afflictions poison the mind, rooted in avidyā, primal ignorance, and branching into ego, attachment, aversion, and the clinging to life; against them he sets kriyā yoga, the yoga of action: austerity, self-study, and surrender to God.',
      svg_compare('The disease and the remedy', {
          'head': 'The five kleshas (afflictions)', 'color': '#b91c1c',
          'items': ['Avidyā — ignorance (the root)', 'Asmitā — egoism', 'Rāga — attachment', 'Dveṣa — aversion', 'Abhiniveśa — clinging to life'],
      }, {
          'head': 'Kriyā yoga (the remedy)', 'color': '#b45309',
          'items': ['Tapas — disciplined austerity', 'Svādhyāya — self-study', 'Īśvara-praṇidhāna — surrender', 'Weakens the kleshas, steadies the mind'],
      }, verdict='Ignorance breeds the afflictions that cause suffering; the yoga of action wears them away.',
         takeaway='Patanjali frames yoga as therapy — naming the mind’s afflictions, then the discipline that dissolves them.', accent=AC),
      bg='The Sādhana Pāda opens with a <b>diagnosis of suffering</b>: the mind is troubled by five <b>kleshas</b>, of which the first, ignorance, is the ground of the rest.',
      people='later commentators who compared this analysis to Buddhist accounts of craving and ignorance; teachers who present the kleshas as the psychology of suffering.',
      what='The five kleshas are <b>avidyā</b> (ignorance), <b>asmitā</b> (egoism), <b>rāga</b> (attachment), <b>dveṣa</b> (aversion) and <b>abhiniveśa</b> (clinging to life). The counter is <b>kriyā yoga</b> — tapas, svādhyāya and īśvara-praṇidhāna.',
      crux='Suffering has a <b>diagnosable cause and a treatable path</b> — ignorance at the root, discipline as the cure.',
      conseq='This therapeutic structure — affliction and remedy — became central to how yoga is taught.',
      matters='It reads like a psychology of the mind two thousand years early: name the affliction, then treat it.'),

    E('ishvara', 'Samādhi Pāda 1.23–1.29', 'Īśvara — the special Self', ['IDEAS', 'PHILOSOPHY'],
      'Though built on a Sāṃkhya frame that needs no creator, Patanjali’s yoga makes room for Īśvara — not a world-maker but a "special puruṣa," a consciousness untouched by affliction, karma or time; devotion to this Īśvara, and meditation on its symbol Om, is offered as one direct road to the stillness yoga seeks.',
      svg_stack('God as a means, not a maker', [
          {'n': 1, 'label': 'Īśvara — a "special puruṣa"', 'sub': 'consciousness free of affliction and karma', 'color': '#b45309'},
          {'n': 2, 'label': 'Its symbol is Om (praṇava)', 'sub': 'repeated and meditated upon', 'color': '#3730a3'},
          {'n': 3, 'label': 'Īśvara-praṇidhāna — surrender', 'sub': 'devotion as a direct path to samādhi', 'color': '#166534'},
      ], takeaway='Patanjali’s God is a focus for devotion and meditation — a catalyst for liberation, not a cosmic creator.', accent=AC),
      bg='Classical Sāṃkhya is essentially <b>non-theistic</b>; Patanjali’s distinctive move is to introduce <b>Īśvara</b> into the yoga system as an aid to practice.',
      people='commentators who debated Īśvara’s exact role; devotional traditions that later expanded this seed into full theism.',
      what='Īśvara is defined (1.24) as a <b>puruṣa-viśeṣa</b>, a "special Self," untouched by afflictions, actions and their traces; its symbol is <b>Om</b> (1.27), and <b>surrender to Īśvara</b> is named a way to samādhi (1.23).',
      crux='God here functions as a <b>transformative focus for the mind</b>, not as the ground or creator of the world.',
      conseq='This gave the yoga tradition a place for devotion (bhakti) alongside disciplined effort.',
      matters='It is a subtle theology — the divine as an instrument of liberation, meeting the practitioner where devotion helps.'),

    E('kaivalya', 'Kaivalya Pāda', 'Kaivalya — the isolation of the Seer', ['IDEAS', 'PHILOSOPHY'],
      'The fourth book names yoga’s ultimate goal — kaivalya, literally "aloneness" or "isolation": the final, irreversible discernment of pure consciousness as wholly distinct from nature, so that the Seer rests in its own light, free of all that it had mistaken for itself. This is the liberation, the mokṣa, toward which every limb was aimed.',
      svg_stack('The summit of the path', [
          {'n': 1, 'label': 'Discriminating knowledge', 'sub': 'puruṣa seen as utterly apart from prakṛti', 'color': '#3730a3'},
          {'n': 2, 'label': 'Kaivalya — "aloneness"', 'sub': 'consciousness isolated, resting in itself', 'color': '#b45309'},
          {'n': 3, 'label': 'Liberation (mokṣa)', 'sub': 'freedom from bondage to nature and rebirth', 'color': '#166534'},
      ], takeaway='The goal is not power or bliss but freedom — awareness standing clear and alone in its true nature.', accent=AC),
      bg='The final <b>Kaivalya Pāda</b> treats liberation and the ultimate reality of the Seer — the destination the whole text has been building toward.',
      people='commentators who distinguish yogic kaivalya from other schools’ ideas of liberation; the Sāṃkhya tradition that shares the term.',
      what='<b>Kaivalya</b> means "isolation" or "aloneness" — the final <b>discernment of puruṣa as entirely distinct from prakṛti</b>, in which consciousness abides in its own nature, free of the mind and the world. It is yoga’s <b>mokṣa</b>.',
      crux='Freedom is <b>a clarity, not an achievement in the world</b> — seeing, once and for all, what the Self truly is and is not.',
      conseq='This defined the horizon of classical yoga and distinguished it within Indian philosophy.',
      matters='It offers a strikingly austere vision of freedom — liberation as pure, undistorted awareness itself.'),
]

# ==================================================================  PHASE 6 — RECEPTION & LEGACY
PHASE_LEGACY = [
    E('vyasa', 'c. 4th–5th c. CE', 'Vyāsa’s Bhāṣya and the commentators', ['LEGACY', 'TEXT'],
      'The terse Sūtras could not travel alone — they came down wrapped in commentary, above all the Yogabhāṣya attributed to the sage Vyāsa, the earliest and most authoritative interpretation, on which nearly all later readings rest; indeed some modern scholars now argue Patanjali wrote sūtras and commentary together as one work, the Pātañjalayogaśāstra.',
      svg_row('How the Sūtras were transmitted', [
          {'n': 1, 'label': 'The bare Sūtras', 'sub': 'aphorisms too cryptic to stand alone', 'color': '#b45309'},
          {'n': 2, 'label': 'Vyāsa’s Yogabhāṣya', 'sub': 'the first, authoritative commentary', 'color': '#3730a3'},
          {'n': 3, 'label': 'A cascade of later readings', 'sub': 'Vācaspati, Bhoja, Vijñānabhikṣu and more', 'color': '#166534'},
      ], edge_labels=['unlocked by', 'then'], takeaway='Patanjali reached us through his commentators — the Sūtras and the Bhāṣya are read as one.', accent=AC),
      bg='The <b>Yoga Sūtras</b> are so compressed that they require a commentary; the <b>Yogabhāṣya</b>, traditionally by <b>Vyāsa</b> (c. 4th–5th century CE), is the foundational one.',
      people='<b>Vyāsa</b>, the traditional commentator; later interpreters such as <b>Vācaspati Miśra</b>, King <b>Bhoja</b>, and <b>Vijñānabhikṣu</b>.',
      what='Vyāsa’s Bhāṣya is the <b>first and most authoritative commentary</b>, the basis of all medieval readings. Some scholars now hold that <b>Patanjali himself composed both</b> as a single work, the <b>Pātañjalayogaśāstra</b>.',
      crux='The living text is <b>sūtra-plus-commentary</b> — Patanjali as we read him is inseparable from Vyāsa.',
      conseq='Centuries of commentary kept the Sūtras central to Indian philosophy and available to later revival.',
      matters='It shows how canonical texts survive — not as bare words, but through the interpreters who keep unfolding them.'),

    E('revival', '19th–21st c.', 'The modern global yoga revival', ['LEGACY', 'TRIUMPH'],
      'Long a specialist’s scripture, the Yoga Sūtras were thrust onto the world stage in the modern era — Vivekananda’s 1896 "Rāja Yoga" carried them to the West, twentieth-century masters like Krishnamacharya and his pupils Iyengar and Pattabhi Jois built a global postural practice partly in their name, and yoga grew into a worldwide phenomenon marked each June by an International Day of Yoga.',
      svg_row('From cloister to the world', [
          {'n': 1, 'label': 'Vivekananda’s Rāja Yoga, 1896', 'sub': 'the Sūtras interpreted for the West', 'color': '#3730a3'},
          {'n': 2, 'label': 'Krishnamacharya & his pupils', 'sub': 'Iyengar, Pattabhi Jois, Devi spread practice', 'color': '#b45309'},
          {'n': 3, 'label': 'A global movement', 'sub': 'International Day of Yoga, 21 June', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='Patanjali’s ancient text became a reference point for a modern, worldwide yoga movement.', accent=AC),
      bg='For most of history the Sūtras were a philosopher’s text; the <b>modern yoga revival</b> made Patanjali a household name far beyond India.',
      people='<b>Swami Vivekananda</b>, whose <b>Rāja Yoga (1896)</b> presented the Sūtras to the West; <b>T. Krishnamacharya</b> and his pupils <b>B.K.S. Iyengar</b>, <b>K. Pattabhi Jois</b> and <b>Indra Devi</b>.',
      what='Vivekananda reintroduced the Sūtras as "Rāja Yoga"; twentieth-century masters built the modern global practice, often invoking Patanjali; and in 2014 the UN declared <b>21 June the International Day of Yoga</b>, first observed in 2015.',
      crux='Modern yoga <b>reaches back to Patanjali for authority</b>, even as its emphasis on posture differs from his emphasis on mind.',
      conseq='The Sūtras are now among the most translated and cited texts of Indian philosophy worldwide.',
      matters='An ancient aphoristic text became the charter of a global wellness movement — influence Patanjali could never have foreseen.'),

    E('legacy', 'to the present', 'The founder-sage of yoga', ['LEGACY', 'TRIUMPH'],
      'Whoever he was, or however many, "Patanjali" endures as the founder-figure of classical yoga — his four short books remain its charter, his eight limbs its map, his definition of yoga its first principle; venerated in a traditional invocation as the serpent-sage who gave the world the science of stilling the mind.',
      svg_stack('An author who became a foundation', [
          {'n': 1, 'label': 'Founder of the Yoga darśana', 'sub': 'one of Hinduism’s six classical schools', 'color': '#b45309'},
          {'n': 2, 'label': 'The eight limbs endure', 'sub': 'still the framework of yoga teaching', 'color': '#3730a3'},
          {'n': 3, 'label': 'Revered across the world', 'sub': 'invoked before practice, studied everywhere', 'color': '#166534'},
      ], takeaway='Patanjali survives as the name that founded and still frames the whole tradition of yoga.', accent=AC),
      bg='Patanjali gave the Yoga school its foundational text and is remembered as its <b>founder-sage</b>, honoured in a traditional invocation recited before practice.',
      people='the worldwide community of practitioners and scholars; the lineages and schools that trace their authority to his Sūtras.',
      what='His <b>Yoga Sūtras</b> remain the classical charter of yoga, his <b>eight limbs</b> its enduring map, and his opening <b>definition</b> its first principle — while his contested identity only adds to his mystique.',
      crux='He is a <b>foundation more than a biography</b> — a name that anchors an entire living tradition.',
      conseq='Two millennia on, his text is studied and practised across the globe, its author half-history, half-legend.',
      matters='Few authors are so influential and so unknown — Patanjali proves that ideas can outlast every fact about the person.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Patanjali is the ancient sage traditionally credited with the <b>Yoga Sūtras</b>, the foundational text of classical yoga — and, by one tradition, with a great commentary on Sanskrit grammar and a lost medical work. Yet he is among the most shadowy of influential figures: his dates are disputed (a grammarian of the 2nd century BCE, a yoga author of perhaps the 2nd–4th century CE), and scholars debate whether one Patanjali existed or several. What survives is the work — some 195 aphorisms defining yoga as the <b>stilling of the mind</b>, mapping the <b>eight limbs</b> from ethics to absorption, and pointing toward liberation. He is the ultimate study in <b>influence without biography.</b></p>
<div class="ov-quote">“Yogaś citta-vṛtti-nirodhaḥ” — Yoga is the stilling of the fluctuations of the mind<span>— Yoga Sūtras 1.2</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A near-faceless sage known only through his texts → the dating puzzle and the legend of a serpent-born author → the grammarian’s Mahābhāṣya → the four-book Yoga Sūtras and their definition of yoga → the eight limbs and the Sāṃkhya metaphysics of puruṣa and prakṛti → the kleshas, Īśvara and kaivalya → and a modern global revival that made an ancient text a worldwide charter.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🧘</div><h4>Founder of classical yoga</h4><p>His Sūtras are the charter of the entire yoga tradition.</p></div>
  <div class="ov-card"><div class="i">🪜</div><h4>The eight limbs</h4><p>A complete ladder from ethics to deep absorption.</p></div>
  <div class="ov-card"><div class="i">🧠</div><h4>A science of the mind</h4><p>Yoga as the disciplined stilling of consciousness.</p></div>
  <div class="ov-card"><div class="i">🌏</div><h4>A global revival</h4><p>An ancient text now studied and practised worldwide.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Mystery</b><small> identity</small><p>The faceless sage, the dating debate, the serpent legend.</p></div>
  <div><b>2 · The Grammarian</b><small> c. 2nd c. BCE</small><p>The Mahābhāṣya and a philosophy of language.</p></div>
  <div><b>3 · The Sūtras</b><small> the text</small><p>Four books, the definition of yoga, the Sāṃkhya frame.</p></div>
  <div><b>4 · The Eight Limbs</b><small> practice</small><p>Ethics, body, breath, senses, and the inner limbs.</p></div>
  <div><b>5 · Liberation</b><small> philosophy</small><p>The kleshas, Īśvara, and kaivalya — the goal.</p></div>
  <div><b>6 · Legacy</b><small> to today</small><p>Vyāsa’s Bhāṣya and the modern global revival.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the idea, then six branches (background, key people, what it says, the crux, consequences, why it matters). Legendary material is <b>flagged as tradition</b>. Use <b>Key Ideas</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Vyāsa', 'role': 'foundational commentator', 'color': '#3730a3',
     'bio': 'The sage traditionally credited with the Yogabhāṣya (c. 4th–5th c. CE), the earliest and most authoritative commentary on the Yoga Sūtras — without which the aphorisms are nearly unreadable.',
     'rel': 'The interpreter through whom Patanjali reaches us; some scholars think Patanjali wrote both.'},
    {'name': 'Pāṇini', 'role': 'the master grammarian', 'color': '#b45309',
     'bio': 'The great founding grammarian of Sanskrit, author of the Aṣṭādhyāyī, whose rules the Mahābhāṣya expounds and defends.',
     'rel': 'The predecessor whose grammar Patanjali the grammarian commented upon.'},
    {'name': 'Kātyāyana', 'role': 'critic of Pāṇini', 'color': '#a16207',
     'bio': 'The grammarian whose Vārttikas offered critical notes on Pāṇini — and which survive largely through their treatment in Patanjali’s Mahābhāṣya.',
     'rel': 'The critic Patanjali both answered and preserved.'},
    {'name': 'Ādiśeṣa (Ananta)', 'role': 'mythic origin', 'color': '#166534',
     'bio': 'The thousand-headed cosmic serpent on whom Vishnu reclines; by tradition, Patanjali is his incarnation, fallen as a tiny snake into a yogini’s palms.',
     'rel': 'The divine serpent whose descent the legend makes Patanjali’s origin.'},
    {'name': 'Swami Vivekananda', 'role': 'modern populariser', 'color': '#b91c1c',
     'bio': 'The monk whose book Rāja Yoga (1896) interpreted the Yoga Sūtras for the West, launching their modern global career.',
     'rel': 'The figure who carried Patanjali’s text onto the world stage.'},
]

KEY_EVENTS = [
    ('c. 150 BCE', 'The Mahābhāṣya', 'Grammar commentary on Pāṇini.'),
    ('2nd–4th c. CE', 'The Yoga Sūtras', '~195 aphorisms in four books.'),
    ('YS 1.2', '“Citta-vṛtti-nirodhaḥ”', 'Yoga defined as stilling the mind.'),
    ('YS 2.29', 'The eight limbs', 'Yama to samādhi — the ladder of yoga.'),
    ('YS 2.30–45', 'Yama & niyama', 'The ethical foundation of practice.'),
    ('YS 2.3–11', 'The five kleshas', 'The afflictions rooted in ignorance.'),
    ('YS 1.23–29', 'Īśvara', 'God as a focus for liberation.'),
    ('Kaivalya Pāda', 'Kaivalya', 'Liberation as the Seer’s isolation.'),
    ('c. 4th–5th c. CE', 'Vyāsa’s Bhāṣya', 'The authoritative commentary.'),
    ('1896–present', 'Global revival', 'Vivekananda; International Day of Yoga.'),
]

MASTER = [
    {'year': 'c. 150 BCE', 'age': 'grammarian', 'phase': 'The Grammarian', 'title': 'Mahābhāṣya', 'desc': 'The "Great Commentary" on Pāṇini.'},
    {'year': '2nd–4th c. CE', 'age': 'yoga author', 'phase': 'The Sūtras', 'title': 'Yoga Sūtras', 'desc': 'Four books, ~195 aphorisms.'},
    {'year': 'YS 1.2', 'age': 'the definition', 'phase': 'The Sūtras', 'title': 'Nirodha', 'desc': 'Yoga as stilling the mind.'},
    {'year': 'YS 2.29', 'age': 'the practice', 'phase': 'Eight Limbs', 'title': 'Ashtāṅga', 'desc': 'The eight-limbed path.'},
    {'year': 'Kaivalya Pāda', 'age': 'the goal', 'phase': 'Liberation', 'title': 'Kaivalya', 'desc': 'Isolation of the Seer.'},
    {'year': 'c. 4th–5th c. CE', 'age': 'reception', 'phase': 'Legacy', 'title': 'Vyāsa’s Bhāṣya', 'desc': 'The authoritative commentary.'},
    {'year': '1896–', 'age': 'revival', 'phase': 'Legacy', 'title': 'Global yoga', 'desc': 'Vivekananda to Yoga Day.'},
]

SOURCES = [
    ('Wikipedia — Patanjali', 'https://en.wikipedia.org/wiki/Patanjali'),
    ('Wikipedia — Yoga Sutras of Patanjali', 'https://en.wikipedia.org/wiki/Yoga_Sutras_of_Patanjali'),
    ('Britannica — Patanjali', 'https://www.britannica.com/biography/Patanjali'),
    ('Britannica — Yoga Sutras', 'https://www.britannica.com/topic/Yoga-sutras'),
    ('Wikipedia — Mahabhashya', 'https://en.wikipedia.org/wiki/Mahabhashya'),
    ('Hindu American Foundation — Who was Patanjali?', 'https://www.hinduamerican.org/blog/who-was-patanjali-and-what-are-the-yoga-sutras'),
    ('Yoga Journal — Who Was Patanjali?', 'https://www.yogajournal.com/yoga-101/philosophy/yoga-sutras/who-was-patanjali/'),
]

def build_meta():
    return {
        'pid': 'gm-patanjali.html', 'kind': 'man', 'emoji': '🧘', 'accent': AC,
        'name': 'Patanjali', 'years': 'c. 2nd c. BCE / 2nd–4th c. CE', 'group': 'Sages, Poets & Philosophers',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The ancient sage credited with the Yoga Sūtras — foundational text of classical yoga, defining yoga as the stilling of the mind and mapping the eight limbs — and, by tradition, a great grammar commentary and a medical work.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'mystery', 'label': '1 · The Mystery', 'type': 'timeline',
             'intro': 'One of Indian thought’s most influential figures is also one of its most shadowy — a name attached to great texts, a disputed date, and a serpent legend filling the biographical void.', 'events': PHASE_MYSTERY},
            {'id': 'grammar', 'label': '2 · The Grammarian', 'type': 'timeline',
             'intro': 'The Patanjali of the 2nd century BCE wrote the Mahābhāṣya, the "Great Commentary" on Pāṇini — a monument of grammar that doubled as a philosophy of language.', 'events': PHASE_GRAMMAR},
            {'id': 'sutras', 'label': '3 · The Sūtras', 'type': 'timeline',
             'intro': 'The Yoga Sūtras compress the whole science of yoga into four short books — defining yoga as the stilling of the mind and resting on the Sāṃkhya duality of puruṣa and prakṛti.', 'events': PHASE_SUTRAS},
            {'id': 'limbs', 'label': '4 · The Eight Limbs', 'type': 'timeline',
             'intro': 'The heart of the practice is aṣṭāṅga, the eight limbs — a graded ladder from ethical conduct and posture through breath and the senses to the deepest absorption of the mind.', 'events': PHASE_LIMBS},
            {'id': 'philosophy', 'label': '5 · Liberation', 'type': 'timeline',
             'intro': 'Patanjali diagnoses suffering in the five kleshas, makes room for a "special Self" in Īśvara, and points beyond both toward kaivalya — the final isolation of pure consciousness.', 'events': PHASE_PHILOSOPHY},
            {'id': 'legacy', 'label': '6 · Legacy', 'type': 'timeline',
             'intro': 'Transmitted through Vyāsa’s commentary and revived by modern masters from Vivekananda onward, Patanjali’s text became the charter of a worldwide yoga movement.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Encyclopaedic and scholarly sources on Patanjali, the Yoga Sūtras and the Mahābhāṣya; the birth and serpent-incarnation stories survive as devotional tradition and are flagged as such.'},
            {'id': 'events', 'label': 'Key Ideas', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
