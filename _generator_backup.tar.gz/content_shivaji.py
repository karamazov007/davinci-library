# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Chhatrapati Shivaji Maharaj.
The founder of the Maratha Empire and the Hindavi Swarajya."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc
from content_shivaji_p1 import EVENTS as SV1
from content_shivaji_p2 import EVENTS as SV2
from content_shivaji_p3 import EVENTS as SV3
from content_shivaji_p4 import EVENTS as SV4
from content_shivaji_p5 import EVENTS as SV5
from content_shivaji_p6 import EVENTS as SV6

AC = '#b45309'  # Maratha saffron

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE RISE
PHASE_RISE = [
    E('shivneri', '1630–1645', 'Born at Shivneri — raised by Jijabai and his gurus', ['RISE'],
      'Born in 1630 at the hill fort of Shivneri to the Bijapur general Shahaji Bhonsle and his devout wife Jijabai, young Shivaji is raised largely by his mother and his administrator-mentor Dadaji Kondadev — steeped in the Ramayana and Mahabharata, trained in arms and governance, and imbued with a vision of self-rule that would become Hindavi Swarajya.',
      svg_row('The making of a future king', [
          {'n': 1, 'label': 'Born at Shivneri, 1630', 'sub': 'son of Shahaji Bhonsle and Jijabai', 'color': '#b45309'},
          {'n': 2, 'label': 'Raised by Jijabai', 'sub': 'mother instils valour and the epics', 'color': '#3730a3'},
          {'n': 3, 'label': 'Guided by his mentors', 'sub': 'Dadaji Kondadev trains him in arms and rule', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='His mother’s devotion and a mentor’s discipline gave him both a cause and the means to pursue it.', accent=AC),
      bg='<b>Shivaji Bhonsle</b> was born in 1630 at Shivneri fort. His father, Shahaji, served the Bijapur Sultanate and was often away, so Shivaji was raised chiefly at Pune under his mother.',
      people='his mother <b>Jijabai</b>; his father <b>Shahaji Bhonsle</b>; his administrator-mentor <b>Dadaji Kondadev</b>; the spiritual guru <b>Samarth Ramdas</b>.',
      what='Raised by <b>Jijabai and Dadaji Kondadev</b>, Shivaji absorbed the Hindu epics, the arts of war and land administration, and an early conviction in <b>Hindavi Swarajya</b> — self-rule for his people.',
      crux='His character was formed by a devout mother and a capable mentor into a settled sense of <b>purpose and duty</b>.',
      conseq='As a teenager he set out from the Pune region to carve an independent Maratha domain out of Bijapur’s lands.',
      matters='Upbringing shapes destiny — the values instilled by Jijabai and his gurus set the aims of his entire life.'),

    E('swarajya-oath', '1645–1647', 'The oath of self-rule — and the first forts', ['RISE', 'TURNING POINT'],
      'As a teenager Shivaji rallies the hardy Maval peasants of the Sahyadri hills into a loyal fighting band, takes an oath of Hindavi Swarajya, and seizes his first hill forts — Torna, then Rajgad and Kondana — from the Bijapur Sultanate, launching his lifelong project of independent rule.',
      svg_stack('From oath to first conquests', [
          {'n': 1, 'label': 'Oath of Hindavi Swarajya', 'sub': 'vows independent self-rule as a youth', 'color': '#b45309'},
          {'n': 2, 'label': 'Rallies the Maval infantry', 'sub': 'binds hill peasants into a loyal force', 'color': '#3730a3'},
          {'n': 3, 'label': 'Seizes his first forts', 'sub': 'Torna, Rajgad and Kondana taken from Bijapur', 'color': '#166534'},
      ], takeaway='He began not with an army but with a cause and a fort — the seed of a kingdom built one hill at a time.', accent=AC),
      bg='The Deccan was divided among the Bijapur and Ahmadnagar Sultanates and the Mughals. In this contested land the young Shivaji found room to build.',
      people='the <b>Maval</b> hill peasants who became his infantry; the officers of the <b>Bijapur Sultanate</b> whose forts he took; his loyal boyhood companions.',
      what='Shivaji won the devotion of the <b>Maval</b> people, took an oath of <b>self-rule</b>, and captured his first strongholds — <b>Torna (1646), Rajgad and Kondana</b> — from Bijapur.',
      crux='He grasped that in the Sahyadris <b>forts, not open fields, were the keys to power</b> — and began collecting them.',
      conseq='These early conquests alarmed Bijapur and set him on a collision course with the Sultanate.',
      matters='Great enterprises start small — a band of loyal hillmen and a few forts became the nucleus of the Maratha state.'),

    E('ganimikava', '1647–1656', 'Guerrilla war and the mountain-fort strategy', ['RISE', 'STRATEGY'],
      'Lacking the numbers for pitched battle, Shivaji pioneers ganimi kava — swift guerrilla warfare using the Sahyadri mountains, lightning raids, ambushes and rapid retreats to a network of hill forts — a mobile, fort-anchored system that lets a small, fast Maratha force bleed and exhaust far larger Sultanate and Mughal armies.',
      svg_compare('Guerrilla mobility versus heavy armies',
          {'head': 'Ganimi kava (Shivaji)', 'color': '#b45309',
           'items': ['Light, fast Maval infantry and cavalry', 'Ambushes and swift night raids', 'Retreat into a web of hill forts', 'Strike supply lines, avoid pitched battle']},
          {'head': 'Conventional armies', 'color': '#b91c1c',
           'items': ['Heavy cavalry, artillery and baggage', 'Slow, supply-bound columns', 'Seek one decisive open battle', 'Exposed and clumsy in mountain terrain']},
          verdict='Mobility and terrain beat mass.',
          takeaway='He turned the mountains themselves into a weapon — a small force that could never be pinned down or destroyed.', accent=AC),
      bg='Shivaji could not match the great armies of Bijapur or the Mughals in the open. He built a way of war suited to the Sahyadri hills.',
      people='the <b>Maval</b> foot soldiers and light horse; the fort commanders (killedars) he trusted; the enemy generals he outmanoeuvred.',
      what='Shivaji perfected <b>ganimi kava</b> — guerrilla warfare of raids, ambushes and rapid withdrawal — anchored on a network of <b>hill forts</b> that gave refuge and control of the countryside.',
      crux='He fought <b>mobility against mass</b>, refusing decisive battle and instead exhausting larger armies by speed, surprise and terrain.',
      conseq='This system let him survive and grow against enemies many times his strength, and became the Maratha way of war.',
      matters='The weaker side wins by changing the rules of the game — Shivaji’s guerrilla-and-fort strategy is studied as a model still.'),
]

# ==================================================================  PHASE 2 — DEFYING BIJAPUR
PHASE_BIJAPUR = [
    E('afzalkhan', '1659', 'The killing of Afzal Khan with the wagh nakh', ['BATTLE', 'TURNING POINT'],
      'Bijapur sends its formidable general Afzal Khan to crush Shivaji; lured to a face-to-face parley in a tent below Pratapgad fort, Shivaji — anticipating treachery — wears concealed armour and the wagh nakh (iron tiger claws) hidden in his hand, and when the towering Khan attempts to stab him during an embrace, disembowels him, springing a prepared Maratha ambush.',
      svg_row('Turning a trap into a triumph', [
          {'n': 1, 'label': 'Afzal Khan marches, 1659', 'sub': 'Bijapur’s best general sent to destroy him', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A parley below Pratapgad', 'sub': 'Shivaji suspects treachery, wears hidden armour', 'color': '#b45309'},
          {'n': 3, 'label': 'The wagh nakh strikes', 'sub': 'kills Afzal Khan with iron tiger claws', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='Anticipating the assassin’s dagger, he came armed for it — and turned his enemy’s treachery into his own masterstroke.', accent=AC),
      bg='In 1659 Bijapur dispatched the veteran general <b>Afzal Khan</b> with a large army to destroy the rising Shivaji, plundering temples along the way to provoke him.',
      people='<b>Afzal Khan</b>, the Bijapur commander; Shivaji, who sensed the trap; the hidden Maratha troops around Pratapgad.',
      what='Summoned to a parley in a tent below <b>Pratapgad</b>, Shivaji wore concealed armour and the <b>wagh nakh</b> (tiger claws); when Afzal Khan tried to stab him in an embrace, Shivaji killed him and gave the signal to attack.',
      crux='He <b>out-thought a would-be assassin</b> — preparing for betrayal and striking first at the decisive instant.',
      conseq='The Khan’s death left the huge Bijapur army leaderless and set up its destruction at Pratapgad.',
      matters='Foresight beats force — Shivaji’s survival at Pratapgad turned on reading his enemy’s intent before the blow fell.'),

    E('pratapgad', '1659', 'The Battle of Pratapgad — a guerrilla annihilation', ['BATTLE'],
      'With Afzal Khan dead, Shivaji springs his prepared ambush — Maratha infantry hidden in the forested slopes fall upon the leaderless Bijapur army and shatter it, capturing guns, horses, elephants and treasure — proving to all the Deccan that ganimi kava could destroy a far larger conventional force.',
      svg_stack('The ambush that made his name', [
          {'n': 1, 'label': 'Bijapur army leaderless', 'sub': 'Afzal Khan slain at the parley', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Marathas spring from the hills', 'sub': 'hidden infantry fall on the columns', 'color': '#b45309'},
          {'n': 3, 'label': 'A shattering victory', 'sub': 'guns, horses and treasure captured', 'color': '#166534'},
      ], takeaway='One killing and one ambush destroyed a whole army — the day the Marathas became a power to be feared.', accent=AC),
      bg='Shivaji had positioned his forces in the wooded ravines around Pratapgad, ready to attack the moment Afzal Khan fell.',
      people='the leaderless <b>Bijapur</b> host; the Maratha infantry and cavalry; Shivaji directing the ambush from the fort.',
      what='At the <b>Battle of Pratapgad (1659)</b> the Marathas fell on the confused Bijapur army and routed it, seizing large quantities of guns, horses, elephants and treasure.',
      crux='He converted a decapitation strike into a <b>total battlefield victory</b> through preparation and terrain.',
      conseq='The plunder and prestige swelled Shivaji’s power and drew Bijapur into a wider, losing war against him.',
      matters='Surprise multiplies strength — a smaller force that chooses the ground and the moment can annihilate a larger one.'),

    E('panhala', '1660', 'The siege of Panhala and the stand at Pavan Khind', ['BATTLE', 'TRAGEDY'],
      'Bijapur strikes back and besieges Shivaji at Panhala fort; he breaks out by night, and his commander Baji Prabhu Deshpande holds the narrow pass of Ghod Khind against overwhelming numbers to the death, buying the time for Shivaji to reach the safety of Vishalgad — a legend of Maratha sacrifice that renamed the pass Pavan Khind, the sacred pass.',
      svg_stack('A stand that bought a king’s escape', [
          {'n': 1, 'label': 'Besieged at Panhala', 'sub': 'Bijapur traps Shivaji in the fort', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A daring night breakout', 'sub': 'Shivaji slips away toward Vishalgad', 'color': '#b45309'},
          {'n': 3, 'label': 'Baji Prabhu holds the pass', 'sub': 'dies defending Pavan Khind to buy time', 'color': '#78350f'},
      ], takeaway='A handful of men died in a mountain pass so their king could live — the loyalty his cause inspired made him hard to kill.', accent=AC),
      bg='After Pratapgad, Bijapur’s general Siddi Jauhar besieged Shivaji in the fort of <b>Panhala</b> in 1660, trapping him with a large force.',
      people='<b>Baji Prabhu Deshpande</b>, the heroic commander; the besieger Siddi Jauhar; the Maval soldiers who held the pass.',
      what='Shivaji broke out of Panhala by night toward Vishalgad; at the narrow <b>Ghod Khind</b> pass, <b>Baji Prabhu Deshpande</b> and a small band held off the pursuers to the death until Shivaji reached safety.',
      crux='The escape rested on <b>devoted self-sacrifice</b> — men willing to die so their king and cause might survive.',
      conseq='Shivaji lived to fight on; the pass was renamed <b>Pavan Khind</b> (sacred pass) in memory of Baji Prabhu.',
      matters='A leader is only as strong as the loyalty he inspires — Shivaji’s cause commanded men who gave their lives for it.'),
]

# ==================================================================  PHASE 3 — WAR WITH THE MUGHALS
PHASE_MUGHAL = [
    E('shaistakhan', '1663', 'The night raid on Shaista Khan', ['BATTLE', 'TURNING POINT'],
      'Aurangzeb sends his uncle Shaista Khan, who occupies Pune and lodges in Shivaji’s own boyhood home, the Lal Mahal; in a stunning night infiltration with a small band, Shivaji storms the Khan’s quarters, kills his son and guards, and severs three of the Khan’s fingers as he escapes through a window — a humiliation that forces the Mughal viceroy’s recall.',
      svg_row('A dagger in the night', [
          {'n': 1, 'label': 'Shaista Khan occupies Pune', 'sub': 'Mughal viceroy seizes the Lal Mahal', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A daring night infiltration', 'sub': 'Shivaji slips in with a few men', 'color': '#b45309'},
          {'n': 3, 'label': 'The Khan flees maimed', 'sub': 'loses three fingers and his son', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='He walked into the heart of the Mughal camp and out again — a raid so audacious it broke the viceroy’s prestige.', accent=AC),
      bg='In 1660 the Mughal emperor Aurangzeb sent his uncle <b>Shaista Khan</b> to subdue Shivaji; the Khan took Pune and occupied Shivaji’s childhood residence, the Lal Mahal.',
      people='<b>Shaista Khan</b>, the Mughal viceroy; <b>Aurangzeb</b>, who sent him; the handful of Marathas who slipped into the camp.',
      what='In a night raid in <b>1663</b>, Shivaji and a small band infiltrated the guarded <b>Lal Mahal</b>, killed the Khan’s son and guards, and <b>cut off three of Shaista Khan’s fingers</b> as he fled through a window.',
      crux='He struck at the enemy’s <b>prestige and person</b>, not just his army — a psychological blow of stunning boldness.',
      conseq='The humiliated Shaista Khan was recalled by Aurangzeb, and Mughal plans in the Deccan were thrown into disarray.',
      matters='Audacity can achieve what armies cannot — one night raid shattered the aura of an imperial viceroy.'),

    E('surat', '1664', 'The sack of Surat', ['BATTLE'],
      'To fund his growing state and strike at Mughal revenue and prestige, Shivaji raids the wealthy imperial port of Surat in 1664, plundering its rich merchants over several days while sparing the poor, foreign missionaries and those who offered no resistance — filling his treasury and announcing the Marathas as a power the empire could no longer ignore.',
      svg_stack('Plunder as strategy', [
          {'n': 1, 'label': 'The empire’s richest port', 'sub': 'Surat, a jewel of Mughal revenue', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Marathas descend, 1664', 'sub': 'days of plunder of wealthy merchants', 'color': '#b45309'},
          {'n': 3, 'label': 'Treasury filled, prestige struck', 'sub': 'Mughal revenue and pride wounded', 'color': '#166534'},
      ], takeaway='He hit the empire where it was richest — turning a raid into both a war chest and a message.', accent=AC),
      bg='<b>Surat</b> was the Mughal empire’s wealthiest port and a great centre of trade and pilgrimage — a tempting and symbolic target.',
      people='the rich merchants of <b>Surat</b>; the Mughal governor who took shelter; Shivaji directing the raid.',
      what='In <b>1664</b> Shivaji sacked <b>Surat</b>, systematically plundering its wealthy merchants over several days while reportedly sparing the poor and those who did not resist, and carrying off vast wealth.',
      crux='He used the raid to <b>fund his state and wound Mughal prestige</b> at once, targeting wealth rather than slaughter.',
      conseq='The plunder filled his treasury; the affront enraged Aurangzeb and escalated the Mughal-Maratha war.',
      matters='War runs on money — Shivaji financed his kingdom by striking the enemy’s richest and most symbolic assets.'),

    E('agra', '1665–1666', 'Purandar, Agra, and the escape in sweet baskets', ['POLITICS', 'TURNING POINT'],
      'Pressed hard by Jai Singh’s Mughal campaign, Shivaji signs the Treaty of Purandar (1665), surrendering many forts, then travels to Aurangzeb’s court at Agra — where he is slighted and placed under house arrest; in 1666 he engineers a legendary escape, smuggling himself and his young son Sambhaji out of captivity hidden in large baskets of sweets sent out as gifts.',
      svg_row('From captivity to a daring escape', [
          {'n': 1, 'label': 'Treaty of Purandar, 1665', 'sub': 'yields many forts to Jai Singh’s Mughals', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Detained at Agra, 1666', 'sub': 'slighted at court and put under house arrest', 'color': '#78350f'},
          {'n': 3, 'label': 'Escapes in sweet baskets', 'sub': 'smuggled out of Aurangzeb’s custody', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='Cornered by treaty and then caged at court, he escaped by wit — a caged tiger who slipped the empire’s bars.', accent=AC),
      bg='The Mughal general <b>Jai Singh I</b> pressed Shivaji so hard that in 1665 he accepted the <b>Treaty of Purandar</b>, surrendering forts and agreeing to serve the empire.',
      people='<b>Jai Singh I</b>, the Rajput Mughal general; <b>Aurangzeb</b>, who detained him; his son <b>Sambhaji</b>, who escaped with him.',
      what='After Purandar, Shivaji went to <b>Agra (1666)</b>, was insulted in open court and placed under <b>house arrest</b>; he then escaped by feigning illness and having himself and Sambhaji <b>carried out hidden in large baskets of sweets</b>.',
      crux='Trapped in the enemy’s capital, he won freedom by <b>cunning and nerve</b> rather than force.',
      conseq='Back in the Deccan he rebuilt his strength, renounced the treaty, and resumed his war of independence.',
      matters='One of history’s great escapes — proof that ingenuity can defeat even an emperor’s cage.'),
]

# ==================================================================  PHASE 4 — HINDAVI SWARAJYA
PHASE_SWARAJYA = [
    E('reconquest', '1670–1672', 'Reconquest — and a second sack of Surat', ['BATTLE'],
      'Back in his homeland, Shivaji renounces the Treaty of Purandar and swiftly recaptures the forts he had surrendered, wins the open Battle of Salher against a large Mughal army, and sacks Surat a second time in 1670 — restoring and greatly expanding his kingdom within just a few years.',
      svg_stack('Rebuilding the kingdom', [
          {'n': 1, 'label': 'Renounces the treaty', 'sub': 'reclaims the surrendered forts', 'color': '#b45309'},
          {'n': 2, 'label': 'Second sack of Surat, 1670', 'sub': 'raids the Mughal port again', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Victory at Salher', 'sub': 'beats a large Mughal army in the open', 'color': '#166534'},
      ], takeaway='He came back stronger than before — reclaiming every fort and beating the Mughals even in open battle.', accent=AC),
      bg='After escaping Agra, Shivaji rebuilt his forces and by 1670 was ready to overturn the humiliating terms of Purandar.',
      people='the Mughal garrisons he expelled; his generals such as <b>Prataprao Gujar</b>; the merchants of Surat, raided anew.',
      what='Shivaji recaptured his lost forts, sacked <b>Surat a second time (1670)</b>, and won the <b>Battle of Salher</b> — a rare open-field victory over a large Mughal army.',
      crux='He showed the Mughal gains were <b>reversible</b>, and that the Marathas could now win even conventional battles.',
      conseq='By the early 1670s his kingdom was larger and stronger than ever, setting the stage for formal sovereignty.',
      matters='Resilience defines the great — a leader who can rebuild after defeat is far more dangerous than one who never falls.'),

    E('coronation', '1674', 'Coronation as Chhatrapati at Raigad', ['TRIUMPH', 'TURNING POINT'],
      'In June 1674 Shivaji is crowned Chhatrapati at his mountain capital of Raigad in a grand Vedic ceremony, formally founding a sovereign Maratha kingdom — Hindavi Swarajya — and asserting an independent Hindu royal authority, with its own seal, coinage and court, in open defiance of the Mughal and Sultanate powers around him.',
      svg_row('Founding a sovereign kingdom', [
          {'n': 1, 'label': 'Crowned at Raigad, 1674', 'sub': 'grand Vedic coronation ceremony', 'color': '#b45309'},
          {'n': 2, 'label': 'Takes the title Chhatrapati', 'sub': 'a sovereign, anointed monarch', 'color': '#3730a3'},
          {'n': 3, 'label': 'Hindavi Swarajya proclaimed', 'sub': 'an independent Maratha state', 'color': '#166534'},
      ], edge_labels=['thus', 'and'], takeaway='The rebel became a king — a formal, sovereign throne that gave the Maratha cause legitimacy and permanence.', accent=AC),
      bg='By 1674 Shivaji ruled a substantial territory but held no royal title. A formal coronation would establish his sovereignty in law and ritual.',
      people='the scholar <b>Gaga Bhatt</b>, who conducted the rites; the assembled Maratha nobility; his mother Jijabai, who lived to see it.',
      what='In <b>1674</b> Shivaji was crowned <b>Chhatrapati</b> at <b>Raigad</b> in an elaborate Vedic ceremony, founding a sovereign kingdom with its own <b>seal, coinage and calendar</b> — the <b>Hindavi Swarajya</b>.',
      crux='He transformed a warlord’s power into a <b>legitimate, anointed monarchy</b> — a state, not merely a rebellion.',
      conseq='The coronation gave the Maratha polity a lasting institutional and symbolic foundation.',
      matters='Legitimacy outlasts conquest — by crowning himself sovereign, Shivaji gave his kingdom an identity that would endure.'),

    E('navy', '1650s–1670s', 'Building a navy and coastal forts', ['REFORM', 'STRATEGY'],
      'Recognising the sea as a frontier to be guarded, Shivaji builds one of India’s first indigenous navies and raises formidable coastal forts such as Sindhudurg and Vijaydurg along the Konkan — checking the Siddis, the Portuguese and other European powers, protecting trade, and earning him lasting recognition as a father of the Indian navy.',
      svg_stack('Mastering the sea frontier', [
          {'n': 1, 'label': 'Sees the sea as a frontier', 'sub': 'the Konkan coast must be guarded', 'color': '#3730a3'},
          {'n': 2, 'label': 'Builds an indigenous navy', 'sub': 'warships to check coastal powers', 'color': '#b45309'},
          {'n': 3, 'label': 'Raises sea forts', 'sub': 'Sindhudurg and Vijaydurg fortified', 'color': '#166534'},
      ], takeaway='Almost alone among Indian rulers of his age, he understood sea power — and built a navy to hold his coast.', accent=AC),
      bg='The Konkan coast was menaced by the Siddis of Janjira and by European traders — the Portuguese, English and others — with naval power Shivaji lacked.',
      people='the <b>Siddis</b> of Janjira; the <b>Portuguese</b> and English on the coast; Shivaji’s admirals and shipwrights.',
      what='Shivaji built a <b>navy</b> of warships and raised strong <b>coastal forts</b> such as <b>Sindhudurg and Vijaydurg</b> to guard the Konkan, protect trade and confront the Siddis and Europeans.',
      crux='He grasped that <b>sea power mattered</b> — a strategic insight rare among the land-focused rulers of India.',
      conseq='His fleet and sea forts secured the coast and led later admirers to call him a father of the Indian navy.',
      matters='Vision anticipates threats — Shivaji saw the coming age of European sea power and prepared to meet it.'),
]

# ==================================================================  PHASE 5 — LEGACY
PHASE_LEGACY = [
    E('ashtapradhan', 'from 1674', 'The Ashta Pradhan and a progressive administration', ['REFORM'],
      'Shivaji governs through the Ashta Pradhan, a council of eight ministers with defined portfolios; he reforms land revenue on measured assessment, pays his soldiers from the treasury rather than by plunder, promotes Marathi and Sanskrit over Persian, and enforces strict protection of civilians, women, farmers and places of worship of all faiths.',
      svg_compare('A new model of rule',
          {'head': 'Shivaji’s Swarajya', 'color': '#b45309',
           'items': ['Ashta Pradhan — a council of eight ministers', 'Salaried, disciplined standing army', 'Measured land-revenue assessment', 'Marathi and Sanskrit promoted at court', 'Protection of civilians and all faiths']},
          {'head': 'The old order', 'color': '#b91c1c',
           'items': ['Rule by distant Sultans and viceroys', 'Soldiers paid largely by plunder', 'Revenue farmed out to jagirdars', 'Persian imposed as court language', 'Frequent desecration of temples']},
          verdict='A disciplined, accountable Hindavi state.',
          takeaway='He built not just an army but a state — ordered, tolerant and answerable, ahead of its age.', accent=AC),
      bg='A durable kingdom needed durable institutions. Shivaji built a structured administration rather than relying on personal rule alone.',
      people='the <b>Ashta Pradhan</b> ministers (Peshwa, Amatya, Senapati and others); his revenue officers; the soldiers he salaried.',
      what='Shivaji ran his state through the <b>Ashta Pradhan</b> (council of eight), reformed <b>land revenue</b> on measured assessment, <b>salaried</b> his troops, promoted <b>Marathi and Sanskrit</b>, and enforced protection of civilians, women and all places of worship.',
      crux='He fused military strength with <b>ordered, tolerant governance</b> — a genuinely progressive administration for its time.',
      conseq='These institutions outlived him and gave the Maratha polity a framework for later expansion.',
      matters='Kingdoms endure on administration, not conquest alone — Shivaji’s tolerant, ordered rule was ahead of its age.'),

    E('karnataka', '1677', 'The southern campaign', ['BATTLE'],
      'In 1677 Shivaji leads a grand expedition into the Deccan south, campaigning through the Karnataka country in alliance with Golconda, taking Vellore and Gingee and other strongholds, and securing vast new territory and revenue — extending Maratha power deep into the peninsula near the end of his life.',
      svg_stack('Extending power into the south', [
          {'n': 1, 'label': 'Marches south, 1677', 'sub': 'a grand Deccan expedition', 'color': '#b45309'},
          {'n': 2, 'label': 'Takes Gingee and Vellore', 'sub': 'seizes key southern forts', 'color': '#3730a3'},
          {'n': 3, 'label': 'Maratha power extended', 'sub': 'new lands and revenue in the south', 'color': '#166534'},
      ], takeaway='Even late in life he expanded — pushing Maratha reach far into the southern peninsula.', accent=AC),
      bg='With his northern frontier stabilised, Shivaji turned south in 1677 to secure new lands, wealth and forts in the Karnataka and Tamil country.',
      people='the ruler of <b>Golconda</b>, his ally; his half-brother <b>Venkoji</b>, who held Thanjavur; the southern garrisons he took.',
      what='In the <b>southern campaign of 1677</b>, Shivaji marched through the Karnataka region in alliance with Golconda, capturing forts such as <b>Gingee (Jinji) and Vellore</b> and adding large territory and revenue.',
      crux='He extended his kingdom into the <b>far south</b>, giving it depth, resources and strategic reach.',
      conseq='The southern gains, especially Gingee, later served as a Maratha refuge and base against the Mughals.',
      matters='Strategic foresight builds depth — Shivaji’s southern conquests gave his kingdom room to survive future storms.'),

    E('death', '1680', 'Death at Raigad — and an empire’s seed', ['DEATH'],
      'Shivaji dies at Raigad in 1680 at about fifty, leaving a compact but sovereign Maratha kingdom with a navy, a network of forts and an ordered administration; though his son Sambhaji would face Aurangzeb’s full onslaught, within a few generations the Marathas would expand into the vast empire that came to dominate much of India.',
      svg_stack('The seed of an empire', [
          {'n': 1, 'label': 'Dies at Raigad, 1680', 'sub': 'at about fifty years old', 'color': '#78350f'},
          {'n': 2, 'label': 'A sovereign kingdom endures', 'sub': 'forts, navy and ordered rule', 'color': '#b45309'},
          {'n': 3, 'label': 'Seed of the Maratha Empire', 'sub': 'heirs expand it across India', 'color': '#166534'},
      ], takeaway='He died young, but the state he founded outgrew him — becoming an empire that reshaped India.', accent=AC),
      bg='Shivaji died at his capital <b>Raigad</b> in 1680 after a short illness, leaving a young kingdom to his son Sambhaji.',
      people='his son and successor <b>Sambhaji</b>; his rival <b>Aurangzeb</b>, who would spend his last decades fighting the Marathas; the later Peshwas.',
      what='Shivaji died in <b>1680</b> at Raigad, aged about fifty, leaving a sovereign Maratha kingdom with a navy, forts and administration that his heirs and the <b>Peshwas</b> would expand into the <b>Maratha Empire</b>.',
      crux='His true legacy was not the land he held but the <b>durable, sovereign state and idea</b> he founded.',
      conseq='The Maratha polity grew to dominate much of India in the 18th century and became a symbol of self-rule.',
      matters='The measure of a founder is what survives him — Shivaji’s kingdom outgrew its maker to reshape a subcontinent.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Chhatrapati Shivaji Maharaj was the founder of the Maratha Empire and the great architect of Hindavi Swarajya — self-rule. Born on a hill fort and raised by his mother Jijabai, he built a kingdom out of the Sahyadri mountains, pioneering guerrilla warfare (ganimi kava) and a network of hill forts that let a small Maratha force defy the mighty Bijapur Sultanate and the Mughal Empire. He killed the general Afzal Khan with hidden tiger claws, raided the Mughal viceroy in the night, escaped Aurangzeb’s custody hidden in baskets of sweets, and crowned himself sovereign at Raigad. Beyond the battlefield he built a navy, coastal forts and a tolerant, ordered administration. He is the ultimate study in <b>self-rule, mobile warfare, sea power, and building an enduring state against overwhelming odds.</b></p>
<div class="ov-quote">“This kingdom of Shivaji, son of Shahaji, shines for the welfare of the people; like the first crescent of the moon, it will ever grow.”<span>— translation of Shivaji’s royal seal (Rajmudra)</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born at Shivneri and raised by Jijabai and his gurus → rallies the Maval hillmen, takes an oath of self-rule, and seizes his first forts → perfects guerrilla war and the mountain-fort strategy → kills Afzal Khan with the wagh nakh and annihilates Bijapur’s army at Pratapgad → raids Shaista Khan by night and sacks Surat → escapes Aurangzeb’s custody at Agra in sweet baskets → rebuilds, crowns himself Chhatrapati at Raigad, and builds a navy → founds a tolerant, ordered administration and leaves the seed of the Maratha Empire.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🚩</div><h4>Hindavi Swarajya</h4><p>Founded a sovereign self-ruling state against two great empires.</p></div>
  <div class="ov-card"><div class="i">⛰️</div><h4>Guerrilla genius</h4><p>Pioneered ganimi kava and the mountain-fort way of war.</p></div>
  <div class="ov-card"><div class="i">⚓</div><h4>Father of the navy</h4><p>Built one of India’s first fleets and coastal forts.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>A progressive state</h4><p>Ordered, tolerant rule through the Ashta Pradhan council.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Rise</b><small> 1630–1656</small><p>Upbringing, first forts, and guerrilla war.</p></div>
  <div><b>2 · Defying Bijapur</b><small> 1659–1660</small><p>Afzal Khan, Pratapgad, and Pavan Khind.</p></div>
  <div><b>3 · War with the Mughals</b><small> 1663–1666</small><p>Shaista Khan, Surat, and the Agra escape.</p></div>
  <div><b>4 · Hindavi Swarajya</b><small> 1670–1674</small><p>Reconquest, coronation, and the navy.</p></div>
  <div><b>5 · Legacy</b><small> 1674–1680</small><p>Administration, the south, and an empire’s seed.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Jijabai', 'role': 'his mother', 'color': '#3730a3',
     'bio': 'The devout, strong-willed mother who raised Shivaji largely on her own, instilling the epics, courage and the dream of self-rule; she lived to see his coronation.',
     'rel': 'The mother who shaped his character and his cause.'},
    {'name': 'Dadaji Kondadev', 'role': 'mentor', 'color': '#166534',
     'bio': 'The able administrator who managed Shahaji’s Pune estate and trained the young Shivaji in arms, revenue and governance.',
     'rel': 'The mentor who taught him war and administration.'},
    {'name': 'Aurangzeb', 'role': 'Mughal adversary', 'color': '#b91c1c',
     'bio': 'The Mughal emperor who detained Shivaji at Agra and waged a decades-long war against the Marathas, never subduing them.',
     'rel': 'The great imperial rival he defied and escaped.'},
    {'name': 'Afzal Khan', 'role': 'Bijapur general', 'color': '#78350f',
     'bio': 'The formidable Bijapur commander sent to destroy Shivaji, killed by the wagh nakh at their parley below Pratapgad in 1659.',
     'rel': 'The general he slew to launch his war of independence.'},
    {'name': 'Jai Singh I', 'role': 'Mughal general', 'color': '#a16207',
     'bio': 'The Rajput Mughal commander whose 1665 campaign forced the Treaty of Purandar and drew Shivaji to Agra.',
     'rel': 'The general who cornered him into treaty and captivity.'},
]

KEY_EVENTS = [
    ('1630', 'Born at Shivneri', 'Son of Shahaji and Jijabai.'),
    ('1646', 'First forts seized', 'Torna and Rajgad taken from Bijapur.'),
    ('1659', 'Afzal Khan slain', 'Killed with the wagh nakh at Pratapgad.'),
    ('1663', 'Raid on Shaista Khan', 'Night attack humiliates the Mughal viceroy.'),
    ('1664', 'Sack of Surat', 'Plunders the Mughal port to fund the state.'),
    ('1666', 'Escape from Agra', 'Slips Aurangzeb’s custody in sweet baskets.'),
    ('1674', 'Crowned Chhatrapati', 'Coronation at Raigad; Hindavi Swarajya.'),
    ('1677', 'Southern campaign', 'Extends Maratha power into the Karnataka.'),
    ('1680', 'Death at Raigad', 'Leaves a sovereign Maratha kingdom.'),
]

MASTER = [
    {'year': '1630', 'age': 'born', 'phase': 'The Rise', 'title': 'Born at Shivneri', 'desc': 'Raised by Jijabai and his gurus.'},
    {'year': '1659', 'age': 'age 29', 'phase': 'Defying Bijapur', 'title': 'Afzal Khan slain', 'desc': 'The wagh nakh at Pratapgad.'},
    {'year': '1663', 'age': 'age 33', 'phase': 'War with the Mughals', 'title': 'Raid on Shaista Khan', 'desc': 'A night attack at Pune.'},
    {'year': '1666', 'age': 'age 36', 'phase': 'War with the Mughals', 'title': 'Escape from Agra', 'desc': 'Flees hidden in sweet baskets.'},
    {'year': '1674', 'age': 'age 44', 'phase': 'Hindavi Swarajya', 'title': 'Crowned Chhatrapati', 'desc': 'Sovereign king at Raigad.'},
    {'year': '1680', 'age': 'age 50', 'phase': 'Legacy', 'title': 'Death at Raigad', 'desc': 'Seed of the Maratha Empire.'},
]

SOURCES = [
    ('Britannica — Shivaji', 'https://www.britannica.com/biography/Shivaji'),
    ('Wikipedia — Shivaji', 'https://en.wikipedia.org/wiki/Shivaji'),
    ('Wikipedia — Battle of Pratapgad', 'https://en.wikipedia.org/wiki/Battle_of_Pratapgarh'),
    ('Wikipedia — Battle of Surat', 'https://en.wikipedia.org/wiki/Battle_of_Surat'),
    ('Wikipedia — Maratha Empire', 'https://en.wikipedia.org/wiki/Maratha_Empire'),
]

def build_meta():
    return {
        'pid': 'gm-shivaji.html', 'kind': 'man', 'emoji': '🚩', 'accent': AC,
        'name': 'Chhatrapati Shivaji Maharaj', 'years': '1630–1680', 'group': 'Indian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The founder of the Maratha Empire and the architect of Hindavi Swarajya — a guerrilla genius who built a sovereign state and a navy out of the Sahyadri hills, defying the Bijapur Sultanate and the Mughal Empire.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Rise', 'type': 'timeline',
             'intro': 'Born at Shivneri and raised by Jijabai and his mentors, he rallies the Maval hillmen, takes an oath of self-rule, seizes his first forts, and perfects guerrilla warfare and the mountain-fort strategy.', 'events': PHASE_RISE + SV1},
            {'id': 'bijapur', 'label': '2 · Defying Bijapur', 'type': 'timeline',
             'intro': 'He kills the general Afzal Khan with the wagh nakh, annihilates Bijapur’s army at Pratapgad, and survives the siege of Panhala through the sacrifice at Pavan Khind.', 'events': PHASE_BIJAPUR + SV2},
            {'id': 'mughal', 'label': '3 · War with the Mughals', 'type': 'timeline',
             'intro': 'He raids the Mughal viceroy Shaista Khan by night, sacks the rich port of Surat, and — after the Treaty of Purandar — escapes Aurangzeb’s custody at Agra hidden in baskets of sweets.', 'events': PHASE_MUGHAL + SV3},
            {'id': 'swarajya', 'label': '4 · Hindavi Swarajya', 'type': 'timeline',
             'intro': 'He renounces the treaty and rebuilds, wins at Salher, crowns himself Chhatrapati at Raigad to found a sovereign kingdom, and builds a navy and coastal forts to master the sea frontier.', 'events': PHASE_SWARAJYA + SV4 + SV5},
            {'id': 'legacy', 'label': '5 · Legacy', 'type': 'timeline',
             'intro': 'He governs through the Ashta Pradhan with a tolerant, ordered administration, extends Maratha power into the south, and dies at Raigad leaving the seed of the Maratha Empire.', 'events': PHASE_LEGACY + SV6,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; some vivid episodes (the wagh nakh, the sweet-basket escape) are drawn from long tradition and are presented as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER, 'auto': True},
        ],
    }
