# -*- coding: utf-8 -*-
"""Full, DEEP birth-to-death guide content for Talleyrand.
The lame bishop who served five regimes, betrayed them all, and always survived."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#5b21b6'  # diplomat's violet

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE LAME BISHOP
PHASE_RISE = [
    E('clubfoot', '1754–1779', 'A clubfoot pushes a nobleman into the Church', ['RISE', 'TRAGEDY'],
      'Born to the high French nobility but with a crippled foot, the young Talleyrand is judged unfit for the family’s military tradition and pushed, against his wishes, into the Church — giving the most worldly, ambitious and irreligious of men a bishop’s robes he never believed in.',
      svg_row('An ambition in the wrong vocation', [
          {'n': 1, 'label': 'High nobility, a clubfoot', 'sub': 'a lame foot bars the expected military career', 'color': '#5b21b6'},
          {'n': 2, 'label': 'Pushed into the Church', 'sub': 'steered to holy orders against his own will', 'color': '#a16207'},
          {'n': 3, 'label': 'A worldly, faithless priest', 'sub': 'ambition and cynicism in a bishop’s robes', 'color': '#166534'},
      ], edge_labels=['so', 'yields'], takeaway='A physical accident set a supremely worldly man on a religious path he never believed in — a contradiction he exploited for life.', accent=AC),
      bg='<b>Charles-Maurice de Talleyrand-Périgord</b> was born in 1754 into one of France’s greatest noble families, but a <b>deformed foot</b> ruled out the military career expected of him.',
      people='his aristocratic family, who redirected his future; the Church he entered without vocation; the ancien régime society he moved through.',
      what='Deemed unfit for the army, Talleyrand was <b>steered into the Church</b> against his inclinations, rising to become <b>Bishop of Autun in 1788</b> — a worldly, ambitious, unbelieving cleric.',
      crux='He was placed in a role that <b>fit his birth but not his nature</b> — and learned early to wear a mask and serve his own interest within it.',
      conseq='The mismatch bred the cynical, adaptable operator who would serve and betray five regimes.',
      matters='People forced into roles they reject often master the art of the mask — serving the form while pursuing their own ends.'),

    E('revolution', '1788–1792', 'The bishop who helped seize the Church’s lands', ['POLITICS', 'TURNING POINT'],
      'When the Revolution comes, Bishop Talleyrand throws in with it — and, in a stunning act of self-interested realism, proposes that the state seize the Catholic Church’s vast lands to solve its debts, a betrayal of his own institution that gets him excommunicated but marks him as a man who serves power, not principle.',
      svg_stack('Serving the Revolution against his own Church', [
          {'n': 1, 'label': 'Embraces the Revolution, 1789', 'sub': 'a noble bishop joins the new order', 'color': '#5b21b6'},
          {'n': 2, 'label': 'Proposes seizing Church lands', 'sub': 'nationalise the Church’s property to pay state debts', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Excommunicated', 'sub': 'the Pope casts him out; he does not care', 'color': '#a16207'},
      ], takeaway='He betrayed his own Church to serve the rising power — the first proof that he served whoever held it.', accent=AC),
      bg='The French Revolution of 1789 needed money and challenged every old institution. Talleyrand, a bishop, chose the Revolution over the Church.',
      people='the revolutionary Assembly; the <b>Pope</b>, who excommunicated him; the clergy whose lands he helped confiscate.',
      what='Talleyrand <b>proposed nationalising the Catholic Church’s property</b> to solve the state’s finances, helped shape early revolutionary reforms, and was <b>excommunicated</b> — unmoved by the sanction.',
      crux='He revealed his defining trait: <b>loyalty to power and self-interest over any institution or creed</b>, even his own Church.',
      conseq='It set the pattern of a career serving each successive regime — and abandoning each when it failed.',
      matters='The consummate survivor attaches to power itself, not to principles or institutions — and sheds them when they weaken.'),

    E('exile', '1792–1796', 'Fleeing the Terror — exile in England and America', ['POLITICS', 'TRAGEDY'],
      'As the Revolution turns to Terror, Talleyrand escapes to England and then America — expelled, stateless, dabbling in land speculation to survive — until the fall of Robespierre lets him return to France, having learned patience and the value of always having somewhere to run.',
      svg_row('Surviving by knowing when to leave', [
          {'n': 1, 'label': 'The Terror closes in', 'sub': 'the Revolution devours its own', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Exile in England, then America', 'sub': 'stateless; survives by land speculation', 'color': '#5b21b6'},
          {'n': 3, 'label': 'Returns after Thermidor', 'sub': 'Robespierre’s fall lets him come home', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='He grasped the survivor’s first rule — get out before the storm hits, and wait for it to pass.', accent=AC),
      bg='The radical phase of the Revolution (the <b>Terror</b>, 1793–94) executed thousands. Talleyrand, suspect as a former noble and bishop, left in time.',
      people='the revolutionaries he fled; his English and American hosts; the moderates who let him return after Robespierre’s fall.',
      what='Talleyrand spent the Terror in <b>exile in England and the United States</b>, surviving on <b>land speculation</b>, and returned to France after the <b>Thermidorian reaction</b> of 1794 made it safe.',
      crux='He mastered the art of the timely exit — <b>leaving before catastrophe and returning when the danger passed</b>.',
      conseq='Back in France, he swiftly climbed into the government of the Directory as its foreign minister.',
      matters='The survivor’s art includes knowing when to disappear — and always keeping a line of retreat open.'),
]

# ==================================================================  PHASE 2 — NAPOLEON'S MINISTER
PHASE_NAPOLEON = [
    E('foreignminister', '1797–1799', 'Foreign Minister — and the price of an audience', ['POLITICS', 'REFORM'],
      'Talleyrand becomes France’s Foreign Minister under the Directory and immediately turns the office into a machine for personal enrichment — most notoriously demanding huge bribes from American envoys in the XYZ Affair, establishing his lifelong practice of selling his services to everyone who needed them.',
      svg_stack('Diplomacy as a private business', [
          {'n': 1, 'label': 'Foreign Minister, 1797', 'sub': 'takes charge of French diplomacy', 'color': '#5b21b6'},
          {'n': 2, 'label': 'The XYZ Affair', 'sub': 'demands bribes from US envoys for an audience', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Wealth from office', 'sub': 'systematically sells access and favours', 'color': '#a16207'},
      ], takeaway='He treated high office as a source of private fortune — corruption raised to an art, alongside real diplomatic skill.', accent=AC),
      bg='Under the <b>Directory</b>, Talleyrand secured the post of <b>Foreign Minister</b> in 1797 — the platform for both his statecraft and his notorious venality.',
      people='the American envoys of the <b>XYZ Affair</b>, from whom he demanded bribes; the Directory; the many parties who paid for his favour.',
      what='As Foreign Minister he ran diplomacy while <b>enriching himself hugely through bribes</b> — the <b>XYZ Affair (1797–98)</b>, in which his agents demanded payment from US envoys, became an international scandal.',
      crux='He fused <b>genuine diplomatic talent with systematic corruption</b> — serving the state and himself in the same acts.',
      conseq='From this post he backed the rising general who would make him the most powerful diplomat in Europe.',
      matters='Great talent and deep corruption can coexist in one figure — Talleyrand was brilliant and for sale at once.'),

    E('brumaire', '1799', 'Backing Bonaparte — the coup of Brumaire', ['POLITICS', 'TURNING POINT'],
      'Sensing that the weak Directory is finished, Talleyrand throws his weight behind the ambitious young General Bonaparte, helping engineer the coup of 18 Brumaire that makes Napoleon ruler of France — and installs Talleyrand as the indispensable Foreign Minister of the new regime.',
      svg_row('Choosing the coming man', [
          {'n': 1, 'label': 'The Directory is failing', 'sub': 'Talleyrand judges it doomed', 'color': '#a16207'},
          {'n': 2, 'label': 'Backs Napoleon’s coup, 1799', 'sub': 'helps engineer 18 Brumaire', 'color': '#5b21b6'},
          {'n': 3, 'label': 'Foreign Minister again', 'sub': 'indispensable to the new ruler of France', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='He picked the winner before the race was decided — attaching himself to power as it rose.', accent=AC),
      bg='By 1799 the <b>Directory</b> was discredited and unstable. Talleyrand judged that <b>General Bonaparte</b> was the coming power and acted accordingly.',
      people='<b>Napoleon Bonaparte</b>, the rising general; the plotters of Brumaire; the collapsing Directory.',
      what='Talleyrand helped engineer the <b>coup of 18 Brumaire (1799)</b> that brought Napoleon to power, and became <b>Foreign Minister</b> of the new regime — the diplomatic architect of the Napoleonic order.',
      crux='He again <b>attached himself to rising power</b> at exactly the right moment, making himself indispensable to the new master.',
      conseq='For nearly a decade he shaped Napoleon’s diplomacy — and grew rich and powerful in the process.',
      matters='The survivor backs the winner early — reading which way power is flowing and moving before others dare.'),

    E('architect', '1800–1807', 'Architect of empire — and doubts about the master', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'As Napoleon’s Foreign Minister, Talleyrand builds the diplomacy of the empire and enriches himself on a colossal scale — but he comes to believe that Napoleon’s appetite for endless war will destroy France, and begins, quietly, to work against the very master he serves.',
      svg_stack('Serving a master he came to distrust', [
          {'n': 1, 'label': 'Builds Napoleon’s diplomacy', 'sub': 'treaties, alliances, the reordering of Europe', 'color': '#5b21b6'},
          {'n': 2, 'label': 'Enriched on a huge scale', 'sub': 'bribes and deals from every court', 'color': '#a16207'},
          {'n': 3, 'label': 'Fears endless war', 'sub': 'concludes Napoleon’s ambition will ruin France', 'color': '#b91c1c'},
      ], takeaway='He was the empire’s chief diplomat even as he began to conclude its emperor must be restrained — or removed.', accent=AC),
      bg='Talleyrand ran French diplomacy through Napoleon’s rise to European mastery, negotiating the treaties that reshaped the continent.',
      people='<b>Napoleon</b>, his master; the European courts he negotiated with (and took money from); the France he feared for.',
      what='Talleyrand was the <b>architect of Napoleonic diplomacy</b> and enriched himself enormously — but grew convinced that Napoleon’s <b>insatiable warmaking would destroy France</b>, and began seeking to check him.',
      crux='He shifted from servant to secret critic — believing that <b>France’s interest now required limiting the man he served</b>.',
      conseq='His growing opposition would lead him into outright, secret betrayal of Napoleon.',
      matters='Loyalty to a leader can diverge from loyalty to a country — and the realist chooses the country, even against his master.'),
]

# ==================================================================  PHASE 3 — THE BETRAYER
PHASE_BETRAYAL = [
    E('erfurt', '1808', 'Erfurt — betraying the emperor to the Tsar', ['POLITICS', 'TRAGEDY', 'TURNING POINT'],
      'At the Congress of Erfurt, where Napoleon brings him to help browbeat the Russian Tsar, Talleyrand does the opposite — secretly advising Alexander to resist Napoleon and stand firm — an astonishing act of treason in which a minister works against his own emperor at the negotiating table.',
      svg_stack('The minister who worked for the other side', [
          {'n': 1, 'label': 'Brought to Erfurt, 1808', 'sub': 'to help Napoleon pressure Tsar Alexander', 'color': '#5b21b6'},
          {'n': 2, 'label': 'Secretly advises the Tsar', 'sub': 'tells Alexander to resist Napoleon and stand firm', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Treason at the table', 'sub': 'works against his own emperor’s aims', 'color': '#78350f'},
      ], takeaway='At the summit he was sent to win, he quietly worked for the enemy — believing he served France by restraining Napoleon.', accent=AC),
      bg='At the <b>Congress of Erfurt (1808)</b>, Napoleon wanted Talleyrand’s help pressuring <b>Tsar Alexander I</b> of Russia into supporting his plans.',
      people='<b>Napoleon</b>, whom he was meant to serve; <b>Tsar Alexander I</b>, whom he secretly counselled; the France he claimed to be protecting.',
      what='Instead of advancing Napoleon’s aims, Talleyrand <b>secretly urged Tsar Alexander to resist</b> Napoleon and preserve his independence — betraying his own emperor at the conference.',
      crux='He justified treason as <b>patriotism</b> — convinced that thwarting Napoleon’s ambitions served France’s true interest.',
      conseq='His double-dealing, once suspected, would earn one of history’s most famous rebukes.',
      matters='One person’s treason is another’s foresight — Talleyrand bet that history would vindicate betraying a doomed master.'),

    E('silkstocking', '1809', '“Shit in a silk stocking” — Napoleon’s fury', ['POLITICS', 'TRAGEDY'],
      'Discovering Talleyrand’s intrigues, Napoleon explodes in a legendary tirade — denouncing him to his face as “shit in a silk stocking” — and strips him of office; yet Talleyrand hears the abuse with icy composure, and quietly remarks only that it is a pity so great a man should be so ill-bred.',
      svg_row('Abuse met with icy composure', [
          {'n': 1, 'label': 'Napoleon uncovers the betrayal', 'sub': 'realises his minister has worked against him', 'color': '#b91c1c'},
          {'n': 2, 'label': '“Shit in a silk stocking”', 'sub': 'a public tirade to Talleyrand’s face, 1809', 'color': '#78350f'},
          {'n': 3, 'label': 'Talleyrand unmoved', 'sub': 'takes it coolly; his position, not his nerve, is lost', 'color': '#5b21b6'},
      ], edge_labels=['then', 'yet'], takeaway='Stripped of office and abused to his face, he never flinched — and simply waited for Napoleon to fall.', accent=AC),
      bg='By 1809 Napoleon had grown suspicious of Talleyrand’s dealings with his enemies and confronted him with notorious ferocity.',
      people='<b>Napoleon</b>, in a towering rage; Talleyrand, coldly composed; the court that witnessed the scene.',
      what='Napoleon denounced Talleyrand to his face as <b>“shit in a silk stocking,”</b> stripping him of his court office. Talleyrand reportedly received the abuse <b>unmoved</b>, remarking that it was a pity such a great man was so ill-bred.',
      crux='He absorbed public humiliation with <b>total composure</b>, understanding that <b>Napoleon’s power was waning</b> and his own patience would outlast it.',
      conseq='Out of favour, Talleyrand waited for Napoleon’s overreach in Russia and Germany to bring the empire down.',
      matters='The survivor endures humiliation without breaking — knowing that composure outlasts a raging master’s power.'),
]

# ==================================================================  PHASE 4 — THE CONGRESS OF VIENNA
PHASE_VIENNA = [
    E('restoration', '1814', 'Engineering the Restoration — bringing back the king', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'As Napoleon’s empire collapses in 1814, Talleyrand seizes the moment — leading a provisional government, persuading the victorious allies to depose Napoleon and restore the Bourbon monarchy under Louis XVIII, and positioning himself, the servant of the Revolution and the Empire, as the indispensable minister of the new king.',
      svg_stack('Managing the fall and the succession', [
          {'n': 1, 'label': 'Napoleon’s empire collapses, 1814', 'sub': 'the allies enter Paris', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Talleyrand leads the transition', 'sub': 'heads a provisional government; deposes Napoleon', 'color': '#5b21b6'},
          {'n': 3, 'label': 'Restores Louis XVIII', 'sub': 'brings back the Bourbons under the flag of legitimacy', 'color': '#166534'},
      ], takeaway='He turned the empire’s collapse into his own triumph — managing the regime change and making himself essential to the next ruler.', accent=AC),
      bg='In 1814 the allied armies defeated Napoleon and entered Paris. Someone had to manage the transition to a new government — and Talleyrand made it himself.',
      people='the victorious allies (Russia, Austria, Prussia, Britain); <b>Louis XVIII</b>, the restored Bourbon king; the deposed Napoleon.',
      what='Talleyrand <b>led a provisional government</b>, engineered Napoleon’s <b>deposition</b>, and secured the <b>Restoration of the Bourbon monarchy under Louis XVIII</b> — making himself the new king’s foreign minister.',
      crux='He <b>managed the regime change</b> so skilfully that the servant of Revolution and Empire became indispensable to the returning monarchy.',
      conseq='As France’s representative, he now faced the victors at the Congress of Vienna — from a position of apparent total weakness.',
      matters='The supreme survivor doesn’t just endure a regime’s fall — he stage-manages the succession and makes himself essential to what comes next.'),

    E('vienna', '1814–1815', 'The Congress of Vienna — winning from a losing hand', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'At the Congress of Vienna, Talleyrand performs his masterpiece — representing defeated, disarmed France among the triumphant victors, he exploits their quarrels (secretly allying with Britain and Austria against Russia and Prussia over Poland and Saxony) to make France an equal partner again and preserve its borders almost intact.',
      svg_stack('Turning defeat into a seat at the top table', [
          {'n': 1, 'label': 'France, defeated and isolated', 'sub': 'the beaten enemy among the victors, 1814', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Exploit the victors’ quarrels', 'sub': 'secret alliance with Britain & Austria vs Russia & Prussia', 'color': '#5b21b6'},
          {'n': 3, 'label': 'France restored as a great power', 'sub': 'borders preserved; back at the top table', 'color': '#166534'},
      ], takeaway='He played a losing hand so brilliantly that defeated France left the peace as one of its makers, not its victims.', accent=AC),
      bg='The <b>Congress of Vienna (1814–15)</b> gathered the powers that had defeated Napoleon to reorder Europe. France was the beaten enemy, expected to have no say.',
      people='<b>Metternich</b> of Austria, <b>Castlereagh</b> of Britain, <b>Tsar Alexander</b> of Russia; Talleyrand, playing them against each other.',
      what='Talleyrand invoked the <b>principle of legitimacy</b> and <b>exploited the victors’ divisions</b> — forging a <b>secret alliance with Britain and Austria against Russia and Prussia</b> over the fate of Poland and Saxony — to make defeated France an equal partner and keep its borders largely intact.',
      crux='He understood that the victors were <b>divided</b>, and that a clever diplomat could <b>turn their quarrels into leverage</b> for the loser.',
      conseq='France re-entered the concert of Europe as a great power — a stunning recovery orchestrated from apparent helplessness.',
      matters='Even from total weakness, a master of division can win — the divisions among the strong are the opportunities of the weak.'),
]

# ==================================================================  PHASE 5 — THE SURVIVOR
PHASE_END = [
    E('belgium', '1830–1834', 'Ambassador at 76 — and the making of Belgium', ['POLITICS', 'TRIUMPH'],
      'Recalled to service at seventy-six after yet another revolution brings a new king, Talleyrand goes to London as ambassador and crowns his career with one last diplomatic triumph — negotiating the independence and permanent neutrality of Belgium, a settlement that helps keep the peace of Europe for decades.',
      svg_row('A last triumph in old age', [
          {'n': 1, 'label': 'Serves a fifth regime, 1830', 'sub': 'ambassador to London under Louis-Philippe, at 76', 'color': '#5b21b6'},
          {'n': 2, 'label': 'The Belgian question', 'sub': 'a new nation’s independence must be settled peacefully', 'color': '#a16207'},
          {'n': 3, 'label': 'Belgium made neutral', 'sub': 'negotiates its independence and lasting neutrality', 'color': '#166534'},
      ], edge_labels=['then', 'yields'], takeaway='At an age when most are long retired, he added one more nation-shaping settlement to his record.', accent=AC),
      bg='The <b>July Revolution of 1830</b> replaced the Bourbons with <b>Louis-Philippe</b>. The aged Talleyrand agreed to serve as ambassador to <b>London</b>.',
      people='King <b>Louis-Philippe</b>; the British government; the new state of <b>Belgium</b>, whose status Europe had to resolve.',
      what='At 76, Talleyrand went to London and helped negotiate the <b>independence and permanent neutrality of Belgium</b> (1830s) — a peaceful settlement of a dangerous question that stabilised Europe.',
      crux='He proved his diplomatic genius undimmed by age, crafting a durable settlement that <b>kept the peace</b> rather than provoking war.',
      conseq='Belgian neutrality endured until 1914; it was a fitting capstone to his career.',
      matters='True mastery of a craft can last a lifetime — Talleyrand shaped Europe from youth to old age.'),

    E('legacy', '1838', 'The survivor — five regimes, one interest', ['POLITICS', 'DEATH', 'TURNING POINT'],
      'Talleyrand dies in 1838 having served — and abandoned — the monarchy, the Revolution, Napoleon, the restored Bourbons and the July Monarchy in turn, reconciling with the Church he had betrayed only at the very end: the supreme survivor and realist, damned as a traitor and admired as a genius, who claimed he had been loyal always to France.',
      svg_compare('Traitor or patriot?',
        {'head': 'The traitor', 'color': '#b91c1c', 'items': ['betrayed Church, Revolution and Napoleon', 'took bribes from every court', '“treason is a matter of dates”']},
        {'head': 'The realist', 'color': '#5b21b6', 'items': ['served France through five regimes', 'restrained Napoleon; restored France at Vienna', 'claimed loyalty to the nation, not the ruler']},
        'He was both — a corrupt, treacherous genius who may also have served France’s interest through every upheaval.',
        'Judge him by the whole: betrayal and survival in service of a country he outlasted five rulers to protect.', AC),
      bg='By his death in 1838, Talleyrand had served five successive French regimes, betraying each as it fell, while amassing wealth and shaping European diplomacy throughout.',
      people='the five regimes he served; the Church, with which he reconciled at the end; historians who still debate him.',
      what='Talleyrand <b>died in 1838</b>, having served the ancien régime, the Revolution, Napoleon, the Bourbon Restoration and the July Monarchy — <b>betraying each in turn</b> — and reconciled with the <b>Church</b> only on his deathbed. He insisted he had always served <b>France</b>.',
      crux='He embodies the ultimate question of the realist: whether serving one’s country through every regime is <b>principled patriotism or shameless betrayal</b> — perhaps both at once.',
      conseq='He remains the archetype of the survivor-diplomat, studied and quoted (“treason is a matter of dates”) ever since.',
      matters='The realist’s loyalty is to the enduring nation, not the passing ruler — a stance history calls treason or wisdom depending on who wins.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Talleyrand was the supreme survivor of an age of revolutions — a lame nobleman turned worldly bishop who served, and betrayed, five successive French regimes: the monarchy, the Revolution, Napoleon, the restored Bourbons, and the July Monarchy. Corrupt, cynical and brilliant, he took bribes from every court while shaping the diplomacy of Europe, betrayed Napoleon believing his wars would ruin France, and at the Congress of Vienna turned defeated France back into a great power by exploiting the victors’ quarrels. He is the ultimate study in <b>realism over principle, the survivor’s art, and loyalty to a nation rather than its rulers.</b></p>
<div class="ov-quote">“Treason is a matter of dates.”<span>— attributed to Talleyrand</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A clubfoot pushes a nobleman into the Church → the bishop backs the Revolution and seizes Church lands → flees the Terror, returns as Foreign Minister → helps Napoleon to power and builds his diplomacy → betrays him at Erfurt, is called “shit in a silk stocking,” and waits → engineers the Bourbon Restoration → wins from a losing hand at the Congress of Vienna → returns at 76 to make Belgium neutral → and dies the archetypal survivor, insisting he served France through it all.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🎭</div><h4>The survivor</h4><p>Served and outlasted five regimes across four decades of upheaval.</p></div>
  <div class="ov-card"><div class="i">♟️</div><h4>Vienna masterpiece</h4><p>Turned defeated France into a great power by dividing the victors.</p></div>
  <div class="ov-card"><div class="i">💰</div><h4>Genius and corruption</h4><p>Brilliant diplomacy and shameless bribe-taking in the same hands.</p></div>
  <div class="ov-card"><div class="i">🇫🇷</div><h4>Nation over ruler</h4><p>Claimed loyalty to France itself, not to any of its passing masters.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Lame Bishop</b><small> 1754–1796</small><p>Church against his will, Revolution, and exile.</p></div>
  <div><b>2 · Napoleon’s Minister</b><small> 1797–1807</small><p>Foreign Minister, the coup, and growing doubts.</p></div>
  <div><b>3 · The Betrayer</b><small> 1808–1812</small><p>Erfurt and “shit in a silk stocking.”</p></div>
  <div><b>4 · The Congress of Vienna</b><small> 1814–1815</small><p>The Restoration and winning from a losing hand.</p></div>
  <div><b>5 · The Survivor</b><small> 1830–1838</small><p>Belgium, and the verdict of history.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Napoleon Bonaparte', 'role': 'master and victim', 'color': '#b91c1c',
     'bio': 'The emperor Talleyrand helped to power and served as Foreign Minister, then betrayed — believing Napoleon’s endless wars would destroy France. Napoleon called him “shit in a silk stocking.”',
     'rel': 'The master he served, then worked to bring down.'},
    {'name': 'Tsar Alexander I', 'role': 'the courted rival', 'color': '#5b21b6',
     'bio': 'The Russian emperor whom Talleyrand secretly advised to resist Napoleon at Erfurt, and later a key player at the Congress of Vienna.',
     'rel': 'The foreign ruler he secretly counselled against his own master.'},
    {'name': 'Klemens von Metternich', 'role': 'fellow diplomat', 'color': '#166534',
     'bio': 'The Austrian statesman and Talleyrand’s counterpart at the Congress of Vienna, with whom he combined against Russia and Prussia.',
     'rel': 'The Austrian rival-partner at Vienna.'},
    {'name': 'Louis XVIII', 'role': 'restored king', 'color': '#a16207',
     'bio': 'The Bourbon monarch Talleyrand helped restore to the throne in 1814, becoming his foreign minister and France’s voice at Vienna.',
     'rel': 'The king he brought back and served.'},
    {'name': 'Louis-Philippe', 'role': 'the last king he served', 'color': '#78350f',
     'bio': 'The “citizen king” of the July Monarchy, under whom the aged Talleyrand served as ambassador to London and negotiated Belgian neutrality.',
     'rel': 'The fifth and final regime he served.'},
]

KEY_EVENTS = [
    ('1754', 'Talleyrand born', 'High nobility; a clubfoot bars the army.'),
    ('1788', 'Bishop of Autun', 'A worldly, unbelieving cleric.'),
    ('1789', 'Backs the Revolution', 'Proposes seizing Church lands.'),
    ('1797', 'Foreign Minister', 'The XYZ Affair scandal.'),
    ('1799', 'Backs Napoleon’s coup', 'Becomes his Foreign Minister.'),
    ('1808', 'Betrays Napoleon at Erfurt', 'Secretly advises the Tsar.'),
    ('1814', 'Engineers the Restoration', 'Brings back Louis XVIII.'),
    ('1814–15', 'Congress of Vienna', 'Wins from a losing hand.'),
    ('1830s', 'Belgian independence', 'Ambassador in London at 76.'),
    ('1838', 'Death of Talleyrand', 'The archetypal survivor.'),
]

MASTER = [
    {'year': '1754', 'age': 'born', 'phase': 'The Lame Bishop', 'title': 'Born a noble', 'desc': 'A clubfoot changes his path.'},
    {'year': '1789', 'age': 'age 35', 'phase': 'The Lame Bishop', 'title': 'Joins the Revolution', 'desc': 'Seizes Church lands.'},
    {'year': '1799', 'age': 'age 45', 'phase': 'Napoleon’s Minister', 'title': 'Backs Napoleon', 'desc': 'Foreign Minister.'},
    {'year': '1808', 'age': 'age 54', 'phase': 'The Betrayer', 'title': 'Erfurt betrayal', 'desc': 'Works against his master.'},
    {'year': '1815', 'age': 'age 60', 'phase': 'Congress of Vienna', 'title': 'Vienna triumph', 'desc': 'France restored.'},
    {'year': '1838', 'age': 'age 84', 'phase': 'The Survivor', 'title': 'Death', 'desc': 'Served five regimes.'},
]

SOURCES = [
    ('Britannica — Talleyrand', 'https://www.britannica.com/biography/Charles-Maurice-de-Talleyrand'),
    ('World History Encyclopedia — Talleyrand', 'https://www.worldhistory.org/Talleyrand/'),
    ('Britannica — Congress of Vienna', 'https://www.britannica.com/event/Congress-of-Vienna'),
    ('Britannica — XYZ Affair', 'https://www.britannica.com/event/XYZ-Affair'),
    ('Wikipedia — Talleyrand', 'https://en.wikipedia.org/wiki/Charles_Maurice_de_Talleyrand-P%C3%A9rigord'),
]

def build_meta():
    return {
        'pid': 'gm-talleyrand.html', 'kind': 'man', 'emoji': '🎭', 'accent': AC,
        'name': 'Talleyrand', 'years': '1754–1838', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The lame bishop who served and betrayed five French regimes — the supreme survivor and realist, who turned defeated France back into a great power at the Congress of Vienna.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Lame Bishop', 'type': 'timeline',
             'intro': 'A clubfoot pushes a high nobleman into the Church against his will; the worldly bishop then backs the Revolution and seizes his own Church’s lands, flees the Terror, and returns as Foreign Minister.', 'events': PHASE_RISE},
            {'id': 'napoleon', 'label': '2 · Napoleon’s Minister', 'type': 'timeline',
             'intro': 'He turns diplomacy into a private fortune, helps Napoleon seize power, builds the diplomacy of the empire — and comes to fear that Napoleon’s endless wars will destroy France.', 'events': PHASE_NAPOLEON},
            {'id': 'betrayal', 'label': '3 · The Betrayer', 'type': 'timeline',
             'intro': 'Believing he serves France by restraining its emperor, he secretly betrays Napoleon to the Tsar at Erfurt — and endures Napoleon’s legendary fury with icy composure, waiting for the fall.', 'events': PHASE_BETRAYAL},
            {'id': 'vienna', 'label': '4 · The Congress of Vienna', 'type': 'timeline',
             'intro': 'As the empire collapses he engineers the Bourbon Restoration, then performs his masterpiece at Vienna — turning defeated, isolated France back into a great power by exploiting the victors’ quarrels.', 'events': PHASE_VIENNA},
            {'id': 'end', 'label': '5 · The Survivor', 'type': 'timeline',
             'intro': 'Recalled at 76 to serve a fifth regime, he crowns his career by making Belgium neutral — and dies the archetypal survivor, damned as a traitor and admired as a genius, insisting he served France through it all.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; famous quips attributed to Talleyrand (“treason is a matter of dates”) capture his reputation and are read as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
