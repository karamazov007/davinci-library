# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Ashoka the Great."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#c2410c'  # saffron

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_kalinga():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">c. 261 BC · the one victory that changed a man</text>'
    boxes=[(40,'#7f1d1d','Conquers Kalinga','~100,000 killed, 150,000 deported — by his own edict'),
           (270,'#c2410c','Overwhelming remorse','the slaughter breaks him; he recoils from conquest'),
           (500,'#166534','Turns to dhamma','embraces Buddhism and rule by moral force')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">The only conqueror in history to record his greatest victory as his deepest regret.</text>'
    return _wrap(W, H, 'Kalinga — the victory he mourned', _tk(b, W, H, 'His turning point was not a defeat but a triumph so bloody it turned him against conquest itself.'), '', AC)

def svg_dhamma():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">what “dhamma” meant as a way to rule an empire</text>'
    rows=[('#166534','Non-violence and welfare','hospitals, wells, roads, rest-houses; care for animals'),
          ('#0369a1','Tolerance of all faiths','honour every sect; “concord is best,” says the edict'),
          ('#c2410c','Moral persuasion, not force','conquest by dhamma replaces conquest by the sword')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="42" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+21}" r="9" fill="{c}"/><text x="62" y="{y+25}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+18}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+34,s,9.3,'#5b6472',500,11,78); b+=ss
        y+=50
    return _wrap(W, H, 'Dhamma — governing by conscience', _tk(b, W, H, 'He tried to hold an empire together not by armies but by a shared ethic of decency and restraint.'), '', AC)

def svg_edicts():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">how a king spoke directly to his people across an empire</text>'
    b += '<rect x="40" y="60" width="300" height="82" rx="12" fill="#fff7ed" stroke="#c2410c" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#c2410c">Carved in stone</text>'
    s1,_=_tspans(54,100,'edicts on rocks and polished pillars set up across India and its borders',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="82" rx="12" fill="#f0f9ff" stroke="#0369a1" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#0369a1">In the people’s languages</text>'
    s2,_=_tspans(394,100,'Prakrit in Brahmi script — and Greek and Aramaic on the frontier',10,'#0369a1',600,12,44); b+=s2
    b += '<line x1="340" y1="101" x2="378" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">The Edicts are the oldest deciphered Indian writing — and a king’s own voice speaking to us across 2,300 years.</text>'
    return _wrap(W, H, 'The Edicts — an empire’s public conscience', _tk(b, W, H, 'He published his ethics permanently, in the people’s own languages — the first great ruler to explain himself to the ruled.'), '', AC)

def svg_rediscovery():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">how the greatest Indian king was lost — and found again</text>'
    boxes=[(40,'#6b7280','Forgotten for ages','the empire falls; the script becomes unreadable'),
           (270,'#0369a1','Prinsep decodes Brahmi','in 1837 the mysterious “Piyadasi” edicts are read'),
           (500,'#c2410c','Reclaimed as a symbol','the Sarnath lions become India’s national emblem')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">A king erased from memory now sits at the heart of India’s flag and its state emblem.</text>'
    return _wrap(W, H, 'Lost and rediscovered', _tk(b, W, H, 'Forgotten for two millennia, he was decoded from his own stones and made the emblem of a modern nation.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE CRUEL PRINCE
PHASE_RISE = [
    E('maurya', 'c. 304–270 BC', 'Heir to the greatest Indian empire', ['RISE'],
      'He is born a prince of the Maurya empire — the vast state his grandfather Chandragupta forged with the help of the shrewd strategist Chanakya — and grows up as a capable, ambitious son of the king, one of many rivals for the throne.',
      svg_stack('The empire he was born to inherit', [
          {'n': 1, 'label': 'Grandfather: Chandragupta', 'sub': 'founded the Maurya empire with Chanakya', 'color': '#c2410c'},
          {'n': 2, 'label': 'Father: Bindusara', 'sub': 'extends the empire across most of India', 'color': '#b45309'},
          {'n': 3, 'label': 'Ashoka, a capable prince', 'sub': 'proves himself as a tough provincial governor', 'color': '#166534'},
      ], takeaway='He inherited the largest empire India had ever seen — and the ruthless statecraft that built it.', accent=AC),
      bg='The <b>Maurya Empire</b>, founded by <b>Chandragupta Maurya</b> (advised by the strategist <b>Chanakya/Kautilya</b>) and expanded by <b>Bindusara</b>, was the first to unite most of the Indian subcontinent.',
      people='His grandfather <b>Chandragupta</b>; the strategist <b>Chanakya</b>, author of the <i>Arthashastra</i>; his father <b>Bindusara</b>; his many brothers, rivals for the succession.',
      what='Ashoka grew up a prince of this powerful state and served as a <b>provincial governor</b> (at Ujjain and Taxila), earning a reputation for administrative and military ability.',
      crux='He was formed by a tradition of <b>hard, calculating statecraft</b> — the Maurya empire was built and held by force, spies and cold policy, the very things he would later renounce.',
      conseq='On Bindusara’s death, a violent succession struggle broke out among the brothers — and Ashoka emerged the victor.',
      matters='The greatest transformations start from a fixed point. Ashoka began as a conventional Maurya prince before becoming something unprecedented.'),

    E('chandragupta', 'c. 320–297 BC', 'The machine he inherited — Chandragupta’s state', ['RISE', 'POLITICS'],
      'Ashoka did not build the Mauryan Empire — he inherited a ruthless, tightly-run war-state forged by his grandfather Chandragupta and the master strategist Kautilya, whose manual of power, the Arthashastra, prized spies, control and force above all.',
      svg_stack('A conquest-state two generations old', [
          {'n': 1, 'label': 'Chandragupta founds the empire', 'sub': 'overthrows the Nandas, checks the Greeks, unifies the north', 'color': '#c2410c'},
          {'n': 2, 'label': 'Kautilya’s Arthashastra', 'sub': 'a cold manual of statecraft — spies, taxes, force', 'color': '#78350f'},
          {'n': 3, 'label': 'A bureaucratic war-machine', 'sub': 'Ashoka inherits its armies, treasury and network of control', 'color': '#a16207'},
      ], takeaway='The empire’s foundation was pure power politics — which makes Ashoka’s later moral turn all the more startling.', accent=AC),
      bg='<b>Chandragupta Maurya</b> (r. c. 321–297 BC), advised by the brilliant, ruthless <b>Kautilya</b> (Chanakya), had built the largest empire India had seen, absorbing the Greek-influenced northwest after Alexander.',
      people='<b>Chandragupta</b>, the founder-grandfather; <b>Kautilya</b>, author of the Arthashastra; <b>Bindusara</b>, Ashoka’s father, who extended the empire southward.',
      what='Ashoka inherited a state organised for <b>conquest and control</b> — a standing army, an elaborate tax system, and a spy network — all justified by the <b>Arthashastra’s</b> hard-nosed philosophy of power.',
      crux='He began with the tools of a <b>ruthless imperial machine</b>, not a saint’s vocation — his transformation had to overcome that inheritance.',
      conseq='The contrast between the Arthashastra’s cold statecraft and Ashoka’s later dhamma is one of history’s sharpest reversals in the same dynasty.',
      matters='What a leader inherits sets the baseline — the measure of change is how far they move from the machine handed to them.'),

    E('taxila', 'c. 285–270 BC', 'The able viceroy — proving himself at Taxila and Ujjain', ['RISE', 'POLITICS'],
      'Long before the throne, he serves as a hard, capable provincial governor — famously sent to quell a revolt at the great frontier city of Taxila, and ruling the rich province of Ujjain — building the administrative and military reputation that would make him a serious contender for power.',
      svg_row('The apprenticeship of a future emperor', [
          {'n': 1, 'label': 'Viceroy of Ujjain', 'sub': 'governs a wealthy central province', 'color': '#c2410c'},
          {'n': 2, 'label': 'Sent to Taxila', 'sub': 'dispatched to put down a frontier revolt', 'color': '#b45309'},
          {'n': 3, 'label': 'Proves his competence', 'sub': 'earns a name as an effective, tough administrator', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He learned to govern and to fight in the provinces — the practical schooling of the ruler he would become.', accent=AC),
      bg='As a Maurya prince, Ashoka was given real responsibility in the provinces — the training ground for imperial rule.',
      people='The restive people of <b>Taxila</b>, a great northwestern city; the administrators of <b>Ujjain</b>, his provincial seat.',
      what='Ashoka served as <b>viceroy of Ujjain</b> and was reportedly sent to <b>suppress a revolt at Taxila</b>, gaining a reputation as a <b>capable and forceful governor</b> — practical experience of both administration and war.',
      crux='He mastered the <b>machinery of Maurya power</b> at the provincial level before ever holding the throne — the competence that made his later contest for succession credible.',
      conseq='This record of ability positioned him to prevail in the violent succession struggle after Bindusara’s death.',
      matters='Great rulers are usually forged in real administrative and military apprenticeship. Ashoka’s provincial years were the making of the emperor.'),

    E('cruel', 'c. 268 BC', 'The bloody road to the throne', ['POLITICS', 'RISE'],
      'He wins the throne through a violent succession struggle, and Buddhist tradition remembers his early reign as that of "Chandashoka" — Ashoka the Cruel — a hard, harsh king, before the war that would remake him.',
      svg_row('From “Ashoka the Cruel” to king', [
          {'n': 1, 'label': 'Succession war', 'sub': 'defeats his brothers for the throne', 'color': '#7f1d1d'},
          {'n': 2, 'label': '“Chandashoka”', 'sub': 'tradition recalls a cruel early reign', 'color': '#b45309'},
          {'n': 3, 'label': 'Crowned emperor', 'sub': 'rules the vast Maurya state, c. 268 BC', 'color': '#c2410c'},
      ], edge_labels=['then', 'then'], takeaway='He began as a hard, even cruel king — which makes his later transformation all the more remarkable.', accent=AC),
      bg='Ottoman-style succession violence was not unique to that empire; in Maurya India too, a king’s death could mean a war among his sons. Ashoka’s accession (c. 268 BC) followed such a struggle.',
      people='His defeated brothers (later legend exaggerates their number); the ministers who backed his claim.',
      what='Ashoka seized the throne after a <b>violent contest</b>. Later Buddhist texts (like the <i>Ashokavadana</i>) paint his early years as harsh and cruel — the phase they call <b>“Chandashoka.”</b>',
      crux='The <b>legendary cruelty of his early reign</b> is partly moralising literature written to heighten the contrast with his later conversion — but the violent path to power is historically plausible.',
      conseq='For roughly eight years he ruled as a conventional, expansionist Maurya emperor — until the war with Kalinga changed everything.',
      matters='Legend and history blur around great figures. We should hold the “cruel Ashoka” stories lightly — but his transformation is documented in his own words.'),
]

# ==================================================================  PHASE 2 — KALINGA
PHASE_KALINGA = [
    E('whyKalinga', 'c. 262 BC', 'Why Kalinga — the one prize left unconquered', ['POLITICS', 'BATTLE'],
      'Kalinga was the glaring gap in the Mauryan map: a proud, wealthy independent kingdom astride the eastern coast and its rich trade routes, which even Chandragupta had failed to take — so the ambitious young emperor set out to finish the family’s conquest.',
      svg_row('The strategic logic behind the war', [
          {'n': 1, 'label': 'An unconquered coast', 'sub': 'Kalinga stayed independent as the empire grew around it', 'color': '#c2410c'},
          {'n': 2, 'label': 'Wealth and trade routes', 'sub': 'controls eastern sea trade and the road to the south', 'color': '#78350f'},
          {'n': 3, 'label': 'A conventional imperial goal', 'sub': 'Ashoka attacks to complete the Mauryan conquest', 'color': '#a16207'},
      ], edge_labels=['means', 'so'], takeaway='The invasion began as ordinary empire-building — the last piece of the map, not a moral crisis.', accent=AC),
      bg='<b>Kalinga</b> (roughly modern Odisha) was a rich, self-governing kingdom that had resisted Mauryan absorption, controlling valuable coastal trade and the routes toward south India.',
      people='The people and army of Kalinga, who resisted fiercely; the Mauryan war-machine; the merchants whose trade the region commanded.',
      what='Around 262–261 BC Ashoka invaded Kalinga to <b>complete the imperial conquest</b> his forebears had left unfinished — a war of ambition, waged with the full force of the Mauryan army.',
      crux='It started as a <b>routine act of empire</b>: seizing the one wealthy region still outside Mauryan control.',
      conseq='The scale of the resulting slaughter — by his own edicts, 100,000 killed and 150,000 deported — turned a conventional conquest into the trauma that changed him.',
      matters='World-changing turns can begin as the most ordinary decisions — the meaning is revealed only by what the act unleashes.'),

    E('war', 'c. 261 BC', 'The conquest of Kalinga', ['BATTLE', 'TRIUMPH', 'TRAGEDY'],
      'He invades the independent kingdom of Kalinga and wins — but the cost is staggering: by his own later reckoning, a hundred thousand killed, a hundred and fifty thousand deported, and many more dead of its aftermath.',
      svg_row('A conquest of appalling cost', [
          {'n': 1, 'label': 'Invades Kalinga', 'sub': 'the last major independent Indian kingdom', 'color': '#c2410c'},
          {'n': 2, 'label': 'Wins the war', 'sub': 'Maurya power crushes fierce resistance', 'color': '#b45309'},
          {'n': 3, 'label': 'A catastrophe of dead', 'sub': '~100,000 killed, 150,000 deported (his own figures)', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He got exactly the victory he wanted — and it horrified him.', accent=AC),
      bg='<b>Kalinga</b> (modern Odisha) was a prosperous, independent kingdom on the east coast — a gap in the otherwise complete Maurya control of the subcontinent.',
      people='The people and soldiers of Kalinga; Ashoka and his army.',
      what='Around <b>261 BC</b> Ashoka conquered Kalinga in a hugely destructive war. In his own <b>Thirteenth Major Rock Edict</b>, he records roughly <b>100,000 killed, 150,000 deported</b>, and many more dead from the war’s aftermath.',
      crux='The Kalinga war was a <b>complete military success</b> that produced a <b>moral catastrophe</b> — and, uniquely, the conqueror himself recorded and lamented the human cost in a public inscription.',
      conseq='The scale of the suffering triggered in Ashoka a profound crisis of conscience that would reverse the entire direction of his reign.',
      matters='Victory and horror can be the same event. Kalinga is history’s starkest case of a triumph that broke its victor.'),

    E('remorse', 'c. 260 BC', 'Remorse — and the turn to dhamma', ['TURNING POINT', 'REFORM'],
      'Overwhelmed by the suffering he has caused, he renounces war as an instrument of policy, embraces Buddhism, and resolves to rule by "dhamma" — moral force — instead of the sword. It is one of the great conversions of history.',
      svg_kalinga(),
      bg='In the aftermath of Kalinga, Ashoka experienced a deep and, by his own account, sincere remorse — a rejection of the conquest that had defined Maurya kingship.',
      people='Buddhist teachers who guided his conversion; the monk-community (<b>sangha</b>) he came to support.',
      what='Ashoka publicly declared his <b>remorse</b> for Kalinga, embraced <b>Buddhism</b>, and announced that henceforth his only true conquest would be <b>“conquest by dhamma”</b> (moral law) rather than by arms.',
      crux='He made a genuine <b>reversal of the purpose of power</b>: from expanding the empire by force to improving it by ethics — an almost unheard-of shift for a ruler at the height of success.',
      conseq='The remaining decades of his reign were devoted to welfare, tolerance, and the promotion of dhamma across and beyond his empire.',
      matters='People — even emperors — can genuinely change. Ashoka’s turn from conqueror to moral ruler is the reason he is remembered as “the Great.”'),
]

# ==================================================================  PHASE 3 — DHAMMA
PHASE_DHAMMA = [
    E('dhamma', 'c. 260–232 BC', 'Rule by dhamma — the moral empire', ['REFORM', 'TRIUMPH'],
      'He builds what may be history’s first welfare state: hospitals for people and animals, wells and shade-trees along the roads, rest-houses for travellers, humane laws, and a policy of tolerance for every religion — governance as an act of conscience.',
      svg_dhamma(),
      bg='Ashoka defined <b>dhamma</b> not as narrow religion but as a broad ethic of <b>right conduct</b>: non-violence, honesty, compassion, tolerance and welfare — a common moral code for a diverse empire.',
      people='The <b>dhamma-mahamatras</b> (officers of morality) he appointed to promote welfare and mediate disputes; his subjects of many faiths.',
      what='Ashoka established <b>medical care for humans and animals</b>, dug <b>wells</b>, planted <b>shade trees</b>, built <b>rest-houses</b>, softened harsh laws, promoted <b>tolerance among all sects</b>, and restricted animal slaughter — administering the empire as a moral project.',
      crux='He tried to hold a vast, diverse empire together with a <b>shared ethic rather than pure force</b> — substituting moral legitimacy for the sword.',
      conseq='For decades the Maurya empire enjoyed a period of relative peace and unusually humane governance for the ancient world.',
      matters='The idea that a state should actively care for the welfare of all its people — and tolerate all its faiths — is astonishingly modern for the 3rd century BC.'),

    E('mahamatras', 'c. 256 BC', 'Officers of dhamma — a moral civil service', ['REFORM', 'POLITICS'],
      'To turn his ethic into administration, Ashoka creates an entirely new class of officials — the dhamma-mahamatras — charged not with tax or war but with promoting welfare, tolerance and justice across every community and faith.',
      svg_stack('Bureaucratising virtue', [
          {'n': 1, 'label': 'A new office is invented', 'sub': 'the “dhamma-mahamatras” — officers of righteousness', 'color': '#c2410c'},
          {'n': 2, 'label': 'Their duties: welfare & fairness', 'sub': 'aid the poor, elderly and prisoners; check officials', 'color': '#78350f'},
          {'n': 3, 'label': 'Across all sects and regions', 'sub': 'work among every faith and community, even outside the empire', 'color': '#16a34a'},
      ], takeaway='He didn’t just preach morality — he built a state machinery to deliver and monitor it.', accent=AC),
      bg='An empire cannot be reformed by proclamations alone. Ashoka needed officials whose specific job was to translate <b>dhamma</b> into everyday practice.',
      people='The <b>dhamma-mahamatras</b> themselves; the diverse communities they served — Buddhists, Brahmins, Jains, Ajivikas; the ordinary subjects meant to benefit.',
      what='He established the <b>dhamma-mahamatras</b>, officers tasked with promoting welfare, ensuring fair treatment, aiding the vulnerable, and fostering harmony among all religions — a civil service devoted to ethics.',
      crux='He grasped that values need <b>institutions to carry them</b> — turning a personal conversion into durable governance.',
      conseq='It was one of history’s earliest attempts at a welfare-and-ethics bureaucracy, extending even to relations with neighbouring peoples.',
      matters='Ideals only reshape a society when embodied in institutions — someone must be paid to make them real.'),

    E('edicts', 'c. 260–232 BC', 'The Edicts — a king who explained himself', ['REFORM', 'TURNING POINT'],
      'He inscribes his principles on rocks and towering polished pillars across the empire — in the people’s own languages, even Greek and Aramaic on the frontier — creating both the oldest deciphered Indian writing and the personal voice of a ruler speaking across 2,300 years.',
      svg_edicts(),
      bg='To communicate dhamma to a largely illiterate, multilingual empire, Ashoka had his messages <b>carved in stone</b> at sites across the realm and its borders.',
      people='The stone-carvers and officials who set up the edicts; later, the scholar <b>James Prinsep</b>, who would decipher them.',
      what='Ashoka issued the <b>Major and Minor Rock Edicts</b> and the <b>Pillar Edicts</b> — inscriptions in <b>Prakrit (Brahmi script)</b>, and in <b>Greek and Aramaic</b> in the northwest — proclaiming his ethics, his remorse for Kalinga, and his welfare policies.',
      crux='He was perhaps the <b>first ruler in history to publicly and permanently explain his own moral reasoning</b> to his people, in their languages — a radical act of accountability.',
      conseq='The edicts are the <b>primary source</b> for Ashoka’s reign and the earliest firmly dated Indian texts; his pillars became icons of Indian art.',
      matters='A ruler who writes down and justifies his ethics to the ruled is doing something extraordinary. Ashoka’s stones still speak in his own voice.'),

    E('welfare', 'c. 256 BC', 'The welfare state in stone — wells, roads and medicine', ['REFORM', 'TRIUMPH'],
      'Ashoka’s edicts boast not of conquests but of public works: shade trees and wells along the roads, rest-houses for travellers, and — remarkably — medical care and healing herbs planted for both humans and animals, across his lands and his neighbours’.',
      svg_stack('Governing as care, not conquest', [
          {'n': 1, 'label': 'Roads made humane', 'sub': 'banyan trees for shade, wells, and rest-houses for travellers', 'color': '#16a34a'},
          {'n': 2, 'label': 'Medicine for all', 'sub': 'healing herbs and treatment provided for people and animals', 'color': '#c2410c'},
          {'n': 3, 'label': 'Even beyond his borders', 'sub': 'he claims to fund welfare in neighbouring kingdoms too', 'color': '#78350f'},
      ], takeaway='He redefined a great king’s boast — from lands conquered to lives eased.', accent=AC),
      bg='Ancient kings advertised their glory through victories. Ashoka instead had his <b>public works</b> and welfare measures carved into rock for all to read.',
      people='The travellers, farmers and sick who benefited; the officials who dug the wells and planted the trees; the neighbouring rulers he claimed to help.',
      what='His edicts record planting <b>shade trees and wells</b> along roads, building <b>rest-houses</b>, and providing <b>medical herbs and care for humans and animals</b> — described as extending even to bordering realms.',
      crux='He reconceived the purpose of state power as <b>the welfare of living beings</b>, and measured his reign by it.',
      conseq='These are among the earliest recorded state welfare programmes, and they anchored his reputation as a model of benevolent rule.',
      matters='How a ruler defines success — territory or wellbeing — shapes everything the state actually does.'),

    E('tolerance', 'c. 256 BC', 'Legislating tolerance — honour every faith', ['REFORM', 'TURNING POINT'],
      'In an age of sectarian rivalry he does something astonishing: he issues an edict positively commanding respect for all religions, warns that praising your own sect by attacking others harms both, and appoints special officers to promote welfare and harmony among every faith and people.',
      svg_stack('An official policy of pluralism', [
          {'n': 1, 'label': 'Honour all sects', 'sub': 'Rock Edict XII: respect other faiths as your own', 'color': '#c2410c'},
          {'n': 2, 'label': '“Concord is best”', 'sub': 'attacking other sects harms your own too', 'color': '#0369a1'},
          {'n': 3, 'label': 'Officers of dhamma', 'sub': 'dhamma-mahamatras promote welfare and harmony', 'color': '#166534'},
      ], takeaway='He didn’t merely tolerate other religions — he made mutual respect an active, enforced policy of the state.', accent=AC),
      bg='Ashoka’s empire contained Buddhists, Brahmins, Jains, Ajivikas and more; sectarian competition was a real source of conflict.',
      people='The many religious communities of the empire; the <b>dhamma-mahamatras</b>, officers tasked with promoting welfare and inter-faith harmony.',
      what='In his <b>Twelfth Major Rock Edict</b> and others, Ashoka <b>commanded respect for all religious sects</b>, warned that exalting one’s own faith by disparaging others damages both, and used his <b>officers of dhamma</b> to promote concord and welfare across all communities.',
      crux='He turned <b>tolerance from a private virtue into official state policy</b> — an active, articulated pluralism remarkably ahead of its time.',
      conseq='His policy gave a diverse empire a shared ethic of mutual respect, reducing sectarian friction and reinforcing unity.',
      matters='State-sponsored religious tolerance, argued and enforced, is a strikingly modern idea — and Ashoka proclaimed it in stone in the 3rd century BC.'),

    E('justice', 'c. 256 BC', 'Softening the law — mercy and its limits', ['REFORM', 'POLITICS'],
      'Ashoka reforms his empire’s harsh justice — demanding uniform, fair procedure, granting condemned prisoners a three-day respite to prepare and appeal — yet, honestly, he never abolishes the death penalty, revealing the gap between an ideal and a working state.',
      svg_row('A gentler law — but not a soft one', [
          {'n': 1, 'label': 'Uniform, fair procedure', 'sub': 'demands consistency and impartiality in judgement', 'color': '#c2410c'},
          {'n': 2, 'label': 'A respite for the condemned', 'sub': 'three days’ grace to appeal, settle affairs, prepare the mind', 'color': '#78350f'},
          {'n': 3, 'label': 'But death remains', 'sub': 'he keeps capital punishment — reform, not abolition', 'color': '#b91c1c'},
      ], edge_labels=['and', 'yet'], takeaway='He humanised the law without disarming the state — the honest limit of a ruler’s idealism.', accent=AC),
      bg='The Mauryan legal system, rooted in the Arthashastra, could be severe. Ashoka sought to make it fairer and more merciful — within the constraints of ruling a vast empire.',
      people='The judges and officials he instructed; the prisoners granted respite; the subjects promised uniform treatment.',
      what='His edicts call for <b>consistency and fairness</b> in justice and grant the condemned a <b>three-day stay</b> before execution. But he <b>retained the death penalty</b> and the machinery of state coercion.',
      crux='He pushed his ideals <b>as far as governing a real empire allowed</b> — mercy tempered by the hard necessities of order.',
      conseq='It stands as a genuine, early humanising of criminal justice — and a candid reminder that even the most benevolent ancient king ruled by force.',
      matters='The measure of an idealist in power is not perfection but how far they bend the machine toward mercy while still making it work.'),

    E('animals', 'c. 258 BC', 'Mercy to all living things — the animal edicts', ['REFORM', 'TRIUMPH'],
      'His compassion extends past humans to all living creatures: he restricts the slaughter of animals, bans many cruel sacrifices and hunts, and — remarkably for the ancient world — establishes medical care for animals as well as people, planting shade trees and digging wells along the roads for man and beast alike.',
      svg_row('Compassion extended to all creatures', [
          {'n': 1, 'label': 'Restrict animal slaughter', 'sub': 'limits killing; bans many sacrifices and hunts', 'color': '#c2410c'},
          {'n': 2, 'label': 'Care for animals too', 'sub': 'medical treatment for beasts as well as people', 'color': '#166534'},
          {'n': 3, 'label': 'Wells and shade for all', 'sub': 'roadside relief for humans and animals alike', 'color': '#b45309'},
      ], edge_labels=['plus', 'plus'], takeaway='His ethic of non-harm reached beyond people to every living thing — astonishingly humane for its age.', accent=AC),
      bg='Ashoka’s principle of <b>ahimsa</b> (non-violence) extended his dhamma to the treatment of <b>animals</b>, not just humans.',
      people='The subjects bound by the new restrictions; the animals protected; later generations who saw the edicts as pioneering.',
      what='In his edicts, Ashoka <b>restricted the slaughter of animals</b>, banned many <b>sacrifices and hunts</b>, provided <b>medical care for animals</b> as well as humans, and planted <b>shade trees and wells</b> along roads for the benefit of all living beings.',
      crux='He applied his ethic of <b>non-harm universally</b>, to animals as well as people — an extraordinarily broad compassion for the 3rd century BC.',
      conseq='These measures made his empire a rare early model of institutionalised kindness to all living things.',
      matters='Ashoka’s concern for animals is one of the earliest state expressions of compassion beyond the human — strikingly ahead of its time.'),

    E('greekedicts', 'c. 258 BC', 'Speaking to the Greek world — the frontier edicts', ['REFORM', 'TURNING POINT'],
      'On his empire’s northwestern edge, where the Hellenistic world of Alexander’s successors began, he has his dhamma inscribed not only in Indian languages but in Greek and Aramaic — a bilingual message, found at Kandahar, deliberately reaching across civilisations to speak to peoples far beyond India.',
      svg_row('A message across civilisations', [
          {'n': 1, 'label': 'The Hellenistic frontier', 'sub': 'Greek-speaking lands on the empire’s edge', 'color': '#c2410c'},
          {'n': 2, 'label': 'Greek & Aramaic edicts', 'sub': 'the Kandahar bilingual inscription', 'color': '#0369a1'},
          {'n': 3, 'label': 'Dhamma for the world', 'sub': 'ethics addressed to peoples beyond India', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He spoke his ethics in Greek and Aramaic to reach the Hellenistic world — a message meant for all humanity.', accent=AC),
      bg='Ashoka’s northwest bordered the <b>Hellenistic world</b> left by Alexander’s successors, where <b>Greek and Aramaic</b> were spoken.',
      people='The Greek and Persian-speaking populations of the frontier; the scribes who carved the bilingual edicts at <b>Kandahar</b>.',
      what='Ashoka had edicts inscribed in <b>Greek and Aramaic</b> (notably the <b>Kandahar bilingual edict</b>) on his northwestern frontier, deliberately addressing his message of dhamma to <b>non-Indian peoples</b> in their own languages.',
      crux='He conceived his ethics as <b>universal, not merely Indian</b> — worth proclaiming across languages and civilisations.',
      conseq='These inscriptions are precious evidence of contact between Mauryan India and the Hellenistic world.',
      matters='Ashoka addressed his moral vision to all humanity, in their own tongues — one of history’s first truly cross-civilisational messages.'),
]

# ==================================================================  PHASE 4 — THE WORLD RELIGION
PHASE_WORLD = [
    E('pilgrimage', 'c. 250 BC', 'The dhamma tours — pilgrimage replaces the hunt', ['REFORM', 'TURNING POINT'],
      'Where kings once toured to hunt and display power, Ashoka replaces the royal hunt with pilgrimages of dhamma — visiting the Buddha’s birthplace at Lumbini, cutting its taxes, and marking the sacred sites with pillars still standing today.',
      svg_stack('Turning the royal progress into a pilgrimage', [
          {'n': 1, 'label': 'Ends the royal hunt', 'sub': 'the traditional display of kingly power is abandoned', 'color': '#78350f'},
          {'n': 2, 'label': 'Dhamma-yatras instead', 'sub': 'tours to sacred sites, meeting sages and common people', 'color': '#c2410c'},
          {'n': 3, 'label': 'Lumbini honoured, c. 249 BC', 'sub': 'visits the Buddha’s birthplace; cuts its tax; raises a pillar', 'color': '#16a34a'},
      ], takeaway='He rebranded the very rituals of kingship — from the violence of the hunt to the devotion of the pilgrim.', accent=AC),
      bg='Royal tours (yatras) traditionally featured hunting and shows of might. Ashoka, deepening as a lay Buddhist (upasaka), transformed their purpose.',
      people='The sages and elders he visited; the people he met and instructed on the road; the officials who erected the commemorative pillars.',
      what='He replaced hunting tours with <b>dhamma-yatras</b>, journeying to holy places. At <b>Lumbini</b> he raised a pillar recording his visit and <b>reduced the village’s taxes</b> — an inscription that helped modern scholars locate the Buddha’s birthplace.',
      crux='He used the <b>symbolism of the throne itself</b> to broadcast his values — even the king’s travels became moral instruction.',
      conseq='The <b>Rummindei (Lumbini) pillar</b> survives as concrete evidence tying Ashoka to the Buddhist holy sites and to a living historical record.',
      matters='Leaders teach by what they visibly do — reshaping royal ritual can preach louder than any edict.'),

    E('buddhism', 'c. 250 BC', 'Turning a sect into a world religion', ['REFORM', 'TRIUMPH'],
      'He convenes a great Buddhist council, and — crucially — sends missionaries far beyond his empire, including his own son and daughter to Sri Lanka, transforming Buddhism from a regional Indian teaching into one of the world’s great faiths.',
      svg_row('Exporting a faith across Asia', [
          {'n': 1, 'label': 'The Third Council', 'sub': 'consolidates Buddhist teaching at Pataliputra', 'color': '#c2410c'},
          {'n': 2, 'label': 'Sends missionaries', 'sub': 'to Sri Lanka, Central Asia and beyond', 'color': '#b45309'},
          {'n': 3, 'label': 'His children to Sri Lanka', 'sub': 'Mahinda and Sanghamitta carry the faith south', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='By exporting the faith, he turned a local Indian sect into a religion for half of Asia.', accent=AC),
      bg='Buddhism in the 3rd century BC was still largely a north Indian movement. Ashoka’s patronage and missionary drive changed its scale forever.',
      people='His son <b>Mahinda</b> and daughter <b>Sanghamitta</b>, who took Buddhism to <b>Sri Lanka</b>; the monks sent to distant lands.',
      what='Ashoka supported the <b>Third Buddhist Council</b> (traditionally at Pataliputra) and dispatched <b>missionaries</b> across and beyond his empire — most famously his children Mahinda and Sanghamitta to <b>Sri Lanka</b>, where Buddhism took deep and lasting root.',
      crux='His state patronage and, above all, his <b>outward missionary effort</b> gave Buddhism the reach to become a <b>trans-regional world religion</b> rather than a local sect.',
      conseq='Buddhism spread to Sri Lanka, Central Asia and eventually East Asia — one of the most consequential religious diffusions in history.',
      matters='Ideas need carriers. Without Ashoka’s missionaries, Buddhism might have remained a minor Indian tradition rather than a faith of hundreds of millions.'),

    E('mahinda', 'c. 250 BC', 'Sri Lanka — the mission of his own children', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'Ashoka’s greatest religious success is carried by his own family: his son Mahinda converts the king of Sri Lanka to Buddhism, and his daughter Sanghamitta follows with a sapling of the very tree the Buddha sat under — planting a faith that thrives on the island to this day.',
      svg_stack('A faith carried by his children', [
          {'n': 1, 'label': 'Mahinda sent to Sri Lanka', 'sub': 'Ashoka’s son leads the mission across the strait', 'color': '#c2410c'},
          {'n': 2, 'label': 'King Tissa converts', 'sub': 'the Sri Lankan king and court embrace Buddhism', 'color': '#16a34a'},
          {'n': 3, 'label': 'The Bodhi tree sapling', 'sub': 'Sanghamitta brings a cutting of the sacred tree to Anuradhapura', 'color': '#78350f'},
      ], takeaway='He exported the faith through his own family — and in Sri Lanka it took root permanently.', accent=AC),
      bg='Ashoka sponsored Buddhist missions to many lands. The one to <b>Sri Lanka</b>, recorded in the island’s own chronicles, became the most enduring.',
      people='<b>Mahinda</b>, his son and the mission’s leader; <b>Sanghamitta</b>, his daughter, who brought the tree; <b>King Devanampiya Tissa</b> of Sri Lanka, the royal convert.',
      what='By tradition, <b>Mahinda</b> converted King Tissa and his court, and <b>Sanghamitta</b> carried a <b>sapling of the Bodhi tree</b> to Anuradhapura, where its descendant still grows — establishing the Theravada Buddhism that defines Sri Lanka today.',
      crux='He turned his mission into a <b>family enterprise</b>, lending it the prestige of the royal house and ensuring its seriousness.',
      conseq='Sri Lanka became a lasting Buddhist heartland and later helped transmit the faith across Southeast Asia — one of Ashoka’s most concrete legacies.',
      matters='Ideas travel furthest when their carriers are fully invested — sending one’s own children signals total commitment.'),

    E('diplomacy', 'c. 256 BC', 'Dhamma diplomacy — envoys to the Greek kings', ['POLITICS', 'REFORM'],
      'His vision reaches astonishingly far: in his own edicts he claims to have sent missions of dhamma to the great Hellenistic kings of the West — named as Antiochus, Ptolemy and others — attempting, uniquely for an ancient ruler, a kind of moral diplomacy across the known world.',
      svg_row('Moral diplomacy across the known world', [
          {'n': 1, 'label': 'Names the Greek kings', 'sub': 'Antiochus, Ptolemy and others in his edicts', 'color': '#c2410c'},
          {'n': 2, 'label': 'Sends dhamma missions', 'sub': 'envoys of ethics to the Hellenistic world', 'color': '#0369a1'},
          {'n': 3, 'label': 'A moral foreign policy', 'sub': 'unique attempt to spread an ethic abroad', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He tried to export not conquest but conscience — naming the Greek kings he sent his ethics to.', accent=AC),
      bg='Ashoka’s <b>Thirteenth Rock Edict</b> names contemporary <b>Hellenistic rulers</b> to whom he claims to have sent missions promoting dhamma.',
      people='The Hellenistic kings named in the edict — <b>Antiochus II, Ptolemy II</b> and others; the envoys Ashoka dispatched.',
      what='In his edicts, Ashoka claims to have sent <b>missions of dhamma</b> to the great kings of the Hellenistic world — <b>Antiochus, Ptolemy, Antigonus, Magas and Alexander</b> — attempting a remarkable form of <b>moral diplomacy</b> across the known world.',
      crux='He conceived foreign policy as the <b>spread of an ethic rather than territory</b> — a genuinely unique ambition among ancient rulers.',
      conseq='Whatever their reception, the missions attest to Mauryan India’s wide diplomatic reach and Ashoka’s universalist vision.',
      matters='Ashoka tried to export conscience, not conquest — perhaps the first ruler in history to attempt moral diplomacy on a world scale.'),

    E('ajivikas', 'c. 250 BC', 'Caves for rival monks — tolerance made concrete', ['REFORM', 'TURNING POINT'],
      'Ashoka’s religious tolerance was not just words: though a Buddhist, he personally donates a set of beautifully polished rock-cut caves to the Ajivikas, a rival ascetic sect — proof that his call to “honour every faith” meant patronising even the competition.',
      svg_row('Tolerance you can touch', [
          {'n': 1, 'label': 'A Buddhist emperor', 'sub': 'Ashoka’s own devotion is to the Buddha’s teaching', 'color': '#c2410c'},
          {'n': 2, 'label': 'Gifts caves to the Ajivikas', 'sub': 'the Barabar Hills caves, dedicated to a rival sect', 'color': '#78350f'},
          {'n': 3, 'label': 'Words matched by deeds', 'sub': 'his tolerance edicts backed by real, dated patronage', 'color': '#16a34a'},
      ], edge_labels=['yet', 'so'], takeaway='He funded the faiths he did not share — turning a slogan of tolerance into hard, carved fact.', accent=AC),
      bg='The <b>Ajivikas</b> were a determinist ascetic sect, rivals of the Buddhists and Jains. Ashoka’s edicts urged respect for all sects; his patronage tested that ideal.',
      people='The <b>Ajivika</b> ascetics who received the caves; the stone-cutters who created the mirror-polished interiors; the later generations who marvelled at them.',
      what='Ashoka (and his grandson) dedicated the <b>Barabar Hills caves</b> — among the oldest surviving rock-cut architecture in India, famous for their polished acoustics — to the <b>Ajivikas</b>, a sect he did not belong to.',
      crux='He demonstrated that <b>tolerance meant patronage of rivals</b>, not mere passive coexistence — a genuinely rare stance for a ruler.',
      conseq='The dated dedications are hard evidence of his pluralism, and the caves influenced centuries of Indian rock-cut architecture.',
      matters='Real tolerance is measured by generosity to those you disagree with — not by kindness to your own.'),

    E('council', 'c. 250 BC', 'The Third Buddhist Council — purifying the faith', ['REFORM', 'POLITICS'],
      'He sponsors a great council of the Buddhist order to settle disputes, expel false monks, and fix the true teaching — an act of state patronage that shapes the canon and organisation of Buddhism, even as it shows a ruler using his authority to order the religion he champions.',
      svg_row('Ordering and purifying the sangha', [
          {'n': 1, 'label': 'Disputes split the order', 'sub': 'the monastic community is divided and lax', 'color': '#c2410c'},
          {'n': 2, 'label': 'The Third Council', 'sub': 'convened under the monk Moggaliputta Tissa', 'color': '#0369a1'},
          {'n': 3, 'label': 'False monks expelled', 'sub': 'the teaching clarified; missions then sent out', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He used royal authority to purify and organise the Buddhist order — patronage that shaped the faith’s future.', accent=AC),
      bg='By Ashoka’s time the Buddhist <b>sangha</b> (monastic order) was troubled by disputes and lax or false monks.',
      people='The monk <b>Moggaliputta Tissa</b>, who presided; the assembled monks; the missionaries dispatched afterward.',
      what='Ashoka sponsored the <b>Third Buddhist Council</b> (traditionally at Pataliputra, under <b>Moggaliputta Tissa</b>), which <b>settled doctrinal disputes, expelled false monks</b>, helped fix the teaching, and organised the great <b>missionary effort</b> that followed.',
      crux='He used <b>state authority to shape and purify the religion</b> he patronised — powerful support, but also a ruler ordering a faith.',
      conseq='The council helped standardise Buddhist doctrine and launched the missions that spread it across Asia.',
      matters='Royal patronage shapes religions. Ashoka’s council was pivotal to Buddhism’s coherence and its spread — for better and, some argue, with strings attached.'),

    E('schism', 'c. 250 BC', 'The schism edict — enforcing unity in the order', ['POLITICS', 'REFORM'],
      'He issues a stern edict against dividing the monastic community, threatening to defrock any monk or nun who splits the order — a striking case of a king using state power to enforce unity within a religion, showing both his devotion and the limits of his tolerance where the sangha’s cohesion was concerned.',
      svg_row('The state enforcing religious unity', [
          {'n': 1, 'label': 'Guard against schism', 'sub': 'divisions in the sangha threaten the faith', 'color': '#c2410c'},
          {'n': 2, 'label': 'The schism edict', 'sub': 'splitters to be defrocked and expelled', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Unity enforced by the crown', 'sub': 'royal power backs monastic discipline', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='He backed the unity of the Buddhist order with the force of the state — devotion with a hard edge.', accent=AC),
      bg='Ashoka cared deeply about the <b>unity and discipline of the sangha</b>, and used his edicts to protect it from division.',
      people='The monks and nuns bound by the edict; the officials tasked with enforcing it.',
      what='Ashoka issued a <b>“schism edict”</b> warning that any monk or nun who <b>divided the sangha</b> would be expelled from the order — using royal authority to enforce <b>monastic unity</b>.',
      crux='It reveals the <b>limits of even Ashoka’s tolerance</b>: he would use state power to keep the Buddhist order itself united and disciplined.',
      conseq='The edict shows the close, sometimes coercive relationship between his state and the Buddhist community.',
      matters='Ashoka’s tolerance had boundaries. On the unity of the sangha, the compassionate king was willing to wield the state’s hard power.'),

    E('stupas', 'c. 250 BC', 'Building the faith in stone — the stupas', ['REFORM', 'TRIUMPH'],
      'He anchors Buddhism physically across the land, tradition holding that he distributed the Buddha’s relics into countless stupas — famously “84,000” — and raised monuments at the great sacred sites, giving the young religion a permanent, monumental presence that survives to this day.',
      svg_row('Giving a religion a physical home', [
          {'n': 1, 'label': 'Relics distributed widely', 'sub': 'tradition: “84,000” stupas across the realm', 'color': '#c2410c'},
          {'n': 2, 'label': 'Monuments at sacred sites', 'sub': 'Sanchi, Bodh Gaya and the Buddha’s life-places', 'color': '#b45309'},
          {'n': 3, 'label': 'A faith made visible', 'sub': 'Buddhism gains a lasting monumental presence', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He gave Buddhism a body of stone — stupas and monuments that rooted the faith in the landscape for millennia.', accent=AC),
      bg='A religion spreads more durably when it has <b>physical, sacred places</b>. Ashoka became Buddhism’s great early builder.',
      people='The Buddhist community; the pilgrims who would visit the sites for centuries; the craftsmen who built the <b>Great Stupa at Sanchi</b> and others.',
      what='By tradition Ashoka <b>distributed the Buddha’s relics into a vast number of stupas</b> (the famous “84,000”), and built or enlarged monuments at the great sites — the <b>Great Stupa at Sanchi</b>, and shrines at <b>Bodh Gaya</b> and the places of the Buddha’s life.',
      crux='He understood that a faith needs <b>tangible, sacred anchors</b>: monuments make a religion visible, permanent and a focus of pilgrimage.',
      conseq='These monuments — Sanchi above all — endured for over two thousand years and remain among the greatest treasures of Buddhist art.',
      matters='Belief is carried by stone as well as by scripture. Ashoka’s stupas gave Buddhism a permanence that outlasted his empire by millennia.'),

    E('pillars', 'c. 250 BC', 'The lions, the wheel, and a lasting art', ['TRIUMPH', 'REFORM'],
      'His craftsmen raise monolithic polished sandstone pillars crowned with sculptures of extraordinary quality — above all the four-lion capital at Sarnath, which two millennia later becomes the emblem of the Republic of India, its wheel of dhamma set at the centre of the flag.',
      svg_stack('Art that became a nation’s emblem', [
          {'n': 1, 'label': 'The polished pillars', 'sub': 'monolithic sandstone columns, mirror-smooth', 'color': '#c2410c'},
          {'n': 2, 'label': 'The Sarnath lion capital', 'sub': 'four lions back-to-back — a masterpiece', 'color': '#b45309'},
          {'n': 3, 'label': "India's national symbols", 'sub': 'the lions are the state emblem; the wheel is on the flag', 'color': '#166534'},
      ], takeaway='He left an artistic legacy so powerful that a modern nation chose it as its own face.', accent=AC),
      bg='Ashoka’s reign produced a distinctive, technically brilliant imperial art — the <b>Ashokan pillars</b> and their sculpted capitals.',
      people='The unnamed master sculptors of the Maurya workshops; the framers of modern India, who adopted the symbols.',
      what='The <b>Ashokan pillars</b>, especially the <b>Lion Capital of Sarnath</b>, are masterpieces of ancient sculpture. In 1950 independent India adopted the <b>Sarnath lions as its State Emblem</b> and placed the <b>Ashoka Chakra</b> (wheel of dhamma) at the centre of its national flag.',
      crux='His art expressed the <b>fusion of power and dhamma</b> — imperial grandeur harnessed to a moral message — with a technical perfection rarely matched.',
      conseq='These symbols link the modern Indian republic directly to Ashoka’s ideals of dhamma, tolerance and righteous rule.',
      matters='Symbols carry ideas across millennia. When India chose Ashoka’s lions, it chose his vision of a moral, tolerant state as its own.'),
]

# ==================================================================  PHASE 5 — LEGACY & REDISCOVERY
PHASE_LEGACY = [
    E('successors', 'c. 232–185 BC', 'Why the empire fell after him', ['DEATH', 'TRAGEDY', 'TURNING POINT'],
      'His empire proves to be an idea held together by one extraordinary man: within fifty years of his death, weak successors, an overstretched administration, economic strain, and perhaps the very pacifism of his later years leave the Maurya state to fragment and collapse — a warning that a realm built on one ruler’s vision rarely survives him.',
      svg_row('The collapse of a personal empire', [
          {'n': 1, 'label': 'Weak successors', 'sub': 'no heir matches Ashoka’s ability or authority', 'color': '#c2410c'},
          {'n': 2, 'label': 'Overstretch and strain', 'sub': 'a vast empire, costly to hold; economic pressure', 'color': '#b45309'},
          {'n': 3, 'label': 'Collapse by ~185 BC', 'sub': 'the last Maurya is overthrown', 'color': '#7f1d1d'},
      ], edge_labels=['plus', 'then'], takeaway='An empire resting on one man’s vision fragmented once that man was gone — a recurring lesson of history.', accent=AC),
      bg='The vast Maurya empire depended heavily on Ashoka’s personal authority and vision, and faced structural strains beneath its surface.',
      people='Ashoka’s <b>weaker successors</b>; the general who overthrew the last Maurya, <b>Pushyamitra Shunga</b> (c. 185 BC).',
      what='After Ashoka’s death (c. 232 BC), the empire <b>declined rapidly</b> under weaker successors, amid administrative overstretch and economic strain, and <b>collapsed within about fifty years</b> (the last Maurya overthrown c. 185 BC).',
      crux='His empire was ultimately a <b>personal creation</b>: its cohesion depended on him, and it could not long survive his particular genius and authority.',
      conseq='India fragmented into successor states; but Ashoka’s ideas, unlike his empire, would ultimately prove immortal.',
      matters='Empires built on one person rarely outlast them. Ashoka’s legacy endured not as a state but as an idea — which is why he is remembered at all.'),

    E('queens', 'c. 260–232 BC', 'The women around the throne', ['POLITICS', 'LOVE', 'TRAGEDY'],
      'Behind the moral emperor stood several queens — the merchant’s daughter who bore his missionary children, the beloved chief queen honoured in his edicts, and, by legend, a jealous later wife who tried to destroy the sacred Bodhi tree itself.',
      svg_stack('Wives, mothers, and one dangerous rival', [
          {'n': 1, 'label': 'Devi — mother of the missions', 'sub': 'the merchant’s daughter, mother of Mahinda and Sanghamitta', 'color': '#c2410c'},
          {'n': 2, 'label': 'Karuvaki — honoured in stone', 'sub': 'a queen named in his own “Queen’s Edict” for her gifts', 'color': '#16a34a'},
          {'n': 3, 'label': 'Tishyarakshita — the jealous legend', 'sub': 'by tradition, tried to kill the Bodhi tree out of envy', 'color': '#b91c1c'},
      ], takeaway='The human drama of the household sits, half-documented and half-legend, beside the marble image of the sage-king.', accent=AC),
      bg='Ashoka’s personal life is known partly from his edicts and partly from later Buddhist legend. Several queens appear across these sources, some historical, some semi-legendary.',
      people='<b>Devi</b>, his early wife and mother of Mahinda and Sanghamitta; <b>Karuvaki</b>, named in the Queen’s Edict; <b>Asandhimitra</b>, his chief queen; and the legendary <b>Tishyarakshita</b>.',
      what='His edicts record a queen’s charitable gifts (the <b>“Queen’s Edict”</b> for Karuvaki); Buddhist legend adds <b>Devi</b> as the mother of his missionary children and <b>Tishyarakshita</b>, who supposedly tried to poison the <b>Bodhi tree</b> in jealousy.',
      crux='The record mixes <b>documented fact and pious legend</b> — a reminder that even Ashoka’s family reaches us through both stone and story.',
      conseq='Devi’s children carried Buddhism to Sri Lanka; the Bodhi-tree legend became a staple of Buddhist storytelling about the perils of envy.',
      matters='The private lives of the great survive as a blend of evidence and myth — and both shape how they are remembered.'),

    E('sources', 'legend vs record', 'Legend and history — how we know Ashoka', ['POLITICS', 'REFORM'],
      'The Ashoka we meet comes from two very different streams — the pious, embroidered legends of later Buddhist texts, and the sober, first-hand voice of his own edicts in stone — and an honest guide keeps them apart, trusting the stones for the man and reading the legends with care.',
      svg_compare('Two streams of knowledge about Ashoka',
          {'head': 'The legends (later texts)', 'color': '#b45309',
           'items': ['the Ashokavadana and Sri Lankan chronicles', 'colourful tales: the cruel youth, 84,000 stupas', 'pious, embroidered, written centuries later']},
          {'head': 'The record (his edicts)', 'color': '#166534',
           'items': ['his own inscriptions, in his own voice', 'remorse for Kalinga; dhamma; tolerance', 'contemporary, first-hand, firmly dated']},
          verdict='The edicts are the bedrock; the legends are evocative but must be handled with care.',
          takeaway='We trust his stones for the real Ashoka and read the pious legends critically — the honest way to know him.', accent=AC),
      bg='Knowledge of Ashoka comes both from later <b>Buddhist legends</b> and from his own <b>contemporary edicts</b> — very different kinds of evidence.',
      people='The authors of the <b>Ashokavadana</b> and the Sri Lankan chronicles; the scholars who deciphered and interpret the edicts.',
      what='Much of the colourful Ashoka story (his cruel youth, the 84,000 stupas, dramatic conversion scenes) comes from <b>later, pious Buddhist texts</b>, while his <b>remorse for Kalinga, his dhamma and his tolerance</b> are documented in his own <b>edicts</b> — the primary, contemporary source.',
      crux='Responsible history <b>distinguishes the legendary from the documented</b>, trusting the edicts for the core of the man and treating the legends as later elaboration.',
      conseq='This guide follows the edicts for Ashoka’s reign and flags the legendary material as such.',
      matters='Knowing how we know matters. The real Ashoka speaks most reliably through his own stones, not through the pious legends that grew around him.'),

    E('laterlegend', 'after 232 BC', 'From “Ashoka the Fierce” to “Ashoka the Righteous”', ['POLITICS', 'REFORM'],
      'Later Buddhist legend reshaped Ashoka into a parable: the cruel young “Chandashoka” who built a torture-prison, transformed into the pious “Dharmashoka” — a story that ends with the greatest emperor, stripped of power, able to give the Sangha only half a fruit.',
      svg_stack('The making of a moral legend', [
          {'n': 1, 'label': '“Chandashoka” — Ashoka the Fierce', 'sub': 'legend of a cruel prince and a “hell” of tortures', 'color': '#b91c1c'},
          {'n': 2, 'label': '“Dharmashoka” — Ashoka the Righteous', 'sub': 'the conversion narrative of the Ashokavadana', 'color': '#c2410c'},
          {'n': 3, 'label': 'The half-myrobalan', 'sub': 'stripped of power at the end, he can donate only half a fruit', 'color': '#78350f'},
      ], takeaway='The legend turned his life into a lesson: even the mightiest king is humbled, and virtue outweighs empire.', accent=AC),
      bg='Centuries after his death, Buddhist texts like the <b>Ashokavadana</b> recast Ashoka’s life as a moral drama — historically unreliable, but hugely influential.',
      people='The monks who composed the legends; later kings across Asia who took Ashoka as their model; storytellers who spread the parables.',
      what='The legends contrast <b>Chandashoka</b> (the fierce, who built a “prison-hell”) with <b>Dharmashoka</b> (the righteous convert), and end with the aged, powerless emperor able to give the order only <b>half a myrobalan fruit</b> before he dies.',
      crux='Legend distilled his life into an <b>archetype of conversion and impermanence</b> — the value of the story lay in its lesson, not its accuracy.',
      conseq='This idealised Ashoka became the template of the Buddhist “universal righteous king” (chakravartin) that later Asian monarchs aspired to.',
      matters='The great often live twice — once in history, and again as the legend later ages need them to be.'),

    E('legacy', 'c. 232 BC – 1837 AD', 'Death, decline, and rediscovery', ['DEATH', 'TURNING POINT'],
      'He dies around 232 BC, and within fifty years his empire crumbles. For two thousand years he is all but forgotten — until a British scholar deciphers the mysterious "Piyadasi" inscriptions in 1837 and restores to history the emperor who chose conscience over conquest.',
      svg_rediscovery(),
      bg='After Ashoka’s death (c. 232 BC), the vast Maurya empire — perhaps overstretched and reliant on his personal vision — declined and fell within decades (the last Maurya was overthrown c. 185 BC).',
      people='Ashoka’s weaker successors; the scholar <b>James Prinsep</b>, who deciphered the Brahmi script in <b>1837</b>, unlocking the edicts.',
      what='Ashoka’s empire fragmented after him and his memory faded; the <b>Brahmi script</b> of his edicts became unreadable. In <b>1837</b>, <b>James Prinsep</b> deciphered it, and scholars gradually identified the edicts’ author <b>“Devanampiya Piyadasi”</b> (“Beloved of the Gods”) as Ashoka — resurrecting one of history’s great figures.',
      crux='His legacy proved <b>an idea, not an institution</b>: the empire built on his personal moral vision could not outlast him — but the vision itself, once rediscovered, became immortal.',
      conseq='Rediscovered, Ashoka became a global symbol of peace, tolerance and enlightened governance — and the emblem of modern India.',
      matters='Some legacies sleep for millennia and wake more powerful than ever. Ashoka the conqueror was forgotten; Ashoka the moral ruler is now known worldwide.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Ashoka the Great turned the largest empire ancient India ever knew away from conquest and toward conscience. After a war so bloody it broke him, he renounced violence, embraced Buddhism, ruled by <b>dhamma</b> — a shared ethic of tolerance and welfare — and helped turn Buddhism into a world religion. He is a study in <b>genuine transformation, moral power over military power, and a legacy that slept for two thousand years before becoming a nation’s emblem.</b></p>
<div class="ov-quote">“All men are my children.” … “The chiefest conquest is the conquest by dhamma.”<span>— from the Edicts of Ashoka</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A Maurya prince wins the throne by force → conquers Kalinga at appalling human cost → is overwhelmed by remorse and turns to Buddhism → rules the empire by dhamma, building a welfare state and preaching tolerance → carves his ethics in stone across the land → sends missionaries who make Buddhism a world religion → dies, his empire fades, his memory is lost → is rediscovered in 1837 and becomes the emblem of modern India.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🔄</div><h4>Real transformation</h4><p>A conqueror who genuinely renounced conquest — recorded in his own words.</p></div>
  <div class="ov-card"><div class="i">🕊️</div><h4>Moral governance</h4><p>Perhaps history’s first welfare state, built on tolerance and non-violence.</p></div>
  <div class="ov-card"><div class="i">☸️</div><h4>A world religion</h4><p>His missionaries turned Buddhism from a local sect into a faith of half of Asia.</p></div>
  <div class="ov-card"><div class="i">🦁</div><h4>India’s emblem</h4><p>His Sarnath lions and dhamma-wheel are the symbols of the modern republic.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Cruel Prince</b><small> to 268 BC</small><p>Maurya heir; the bloody road to the throne.</p></div>
  <div><b>2 · Kalinga</b><small> c. 261 BC</small><p>The victory that horrified its victor.</p></div>
  <div><b>3 · Dhamma</b><small> 260–232 BC</small><p>The moral empire and the Edicts.</p></div>
  <div><b>4 · The World Religion</b><small> c. 250 BC</small><p>Missionaries, Sri Lanka, and the lions.</p></div>
  <div><b>5 · Legacy</b><small> 232 BC–1837 AD</small><p>Decline, oblivion, and rediscovery.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Chandragupta Maurya', 'role': 'grandfather / founder', 'color': '#b45309',
     'bio': 'Ashoka’s grandfather, who founded the Maurya Empire around 321 BC, drove back the successors of Alexander, and united most of India with the help of the strategist Chanakya.',
     'rel': 'The empire-builder whose realm Ashoka inherited.'},
    {'name': 'Chanakya (Kautilya)', 'role': 'strategist', 'color': '#6b7280',
     'bio': 'The shrewd advisor to Chandragupta and reputed author of the Arthashastra, the classic manual of ruthless statecraft — the tradition of hard power Ashoka would later renounce.',
     'rel': 'The mind behind the Maurya statecraft Ashoka turned away from.'},
    {'name': 'Bindusara', 'role': 'father / emperor', 'color': '#9a3412',
     'bio': 'Ashoka’s father, who extended the Maurya empire across most of the subcontinent, leaving only a few regions — like Kalinga — independent.',
     'rel': 'The father whose empire Ashoka completed and transformed.'},
    {'name': 'Mahinda', 'role': 'son / missionary', 'color': '#166534',
     'bio': 'Ashoka’s son (by tradition), who led the Buddhist mission to Sri Lanka, where the faith took deep and lasting root.',
     'rel': 'The son who carried Buddhism to Sri Lanka.'},
    {'name': 'Sanghamitta', 'role': 'daughter / missionary', 'color': '#0369a1',
     'bio': 'Ashoka’s daughter (by tradition), who brought a sapling of the Bodhi tree and the order of nuns to Sri Lanka.',
     'rel': 'The daughter who helped root Buddhism in Sri Lanka.'},
    {'name': 'James Prinsep', 'role': 'decipherer', 'color': '#c2410c',
     'bio': 'The British scholar and official who deciphered the Brahmi script in 1837, making the Edicts readable and restoring Ashoka to history.',
     'rel': 'The scholar who rescued Ashoka from 2,000 years of oblivion.'},
]

KEY_EVENTS = [
    ('c. 304 BC', 'Born a Maurya prince', 'Grandson of the empire’s founder, Chandragupta.'),
    ('c. 268 BC', 'Accession after a succession war', 'Tradition recalls a harsh early reign.'),
    ('c. 261 BC', 'Conquest of Kalinga', '~100,000 killed; the turning point of his life.'),
    ('c. 260 BC', 'Remorse and conversion', 'Renounces war; embraces Buddhism and dhamma.'),
    ('c. 260–232 BC', 'Rule by dhamma', 'Welfare, tolerance, and the Edicts in stone.'),
    ('c. 250 BC', 'Third Buddhist Council', 'Consolidates and then exports the faith.'),
    ('c. 250 BC', 'Missionaries to Sri Lanka', 'Mahinda and Sanghamitta spread Buddhism south.'),
    ('c. 232 BC', 'Death of Ashoka', 'The empire declines within decades.'),
    ('1837 AD', 'The Edicts deciphered', 'Prinsep restores Ashoka to history.'),
    ('1950 AD', 'India adopts his symbols', 'The Sarnath lions and the dhamma-wheel.'),
]

MASTER = [
    {'year': 'c.304 BC', 'age': 'born', 'phase': 'The Prince', 'title': 'Born a Maurya prince', 'desc': 'Grandson of Chandragupta.'},
    {'year': 'c.268 BC', 'age': 'young man', 'phase': 'The Prince', 'title': 'Accession', 'desc': 'Wins the throne by force.'},
    {'year': 'c.261 BC', 'age': 'king', 'phase': 'Kalinga', 'title': 'Conquest of Kalinga', 'desc': 'The victory that broke him.'},
    {'year': 'c.260 BC', 'age': 'king', 'phase': 'Kalinga', 'title': 'Remorse and conversion', 'desc': 'Turns to dhamma.'},
    {'year': 'c.255 BC', 'age': 'king', 'phase': 'Dhamma', 'title': 'The Edicts', 'desc': 'His ethics carved in stone.'},
    {'year': 'c.250 BC', 'age': 'king', 'phase': 'World Faith', 'title': 'Missionaries sent', 'desc': 'Buddhism goes to Sri Lanka.'},
    {'year': 'c.232 BC', 'age': 'death', 'phase': 'Legacy', 'title': 'Death of Ashoka', 'desc': 'The empire fades.'},
    {'year': '1837 AD', 'age': 'legacy', 'phase': 'Legacy', 'title': 'Rediscovered', 'desc': 'Prinsep deciphers the edicts.'},
]

SOURCES = [
    ('Britannica — Ashoka', 'https://www.britannica.com/biography/Ashoka'),
    ('World History Encyclopedia — Ashoka the Great', 'https://www.worldhistory.org/Ashoka/'),
    ('Britannica — Edicts of Ashoka / Maurya Empire', 'https://www.britannica.com/place/Mauryan-Empire'),
    ('Wikipedia — Ashoka', 'https://en.wikipedia.org/wiki/Ashoka'),
]

def build_meta():
    return {
        'pid': 'gm-ashoka.html', 'kind': 'man', 'emoji': '🦁', 'accent': AC,
        'name': 'Ashoka the Great', 'years': 'c. 304–232 BC', 'group': 'Indian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The conqueror who renounced conquest — remade the largest empire of ancient India around tolerance and welfare, turned Buddhism into a world religion, and became the emblem of a nation.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Cruel Prince', 'type': 'timeline',
             'intro': 'He is born heir to the greatest empire ancient India had known — and wins its throne by force, ruling at first as a hard, conventional Maurya king.', 'events': PHASE_RISE},
            {'id': 'kalinga', 'label': '2 · Kalinga', 'type': 'timeline',
             'intro': 'He conquers the last free Indian kingdom — and the appalling human cost, recorded in his own words, breaks him and turns him against conquest itself.', 'events': PHASE_KALINGA},
            {'id': 'dhamma', 'label': '3 · Dhamma', 'type': 'timeline',
             'intro': 'He rebuilds his reign around dhamma — a shared ethic of non-violence, welfare and tolerance — and carves his principles in stone across the empire.', 'events': PHASE_DHAMMA},
            {'id': 'world', 'label': '4 · The World Religion', 'type': 'timeline',
             'intro': 'He convenes a great council and sends missionaries — including his own children to Sri Lanka — turning Buddhism from a local sect into a world faith, and leaving art that became a nation’s emblem.', 'events': PHASE_WORLD},
            {'id': 'legacy', 'label': '5 · Legacy', 'type': 'timeline',
             'intro': 'His empire fades within decades and his memory is lost for two thousand years — until his own stones are deciphered and he is restored as one of history’s great moral rulers.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Much of the narrative of Ashoka’s early cruelty and his conversion comes from later Buddhist tradition; his remorse for Kalinga and his dhamma policy are documented in his own Edicts, the primary source for his reign.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
