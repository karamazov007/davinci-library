# -*- coding: utf-8 -*-
"""Great Eras guide content for the Sengoku Jidai (Japan's Warring States)."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#7f1d1d'  # lacquer blood-red

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_gekokujo():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">gekokujō — “the low overthrow the high”</text>'
    boxes=[(40,'#7f1d1d','Shogun’s authority collapses','the Ōnin War wrecks central power'),
           (270,'#b45309','Everyone for themselves','retainers overthrow lords; provinces go independent'),
           (500,'#166534','Talent beats birth','able men rise from nothing to rule domains')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">When the old order dissolved, ability — not lineage — decided who ruled. That is the whole spirit of the age.</text>'
    return _wrap(W, H, 'Gekokujō — an age of the self-made', _tk(b, W, H, 'Central authority collapsed, and for a century talent and ruthlessness, not birth, decided who held power.'), '', AC)

def svg_nagashino():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1575 · Nagashino · how guns broke the cavalry age in Japan</text>'
    b += '<rect x="40" y="60" width="300" height="82" rx="12" fill="#fef2f2" stroke="#b45309" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#b45309">Takeda’s famed cavalry</text>'
    s1,_=_tspans(54,100,'the most feared mounted warriors in Japan charge the line',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="82" rx="12" fill="#fdeeee" stroke="#7f1d1d" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#7f1d1d">Nobunaga’s guns and palisades</text>'
    s2,_=_tspans(394,100,'ranks of matchlock gunners behind wooden stockades fire in rotation',10,'#7f1d1d',600,12,44); b+=s2
    b += '<line x1="340" y1="101" x2="378" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Fortified gun-lines shredded the charge — a turning point that made firearms decisive in Japanese war.</text>'
    return _wrap(W, H, 'Nagashino — gunpowder changes everything', _tk(b, W, H, 'Nobunaga used massed matchlocks behind palisades to destroy the age’s finest cavalry — war would never be the same.'), '', AC)

def svg_unifiers():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the old saying: three men, one national rice-cake</text>'
    rows=[('#7f1d1d','Nobunaga pounds the rice','the ruthless innovator smashes the old order'),
          ('#b45309','Hideyoshi kneads the dough','the peasant genius completes the unification'),
          ('#166534','Ieyasu eats the cake','the patient waiter inherits the finished nation')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="42" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+21}" r="9" fill="{c}"/><text x="62" y="{y+25}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+18}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+34,s,9.3,'#5b6472',500,11,78); b+=ss
        y+=50
    return _wrap(W, H, 'The three unifiers — one rice-cake', _tk(b, W, H, 'A famous verse sums up the age: Nobunaga pounds the rice, Hideyoshi kneads it, and Ieyasu sits down to eat.'), '', AC)

def svg_sekigahara():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1600 · Sekigahara · the battle that decided 250 years</text>'
    boxes=[(40,'#7f1d1d','Two great coalitions','Ieyasu’s East vs Ishida’s West — for all Japan'),
           (270,'#b45309','A pivotal betrayal','Kobayakawa defects to Ieyasu mid-battle'),
           (500,'#166534','Ieyasu wins it all','the West collapses; Ieyasu is master of Japan')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">One day’s fighting — and one well-timed betrayal — settled who would rule Japan for a quarter of a millennium.</text>'
    return _wrap(W, H, 'Sekigahara — one day decides everything', _tk(b, W, H, 'The largest battle of the age turned on a single betrayal and handed Japan to the Tokugawa for 250 years.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE SHATTERING
PHASE_SHATTER = [
    E('onin', '1467–1477', 'The Ōnin War shatters the order', ['TURNING POINT', 'TRAGEDY'],
      'A succession dispute inside the ruling Ashikaga shogunate explodes into a decade-long war that wrecks the capital, Kyoto, and destroys central authority — plunging Japan into a century in which no one truly rules and everyone fights.',
      svg_gekokujo(),
      bg='By the 15th century the <b>Ashikaga shogunate</b> was weak. A dispute over its succession, entangled with feuding great houses, ignited the <b>Ōnin War</b>.',
      people='The Ashikaga shoguns; the great warrior houses whose feuds tore the capital apart.',
      what='The <b>Ōnin War (1467–1477)</b> devastated <b>Kyoto</b> and shattered the shogunate’s authority. Central power effectively collapsed, and Japan fragmented into dozens of warring domains — the beginning of the <b>Sengoku Jidai</b>.',
      crux='It unleashed <b>gekokujō</b> — "the low overthrow the high": with the old order gone, power flowed to whoever could seize and hold it, regardless of birth.',
      conseq='For a century, competing <b>daimyō</b> (warlords) fought endlessly for survival and supremacy across a fractured Japan.',
      matters='When central authority collapses, ability and ruthlessness replace birthright. The Ōnin War opened the most fluid, dangerous, opportunity-filled age in Japanese history.'),

    E('daimyo', '1477–1543', 'The age of the warlords', ['BATTLE', 'POLITICS'],
      'Across a Japan with no centre, ambitious warlords — the daimyō — build domains, castles and armies, rising and falling by cunning and force, in a century-long free-for-all where a village headman’s son might end up ruling a province.',
      svg_stack('A century of warring domains', [
          {'n': 1, 'label': 'Independent daimyō', 'sub': 'warlords rule their own domains by the sword', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Castles and armies', 'sub': 'castle towns, retainers, and constant war', 'color': '#b45309'},
          {'n': 3, 'label': 'Rise by talent', 'sub': 'able commoners can climb to power', 'color': '#166534'},
      ], takeaway='For a hundred years Japan was a patchwork of warlord states in near-constant war — a brutal meritocracy of violence.', accent=AC),
      bg='With no effective central government, real power lay with regional <b>daimyō</b>, each ruling a domain and competing with neighbours.',
      people='Great warlord houses such as the <b>Takeda, Uesugi, Hōjō, Imagawa</b> and <b>Mōri</b>.',
      what='For decades, <b>daimyō</b> across Japan built fortified domains and fought endlessly for land and survival. Social mobility was high: talented men could rise far above their birth in the chaos.',
      crux='The age rewarded <b>military skill, cunning and adaptability</b> over pedigree — a violent, competitive crucible that produced extraordinary leaders.',
      conseq='This brutal competition set the stage for the emergence of unifiers who could impose order on the chaos.',
      matters='Sustained disorder is a forge. The Sengoku free-for-all produced some of history’s most remarkable military and political talents.'),

    E('kawanakajima', '1553–1564', 'The great rivalry — Shingen and Kenshin at Kawanakajima', ['BATTLE', 'POLITICS'],
      'The age’s most famous rivalry pits two titans against each other: Takeda Shingen, master of the finest cavalry in Japan, and Uesugi Kenshin, the "God of War," clash five times over a decade at Kawanakajima in duels so evenly matched that neither can win — the romantic epitome of the honorable, indecisive warlord warfare that the unifiers would sweep away.',
      svg_row('Two titans locked in a perfect stalemate', [
          {'n': 1, 'label': 'Takeda Shingen', 'sub': 'master of Japan’s finest cavalry', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Uesugi Kenshin', 'sub': 'the brilliant “God of War”', 'color': '#b45309'},
          {'n': 3, 'label': 'Five battles, no victor', 'sub': 'Kawanakajima — evenly matched to the end', 'color': '#166534'},
      ], edge_labels=['vs', 'so'], takeaway='The era’s greatest rivalry was a perfect stalemate — the romantic, honorable warfare the unifiers would soon replace.', accent=AC),
      bg='Among the warlords, none were more celebrated than <b>Takeda Shingen</b> and <b>Uesugi Kenshin</b>, rivals for control of central Japan.',
      people='<b>Takeda Shingen</b>, the cavalry master; <b>Uesugi Kenshin</b>, the “God of War”; the retainers who fought at Kawanakajima.',
      what='Shingen and Kenshin fought <b>five battles at Kawanakajima (1553–1564)</b> — celebrated in legend, including a supposed single combat between the two lords — so <b>evenly matched that neither could win decisively</b>.',
      crux='Their rivalry epitomised the <b>honorable, personal, and ultimately indecisive</b> warlord warfare of the mid-Sengoku — brilliant but incapable of producing unification.',
      conseq='Both died without unifying Japan; their style of war would be eclipsed by Nobunaga’s ruthless, gunpowder-driven methods.',
      matters='Kawanakajima is the romantic heart of the Sengoku legend — and a lesson in why honorable stalemate lost to ruthless innovation.'),

    E('houses', '1500s–1580s', 'The great houses — a map of contenders', ['POLITICS', 'BATTLE'],
      'The struggle for Japan is fought among a shifting constellation of great regional houses — the Hōjō in the east, the Mōri in the west, the Shimazu in the far south, the young "one-eyed dragon" Date Masamune in the north — each a power in its own right, and each in time crushed, co-opted, or outlasted by the three unifiers.',
      svg_row('The powers the unifiers had to master', [
          {'n': 1, 'label': 'Hōjō (east) & Mōri (west)', 'sub': 'great regional powers holding key regions', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Shimazu (Kyushu)', 'sub': 'the fierce house of the far south', 'color': '#b45309'},
          {'n': 3, 'label': 'Date Masamune (north)', 'sub': 'the ambitious “one-eyed dragon”', 'color': '#166534'},
      ], edge_labels=['and', 'and'], takeaway='Unification meant mastering a whole map of formidable regional houses — by war, alliance, or attrition.', accent=AC),
      bg='Beyond the three unifiers, the Sengoku was contested by powerful regional dynasties across Japan’s islands.',
      people='The <b>Hōjō</b> of the Kanto; the <b>Mōri</b> of the west; the <b>Shimazu</b> of Kyushu; the <b>Date</b> of the north.',
      what='Great houses — the <b>Hōjō</b> (east), <b>Mōri</b> (west), <b>Shimazu</b> (Kyushu), and the northern <b>Date Masamune</b> — each dominated their regions, and each was ultimately <b>subdued, co-opted or outlasted</b> by Nobunaga, Hideyoshi and Ieyasu.',
      crux='Unification was not a duel but the <b>mastering of a whole board of regional powers</b>, by conquest, alliance and attrition.',
      conseq='One by one these houses were brought to heel, until only the Tokugawa stood supreme.',
      matters='The Sengoku was a contest among many great houses. Understanding them is understanding the true scale of what the unifiers achieved.'),

    E('guns', '1543–1549', 'Guns and the cross arrive', ['REFORM', 'TURNING POINT'],
      'Two foreign imports transform the age: Portuguese traders bring firearms in 1543, which Japan swiftly copies and mass-produces, and Christian missionaries arrive in 1549 — adding gunpowder and a new faith to the volatile Sengoku mix.',
      svg_row('Foreign imports reshape the war', [
          {'n': 1, 'label': 'Firearms arrive, 1543', 'sub': 'Portuguese matchlocks land at Tanegashima', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Japan mass-produces them', 'sub': 'smiths copy and improve the guns fast', 'color': '#b45309'},
          {'n': 3, 'label': 'Christianity arrives, 1549', 'sub': 'Francis Xavier begins Jesuit missions', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='Gunpowder and a new religion poured into the chaos — and the warlords who used them best pulled ahead.', accent=AC),
      bg='In the mid-16th century, contact with <b>Portuguese</b> traders and missionaries introduced revolutionary new tools and ideas to Japan.',
      people='The Portuguese who landed at <b>Tanegashima</b>; the Jesuit missionary <b>Francis Xavier</b>; the gunsmiths who copied firearms.',
      what='<b>Firearms (matchlocks)</b> arrived via the Portuguese at <b>Tanegashima in 1543</b> and were quickly copied and mass-produced; in <b>1549</b> <b>Francis Xavier</b> began Christian missionary work in Japan.',
      crux='The rapid Japanese <b>adoption and mass production of firearms</b> would soon transform warfare — and the warlords quickest to exploit guns gained a decisive edge.',
      conseq='Firearms reshaped Sengoku battle; Christianity spread among some daimyō and commoners, adding a new fault line.',
      matters='Technology and ideas transfer fast in a competitive age. Japan’s rapid mastery of the gun would decide the coming wars of unification.'),

    E('militaryrev', '1540s–1600', 'The military revolution — peasants, guns, and mass war', ['REFORM', 'BATTLE', 'TURNING POINT'],
      'Warfare itself is transformed: the age of the individual mounted samurai gives way to massed armies of common foot-soldiers — the ashigaru — drilled with pikes and matchlock guns, so that battles are decided by disciplined volleys and numbers rather than aristocratic heroics, a Japanese military revolution that mirrors the one reshaping Europe.',
      svg_row('From heroic cavalry to mass firepower', [
          {'n': 1, 'label': 'The ashigaru rise', 'sub': 'massed commoner foot-soldiers replace lone samurai', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Pikes and matchlocks', 'sub': 'disciplined volleys and drilled formations', 'color': '#b45309'},
          {'n': 3, 'label': 'War by numbers and drill', 'sub': 'firepower and organisation over heroics', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='War shifted from heroic cavalry duels to disciplined masses of gun-armed commoners — a true military revolution.', accent=AC),
      bg='The spread of firearms and ever-larger armies transformed how Sengoku battles were fought.',
      people='The <b>ashigaru</b> (commoner foot-soldiers); the daimyō who drilled and equipped them; the gunsmiths arming them.',
      what='Warfare shifted from the individual mounted <b>samurai</b> to massed armies of <b>ashigaru</b> foot-soldiers drilled with <b>pikes and matchlock guns</b>, decided by <b>disciplined volleys and numbers</b> — a Japanese parallel to Europe’s "military revolution."',
      crux='The <b>industrialisation of war</b> — mass infantry, firearms, drill — rewarded organisation and resources over aristocratic prowess, favouring the great unifiers.',
      conseq='This transformation made possible the huge, disciplined armies with which Nobunaga, Hideyoshi and Ieyasu unified Japan.',
      matters='The Sengoku was a military revolution as much as a political one — and it reshaped Japanese society, elevating organisation over birth.'),
]

# ==================================================================  PHASE 2 — NOBUNAGA
PHASE_NOBUNAGA = [
    E('okehazama', '1560', 'Nobunaga stuns the age at Okehazama', ['BATTLE', 'RISE', 'TURNING POINT'],
      'A minor, eccentric warlord named Oda Nobunaga, wildly outnumbered, launches a daring surprise attack in a rainstorm on the great Imagawa army and kills its lord — an astonishing upset that announces the arrival of the age’s first great unifier.',
      svg_row('The upset that launched a unifier', [
          {'n': 1, 'label': 'Imagawa invades', 'sub': 'a huge army marches through Oda land', 'color': '#b45309'},
          {'n': 2, 'label': 'Nobunaga gambles', 'sub': 'a surprise strike in a storm on the enemy camp', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'The warlord slain', 'sub': 'Imagawa Yoshimoto killed; Oda rises', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='One audacious gamble against the odds turned a minor lord into a rising power overnight.', accent=AC),
      bg='<b>Oda Nobunaga</b> was a minor, unconventional daimyō when the powerful <b>Imagawa Yoshimoto</b> invaded his territory with a far larger army in <b>1560</b>.',
      people='<b>Oda Nobunaga</b>; the great lord <b>Imagawa Yoshimoto</b>; the young <b>Tokugawa Ieyasu</b>, then an Imagawa vassal.',
      what='At <b>Okehazama (1560)</b>, Nobunaga made a daring <b>surprise attack</b> — reportedly under cover of a storm — on the resting Imagawa camp and <b>killed Yoshimoto</b>, shattering a far larger force.',
      crux='He won by <b>audacity, intelligence and surprise</b> against overwhelming odds — the boldness and cunning that would define his rise.',
      conseq='The victory freed the young Tokugawa Ieyasu from Imagawa control and set Nobunaga on the path to dominate central Japan.',
      matters='Boldness can overturn brute strength. Okehazama launched the career of the man who would begin Japan’s reunification.'),

    E('nagashino', '1575', 'Nagashino — the gun revolution', ['BATTLE', 'TRIUMPH', 'REFORM'],
      'Nobunaga perfects a new kind of war: at Nagashino he sets ranks of matchlock gunners behind wooden palisades and annihilates the famed Takeda cavalry, proving that massed firearms and field fortifications now rule the battlefield.',
      svg_nagashino(),
      bg='The <b>Takeda</b> clan’s cavalry was the most feared force in Japan. In <b>1575</b> it faced the combined armies of <b>Nobunaga</b> and his ally <b>Tokugawa Ieyasu</b> at <b>Nagashino</b>.',
      people='<b>Oda Nobunaga</b> and <b>Tokugawa Ieyasu</b>; the Takeda cavalry under <b>Takeda Katsuyori</b>.',
      what='At <b>Nagashino (1575)</b>, Nobunaga deployed massed <b>matchlock gunners behind wooden palisades</b>, firing in disciplined volleys to shatter the charging <b>Takeda cavalry</b> — a landmark in the use of firearms.',
      crux='He <b>industrialised firepower</b>, combining guns, fortifications and discipline to defeat even the finest traditional cavalry — a decisive tactical revolution.',
      conseq='The Takeda were broken; Nobunaga’s dominance of central Japan was assured, and he pressed toward total control.',
      matters='Nagashino is Japan’s emblem of the gunpowder revolution — proof that organised firepower had overtaken heroic cavalry.'),

    E('honnoji', '1568–1582', 'Nobunaga’s rise — and betrayal at Honnō-ji', ['POLITICS', 'DEATH', 'TRAGEDY'],
      'Ruthless and brilliant, Nobunaga seizes the capital, crushes rivals and even warrior-monks, and comes within reach of unifying Japan — until, in 1582, one of his own generals betrays him and he dies in the burning Honnō-ji temple, his work unfinished.',
      svg_stack('The innovator cut down near the summit', [
          {'n': 1, 'label': 'Seizes the capital', 'sub': 'takes Kyoto; dominates central Japan', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Crushes all rivals', 'sub': 'even burns the warrior-monks of Enryaku-ji', 'color': '#b45309'},
          {'n': 3, 'label': 'Betrayed at Honnō-ji', 'sub': 'his general Akechi turns; Nobunaga dies, 1582', 'color': '#111827'},
      ], takeaway='He nearly unified Japan by sheer ruthlessness — then was destroyed by a betrayal from within, at the very brink.', accent=AC),
      bg='Through the 1560s–70s Nobunaga expanded relentlessly, taking <b>Kyoto</b>, deposing the last Ashikaga shogun, and crushing opponents including the militant <b>warrior-monks</b>.',
      people='<b>Oda Nobunaga</b>; his general and betrayer <b>Akechi Mitsuhide</b>; his rising retainers <b>Hideyoshi</b> and <b>Ieyasu</b>.',
      what='Nobunaga dominated central Japan through force and innovation, even <b>burning the warrior-monk stronghold of Enryaku-ji</b>. In <b>1582</b>, his general <b>Akechi Mitsuhide</b> turned on him and Nobunaga died at the <b>Honnō-ji</b> temple in Kyoto, his unification unfinished.',
      crux='His career shows both the <b>power of ruthless innovation</b> and its danger: a leader feared by all is vulnerable to betrayal by those closest to him.',
      conseq='His death opened a scramble for his legacy — won, with startling speed, by his brilliant peasant-born general Hideyoshi.',
      matters='The most feared leaders can fall to those nearest them. Nobunaga began the unification but did not live to complete it.'),

    E('ikkoikki', '1570–1580', 'The warrior-monks — Nobunaga’s war on militant Buddhism', ['BATTLE', 'TRAGEDY'],
      'One of the great powers of the age is not a warlord but a religion: the Ikkō-ikki, militant leagues of Buddhist believers whose fortress-temple at Ishiyama Honganji defies Nobunaga for a decade — a holy war he wins only by siege, starvation, and massacre, breaking the political power of militant Buddhism forever.',
      svg_row('Crushing a religious military power', [
          {'n': 1, 'label': 'The Ikkō-ikki leagues', 'sub': 'militant Buddhist believers, a real military power', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'The Ishiyama Honganji war', 'sub': 'their fortress-temple defies Nobunaga for 10 years', 'color': '#b45309'},
          {'n': 3, 'label': 'Broken by siege and slaughter', 'sub': 'militant Buddhism’s political power destroyed', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='Nobunaga waged a decade-long holy war to break the militant Buddhist leagues — one of the age’s great powers.', accent=AC),
      bg='The <b>Ikkō-ikki</b> — leagues of militant True Pure Land Buddhists — controlled provinces and fielded armies, a formidable obstacle to unification.',
      people='The <b>Ikkō-ikki</b> believers; their fortress-temple <b>Ishiyama Honganji</b>; Nobunaga, their implacable enemy.',
      what='Nobunaga fought a <b>decade-long war (1570–80)</b> against the <b>Ikkō-ikki</b>, besieging their great fortress-temple <b>Ishiyama Honganji</b> and crushing their leagues through siege, starvation and <b>massacre</b>, ending militant Buddhism’s political power.',
      crux='He recognised that <b>unification required breaking every rival power</b> — including organised religion — and did so with characteristic ruthlessness.',
      conseq='The political-military power of militant Buddhism was destroyed, removing a major obstacle to central rule.',
      matters='The Sengoku’s contenders included armed religion. Nobunaga’s war on the Ikkō-ikki was essential — and brutal — to clearing the path to unity.'),

    E('enryakuji', '1571', 'The burning of Mount Hiei', ['BATTLE', 'TRAGEDY', 'TURNING POINT'],
      'In his most notorious act, Nobunaga destroys the ancient, powerful Buddhist monastery complex on Mount Hiei — burning its temples and slaughtering thousands of monks, women and children — a shocking atrocity that announces he will let no traditional power, however sacred, stand in the way of unification.',
      svg_row('An atrocity that shattered a taboo', [
          {'n': 1, 'label': 'Mount Hiei defies him', 'sub': 'the powerful Enryaku-ji monastery aids his enemies', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Nobunaga burns it', 'sub': 'temples torched; thousands massacred, 1571', 'color': '#b45309'},
          {'n': 3, 'label': 'No sacred exceptions', 'sub': 'he will crush any power that resists', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='By burning a sacred mountain he served brutal notice: no traditional power was safe from his drive to unify.', accent=AC),
      bg='The monastery complex of <b>Enryaku-ji</b> on <b>Mount Hiei</b>, near Kyoto, was an ancient, wealthy, and militarily powerful religious institution.',
      people='The monks, and the sheltered civilians, of <b>Mount Hiei</b>; Nobunaga and his army.',
      what='In <b>1571</b> Nobunaga <b>burned the Enryaku-ji complex on Mount Hiei</b> and <b>massacred thousands</b> — monks, women and children alike — a shocking atrocity against one of Japan’s holiest sites.',
      crux='He demonstrated with horrifying clarity that <b>no power — not even the most sacred — could defy him</b> and survive.',
      conseq='The destruction cowed other religious and traditional powers and advanced the ruthless centralisation of the age.',
      matters='The burning of Mount Hiei is the Sengoku’s starkest image of ruthless modernising power overriding ancient sacred authority.'),

    E('castles', '1576–1600', 'Castles of stone and gold — the age of the great keeps', ['REFORM', 'TRIUMPH'],
      'The transformation of war and power is written in architecture: the unifiers raise towering stone castles crowned with soaring keeps — Nobunaga’s dazzling Azuchi, Hideyoshi’s mighty Osaka, the sublime white Himeji — that are at once fortresses, seats of government, and breathtaking statements of a new, centralised authority.',
      svg_row('Power made monumental in stone', [
          {'n': 1, 'label': 'Azuchi Castle', 'sub': 'Nobunaga’s dazzling, innovative keep', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Osaka Castle', 'sub': 'Hideyoshi’s vast fortress-capital', 'color': '#b45309'},
          {'n': 3, 'label': 'Himeji and the great keeps', 'sub': 'fortress, palace, and symbol of central power', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='The soaring stone castles were fortresses and thrones at once — power itself made monumental.', accent=AC),
      bg='As armies and central authority grew, the unifiers built <b>monumental stone castles</b> unlike anything before in Japan.',
      people='Nobunaga (Azuchi); Hideyoshi (Osaka); the builders of the great keeps like <b>Himeji</b>.',
      what='The age produced Japan’s great <b>castles</b> — Nobunaga’s innovative, gilded <b>Azuchi</b>, Hideyoshi’s enormous <b>Osaka</b>, and masterpieces like <b>Himeji</b> — serving simultaneously as <b>fortresses, administrative seats, and symbols</b> of new centralised power.',
      crux='These castles embodied the shift from <b>scattered warlord holdings to centralised, monumental authority</b> — power expressed in stone and gold.',
      conseq='The great keeps became the administrative and symbolic centres of the emerging unified order.',
      matters='Architecture mirrors power. The Sengoku’s soaring castles are the physical expression of Japan’s transformation from chaos to central rule.'),
]

# ==================================================================  PHASE 3 — HIDEYOSHI
PHASE_HIDEYOSHI = [
    E('yamazaki', '1582', 'Hideyoshi seizes the moment', ['BATTLE', 'RISE', 'TURNING POINT'],
      'A man born a peasant, risen through Nobunaga’s service by sheer ability, Toyotomi Hideyoshi reacts to his master’s murder with astonishing speed — crushing the traitor Akechi within days at Yamazaki and positioning himself as Nobunaga’s true heir.',
      svg_row('The peasant who seized the succession', [
          {'n': 1, 'label': 'Nobunaga murdered', 'sub': 'the realm suddenly leaderless', 'color': '#b45309'},
          {'n': 2, 'label': 'Hideyoshi races back', 'sub': 'makes peace and marches on the traitor', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Yamazaki, 1582', 'sub': 'destroys Akechi; becomes Nobunaga’s heir', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He turned the chaos of his master’s death into his own ascent — with breathtaking speed.', accent=AC),
      bg='<b>Toyotomi Hideyoshi</b>, born a commoner, had risen through Nobunaga’s ranks by talent alone. When Nobunaga was killed, he was campaigning nearby.',
      people='<b>Toyotomi Hideyoshi</b>; the traitor <b>Akechi Mitsuhide</b>; rival Oda generals.',
      what='Hideyoshi made a lightning peace with the enemy he was fighting, raced back, and <b>defeated and killed Akechi at the Battle of Yamazaki (1582)</b>, just days after Nobunaga’s death — establishing himself as the avenger and heir.',
      crux='He combined <b>speed, decisiveness and political skill</b> to convert a crisis into supremacy, outmanoeuvring rivals for Nobunaga’s legacy.',
      conseq='Hideyoshi rapidly consolidated power and set out to complete the unification Nobunaga had begun.',
      matters='The Sengoku rewarded those who acted fastest in a crisis. Hideyoshi’s speed after Honnō-ji made him master of Nobunaga’s realm.'),

    E('unify', '1583–1590', 'The peasant completes the unification', ['TRIUMPH', 'REFORM'],
      'Through war and shrewd diplomacy, Hideyoshi brings the last great domains to heel — Shikoku, Kyushu, and finally the mighty Hōjō at Odawara in 1590 — completing the unification of Japan under a man who began life with nothing.',
      svg_row('Bringing the last domains to heel', [
          {'n': 1, 'label': 'Wins by war and deal', 'sub': 'defeats or allies with the great houses', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Shikoku and Kyushu', 'sub': 'brings the outer islands under control', 'color': '#b45309'},
          {'n': 3, 'label': 'Odawara, 1590', 'sub': 'the last great rival, the Hōjō, falls', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='A man born a peasant united all Japan — the ultimate gekokujō success story.', accent=AC),
      bg='After Yamazaki, Hideyoshi moved to bring every remaining independent daimyō under his authority.',
      people='The great houses he subdued or co-opted — the <b>Mōri, Chōsokabe, Shimazu</b>, and finally the <b>Hōjō</b>.',
      what='Through the 1580s Hideyoshi subdued <b>Shikoku, Kyushu</b>, and in <b>1590</b> crushed the <b>Hōjō at Odawara</b>, completing the <b>unification of Japan</b> under his rule.',
      crux='He blended <b>overwhelming force with clever diplomacy and generous terms</b>, absorbing rivals rather than merely destroying them — and did it all having risen from the peasantry.',
      conseq='For the first time in over a century, Japan was united — under a single ruler of humble birth.',
      matters='Hideyoshi’s rise from peasant to unifier is the greatest gekokujō story of all — talent triumphing utterly over birth.'),

    E('korea', '1585–1598', 'The sword hunt — and the Korean disaster', ['REFORM', 'DEFEAT', 'TRAGEDY'],
      'To freeze the fluid society that let him rise, Hideyoshi disarms the peasants and fixes the class order — then, his ambition unbounded, hurls Japan into two catastrophic invasions of Korea that end only with his death in 1598.',
      svg_stack('Consolidation at home, catastrophe abroad', [
          {'n': 1, 'label': 'The sword hunt', 'sub': 'disarms peasants; freezes the class system', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Invades Korea', 'sub': 'two vast, bloody invasions (1592, 1597)', 'color': '#b45309'},
          {'n': 3, 'label': 'Dies, 1598', 'sub': 'the failed war ends only when he dies', 'color': '#111827'},
      ], takeaway='He locked shut the ladder he had climbed — then wasted his power on a ruinous foreign war.', accent=AC),
      bg='Having unified Japan, Hideyoshi sought to stabilise his rule and then turned his ambitions overseas.',
      people='The Japanese armies in Korea; Korea’s defenders and their Ming Chinese allies; the admiral <b>Yi Sun-sin</b>, whose fleet devastated the invaders.',
      what='Hideyoshi conducted a <b>"sword hunt"</b> disarming peasants and rigidly <b>fixed the social classes</b>; then he launched two massive <b>invasions of Korea (1592 and 1597)</b>, which bogged down disastrously and were abandoned only after his <b>death in 1598</b>.',
      crux='He ironically <b>closed off the social mobility that had made him</b>, and then overreached abroad — power without a check on ambition ending in catastrophe.',
      conseq='The Korean wars drained Japan and left a power vacuum; on his death, his young son’s inheritance was precarious.',
      matters='Even the greatest self-made ruler can overreach. Hideyoshi froze the ladder behind him and squandered his triumph on an unwinnable war.'),

    E('tea', '1570s–1591', 'The way of tea — beauty amid the blood', ['REFORM', 'TRAGEDY'],
      'Alongside the carnage flourishes one of the world’s great aesthetic traditions: the tea ceremony, refined to sublime, austere perfection by the master Sen no Rikyū under Nobunaga and Hideyoshi — a cult of beauty, simplicity and calm so prized that warlords collect tea utensils like provinces, until Rikyū’s own influence grows so great that Hideyoshi orders him to take his own life.',
      svg_row('A cult of beauty in a violent age', [
          {'n': 1, 'label': 'Sen no Rikyū', 'sub': 'perfects the austere wabi-cha tea ceremony', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Prized by warlords', 'sub': 'tea utensils valued like castles and provinces', 'color': '#b45309'},
          {'n': 3, 'label': 'Ordered to die, 1591', 'sub': 'Rikyū’s influence provokes Hideyoshi’s wrath', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='The bloody age also perfected the tea ceremony — and its greatest master paid for his influence with his life.', accent=AC),
      bg='Amid the wars, an intense culture of the <b>tea ceremony</b> flourished among the warlords, refined by the master <b>Sen no Rikyū</b>.',
      people='<b>Sen no Rikyū</b>, the great tea master; Nobunaga and Hideyoshi, his patrons and, for Hideyoshi, ultimately his executioner.',
      what='<b>Sen no Rikyū</b> perfected the austere, profound <b>wabi-cha</b> tea ceremony, prized so highly that warlords treasured <b>tea utensils like provinces</b> — until his influence grew so great that <b>Hideyoshi ordered him to commit ritual suicide in 1591</b>.',
      crux='The age fused <b>refined aesthetics with lethal politics</b>: even the way of tea was entangled with power, and its master died by it.',
      conseq='Rikyū’s aesthetic — simplicity, imperfection, calm (wabi-sabi) — became a lasting pillar of Japanese culture.',
      matters='Beauty and blood coexisted in the Sengoku. The tea ceremony — sublime and, for its master, fatal — is the age’s cultural soul.'),

    E('nanban', '1543–1614', 'The nanban century — Japan meets Europe', ['REFORM', 'POLITICS'],
      'For a few remarkable decades Japan is wide open to the wider world: Portuguese and Spanish "southern barbarians" bring guns, trade, and Christianity; the port of Nagasaki booms; hundreds of thousands convert, some daimyō among them — a cosmopolitan opening that the Tokugawa peace will later slam shut.',
      svg_row('A window to the world, briefly open', [
          {'n': 1, 'label': 'The “southern barbarians”', 'sub': 'Portuguese and Spanish traders and Jesuits', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Trade and conversion', 'sub': 'Nagasaki booms; Christian daimyō and converts', 'color': '#b45309'},
          {'n': 3, 'label': 'A door soon to close', 'sub': 'the Tokugawa will later shut Japan off', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='For a cosmopolitan few decades Japan embraced the wider world — before the peace closed the door.', accent=AC),
      bg='The arrival of Europeans opened a period of intense <b>trade and cultural exchange</b> — the <b>nanban</b> ("southern barbarian") era.',
      people='The Portuguese and Spanish traders and <b>Jesuit missionaries</b>; the Christian <b>daimyō</b> and hundreds of thousands of converts; the port of <b>Nagasaki</b>.',
      what='For decades Japan engaged intensely with Europe — importing <b>guns and goods</b>, embracing <b>Christianity</b> (with hundreds of thousands of converts, including some daimyō), and building the boom port of <b>Nagasaki</b> — an openness the Tokugawa would later reverse.',
      crux='The Sengoku was, briefly, an <b>era of cosmopolitan openness</b> to the wider world — a road not taken, closed off by the coming peace.',
      conseq='The Tokugawa, fearing foreign subversion, would persecute Christianity and largely seal Japan off (sakoku) for over two centuries.',
      matters='The Sengoku’s openness to the world is a poignant might-have-been — a cosmopolitan window that the Great Peace deliberately closed.'),
]

# ==================================================================  PHASE 4 — IEYASU
PHASE_IEYASU = [
    E('sekigahara', '1598–1600', 'Sekigahara — the great decision', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'Hideyoshi’s death leaves a five-year-old heir and a divided realm. The patient, powerful Tokugawa Ieyasu makes his move — and at Sekigahara in 1600, the largest battle in Japanese history, a mid-battle betrayal hands him mastery of all Japan.',
      svg_sekigahara(),
      bg='Hideyoshi died in <b>1598</b> leaving a young son, <b>Hideyori</b>, under a council of regents. The most powerful of them, <b>Tokugawa Ieyasu</b>, and the loyalist <b>Ishida Mitsunari</b> soon split the country.',
      people='<b>Tokugawa Ieyasu</b> (the Eastern Army); <b>Ishida Mitsunari</b> (the Western Army); the defector <b>Kobayakawa Hideaki</b>.',
      what='At the <b>Battle of Sekigahara (1600)</b>, two great coalitions clashed for control of Japan. The <b>defection of Kobayakawa Hideaki</b> mid-battle broke the Western Army, and <b>Ieyasu won decisively</b>.',
      crux='It was decided by <b>Ieyasu’s patient coalition-building and a decisive betrayal</b> he had helped arrange — the culmination of a lifetime of waiting for the right moment.',
      conseq='Ieyasu became the paramount power in Japan and, in 1603, was named <b>shogun</b>, founding the Tokugawa shogunate.',
      matters='One battle can settle an age. Sekigahara ended the Sengoku struggle and determined who would rule Japan for 250 years.'),

    E('osaka', '1603–1615', 'Shogun — and the end of the wars', ['BATTLE', 'TRIUMPH'],
      'Ieyasu takes the title of shogun and secures his dynasty — then, to remove the last threat, destroys Hideyoshi’s heir at the great sieges of Osaka Castle in 1614–15, extinguishing the Toyotomi and finally ending a century and a half of war.',
      svg_row('Sealing the peace by force', [
          {'n': 1, 'label': 'Becomes shogun, 1603', 'sub': 'founds the Tokugawa shogunate', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'The last threat: Osaka', 'sub': 'Hideyoshi’s heir holds the great castle', 'color': '#b45309'},
          {'n': 3, 'label': 'Sieges of Osaka, 1614–15', 'sub': 'the Toyotomi destroyed; the wars end', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He made his dynasty permanent by eliminating the last rival — and closed the Warring States for good.', accent=AC),
      bg='Named <b>shogun</b> in 1603, Ieyasu secured his family’s dominance but still faced the potential rallying point of Hideyoshi’s son <b>Hideyori</b>, holding <b>Osaka Castle</b>.',
      people='<b>Tokugawa Ieyasu</b>; <b>Toyotomi Hideyori</b> and the last defenders of Osaka.',
      what='Ieyasu founded the <b>Tokugawa shogunate (1603)</b> and, in the <b>Sieges of Osaka (1614–1615)</b>, destroyed the <b>Toyotomi</b> and their heir, eliminating the final rival and formally ending the Sengoku era.',
      crux='He completed the work by <b>ruthlessly removing every remaining threat</b>, ensuring the Tokugawa peace could not be challenged from within.',
      conseq='With the Toyotomi gone, Japan entered a long era of stability under Tokugawa rule.',
      matters='Founding a lasting peace sometimes takes a final, ruthless act. Osaka closed the age of the Warring States for good.'),

    E('women', '1550s–1615', 'The women of the Sengoku — power behind the wars', ['POLITICS', 'TRAGEDY'],
      'Behind the warlords stand formidable women whose marriages, loyalties and tragedies shape the age: Oda Nobunaga’s sister Oichi, twice married into doomed clans; Hideyoshi’s shrewd wife Nene and his consort Yodo-dono, who holds Osaka Castle to its fiery end; and the Christian Hosokawa Gracia, who chooses death over capture — reminders that the Sengoku’s drama was as much dynastic and personal as military.',
      svg_row('Women who shaped the fate of clans', [
          {'n': 1, 'label': 'Oichi', 'sub': 'Nobunaga’s sister, twice wed into doomed houses', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Nene and Yodo-dono', 'sub': 'Hideyoshi’s wife and consort; Yodo dies at Osaka', 'color': '#b45309'},
          {'n': 3, 'label': 'Hosokawa Gracia', 'sub': 'the Christian noblewoman who chose death', 'color': '#166534'},
      ], edge_labels=['and', 'and'], takeaway='The age’s women — through marriage, loyalty and sacrifice — shaped the fate of clans as surely as any battle.', accent=AC),
      bg='Elite women were central to Sengoku politics through <b>marriage alliances, loyalty, and dynastic fate</b>, often meeting tragic ends.',
      people='<b>Oichi</b>, Nobunaga’s sister; <b>Nene</b> and <b>Yodo-dono</b>, Hideyoshi’s wife and consort; the Christian <b>Hosokawa Gracia</b>.',
      what='Women like <b>Oichi</b> (twice married into destroyed clans), <b>Nene</b> and <b>Yodo-dono</b> (who held Osaka Castle to its fall), and <b>Hosokawa Gracia</b> (who chose death over capture) shaped the era’s <b>alliances, loyalties and tragedies</b>.',
      crux='The Sengoku’s drama was deeply <b>dynastic and personal</b>, and elite women were central actors in it — through marriage, influence, and sacrifice.',
      conseq='Their stories became some of the age’s most enduring and poignant, woven through its wars and its legend.',
      matters='The Sengoku was not only a men’s war. Its women shaped the fate of clans and gave the age some of its deepest human drama.'),
]

# ==================================================================  PHASE 5 — THE GREAT PEACE
PHASE_PEACE = [
    E('peace', '1615–1868', 'The Great Peace and the age it made', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'Out of a century and a half of chaos comes one of history’s great stabilities: the Tokugawa impose 250 years of peace, seal Japan off from the outside world, and transform the warrior class into administrators — the settled order the whole bloody age had been building toward.',
      svg_stack('Order out of a century of blood', [
          {'n': 1, 'label': '~250 years of peace', 'sub': 'the Tokugawa shogunate ends the endless wars', 'color': '#166534'},
          {'n': 2, 'label': 'Sakoku — closed country', 'sub': 'Japan seals itself off from the outside world', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Warriors become bureaucrats', 'sub': 'the samurai turn from soldiers to administrators', 'color': '#b45309'},
      ], takeaway='The Warring States ended in its opposite: a rigid, peaceful, closed order that lasted a quarter of a millennium.', accent=AC),
      bg='The Tokugawa shogunate, founded on the ashes of the Sengoku, built one of the most durable orders in Japanese history.',
      people='The Tokugawa shoguns; the samurai class transformed by peace; the merchant culture that flourished under it.',
      what='The <b>Tokugawa peace</b> lasted about <b>250 years</b>, enforced by a tight system of control, a policy of near-total isolation (<b>sakoku</b>), and the gradual transformation of the <b>samurai from warriors into administrators</b> — while a rich urban culture flourished.',
      crux='The age of endless war ended in its <b>opposite</b>: a rigidly ordered, peaceful, closed society — the settled destination toward which the whole violent era had been driving.',
      conseq='This stability shaped Japan until the mid-19th century, when Western pressure and internal strains brought the Tokugawa order down and launched Japan’s modern transformation.',
      matters='The Sengoku’s ultimate meaning lies in what it produced: the long Tokugawa peace, and the foundations of the Japan that would later modernise so explosively.'),

    E('culture', '1615–1868', 'The flowering — a golden age of peace', ['REFORM', 'TRIUMPH'],
      'The long peace that ends the wars becomes one of history’s great cultural flowerings: with the samurai idled and cities booming, a vibrant urban culture explodes — kabuki theatre, the woodblock prints of the "floating world," haiku poetry, and a thriving merchant class — the creative harvest of the order the century of war finally produced.',
      svg_stack('War’s end becomes a cultural golden age', [
          {'n': 1, 'label': 'A booming urban culture', 'sub': 'great cities; a rich, rising merchant class', 'color': '#166534'},
          {'n': 2, 'label': 'Kabuki and ukiyo-e', 'sub': 'theatre and the woodblock prints of the “floating world”', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Haiku and the arts', 'sub': 'Bashō’s poetry; a flowering of arts and letters', 'color': '#b45309'},
      ], takeaway='The peace the wars produced became a golden age — kabuki, ukiyo-e, haiku, and a vibrant merchant culture.', accent=AC),
      bg='The stability of the Tokugawa peace, following a century of war, allowed an extraordinary <b>cultural flowering</b>, especially in the growing cities.',
      people='The urban merchants and artisans; playwrights, print-makers and poets like <b>Bashō</b>; the idled samurai turned scholars and administrators.',
      what='The Tokugawa peace produced a <b>golden age of urban culture</b> — <b>kabuki theatre</b>, the <b>ukiyo-e woodblock prints</b> of the "floating world," <b>haiku</b> poetry, and a thriving <b>merchant class</b> — the creative harvest of the order the wars had forged.',
      crux='The century of war ultimately yielded not just peace but a <b>rich, distinctive civilisation</b> — the constructive fruit of all the preceding destruction.',
      conseq='This culture defined much of what the world now recognises as classical Japanese art and remains deeply influential.',
      matters='The Sengoku’s final gift was cultural. The peace it produced flowered into one of history’s great artistic ages — beauty born from an age of blood.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">The Sengoku Jidai — Japan’s "Warring States" era — was a century and a half of civil war that began when central authority collapsed and ended when three extraordinary unifiers — Nobunaga, Hideyoshi and Ieyasu — forged a single, peaceful nation from the chaos. It is a study in <b>the collapse and rebuilding of order, talent triumphing over birth (gekokujō), the gunpowder revolution, and how a violent age produced a 250-year peace.</b></p>
<div class="ov-quote">“Nobunaga pounds the national rice-cake, Hideyoshi kneads it, and in the end Ieyasu sits down and eats it.”<span>— a famous Japanese verse on the three unifiers</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">The Ōnin War shatters central authority → a century of warlords fight in a brutal meritocracy of violence → firearms and Christianity arrive → Nobunaga rises at Okehazama and revolutionises war at Nagashino, then is betrayed at Honnō-ji → the peasant Hideyoshi avenges him, completes the unification, and overreaches in Korea → Ieyasu wins the decisive Battle of Sekigahara, becomes shogun, and destroys the last rivals at Osaka → and the Tokugawa impose 250 years of peace.</p>
<div class="ov-lbl">Why the era matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⚔️</div><h4>Order rebuilt</h4><p>A masterclass in how collapse gives way to a new, lasting order.</p></div>
  <div class="ov-card"><div class="i">🌾</div><h4>Gekokujō</h4><p>An age when a peasant could rise to rule all Japan.</p></div>
  <div class="ov-card"><div class="i">🔫</div><h4>The gun revolution</h4><p>Nagashino shows firepower overtaking the cavalry charge.</p></div>
  <div class="ov-card"><div class="i">🏯</div><h4>The 250-year peace</h4><p>A violent era produced one of history’s great stabilities.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Shattering</b><small> 1467–1549</small><p>The Ōnin War, the warlords, and the coming of the gun.</p></div>
  <div><b>2 · Nobunaga</b><small> 1560–82</small><p>The ruthless innovator who begins unification.</p></div>
  <div><b>3 · Hideyoshi</b><small> 1582–98</small><p>The peasant who completes it — and overreaches.</p></div>
  <div><b>4 · Ieyasu</b><small> 1598–1615</small><p>Sekigahara, the shogunate, and Osaka.</p></div>
  <div><b>5 · The Great Peace</b><small> 1615–1868</small><p>The 250-year Tokugawa order.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b> of the era’s turning points. <b>Click any event</b> to expand its concept map. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references. For a deeper look at the third unifier, see the Tokugawa Ieyasu guide in Great Men.</p>
"""

WHO = [
    {'name': 'Oda Nobunaga', 'role': 'first unifier', 'color': '#7f1d1d',
     'bio': 'The ruthless, innovative warlord who began the unification of Japan, revolutionised warfare with firearms, and was betrayed and killed at Honnō-ji in 1582.',
     'rel': 'The innovator who "pounds the rice" — begins the unification.'},
    {'name': 'Toyotomi Hideyoshi', 'role': 'second unifier', 'color': '#b45309',
     'bio': 'A man born a peasant who rose through Nobunaga’s service to complete the unification of Japan, then overreached in two disastrous invasions of Korea.',
     'rel': 'The peasant genius who "kneads the dough" — completes unification.'},
    {'name': 'Tokugawa Ieyasu', 'role': 'third unifier', 'color': '#166534',
     'bio': 'The patient, calculating warlord who won at Sekigahara, became shogun in 1603, and founded a dynasty that ruled Japan in peace for over 250 years.',
     'rel': 'The patient waiter who "eats the cake" — inherits a united Japan.'},
    {'name': 'Imagawa Yoshimoto', 'role': 'great warlord', 'color': '#6b7280',
     'bio': 'A powerful daimyō whose huge army was destroyed and who was killed by Nobunaga at Okehazama in 1560 — the upset that launched Nobunaga.',
     'rel': 'The great lord whose fall began Nobunaga’s rise.'},
    {'name': 'Akechi Mitsuhide', 'role': 'the betrayer', 'color': '#7c3aed',
     'bio': 'Nobunaga’s general who turned on him at Honnō-ji in 1582, only to be crushed days later by Hideyoshi at Yamazaki.',
     'rel': 'The general whose betrayal killed Nobunaga.'},
    {'name': 'Ishida Mitsunari', 'role': 'Toyotomi loyalist', 'color': '#0369a1',
     'bio': 'The loyalist who led the Western Army against Ieyasu at Sekigahara in defence of Hideyoshi’s heir, and was defeated and executed.',
     'rel': 'The loyalist who lost the decisive battle to Ieyasu.'},
]

KEY_EVENTS = [
    ('1467–77', 'The Ōnin War', 'Central authority collapses; the era begins.'),
    ('1543', 'Firearms arrive', 'Portuguese matchlocks reach Tanegashima.'),
    ('1549', 'Christianity arrives', 'Francis Xavier begins Jesuit missions.'),
    ('1560', 'Battle of Okehazama', 'Nobunaga’s stunning upset launches his rise.'),
    ('1575', 'Battle of Nagashino', 'Guns and palisades destroy Takeda cavalry.'),
    ('1582', 'Honnō-ji Incident', 'Nobunaga betrayed and killed; Hideyoshi avenges him.'),
    ('1590', 'Siege of Odawara', 'Hideyoshi completes the unification.'),
    ('1592–98', 'Invasions of Korea', 'A catastrophic overreach; ends with his death.'),
    ('1600', 'Battle of Sekigahara', 'Ieyasu wins mastery of Japan.'),
    ('1603', 'Tokugawa shogunate founded', 'Ieyasu becomes shogun.'),
    ('1614–15', 'Sieges of Osaka', 'The Toyotomi destroyed; the wars end.'),
    ('1615+', 'The Great Peace', '~250 years of Tokugawa stability.'),
]

MASTER = [
    {'year': '1467', 'age': 'start', 'phase': 'Shattering', 'title': 'The Ōnin War', 'desc': 'Order collapses.'},
    {'year': '1543', 'age': '—', 'phase': 'Shattering', 'title': 'Firearms arrive', 'desc': 'War is transformed.'},
    {'year': '1560', 'age': '—', 'phase': 'Nobunaga', 'title': 'Okehazama', 'desc': 'Nobunaga rises.'},
    {'year': '1575', 'age': '—', 'phase': 'Nobunaga', 'title': 'Nagashino', 'desc': 'The gun revolution.'},
    {'year': '1582', 'age': '—', 'phase': 'Hideyoshi', 'title': 'Honnō-ji', 'desc': 'Nobunaga falls; Hideyoshi rises.'},
    {'year': '1590', 'age': '—', 'phase': 'Hideyoshi', 'title': 'Unification complete', 'desc': 'Odawara falls.'},
    {'year': '1600', 'age': '—', 'phase': 'Ieyasu', 'title': 'Sekigahara', 'desc': 'Ieyasu wins Japan.'},
    {'year': '1615', 'age': 'end', 'phase': 'Great Peace', 'title': 'Osaka; the peace', 'desc': 'The Sengoku ends.'},
]

SOURCES = [
    ('Britannica — Sengoku period', 'https://www.britannica.com/topic/Sengoku-period'),
    ('World History Encyclopedia — Sengoku Period', 'https://www.worldhistory.org/Sengoku_Period/'),
    ('Britannica — Oda Nobunaga / Toyotomi Hideyoshi / Tokugawa Ieyasu', 'https://www.britannica.com/biography/Oda-Nobunaga'),
    ('Wikipedia — Sengoku period', 'https://en.wikipedia.org/wiki/Sengoku_period'),
]

def build_meta():
    return {
        'pid': 'era-sengoku.html', 'kind': 'era', 'emoji': '⚔️', 'accent': AC,
        'name': 'Sengoku Jidai', 'years': 'c. 1467–1615', 'group': 'Japan',
        'back': ('great-eras.html', 'Great Eras'),
        'epithet': 'Japan’s century and a half of civil war — the age of gekokujō and the gun — that forged three unifiers and ended in the 250-year Tokugawa peace.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'shatter', 'label': '1 · The Shattering', 'type': 'timeline',
             'intro': 'The Ōnin War wrecks central authority and plunges Japan into a century of warlords fighting in a brutal meritocracy of violence — into which firearms and Christianity suddenly arrive.', 'events': PHASE_SHATTER},
            {'id': 'nobunaga', 'label': '2 · Nobunaga', 'type': 'timeline',
             'intro': 'A minor, eccentric warlord stuns the age at Okehazama, revolutionises war with massed guns at Nagashino, and comes within reach of unifying Japan — before betrayal cuts him down at Honnō-ji.', 'events': PHASE_NOBUNAGA},
            {'id': 'hideyoshi', 'label': '3 · Hideyoshi', 'type': 'timeline',
             'intro': 'A man born a peasant avenges Nobunaga with astonishing speed, completes the unification of Japan by war and diplomacy, freezes the class system behind him — and overreaches disastrously in Korea.', 'events': PHASE_HIDEYOSHI},
            {'id': 'ieyasu', 'label': '4 · Ieyasu', 'type': 'timeline',
             'intro': 'The patient Tokugawa Ieyasu wins the decisive Battle of Sekigahara, becomes shogun, and destroys the last rivals at Osaka — ending a century and a half of war.', 'events': PHASE_IEYASU},
            {'id': 'peace', 'label': '5 · The Great Peace', 'type': 'timeline',
             'intro': 'Out of the chaos comes one of history’s great stabilities: the 250-year Tokugawa peace, a closed country, and the transformation of the samurai from warriors into administrators.', 'events': PHASE_PEACE,
             'sources': SOURCES, 'srcnote': 'Some vivid details (the rainstorm at Okehazama, the exact conduct of Nagashino’s volley fire) are debated by historians; the broad narrative of the three unifiers is well established.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
