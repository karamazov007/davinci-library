# -*- coding: utf-8 -*-
"""Full, DEEP birth-to-death guide content for Cardinal Richelieu.
The priest who built French absolutism and made 'reason of state' the law of nations."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#7f1d1d'  # cardinal red

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE RISE
PHASE_RISE = [
    E('bishop', '1585–1614', 'A soldier’s path abandoned for a bishop’s mitre', ['RISE'],
      'Armand-Jean du Plessis is raised for the army — but when the family’s only source of income, the bishopric of Luçon, needs an heir, the ambitious young man switches to the Church instead, becoming a bishop at twenty-one and turning a modest, marshy see into a springboard for boundless ambition.',
      svg_row('An ambition that took holy orders', [
          {'n': 1, 'label': 'Destined for the army', 'sub': 'a younger noble son trained as a soldier', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Takes the family bishopric', 'sub': 'switches to the Church to keep Luçon’s income', 'color': '#a16207'},
          {'n': 3, 'label': 'Bishop at 21, c. 1607', 'sub': 'a poor see becomes a base for advancement', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He bent his career to opportunity — trading a sword for a mitre to serve the same limitless ambition.', accent=AC),
      bg='Born in 1585 into the minor French nobility, <b>Armand-Jean du Plessis de Richelieu</b> was raised for a military career until family circumstances redirected him.',
      people='his family, whose fortunes depended on the <b>bishopric of Luçon</b>; the young Richelieu, adapting his path to ambition.',
      what='When the family bishopric of <b>Luçon</b> needed an heir, Richelieu took holy orders and became <b>bishop at 21</b> (c. 1607), throwing himself into administration and study while eyeing a far larger stage.',
      crux='He treated a career as a means to power — <b>switching from soldier to priest</b> without hesitation when the Church offered the surer route up.',
      conseq='The obscure young bishop soon found his opening on the national stage.',
      matters='The ambitious adapt their path to whatever door opens — the goal is power; the vocation is merely the vehicle.'),

    E('estates', '1614–1624', 'The Estates-General — a rising star at court', ['POLITICS', 'RISE', 'TURNING POINT'],
      'Richelieu makes his name at the Estates-General of 1614, impressing with his eloquence and gaining the patronage of the queen mother Marie de’ Medici — then, after political reversals and exile, claws his way back, wins a cardinal’s hat, and by 1624 enters the royal council of King Louis XIII.',
      svg_stack('Climbing to the king’s council', [
          {'n': 1, 'label': 'Shines at the Estates-General, 1614', 'sub': 'eloquence wins him notice and patrons', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Marie de’ Medici’s favour', 'sub': 'the queen mother becomes his patron', 'color': '#a16207'},
          {'n': 3, 'label': 'Cardinal 1622, council 1624', 'sub': 'enters Louis XIII’s government', 'color': '#166534'},
      ], takeaway='He rose by patronage and sheer ability — surviving reversals to reach the inner circle of royal power.', accent=AC),
      bg='France in the early 1600s was ruled by the young <b>Louis XIII</b> under the regency and influence of his mother, <b>Marie de’ Medici</b>.',
      people='<b>Marie de’ Medici</b>, the queen mother and his patron; <b>Louis XIII</b>, the king he would serve; rival court factions.',
      what='Richelieu impressed at the <b>Estates-General of 1614</b>, gained Marie de’ Medici’s patronage, weathered political exile, was made a <b>cardinal in 1622</b>, and joined the <b>royal council in 1624</b>, soon becoming Louis XIII’s chief minister.',
      crux='He advanced through <b>patronage, eloquence and resilience</b>, turning setbacks into stepping-stones toward the center of power.',
      conseq='As chief minister, he would rule France in the king’s name for eighteen years.',
      matters='Political ascent is rarely straight — the survivors turn exile and reversal into the experience that carries them to the top.'),
]

# ==================================================================  PHASE 2 — REASON OF STATE
PHASE_POWER = [
    E('daydupes', '1630', 'The Day of the Dupes — surviving the queen mother', ['POLITICS', 'TURNING POINT'],
      'Richelieu’s enemies, led by his own former patron Marie de’ Medici, seem to have won — convincing the king to dismiss him — but in a single dramatic day Louis XIII reverses himself, keeps Richelieu, and exiles the queen mother instead, cementing the Cardinal’s power for the rest of his life.',
      svg_stack('A dismissal that became a triumph', [
          {'n': 1, 'label': 'Marie de’ Medici moves against him', 'sub': 'the queen mother demands his dismissal', 'color': '#a16207'},
          {'n': 2, 'label': 'The king seems to agree', 'sub': 'the court believes Richelieu is finished', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Louis XIII backs Richelieu', 'sub': 'the queen mother is exiled; the Cardinal supreme', 'color': '#7f1d1d'},
      ], takeaway='At the moment he seemed doomed, the king chose him over his own mother — and his power became unshakable.', accent=AC),
      bg='By 1630 Richelieu’s policies had made powerful enemies, above all his former patron <b>Marie de’ Medici</b>, who pressed Louis XIII to be rid of him.',
      people='<b>Marie de’ Medici</b>, the queen mother; <b>Louis XIII</b>, forced to choose; the courtiers who wrongly celebrated Richelieu’s fall.',
      what='On the <b>“Day of the Dupes” (Nov 1630)</b>, Marie de’ Medici seemed to have secured Richelieu’s dismissal — but Louis XIII <b>reaffirmed his minister and exiled his own mother</b>, ending the threat.',
      crux='He survived because <b>the king valued his indispensable competence</b> over family and faction — a bond that made him unassailable.',
      conseq='From 1630 until his death, Richelieu ruled France with the king’s full backing, free to pursue his grand design.',
      matters='The indispensable servant can outweigh even a king’s mother — competence, and a monarch’s trust, are the surest shields.'),

    E('raison', '1624–1642', 'Raison d’état — the state above all', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'Richelieu governs by a single ruthless principle — raison d’état, “reason of state” — the doctrine that the interest of the state stands above religion, morality, and every private loyalty, and that the ends of national power justify almost any means, a philosophy that founds the modern state itself.',
      svg_stack('The doctrine that made the modern state', [
          {'n': 1, 'label': 'The state’s interest is supreme', 'sub': 'above religion, faction and private morality', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Ends justify the means', 'sub': 'ruthless methods in the service of national power', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A Catholic cardinal’s cold logic', 'sub': 'a priest who put France before the faith', 'color': '#a16207'},
      ], takeaway='He made the interest of the state the highest law — a principle that still underlies international politics.', accent=AC),
      bg='Europe was riven by religious war. Richelieu, though a cardinal, came to judge every question by <b>the interest of the French state</b>, not by faith.',
      people='the theorists of <b>raison d’état</b>; his critics who called it godless; the later statesmen who inherited the doctrine.',
      what='Richelieu governed by <b>raison d’état</b> — placing the <b>state’s interest above religion, morality and private loyalty</b>, and holding that the ends of national power justify ruthless means — a foundational principle of the modern state.',
      crux='He elevated <b>the state itself into the supreme value</b>, detaching politics from religion and personal morality.',
      conseq='Raison d’état shaped the European state system codified at Westphalia (1648) and the practice of power politics ever since.',
      matters='The idea that the state’s interest overrides all else defines modern politics — and Richelieu is its founding practitioner.'),
]

# ==================================================================  PHASE 3 — TAMING FRANCE
PHASE_DOMESTIC = [
    E('larochelle', '1627–1628', 'La Rochelle — breaking the Protestant state-within-a-state', ['BATTLE', 'POLITICS', 'TRIUMPH'],
      'The Huguenots — French Protestants — hold fortified cities and their own armies, a state within the state that Richelieu cannot tolerate; he besieges their great stronghold of La Rochelle, seals its harbour with a vast sea-wall, and starves it into surrender — then, revealingly, lets the Protestants keep their religion, proving his aim was political power, not faith.',
      svg_stack('Crushing a rival power, not a religion', [
          {'n': 1, 'label': 'Huguenot armed cities', 'sub': 'a Protestant “state within the state”', 'color': '#a16207'},
          {'n': 2, 'label': 'Siege of La Rochelle, 1627–28', 'sub': 'a huge sea-wall seals the harbour; the city starves', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Religion kept, power broken', 'sub': 'the Peace of Alès leaves faith but ends the armies', 'color': '#166534'},
      ], takeaway='He destroyed the Huguenots’ military power while leaving their faith — proof his war was for the state, not the Church.', accent=AC),
      bg='The <b>Huguenots</b> (French Protestants) held fortified towns and private armies under earlier edicts — an armed rival to royal authority Richelieu meant to end.',
      people='the Huguenot defenders of <b>La Rochelle</b>; their English would-be rescuers; Louis XIII and Richelieu directing the siege.',
      what='Richelieu besieged <b>La Rochelle (1627–28)</b>, building a <b>1.5 km sea-wall</b> to seal its harbour and starving it into surrender. The <b>Peace of Alès (1629)</b> stripped the Huguenots of their fortresses and armies <b>but preserved their freedom of worship</b>.',
      crux='He targeted the Huguenots’ <b>political and military autonomy, not their beliefs</b> — a purely raison-d’état distinction.',
      conseq='The Protestant “state within the state” was destroyed; royal authority extended over all of France.',
      matters='The state cannot tolerate rival armed powers within it — Richelieu ended the Huguenots’ autonomy while sparing their faith.'),

    E('nobles', '1626–1642', 'Breaking the great nobles — duels, castles and conspiracies', ['POLITICS', 'TRAGEDY', 'REFORM'],
      'Richelieu wages a relentless campaign to subordinate the mighty French aristocracy to the crown — banning the duels by which they asserted honour, razing the fortified castles from which they defied the king, and crushing conspiracy after conspiracy with the executioner’s axe, even against the highest in the land.',
      svg_row('Subordinating the aristocracy to the crown', [
          {'n': 1, 'label': 'Ban private war and duels', 'sub': 'ends the nobles’ tradition of settling honour by the sword', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Raze the fortified castles', 'sub': 'demolishes strongholds that defied royal power', 'color': '#a16207'},
          {'n': 3, 'label': 'Execute the conspirators', 'sub': 'Chalais, Montmorency, Cinq-Mars — no rank is safe', 'color': '#b91c1c'},
      ], edge_labels=['plus', 'plus'], takeaway='He tamed the proud aristocracy by force and fear — no title was high enough to escape the axe.', accent=AC),
      bg='The great <b>French nobility</b> held private armies, fortresses and a tradition of defying the crown. Richelieu set out to make them obey the king absolutely.',
      people='the executed conspirators <b>Chalais (1626)</b>, <b>Montmorency (1632)</b> and <b>Cinq-Mars (1642)</b>; the dueling nobles; the crown.',
      what='Richelieu <b>banned dueling and private war</b>, ordered the <b>demolition of noble fortresses</b>, and <b>ruthlessly crushed aristocratic conspiracies</b> — executing even great lords like Montmorency and the king’s favourite Cinq-Mars.',
      crux='He subordinated the nobility to the state by <b>stripping their means of defiance and terrifying them into obedience</b>.',
      conseq='The taming of the aristocracy laid the groundwork for the absolute monarchy Louis XIV would perfect.',
      matters='Centralised power requires humbling rival elites — Richelieu broke the nobles’ independence and bent them to the crown.'),

    E('intendants', '1624–1642', 'The intendants — a bureaucracy loyal only to the king', ['REFORM', 'POLITICS'],
      'To rule France directly rather than through unreliable local grandees, Richelieu extends the use of intendants — royal agents sent into the provinces with sweeping powers over justice, taxes and order, answerable only to the crown — building the professional bureaucracy of the modern centralized state.',
      svg_stack('Governing through the king’s own agents', [
          {'n': 1, 'label': 'Unreliable local powers', 'sub': 'provincial nobles and officeholders resist the crown', 'color': '#a16207'},
          {'n': 2, 'label': 'Royal intendants sent out', 'sub': 'agents with power over justice, tax and order', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Loyal only to the king', 'sub': 'a professional bureaucracy bypassing the grandees', 'color': '#166534'},
      ], takeaway='He built a professional state machine answerable directly to the crown — the skeleton of modern government.', accent=AC),
      bg='Royal power in the provinces had depended on local nobles and venal officeholders with their own interests. Richelieu needed direct, reliable control.',
      people='the <b>intendants</b>, the crown’s provincial agents; the local grandees they bypassed; the taxpayers they oversaw.',
      what='Richelieu expanded the system of <b>intendants</b> — royal commissioners dispatched to the provinces with broad authority over <b>justice, finance and policing</b>, answerable only to the crown — a foundation of centralized administration.',
      crux='He replaced rule through <b>independent local elites</b> with a <b>professional bureaucracy loyal to the king alone</b>.',
      conseq='The intendant system became a pillar of French absolutism and a model of the modern administrative state.',
      matters='Central power is built through loyal administration — a professional bureaucracy that answers only to the center.'),
]

# ==================================================================  PHASE 4 — THE STATE-BUILDER
PHASE_STATE = [
    E('academie', '1635', 'The Académie française — controlling language and culture', ['REFORM', 'TRIUMPH'],
      'Richelieu understands that power includes prestige and ideas — so he founds the Académie française to regulate and refine the French language, patronises the theatre and the arts, and harnesses culture to the glory of the state he is building.',
      svg_row('Power over words and ideas', [
          {'n': 1, 'label': 'Founds the Académie française, 1635', 'sub': 'a body to regulate and perfect the language', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Patron of arts and theatre', 'sub': 'supports writers and playwrights', 'color': '#a16207'},
          {'n': 3, 'label': 'Culture in the state’s service', 'sub': 'prestige and ideas harnessed to national glory', 'color': '#166534'},
      ], edge_labels=['plus', 'so'], takeaway='He grasped that a great state needs cultural authority — and institutionalised control over the language itself.', accent=AC),
      bg='Richelieu saw <b>language, prestige and ideas</b> as instruments of state power, and sought to make France the cultural leader of Europe.',
      people='the writers and scholars of the <b>Académie française</b>; the playwrights (like Corneille) he patronised and sometimes chafed against.',
      what='In <b>1635</b> Richelieu founded the <b>Académie française</b> to standardize and refine the French language, and became a major <b>patron of literature and theatre</b> — binding culture to the state’s prestige.',
      crux='He treated <b>culture and language as instruments of national power</b>, institutionalising authority over them.',
      conseq='The Académie française still governs the French language today, nearly four centuries later — one of his most enduring creations.',
      matters='Great powers project through culture as well as arms — controlling language and prestige is a form of statecraft.'),

    E('navy', '1626–1642', 'Sea power and empire — building France outward', ['REFORM', 'BATTLE'],
      'Richelieu builds France into a naval and commercial power almost from scratch — creating a royal navy and merchant marine, chartering trading companies, and promoting colonization in New France (Canada) — extending the reach of the state onto the oceans and into a new world.',
      svg_stack('A land power turns to the sea', [
          {'n': 1, 'label': 'A new royal navy', 'sub': 'builds fleets for the Atlantic and Mediterranean', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Trade companies', 'sub': 'charters commercial ventures on the Dutch model', 'color': '#a16207'},
          {'n': 3, 'label': 'New France expands', 'sub': 'promotes colonization in Canada', 'color': '#166534'},
      ], takeaway='He extended state power onto the oceans — laying the foundations of France as a maritime and colonial power.', accent=AC),
      bg='France lagged the Dutch and English at sea. Richelieu, taking the title of grand master of navigation, set out to build French naval and commercial power.',
      people='the shipwrights and sailors of the new navy; the trading companies he chartered; the colonists of <b>New France</b>.',
      what='Richelieu <b>built a royal navy and merchant marine</b>, chartered <b>trading companies</b>, and promoted the <b>colonization of New France (Canada)</b> — projecting the state’s power onto the seas and overseas.',
      crux='He understood that a first-rank power needed <b>maritime and commercial strength</b>, not just armies — and built them where France had lacked them.',
      conseq='His naval and colonial foundations underpinned France’s later emergence as a global power.',
      matters='Great-power status requires reach — a serious state builds the ships and trade that project it beyond its borders.'),
]

# ==================================================================  PHASE 5 — AGAINST THE HABSBURGS
PHASE_FOREIGN = [
    E('thirtyyears', '1630–1642', 'Catholic France against the Catholic Habsburgs', ['BATTLE', 'POLITICS', 'TURNING POINT'],
      'In the Thirty Years’ War, Richelieu makes the most shocking application of raison d’état — a Catholic cardinal funding and then joining Protestant powers, Sweden and the Dutch, against the Catholic Habsburgs of Austria and Spain — because France’s overriding interest is to break the Habsburg ring that encircles her, faith be damned.',
      svg_compare('Faith versus the interest of France',
        {'head': 'Religion would say', 'color': '#a16207', 'items': ['a cardinal should back Catholic Habsburgs', 'against Protestant Sweden and the Dutch', 'the war is a Catholic-Protestant struggle']},
        {'head': 'Raison d’état said', 'color': '#7f1d1d', 'items': ['France is encircled by Habsburg power', 'so fund and join the Protestants', 'break the Habsburg ring at any cost']},
        'He chose France over the Church — a Catholic cardinal at war with the Catholic powers.',
        'Reason of state overrode even religion — national interest as the supreme guide.', AC),
      bg='The <b>Habsburgs</b> of Austria and Spain surrounded France and dominated the <b>Thirty Years’ War</b>. Richelieu judged breaking their encirclement France’s vital interest.',
      people='the Protestant allies — <b>Sweden</b> (Gustavus Adolphus) and the <b>Dutch</b>; the Catholic <b>Habsburgs</b> he opposed; his scandalised critics.',
      what='Richelieu first <b>subsidised the Protestant powers</b> (Sweden, the Dutch) against the Habsburgs, then brought France into open war — a Catholic cardinal fighting the Catholic powers <b>purely for reasons of state</b>.',
      crux='He subordinated <b>religion entirely to national interest</b> — the purest and most controversial application of raison d’état.',
      conseq='France’s intervention helped break Habsburg dominance and set France on the path to becoming Europe’s leading power.',
      matters='National interest can override even deep religious loyalty — Richelieu proved the state had become the highest allegiance.'),

    E('spain', '1635–1642', 'War with Spain — from near-disaster to dominance', ['BATTLE', 'TRIUMPH', 'TRAGEDY'],
      'Richelieu takes France into open war with Spain in 1635 — a colossal strain that nearly ends in catastrophe when Spanish forces drive to within striking distance of Paris in 1636 — but he holds his nerve, rallies the country, and turns the tide, setting France on course to supplant Spain as the greatest power in Europe.',
      svg_stack('Holding nerve through catastrophe', [
          {'n': 1, 'label': 'Open war with Spain, 1635', 'sub': 'a vast, costly struggle on many fronts', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Crisis at Corbie, 1636', 'sub': 'Spanish forces threaten Paris; panic grips the capital', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The tide turns', 'sub': 'Richelieu rallies France; the danger passes', 'color': '#166534'},
      ], takeaway='He gambled France into a war for European mastery — and held his nerve through the moment it nearly failed.', accent=AC),
      bg='In 1635 Richelieu committed France to <b>open war with Habsburg Spain</b>, then the greatest power in Europe — an enormous, ruinously expensive undertaking.',
      people='the Spanish armies that nearly reached Paris; the French population strained by war taxes; Richelieu, steadying the state.',
      what='The war brought France to the brink when Spanish forces advanced to <b>Corbie</b>, near Paris, in <b>1636</b>. Richelieu <b>rallied the nation</b>, the crisis passed, and France gradually gained the upper hand.',
      crux='He held his nerve at the point of near-catastrophe, understanding that <b>the struggle for European primacy was worth the risk</b>.',
      conseq='The war (continued after his death) ended with France supplanting Spain as Europe’s dominant power.',
      matters='The greatest gambles demand steadiness at the moment of maximum danger — nerve, not just planning, wins wars for supremacy.'),

    E('death', '1642', 'Death — and an empire of the state left behind', ['DEATH', 'REFORM', 'TURNING POINT'],
      'Richelieu dies in 1642, worn out at fifty-seven, having transformed France from a fractured, faction-ridden kingdom into a centralized state on the road to European dominance — leaving his protégé Mazarin to continue his work and the ground prepared for the absolute monarchy of Louis XIV, the Sun King.',
      svg_row('The state he built outlives him', [
          {'n': 1, 'label': 'Dies in 1642', 'sub': 'exhausted at 57, the state transformed', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Mazarin continues', 'sub': 'his hand-picked protégé carries on the design', 'color': '#a16207'},
          {'n': 3, 'label': 'The road to Louis XIV', 'sub': 'the ground laid for absolute monarchy and French primacy', 'color': '#166534'},
      ], edge_labels=['then', 'toward'], takeaway='He built a state, not just a career — and it carried France to the summit of Europe after he was gone.', accent=AC),
      bg='By 1642 Richelieu had governed France for eighteen years, remaking it as a centralized power — but the strain had broken his health.',
      people='his protégé <b>Cardinal Mazarin</b>, who succeeded him; <b>Louis XIII</b> (who died in 1643); the young <b>Louis XIV</b>, whose absolutism he prepared.',
      what='Richelieu <b>died in 1642</b>, aged 57, having centralized the state, humbled the nobles and Huguenots, and set France against the Habsburgs. <b>Mazarin</b> continued his policies, and the absolute monarchy of <b>Louis XIV</b> rose on his foundations.',
      crux='He built <b>durable institutions of state power</b>, not merely a personal ascendancy — his design outlasted him.',
      conseq='French absolutism and European primacy in the later 1600s were the harvest of Richelieu’s work.',
      matters='The truest measure of a statesman is what survives him — Richelieu built a state that carried France to greatness after his death.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Cardinal Richelieu was the founder of French absolutism and the master of a ruthless idea: raison d’état, that the interest of the state stands above religion, morality, and every private loyalty. As chief minister to Louis XIII for eighteen years, he broke the Huguenots’ armed autonomy, humbled the great nobles, built a centralized bureaucracy, founded the Académie française, and — a Catholic cardinal — allied France with Protestant powers against the Catholic Habsburgs to make France the leading power in Europe. He is the ultimate study in <b>the state above all, power over principle, and building institutions that outlast their maker.</b></p>
<div class="ov-quote">“Where the interests of the state are concerned, one must set aside the ties of blood, of friendship, of religion.”<span>— attributed to the spirit of Richelieu’s raison d’état</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A soldier’s son takes a bishopric to advance → shines at the Estates-General and wins royal patronage → becomes cardinal and chief minister → survives the Day of the Dupes to rule unchallenged → governs by raison d’état → breaks the Huguenots at La Rochelle and humbles the nobles → builds intendants, a navy and the Académie française → and, a Catholic cardinal, wages war on the Catholic Habsburgs to make France supreme — leaving a centralized state that carries France to the age of Louis XIV.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⛪</div><h4>Reason of state</h4><p>Made the state’s interest the supreme value — the foundation of modern politics.</p></div>
  <div class="ov-card"><div class="i">👑</div><h4>French absolutism</h4><p>Centralized the state and humbled its rivals — the road to the Sun King.</p></div>
  <div class="ov-card"><div class="i">🏛️</div><h4>The administrative state</h4><p>Intendants and bureaucracy loyal only to the crown — modern government.</p></div>
  <div class="ov-card"><div class="i">🌍</div><h4>France ascendant</h4><p>Broke Habsburg dominance to make France Europe’s leading power.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Rise</b><small> 1585–1624</small><p>Bishop, court star, and cardinal-minister.</p></div>
  <div><b>2 · Reason of State</b><small> 1624–1642</small><p>The Day of the Dupes and raison d’état.</p></div>
  <div><b>3 · Taming France</b><small> 1626–1642</small><p>La Rochelle, the nobles, and the intendants.</p></div>
  <div><b>4 · The State-Builder</b><small> 1635–1642</small><p>The Académie, the navy, and empire.</p></div>
  <div><b>5 · Against the Habsburgs</b><small> 1630–1642</small><p>The Thirty Years’ War and war with Spain.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Louis XIII', 'role': 'king', 'color': '#a16207',
     'bio': 'King of France who, despite an often uneasy personal relationship, backed Richelieu absolutely for eighteen years — the trust that made the Cardinal’s power possible.',
     'rel': 'The king whose steadfast backing was Richelieu’s shield.'},
    {'name': 'Marie de’ Medici', 'role': 'patron then enemy', 'color': '#b91c1c',
     'bio': 'The queen mother who first sponsored Richelieu’s rise, then turned against him — and was exiled after failing to bring him down on the Day of the Dupes.',
     'rel': 'The patron-turned-enemy he defeated in 1630.'},
    {'name': 'Cardinal Mazarin', 'role': 'protégé and successor', 'color': '#166534',
     'bio': 'Richelieu’s hand-picked protégé, who succeeded him as chief minister and continued his policies through the minority of Louis XIV.',
     'rel': 'The successor who carried on his design.'},
    {'name': 'Gustavus Adolphus', 'role': 'Protestant ally', 'color': '#7f1d1d',
     'bio': 'The Protestant king of Sweden whom the Catholic Richelieu subsidised against the Habsburgs — the boldest stroke of his raison-d’état diplomacy.',
     'rel': 'The Protestant champion Richelieu funded against Catholic powers.'},
    {'name': 'Cinq-Mars', 'role': 'conspirator', 'color': '#78350f',
     'bio': 'The young royal favourite whose plot against Richelieu was uncovered and who was executed in 1642 — the last of the noble conspiracies the Cardinal crushed.',
     'rel': 'The favourite whose conspiracy Richelieu destroyed.'},
]

KEY_EVENTS = [
    ('1585', 'Richelieu born', 'Into the minor French nobility.'),
    ('c.1607', 'Bishop of Luçon', 'Takes holy orders for advancement.'),
    ('1622', 'Made a cardinal', 'Rises toward the center of power.'),
    ('1624', 'Chief minister', 'Enters Louis XIII’s council.'),
    ('1628', 'Fall of La Rochelle', 'Breaks Huguenot military power.'),
    ('1630', 'The Day of the Dupes', 'Survives; the queen mother exiled.'),
    ('1635', 'Académie française founded', 'And open war with Spain begins.'),
    ('1635–42', 'War on the Habsburgs', 'Raison d’état over religion.'),
    ('1642', 'Death of Richelieu', 'Mazarin succeeds; absolutism prepared.'),
]

MASTER = [
    {'year': '1585', 'age': 'born', 'phase': 'The Rise', 'title': 'Born a noble’s son', 'desc': 'Minor French nobility.'},
    {'year': '1624', 'age': 'age 39', 'phase': 'Reason of State', 'title': 'Chief minister', 'desc': 'Rules for the king.'},
    {'year': '1628', 'age': 'age 43', 'phase': 'Taming France', 'title': 'La Rochelle falls', 'desc': 'Huguenot power broken.'},
    {'year': '1630', 'age': 'age 45', 'phase': 'Reason of State', 'title': 'Day of the Dupes', 'desc': 'Power made secure.'},
    {'year': '1635', 'age': 'age 50', 'phase': 'Against the Habsburgs', 'title': 'War on Spain', 'desc': 'For French primacy.'},
    {'year': '1642', 'age': 'age 57', 'phase': 'Against the Habsburgs', 'title': 'Death', 'desc': 'The state built to last.'},
]

SOURCES = [
    ('Britannica — Cardinal de Richelieu', 'https://www.britannica.com/biography/Armand-Jean-du-Plessis-cardinal-et-duc-de-Richelieu'),
    ('World History Encyclopedia — Cardinal Richelieu', 'https://www.worldhistory.org/Cardinal_Richelieu/'),
    ('Britannica — Siege of La Rochelle', 'https://www.britannica.com/event/Siege-of-La-Rochelle'),
    ('Britannica — Thirty Years’ War', 'https://www.britannica.com/event/Thirty-Years-War'),
    ('Wikipedia — Cardinal Richelieu', 'https://en.wikipedia.org/wiki/Cardinal_Richelieu'),
]

def build_meta():
    return {
        'pid': 'gm-richelieu.html', 'kind': 'man', 'emoji': '⛪', 'accent': AC,
        'name': 'Cardinal Richelieu', 'years': '1585–1642', 'group': 'Diplomats & Strategists',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The cardinal who founded French absolutism and made raison d’état — the interest of the state above religion and morality — the guiding principle of the modern state.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Rise', 'type': 'timeline',
             'intro': 'A soldier’s son takes a bishopric to advance, shines at the Estates-General, wins royal patronage, and rises through cardinal’s rank into the royal council as chief minister.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · Reason of State', 'type': 'timeline',
             'intro': 'He survives the Day of the Dupes to rule unchallenged, and governs by a single ruthless principle — raison d’état, the interest of the state above religion, morality and every private loyalty.', 'events': PHASE_POWER},
            {'id': 'domestic', 'label': '3 · Taming France', 'type': 'timeline',
             'intro': 'He breaks every rival power within France — the Huguenots’ armed autonomy at La Rochelle, the great nobles by axe and demolition, and local grandees through a bureaucracy of royal intendants.', 'events': PHASE_DOMESTIC},
            {'id': 'state', 'label': '4 · The State-Builder', 'type': 'timeline',
             'intro': 'He builds the machinery and prestige of a great state — founding the Académie française to command language and culture, and creating a navy and colonies to project French power outward.', 'events': PHASE_STATE},
            {'id': 'foreign', 'label': '5 · Against the Habsburgs', 'type': 'timeline',
             'intro': 'In the ultimate act of raison d’état, the Catholic cardinal funds and joins the Protestant powers against the Catholic Habsburgs — surviving near-catastrophe to set France on the road to European dominance.', 'events': PHASE_FOREIGN,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; some famous phrasings of “reason of state” are later attributions capturing his practice.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
