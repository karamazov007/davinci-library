# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Maharana Pratap.
The Sisodia Rajput ruler of Mewar who refused to submit to Akbar — an enduring symbol of defiance and honour."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b45309'  # Mewar saffron

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE RISE
PHASE_RISE = [
    E('origins', '1540', 'Born a Sisodia of Mewar', ['RISE', 'HONOUR'],
      'Pratap is born in 1540 at Kumbhalgarh, eldest son of Rana Udai Singh II and heir to the house of Sisodia — the proudest of the Rajput dynasties, whose creed held that Mewar must never bow to a foreign throne.',
      svg_row('Heir to the proudest Rajput house', [
          {'n': 1, 'label': 'Born at Kumbhalgarh, 1540', 'sub': 'eldest son of Rana Udai Singh II', 'color': '#b45309'},
          {'n': 2, 'label': 'The house of Sisodia', 'sub': 'the senior line of the Rajputs of Mewar', 'color': '#3730a3'},
          {'n': 3, 'label': 'A creed of honour', 'sub': 'Mewar must bow to no foreign crown', 'color': '#166534'},
      ], edge_labels=['of', 'and'], takeaway='He was raised in the one Rajput house that made never submitting a sacred point of honour.', accent=AC),
      bg='<b>Pratap Singh</b> was born on 18 May 1540 at Kumbhalgarh Fort, eldest son of <b>Rana Udai Singh II</b> of Mewar, of the Sisodia clan.',
      people='his father <b>Udai Singh II</b>, founder of Udaipur; the Sisodia nobles; the Rajput houses of Rajputana.',
      what='Pratap was born heir to <b>Mewar</b>, the leading Rajput kingdom, whose Sisodia rulers took special pride in never having accepted a foreign overlord — a tradition that would define his life.',
      crux='His identity was bound to a <b>creed of independence</b> — that honour mattered more than safety or gain.',
      conseq='This inheritance set him on a collision course with the expanding Mughal empire.',
      matters='Values absorbed in youth can shape a life — Pratap inherited a code that made submission unthinkable.'),

    E('chittor', '1568', 'The sack of Chittor', ['TRAGEDY', 'BATTLE'],
      'Akbar storms Mewar’s great fortress of Chittor in 1568, massacring its defenders and seizing the fertile eastern plains — a blow that drives the Mewar court west into the Aravalli hills and leaves the kingdom Pratap will inherit already broken.',
      svg_stack('The great fort falls', [
          {'n': 1, 'label': 'Akbar storms Chittor, 1568', 'sub': 'the Mughal siege takes Mewar’s chief fortress', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The eastern plains lost', 'sub': 'fertile Mewar passes to the Mughals', 'color': '#a16207'},
          {'n': 3, 'label': 'The court retreats west', 'sub': 'to Udaipur and the shelter of the Aravallis', 'color': '#3730a3'},
      ], takeaway='Chittor’s fall broke Mewar in two — and made its recovery the dream that would haunt the dynasty.', accent=AC),
      bg='In 1567–68 Akbar besieged and stormed <b>Chittorgarh</b>, Mewar’s greatest fort, before Pratap came to the throne.',
      people='<b>Akbar</b>, the conquering emperor; <b>Udai Singh II</b>, who had withdrawn from the fort; the slaughtered garrison.',
      what='Akbar’s <b>sack of Chittor (1568)</b> cost Mewar its symbolic fortress and its fertile eastern belt; the court fell back on the new capital of Udaipur and the hill country of the Aravalli range.',
      crux='The heart of the kingdom was lost, but the <b>wooded hills remained free</b> — a base from which to resist.',
      conseq='Recovering Chittor became the abiding ambition Pratap would pursue and, ultimately, fail to fulfil.',
      matters='A single defeat can define generations — the loss of Chittor set the stakes of Pratap’s entire struggle.'),

    E('accession', '1572', 'Crowned Rana at Gogunda', ['RISE', 'TURNING POINT'],
      'When Udai Singh dies in 1572, the succession is contested — but the nobles of Mewar override the late Rana’s favoured younger son and crown Pratap at Gogunda, placing on his shoulders a shrunken, hard-pressed kingdom that has already lost Chittor.',
      svg_stack('The chiefs choose their Rana', [
          {'n': 1, 'label': 'Udai Singh dies, 1572', 'sub': 'the succession is disputed with his brother Jagmal', 'color': '#a16207'},
          {'n': 2, 'label': 'The nobles crown Pratap', 'sub': 'they override the stepmother’s chosen heir', 'color': '#b45309'},
          {'n': 3, 'label': 'Rana of a shrunken realm', 'sub': 'the hills held, Chittor lost', 'color': '#166534'},
      ], takeaway='The nobles chose the elder, harder man for a hard time — and Pratap took up a kingdom under siege.', accent=AC),
      bg='<b>Udai Singh II</b> died in 1572, having favoured a younger son, <b>Jagmal</b>, over Pratap for the succession.',
      people='<b>Pratap</b>, the elder son; his half-brother <b>Jagmal</b>; the Sisodia nobles who decided the throne.',
      what='On his father’s death the <b>Mewar nobles set aside Jagmal and crowned Pratap</b> at Gogunda in 1572, giving him a kingdom reduced to its hills and stripped of Chittor.',
      crux='He inherited not a prize but a <b>burden</b> — a proud realm cut down and hemmed in by the Mughals.',
      conseq='As Rana, he now faced Akbar’s determined effort to bring Mewar, like the other Rajput states, under Mughal suzerainty.',
      matters='Leadership is often inherited at the worst moment — Pratap took the throne precisely when it was hardest to hold.'),
]

# ==================================================================  PHASE 2 — DEFIANCE
PHASE_DEFIANCE = [
    E('submission', '1572–1573', 'The Rajputs who bent the knee', ['POLITICS', 'HONOUR'],
      'Across Rajputana, the great Rajput houses make their peace with Akbar — entering Mughal service, sealing marriage alliances, and accepting rank and honour under the emperor. Pratap stands almost alone in refusing, keeping Mewar’s independence at the price of isolation.',
      svg_compare('Alliance versus defiance', {
          'head': 'Rajputs who allied with Akbar', 'color': '#a16207',
          'items': ['Amber’s Raja Man Singh joins Mughal service',
                    'Raja Bhagwan Das and other houses submit',
                    'marriage alliances bind them to the throne',
                    'rank and imperial favour reward their loyalty'],
      }, {
          'head': 'Pratap stands apart', 'color': '#b45309',
          'items': ['refuses to attend the Mughal court',
                    'rejects vassalage to the emperor',
                    'keeps Mewar formally independent',
                    'accepts isolation for the sake of honour'],
      }, verdict='Most Rajput kings chose accommodation; Pratap chose defiance.',
      takeaway='He was not fighting a foreign faith so much as standing alone against a settlement his own peers had accepted.', accent=AC),
      bg='By the 1570s <b>Akbar</b> had drawn most of the Rajput states into his empire through service and marriage, notably the house of <b>Amber</b>.',
      people='<b>Man Singh</b> and <b>Bhagwan Das</b> of Amber, now Mughal grandees; the other Rajput rajas; Pratap, the holdout.',
      what='While the leading <b>Rajput houses accepted Mughal overlordship</b> — taking rank, commands and marriage ties — Pratap refused to submit, isolating Mewar as the last great Rajput state outside the empire.',
      crux='His stand was as much against his <b>peers’ accommodation</b> as against Akbar — a lonely choice of principle.',
      conseq='His refusal made Mewar the one unresolved gap in Akbar’s otherwise complete Rajput settlement.',
      matters='Principle can mean isolation — Pratap paid for his defiance by standing where his fellow kings would not.'),

    E('envoys', '1573', 'Four missions, four refusals', ['POLITICS', 'TURNING POINT'],
      'Akbar tries hard to win Mewar without war, sending a succession of envoys — Jalal Khan, then Man Singh, then Bhagwan Das, then his finance minister Todar Mal — each offering Pratap honourable terms of submission. Every mission comes back empty; Pratap will not bend.',
      svg_stack('Diplomacy exhausted', [
          {'n': 1, 'label': 'Akbar sends his envoys', 'sub': 'first Jalal Khan, then Raja Man Singh', 'color': '#3730a3'},
          {'n': 2, 'label': 'Bhagwan Das and Todar Mal try', 'sub': 'honourable terms of submission offered', 'color': '#a16207'},
          {'n': 3, 'label': 'Every mission fails', 'sub': 'Pratap refuses to attend the court', 'color': '#b45309'},
      ], takeaway='Akbar preferred to win Mewar by persuasion — and only when four embassies failed did he resolve on war.', accent=AC),
      bg='Rather than fight, <b>Akbar</b> first sought to bring Pratap to submission through diplomacy in 1572–73.',
      people='the envoys <b>Jalal Khan</b>, <b>Man Singh</b>, <b>Bhagwan Das</b> and <b>Todar Mal</b>; Pratap, who received but resisted them.',
      what='Akbar dispatched <b>four successive embassies</b> — culminating in his ablest men — pressing Pratap to accept Mughal suzerainty; <b>all of them failed</b>, as Pratap consistently refused to appear at court in submission.',
      crux='He would not perform the ritual of submission — attending court — that Akbar required as the mark of vassalage.',
      conseq='With diplomacy exhausted, Akbar prepared to impose his will on Mewar by force.',
      matters='Some lines cannot be negotiated — Pratap’s refusal of even a symbolic bow made war inevitable.'),

    E('vow', '1573–1576', 'Honour over submission', ['HONOUR', 'TURNING POINT'],
      'The choice before Pratap is stark: submit and keep his lands in comfort under Akbar’s crown, or defy the mightiest empire in Asia and face ruin. He chooses defiance — placing the independence of Mewar above his own safety, wealth and survival.',
      svg_row('The stark choice', [
          {'n': 1, 'label': 'Submission means survival', 'sub': 'Akbar offers rank and autonomy under his crown', 'color': '#a16207'},
          {'n': 2, 'label': 'Pratap chooses defiance', 'sub': 'Mewar’s independence above all', 'color': '#b45309'},
          {'n': 3, 'label': 'War becomes certain', 'sub': 'Akbar resolves to break him by force', 'color': '#b91c1c'},
      ], edge_labels=['but', 'so'], takeaway='Offered ease in exchange for a bow, he chose hardship and freedom — the decision that made him a legend.', accent=AC),
      bg='By the mid-1570s Pratap faced a clear choice between accepting Mughal overlordship on generous terms or resisting alone.',
      people='<b>Pratap</b>, the defiant Rana; <b>Akbar</b>, whose patience had run out; the Mewar nobles who backed their king.',
      what='Pratap <b>rejected submission outright</b>, choosing to defend Mewar’s independence rather than accept Akbar’s suzerainty — a decision that guaranteed war with the empire.',
      crux='He valued <b>honour and independence above survival</b>, refusing comfort bought by a bended knee.',
      conseq='Akbar responded by ordering a full military campaign to crush Mewar’s resistance.',
      matters='The measure of a stand is its cost — Pratap chose the harder road knowingly, which is why it endured in memory.'),
]

# ==================================================================  PHASE 3 — HALDIGHATI
PHASE_HALDIGHATI = [
    E('prelude', '1576', 'The army marches under Man Singh', ['BATTLE', 'POLITICS'],
      'In 1576 Akbar sends a large army into Mewar to force the issue — and, in a bitter irony, places it under Raja Man Singh of Amber, a Rajput now serving the Mughals. Pratap gathers his outnumbered forces at the mountain pass of Haldighati to meet them.',
      svg_stack('Rajput against Rajput', [
          {'n': 1, 'label': 'Akbar orders invasion, 1576', 'sub': 'a Mughal army marches into Mewar', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Man Singh of Amber commands', 'sub': 'a Rajput leads the emperor’s host', 'color': '#a16207'},
          {'n': 3, 'label': 'Pratap masses at Haldighati', 'sub': 'the mountain pass near Gogunda', 'color': '#b45309'},
      ], takeaway='The battle would be Rajput against Rajput — the empire fielding one of its own against the last holdout.', accent=AC),
      bg='After diplomacy failed, <b>Akbar</b> ordered a military campaign against Mewar in 1576.',
      people='<b>Raja Man Singh I</b> of Amber, the Mughal commander; <b>Pratap</b>, defending; the mixed Mughal host.',
      what='Akbar sent a large army under <b>Man Singh of Amber</b> — a Rajput in Mughal service — into Mewar; Pratap chose to make his stand at the defile of <b>Haldighati</b>, near Gogunda, where the hills favoured a smaller force.',
      crux='The empire deliberately fielded a <b>Rajput commander</b> against Pratap, turning the war into a clash within Rajput society.',
      conseq='The two armies met on 18 June 1576 in the battle that would define Pratap’s legend.',
      matters='Empires co-opt the conquered to fight the free — Man Singh’s command shows how the Mughals absorbed Rajput power.'),

    E('battle', '18 June 1576', 'The Battle of Haldighati', ['BATTLE', 'TURNING POINT'],
      'At Haldighati, Pratap’s few thousand horsemen and Bhil archers throw themselves against a Mughal army several times their size. After hours of ferocious fighting Pratap is wounded and the field is lost — yet the Mughals fail in their real aim: they cannot capture or kill the Rana, who escapes to fight on.',
      svg_compare('The odds at Haldighati', {
          'head': 'Maharana Pratap', 'color': '#b45309',
          'items': ['around 3,000 cavalry',
                    'some 400 Bhil archers',
                    'fighting on home ground in the hills',
                    'Rajput and tribal allies'],
      }, {
          'head': 'The Mughal army', 'color': '#b91c1c',
          'items': ['around 10,000 men',
                    'led by Raja Man Singh of Amber',
                    'artillery, cavalry and archers',
                    'the resources of the empire'],
      }, verdict='A Mughal tactical victory — but Pratap escaped uncaptured.',
      takeaway='He lost the field but denied Akbar the one thing that mattered: the person of the Rana himself.', accent=AC),
      bg='On <b>18 June 1576</b> the two armies clashed in the pass of Haldighati, near Gogunda in modern Rajsamand.',
      people='<b>Pratap</b> and his Rajput and <b>Bhil</b> fighters; <b>Man Singh</b>’s far larger Mughal host.',
      what='At <b>Haldighati</b>, Pratap’s roughly 3,000 horse and 400 Bhil archers fought Man Singh’s army of some 10,000 for hours; the <b>Mughals won the field</b> and Pratap was wounded, but they failed to capture or destroy him.',
      crux='The victory was <b>hollow</b> — killing or seizing the Rana was the objective, and it eluded them.',
      conseq='Pratap withdrew into the hills, and the war became a long guerrilla struggle rather than a single decisive battle.',
      matters='A battle can be lost and a cause survive — Haldighati failed to end Mewar’s resistance, which was its whole point.'),

    E('chetak', '1576', 'Chetak and the escape', ['LEGEND', 'BATTLE'],
      'The most cherished stories of Haldighati cluster around Pratap’s escape: his faithful horse Chetak, said to have carried the wounded Rana clear of the enemy before dying of its own wounds, and a loyal Jhala chief who took up the royal insignia to draw the Mughals onto himself so his king could slip away.',
      svg_stack('Saved by loyalty', [
          {'n': 1, 'label': 'Pratap charges into the fight', 'sub': 'mounted, by tradition, on his horse Chetak', 'color': '#b45309'},
          {'n': 2, 'label': 'Chetak bears him clear', 'sub': 'the loyal steed carries him off, then dies (legend)', 'color': '#a16207'},
          {'n': 3, 'label': 'A Jhala chief saves the Rana', 'sub': 'takes up the royal emblem to draw the enemy', 'color': '#166534'},
      ], takeaway='The escape is remembered through acts of devotion — a horse and a chieftain who gave everything so the Rana lived.', accent=AC),
      bg='Pratap’s survival at Haldighati became the seed of Mewar’s most enduring legends of loyalty and sacrifice.',
      people='the warhorse <b>Chetak</b>, celebrated in tradition; the <b>Jhala chief</b> who covered his retreat; Pratap himself.',
      what='By tradition, Pratap’s horse <b>Chetak</b> carried the wounded Rana to safety before dying of its wounds, while a <b>Jhala noble</b> assumed the royal insignia to divert the enemy — enabling Pratap’s escape from the field.',
      crux='The heart of the legend is <b>self-sacrifice for the king</b> — devotion that turned a defeat into an epic.',
      conseq='Pratap lived to lead nearly two more decades of resistance from the hills.',
      matters='History records the escape; legend supplies its heroes — Chetak is celebrated in tradition rather than firmly documented.'),
]

# ==================================================================  PHASE 4 — THE WILDERNESS
PHASE_WILDERNESS = [
    E('guerrilla', '1576–1579', 'War from the hills', ['BATTLE', 'HARDSHIP'],
      'After Haldighati the Mughals seize Mewar’s towns — Gogunda, Udaipur, Kumbhalgarh — but Pratap refuses pitched battle. Withdrawing into the rugged Aravalli range, he wages a relentless guerrilla war of raids and ambushes, denying the enemy any decisive victory.',
      svg_stack('Refusing the pitched battle', [
          {'n': 1, 'label': 'Mughals hold the towns', 'sub': 'Gogunda, Udaipur and Kumbhalgarh fall', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Pratap takes to the Aravallis', 'sub': 'refusing to meet the enemy head-on', 'color': '#3730a3'},
          {'n': 3, 'label': 'A war of raids and ambushes', 'sub': 'strike, withdraw, and vanish into the hills', 'color': '#b45309'},
      ], takeaway='Denied a decisive battle, he made the mountains his weapon — a guerrilla war the empire could not win outright.', accent=AC),
      bg='Following Haldighati, Mughal commanders such as Shahbaz Khan overran Mewar’s strongholds through the late 1570s.',
      people='the Mughal generals occupying Mewar; the <b>Bhil</b> hillmen; Pratap, leading the resistance.',
      what='Unable to hold the towns, Pratap adopted <b>guerrilla warfare</b> from the Aravalli hills — raiding Mughal outposts and supply lines, avoiding pitched battle, and keeping the resistance alive when open war was hopeless.',
      crux='He changed the <b>nature of the war</b> — trading territory for time and turning geography into his ally.',
      conseq='The Mughals could occupy Mewar’s towns but never pacify its hills or catch its Rana.',
      matters='The weak wage war on their own terms — Pratap’s guerrilla methods let a small force defy an empire for years.'),

    E('grass', '1578–1579', 'The bread of grass', ['LEGEND', 'HARDSHIP'],
      'These are the years of deepest hardship — Pratap and his family hunted and homeless in the wilds, their supplies exhausted. From this time comes Mewar’s most famous legend: that Pratap would sooner eat bread made of grass than submit to Akbar for the sake of comfort.',
      svg_row('Hardship and resolve', [
          {'n': 1, 'label': 'Years of hardship', 'sub': 'hunted and homeless in the wilderness', 'color': '#78350f'},
          {'n': 2, 'label': 'The bread of grass', 'sub': 'sooner grass-bread than submission (legend)', 'color': '#a16207'},
          {'n': 3, 'label': 'Resolve renewed', 'sub': 'a low point overcome, the fight goes on', 'color': '#b45309'},
      ], edge_labels=['brings', 'yet'], takeaway='The grass-bread story, legendary or not, captures the truth of these years — extreme hardship met with unbroken will.', accent=AC),
      bg='Pushed into the wild, Pratap endured extreme privation, and popular tradition dwells on this period of suffering.',
      people='Pratap and his family in the wilderness; the loyal followers who shared their hardship.',
      what='In the hardest years Pratap and his family lived as fugitives in the hills; the celebrated legend that he would <b>eat bread of grass rather than submit</b> belongs to this period, dramatising his refusal to trade honour for comfort.',
      crux='The story’s power lies in the <b>choice it dramatises</b> — starvation with freedom over plenty with submission.',
      conseq='At his lowest, Pratap was on the verge of giving up — until fresh support let him fight on.',
      matters='Legend distils character — whether literally true or not, the grass-bread tale expresses the core of his defiance.'),

    E('bhamashah', '1578', 'The Bhils and Bhamashah’s gift', ['REFORM', 'TURNING POINT'],
      'Two sources sustain the resistance when it is nearest collapse: the loyal Bhil tribes of the Aravallis, who fight and scout for their Rana, and — by tradition — his minister Bhamashah, who donates his personal fortune to refinance Pratap’s army for years of renewed war.',
      svg_row('Rescued by loyalty and gold', [
          {'n': 1, 'label': 'The Bhil tribes stand by him', 'sub': 'hillmen and archers of the Aravallis', 'color': '#166534'},
          {'n': 2, 'label': 'Bhamashah’s treasure', 'sub': 'his minister gives a fortune (tradition)', 'color': '#a16207'},
          {'n': 3, 'label': 'The war reborn', 'sub': 'enough to fund the army for years', 'color': '#b45309'},
      ], edge_labels=['plus', 'yields'], takeaway='Loyalty from the poorest tribes and gold from a faithful minister together kept the cause alive.', accent=AC),
      bg='Pratap’s resistance depended on the <b>Bhil</b> people of the hills and on the loyalty of his own ministers.',
      people='the <b>Bhil</b> tribes of the Aravallis; the minister <b>Bhamashah</b>; Pratap, refinancing his struggle.',
      what='The <b>Bhil tribes</b> served Pratap as scouts and archers in the hills, while — by tradition — his minister <b>Bhamashah</b> donated his wealth to <b>re-equip and pay the army</b>, reviving the war when it was near collapse.',
      crux='His power rested not on great vassals but on <b>tribal loyalty and one man’s generosity</b> — a resistance from below.',
      conseq='Refinanced and resupplied, Pratap was able to go back on the offensive as Mughal pressure eased.',
      matters='Resistance runs on loyalty and money — Pratap’s cause survived because both the Bhils and Bhamashah gave freely.'),
]

# ==================================================================  PHASE 5 — RECONQUEST
PHASE_RECONQUEST = [
    E('recovery', '1585–1597', 'The reconquest of Mewar', ['TRIUMPH', 'BATTLE'],
      'From the mid-1580s, Akbar’s attention is pulled to revolts in the north-west, and pressure on Mewar relaxes. Pratap seizes the moment, going on the offensive to recapture some thirty-six Mughal outposts and, with them, most of his lost kingdom — Kumbhalgarh, Udaipur and the western hills all return to his hands.',
      svg_row('The tide turns back', [
          {'n': 1, 'label': 'Mughal pressure eases', 'sub': 'revolts pull Akbar’s armies away after 1579', 'color': '#3730a3'},
          {'n': 2, 'label': 'Pratap counterattacks', 'sub': 'retakes some 36 Mughal outposts', 'color': '#b45309'},
          {'n': 3, 'label': 'Most of Mewar regained', 'sub': 'Kumbhalgarh, Udaipur and the hills recovered', 'color': '#166534'},
      ], edge_labels=['lets', 'and'], takeaway='Patience paid: as the empire looked elsewhere, Pratap clawed back nearly all of his kingdom.', accent=AC),
      bg='After 1579 rebellions in Bengal and Bihar, and Akbar’s move to Lahore in 1585, drew Mughal forces away from Mewar.',
      people='<b>Akbar</b>, distracted by revolts elsewhere; the Mughal garrisons Pratap overran; Pratap, on the offensive.',
      what='With Mughal pressure relaxed, Pratap <b>recaptured about thirty-six outposts</b> and most of Mewar in his later years, including <b>Kumbhalgarh and Udaipur</b> and much of the western territory lost after Haldighati.',
      crux='His long patience was <b>vindicated</b> — endurance, not a single battle, won back the kingdom.',
      conseq='By the 1590s Pratap ruled again over most of Mewar, though not its symbolic heart.',
      matters='Attrition can defeat a giant — Pratap outlasted the empire’s attention and recovered by persistence what he lost in battle.'),

    E('chavand', '1585', 'A new capital — but not Chittor', ['REFORM', 'TRAGEDY'],
      'Pratap makes Chavand his capital, and in his recovered kingdom a court of poets and painters revives, giving its name to a school of art. Yet one prize eludes him to the end: Chittor, Mewar’s great fortress, remains in Mughal hands, its recovery a dream he cannot fulfil.',
      svg_stack('Restored, but incomplete', [
          {'n': 1, 'label': 'Chavand becomes the capital', 'sub': 'a court of poets and painters revives', 'color': '#b45309'},
          {'n': 2, 'label': 'Most of Mewar restored', 'sub': 'Udaipur, Gogunda and Kumbhalgarh held', 'color': '#166534'},
          {'n': 3, 'label': 'Chittor beyond his reach', 'sub': 'the great fort is never recovered', 'color': '#b91c1c'},
      ], takeaway='He rebuilt a kingdom and its culture — but the fort that symbolised Mewar stayed forever out of his grasp.', accent=AC),
      bg='In his last years Pratap ruled a largely restored Mewar from his new capital at <b>Chavand</b>.',
      people='the poets, painters and artisans of the <b>Chavand</b> court; Pratap, patron and ruler; the still-Mughal garrison of Chittor.',
      what='Pratap established his capital at <b>Chavand</b>, where a revival of art and letters flourished; he had recovered most of Mewar, but <b>Chittor itself remained in Mughal hands</b> and beyond his power to retake.',
      crux='His triumph was <b>real but unfinished</b> — the kingdom largely regained, its symbolic fortress still lost.',
      conseq='The dream of recovering Chittor passed, unfulfilled, to his heirs.',
      matters='Even great recoveries can fall short — Pratap won back nearly everything except the one place that meant the most.'),

    E('death', '1597', 'Death and the unbroken vow', ['DEATH', 'HONOUR'],
      'Pratap dies at Chavand in 1597, at about fifty-six, from injuries said to have come from a hunting accident. On his deathbed he charges his son Amar Singh never to submit to the Mughals and to reclaim Chittor — passing on the defiance that would make him an enduring symbol of honour and freedom.',
      svg_stack('The vow passed on', [
          {'n': 1, 'label': 'Dies at Chavand, 1597', 'sub': 'from a hunting injury, aged about 56', 'color': '#78350f'},
          {'n': 2, 'label': 'The deathbed charge', 'sub': 'bids Amar Singh never submit, reclaim Chittor', 'color': '#3730a3'},
          {'n': 3, 'label': 'An enduring symbol', 'sub': 'of defiance, honour and freedom', 'color': '#b45309'},
      ], takeaway='He died as he had lived — unsubmitting — and handed his resistance, like an inheritance, to his son.', accent=AC),
      bg='Pratap died on 19 January 1597 at his capital of <b>Chavand</b>, reportedly of injuries from a hunting accident.',
      people='<b>Amar Singh I</b>, his son and heir; the Mewar court; later generations who made him a national symbol.',
      what='Pratap <b>died in 1597</b> having recovered most of Mewar; on his deathbed he charged his son <b>Amar Singh I</b> to never submit to the Mughals and to keep striving to reclaim Chittor.',
      crux='He was <b>unbeaten in spirit to the end</b>, converting his own struggle into a duty for his line.',
      conseq='Amar Singh continued the resistance, though Mewar eventually reached terms with the Mughals in 1615.',
      matters='A cause outlives the man — Pratap became, and remains, an enduring symbol of defiance, honour and independence.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Maharana Pratap was the Sisodia Rajput ruler of Mewar who refused to submit to the Mughal emperor Akbar when nearly every other Rajput king had made his peace with the empire. Defeated but not captured at the Battle of Haldighati in 1576, he took to the Aravalli hills and waged years of guerrilla war and endured extreme hardship rather than bow — sustained by the loyalty of the Bhil tribes and the wealth of his minister Bhamashah. In his last years he reconquered most of Mewar, though never its great fortress of Chittor, and died unsubmitting in 1597. He is the enduring Indian symbol of <b>defiance, honour and the refusal to surrender freedom.</b></p>
<div class="ov-quote">He would sooner eat bread of grass than bow to the emperor.<span>— the enduring legend of his defiance</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born a Sisodia heir as Akbar sacks Chittor → crowned Rana of a shrunken Mewar → refuses to submit when other Rajputs ally with the emperor → fights Man Singh at Haldighati and escapes → wages guerrilla war from the Aravallis through years of hardship → is kept alive by the Bhils and Bhamashah’s gold → reconquers most of Mewar but never Chittor → and dies defiant in 1597, his vow passed to his son.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🛡️</div><h4>The lone holdout</h4><p>Refused Akbar when almost every other Rajput king submitted.</p></div>
  <div class="ov-card"><div class="i">🐎</div><h4>Haldighati &amp; Chetak</h4><p>Lost the field in 1576 but escaped to fight another day.</p></div>
  <div class="ov-card"><div class="i">🏔️</div><h4>The guerrilla war</h4><p>Turned the Aravalli hills into a weapon against an empire.</p></div>
  <div class="ov-card"><div class="i">🔥</div><h4>Defiance and honour</h4><p>An enduring symbol of freedom over comfort or survival.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Rise</b><small> 1540–1572</small><p>A Sisodia heir; Chittor falls; crowned Rana.</p></div>
  <div><b>2 · Defiance</b><small> 1572–1576</small><p>Alone among Rajputs, he refuses Akbar.</p></div>
  <div><b>3 · Haldighati</b><small> 1576</small><p>The battle, Chetak, and the escape.</p></div>
  <div><b>4 · The Wilderness</b><small> 1576–1585</small><p>Guerrilla war, hardship, Bhils and Bhamashah.</p></div>
  <div><b>5 · Reconquest</b><small> 1585–1597</small><p>Most of Mewar regained; death, undefeated in spirit.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references. Where the record is thin, this guide marks <b>legend</b> as legend.</p>
"""

WHO = [
    {'name': 'Akbar', 'role': 'the Mughal emperor', 'color': '#b91c1c',
     'bio': 'The great Mughal emperor who had absorbed the other Rajput states and sought, by diplomacy then war, to bring Mewar under his suzerainty.',
     'rel': 'The adversary Pratap refused to submit to for his entire reign.'},
    {'name': 'Raja Man Singh I', 'role': 'Mughal commander', 'color': '#a16207',
     'bio': 'The Rajput ruler of Amber, now a leading Mughal general, who led Akbar’s army against Pratap at Haldighati — Rajput fighting Rajput.',
     'rel': 'The Rajput-in-Mughal-service who commanded against him at Haldighati.'},
    {'name': 'Udai Singh II', 'role': 'his father', 'color': '#3730a3',
     'bio': 'The Rana of Mewar who founded Udaipur and withdrew from Chittor before its fall; his death in 1572 brought Pratap to the throne.',
     'rel': 'The father whose besieged kingdom Pratap inherited.'},
    {'name': 'Bhamashah', 'role': 'his minister', 'color': '#166534',
     'bio': 'Pratap’s loyal minister who, by tradition, donated his personal fortune to refinance and re-equip the army when the resistance was near collapse.',
     'rel': 'The minister whose wealth, in tradition, revived the fight.'},
    {'name': 'Chetak', 'role': 'his warhorse', 'color': '#b45309',
     'bio': 'Pratap’s celebrated horse, remembered in tradition for carrying the wounded Rana clear of the enemy at Haldighati before dying of its wounds.',
     'rel': 'The legendary steed of Haldighati, honoured in Mewar memory.'},
]

KEY_EVENTS = [
    ('1540', 'Pratap born', 'At Kumbhalgarh, heir of the Sisodia house.'),
    ('1568', 'Sack of Chittor', 'Akbar takes Mewar’s great fortress.'),
    ('1572', 'Crowned Rana', 'The nobles choose Pratap at Gogunda.'),
    ('1573', 'Envoys refused', 'Four Mughal missions come back empty.'),
    ('1576', 'Battle of Haldighati', 'Defeated by Man Singh, but escapes.'),
    ('1576–79', 'Guerrilla war', 'Resistance from the Aravalli hills.'),
    ('1578', 'Bhamashah’s gift', 'Wealth refinances the army (tradition).'),
    ('1585–97', 'Reconquest of Mewar', 'Retakes most of the kingdom, not Chittor.'),
    ('1597', 'Death at Chavand', 'Dies defiant; vow passed to Amar Singh.'),
]

MASTER = [
    {'year': '1540', 'age': 'born', 'phase': 'The Rise', 'title': 'Born at Kumbhalgarh', 'desc': 'Heir of the Sisodia house.'},
    {'year': '1572', 'age': 'age 32', 'phase': 'Defiance', 'title': 'Crowned Rana', 'desc': 'Takes a shrunken Mewar.'},
    {'year': '1576', 'age': 'age 36', 'phase': 'Haldighati', 'title': 'Battle of Haldighati', 'desc': 'Defeated but not captured.'},
    {'year': '1578', 'age': 'age 38', 'phase': 'The Wilderness', 'title': 'Bhamashah’s gift', 'desc': 'The war refinanced.'},
    {'year': '1585', 'age': 'age 45', 'phase': 'Reconquest', 'title': 'Recovery begins', 'desc': 'Most of Mewar regained.'},
    {'year': '1597', 'age': 'age 56', 'phase': 'Reconquest', 'title': 'Death at Chavand', 'desc': 'Undefeated in spirit.'},
]

SOURCES = [
    ('Britannica — Pratap Singh (Rana of Mewar)', 'https://www.britannica.com/biography/Pratap-Singh'),
    ('Wikipedia — Maharana Pratap', 'https://en.wikipedia.org/wiki/Maharana_Pratap'),
    ('Wikipedia — Battle of Haldighati', 'https://en.wikipedia.org/wiki/Battle_of_Haldighati'),
    ('Britannica — Akbar', 'https://www.britannica.com/biography/Akbar'),
    ('Wikipedia — Chetak', 'https://en.wikipedia.org/wiki/Chetak'),
]

def build_meta():
    return {
        'pid': 'gm-maharanapratap.html', 'kind': 'man', 'emoji': '🐎', 'accent': AC,
        'name': 'Maharana Pratap', 'years': '1540–1597', 'group': 'Indian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Sisodia Rajput ruler of Mewar who refused to submit to Akbar — hero of Haldighati and of a long guerrilla resistance from the Aravalli hills, an enduring Indian symbol of defiance and honour.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Rise', 'type': 'timeline',
             'intro': 'Born a Sisodia heir as Akbar sacks Chittor, Pratap is crowned Rana of a Mewar already cut down and hemmed in by the Mughals.', 'events': PHASE_RISE},
            {'id': 'defiance', 'label': '2 · Defiance', 'type': 'timeline',
             'intro': 'As the other Rajput houses make their peace with Akbar, Pratap stands almost alone in refusing — turning away four embassies and choosing honour over submission.', 'events': PHASE_DEFIANCE},
            {'id': 'haldighati', 'label': '3 · Haldighati', 'type': 'timeline',
             'intro': 'Akbar sends an army under Man Singh; at the pass of Haldighati Pratap is defeated but escapes — through the sacrifice of his horse Chetak and a loyal chief.', 'events': PHASE_HALDIGHATI},
            {'id': 'wilderness', 'label': '4 · The Wilderness', 'type': 'timeline',
             'intro': 'Refusing pitched battle, Pratap wages guerrilla war from the Aravallis through years of hardship — kept alive by the loyal Bhil tribes and the wealth of Bhamashah.', 'events': PHASE_WILDERNESS},
            {'id': 'reconquest', 'label': '5 · Reconquest', 'type': 'timeline',
             'intro': 'As Mughal pressure eases, Pratap reconquers most of Mewar — though never Chittor — and dies at Chavand in 1597, undefeated in spirit, his vow passed to his son.', 'events': PHASE_RECONQUEST,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; famous episodes — Chetak, the bread of grass, Bhamashah’s donation — are traditional accounts and are noted as legend rather than firm record.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
