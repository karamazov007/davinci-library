# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Rabindranath Tagore.
The Bengali polymath — poet, composer, painter and sage — who won the Nobel Prize, built Santiniketan, and gave two nations their anthems."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b45309'  # ochre-gold of the poet-sage

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — ROOTS AT JORASANKO
PHASE_ROOTS = [
    E('origins', '1861', 'Born into the Tagore house of Jorasanko', ['RISE', 'ORIGINS'],
      'Rabindranath Tagore is born on 7 May 1861 in the sprawling Jorasanko mansion in Calcutta, the fourteenth child of Debendranath Tagore — a family at the very centre of the Bengal Renaissance, wealthy, reformist, and steeped in art, music, philosophy and the Brahmo faith.',
      svg_row('A child of the Bengal Renaissance', [
          {'n': 1, 'label': 'Born at Jorasanko, 1861', 'sub': 'youngest son in a vast Calcutta mansion', 'color': '#b45309'},
          {'n': 2, 'label': 'The Tagore family', 'sub': 'reformist, wealthy, Brahmo, deeply cultured', 'color': '#3730a3'},
          {'n': 3, 'label': 'Art as the family air', 'sub': 'music, theatre and philosophy fill the house', 'color': '#166534'},
      ], edge_labels=['into', 'so'], takeaway='He was born into the leading cultural family of Bengal — genius had a nursery ready-made.', accent=AC),
      bg='<b>Rabindranath Tagore</b> was born on <b>7 May 1861</b> at the Jorasanko mansion in Calcutta, the youngest of many children of the reformer and Brahmo leader <b>Debendranath Tagore</b> (1817–1905).',
      people='his father <b>Debendranath Tagore</b>, a leader of the Brahmo Samaj; his mother <b>Sarada Devi</b>; and the many artistically gifted Tagore siblings around him.',
      what='He grew up inside the <b>Jorasanko house</b>, a hub of the Bengal Renaissance where poetry, music, drama and religious reform were part of daily life — but the boy was restless with formal schooling and largely educated at home.',
      crux='His genius was <b>cultivated, not accidental</b> — a household of artists and reformers gave him every tool and freedom.',
      conseq='He absorbed music, verse and a questioning Brahmo spirituality that would shape every later work.',
      matters='Environment can be destiny — the Tagore house handed Rabindranath a language, a faith and an art before he had to seek them.'),

    E('bhanusimha', '1875–1878', 'The boy poet and “Bhanusimha”', ['RISE', 'IDEAS'],
      'A prodigy, Tagore writes verse from childhood and at sixteen publishes poems under the pen name "Bhanusimha" (Sun Lion) — imitations of old Vaishnava lyrics so convincing that literary authorities mistake them for long-lost classics — announcing a talent that would soon dominate Bengali letters.',
      svg_stack('A prodigy announces himself', [
          {'n': 1, 'label': 'Writing verse as a child', 'sub': 'poetry pours out before he is grown', 'color': '#166534'},
          {'n': 2, 'label': 'Poems as “Bhanusimha”, c.1877', 'sub': 'the pen name means “Sun Lion”', 'color': '#b45309'},
          {'n': 3, 'label': 'Mistaken for lost classics', 'sub': 'scholars take the fakes for old masters', 'color': '#3730a3'},
      ], takeaway='He arrived fully formed — a teenager whose imitations fooled the experts marked a rare, precocious gift.', accent=AC),
      bg='Tagore showed poetic gifts very young and began publishing while still a boy, resisting formal classrooms in favour of writing and self-directed study.',
      people='his elder brothers and sister-in-law <b>Kadambari Devi</b>, who nurtured his early art; the Bengali literary world he was entering.',
      what='At about sixteen he published poems under the pseudonym <b>“Bhanusimha”</b>, Vaishnava-style lyrics so accomplished that some <b>critics took them for genuine antique verse</b>; he was soon writing stories and drama under his own name.',
      crux='The hoax proved his <b>mastery of tradition</b> — he could inhabit the old forms perfectly before breaking them open.',
      conseq='By his late teens he was a recognised young voice in Bengali literature.',
      matters='True originality often begins in imitation — Tagore learned the whole tradition so well he could later remake it.'),

    E('marriage', '1878–1883', 'England, marriage, and a new voice', ['RISE', 'LOVE'],
      'Sent to England in 1878 to study law, Tagore returns without a degree but full of Western literature and music; in 1883 he marries Mrinalini Devi and, through the 1880s, publishes the poetry of "Manasi" — the collection in which his mature, original voice first fully emerges.',
      svg_row('Finding his own voice', [
          {'n': 1, 'label': 'To England, 1878', 'sub': 'studies law, absorbs Western art, no degree', 'color': '#3730a3'},
          {'n': 2, 'label': 'Marries Mrinalini Devi, 1883', 'sub': 'settles into family and prolific writing', 'color': '#db2777'},
          {'n': 3, 'label': '“Manasi” and maturity', 'sub': 'his original poetic voice fully emerges', 'color': '#b45309'},
      ], edge_labels=['then', 'and'], takeaway='He fused East and West into something new — a voice at once rooted in Bengal and open to the world.', accent=AC),
      bg='In <b>1878</b> Tagore travelled to England intending to study law and become a barrister, but left without completing a degree, having steeped himself in English literature and European music.',
      people='<b>Mrinalini Devi</b>, whom he married in 1883; the English writers and composers whose work he encountered abroad.',
      what='He returned to Bengal, <b>married Mrinalini Devi in 1883</b>, and through the 1880s produced increasingly original work — the collection <b>“Manasi” (1890)</b> marking the arrival of his mature poetic voice.',
      crux='He absorbed the West without being colonised by it, <b>blending European form with Bengali sensibility</b>.',
      conseq='He entered the 1890s as an established writer, ready for the great creative decade ahead.',
      matters='A wide window on the world sharpened rather than erased his roots — the mark of a truly synthesising mind.'),
]

# ==================================================================  PHASE 2 — THE PADMA YEARS
PHASE_PADMA = [
    E('shelaidaha', '1890', 'Manager of the estates at Shelaidaha', ['RISE', 'REFORM'],
      'In 1890 Tagore is sent to manage the family’s ancestral estates at Shelaidaha in East Bengal — and the poet of the drawing room becomes a man among peasants and rivers, living for long stretches on a houseboat on the Padma, an immersion in rural life that transforms his art.',
      svg_stack('From drawing room to riverbank', [
          {'n': 1, 'label': 'Sent to Shelaidaha, 1890', 'sub': 'manages the family estates in East Bengal', 'color': '#3730a3'},
          {'n': 2, 'label': 'Life on the Padma river', 'sub': 'long spells on the family houseboat', 'color': '#0891b2'},
          {'n': 3, 'label': 'Among the peasants', 'sub': 'daily contact with rural Bengal’s poor', 'color': '#b45309'},
      ], takeaway='The riverine years grounded the poet in real village life — landscape and peasant became his great subjects.', accent=AC),
      bg='From <b>1890</b> Tagore took charge of the Tagore family’s ancestral lands at <b>Shelaidaha</b> (in present-day Bangladesh), managing tenants and revenue.',
      people='the peasants and tenants of the estates; the boatmen of the Padma; the villagers whose lives now filled his notebooks.',
      what='He spent long periods travelling the <b>Padma River by family barge</b>, living close to the rhythms of rural Bengal — an immersion that fed both his social conscience and a great outpouring of writing.',
      crux='Direct contact with <b>ordinary rural life</b> gave his art a new realism, tenderness and moral weight.',
      conseq='The Shelaidaha years produced some of his finest poetry and the bulk of his celebrated short stories.',
      matters='Great art often needs the world outside the study — the river years turned a gifted poet into a chronicler of a whole society.'),

    E('stories', '1891–1901', 'The master of the Bengali short story', ['TRIUMPH', 'IDEAS'],
      'From the Padma years pours a flood of short fiction — the stories gathered in "Galpaguchchha" — in which Tagore all but invents the modern Bengali short story, drawing unforgettable portraits of village life, women’s inner worlds, and the quiet cruelties of custom and poverty.',
      svg_row('Inventing a form', [
          {'n': 1, 'label': 'Stories from the estates', 'sub': 'village lives observed at close range', 'color': '#0891b2'},
          {'n': 2, 'label': '“Galpaguchchha” collection', 'sub': 'the modern Bengali short story is born', 'color': '#b45309'},
          {'n': 3, 'label': 'The overlooked made visible', 'sub': 'women, peasants and the poor at the centre', 'color': '#166534'},
      ], edge_labels=['become', 'so'], takeaway='He gave Bengali prose a new form and a new conscience — small lives rendered with piercing sympathy.', accent=AC),
      bg='During and after the Shelaidaha years Tagore wrote prolifically in prose, drawing directly on the rural world around him.',
      people='the village characters he drew from life; the readers of Bengali magazines who devoured his tales; later translators who carried them abroad.',
      what='He wrote scores of short stories, later gathered as <b>“Galpaguchchha”</b>, effectively <b>founding the modern Bengali short story</b> and filling it with the lives of women, peasants and the poor.',
      crux='He proved that <b>the humblest lives could carry high art</b> — dignity and tragedy found in ordinary Bengal.',
      conseq='These stories remain classics of Indian literature and shaped generations of writers and film-makers.',
      matters='A form can be a gift to a culture — Tagore handed Bengali literature a modern short story it did not have before.'),

    E('santiniketan', '1901', 'Founding the school at Santiniketan', ['REFORM', 'RISE'],
      'In 1901 Tagore, who had hated his own schooling, founds an experimental school at Santiniketan — an ashram where children learn in the open air, under trees, close to nature and the arts rather than by rote — the seed that would one day grow into a university.',
      svg_stack('A school under the trees', [
          {'n': 1, 'label': 'Santiniketan ashram, 1901', 'sub': 'an experimental school in rural Bengal', 'color': '#166534'},
          {'n': 2, 'label': 'Learning in the open air', 'sub': 'lessons under trees, close to nature', 'color': '#0891b2'},
          {'n': 3, 'label': 'The arts over rote', 'sub': 'music, drama and freedom, not the cane', 'color': '#b45309'},
      ], takeaway='He built the school he had wished for as a boy — an education of freedom, nature and art.', accent=AC),
      bg='Tagore had loathed the rigid, rote-based schooling of his own childhood and long dreamed of a freer kind of education.',
      people='his father Debendranath, on whose Santiniketan land the school arose; the first handful of pupils and teachers; his family, who helped fund it.',
      what='In <b>1901</b> he founded a <b>Brahmacharya ashram school at Santiniketan</b> (“Abode of Peace”), where a small band of children were taught <b>in the open air, close to nature</b>, with the arts and personal mentorship at the centre.',
      crux='He believed education should <b>free and awaken the child</b>, not cram and cow it — nature and creativity over discipline and exams.',
      conseq='The school became his life’s practical passion and the nucleus of Visva-Bharati University two decades later.',
      matters='He put his ideals into brick and tree — a working experiment in humane education that still endures.'),
]

# ==================================================================  PHASE 3 — GITANJALI AND THE WORLD
PHASE_GITANJALI = [
    E('losses', '1902–1907', 'Years of sorrow', ['TRAGEDY', 'LOVE'],
      'Between 1902 and 1907 death comes again and again — Tagore loses his wife Mrinalini, a daughter, his father, and a young son — a cascade of bereavement that deepens the spiritual, elegiac note that would soon flower in the devotional songs of Gitanjali.',
      svg_row('Grief that deepened the song', [
          {'n': 1, 'label': 'Wife Mrinalini dies, 1902', 'sub': 'the first of a wave of losses', 'color': '#9f1239'},
          {'n': 2, 'label': 'Daughter, father, son', 'sub': 'repeated bereavement, 1902–1907', 'color': '#78350f'},
          {'n': 3, 'label': 'A deeper, spiritual voice', 'sub': 'sorrow turns his verse toward the divine', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='Personal loss darkened and deepened his art — grief became the ground of his most spiritual poetry.', accent=AC),
      bg='In the early 1900s Tagore suffered a series of family deaths in quick succession, even as he poured himself into the Santiniketan school.',
      people='his wife <b>Mrinalini Devi</b> (d. 1902); his daughter Renuka; his father <b>Debendranath</b> (d. 1905); and his son Samindranath.',
      what='He lost his <b>wife in 1902</b>, a daughter soon after, his <b>father in 1905</b>, and a young son in 1907 — a cascade of grief that turned his poetry toward <b>mortality, longing and the divine</b>.',
      crux='Sorrow refined rather than silenced him, giving his devotional verse its <b>aching, intimate spirituality</b>.',
      conseq='Out of these years came the Bengali songs that he would gather as <b>Gitanjali</b>.',
      matters='Suffering can be transmuted into art — Tagore’s losses fed the very poems that would conquer the world.'),

    E('gitanjali', '1910', 'Gitanjali — the song offerings', ['TRIUMPH', 'IDEAS'],
      'In 1910 Tagore publishes "Gitanjali" (Song Offerings) in Bengali — a collection of intensely devotional lyrics addressed to a personal, indwelling God — the work that, more than any other, would carry his name across the world.',
      svg_stack('A garland of devotional song', [
          {'n': 1, 'label': '“Gitanjali” in Bengali, 1910', 'sub': 'the title means “song offerings”', 'color': '#b45309'},
          {'n': 2, 'label': 'Devotion made intimate', 'sub': 'lyrics to a personal, indwelling divine', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Song, not sermon', 'sub': 'many were composed to be sung', 'color': '#166534'},
      ], takeaway='He turned private devotion into universal song — mystical, tender verse that would soon travel far beyond Bengal.', accent=AC),
      bg='By 1910 Tagore was the foremost poet of Bengal, his art deepened by years of loss and spiritual searching.',
      people='the Bengali readers and singers who first received the poems; the divine “Lord of my life” to whom the lyrics are addressed.',
      what='He published <b>“Gitanjali” (Song Offerings)</b> in Bengali in 1910 — a gathering of <b>devotional lyrics</b>, many meant to be sung, expressing a direct, personal relationship with the divine.',
      crux='Its power lay in <b>simplicity and intimacy</b> — vast spiritual longing spoken in plain, singing words.',
      conseq='Two years later Tagore himself rendered a selection into English, opening the door to worldwide fame.',
      matters='Some books change a life’s direction — Gitanjali would take a Bengali poet to a global stage.'),

    E('songofferings', '1912', 'The English Gitanjali and W.B. Yeats', ['TRIUMPH', 'TURNING POINT'],
      'In 1912 Tagore travels to London and shares his own English prose translations of Gitanjali with William Butler Yeats and Ezra Pound — Yeats is enraptured, writes a glowing introduction, and the slim English "Gitanjali" bursts upon literary London as a revelation.',
      svg_row('Bengal meets literary London', [
          {'n': 1, 'label': 'English Gitanjali, 1912', 'sub': 'Tagore’s own prose translations', 'color': '#b45309'},
          {'n': 2, 'label': 'Yeats and Pound enthralled', 'sub': 'Yeats writes a rapturous introduction', 'color': '#3730a3'},
          {'n': 3, 'label': 'A literary sensation', 'sub': 'London hails a new spiritual voice', 'color': '#7c3aed'},
      ], edge_labels=['shown to', 'so'], takeaway='A chance London encounter lit the fuse — Yeats’s praise turned an unknown Bengali into the talk of the West.', accent=AC),
      bg='On a 1912 voyage to England, Tagore carried notebooks of his own English renderings of the Gitanjali poems.',
      people='the Irish poet <b>W.B. Yeats</b>, who championed the book; <b>Ezra Pound</b>; the London literary circles that took him up.',
      what='He shared the translations with <b>Yeats and Ezra Pound</b>; Yeats was so moved he wrote an <b>ecstatic introduction</b>, and the English <b>“Gitanjali” (1912)</b> was published by the India Society to acclaim.',
      crux='Yeats’s endorsement gave Tagore <b>instant standing in the West</b> — a passport into the heart of English letters.',
      conseq='The book’s sensation set the stage directly for the Nobel Prize the following year.',
      matters='The right champion at the right moment can change a career — Yeats opened the West’s ear to Tagore.'),
]

# ==================================================================  PHASE 4 — NOBEL, KNIGHTHOOD, DEFIANCE
PHASE_NOBEL = [
    E('nobel', '1913', 'The Nobel Prize in Literature', ['TRIUMPH', 'TURNING POINT'],
      'In November 1913 the Swedish Academy awards Rabindranath Tagore the Nobel Prize in Literature, largely for Gitanjali — making him the first non-European, and the first Asian, ever to win a Nobel Prize, and turning a Bengali poet into a world figure overnight.',
      svg_stack('A first for Asia', [
          {'n': 1, 'label': 'Nobel Prize, November 1913', 'sub': 'awarded largely for Gitanjali', 'color': '#7c3aed'},
          {'n': 2, 'label': 'First non-European laureate', 'sub': 'the first Asian to win any Nobel', 'color': '#b45309'},
          {'n': 3, 'label': 'A world figure overnight', 'sub': 'Bengal’s poet becomes a global name', 'color': '#166534'},
      ], takeaway='The prize shattered a colour line — the East claimed a place at the summit of world literature.', accent=AC),
      bg='The English Gitanjali had made Tagore a literary sensation across Europe within a year of its publication.',
      people='the <b>Swedish Academy</b> that made the award; W.B. Yeats and the Western admirers who had promoted him; the Indians who now claimed him with pride.',
      what='In <b>November 1913</b> Tagore won the <b>Nobel Prize in Literature</b>, cited for his “profoundly sensitive, fresh and beautiful verse” — the <b>first non-European and first Asian Nobel laureate</b> in any field.',
      crux='The award was a <b>symbolic breakthrough</b> — recognition that great literature could rise from a colonised Asia.',
      conseq='Tagore became a global celebrity and, for many, the very face of Indian culture to the world.',
      matters='One prize can rearrange a hierarchy — Tagore’s Nobel told the world that genius wore no single skin.'),

    E('knighthood', '1915', 'Knighted by the Crown', ['POLITICS', 'RISE'],
      'In 1915 the British Crown knights Rabindranath Tagore, then at the height of his world fame — an honour that binds the poet, however uneasily, to the imperial establishment, and one he will dramatically cast off just four years later.',
      svg_row('An honour soon to be returned', [
          {'n': 1, 'label': 'Knighted by the Crown, 1915', 'sub': 'the Empire honours its famous poet', 'color': '#3730a3'},
          {'n': 2, 'label': 'At the height of fame', 'sub': 'the Nobel laureate courted by Britain', 'color': '#b45309'},
          {'n': 3, 'label': 'A tie he would cut', 'sub': 'the knighthood lasts just four years', 'color': '#9f1239'},
      ], edge_labels=['while', 'yet'], takeaway='The Empire drew him close with a title — a bond he would soon break in protest.', accent=AC),
      bg='By 1915 Tagore was the most celebrated Indian in the world, and the British authorities were keen to associate themselves with him.',
      people='the British Crown and Raj administration; the Indian public watching how their laureate related to the rulers.',
      what='In <b>1915</b> Tagore was <b>awarded a knighthood</b> by the British Crown — a mark of the highest imperial esteem for the Nobel-winning poet.',
      crux='The title placed him in an <b>uneasy proximity to the Raj</b> he was increasingly to criticise.',
      conseq='It set up the far more famous gesture of 1919, when he would renounce it in outrage.',
      matters='Honours can become liabilities — the knighthood mattered most for the moment Tagore chose to give it back.'),

    E('jallianwala', '1919', 'Renouncing the knighthood', ['TRAGEDY', 'TURNING POINT'],
      'When British troops massacre hundreds of unarmed Indians at Jallianwala Bagh in Amritsar in April 1919, Tagore is stricken — and in a searing letter to the Viceroy he renounces his knighthood, refusing to wear "badges of honour" amid his people’s humiliation, in one of the great moral gestures of the freedom struggle.',
      svg_stack('The poet answers a massacre', [
          {'n': 1, 'label': 'Jallianwala Bagh, April 1919', 'sub': 'troops fire on an unarmed crowd', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Tagore renounces his knighthood', 'sub': 'a searing public letter to the Viceroy', 'color': '#b45309'},
          {'n': 3, 'label': '“Badges of honour” cast off', 'sub': 'he will not be honoured amid shame', 'color': '#9f1239'},
      ], takeaway='He turned his fame into a weapon of conscience — giving back the Empire’s honour to stand with the massacred.', accent=AC),
      bg='On 13 April 1919, British Indian Army troops under General <b>Reginald Dyer</b> opened fire on a peaceful gathering at <b>Jallianwala Bagh</b> in Amritsar, killing and wounding hundreds.',
      people='the massacred crowd of Amritsar; General Dyer; <b>Lord Chelmsford</b>, the Viceroy to whom Tagore addressed his protest.',
      what='Horrified, Tagore <b>renounced his knighthood</b> in a public letter to the Viceroy, writing that <b>“badges of honour make our shame glaring in their incongruous context of humiliation.”</b>',
      crux='He staked his standing with the rulers on <b>solidarity with his humiliated people</b> — moral witness over royal favour.',
      conseq='The gesture rang across India and the world, aligning the great poet with the national cause.',
      matters='A single principled renunciation can outshine a lifetime of honours — Tagore’s letter became a landmark of dignity.'),
]

# ==================================================================  PHASE 5 — THE WORLD SAGE
PHASE_SAGE = [
    E('visvabharati', '1921', 'Visva-Bharati — a university of the world', ['REFORM', 'IDEAS'],
      'In 1921 Tagore expands his Santiniketan school into Visva-Bharati University — an institution built on the motto that "the world makes a home in a single nest," dedicated to bringing together the cultures of East and West and to a humane, boundary-crossing idea of learning.',
      svg_row('Where the world nests together', [
          {'n': 1, 'label': 'Visva-Bharati founded, 1921', 'sub': 'the school grows into a university', 'color': '#166534'},
          {'n': 2, 'label': '“The world in one nest”', 'sub': 'its motto: a meeting of all cultures', 'color': '#b45309'},
          {'n': 3, 'label': 'East meets West', 'sub': 'scholars and arts drawn from everywhere', 'color': '#3730a3'},
      ], edge_labels=['becomes', 'so'], takeaway='He built a university around an idea of human unity — learning without borders of nation or creed.', accent=AC),
      bg='Two decades of the Santiniketan experiment had convinced Tagore that his educational vision deserved a fuller institution.',
      people='the international scholars and artists he drew to Santiniketan; the students of many nations; later luminaries the school would shape.',
      what='In <b>1921</b> he founded <b>Visva-Bharati University</b> at Santiniketan, taking as its ideal <b>“Yatra visvam bhavati ekanidam” — where the world makes its home in a single nest</b>, a centre for the meeting of Eastern and Western cultures.',
      crux='Learning, for Tagore, meant <b>human unity and creative freedom</b>, not narrow nationalism or rote credentialing.',
      conseq='Visva-Bharati became a renowned seat of the arts and humanities and remains a living monument to his vision.',
      matters='An idea can be institutionalised — Tagore turned a philosophy of unity into a lasting university.'),

    E('travels', '1916–1934', 'The wandering ambassador of culture', ['POLITICS', 'IDEAS'],
      'For nearly two decades Tagore circles the globe — lecturing across Europe, the Americas, East Asia and the Middle East — a tireless ambassador for Indian culture and for the unity of humanity, warning the world, even as it lionises him, against the idolatry of the nation-state.',
      svg_stack('A poet on every continent', [
          {'n': 1, 'label': 'World tours, 1916–1934', 'sub': 'Europe, the Americas, Asia and beyond', 'color': '#0891b2'},
          {'n': 2, 'label': 'Lecturing on unity', 'sub': 'India’s spirit and a shared humanity', 'color': '#b45309'},
          {'n': 3, 'label': 'Warning against nationalism', 'sub': 'he critiques the worship of the nation-state', 'color': '#3730a3'},
      ], takeaway='He carried his message to the whole world — human unity above the narrow idol of nationalism.', accent=AC),
      bg='World fame after the Nobel turned Tagore into a sought-after lecturer, and he used the platform to spread his ideas.',
      people='the vast audiences across five continents; heads of state and thinkers he met; the many admirers who hosted his tours.',
      what='Between roughly <b>1916 and 1934</b> Tagore made repeated <b>world tours</b>, lecturing on Indian culture and human unity, and delivering pointed <b>critiques of aggressive nationalism</b> even to the nations that fêted him.',
      crux='He preached a <b>universal humanism</b> — belonging to humanity above any flag — against the tide of his age.',
      conseq='He became a global moral voice, though his warnings on nationalism often ran against the political current.',
      matters='He used celebrity as a pulpit for conscience — a poet reminding a nationalist century of its shared humanity.'),

    E('gandhi', '1915–1941', 'Tagore and Gandhi — the poet and the Mahatma', ['POLITICS', 'IDEAS'],
      'Tagore and Mohandas Gandhi share deep mutual reverence — it is Tagore who helps popularise the title "Mahatma" for Gandhi, while Gandhi calls Tagore "Gurudev" — yet the two great men debate profoundly over nationalism, reason, machinery and the burning of foreign cloth, a friendship of loving disagreement.',
      svg_compare('Two visions of India’s soul', {
          'head': 'Tagore — the poet', 'color': '#b45309',
          'items': ['Universal humanism over nationalism', 'Reason, science and open inquiry', 'Freedom through creativity and education', 'Wary of mass boycotts and cloth-burning'],
      }, {
          'head': 'Gandhi — the Mahatma', 'color': '#166534',
          'items': ['Mass struggle for national swaraj', 'Faith, discipline and self-suffering', 'Freedom through non-cooperation', 'The spinning wheel and swadeshi'],
      }, verdict='They revered each other across a real divide — the poet and the Mahatma sharpened the nation by disagreeing.',
         takeaway='Their loving debate framed India’s deepest questions — humanism and reason set against mass struggle and faith.', accent=AC),
      bg='Tagore and <b>Mohandas Gandhi</b> were the two towering moral figures of modern India, bound by respect yet divided on method.',
      people='<b>Mahatma Gandhi</b>, whom Tagore addressed with reverence; the Indian public who watched their exchanges; the freedom movement each shaped.',
      what='Tagore helped make the title <b>“Mahatma” (Great Soul)</b> current for Gandhi, who in turn called him <b>“Gurudev”</b>; yet they <b>debated openly</b> over nationalism, the rejection of Western learning, and the burning of foreign cloth.',
      crux='Their bond showed that <b>deep respect and deep disagreement can coexist</b> — each thought the other partly wrong and wholly great.',
      conseq='Their dialogue became one of the defining intellectual exchanges of the freedom era.',
      matters='A civilisation argues with itself through its best minds — Tagore and Gandhi modelled reverent, honest dissent.'),

    E('einstein', '1930', 'Conversations with Einstein', ['IDEAS', 'TRIUMPH'],
      'In 1930 Tagore meets Albert Einstein near Berlin, and the two hold a now-famous dialogue on the nature of reality, truth and beauty — the physicist arguing for a truth independent of humanity, the poet for a reality bound up with human consciousness — a meeting of two of the age’s greatest minds.',
      svg_row('The poet debates the physicist', [
          {'n': 1, 'label': 'Tagore meets Einstein, 1930', 'sub': 'near Berlin, a famous recorded dialogue', 'color': '#3730a3'},
          {'n': 2, 'label': 'What is truth?', 'sub': 'reality apart from man, or bound to mind?', 'color': '#b45309'},
          {'n': 3, 'label': 'Science meets the sages', 'sub': 'physics and Indian philosophy in dialogue', 'color': '#7c3aed'},
      ], edge_labels=['on', 'so'], takeaway='Two summits of the modern mind met as equals — the physicist and the poet probing the nature of truth.', accent=AC),
      bg='By 1930 Tagore’s world tours brought him into contact with the leading minds of Europe, among them Albert Einstein.',
      people='<b>Albert Einstein</b>, the physicist; Tagore, the poet-philosopher; the interpreters who preserved their exchange.',
      what='In <b>1930</b> the two met near Berlin for a celebrated <b>conversation on reality, truth and beauty</b> — Einstein defending a truth <b>independent of human beings</b>, Tagore holding that reality is <b>inseparable from human consciousness</b>.',
      crux='Their disagreement dramatised a deep question — whether truth is <b>objective and external, or humanly constituted</b>.',
      conseq='The published dialogue became one of the most famous encounters between science and Eastern philosophy.',
      matters='It marked Tagore as a philosopher of world stature — engaging the century’s greatest scientist as a peer.'),
]

# ==================================================================  PHASE 6 — LATE HARVEST AND LEGACY
PHASE_LEGACY = [
    E('painting', '1928–1940', 'The painter at sixty', ['RISE', 'IDEAS'],
      'In his sixties Tagore takes up painting in earnest — turning the crossings-out in his manuscripts into strange, expressive images — and produces thousands of bold, primitive-modern works, exhibited across Europe, opening a wholly new career in a wholly new art near the end of his life.',
      svg_stack('A new art in old age', [
          {'n': 1, 'label': 'Painting seriously from c.1928', 'sub': 'a new art begun in his sixties', 'color': '#b45309'},
          {'n': 2, 'label': 'From crossings-out to canvas', 'sub': 'manuscript scribbles become images', 'color': '#0891b2'},
          {'n': 3, 'label': 'Exhibited across Europe', 'sub': 'thousands of bold, modernist works', 'color': '#7c3aed'},
      ], takeaway='He reinvented himself yet again — becoming a striking modern painter when most men would have stopped.', accent=AC),
      bg='Already a poet, novelist, composer and educator, Tagore turned to visual art late, encouraged by the abstract doodles in his manuscripts.',
      people='the European galleries that exhibited him; the modern artists whose world he now entered; his admirers, astonished at the new turn.',
      what='From around his sixtieth year Tagore <b>painted prolifically</b>, producing some <b>2,000–3,000 works</b> — dark, dreamlike and boldly modern — that were <b>exhibited across Europe</b>, despite his probable colour-blindness.',
      crux='He proved creativity need not fade with age — <b>a whole new art form opened to him past sixty</b>.',
      conseq='His paintings are now regarded as a striking, original contribution to modern Indian art.',
      matters='Reinvention has no age limit — Tagore’s late painting is a testament to lifelong creative courage.'),

    E('anthems', '1905–1941', 'The songs and two national anthems', ['LEGACY', 'TRIUMPH'],
      'Tagore composes some 2,000 songs — the entire genre of "Rabindra Sangeet" that still saturates Bengali life — and two of them become national anthems: "Jana Gana Mana," adopted by India, and "Amar Sonar Bangla," adopted by Bangladesh, a distinction held by no other person on earth.',
      svg_row('A composer for two nations', [
          {'n': 1, 'label': 'Rabindra Sangeet', 'sub': 'some 2,000 songs, words and music his own', 'color': '#b45309'},
          {'n': 2, 'label': '“Jana Gana Mana”', 'sub': 'becomes the national anthem of India', 'color': '#166534'},
          {'n': 3, 'label': '“Amar Sonar Bangla”', 'sub': 'becomes the national anthem of Bangladesh', 'color': '#0891b2'},
      ], edge_labels=['include', 'and'], takeaway='No one else has written two nations’ anthems — Tagore’s song runs in the blood of a whole culture.', accent=AC),
      bg='Music was central to Tagore’s art all his life; he wrote both the words and the melodies of a vast body of song.',
      people='the singers and households of Bengal for whom Rabindra Sangeet is a living tradition; the nations of India and Bangladesh.',
      what='He composed roughly <b>2,000 songs</b> — the genre known as <b>“Rabindra Sangeet”</b> — of which <b>“Jana Gana Mana”</b> became <b>India’s national anthem</b> and <b>“Amar Sonar Bangla”</b> became the <b>national anthem of Bangladesh</b>.',
      crux='He fused poetry and melody into a <b>living popular art</b>, then gave two nations their very voice.',
      conseq='Rabindra Sangeet remains woven into everyday Bengali life on both sides of the border.',
      matters='It is a distinction no other person shares — one man wrote the anthems of two sovereign countries.'),

    E('death', '1941', 'The passing at Jorasanko', ['DEATH', 'TRAGEDY'],
      'On 7 August 1941, after a long illness, Rabindranath Tagore dies at the age of eighty in the same Jorasanko mansion where he was born — plunging Bengal and India into mourning, and closing one of the most staggeringly prolific creative lives in human history.',
      svg_stack('The circle closes', [
          {'n': 1, 'label': 'Dies 7 August 1941', 'sub': 'after long illness, at the age of 80', 'color': '#111827'},
          {'n': 2, 'label': 'At Jorasanko once more', 'sub': 'in the very house where he was born', 'color': '#9f1239'},
          {'n': 3, 'label': 'A nation in mourning', 'sub': 'Bengal and India grieve their poet', 'color': '#b45309'},
      ], takeaway='He died where he began — the long arc from Jorasanko to the world closing back at its start.', accent=AC),
      bg='Tagore remained creatively active into his final years, writing and painting even as his health declined.',
      people='the family at his bedside; the countless Indians and Bengalis who mourned; the world that had made him famous.',
      what='On <b>7 August 1941</b> Tagore <b>died at eighty in the Jorasanko mansion</b> of his birth, after a prolonged illness, ending a life of almost unmatched creative range.',
      crux='His death marked the passing of a whole epoch — <b>the last great figure of the Bengal Renaissance</b>.',
      conseq='India and Bengal mourned deeply, and his reputation only grew in the decades that followed.',
      matters='A life that ended where it began — from the Jorasanko nursery to the world’s stage and home again.'),

    E('legacy', '1941–', 'Gurudev — the enduring polymath', ['LEGACY', 'TRIUMPH'],
      'Tagore endures as "Gurudev," perhaps the most complete polymath of modern times — poet, novelist, composer, painter, educator and philosopher — his songs sung daily, his university alive, his anthems ringing over two nations, an emblem of Indian culture and of a boundary-crossing human spirit.',
      svg_row('The universal man', [
          {'n': 1, 'label': 'Poet, composer, painter, sage', 'sub': 'a polymath of staggering range', 'color': '#b45309'},
          {'n': 2, 'label': 'Living legacy', 'sub': 'Visva-Bharati, Rabindra Sangeet, the anthems', 'color': '#166534'},
          {'n': 3, 'label': 'Revered as “Gurudev”', 'sub': 'the face of Indian culture to the world', 'color': '#7c3aed'},
      ], edge_labels=['leave', 'so'], takeaway='He remains a whole civilisation in one man — the enduring symbol of a creative, humane India.', accent=AC),
      bg='Tagore left behind a body of work spanning nearly every art and a set of institutions and songs that outlived him.',
      people='the generations of Bengalis raised on his songs; the students of Visva-Bharati; admirers of Indian culture worldwide.',
      what='He is revered as <b>“Gurudev”</b> — a polymath who reshaped <b>literature, music, painting, education and thought</b> — his <b>songs, university and two national anthems</b> all living on.',
      crux='His greatness lies in <b>sheer creative universality married to a humane vision</b> — art in the service of human unity.',
      conseq='He remains the towering figure of modern Indian culture and one of the world’s great humanists.',
      matters='Some lives are too large for a single label — Tagore is remembered as the complete creative human being.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Rabindranath Tagore was the Bengali polymath — poet, novelist, composer, painter, educator and philosopher — who carried Indian culture to the world and won the 1913 Nobel Prize in Literature, the first ever awarded to a non-European. Born into the great Tagore house of Jorasanko, he remade Bengali poetry and prose, gathered his devotional songs into <i>Gitanjali</i>, renounced a British knighthood in protest at the Jallianwala Bagh massacre, built the school and university of Santiniketan, debated Gandhi and Einstein, took up painting at sixty, and composed the national anthems of <b>two</b> nations. He is the ultimate study in <b>creative universality and a boundary-crossing human spirit.</b></p>
<div class="ov-quote">“Where the mind is without fear and the head is held high … into that heaven of freedom, my Father, let my country awake.”<span>— Rabindranath Tagore, Gitanjali</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born into the cultured Tagore house of Jorasanko → a prodigy who masters and remakes Bengali letters → the river years at Shelaidaha ground his art in rural life → sorrow deepens him into the devotional songs of Gitanjali → Yeats and the West acclaim him and the Nobel follows → he renounces his knighthood over Jallianwala Bagh and builds Visva-Bharati → tours the world debating nationalism, Gandhi and Einstein → and in late life paints, gives two nations their anthems, and dies at Jorasanko a universal sage.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🪶</div><h4>A world laureate</h4><p>First non-European to win the Nobel Prize in Literature, 1913.</p></div>
  <div class="ov-card"><div class="i">🎼</div><h4>Two nations’ anthems</h4><p>Composed both India’s and Bangladesh’s national songs.</p></div>
  <div class="ov-card"><div class="i">🌳</div><h4>A new education</h4><p>Built Santiniketan and Visva-Bharati around freedom and unity.</p></div>
  <div class="ov-card"><div class="i">✊</div><h4>Conscience over honour</h4><p>Renounced his knighthood after the Amritsar massacre.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Roots</b><small> 1861–1883</small><p>Jorasanko, the boy poet “Bhanusimha,” England and marriage.</p></div>
  <div><b>2 · The Padma</b><small> 1890–1901</small><p>Estates at Shelaidaha, the short stories, the school at Santiniketan.</p></div>
  <div><b>3 · Gitanjali</b><small> 1902–1912</small><p>Years of sorrow, the song offerings, and Yeats’s London.</p></div>
  <div><b>4 · The Nobel</b><small> 1913–1919</small><p>The prize, the knighthood, and its renunciation.</p></div>
  <div><b>5 · World Sage</b><small> 1921–1930</small><p>Visva-Bharati, world tours, Gandhi and Einstein.</p></div>
  <div><b>6 · Late Harvest</b><small> 1928–1941</small><p>The painter at sixty, the anthems, death and legacy.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Debendranath Tagore', 'role': 'father', 'color': '#3730a3',
     'bio': 'The reformer and Brahmo Samaj leader who headed the Tagore household, on whose Santiniketan land Rabindranath later built his school.',
     'rel': 'His father, whose faith and reform shaped his earliest world.'},
    {'name': 'W.B. Yeats', 'role': 'champion in the West', 'color': '#7c3aed',
     'bio': 'The Irish poet who was enraptured by the English Gitanjali in 1912 and wrote its glowing introduction, opening the West to Tagore.',
     'rel': 'The Western poet whose praise helped win him the Nobel.'},
    {'name': 'Mahatma Gandhi', 'role': 'reverent rival', 'color': '#166534',
     'bio': 'The leader of India’s non-violent freedom struggle, who called Tagore “Gurudev” while debating him over nationalism, reason and swadeshi.',
     'rel': 'His great friend and profound intellectual sparring partner.'},
    {'name': 'Albert Einstein', 'role': 'fellow mind', 'color': '#0891b2',
     'bio': 'The physicist who met Tagore near Berlin in 1930 for a famous dialogue on the nature of truth, reality and beauty.',
     'rel': 'The scientist he engaged as a philosophical equal.'},
    {'name': 'Mrinalini Devi', 'role': 'wife', 'color': '#db2777',
     'bio': 'Tagore’s wife from 1883, mother of his children, whose death in 1902 began the wave of loss that deepened his spiritual verse.',
     'rel': 'His wife, whose loss shadowed the Gitanjali years.'},
]

KEY_EVENTS = [
    ('1861', 'Born at Jorasanko', 'Into the leading cultured family of Bengal.'),
    ('1877', 'Poems as “Bhanusimha”', 'A teenage prodigy fools the critics.'),
    ('1890', 'Estates at Shelaidaha', 'The Padma years ground his art in rural life.'),
    ('1901', 'Santiniketan school', 'An open-air education of freedom and nature.'),
    ('1910', 'Gitanjali published', 'Devotional song offerings in Bengali.'),
    ('1912', 'English Gitanjali & Yeats', 'Literary London hails a new voice.'),
    ('1913', 'Nobel Prize', 'First non-European laureate in Literature.'),
    ('1915', 'Knighted', 'Honoured by the British Crown at his peak.'),
    ('1919', 'Renounces knighthood', 'In protest at the Jallianwala Bagh massacre.'),
    ('1921', 'Visva-Bharati founded', 'A university where “the world nests as one.”'),
    ('1930', 'Meets Einstein', 'A famous dialogue on truth and reality.'),
    ('1941', 'Dies at Jorasanko', 'A universal sage passes at eighty.'),
]

MASTER = [
    {'year': '1861', 'age': 'born', 'phase': 'Roots', 'title': 'Born at Jorasanko', 'desc': 'Into the great Tagore family of Calcutta.'},
    {'year': '1877', 'age': 'age 16', 'phase': 'Roots', 'title': 'The boy poet', 'desc': 'Publishes as “Bhanusimha.”'},
    {'year': '1890', 'age': 'age 29', 'phase': 'The Padma', 'title': 'Shelaidaha estates', 'desc': 'The river years shape his art.'},
    {'year': '1901', 'age': 'age 40', 'phase': 'The Padma', 'title': 'Santiniketan school', 'desc': 'An experiment in free education.'},
    {'year': '1910', 'age': 'age 49', 'phase': 'Gitanjali', 'title': 'Gitanjali', 'desc': 'The devotional song offerings.'},
    {'year': '1912', 'age': 'age 51', 'phase': 'Gitanjali', 'title': 'Yeats and London', 'desc': 'The English Gitanjali stuns the West.'},
    {'year': '1913', 'age': 'age 52', 'phase': 'The Nobel', 'title': 'Nobel Prize', 'desc': 'First non-European laureate.'},
    {'year': '1919', 'age': 'age 58', 'phase': 'The Nobel', 'title': 'Renounces knighthood', 'desc': 'Protest at Jallianwala Bagh.'},
    {'year': '1921', 'age': 'age 60', 'phase': 'World Sage', 'title': 'Visva-Bharati', 'desc': 'A university of world cultures.'},
    {'year': '1930', 'age': 'age 69', 'phase': 'World Sage', 'title': 'Einstein dialogue', 'desc': 'On the nature of truth.'},
    {'year': '1941', 'age': 'age 80', 'phase': 'Late Harvest', 'title': 'Dies at Jorasanko', 'desc': 'A universal life closes.'},
]

SOURCES = [
    ('Britannica — Rabindranath Tagore', 'https://www.britannica.com/biography/Rabindranath-Tagore'),
    ('Wikipedia — Rabindranath Tagore', 'https://en.wikipedia.org/wiki/Rabindranath_Tagore'),
    ('The Nobel Prize — Rabindranath Tagore', 'https://www.nobelprize.org/prizes/literature/1913/tagore/facts/'),
    ('Poetry Foundation — Rabindranath Tagore', 'https://www.poetryfoundation.org/poets/rabindranath-tagore'),
    ('New World Encyclopedia — Rabindranath Tagore', 'https://www.newworldencyclopedia.org/entry/Rabindranath_Tagore'),
]

def build_meta():
    return {
        'pid': 'gm-tagore.html', 'kind': 'man', 'emoji': '🪶', 'accent': AC,
        'name': 'Rabindranath Tagore', 'years': '1861–1941', 'group': 'Sages, Poets & Philosophers',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Bengali polymath — poet, composer, painter and sage — who won the 1913 Nobel Prize as the first non-European laureate, built Santiniketan, renounced a knighthood over Jallianwala Bagh, and gave two nations their anthems.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'roots', 'label': '1 · Roots', 'type': 'timeline',
             'intro': 'Born into the cultured Tagore house of Jorasanko, a prodigy who fools the critics as “Bhanusimha,” he travels to England and returns to marriage and a mature poetic voice.', 'events': PHASE_ROOTS},
            {'id': 'padma', 'label': '2 · The Padma', 'type': 'timeline',
             'intro': 'Managing the estates at Shelaidaha, he lives among peasants and rivers, all but invents the modern Bengali short story, and founds his open-air school at Santiniketan.', 'events': PHASE_PADMA},
            {'id': 'gitanjali', 'label': '3 · Gitanjali', 'type': 'timeline',
             'intro': 'A cascade of family loss deepens his verse into the devotional songs of Gitanjali — which, in his own English translation, dazzles W.B. Yeats and literary London.', 'events': PHASE_GITANJALI},
            {'id': 'nobel', 'label': '4 · The Nobel', 'type': 'timeline',
             'intro': 'The 1913 Nobel makes him a world figure; a knighthood follows in 1915 — and in 1919 he casts it off in outrage at the Jallianwala Bagh massacre.', 'events': PHASE_NOBEL},
            {'id': 'sage', 'label': '5 · World Sage', 'type': 'timeline',
             'intro': 'He builds Visva-Bharati as a university of world cultures and circles the globe as an ambassador of human unity — debating Gandhi and Einstein along the way.', 'events': PHASE_SAGE},
            {'id': 'legacy', 'label': '6 · Late Harvest', 'type': 'timeline',
             'intro': 'In old age he becomes a bold modern painter, gives two nations their anthems, and dies at Jorasanko — enduring as “Gurudev,” the complete creative human being.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; translations and song counts vary slightly between authorities and are given as widely cited approximations.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
