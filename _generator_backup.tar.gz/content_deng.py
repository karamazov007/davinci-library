# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Deng Xiaoping.
The pragmatic architect of China’s reform who lifted hundreds of millions from poverty — and ordered the guns at Tiananmen."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#be123c'  # Chinese crimson

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING
PHASE_MAKING = [
    E('origins', '1904–1920', 'A Sichuan boy who leaves for the world', ['RISE'],
      'Born in 1904 to a modestly landed family in Sichuan, Deng Xiaoping grows up in a China humiliated by foreign powers and a decaying empire — and at just sixteen boards a ship for France on a work-study programme, leaving home to find the tools to save his country.',
      svg_row('From a village to the wider world', [
          {'n': 1, 'label': 'Born in Sichuan, 1904', 'sub': 'a modestly landed family in Guang’an', 'color': '#be123c'},
          {'n': 2, 'label': 'A China in crisis', 'sub': 'empire fallen, warlords and foreign powers', 'color': '#b45309'},
          {'n': 3, 'label': 'Sails for France at 16', 'sub': 'a work-study programme, 1920', 'color': '#166534'},
      ], edge_labels=['amid', 'so'], takeaway='A boy from the Sichuan hinterland set out for Europe to find what could rescue a broken China.', accent=AC),
      bg='<b>Deng Xiaoping</b> was born in 1904 in Guang’an county, Sichuan, into a landholding family, as the Qing dynasty collapsed and China fractured under warlords and foreign encroachment.',
      people='his father, a local landowner; the reformist teachers who urged study abroad; the generation of young Chinese seeking national renewal.',
      what='Amid national humiliation and chaos, the sixteen-year-old Deng joined a <b>diligent-work, frugal-study</b> movement and <b>sailed for France in 1920</b> to learn from the industrial West.',
      crux='His formation was defined by <b>China’s weakness and his hunger to fix it</b> — a lifelong pragmatist looking for what actually works.',
      conseq='In France he would find not engineering but revolution, and a mentor who shaped the rest of his life.',
      matters='Great reformers are often forged by national humiliation — Deng’s whole career was an answer to the China he was born into.'),

    E('france', '1920–1926', 'Factory floors of France — a communist is born', ['RISE', 'TURNING POINT'],
      'The work-study dream collapses into hard labour — Deng toils in French factories, including Renault, too poor to study much — and there, among fellow exiles, he is drawn into communism, joins the movement, and falls under the wing of Zhou Enlai, forging the bond that will define his life.',
      svg_stack('Poverty, labour, and a new faith', [
          {'n': 1, 'label': 'Work-study collapses into toil', 'sub': 'factory labour at Renault and elsewhere', 'color': '#b45309'},
          {'n': 2, 'label': 'Drawn into communism', 'sub': 'joins the Chinese Communist Youth in Europe', 'color': '#be123c'},
          {'n': 3, 'label': 'Zhou Enlai becomes his mentor', 'sub': 'a bond that lasts fifty years', 'color': '#166534'},
      ], takeaway='France gave Deng not a diploma but a cause — and the mentor, Zhou Enlai, who would shield him for a lifetime.', accent=AC),
      bg='The work-study scheme left students destitute; Deng spent his French years (1920–26) largely as a labourer rather than a scholar.',
      people='<b>Zhou Enlai</b>, his mentor and future protector; the community of radical Chinese students in Paris; the French labour movement.',
      what='Working in factories including <b>Renault</b>, Deng joined the <b>Chinese Communist movement in Europe</b>, edited its propaganda, and became a devoted follower of <b>Zhou Enlai</b> before leaving for Moscow in 1926.',
      crux='His communism was <b>learned in a factory, not a library</b> — practical, hardened, and tied to Zhou by loyalty.',
      conseq='From Moscow he returned to China to become a soldier and organiser of the revolution.',
      matters='Ideas are shaped by the men who carry them — Deng’s bond with Zhou Enlai twice saved his life and his career.'),

    E('revolution', '1926–1949', 'The Long March and the road to power', ['RISE', 'BATTLE'],
      'Returning through Moscow, Deng becomes a revolutionary soldier and political commissar — he survives the epic Long March of 1934–35, rises within Mao’s circle, and commands men through the war against Japan and the civil war, emerging in 1949 as a founding leader of the People’s Republic of China.',
      svg_stack('From commissar to founder of a state', [
          {'n': 1, 'label': 'Revolutionary and commissar', 'sub': 'organiser and political officer in the Red Army', 'color': '#be123c'},
          {'n': 2, 'label': 'Survives the Long March', 'sub': 'the epic 1934–35 retreat that made Mao', 'color': '#b45309'},
          {'n': 3, 'label': 'A founder of the PRC, 1949', 'sub': 'victorious in the civil war under Mao', 'color': '#166534'},
      ], takeaway='Deng earned his standing the hard way — through the Long March and decades of war at Mao’s side.', accent=AC),
      bg='After training in Moscow, Deng returned to a China torn between Nationalists and Communists, throwing himself into the armed revolution.',
      people='<b>Mao Zedong</b>, the rising leader; <b>Zhou Enlai</b>, his patron; the Red Army soldiers he led as political commissar.',
      what='Deng survived the <b>Long March (1934–35)</b>, served as a leading political commissar through the anti-Japanese and civil wars, and helped found the <b>People’s Republic of China in 1949</b>.',
      crux='He built <b>revolutionary credentials no one could question</b> — a veteran of the March and of victory in the field.',
      conseq='These credentials made him a top leader of the new state, and later gave him the authority to remake it.',
      matters='Legitimacy in revolutionary China was earned in blood — Deng’s war record was the foundation of everything that followed.'),
]

# ==================================================================  PHASE 2 — UNDER MAO
PHASE_MAO = [
    E('newprc', '1949–1956', 'Building the new China — and rising fast', ['POLITICS', 'RISE'],
      'In the new People’s Republic Deng rises with startling speed — pacifying his native southwest, moving to Beijing as a vice premier, and by 1956 becoming General Secretary of the Communist Party, one of the handful of men at the very summit of Mao’s China.',
      svg_row('A swift climb to the summit', [
          {'n': 1, 'label': 'Governs the southwest', 'sub': 'consolidates Communist rule after 1949', 'color': '#be123c'},
          {'n': 2, 'label': 'Vice Premier in Beijing', 'sub': 'a rising national administrator', 'color': '#b45309'},
          {'n': 3, 'label': 'General Secretary, 1956', 'sub': 'runs the Party machine under Mao', 'color': '#166534'},
      ], edge_labels=['then', 'to'], takeaway='Deng rose from regional boss to General Secretary in seven years — Mao’s trusted organiser of the Party.', accent=AC),
      bg='After 1949 the new regime needed capable administrators; Deng’s talent for organisation marked him for rapid promotion.',
      people='<b>Mao Zedong</b>, the paramount leader; <b>Liu Shaoqi</b>, a fellow pragmatist; the Party apparatus Deng came to run.',
      what='Deng consolidated Communist power in the <b>southwest</b>, became a <b>vice premier</b>, and in <b>1956 was named General Secretary</b> of the Chinese Communist Party, running its day-to-day machinery.',
      crux='He made himself <b>indispensable as an administrator</b> — the man who made the Party actually function.',
      conseq='His command of the Party machine put him at the centre of every struggle over China’s direction.',
      matters='Organisational skill is quiet power — Deng rose not by charisma but by making the system run.'),

    E('pragmatist', '1957–1962', 'The black cat, the white cat', ['POLITICS', 'REFORM'],
      'When Mao’s Great Leap Forward ends in catastrophic famine, Deng and other pragmatists step in to repair the economy — relaxing collectivisation to let peasants produce — and Deng gives voice to his whole philosophy: it does not matter if a cat is black or white, so long as it catches mice.',
      svg_compare('Two ways to run an economy', {
          'head': 'Maoist orthodoxy', 'color': '#7f1d1d',
          'items': ['Ideology decides everything', 'Mass collectivisation', 'Revolutionary zeal over results', 'The Great Leap ends in famine'],
      }, {
          'head': 'Deng’s pragmatism', 'color': '#166534',
          'items': ['Whatever raises production', 'Let peasants farm and profit', 'Results over slogans', 'The black-cat, white-cat test'],
      }, verdict='Deng: “It doesn’t matter if a cat is black or white, so long as it catches mice.”',
         takeaway='Deng judged policy by results, not doctrine — a heresy under Mao that became his life’s creed.', accent=AC),
      bg='Mao’s <b>Great Leap Forward (1958–62)</b> caused one of history’s deadliest famines; pragmatists were called in to rescue the economy.',
      people='<b>Mao Zedong</b>, author of the Leap; <b>Liu Shaoqi</b>, co-repairer; the starving peasants whose recovery was urgent.',
      what='To reverse the famine Deng backed <b>loosening collective agriculture</b> to restore output, and famously argued that <b>results matter more than ideology</b> — the “black cat, white cat” maxim (1962).',
      crux='He believed in <b>pragmatism over dogma</b> — that a policy should be judged by whether it works, not by its ideological purity.',
      conseq='This pragmatism repaired the economy but marked him, in Mao’s eyes, as a “capitalist roader” to be purged.',
      matters='The idea that results outrank ideology is Deng’s core legacy — and in Mao’s China it was a dangerous heresy.'),

    E('firstpurge', '1966–1969', 'Cast down — the first purge', ['POLITICS', 'DEFEAT', 'TRAGEDY'],
      'Mao launches the Cultural Revolution to smash the pragmatists, and Deng is denounced as the “number two capitalist roader,” stripped of all offices, publicly humiliated, and exiled to labour in a tractor factory in Jiangxi — his eldest son crippled after being driven from a window by Red Guards.',
      svg_stack('The pragmatist is destroyed', [
          {'n': 1, 'label': 'The Cultural Revolution, 1966', 'sub': 'Mao unleashes the Red Guards on his own party', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Denounced as a “capitalist roader”', 'sub': 'stripped of office and paraded in disgrace', 'color': '#be123c'},
          {'n': 3, 'label': 'Exiled to labour in Jiangxi', 'sub': 'toils in a tractor factory; his son is crippled', 'color': '#44403c'},
      ], takeaway='Mao’s purge cost Deng his power, his freedom, and grievously his family — yet he survived where others died.', accent=AC),
      bg='Fearing his revolution was being betrayed, Mao launched the <b>Cultural Revolution (1966)</b> to purge pragmatists and rivals.',
      people='<b>Mao Zedong</b>, who ordered the purge; <b>Jiang Qing</b> and the radicals who drove it; Deng’s family, made to suffer.',
      what='Deng was denounced as the <b>“number two capitalist roader,”</b> stripped of all posts, publicly humiliated, and sent to <b>labour in a Jiangxi tractor factory</b>; his son Deng Pufang was crippled after a fall from a building under Red Guard persecution.',
      crux='He was destroyed for the crime of <b>pragmatism</b> — and endured it with a patience that would define his comeback.',
      conseq='Unlike Liu Shaoqi, who died in prison, Deng survived — kept alive, it is said, by Mao’s residual respect and Zhou’s protection.',
      matters='Survival is itself a victory — Deng’s ability to endure disgrace without breaking set up the greatest comeback in modern politics.'),
]

# ==================================================================  PHASE 3 — PURGED AND REBORN
PHASE_REBORN = [
    E('return', '1973–1976', 'Down and up — and purged again', ['POLITICS', 'TURNING POINT'],
      'A dying Zhou Enlai brings Deng back to run the government in 1973, and he sets about restoring order after the chaos — but when Zhou dies in 1976 and crowds mourn him at Tiananmen, the radical Gang of Four blame Deng for the unrest and purge him a second time, days before Mao’s own death.',
      svg_stack('Rehabilitated, then cast down once more', [
          {'n': 1, 'label': 'Zhou brings him back, 1973', 'sub': 'Deng runs the government, restoring order', 'color': '#166534'},
          {'n': 2, 'label': 'Zhou Enlai dies, January 1976', 'sub': 'Deng loses his great protector', 'color': '#44403c'},
          {'n': 3, 'label': 'The Gang of Four purge him again', 'sub': 'blamed for the Tiananmen mourning, April 1976', 'color': '#be123c'},
      ], takeaway='Twice raised and twice thrown down — Deng’s fortunes rode the last convulsions of the Mao era.', accent=AC),
      bg='By the early 1970s the Cultural Revolution had wrecked the economy; the ailing <b>Zhou Enlai</b> needed a capable hand to restore it.',
      people='<b>Zhou Enlai</b>, who rehabilitated him; the <b>Gang of Four</b> (led by Jiang Qing), who feared him; a dying Mao.',
      what='Rehabilitated in <b>1973</b>, Deng ran the government and pushed order and modernisation — but after Zhou’s death, the mourning crowds at the <b>Tiananmen Incident of April 1976</b> gave the radicals a pretext to <b>purge him a second time</b>.',
      crux='He rose and fell on the tide of the succession struggle — <b>twice purged, twice a survivor</b>, awaiting his moment.',
      conseq='Within months Mao was dead and the Gang of Four arrested, opening the door for Deng’s final, decisive return.',
      matters='Persistence outlasts persecution — the man purged twice would inherit the very country that cast him out.'),

    E('paramount', '1977–1978', 'The comeback — becoming paramount leader', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'After Mao’s death Deng is rehabilitated a final time, and by sheer prestige and political skill he outmanoeuvres Mao’s chosen heir Hua Guofeng — and at the epochal Third Plenum of December 1978 he emerges as China’s paramount leader, ready to turn the nation away from Maoist dogma toward reform.',
      svg_row('The rise to undisputed power', [
          {'n': 1, 'label': 'Mao dies; Gang of Four fall, 1976', 'sub': 'the radical era collapses', 'color': '#44403c'},
          {'n': 2, 'label': 'Deng rehabilitated, 1977', 'sub': 'outmanoeuvres the heir Hua Guofeng', 'color': '#be123c'},
          {'n': 3, 'label': 'Paramount leader, Dec 1978', 'sub': 'the Third Plenum turns China to reform', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='Without ever taking the top title, Deng became the man who ran China — and pointed it toward reform.', accent=AC),
      bg='Mao’s death in 1976 left a vacuum; his designated successor <b>Hua Guofeng</b> lacked the stature to hold it against a returning Deng.',
      people='<b>Hua Guofeng</b>, the outmanoeuvred heir; Deng’s reformist allies; the veteran cadres who backed his return.',
      what='Rehabilitated in <b>1977</b>, Deng used his prestige to sideline Hua, and at the <b>Third Plenum of the 11th Central Committee (December 1978)</b> he became China’s <b>paramount leader</b>, launching the era of reform.',
      crux='He took power through <b>authority and consensus, not titles</b> — ruling as paramount leader while others held the formal posts.',
      conseq='With power secured, Deng launched the transformation known as “Reform and Opening Up.”',
      matters='Real power need not wear a crown — Deng ran China for years as its acknowledged leader without being head of state or party.'),

    E('boluan', '1978–1981', 'Reversing the verdicts, opening the door', ['POLITICS', 'REFORM'],
      'Deng consolidates his revolution by rehabilitating millions of Cultural Revolution victims, putting the Gang of Four on trial, and delivering a careful verdict on Mao — “seventy per cent right, thirty per cent wrong” — preserving the Party’s legitimacy while decisively closing the door on Maoist radicalism.',
      svg_stack('Settling the past to free the future', [
          {'n': 1, 'label': 'Rehabilitate the victims', 'sub': 'millions purged under Mao are restored', 'color': '#166534'},
          {'n': 2, 'label': 'Try the Gang of Four, 1980–81', 'sub': 'the radicals are condemned for the terror', 'color': '#be123c'},
          {'n': 3, 'label': 'A verdict on Mao', 'sub': '“70% right, 30% wrong” — the Party endures', 'color': '#b45309'},
      ], takeaway='Deng buried the Maoist era without burying the Party — condemning the excess while keeping the founding myth.', accent=AC),
      bg='To launch reform, Deng first had to settle accounts with the Cultural Revolution without destroying the Party that had waged it.',
      people='the <b>Gang of Four</b>, now on trial; the millions of rehabilitated victims; the Party Deng was determined to preserve.',
      what='Deng <b>rehabilitated millions</b> of purge victims, oversaw the <b>trial of the Gang of Four (1980–81)</b>, and issued the official verdict that Mao was <b>“seventy per cent right, thirty per cent wrong”</b> — sealing off radicalism while shielding the Party.',
      crux='He drew a careful line: <b>reject the disaster, preserve the legitimacy</b> — repudiating Maoism without repudiating Mao.',
      conseq='With the past settled on his terms, Deng was free to remake the economy.',
      matters='A revolution that survives must reckon with its own crimes selectively — Deng’s verdict on Mao still governs how China remembers itself.'),
]

# ==================================================================  PHASE 4 — REFORM AND OPENING UP
PHASE_REFORM = [
    E('farms', '1978–1984', 'Giving the land back — dismantling the communes', ['REFORM', 'TRIUMPH'],
      'Deng’s first great reform breaks up Mao’s collective farms — the Household Responsibility System lets families work their own plots and sell the surplus, and once peasants can profit from their labour, grain output surges and hundreds of millions begin to climb out of hunger.',
      svg_row('Incentives unleash the countryside', [
          {'n': 1, 'label': 'Collective farms fail', 'sub': 'the communes leave peasants poor and hungry', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Household Responsibility System', 'sub': 'families farm their own land, keep the surplus', 'color': '#be123c'},
          {'n': 3, 'label': 'Output surges', 'sub': 'incomes rise; hunger recedes across China', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='Let farmers profit from their own work and production soared — the simplest and most transformative of Deng’s reforms.', accent=AC),
      bg='Mao’s collective communes had left rural China trapped in poverty; reformers wanted to restore the link between effort and reward.',
      people='the peasants freed to farm for themselves; local officials who piloted the reform; Deng, who blessed and spread it.',
      what='Deng backed the <b>Household Responsibility System</b>, which effectively <b>dismantled the collective farms</b>, letting families cultivate their own plots and <b>sell their surplus</b> — sending agricultural output and rural incomes soaring.',
      crux='He restored the <b>link between effort and reward</b> — the market incentive Maoism had abolished.',
      conseq='The rural boom fed the cities, freed labour for industry, and proved reform could work.',
      matters='Aligning incentives with effort is the engine of growth — decollectivisation began the greatest reduction of poverty in history.'),

    E('sez', '1980', 'Shenzhen rising — the Special Economic Zones', ['REFORM', 'TURNING POINT'],
      'Deng opens China to the world by carving out Special Economic Zones — capitalist enclaves where foreign investment, private enterprise and export manufacturing are welcomed — and turns a sleepy fishing town called Shenzhen, on the border with Hong Kong, into a laboratory that becomes a booming metropolis.',
      svg_stack('A window opened to the world', [
          {'n': 1, 'label': 'Special Economic Zones, 1980', 'sub': 'Shenzhen, Zhuhai, Shantou, Xiamen', 'color': '#be123c'},
          {'n': 2, 'label': 'Capitalism inside socialism', 'sub': 'foreign capital, private firms, exports welcomed', 'color': '#b45309'},
          {'n': 3, 'label': 'Shenzhen becomes a boomtown', 'sub': 'a fishing village grows into a megacity', 'color': '#166534'},
      ], takeaway='Deng let capitalism loose in fenced-off zones — and Shenzhen’s explosion showed the whole nation what reform could do.', accent=AC),
      bg='China was starved of capital and technology; Deng needed a way to import both without opening the whole country at once.',
      people='foreign and Hong Kong investors; the migrant workers who built Shenzhen; the reformist officials who ran the zones.',
      what='In <b>1980</b> Deng established <b>Special Economic Zones</b> — beginning with <b>Shenzhen</b> next to Hong Kong — where <b>foreign investment, private enterprise and export industry</b> were permitted, turning Shenzhen from a village into a global manufacturing hub.',
      crux='He reformed by <b>experiment</b> — testing capitalism in controlled zones before extending it, “crossing the river by feeling the stones.”',
      conseq='The zones’ success became the model for opening the entire Chinese economy.',
      matters='Bold change through careful pilots is Deng’s method — Shenzhen is the living monument to “Reform and Opening Up.”'),

    E('socialism', '1982–1988', 'Socialism with Chinese characteristics', ['REFORM', 'POLITICS'],
      'Deng gives his revolution a name and a licence — “socialism with Chinese characteristics” — declaring that markets are tools, not ideology, and that “to get rich is glorious.” Yet the same era brings the coercive one-child policy, showing the hard hand of the state alongside the freeing of the economy.',
      svg_row('A new formula for a changing China', [
          {'n': 1, 'label': '“Socialism with Chinese characteristics”', 'sub': 'markets as tools, not betrayal', 'color': '#be123c'},
          {'n': 2, 'label': '“To get rich is glorious”', 'sub': 'private wealth becomes patriotic', 'color': '#166534'},
          {'n': 3, 'label': 'The one-child policy', 'sub': 'the coercive face of the same state', 'color': '#7f1d1d'},
      ], edge_labels=['and', 'yet'], takeaway='Deng freed people to grow rich while the state tightened control over their families — reform’s double face.', accent=AC),
      bg='Deng needed an ideological cover to pursue market reform inside a one-party communist state without appearing to abandon socialism.',
      people='the entrepreneurs Deng encouraged; the Party theorists who framed the doctrine; the families bound by the birth-control campaign.',
      what='Deng coined <b>“socialism with Chinese characteristics”</b> (1982) to license market reform, spread the slogan that <b>“to get rich is glorious,”</b> while the state imposed the coercive <b>one-child policy</b> to curb population growth.',
      crux='He separated <b>economic freedom from political freedom</b> — loosening the market while the Party kept absolute control, including over childbirth.',
      conseq='Wealth and inequality both grew fast, and the tension between economic opening and political control would erupt in 1989.',
      matters='Deng’s bargain — economic liberty without political liberty — still defines China, with all its prosperity and its coercion.'),
]

# ==================================================================  PHASE 5 — TRIUMPH AND TRAGEDY
PHASE_LEGACY = [
    E('tiananmen', '1989', 'Tiananmen — the darkest decision', ['POLITICS', 'TRAGEDY', 'DEFEAT'],
      'In 1989 vast crowds fill Tiananmen Square demanding democracy and an end to corruption — and Deng, fearing chaos and the loss of Party control, backs the hardliners, declares martial law, and approves the use of the army. On the night of June 3–4 troops clear the square by force, killing many. It is his darkest and most debated act.',
      svg_stack('When reform met its limit', [
          {'n': 1, 'label': 'Protests fill the square, 1989', 'sub': 'students and citizens demand democracy and reform', 'color': '#b45309'},
          {'n': 2, 'label': 'Deng backs the hardliners', 'sub': 'martial law declared; Zhao Ziyang purged', 'color': '#be123c'},
          {'n': 3, 'label': 'The army clears the square', 'sub': 'June 3–4: force used, many killed', 'color': '#7f1d1d'},
      ], takeaway='Deng chose Party control over the protesters’ demands — a bloody crackdown that remains the gravest stain on his legacy.', accent=AC),
      bg='By 1989 economic reform, inflation and corruption had fed public anger; the death of reformist Hu Yaobang sparked mass protests centred on <b>Tiananmen Square</b>.',
      people='the student and citizen protesters; <b>Zhao Ziyang</b>, the reformist leader who sympathised and was purged; the hardliners Deng sided with.',
      what='Fearing chaos and a threat to Party rule, Deng supported the decision to <b>impose martial law</b> and <b>use the army to clear Tiananmen Square on the night of 3–4 June 1989</b>, a crackdown that killed many; the reformer <b>Zhao Ziyang</b> was ousted for opposing it. The event is historically presented as the most disputed act of his rule.',
      crux='Confronted with a choice between <b>political opening and Party control, Deng chose control</b> — and force — placing stability above reform’s political logic.',
      conseq='The crackdown brought international condemnation and a conservative retreat that threatened to halt reform altogether.',
      matters='Deng’s legacy is genuinely two-sided: the architect of prosperity was also the man who ordered the guns — both belong in any honest account.'),

    E('southerntour', '1992', 'The Southern Tour — relaunching reform', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'After Tiananmen, conservatives try to roll reform back — so in 1992 the aged, semi-retired Deng makes a dramatic personal journey through the booming south, to Shenzhen and beyond, publicly demanding faster and bolder reform. The tour breaks the deadlock and relaunches China’s economic opening for good.',
      svg_row('One last push to save the reform', [
          {'n': 1, 'label': 'Reform stalls after 1989', 'sub': 'conservatives try to reverse the opening', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'The Southern Tour, 1992', 'sub': 'Deng tours Shenzhen and the south', 'color': '#be123c'},
          {'n': 3, 'label': 'Reform relaunched', 'sub': 'growth accelerates; the boom is unleashed', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='With no formal office left, Deng used sheer authority to force reform back on track — his final decisive act.', accent=AC),
      bg='The post-Tiananmen backlash had empowered conservatives who wanted to reverse market reform; the whole project hung in the balance.',
      people='the reformist officials Deng rallied; the conservative rivals he overrode; the southern cities that embodied his vision.',
      what='In early <b>1992</b>, though holding no top office, Deng made his celebrated <b>Southern Tour (Nanxun)</b> through <b>Shenzhen, Zhuhai and Shanghai</b>, publicly demanding <b>bolder and faster reform</b> — breaking the conservative deadlock and reigniting China’s growth.',
      crux='He proved that <b>moral authority can outweigh formal power</b> — a retired man’s tour reset the direction of a nation.',
      conseq='China entered its era of explosive double-digit growth, cementing Deng’s economic model.',
      matters='Deng’s last great act rescued his life’s work — the Southern Tour set China on the path to becoming an economic superpower.'),

    E('death', '1997', 'Death and the world he remade', ['DEATH', 'TRIUMPH'],
      'Deng Xiaoping dies in 1997, aged 92, having transformed China more than anyone since Mao — an economy unleashed, hundreds of millions lifted from poverty, and a nation set on the road to superpower — even as the shadow of Tiananmen and the absence of political freedom remain his unresolved legacy.',
      svg_stack('The measure of the man', [
          {'n': 1, 'label': 'Dies in 1997, aged 92', 'sub': 'his reforms firmly entrenched', 'color': '#44403c'},
          {'n': 2, 'label': 'Hundreds of millions lifted from poverty', 'sub': 'the greatest such rise in history', 'color': '#166534'},
          {'n': 3, 'label': 'An unresolved legacy', 'sub': 'prosperity without political freedom; Tiananmen’s shadow', 'color': '#be123c'},
      ], takeaway='Deng remade China as an economic giant while leaving its politics unfree — a legacy both towering and deeply contested.', accent=AC),
      bg='By his death in <b>1997</b>, Deng’s reforms had reshaped China; months later Hong Kong returned to Chinese rule under his “one country, two systems” formula.',
      people='his chosen successors who continued reform; the hundreds of millions whose lives he transformed; the victims of Tiananmen still uncommemorated.',
      what='Deng died in <b>1997 at 92</b>, having engineered history’s <b>largest escape from poverty</b> and set China toward superpower status, while leaving <b>political liberalisation firmly refused</b> and Tiananmen unaddressed.',
      crux='His legacy is a <b>deliberate trade</b> — extraordinary economic transformation bought with continued one-party control.',
      conseq='The China of the twenty-first century — prosperous, powerful and authoritarian — is fundamentally Deng’s creation.',
      matters='Deng is the defining paradox of modern China: the liberator of its economy and the enforcer of its political limits, in one man.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Deng Xiaoping was the pragmatic architect of modern China — the man who, after Mao, turned a poor and closed communist state into an economic superpower and lifted hundreds of millions out of poverty. Twice purged and twice reborn, he rose to paramount leader in 1978 and launched “Reform and Opening Up”: dismantling collective farms, opening Special Economic Zones, and declaring that “to get rich is glorious.” Yet the same leader ordered the army into Tiananmen Square in 1989. He is the ultimate study in <b>pragmatism over dogma, economic freedom without political freedom, and a legacy that is genuinely two-sided.</b></p>
<div class="ov-quote">“It doesn’t matter whether a cat is black or white, so long as it catches mice.”<span>— Deng Xiaoping</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A Sichuan boy sails to France and becomes a communist → survives the Long March and helps found the People’s Republic → rises to General Secretary, then is purged twice in the Cultural Revolution → returns after Mao’s death to become paramount leader in 1978 → dismantles the communes, opens Shenzhen and the Special Economic Zones, and launches reform → orders the crackdown at Tiananmen in 1989 → relaunches reform with his 1992 Southern Tour → and dies in 1997 having remade China.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🐱</div><h4>Pragmatism over dogma</h4><p>Judged policy by results, not ideology — the black-cat, white-cat creed.</p></div>
  <div class="ov-card"><div class="i">🏙️</div><h4>Reform and Opening Up</h4><p>Shenzhen, the SEZs and the household farms unleashed history’s greatest boom.</p></div>
  <div class="ov-card"><div class="i">📈</div><h4>Poverty’s great retreat</h4><p>Hundreds of millions climbed out of poverty in a single generation.</p></div>
  <div class="ov-card"><div class="i">🕯️</div><h4>Tiananmen’s shadow</h4><p>The architect of prosperity also ordered the guns — his darkest, most debated act.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Making</b><small> 1904–1949</small><p>France, communism, the Long March.</p></div>
  <div><b>2 · Under Mao</b><small> 1949–1969</small><p>General Secretary, the cat, the first purge.</p></div>
  <div><b>3 · Purged and Reborn</b><small> 1973–1981</small><p>Twice cast down, then paramount leader.</p></div>
  <div><b>4 · Reform and Opening Up</b><small> 1978–1988</small><p>Farms freed, Shenzhen risen, wealth glorious.</p></div>
  <div><b>5 · Triumph and Tragedy</b><small> 1989–1997</small><p>Tiananmen, the Southern Tour, and death.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Mao Zedong', 'role': 'the leader he served and survived', 'color': '#7f1d1d',
     'bio': 'The founder of the People’s Republic under whom Deng rose, and who twice purged him during the Cultural Revolution for his pragmatism.',
     'rel': 'The revolutionary titan he served, was destroyed by, and ultimately succeeded and corrected.'},
    {'name': 'Zhou Enlai', 'role': 'mentor and protector', 'color': '#166534',
     'bio': 'The premier who first drew Deng into communism in France and, decades later, shielded him and brought him back to power in 1973.',
     'rel': 'His lifelong mentor from their Paris days, who twice saved his career.'},
    {'name': 'Jiang Qing & the Gang of Four', 'role': 'radical persecutors', 'color': '#be123c',
     'bio': 'Mao’s wife and her radical allies who drove the Cultural Revolution and engineered Deng’s second purge in 1976, before falling after Mao’s death.',
     'rel': 'The radicals who purged him and whom he later put on trial.'},
    {'name': 'Hua Guofeng', 'role': 'the outmanoeuvred heir', 'color': '#b45309',
     'bio': 'Mao’s designated successor, whom Deng eclipsed through prestige and political skill to become China’s paramount leader by 1978.',
     'rel': 'The chosen heir he outmanoeuvred on the road to power.'},
    {'name': 'Zhao Ziyang', 'role': 'reformist protégé', 'color': '#4f46e5',
     'bio': 'Deng’s reform-minded lieutenant who sympathised with the 1989 protesters and was purged and placed under house arrest for opposing the crackdown.',
     'rel': 'The reformist ally he elevated and then discarded over Tiananmen.'},
]

KEY_EVENTS = [
    ('1904', 'Deng born in Sichuan', 'A landholding family in Guang’an county.'),
    ('1920–26', 'Work-study in France', 'Factory labour; becomes a communist under Zhou Enlai.'),
    ('1934–35', 'The Long March', 'Survives the epic retreat that made Mao.'),
    ('1956', 'General Secretary', 'Runs the Party machine under Mao.'),
    ('1966', 'Purged in the Cultural Revolution', 'Denounced as a “capitalist roader.”'),
    ('1978', 'Becomes paramount leader', 'The Third Plenum launches reform.'),
    ('1980', 'Special Economic Zones', 'Shenzhen opens China to the world.'),
    ('1989', 'Tiananmen crackdown', 'Backs martial law and the use of force.'),
    ('1992', 'The Southern Tour', 'Relaunches reform in his final act.'),
    ('1997', 'Death of Deng', 'Dies at 92, China remade.'),
]

MASTER = [
    {'year': '1904', 'age': 'born', 'phase': 'The Making', 'title': 'Born in Sichuan', 'desc': 'Into a China in crisis.'},
    {'year': '1920', 'age': 'age 16', 'phase': 'The Making', 'title': 'Work-study in France', 'desc': 'Becomes a communist.'},
    {'year': '1956', 'age': 'age 52', 'phase': 'Under Mao', 'title': 'General Secretary', 'desc': 'At the summit of the Party.'},
    {'year': '1966', 'age': 'age 62', 'phase': 'Purged and Reborn', 'title': 'First purge', 'desc': 'Exiled to a tractor factory.'},
    {'year': '1978', 'age': 'age 74', 'phase': 'Reform and Opening Up', 'title': 'Paramount leader', 'desc': 'Reform and Opening Up begins.'},
    {'year': '1989', 'age': 'age 84', 'phase': 'Triumph and Tragedy', 'title': 'Tiananmen', 'desc': 'The crackdown; his darkest act.'},
    {'year': '1997', 'age': 'age 92', 'phase': 'Triumph and Tragedy', 'title': 'Death of Deng', 'desc': 'China transformed.'},
]

SOURCES = [
    ('Britannica — Deng Xiaoping', 'https://www.britannica.com/biography/Deng-Xiaoping'),
    ('World History Encyclopedia — Deng Xiaoping', 'https://www.worldhistory.org/Deng_Xiaoping/'),
    ('Wikipedia — Deng Xiaoping', 'https://en.wikipedia.org/wiki/Deng_Xiaoping'),
    ('Wikipedia — Chinese economic reform', 'https://en.wikipedia.org/wiki/Chinese_economic_reform'),
    ('Wikipedia — 1989 Tiananmen Square protests and massacre', 'https://en.wikipedia.org/wiki/1989_Tiananmen_Square_protests_and_massacre'),
]

def build_meta():
    return {
        'pid': 'gm-deng.html', 'kind': 'man', 'emoji': '🧧', 'accent': AC,
        'name': 'Deng Xiaoping', 'years': '1904–1997', 'group': 'Modern Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The pragmatic architect of modern China — twice purged, twice reborn, who unleashed “Reform and Opening Up” and lifted hundreds of millions from poverty, yet also ordered the guns at Tiananmen.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'making', 'label': '1 · The Making', 'type': 'timeline',
             'intro': 'A Sichuan boy sails to France on a work-study programme, becomes a communist under Zhou Enlai, survives the Long March, and helps found the People’s Republic.', 'events': PHASE_MAKING},
            {'id': 'mao', 'label': '2 · Under Mao', 'type': 'timeline',
             'intro': 'Deng rises to General Secretary and repairs Mao’s failed economy with pragmatism — the “black cat, white cat” creed — until the Cultural Revolution casts him down as a “capitalist roader.”', 'events': PHASE_MAO},
            {'id': 'reborn', 'label': '3 · Purged and Reborn', 'type': 'timeline',
             'intro': 'Twice purged and twice rehabilitated in the last convulsions of the Mao era, Deng returns after Mao’s death to outmanoeuvre his heir and become China’s paramount leader.', 'events': PHASE_REBORN},
            {'id': 'reform', 'label': '4 · Reform and Opening Up', 'type': 'timeline',
             'intro': 'Deng remakes China — dismantling the communes, opening Shenzhen and the Special Economic Zones, and licensing wealth under “socialism with Chinese characteristics” — even as the one-child policy shows the state’s hard hand.', 'events': PHASE_REFORM},
            {'id': 'legacy', 'label': '5 · Triumph and Tragedy', 'type': 'timeline',
             'intro': 'The architect of prosperity orders the crackdown at Tiananmen, then rescues his own reforms with the 1992 Southern Tour — dying in 1997 having transformed China, and leaving a legacy that is genuinely two-sided.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; the 1989 Tiananmen events are presented factually, and famous quips attributed to Deng capture his outlook and are read as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
