# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Bhagat Singh.
The young revolutionary whose defiance and martyrdom made him an enduring icon of Indian freedom."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#c2410c'  # revolutionary saffron

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — ROOTS IN A PATRIOTIC PUNJAB
PHASE_ROOTS = [
    E('origins', '1907', 'Born into a family of freedom fighters', ['RISE', 'ORIGINS'],
      'Bhagat Singh is born in September 1907 in Banga, in Punjab’s Lyallpur district, into a patriotic Sikh Jat family already steeped in resistance to British rule — his father Kishan Singh and uncle Ajit Singh both active nationalists linked to the Ghadar movement, so that the boy grows up breathing the air of rebellion.',
      svg_row('A childhood steeped in rebellion', [
          {'n': 1, 'label': 'Born in Banga, Punjab, 1907', 'sub': 'a Sikh Jat family of the Lyallpur district', 'color': '#c2410c'},
          {'n': 2, 'label': 'Father and uncle are nationalists', 'sub': 'Kishan Singh and Ajit Singh defy the Raj', 'color': '#3730a3'},
          {'n': 3, 'label': 'Rebellion as an inheritance', 'sub': 'he grows up amid struggle against British rule', 'color': '#166534'},
      ], edge_labels=['into', 'so'], takeaway='He was born into resistance — the cause of Indian freedom was his family’s creed before it was his own.', accent=AC),
      bg='<b>Bhagat Singh</b> was born in September 1907 at Banga in the Lyallpur district of Punjab (now in Pakistan), into a Sikh family known for its opposition to colonial rule.',
      people='his father <b>Kishan Singh</b> and uncle <b>Ajit Singh</b>, both nationalist agitators; the wider Ghadar movement they moved among.',
      what='Bhagat Singh grew up in a household where <b>defiance of the British was a family tradition</b> — his father and uncle were imprisoned and exiled for their politics, and the struggle for freedom shaped his earliest memories.',
      crux='His radicalism had <b>deep roots</b> — patriotism and sacrifice were the values of the home that raised him.',
      conseq='He entered adolescence already convinced that India’s freedom was the one cause worth living and dying for.',
      matters='Conviction is often inherited before it is chosen — the child of rebels was primed to become a rebel himself.'),

    E('jallianwala', '1919', 'Jallianwala Bagh — a wound that never healed', ['TRAGEDY', 'TURNING POINT'],
      'When Bhagat Singh is barely twelve, British troops under General Dyer fire on an unarmed crowd at Jallianwala Bagh in Amritsar, killing hundreds — a massacre that, by his own account, sears itself into the boy and hardens into a lifelong resolve to drive the British from India.',
      svg_stack('The massacre that made a revolutionary', [
          {'n': 1, 'label': 'Jallianwala Bagh, April 1919', 'sub': 'Dyer’s troops fire on an unarmed crowd', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Hundreds killed in Amritsar', 'sub': 'a peaceful gathering turned to slaughter', 'color': '#78350f'},
          {'n': 3, 'label': 'A boy’s resolve is forged', 'sub': 'the young Bhagat Singh vows to fight the Raj', 'color': '#c2410c'},
      ], takeaway='The Amritsar massacre turned a schoolboy’s grief into purpose — he would spend his life avenging that day.', accent=AC),
      bg='On 13 April 1919, British Indian Army troops commanded by General <b>Reginald Dyer</b> opened fire on a peaceful gathering at Jallianwala Bagh in Amritsar, killing and wounding many hundreds.',
      people='General <b>Dyer</b>, who ordered the firing; the unarmed victims of Amritsar; the boy Bhagat Singh, then about twelve.',
      what='The <b>Jallianwala Bagh massacre</b> was a defining shock of Bhagat Singh’s youth — legend holds he visited the blood-soaked site — and it deepened his conviction that British rule was irredeemably brutal.',
      crux='The massacre convinced him that <b>the Raj answered peaceful assembly with bullets</b>, and would yield only to determined resistance.',
      conseq='The memory of Amritsar drove him steadily toward the revolutionary path over the years that followed.',
      matters='State violence can create the very rebels it means to cow — Amritsar radicalised a generation, Bhagat Singh among them.'),

    E('college', '1923–1926', 'National College and the turn to revolution', ['RISE', 'POLITICS'],
      'Enrolling at Lahore’s National College, Bhagat Singh drinks deep of European revolutionary and socialist thought — and, disillusioned when Gandhi calls off non-cooperation after Chauri Chaura, concludes that prayer and passive protest cannot win freedom, helping found the Naujawan Bharat Sabha to organise militant youth.',
      svg_row('From student to organiser', [
          {'n': 1, 'label': 'National College, Lahore', 'sub': 'reads Marx, Lenin and revolutionary history', 'color': '#3730a3'},
          {'n': 2, 'label': 'Disillusioned with passive protest', 'sub': 'Gandhi halts non-cooperation after Chauri Chaura', 'color': '#a16207'},
          {'n': 3, 'label': 'Founds Naujawan Bharat Sabha', 'sub': 'organises youth for militant struggle, 1926', 'color': '#c2410c'},
      ], edge_labels=['then', 'so'], takeaway='He chose the revolutionary road young — reading, arguing and organising toward armed struggle rather than petitions.', accent=AC),
      bg='Bhagat Singh studied at the <b>National College in Lahore</b>, founded by nationalists as an alternative to British-run institutions, where he immersed himself in radical literature.',
      people='the revolutionary writers he studied (Marx, Lenin, European anarchists); fellow students; the elders of the freedom movement.',
      what='At college he embraced <b>socialist and revolutionary ideas</b>, grew disillusioned with Gandhi’s suspension of non-cooperation after the Chauri Chaura violence, and helped found the <b>Naujawan Bharat Sabha (1926)</b> to mobilise young people.',
      crux='He decided that <b>freedom would be won by organised struggle</b>, not by moral appeal to the coloniser’s conscience.',
      conseq='This conviction led him toward the underground revolutionary networks he would soon help lead.',
      matters='Ideas find their moment — a well-read young idealist, disappointed by half-measures, turns to revolution.'),
]

# ==================================================================  PHASE 2 — THE REVOLUTIONARY CREED
PHASE_CREED = [
    E('hsra', '1928', 'Forging the HSRA — a socialist republic', ['POLITICS', 'REFORM'],
      'Bhagat Singh helps transform the Hindustan Republican Association into the Hindustan Socialist Republican Association — adding the word "Socialist" to declare that the goal was not merely to expel the British but to build a republic free of exploitation, of workers and peasants as well as of foreign rule.',
      svg_stack('Independence plus social revolution', [
          {'n': 1, 'label': 'Joins the revolutionary underground', 'sub': 'the Hindustan Republican Association', 'color': '#3730a3'},
          {'n': 2, 'label': 'Adds “Socialist” to the name, 1928', 'sub': 'the HSRA is born in Delhi', 'color': '#c2410c'},
          {'n': 3, 'label': 'A republic without exploitation', 'sub': 'freedom for workers and peasants, not just from Britain', 'color': '#166534'},
      ], takeaway='He gave the revolution a social goal — not only to end British rule, but to end exploitation of the poor.', accent=AC),
      bg='In 1928 Bhagat Singh and his comrades reorganised the <b>Hindustan Republican Association</b>, giving it a fuller revolutionary programme.',
      people='fellow revolutionaries <b>Chandra Shekhar Azad</b>, <b>Sukhdev</b>, <b>Rajguru</b> and <b>Batukeshwar Dutt</b>; the peasants and workers the movement claimed to serve.',
      what='The group became the <b>Hindustan Socialist Republican Association (HSRA)</b>, and Bhagat Singh pressed the case that independence must bring a <b>socialist republic</b> ending economic as well as colonial oppression.',
      crux='For him, <b>political freedom without social justice was hollow</b> — the revolution had to remake society, not just change rulers.',
      conseq='This vision set him apart as a thinker, not merely a fighter, within the freedom movement.',
      matters='Revolutions define themselves by their goals — Bhagat Singh insisted India’s must aim at equality, not just a change of flag.'),

    E('atheist', '1928–1930', 'The socialist and the atheist', ['POLITICS', 'IDEAS'],
      'Bhagat Singh’s convictions harden into an uncompromising rationalism — a committed socialist and outspoken atheist who rejects religion as a prop of superstition and, from his death cell, writes "Why I Am an Atheist" to explain that his disbelief springs from reason and courage, not vanity.',
      svg_compare('Two visions of the freedom struggle', {
          'head': 'Bhagat Singh’s creed', 'color': '#c2410c',
          'items': ['Socialist republic ending exploitation', 'Reason and atheism over religion', 'Militant, organised struggle', 'Freedom as social transformation'],
      }, {
          'head': 'The dominant path', 'color': '#3730a3',
          'items': ['Independence within existing order', 'Faith and spiritual appeal', 'Non-violence and mass petition', 'Freedom as transfer of power'],
      }, verdict='He fused nationalism with socialism and reason — a distinctly radical vision of what free India should become.',
         takeaway='His atheism and socialism were not poses but a whole worldview — freedom meant reason, equality and self-respect.', accent=AC),
      bg='Widely read in Marxist and rationalist thought, Bhagat Singh developed a coherent worldview that set him apart from religiously framed nationalism.',
      people='the fellow prisoner <b>Randhir Singh</b> who challenged his disbelief; the socialist and rationalist writers who shaped him.',
      what='He was a convinced <b>socialist and atheist</b>, and in 1930 wrote the essay <b>“Why I Am an Atheist”</b>, arguing that his rejection of God rested on <b>reason and independent thought</b>, not arrogance or despair.',
      crux='He held that <b>real courage was to face death without the comfort of faith</b> — and that superstition kept people in chains.',
      conseq='The essay became a landmark of Indian rationalist writing and deepened his stature as a thinker.',
      matters='He modelled intellectual honesty under ultimate pressure — refusing false comfort even at the edge of the gallows.'),

    E('lajpatrai', '1928', 'The death of Lala Lajpat Rai', ['TRAGEDY', 'TURNING POINT'],
      'When the Simon Commission is met by protest, police lathis fall on the veteran leader Lala Lajpat Rai, who dies weeks later of his injuries — and Bhagat Singh and his comrades resolve to avenge the beating of the man revered as the "Lion of Punjab" by striking back at the British police.',
      svg_row('An outrage that demanded an answer', [
          {'n': 1, 'label': 'Simon Commission protest, 1928', 'sub': 'Indians demand a voice in their own future', 'color': '#3730a3'},
          {'n': 2, 'label': 'Lala Lajpat Rai lathi-charged', 'sub': 'the “Lion of Punjab” is beaten, then dies', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The HSRA vows revenge', 'sub': 'a police officer will answer for the death', 'color': '#c2410c'},
      ], edge_labels=['met by', 'so'], takeaway='The killing of a revered elder by police lathis pushed the revolutionaries from words to lethal action.', accent=AC),
      bg='In 1928 the all-British <b>Simon Commission</b> arrived to review India’s constitution; Indians boycotted it, protesting that it contained no Indian members.',
      people='<b>Lala Lajpat Rai</b>, the revered nationalist leader; police superintendent <b>James Scott</b>, who ordered the charge; the HSRA revolutionaries.',
      what='During a Lahore protest, police <b>lathi-charged the marchers</b> and <b>Lala Lajpat Rai</b> was badly injured; he died weeks later, and Bhagat Singh’s group resolved to <b>avenge his death</b>.',
      crux='The killing convinced them that <b>the Raj respected only force</b>, and that its violence must be answered in kind.',
      conseq='Their vow of revenge led directly to the killing of a British police officer in December 1928.',
      matters='A single act of state brutality can become a spark — the death of Lajpat Rai set the revolutionaries on their fateful course.'),
]

# ==================================================================  PHASE 3 — ACTS OF DEFIANCE
PHASE_DEFIANCE = [
    E('saunders', '1928', 'The killing of Saunders', ['BATTLE', 'TURNING POINT'],
      'In revenge for Lala Lajpat Rai, Bhagat Singh and Rajguru shoot dead a young British police officer, J.P. Saunders, in Lahore in December 1928 — mistaking him for the superintendent Scott who had ordered the fatal lathi charge — and the HSRA proclaims the deed as retribution for the leader’s death.',
      svg_stack('Revenge for the Lion of Punjab', [
          {'n': 1, 'label': 'A police officer marked for death', 'sub': 'the HSRA targets those responsible', 'color': '#3730a3'},
          {'n': 2, 'label': 'Saunders shot in Lahore, Dec 1928', 'sub': 'mistaken for Superintendent Scott', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Retribution proclaimed', 'sub': 'posters declare the death avenged', 'color': '#c2410c'},
      ], takeaway='The revolutionaries answered a killing with a killing — and openly claimed it as justice for Lajpat Rai.', accent=AC),
      bg='Having vowed to avenge Lala Lajpat Rai, the HSRA plotted to kill the police superintendent <b>James Scott</b>, who had ordered the lathi charge.',
      people='<b>J.P. Saunders</b>, the officer shot; <b>Rajguru</b> and <b>Chandra Shekhar Azad</b>, who acted with Bhagat Singh; the intended target Scott.',
      what='On <b>17 December 1928</b> Bhagat Singh and Rajguru shot dead <b>Assistant Superintendent J.P. Saunders</b> outside the Lahore police headquarters — a case of mistaken identity, as they had meant to kill Scott.',
      crux='It was a deliberate act of <b>armed reprisal</b> — the revolutionaries answering colonial violence with their own.',
      conseq='A massive manhunt followed; Bhagat Singh escaped Lahore in disguise, and the killing became the core of the Lahore Conspiracy Case.',
      matters='Political violence is a double-edged act — it made the revolutionaries feared and famous, and marked them for the gallows.'),

    E('escape', '1928–1929', 'Escape in disguise', ['POLITICS', 'DRAMA'],
      'To slip through the police dragnet after the Saunders killing, Bhagat Singh cuts his hair and beard and, dressed as a European gentleman with a comrade posing as his wife, boldly walks out of Lahore by train — a daring escape that becomes part of his growing legend.',
      svg_row('Slipping through the dragnet', [
          {'n': 1, 'label': 'A city sealed by police', 'sub': 'a manhunt hunts Saunders’ killers', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Bhagat Singh cuts his hair', 'sub': 'disguised as a European sahib', 'color': '#c2410c'},
          {'n': 3, 'label': 'Walks out of Lahore by train', 'sub': 'escapes with comrades in plain sight', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='He escaped the tightest cordon by sheer nerve and disguise — the stuff of the legend that grew around him.', accent=AC),
      bg='After the Saunders shooting, the Lahore police mounted an intensive search for the killers, watching roads and railway stations.',
      people='Bhagat Singh and his comrades, including <b>Durga Devi (Durgawati Devi)</b>, who posed as his wife; <b>Rajguru</b>, travelling as a servant.',
      what='Bhagat Singh <b>cut off his hair and beard</b>, dressed as a well-to-do European, and with a comrade playing his wife <b>boarded a train and left Lahore undetected</b>, evading the manhunt.',
      crux='His escape depended on <b>audacity and quick thinking</b> — hiding in plain sight rather than fleeing into the shadows.',
      conseq='He remained free to plan his next, far more public act of defiance — the bombing of the Assembly.',
      matters='Cool nerve under danger built his reputation — a young man outwitting the empire’s police captured the popular imagination.'),

    E('assembly', '1929', 'The Assembly bombing — “to make the deaf hear”', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'On 8 April 1929 Bhagat Singh and Batukeshwar Dutt throw two harmless bombs into the Central Legislative Assembly in Delhi, shower leaflets and shout "Inquilab Zindabad" — deliberately courting arrest, since the aim, in their words, was "to make the deaf hear," to seize a public platform, not to kill.',
      svg_stack('A bomb meant to be heard, not to kill', [
          {'n': 1, 'label': 'Bombs thrown in the Assembly, 1929', 'sub': 'Bhagat Singh and Batukeshwar Dutt, 8 April', 'color': '#c2410c'},
          {'n': 2, 'label': '“To make the deaf hear”', 'sub': 'leaflets rain down; “Inquilab Zindabad!”', 'color': '#a16207'},
          {'n': 3, 'label': 'They stay to be arrested', 'sub': 'a public platform, not an escape', 'color': '#166534'},
      ], takeaway='They chose the dock over the getaway — turning arrest itself into a megaphone for the revolution.', accent=AC),
      bg='The revolutionaries opposed repressive bills before the <b>Central Legislative Assembly</b> and sought a dramatic way to protest them and spread their ideas.',
      people='<b>Batukeshwar Dutt</b>, who threw bombs alongside him; the startled legislators; the wider Indian public they aimed to reach.',
      what='On <b>8 April 1929</b> the pair threw two low-intensity bombs into an empty part of the chamber, scattered leaflets, shouted <b>“Inquilab Zindabad” (Long Live Revolution)</b>, and made no attempt to flee — courting arrest to <b>“make the deaf hear.”</b>',
      crux='The bombing was <b>propaganda by deed</b> — designed not to kill but to <b>win a courtroom platform</b> for the revolutionary cause.',
      conseq='Bhagat Singh was arrested and put on trial, exactly as intended, giving him a national stage.',
      matters='He grasped the power of the spectacle — an act of theatre, chosen over violence, that broadcast a message across India.'),
]

# ==================================================================  PHASE 4 — THE TRIAL AND THE CELL
PHASE_TRIAL = [
    E('platform', '1929–1930', 'The trial as a stage', ['POLITICS', 'IDEAS'],
      'Rather than mount a legal defence, Bhagat Singh turns his trial into a political platform — using the courtroom and the press to broadcast the ideals of the revolution, arguing that his aim was never murder but to shake a deaf regime awake and awaken his countrymen to freedom.',
      svg_row('Turning the dock into a pulpit', [
          {'n': 1, 'label': 'On trial for the bombing', 'sub': 'the courtroom becomes a public stage', 'color': '#3730a3'},
          {'n': 2, 'label': 'He argues the cause, not innocence', 'sub': 'statements printed across the country', 'color': '#c2410c'},
          {'n': 3, 'label': 'A nation begins to listen', 'sub': 'his words reach far beyond the court', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='He used the trial exactly as he intended — as a megaphone to carry the revolution to the whole country.', accent=AC),
      bg='Arrested after the Assembly bombing, Bhagat Singh faced trial in a legal system he regarded as an instrument of the colonial state.',
      people='the British judges and prosecutors; the newspapers that carried his words; the young Indians who read them.',
      what='Bhagat Singh <b>used the trial as a political platform</b>, making statements explaining the revolutionaries’ aims and refusing to plead for mercy, so that the proceedings <b>spread his ideas nationwide</b>.',
      crux='He treated the courtroom as a <b>weapon of publicity</b> — the trial’s real verdict was to be won in public opinion.',
      conseq='His conduct made him a household name and a hero to a generation of Indians.',
      matters='A defendant can turn a show-trial against its stagers — Bhagat Singh made his prosecutors amplify the very cause they meant to crush.'),

    E('hungerstrike', '1929', 'The hunger strike for prisoners’ rights', ['POLITICS', 'TRAGEDY'],
      'In jail, Bhagat Singh leads a long hunger strike demanding that Indian political prisoners be treated with dignity rather than as common criminals — a battle of endurance in which his comrade Jatindra Nath Das dies after sixty-three days, an ordeal that grips and galvanises the nation.',
      svg_stack('Endurance as a weapon', [
          {'n': 1, 'label': 'Hunger strike begins, 1929', 'sub': 'demanding rights for political prisoners', 'color': '#c2410c'},
          {'n': 2, 'label': 'Jatindra Nath Das dies', 'sub': 'after a 63-day fast, a martyr is made', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The nation is galvanised', 'sub': 'public sympathy surges behind them', 'color': '#166534'},
      ], takeaway='He fought the jailers with his own body — and the death of a comrade turned the strike into a national cause.', accent=AC),
      bg='Held under harsh conditions, Bhagat Singh and his comrades protested that Indian political prisoners were denied the treatment given to European convicts.',
      people='<b>Jatindra Nath Das</b>, who fasted to death; Bhagat Singh and his fellow strikers; the officials who force-fed them.',
      what='Bhagat Singh led a prolonged <b>hunger strike for prisoners’ rights</b>; his comrade <b>Jatindra Nath Das died after 63 days</b>, while Bhagat Singh himself fasted for many weeks, and the ordeal drew huge public attention.',
      crux='He fought a battle of <b>moral endurance</b> — willing to starve to expose the injustice of colonial imprisonment.',
      conseq='The strike, and Das’s death, won concessions and vastly increased public sympathy for the revolutionaries.',
      matters='Self-suffering can be a political force — the strikers turned their own bodies into an argument the public could not ignore.'),

    E('writings', '1929–1931', 'The prison notebook and the writings', ['IDEAS', 'LEGACY'],
      'Behind bars Bhagat Singh reads voraciously and writes — filling a jail notebook with extracts and reflections, composing essays like "Why I Am an Atheist" and messages to India’s youth — turning his cell into a study and leaving a body of thought that outlives him.',
      svg_row('A revolutionary of ideas', [
          {'n': 1, 'label': 'Reads deeply in his cell', 'sub': 'Marx, Lenin, history and philosophy', 'color': '#3730a3'},
          {'n': 2, 'label': 'Fills a prison notebook', 'sub': 'extracts and reflections on revolution', 'color': '#c2410c'},
          {'n': 3, 'label': 'Writes essays and messages', 'sub': '“Why I Am an Atheist”; letters to the youth', 'color': '#166534'},
      ], edge_labels=['and', 'so'], takeaway='He was as much thinker as fighter — leaving writings that would shape Indian radical thought for generations.', accent=AC),
      bg='Imprisonment gave Bhagat Singh time to read and write, and he used it to develop and record his political thought.',
      people='the writers and revolutionaries he studied; the comrades he debated; the young readers he addressed.',
      what='In prison he kept a famous <b>jail notebook</b>, wrote essays including <b>“Why I Am an Atheist” (1930)</b>, and composed messages urging India’s youth toward a socialist, rational revolution.',
      crux='He insisted that revolution was <b>a matter of ideas as well as action</b> — the mind had to be armed alongside the hand.',
      conseq='These writings became foundational texts of Indian revolutionary and rationalist thought.',
      matters='The pen outlasts the man — Bhagat Singh’s prison words carried his convictions far beyond the walls that held him.'),
]

# ==================================================================  PHASE 5 — MARTYRDOM AND LEGEND
PHASE_LEGEND = [
    E('conspiracy', '1930', 'The Lahore Conspiracy Case', ['POLITICS', 'TRAGEDY'],
      'The killing of Saunders is prosecuted as the Lahore Conspiracy Case before a special tribunal that proceeds even in the absence of the accused — a trial widely condemned as a travesty of justice — and Bhagat Singh, Rajguru and Sukhdev are sentenced to death by hanging.',
      svg_stack('A trial engineered to hang them', [
          {'n': 1, 'label': 'The Lahore Conspiracy Case', 'sub': 'the Saunders killing brought to trial', 'color': '#3730a3'},
          {'n': 2, 'label': 'A special tribunal, few safeguards', 'sub': 'proceedings held even without the accused', 'color': '#78350f'},
          {'n': 3, 'label': 'Death sentence for three', 'sub': 'Bhagat Singh, Rajguru and Sukhdev to hang', 'color': '#b91c1c'},
      ], takeaway='The colonial state answered his defiance with a trial built to deliver a foregone verdict — the gallows.', accent=AC),
      bg='For the Saunders killing, the British tried Bhagat Singh and his comrades under the <b>Lahore Conspiracy Case</b> before a specially constituted tribunal.',
      people='Bhagat Singh, <b>Rajguru</b> and <b>Sukhdev</b>, the condemned; the tribunal that tried them; the British authorities who sought their deaths.',
      what='The <b>special tribunal</b> pushed the case forward with limited defence rights — later Indian jurists judged it deeply unjust — and sentenced <b>Bhagat Singh, Rajguru and Sukhdev to death</b>.',
      crux='The proceedings showed the Raj determined to <b>make an example</b> of the revolutionaries, whatever the cost to legal norms.',
      conseq='Appeals and public pleas for clemency followed, but the death sentences stood.',
      matters='Justice bent to power becomes its opposite — the trial’s unfairness only sharpened Bhagat Singh’s image as a martyr.'),

    E('execution', '1931', 'Hanged at twenty-three', ['DEATH', 'TURNING POINT'],
      'On 23 March 1931, at the age of just twenty-three, Bhagat Singh is hanged in Lahore jail alongside Rajguru and Sukhdev — going to the gallows without flinching, reportedly with revolutionary slogans on his lips — a death that sends a wave of grief and anger across India.',
      svg_row('A young man walks calmly to the gallows', [
          {'n': 1, 'label': 'Hanged, 23 March 1931', 'sub': 'in Lahore, at just 23 years old', 'color': '#b91c1c'},
          {'n': 2, 'label': 'With Rajguru and Sukhdev', 'sub': 'three revolutionaries die together', 'color': '#78350f'},
          {'n': 3, 'label': 'Grief and rage across India', 'sub': 'a martyr is born; “Inquilab Zindabad”', 'color': '#c2410c'},
      ], edge_labels=['with', 'so'], takeaway='He met death without fear at twenty-three — and in dying became a more powerful symbol than he had ever been alive.', accent=AC),
      bg='Despite appeals and widespread public feeling against the sentence, the British went ahead with the execution.',
      people='<b>Rajguru</b> and <b>Sukhdev</b>, hanged beside him; the jail authorities; the millions of Indians who mourned.',
      what='On <b>23 March 1931</b> Bhagat Singh was <b>hanged in Lahore at the age of 23</b>, together with Rajguru and Sukhdev, reportedly meeting death calmly and defiantly.',
      crux='He accepted death as the <b>final act of his defiance</b> — a sacrifice offered deliberately to the cause of freedom.',
      conseq='His execution provoked mass grief and protest, and turned him into one of independent India’s most revered martyrs.',
      matters='Martyrdom can be more potent than survival — the calm courage of a 23-year-old at the gallows inspired a nation.'),

    E('legacy', '1931–', 'The enduring youth icon', ['LEGACY', 'TRIUMPH'],
      'Bhagat Singh’s early death makes him immortal — remembered as "Shaheed-e-Azam," the great martyr, his slogan "Inquilab Zindabad" echoing through India’s freedom struggle and beyond, his image and writings enduring as a symbol of fearless, principled youth for generations.',
      svg_stack('Immortal in death', [
          {'n': 1, 'label': 'Revered as “Shaheed-e-Azam”', 'sub': 'the great martyr of the freedom struggle', 'color': '#c2410c'},
          {'n': 2, 'label': '“Inquilab Zindabad” endures', 'sub': 'his slogan echoes across generations', 'color': '#a16207'},
          {'n': 3, 'label': 'An icon of fearless youth', 'sub': 'his image and writings live on', 'color': '#166534'},
      ], takeaway='He remains a living symbol — the young revolutionary who chose principle and sacrifice over safety.', accent=AC),
      bg='Bhagat Singh died at 23, but his memory swelled rather than faded, growing into one of the most potent symbols of Indian nationalism.',
      people='the generations of Indians who revere him; the youth who take him as their model; the writers and film-makers who retell his story.',
      what='Bhagat Singh became known as <b>“Shaheed-e-Azam” (the Great Martyr)</b>; his cry of <b>“Inquilab Zindabad”</b> passed into the vocabulary of protest, and his writings and image endure as an <b>emblem of principled, fearless youth</b>.',
      crux='His legend rests on <b>courage married to conviction</b> — a young man who lived and died for clearly reasoned ideals.',
      conseq='He remains among the most beloved and invoked figures of India’s independence movement.',
      matters='Some lives are amplified by their brevity — Bhagat Singh’s youth and sacrifice made him a permanent icon of resistance.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Bhagat Singh was the young revolutionary whose fearless defiance and early martyrdom made him one of the most beloved icons of India’s freedom struggle. Born into a patriotic Sikh family and scarred as a boy by the Jallianwala Bagh massacre, he turned from a well-read student into a committed socialist and atheist revolutionary — killing a British officer in revenge for Lala Lajpat Rai, bombing the Legislative Assembly “to make the deaf hear,” and turning his trial and a jail hunger strike into a stage for the cause. Hanged at just twenty-three, he became immortal. He is the ultimate study in <b>conviction, sacrifice, and the power of principled defiance.</b></p>
<div class="ov-quote">“Inquilab Zindabad!” — Long Live the Revolution<span>— Bhagat Singh’s rallying cry</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born into a family of freedom fighters and marked by Jallianwala Bagh → turns revolutionary at college and helps build the socialist HSRA → avenges Lala Lajpat Rai by killing Saunders → bombs the Assembly “to make the deaf hear” and courts arrest → turns his trial and a hunger strike into a national platform → and is hanged at twenty-three, becoming an enduring martyr and youth icon.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">✊</div><h4>Fearless defiance</h4><p>Chose arrest and the gallows over safety to broadcast his cause.</p></div>
  <div class="ov-card"><div class="i">📕</div><h4>A thinking revolutionary</h4><p>Socialist and atheist; his writings shaped Indian radical thought.</p></div>
  <div class="ov-card"><div class="i">🔥</div><h4>The power of sacrifice</h4><p>Death at 23 made him immortal — a martyr for freedom.</p></div>
  <div class="ov-card"><div class="i">🌟</div><h4>An enduring youth icon</h4><p>“Inquilab Zindabad” still echoes across generations.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Roots</b><small> 1907–1926</small><p>A patriotic Punjab, Jallianwala Bagh, the turn to revolution.</p></div>
  <div><b>2 · The Creed</b><small> 1928</small><p>The socialist HSRA, atheism, and Lajpat Rai’s death.</p></div>
  <div><b>3 · Defiance</b><small> 1928–1929</small><p>Killing Saunders, escape, and the Assembly bomb.</p></div>
  <div><b>4 · Trial &amp; Cell</b><small> 1929–1931</small><p>The trial as a stage, the hunger strike, the writings.</p></div>
  <div><b>5 · Martyrdom</b><small> 1930–</small><p>The Lahore case, the gallows, and the legend.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Batukeshwar Dutt', 'role': 'co-conspirator', 'color': '#c2410c',
     'bio': 'The revolutionary who threw bombs beside Bhagat Singh in the Central Legislative Assembly on 8 April 1929 and stood trial with him.',
     'rel': 'His comrade in the Assembly bombing and courtroom protest.'},
    {'name': 'Chandra Shekhar Azad', 'role': 'HSRA leader', 'color': '#3730a3',
     'bio': 'The fearless commander of the Hindustan Socialist Republican Association who worked closely with Bhagat Singh and died fighting police in 1931.',
     'rel': 'His fellow leader and comrade in the revolutionary underground.'},
    {'name': 'Sukhdev & Rajguru', 'role': 'fellow martyrs', 'color': '#b91c1c',
     'bio': 'The two comrades condemned in the Lahore Conspiracy Case and hanged alongside Bhagat Singh on 23 March 1931.',
     'rel': 'The comrades who went to the gallows with him.'},
    {'name': 'Lala Lajpat Rai', 'role': 'martyred leader', 'color': '#a16207',
     'bio': 'The revered “Lion of Punjab,” fatally injured in a police lathi charge in 1928 — the death Bhagat Singh set out to avenge.',
     'rel': 'The leader whose death spurred the killing of Saunders.'},
    {'name': 'Mahatma Gandhi', 'role': 'rival strategy', 'color': '#166534',
     'bio': 'The apostle of non-violent struggle whose calling-off of non-cooperation helped push Bhagat Singh toward the revolutionary path.',
     'rel': 'The champion of the non-violent path he chose to reject.'},
]

KEY_EVENTS = [
    ('1907', 'Bhagat Singh born', 'A patriotic Sikh family in Punjab.'),
    ('1919', 'Jallianwala Bagh massacre', 'Sears the young boy’s conscience.'),
    ('1926', 'Naujawan Bharat Sabha', 'Organises militant youth in Lahore.'),
    ('1928', 'HSRA founded', 'Adds “Socialist” to the revolution’s goal.'),
    ('1928', 'Death of Lala Lajpat Rai', 'A lathi charge kills the leader.'),
    ('1928', 'Saunders killed', 'Revenge for Lajpat Rai in Lahore.'),
    ('1929', 'Assembly bombing', '“To make the deaf hear”; deliberate arrest.'),
    ('1929', 'Hunger strike', 'For prisoners’ rights; Jatindra Nath Das dies.'),
    ('1931', 'Hanged at 23', 'With Rajguru and Sukhdev; a martyr is born.'),
]

MASTER = [
    {'year': '1907', 'age': 'born', 'phase': 'Roots', 'title': 'Born in Banga', 'desc': 'A family of freedom fighters.'},
    {'year': '1919', 'age': 'age 12', 'phase': 'Roots', 'title': 'Jallianwala Bagh', 'desc': 'A wound that never healed.'},
    {'year': '1928', 'age': 'age 21', 'phase': 'The Creed', 'title': 'HSRA & Saunders', 'desc': 'Revenge for Lajpat Rai.'},
    {'year': '1929', 'age': 'age 21', 'phase': 'Defiance', 'title': 'Assembly bombing', 'desc': 'To make the deaf hear.'},
    {'year': '1929', 'age': 'age 22', 'phase': 'Trial & Cell', 'title': 'Hunger strike', 'desc': 'Prisoners’ rights; Das dies.'},
    {'year': '1931', 'age': 'age 23', 'phase': 'Martyrdom', 'title': 'Hanged in Lahore', 'desc': 'Becomes an enduring icon.'},
]

SOURCES = [
    ('Britannica — Bhagat Singh', 'https://www.britannica.com/biography/Bhagat-Singh'),
    ('Wikipedia — Bhagat Singh', 'https://en.wikipedia.org/wiki/Bhagat_Singh'),
    ('New World Encyclopedia — Bhagat Singh', 'https://www.newworldencyclopedia.org/entry/Bhagat_Singh'),
    ('Britannica — Jallianwala Bagh Massacre', 'https://www.britannica.com/event/Jallianwala-Bagh-Massacre'),
    ('Marxists Internet Archive — Why I Am an Atheist', 'https://www.marxists.org/archive/bhagat-singh/1930/12/05.htm'),
]

def build_meta():
    return {
        'pid': 'gm-bhagatsingh.html', 'kind': 'man', 'emoji': '✊', 'accent': AC,
        'name': 'Bhagat Singh', 'years': '1907–1931', 'group': 'Independence & Nation-Building',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The young Indian revolutionary whose fearless defiance — killing Saunders, bombing the Assembly, and going calmly to the gallows at twenty-three — made him an enduring martyr and icon of the freedom struggle.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'roots', 'label': '1 · Roots', 'type': 'timeline',
             'intro': 'Born into a patriotic Sikh family and scarred as a boy by the Jallianwala Bagh massacre, he turns from student to revolutionary at Lahore’s National College.', 'events': PHASE_ROOTS},
            {'id': 'creed', 'label': '2 · The Creed', 'type': 'timeline',
             'intro': 'He helps build the socialist HSRA and hardens into an atheist revolutionary — until the killing of Lala Lajpat Rai demands an answer.', 'events': PHASE_CREED},
            {'id': 'defiance', 'label': '3 · Defiance', 'type': 'timeline',
             'intro': 'He avenges Lajpat Rai by killing Saunders, escapes Lahore in disguise, and then bombs the Assembly “to make the deaf hear,” courting arrest.', 'events': PHASE_DEFIANCE},
            {'id': 'trial', 'label': '4 · Trial & Cell', 'type': 'timeline',
             'intro': 'From the dock and the death cell he wages his greatest campaign — turning his trial into a stage, leading a hunger strike, and writing.', 'events': PHASE_TRIAL},
            {'id': 'legend', 'label': '5 · Martyrdom', 'type': 'timeline',
             'intro': 'Condemned in the Lahore Conspiracy Case, he is hanged at twenty-three with Rajguru and Sukhdev — and in death becomes an immortal icon of Indian freedom.', 'events': PHASE_LEGEND,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; some episodes (such as the escape from Lahore) survive partly through revolutionary tradition and are read as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
