# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Akbar the Great."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#6d28d9'  # Mughal imperial violet

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_panipat():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1556 · a 13-year-old’s throne saved by a single arrow</text>'
    boxes=[(40,'#7f1d1d','A lost empire','Humayun dies; the Hindu general Hemu holds Delhi'),
           (270,'#6d28d9','Panipat, 1556','the boy-king’s army faces Hemu’s larger force'),
           (500,'#166534','An arrow decides it','Hemu is struck in the eye; his army collapses')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">The Mughal restoration hung on a chance shot — then Akbar spent 49 years making it permanent.</text>'
    return _wrap(W, H, 'Second Panipat — reclaiming a lost empire', _tk(b, W, H, 'He inherited only a claim; a single battle — and a lucky arrow — turned it into a throne.'), '', AC)

def svg_rajput():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">how he turned India’s fiercest warriors from enemies into pillars</text>'
    b += '<rect x="40" y="60" width="300" height="82" rx="12" fill="#f5f3ff" stroke="#6d28d9" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#6d28d9">Alliance, not just conquest</text>'
    s1,_=_tspans(54,100,'marries Rajput princesses; makes their kings his greatest generals and governors',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="82" rx="12" fill="#dcfce7" stroke="#166534" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#166534">Abolish the jizya, 1564</text>'
    s2,_=_tspans(394,100,'ends the tax on non-Muslims and the pilgrim tax — rule for all, not one faith',10,'#166534',600,12,44); b+=s2
    b += '<line x1="340" y1="101" x2="378" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He built a Muslim empire that Hindus helped to run — the secret of its stability and reach.</text>'
    return _wrap(W, H, 'The Rajput policy — inclusion as strategy', _tk(b, W, H, 'He made the conquered into partners — winning by alliance and fairness what force alone could never hold.'), '', AC)

def svg_mansab():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the machine that ran an empire of a hundred million</text>'
    rows=[('#6d28d9','Mansabdari ranks','every officer holds a numbered rank fixing his pay and troops'),
          ('#0369a1','Todar Mal’s revenue reform','land surveyed and taxed fairly by measured yield (zabt)'),
          ('#166534','A salaried, loyal state','officials paid and rotated — power flows to the throne')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="42" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+21}" r="9" fill="{c}"/><text x="62" y="{y+25}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+18}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+34,s,9.3,'#5b6472',500,11,78); b+=ss
        y+=50
    return _wrap(W, H, 'The administrative genius', _tk(b, W, H, 'His empire lasted because he built a fair, centralised bureaucracy — not just because he won battles.'), '', AC)

def svg_ibadat():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">an illiterate emperor’s lifelong search for truth</text>'
    boxes=[(40,'#6d28d9','The House of Worship','scholars of every faith debate before him at Fatehpur Sikri'),
           (270,'#0369a1','Sulh-i-kul','he adopts “universal peace” — tolerance as state policy'),
           (500,'#b45309','Din-i-Ilahi','a small syncretic order drawing on many faiths')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He could not read a word — yet hosted the boldest religious debates of the age and preached tolerance.</text>'
    return _wrap(W, H, 'Sulh-i-kul — the House of Worship', _tk(b, W, H, 'He treated faith as a question to be explored, not a weapon — centuries ahead of his time.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE ORPHAN HEIR
PHASE_RISE = [
    E('exile', '1542–1556', 'Born to a father with no throne', ['RISE'],
      'He is born in the desert of Sindh while his father Humayun is a hunted fugitive who has already lost the empire that Babur won. Akbar’s childhood is one of flight and exile — and he grows up unable even to read.',
      svg_stack('An inheritance of loss', [
          {'n': 1, 'label': 'Grandson of Babur', 'sub': 'Timur’s and Genghis’s line; the Mughal founder', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Born in exile, 1542', 'sub': 'while Humayun flees, having lost the empire', 'color': '#b45309'},
          {'n': 3, 'label': 'Never learns to read', 'sub': 'yet grows intensely curious and able', 'color': '#166534'},
      ], takeaway='He was born with a dynasty’s claim but no realm — and an illiteracy he turned into a hunger to learn by ear.', accent=AC),
      bg='<b>Babur</b> had founded the <b>Mughal Empire</b> in 1526, but his son <b>Humayun</b> lost it to <b>Sher Shah Suri</b> and fled into exile in Persia. Akbar was born in <b>1542</b> during that flight.',
      people='His grandfather <b>Babur</b>; his father <b>Humayun</b>, the exiled emperor; his guardian and general <b>Bairam Khan</b>.',
      what='Akbar spent his early years amid his family’s exile and reconquest. Remarkably, he <b>never learned to read or write</b> — yet became one of history’s most curious and cultured rulers, absorbing everything through others reading aloud.',
      crux='He inherited a <b>claim without a country</b>, and an unusual mind: illiterate but ferociously intelligent, learning through listening and conversation rather than books.',
      conseq='When Humayun briefly regained Delhi (1555) and then died in 1556, the throne fell to a thirteen-year-old boy.',
      matters='Great ability can take unexpected forms. Akbar could not read a word, yet built one of the best-run empires of his age.'),

    E('humayun', '1555–1556', 'A father regains a throne — then falls down the stairs', ['RISE', 'TRAGEDY', 'TURNING POINT'],
      'After fifteen years in exile, Akbar’s father Humayun finally recovers the Delhi throne — only to die months later tumbling down his library stairs, leaving the empire to a boy of thirteen before it is even secure.',
      svg_stack('An inheritance won and lost in a year', [
          {'n': 1, 'label': 'Humayun retakes Delhi, 1555', 'sub': 'the exiled emperor reclaims his father Babur’s throne', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Dies on the stairs, Jan 1556', 'sub': 'a fatal fall while descending his library', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Akbar inherits at 13', 'sub': 'a fragile, half-reconquered empire and a child ruler', 'color': '#a16207'},
      ], takeaway='The empire fell to Akbar by sudden accident, before it was truly won — everything still had to be secured.', accent=AC),
      bg='<b>Humayun</b>, Akbar’s father, had lost the Mughal throne to the Afghan Sher Shah and spent years in exile in Persia before mounting a comeback.',
      people='<b>Humayun</b>, the restored then suddenly dead emperor; the regent <b>Bairam Khan</b>; the Afghan and Hindu powers still contesting north India.',
      what='Humayun <b>recaptured Delhi in 1555</b> but <b>died in January 1556</b> after falling down his library stairs. The half-reconquered empire passed to the thirteen-year-old Akbar under a regent.',
      crux='Akbar’s reign began by <b>accident and in danger</b> — inheriting not a secure realm but a contested claim that had to be fought for.',
      conseq='Within months the boy-king faced the battle of Panipat to keep even Delhi — the true founding of his rule came by his own effort, not inheritance.',
      matters='What you inherit by chance you must still earn by deed — a throne handed over is not a throne secured.'),

    E('panipat', '1556', 'Crowned at thirteen — and a battle to keep it', ['BATTLE', 'TURNING POINT'],
      'His father dies suddenly and Akbar is crowned at thirteen — with the Mughal hold on India collapsing. At Panipat his guardian faces the Hindu general Hemu, and the whole restoration turns on a single arrow that finds Hemu’s eye.',
      svg_panipat(),
      bg='When Humayun died in 1556, the Mughal position was desperate: the Hindu general <b>Hemu</b> had seized Delhi and Agra and proclaimed himself ruler.',
      people='The boy-king <b>Akbar</b>; his regent and general <b>Bairam Khan</b>, who directed the campaign; the general <b>Hemu</b>.',
      what='At the <b>Second Battle of Panipat (1556)</b>, Bairam Khan led Akbar’s army against Hemu’s larger force. Hemu was winning until an <b>arrow struck him in the eye</b>; leaderless, his army broke, and the Mughals reclaimed Delhi.',
      crux='The restoration hung on <b>chance and the steadiness of his regent</b> — but victory gave the boy Akbar the base from which to build, over the next half-century, a durable empire.',
      conseq='The Mughal Empire was saved; Bairam Khan governed as regent while Akbar grew toward taking real power himself.',
      matters='Empires can turn on a single moment of luck. Panipat gave Akbar the throne; what he did with it over 49 years made him great.'),

    E('power', '1560–1562', 'Seizing power from his own guardians', ['POLITICS', 'TURNING POINT'],
      'As a teenager he throws off the domineering regent Bairam Khan, then breaks the grip of the palace faction around his foster-mother — most dramatically by having the overmighty Adham Khan hurled from the palace ramparts. By eighteen he rules in fact as well as name.',
      svg_row('Becoming his own master', [
          {'n': 1, 'label': 'Dismisses Bairam Khan', 'sub': 'ends the regency in 1560', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Breaks the harem party', 'sub': 'the faction around his foster-mother', 'color': '#b45309'},
          {'n': 3, 'label': 'Adham Khan cast down', 'sub': 'the overmighty favourite thrown from the walls', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He served notice, young and hard, that no regent or faction would rule in his name.', accent=AC),
      bg='Even after Panipat, real power lay with the regent <b>Bairam Khan</b> and, later, a court faction around Akbar’s foster-mother <b>Maham Anga</b> and her son <b>Adham Khan</b>.',
      people='The regent <b>Bairam Khan</b>; the foster-mother <b>Maham Anga</b>; her son <b>Adham Khan</b>, executed on Akbar’s order.',
      what='In <b>1560</b> Akbar dismissed <b>Bairam Khan</b>, and in <b>1562</b> he crushed the palace faction — famously having the insubordinate <b>Adham Khan thrown from the ramparts</b> of the fort — asserting personal control of the state.',
      crux='He demonstrated early the <b>ruthless will to hold power himself</b>, refusing to be a figurehead for regents or relatives.',
      conseq='From his late teens Akbar ruled directly, free to launch the conquests and reforms that would define his reign.',
      matters='Inherited power must still be seized. Akbar’s early ruthlessness cleared the way for the wise ruler he would become.'),
]

# ==================================================================  PHASE 2 — THE CONQUEROR
PHASE_CONQUER = [
    E('malwa', '1561', 'Malwa — a first conquest, and a lesson in restraint', ['BATTLE', 'TRAGEDY', 'TURNING POINT'],
      'His first great conquest as a young ruler comes with an ugly shock: his own general Adham Khan storms Malwa and carries out a needless massacre — and Akbar’s furious repudiation of the atrocity signals, early, the kind of ruler he means to be.',
      svg_row('Conquest — and a repudiated massacre', [
          {'n': 1, 'label': 'Malwa conquered, 1561', 'sub': 'a rich central-Indian sultanate taken', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Adham Khan’s massacre', 'sub': 'his general slaughters captives needlessly', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Akbar recoils', 'sub': 'he is enraged; later destroys the overmighty Adham Khan', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='His first big conquest doubled as a moral marker — he angrily rejected the gratuitous slaughter his own general committed.', accent=AC),
      bg='One of Akbar’s earliest conquests was the wealthy sultanate of <b>Malwa</b> in central India, entrusted to his foster-brother <b>Adham Khan</b>.',
      people='The general <b>Adham Khan</b>, whose brutality Akbar came to loathe; the massacred people of Malwa.',
      what='In <b>1561</b> Akbar’s forces conquered <b>Malwa</b>, but <b>Adham Khan carried out a gratuitous massacre</b>. Akbar was <b>furious</b>, an early sign of a temperament that would later favour clemency — and he soon eliminated the insubordinate Adham Khan.',
      crux='Even as a young conqueror he showed an <b>instinct against needless cruelty</b> that would grow into his signature policy of tolerance and reconciliation.',
      conseq='Malwa was absorbed, and Akbar’s reaction foreshadowed the more humane style of rule that set him apart.',
      matters='The seeds of Akbar’s greatness show early: a conqueror who was genuinely troubled by gratuitous slaughter.'),

    E('artillery', '1560s–1600', 'The gunpowder emperor — cannon, matchlocks and elephants', ['BATTLE', 'REFORM'],
      'Akbar wins his empire not just with cavalry but with firepower: heavy siege guns that crack Rajput fortresses, ranks of matchlock infantry, and war elephants — and he takes a personal, hands-on interest in designing and improving his weapons.',
      svg_row('An army built around firepower', [
          {'n': 1, 'label': 'Heavy siege artillery', 'sub': 'great guns to breach the mightiest hill-forts', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Matchlock infantry', 'sub': 'disciplined gunners backing the traditional horse', 'color': '#7c3aed'},
          {'n': 3, 'label': 'A hands-on tinkerer', 'sub': 'Akbar personally designs and improves firearms', 'color': '#a16207'},
      ], edge_labels=['plus', 'and'], takeaway='He fused steppe cavalry tradition with modern gunpowder — and took a craftsman’s interest in his weapons.', accent=AC),
      bg='Sixteenth-century Indian warfare was being transformed by gunpowder. Akbar, heir to a Timurid-Mongol cavalry tradition, embraced the new firepower wholeheartedly.',
      people='his artillerymen and gun-founders; the Rajput defenders of great forts like Chittorgarh; the craftsmen whose work he personally supervised.',
      what='Akbar deployed <b>heavy siege cannon</b>, large corps of <b>matchlock musketeers</b>, and <b>war elephants</b>, and — famously curious and mechanically minded — <b>personally designed and refined firearms</b> and gun-carriages.',
      crux='He understood that <b>gunpowder was decisive</b> and mastered it thoroughly, rather than clinging to cavalry tradition alone.',
      conseq='His firepower reduced the great Rajput hill-forts and underpinned the conquests that built the Mughal Empire.',
      matters='Winners embrace the decisive new technology of their age — and the best leaders understand their tools intimately.'),

    E('rajputana', '1568', 'Rajputana and the storm of Chittorgarh', ['BATTLE', 'TRIUMPH', 'TRAGEDY'],
      'He turns to the proud warrior kingdoms of Rajputana. Most he wins by alliance — but the defiant fortress of Chittorgarh he takes by storm, in a brutal siege whose bloody end teaches both his enemies and himself hard lessons.',
      svg_row('Breaking and befriending the Rajputs', [
          {'n': 1, 'label': 'Targets Rajputana', 'sub': 'the fierce Rajput kingdoms of the northwest', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Storm of Chittorgarh', 'sub': 'a brutal siege ends in a bloody sack, 1568', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Most Rajputs allied', 'sub': 'others join him as generals and governors', 'color': '#166534'},
      ], edge_labels=['then', 'yet'], takeaway='He showed he could crush resistance utterly — which made his offers of honourable alliance all the more compelling.', accent=AC),
      bg='The <b>Rajputs</b> of northwestern India were fierce, proud Hindu warrior clans — the toughest obstacle to Mughal dominance, and its greatest potential asset.',
      people='The defenders of <b>Chittorgarh</b> (a Mewar stronghold); the Rajput rulers who chose alliance, like those of <b>Amber</b>.',
      what='Akbar subdued Rajputana through the 1560s. He took the great fortress of <b>Chittorgarh</b> by storm in <b>1568</b> after a fierce siege ending in a bloody sack — but pursued alliance with most other Rajput houses.',
      crux='He combined <b>overwhelming force against defiance with generous terms for cooperation</b>, making submission far more attractive than resistance.',
      conseq='Rajput manpower and loyalty became a foundation of Mughal power; Rajput princes rose to the highest ranks of his service.',
      matters='The wisest conquerors leave a golden bridge. Akbar’s mix of hard war and honourable alliance turned deadly rivals into partners.'),

    E('gujarat', '1572–1573', 'Gujarat and the legendary forced march', ['BATTLE', 'TRIUMPH'],
      'He conquers the wealthy trading province of Gujarat — then, when it rebels, makes one of history’s great forced marches, covering the distance to Ahmedabad in eleven days with a small force and crushing the revolt before the rebels believe he could possibly have arrived.',
      svg_row('Conquest, revolt, and a lightning return', [
          {'n': 1, 'label': 'Conquers Gujarat', 'sub': 'the rich coastal trade province, 1573', 'color': '#6d28d9'},
          {'n': 2, 'label': 'It rebels behind him', 'sub': 'as soon as he leaves, revolt breaks out', 'color': '#b45309'},
          {'n': 3, 'label': 'The 11-day march', 'sub': 'races back with a small force and shatters the rebels', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He answered a rebellion with a march so fast the rebels could not believe their eyes.', accent=AC),
      bg='<b>Gujarat</b>, with its ports and trade, was a rich prize. Akbar conquered it in 1573 — but rebellion flared the moment his main army withdrew.',
      people='The Mirza rebels of Gujarat; Akbar and the small, fast column he led back.',
      what='Learning of the revolt, Akbar led a <b>picked force on a famous forced march</b> — covering the long distance to <b>Ahmedabad in about eleven days</b> — and defeated the far larger rebel force by sheer speed and surprise.',
      crux='He grasped that <b>speed can substitute for numbers</b>: arriving before the enemy thought possible, he shattered them psychologically before the fight.',
      conseq='Gujarat was secured, adding immense trade wealth; the exploit became legendary and cemented his military reputation.',
      matters='Audacity and speed win wars. Akbar’s eleven-day march is a classic of turning tempo into a weapon.'),

    E('ranthambore', '1569', 'Ranthambore and Kalinjar — finishing Rajputana', ['BATTLE', 'TRIUMPH'],
      'After Chittorgarh, he takes the two other great Rajput fortresses — mighty Ranthambore and Kalinjar — completing the subjugation of Rajputana and convincing most of its remaining kings that alliance with the Mughals is wiser than annihilation.',
      svg_row('Completing the conquest of the Rajputs', [
          {'n': 1, 'label': 'Storms Ranthambore, 1569', 'sub': 'one of India’s strongest hill-fortresses falls', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Takes Kalinjar', 'sub': 'another great fortress submits', 'color': '#b45309'},
          {'n': 3, 'label': 'Rajputs choose alliance', 'sub': 'most houses now bind themselves to him', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='By taking the last great Rajput strongholds he made submission-by-alliance the obvious choice for the rest.', accent=AC),
      bg='After the bloody fall of Chittorgarh, two other formidable Rajput fortresses still stood: <b>Ranthambore</b> and <b>Kalinjar</b>.',
      people='The Rajput defenders; the houses (like Amber) that chose alliance and rose in Mughal service.',
      what='In <b>1569</b> Akbar captured the great fortress of <b>Ranthambore</b> and then <b>Kalinjar</b>, effectively completing the conquest of <b>Rajputana</b> and cementing the pattern of Rajput houses joining him as allies and generals.',
      crux='He paired <b>irresistible force against holdouts with honourable partnership for those who joined</b> — completing the strategy begun at Chittorgarh.',
      conseq='Rajputana was secured as a pillar of Mughal power, its warriors now serving the empire.',
      matters='Finishing the job matters. By taking the last strongholds, Akbar turned Rajputana from a threat into a foundation.'),

    E('haldighati', '1576', 'The Rana who never bowed — Haldighati', ['BATTLE', 'TRIUMPH', 'TRAGEDY'],
      'Not everyone submits: Maharana Pratap of Mewar refuses alliance and fights on, and at the fierce battle of Haldighati Akbar’s army — led by the Rajput Man Singh — defeats him, yet Pratap escapes to wage a lifelong guerrilla resistance, becoming a legend of defiance against the very empire Akbar built on Rajput partnership.',
      svg_row('The great exception to the Rajput peace', [
          {'n': 1, 'label': 'Maharana Pratap refuses', 'sub': 'Mewar’s ruler will not submit to the Mughals', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Haldighati, 1576', 'sub': 'a fierce battle; Pratap defeated but escapes', 'color': '#6d28d9'},
          {'n': 3, 'label': 'Endless resistance', 'sub': 'Pratap fights a guerrilla war for the rest of his life', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='One Rajput prince’s refusal to submit became an enduring legend — the shadow-side of Akbar’s policy of alliance.', accent=AC),
      bg='While most Rajput houses allied with Akbar, <b>Maharana Pratap</b> of <b>Mewar</b> refused, choosing endless resistance over submission.',
      people='<b>Maharana Pratap</b>, the defiant Rana; <b>Raja Man Singh</b>, the Rajput general who led Akbar’s army against him.',
      what='At the <b>Battle of Haldighati (1576)</b>, Akbar’s army — commanded by the Rajput <b>Man Singh</b> — defeated Pratap, but the Rana <b>escaped and waged a lifelong guerrilla war</b>, never accepting Mughal rule; he became a celebrated symbol of resistance.',
      crux='Haldighati captures the <b>limit of Akbar’s inclusive strategy</b>: it won over most, but not all — and the one who refused became immortal.',
      conseq='Mewar remained a thorn for years; Pratap’s defiance became legendary in Indian memory.',
      matters='Every policy has its exception. Pratap’s resistance is the heroic counter-story to Akbar’s otherwise successful embrace of the Rajputs.'),

    E('bengalrevolt', '1580–1581', 'The great revolt — the empire’s severest test', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'His boldest reforms provoke the gravest crisis of his reign: a huge rebellion erupts across the east and even backs his own brother as a rival emperor, partly in reaction to his religious liberalism — and Akbar, for a moment in real danger, holds his nerve and crushes it, emerging stronger and more radical.',
      svg_row('Rebellion — and survival', [
          {'n': 1, 'label': 'Revolt sweeps the east', 'sub': 'Bengal and Bihar rise; nobles and clerics resist', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'His brother made a rival', 'sub': 'rebels back Mirza Hakim as emperor', 'color': '#b45309'},
          {'n': 3, 'label': 'Akbar crushes it', 'sub': 'holds his nerve; defeats the rebellion by 1581', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='The gravest threat of his reign — fed by backlash to his reforms — he faced down and survived, more powerful than before.', accent=AC),
      bg='Around <b>1580–81</b>, resentment at Akbar’s centralising reforms and religious liberalism fuelled a massive <b>revolt</b> in the eastern provinces, some rebels proclaiming his half-brother <b>Mirza Hakim</b> emperor.',
      people='The rebellious nobles and orthodox clerics; his half-brother <b>Mirza Hakim</b> of Kabul; the loyal commanders who held the line.',
      what='A widespread <b>rebellion across Bengal and Bihar</b>, backed by conservative reaction to his policies and by his brother’s claim, briefly put Akbar in real danger — but he <b>held firm and suppressed it</b> by 1581.',
      crux='He weathered the <b>backlash to his own boldness</b> without retreating, proving his throne — and his reforms — could survive determined opposition.',
      conseq='Victory left Akbar more secure and, if anything, more willing to pursue his radical religious and administrative vision.',
      matters='Bold reform breeds backlash. Akbar’s survival of the great revolt shows the resilience that let him keep remaking the empire.'),

    E('empire', '1574–1601', 'Assembling the empire — Bengal to the Deccan', ['BATTLE', 'TRIUMPH'],
      'Over three decades he binds a subcontinent together: Bengal in the east, Kabul and Kashmir in the north, Sindh in the west, and finally a push into the Deccan in the south — forging the largest, richest and best-run Indian empire since Ashoka.',
      svg_stack('A subcontinent brought under one rule', [
          {'n': 1, 'label': 'East and north', 'sub': 'Bengal, Kabul, Kashmir (1586) added', 'color': '#6d28d9'},
          {'n': 2, 'label': 'West', 'sub': 'Sindh and the frontier secured', 'color': '#b45309'},
          {'n': 3, 'label': 'Into the Deccan', 'sub': 'Ahmadnagar and Asirgarh (1601) in the south', 'color': '#166534'},
      ], takeaway='By 1600 he ruled the richest empire in the world — a state stretching across nearly all of northern India.', accent=AC),
      bg='Having secured the northwest, Akbar steadily expanded in every direction, absorbing independent sultanates and kingdoms into a single imperial structure.',
      people='His great generals, many of them Rajputs, like <b>Raja Man Singh</b>; the rulers of Bengal, Kashmir and the Deccan sultanates.',
      what='Akbar conquered <b>Bengal</b>, <b>Kabul</b>, <b>Kashmir (1586)</b>, <b>Sindh</b>, and pushed into the <b>Deccan</b> (taking Ahmadnagar’s fort and <b>Asirgarh in 1601</b>), assembling an empire covering most of the subcontinent.',
      crux='His conquests were paired with <b>rapid integration</b> — new lands were folded into his administrative and revenue systems, not merely occupied.',
      conseq='The Mughal Empire became the wealthiest and most populous state of its era, a superpower of the early-modern world.',
      matters='Building an empire is one thing; making it cohere is another. Akbar did both, which is why his lasted where others crumbled.'),

    E('deccan', '1595–1601', 'Into the Deccan — Chand Bibi and the fall of Asirgarh', ['BATTLE', 'TRIUMPH', 'TRAGEDY'],
      'Turning south at last, Akbar’s armies push into the Deccan sultanates — where the regent queen Chand Bibi heroically defends Ahmadnagar against them — and the great fortress of Asirgarh finally falls, more to gold than to guns, extending the empire deep into the peninsula.',
      svg_stack('The unfinished conquest of the south', [
          {'n': 1, 'label': 'Ahmadnagar besieged, 1595', 'sub': 'Chand Bibi rallies the defence against the Mughals', 'color': '#6d28d9'},
          {'n': 2, 'label': 'A fierce, drawn-out struggle', 'sub': 'the Deccan resists; the frontier stays contested', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Asirgarh taken by bribery, 1601', 'sub': 'the great fort falls to gold where guns had stalled', 'color': '#a16207'},
      ], takeaway='He extended the empire southward but never fully subdued the Deccan — a frontier that would consume his descendants.', accent=AC),
      bg='Beyond the Mughal heartland lay the independent <b>Deccan sultanates</b>. In his last decade Akbar sent his armies south to bring them under imperial control.',
      people='<b>Chand Bibi</b>, the queen-regent who defended Ahmadnagar; Akbar’s son <b>Prince Murad</b> and other commanders; the Deccan rulers who resisted.',
      what='Mughal forces besieged <b>Ahmadnagar</b> (defended memorably by <b>Chand Bibi</b>) and, in 1601, took the formidable fortress of <b>Asirgarh</b> largely through <b>bribery</b> — pushing the empire into the northern Deccan.',
      crux='He learned that the Deccan was a <b>tougher, more distant frontier</b> — subdued only partially, and as much by money as by arms.',
      conseq='The Deccan remained unfinished business; its later conquest would obsess and ultimately exhaust his great-grandson Aurangzeb.',
      matters='Some frontiers resist even the greatest power — overreach into them can drain an empire for generations.'),

    E('kandahar', '1585–1598', 'Guarding the northwest — Lahore, Kabul and Kandahar', ['BATTLE', 'POLITICS'],
      'For over a decade he shifts his capital to Lahore to manage the dangerous northwest frontier — securing Kabul on his brother’s death, taking the great strategic city of Kandahar, and holding the passes against Uzbek and Persian rivals — the unglamorous but vital work of defending an empire’s edges.',
      svg_row('Holding the empire’s dangerous frontier', [
          {'n': 1, 'label': 'Capital to Lahore', 'sub': 'moves west to manage the northwest, 1585', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Secures Kabul and the passes', 'sub': 'takes Kabul; guards against Uzbeks', 'color': '#b45309'},
          {'n': 3, 'label': 'Kandahar taken, 1595', 'sub': 'the key strategic city secured from Persia', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He spent years personally guarding the empire’s most dangerous frontier — the vital, unglamorous work of defence.', accent=AC),
      bg='The <b>northwest frontier</b> — Kabul, the passes, and the strategic city of <b>Kandahar</b> — was the empire’s most exposed edge, contested with Uzbeks and Safavid Persia.',
      people='His half-brother <b>Mirza Hakim</b> of Kabul; the Uzbek and Persian rivals; the frontier garrisons.',
      what='Akbar moved his capital to <b>Lahore (1585–1598)</b> to manage the frontier, <b>secured Kabul</b> after Mirza Hakim’s death, and <b>took Kandahar (1595)</b>, stabilising the northwest against Uzbek and Persian pressure.',
      crux='He understood that empires are lost at their <b>frontiers</b>, and committed years of personal attention to defending the vulnerable northwest.',
      conseq='The frontier held, protecting the Indian heartland; Kandahar would remain a contested prize for his successors.',
      matters='Great builders mind their borders. Akbar’s long frontier vigil was as essential to the empire as his famous conquests.'),
]

# ==================================================================  PHASE 3 — THE STATESMAN
PHASE_STATE = [
    E('women', '1556–1605', 'The women of the house — mothers, a regent, and a chronicler', ['POLITICS', 'REFORM'],
      'Akbar’s empire was shaped by formidable women: the mother who steadied his exile-born childhood, the foster-mother whose faction nearly ran the state, the Rajput wife who bore his heir, and the aunt who led the royal pilgrimage and wrote the age’s only memoir by a Mughal woman.',
      svg_stack('The women behind the throne', [
          {'n': 1, 'label': 'Hamida Banu, the mother', 'sub': 'anchor of his exile childhood and revered dowager', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Maham Anga, the foster-mother', 'sub': 'her faction’s “petticoat government” gripped the young reign', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Gulbadan, the chronicler', 'sub': 'his aunt led the royal hajj and wrote the Humayun-nama', 'color': '#16a34a'},
      ], takeaway='The Mughal court’s women were political actors and authors — not ornaments — in Akbar’s story.', accent=AC),
      bg='Mughal royal women wielded real influence over politics, patronage and culture. Several shaped Akbar’s reign directly.',
      people='<b>Hamida Banu Begum</b>, his mother; <b>Maham Anga</b>, foster-mother and head of a court faction; <b>Mariam-uz-Zamani</b>, his Rajput wife and mother of Jahangir; <b>Gulbadan Begum</b>, his aunt and biographer.',
      what='His mother steadied the dynasty; <b>Maham Anga’s</b> faction dominated the early reign until Akbar broke it; his <b>Rajput wife</b> bore his heir; and <b>Gulbadan</b> led the imperial <b>hajj</b> and wrote the <b>Humayun-nama</b>, a rare memoir by a Mughal woman.',
      crux='He operated within a court where <b>women held power and produced culture</b> — a fuller picture than the lone-emperor image suggests.',
      conseq='The marriage alliances (especially Rajput) and the influence of these women shaped succession, culture and the tolerant character of his rule.',
      matters='The stories of the great are incomplete without the women who advised, ruled, birthed heirs and recorded them.'),

    E('rajput', '1562–1564', 'Turning enemies into pillars', ['REFORM', 'POLITICS', 'TURNING POINT'],
      'His masterstroke is not a battle but a policy: he marries Rajput princesses, raises Hindu nobles to the summit of his government, and abolishes the hated jizya tax on non-Muslims — building a Muslim empire that Hindus help to rule.',
      svg_rajput(),
      bg='India was overwhelmingly Hindu, ruled by a Muslim dynasty. Earlier rulers had governed as conquerors over subjects; Akbar chose a different path.',
      people='His Rajput wives (including the mother of his heir Jahangir); Hindu ministers like <b>Raja Todar Mal</b> and generals like <b>Raja Man Singh</b>.',
      what='Akbar formed <b>marriage alliances</b> with Rajput houses, appointed <b>Hindus to the highest offices</b>, and in <b>1564 abolished the jizya</b> (the tax on non-Muslims) and the pilgrim tax — treating all subjects, regardless of faith, as belonging to the empire.',
      crux='He understood that a durable empire in a diverse land needed the <b>active partnership of the majority</b>, not just their submission — inclusion as the foundation of stability.',
      conseq='Hindu elites became stakeholders in Mughal power; the empire gained legitimacy, loyalty and talent it could not otherwise have commanded.',
      matters='Inclusion can be the deepest strategy of all. Akbar’s tolerance was not only moral but supremely practical — it made the empire hold.'),

    E('todarmal', '1570s–1580s', 'Todar Mal’s revenue revolution', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'Akbar’s finance minister Raja Todar Mal remakes the empire’s tax system on a foundation of measurement and fairness — surveying the land, recording its yields over years, and fixing a predictable cash assessment that funds the state without ruining the peasant.',
      svg_stack('Taxing by measurement, not guesswork', [
          {'n': 1, 'label': 'Measure and classify the land', 'sub': 'systematic survey of area, soil and crop', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Average yields over ten years', 'sub': 'the “dahsala” system sets a fair, stable rate', 'color': '#7c3aed'},
          {'n': 3, 'label': 'A predictable cash tax', 'sub': 'assessed in money — reliable revenue, protected peasants', 'color': '#16a34a'},
      ], takeaway='He built the empire’s wealth on a rational, data-driven revenue system decades ahead of its time.', accent=AC),
      bg='An empire’s strength rests on its finances. Akbar entrusted <b>Raja Todar Mal</b>, a brilliant Hindu administrator, with overhauling land revenue.',
      people='<b>Raja Todar Mal</b>, the finance genius; the imperial surveyors and record-keepers; the peasants and revenue officials across the provinces.',
      what='The <b>zabt</b> and <b>dahsala</b> systems <b>measured landholdings</b>, averaged their yields over ten years, and fixed a <b>cash assessment</b> — a rational, standardised revenue system that stabilised imperial finances.',
      crux='He grounded state power in <b>accurate data and predictable, fair taxation</b> rather than arbitrary extraction.',
      conseq='The reform gave the Mughals a rich, stable treasury and a model of administration studied long afterward, including under British rule.',
      matters='Durable power is built on sound finance — measuring reality and taxing it fairly outlasts any conquest.'),

    E('mansab', '1571–1580', 'The administrative machine', ['REFORM', 'TRIUMPH'],
      'He builds a state that runs: a ranked hierarchy of salaried officers (the mansabdari system) and a brilliant, fair land-revenue system devised by his finance minister Todar Mal — the machinery that lets one man govern a hundred million.',
      svg_mansab(),
      bg='A vast empire needs administration, not just armies. Akbar created institutions to tax, pay and control it centrally and fairly.',
      people='His Hindu finance minister <b>Raja Todar Mal</b>, architect of the revenue reforms; the mansabdars (ranked officers) of the empire.',
      what='Akbar established the <b>mansabdari system</b> — every officer held a numerical <b>rank</b> setting his salary and the troops he maintained — and adopted <b>Todar Mal’s revenue reforms</b> (the <i>zabt</i>/<i>dahsala</i> system), assessing land tax fairly on measured productivity.',
      crux='He replaced arbitrary, personal rule with a <b>centralised, salaried, meritocratic bureaucracy</b> and a rational tax base — the true engine of Mughal strength.',
      conseq='The empire enjoyed efficient administration, reliable revenue, and reduced corruption; the systems endured for generations.',
      matters='Institutions outlast individuals. Akbar’s greatest conquest may have been over chaos itself — building a state that could run without him.'),

    E('pilgrimtax', '1563–1564', 'Abolishing the taxes on being non-Muslim', ['REFORM', 'TURNING POINT'],
      'Very early in his personal rule he makes two revolutionary gestures: he abolishes the tax pilgrims paid to visit Hindu holy sites, and then the jizya — the poll tax on all non-Muslims — declaring, in effect, that his Hindu subjects are citizens, not merely the conquered.',
      svg_row('Removing the badges of second-class status', [
          {'n': 1, 'label': 'Abolishes the pilgrim tax, 1563', 'sub': 'no more levy on Hindu pilgrimage', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Abolishes the jizya, 1564', 'sub': 'ends the poll tax on non-Muslims', 'color': '#166534'},
          {'n': 3, 'label': 'Subjects, not the conquered', 'sub': 'Hindus treated as full members of the realm', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='Two early tax abolitions announced his whole philosophy: rule for all faiths, not one.', accent=AC),
      bg='Non-Muslims under earlier Islamic rule paid the <b>jizya</b> poll tax and other levies marking their subordinate status.',
      people='The Hindu majority of the empire; the orthodox clerics who resented the reforms.',
      what='In <b>1563</b> Akbar <b>abolished the tax on Hindu pilgrims</b>, and in <b>1564 abolished the jizya</b> itself — removing the fiscal badges of second-class status for non-Muslims, decades before his more famous religious experiments.',
      crux='He signalled early and concretely that his empire would <b>treat all faiths as belonging</b> — turning principle into policy through the tax code.',
      conseq='The reforms won deep goodwill from the Hindu majority and underpinned the loyalty that stabilised the empire.',
      matters='Policy speaks louder than words. By abolishing these taxes so early, Akbar made his inclusive vision real and material.'),

    E('infrastructure', '1570s–1600', 'Binding the empire — roads, sarais and couriers', ['REFORM', 'POLITICS'],
      'Akbar knits his vast realm together with hard infrastructure: tree-lined highways studded with rest-houses, a fast courier system, and revived river and road trade — the physical sinews that let orders, armies and goods move across a subcontinent.',
      svg_stack('The physical network of empire', [
          {'n': 1, 'label': 'Highways and milestones', 'sub': 'roads improved and planted, linking the great cities', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Sarais for travellers', 'sub': 'rest-houses and wells make long-distance travel safe', 'color': '#7c3aed'},
          {'n': 3, 'label': 'A courier and post system', 'sub': 'relay runners and riders carry news across the realm', 'color': '#16a34a'},
      ], takeaway='He made distance governable — the empire moved on the roads and relays he built and maintained.', accent=AC),
      bg='Ruling from the Hindu Kush to Bengal required moving information, troops and trade across enormous distances quickly and safely.',
      people='the road-builders and sarai-keepers; the couriers of the imperial post; the merchants whose caravans used the improved routes.',
      what='Akbar improved and secured the great <b>highways</b>, built <b>sarais</b> (rest-houses) and wells, and maintained a <b>courier and postal network</b> — the logistical backbone that held the empire together.',
      crux='He understood that an empire is only as strong as its <b>connective tissue</b> — roads and communications are power made physical.',
      conseq='This infrastructure sped administration, boosted trade and reinforced central control across the subcontinent.',
      matters='Empires run on their roads and relays as much as their armies — connectivity is a form of control.'),

    E('ain', '1590s', 'Documenting an empire — the Ain-i-Akbari', ['REFORM', 'TRIUMPH'],
      'He commissions one of history’s great works of administration: a vast, statistical gazetteer of the entire empire — its provinces, revenues, army, coinage, customs, castes and crops — compiled by Abu’l-Fazl, giving the state an unprecedented, data-driven grasp of what it governed.',
      svg_stack('Ruling by data, not just decree', [
          {'n': 1, 'label': 'Survey the whole empire', 'sub': 'provinces, revenues, prices, population', 'color': '#6d28d9'},
          {'n': 2, 'label': 'The Ain-i-Akbari', 'sub': 'Abu’l-Fazl’s vast administrative gazetteer', 'color': '#0369a1'},
          {'n': 3, 'label': 'A state that knows itself', 'sub': 'data underpins tax, justice and planning', 'color': '#166534'},
      ], takeaway='He built a state that measured and recorded itself in astonishing detail — governance as information.', accent=AC),
      bg='Good administration needs good information. Akbar’s government gathered and recorded data on the empire at a scale rare for its age.',
      people='<b>Abu’l-Fazl</b>, compiler of the <b>Ain-i-Akbari</b> (part of the Akbarnama); the surveyors and clerks of the revenue system.',
      what='Akbar had the empire exhaustively documented in the <b>Ain-i-Akbari</b> — a statistical account of provinces, <b>revenues, the army, coinage, prices, customs, castes and agriculture</b> — giving the state a remarkably detailed, data-driven picture of what it ruled.',
      crux='He treated <b>information as an instrument of power</b>: a state that measures itself can tax fairly, plan, and govern far more effectively.',
      conseq='The Ain-i-Akbari became a foundation of Mughal administration and remains a priceless historical source.',
      matters='Modern government runs on data — and Akbar grasped this in the 16th century, building a state that knew itself in extraordinary detail.'),

    E('economy', '1570s–1600', 'One coin, one market — the wealth of the empire', ['REFORM', 'TRIUMPH'],
      'Akbar standardises the empire’s money and integrates its markets, minting beautifully pure gold, silver and copper coin and fostering trade so that a vast, secure common market makes the Mughal Empire one of the richest states on earth.',
      svg_row('Prosperity engineered by policy', [
          {'n': 1, 'label': 'A reformed, pure coinage', 'sub': 'reliable gold mohur, silver rupee and copper dam', 'color': '#6d28d9'},
          {'n': 2, 'label': 'An integrated market', 'sub': 'safe roads and uniform money knit provinces together', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Among the world’s richest states', 'sub': 'huge revenues fund army, court and building', 'color': '#16a34a'},
      ], edge_labels=['enables', 'yields'], takeaway='Sound money and a unified market turned conquest into lasting, funded prosperity.', accent=AC),
      bg='A sprawling empire needed reliable money and open trade to translate territory into wealth. Akbar reformed both.',
      people='the master of the mint and treasury officials; the merchants and bankers of the empire; the artisans whose goods it traded.',
      what='He issued a <b>standardised, high-purity coinage</b> (the silver rupee, gold mohur, copper dam), secured the trade routes, and encouraged commerce — building a huge, integrated market and one of the wealthiest treasuries in the world.',
      crux='He saw that <b>uniform money plus secure trade</b> converts a patchwork of conquests into a single prosperous economy.',
      conseq='Mughal India under Akbar became a byword for wealth, its revenues dwarfing contemporary European states and funding a golden age.',
      matters='Territory is only potential wealth — it takes sound currency and open markets to turn conquest into riches.'),

    E('dagh', '1573–1580', 'Stopping the fraud — branding the horses', ['REFORM', 'POLITICS'],
      'He plugs the great leak in his military system with a famously practical reform: since officers were paid for troops and horses they often didn’t really have, he orders every cavalry horse branded and every soldier described in a register — a small, shrewd measure that saved the treasury and tightened the army.',
      svg_row('A shrewd fix for a costly cheat', [
          {'n': 1, 'label': 'The muster fraud', 'sub': 'officers claim pay for phantom troops and horses', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Brand every horse (dagh)', 'sub': 'and register each soldier’s description (chehra)', 'color': '#6d28d9'},
          {'n': 3, 'label': 'The leak is plugged', 'sub': 'real strength known; the treasury protected', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='A humble branding iron closed a fraud that had quietly drained empires — administration in the details.', accent=AC),
      bg='Under the mansabdari system, officers were paid to maintain set numbers of cavalry — and many <b>cheated</b>, claiming pay for troops and horses they did not keep.',
      people='The mansabdar officers; the muster-masters who enforced the new checks.',
      what='Akbar enforced the <b>dagh (branding of cavalry horses)</b> and the <b>chehra (a descriptive register of each soldier)</b>, so the state could verify that officers actually maintained the troops they were paid for, curbing widespread <b>muster fraud</b>.',
      crux='He understood that <b>systems fail in the details</b>: a simple verification mechanism protected the treasury and kept the army genuinely strong.',
      conseq='Military accounting became far more honest and the army’s real strength more reliable — sinews of a durable empire.',
      matters='Great administration lives in unglamorous checks. Akbar’s horse-branding is a classic case of a small reform with large effects.'),
]

# ==================================================================  PHASE 4 — SULH-I-KUL
PHASE_TRUTH = [
    E('ibadat', '1575–1582', 'The House of Worship and universal peace', ['REFORM', 'TURNING POINT'],
      'The illiterate emperor becomes the great questioner of his age: he builds a House of Worship where scholars of every religion — Muslim, Hindu, Jain, Zoroastrian, and Jesuit Christian — debate before him, and from it he draws his guiding principle of sulh-i-kul, "peace with all."',
      svg_ibadat(),
      bg='Akbar was intensely, restlessly religious and curious. At <b>Fatehpur Sikri</b> he created the <b>Ibadat Khana</b> (House of Worship) for religious debate.',
      people='Muslim theologians; Hindu, Jain and Zoroastrian scholars; <b>Jesuit missionaries</b> from Goa; his friend and biographer <b>Abu’l-Fazl</b>.',
      what='In the <b>Ibadat Khana</b>, Akbar hosted debates among scholars of all faiths and adopted <b>sulh-i-kul</b> ("universal peace/reconciliation") as state policy — an official commitment to religious tolerance extraordinary for its time.',
      crux='He treated religion as a <b>subject of open inquiry rather than an unquestionable given</b>, and made tolerance a principle of governance — the intellectual heart of his reign.',
      conseq='His tolerant policy gave his diverse empire a shared civic space above sectarian division, strengthening its unity.',
      matters='An open mind at the top can reshape a civilisation. Akbar’s sulh-i-kul is one of history’s boldest official embraces of pluralism.'),

    E('mahzar', '1579', 'The infallibility decree — supreme arbiter of faith', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'He makes his boldest move against clerical power: a decree, signed by the leading theologians themselves, declaring that in disputed religious questions the emperor’s ruling shall prevail — freeing him from the veto of the orthodox ulama and making the throne, not the clergy, the final authority in his realm.',
      svg_row('Breaking the clergy’s grip on the state', [
          {'n': 1, 'label': 'Clerics resist his reforms', 'sub': 'the orthodox ulama oppose his liberalism', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'The mahzar of 1579', 'sub': 'a decree making the emperor the final arbiter', 'color': '#6d28d9'},
          {'n': 3, 'label': 'Throne over pulpit', 'sub': 'religious authority subordinated to the state', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='He turned the throne into the supreme arbiter of religious disputes — a decisive check on clerical power.', accent=AC),
      bg='The orthodox <b>ulama</b> (religious scholars) were a powerful check on the ruler, and increasingly opposed Akbar’s tolerant and experimental policies.',
      people='The leading theologians who (under pressure) signed the decree; the orthodox clerics whose authority it curbed; Abu’l-Fazl, its likely architect.',
      what='In <b>1579</b> Akbar issued the <b>mahzar</b> (“infallibility decree”), signed by leading religious scholars, declaring that where jurists disagreed, <b>the emperor’s ruling would prevail</b> — making the throne, not the clergy, the ultimate authority on contested religious matters.',
      crux='He asserted the <b>supremacy of the state over the religious establishment</b>, freeing his reforms from clerical veto — a striking early assertion of royal authority over the pulpit.',
      conseq='Freed from orthodox constraint, Akbar pursued his tolerant policies and religious experiments; clerics bristled but were sidelined.',
      matters='Who holds final authority — throne or pulpit — is one of history’s great questions. Akbar answered it firmly in favour of the state.'),

    E('jesuits', '1580–1595', 'The Jesuits at court — seeking every truth', ['REFORM', 'POLITICS', 'TURNING POINT'],
      'Hungry for religious understanding, Akbar invites Catholic priests all the way from Portuguese Goa to debate at his court — questioning them closely on Christianity, letting his son learn from them, and folding their ideas into his ever-widening search for a universal truth.',
      svg_row('An emperor who summoned every faith', [
          {'n': 1, 'label': 'Jesuits invited from Goa, 1580', 'sub': 'Catholic priests travel to the Mughal court to debate', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Akbar questions them intently', 'sub': 'probes Christianity alongside Islam, Hinduism, Jainism', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Curiosity, not conversion', 'sub': 'he absorbs ideas but embraces no single creed', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He sought truth by summoning its every claimant — an openness astonishing for any 16th-century monarch.', accent=AC),
      bg='Ruling a mostly Hindu empire as a Muslim, Akbar pursued a genuine, restless inquiry into religion, inviting scholars of many faiths to his House of Worship.',
      people='the Jesuit fathers <b>Rodolfo Acquaviva</b> and <b>Monserrate</b> from Goa; Hindu, Jain, Zoroastrian and Muslim scholars; his sons, exposed to the debates.',
      what='Akbar invited <b>Jesuit missions from Portuguese Goa</b> (from 1580), debated Christianity with them at length, and welcomed their books and ideas — though he adopted no creed, treating all as sources in his search.',
      crux='He approached faith as an <b>open question to be investigated</b>, not a settled inheritance to be enforced — inviting even distant foreign priests.',
      conseq='The encounters fed his syncretic outlook and the Din-i-Ilahi, and left a remarkable record of cross-cultural dialogue.',
      matters='True intellectual openness invites even the unfamiliar and foreign to make its case — and judges ideas on their merits.'),

    E('dinilahi', '1582', 'Din-i-Ilahi — a faith of his own', ['REFORM', 'POLITICS'],
      'From these debates he distils Din-i-Ilahi, a small syncretic "Divine Faith" blending elements of many religions around loyalty to the emperor and ethical living. It wins few followers and dies with him — but it embodies his lifelong conviction that no single creed holds all truth.',
      svg_stack('An emperor’s experiment in belief', [
          {'n': 1, 'label': 'Draws from many faiths', 'sub': 'Islam, Hinduism, Zoroastrianism, Jainism, more', 'color': '#6d28d9'},
          {'n': 2, 'label': 'A tiny elite order', 'sub': 'a handful of courtiers, not a mass religion', 'color': '#b45309'},
          {'n': 3, 'label': 'Dies with Akbar', 'sub': 'it does not outlive its founder', 'color': '#6b7280'},
      ], takeaway='His “Divine Faith” failed as a religion — but perfectly captured his refusal to believe any one creed owned the truth.', accent=AC),
      bg='Convinced no single religion held the whole truth, Akbar around <b>1582</b> promoted <b>Din-i-Ilahi</b> ("Religion of God"), a syncretic ethical path centred on the emperor.',
      people='The small circle of courtiers who adopted it; orthodox Muslim clerics who bitterly opposed it as heresy.',
      what='<b>Din-i-Ilahi</b> blended elements of several religions into an ethical, monotheistic order emphasising virtue and devotion to the emperor. It attracted <b>only a handful of followers</b> and effectively vanished after Akbar’s death.',
      crux='It was less a successful religion than an <b>expression of Akbar’s syncretic, questioning worldview</b> — and of an emperor’s belief that he stood above sectarian divisions.',
      conseq='It alienated orthodox clerics and never spread, but reinforced his image as a uniquely tolerant, philosophically adventurous ruler.',
      matters='Not every bold idea succeeds. Din-i-Ilahi failed as a faith, yet stands as a remarkable monument to one ruler’s open, searching mind.'),

    E('socialreform', '1560s–1600', 'Reforming society — against sati, slavery and child marriage', ['REFORM', 'TURNING POINT'],
      'Akbar turns his tolerance into concrete social reform: discouraging the burning of widows, seeking to raise the age of marriage, permitting widows to remarry, and forbidding the enslavement of prisoners’ families — pushing a compassionate agenda far ahead of his age.',
      svg_stack('Compassion translated into policy', [
          {'n': 1, 'label': 'Against forced sati', 'sub': 'discourages widow-burning; forbids coercing widows', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Marriage and remarriage', 'sub': 'seeks to raise the marriage age; allows widow remarriage', 'color': '#7c3aed'},
          {'n': 3, 'label': 'No enslaving captives’ families', 'sub': 'bans the customary enslavement of prisoners’ women and children', 'color': '#16a34a'},
      ], takeaway='He used state power to soften cruel customs — social reform centuries ahead of much of the world.', accent=AC),
      bg='Akbar’s doctrine of <b>sulh-i-kul</b> (“universal peace”) extended beyond tolerance into active reform of harsh social practices among his subjects.',
      people='the widows and prisoners affected; conservative clergy and nobles who resisted; the reforming officials who enforced the measures.',
      what='He <b>discouraged sati</b> (forbidding it where coerced), tried to <b>raise the age of marriage</b>, <b>permitted widow remarriage</b>, and <b>banned the enslavement</b> of war captives’ families — a remarkably humane program.',
      crux='He believed a just ruler should <b>reform cruel customs</b>, not merely tolerate them — extending compassion into law.',
      conseq='Enforcement was uneven and some reforms faded under successors, but they marked a strikingly progressive vision of the state’s moral role.',
      matters='Tolerance at its fullest becomes reform — using power not just to permit difference but to reduce suffering.'),

    E('translation', '1575–1595', 'The illiterate emperor’s house of translation', ['REFORM', 'TRIUMPH'],
      'A man who cannot read builds one of history’s great libraries and a translation bureau, ordering the Hindu epics — the Mahabharata and Ramayana — rendered into Persian so his Muslim court can read them, and gathering the learning of many faiths and languages under one roof.',
      svg_stack('Building a bridge between civilisations', [
          {'n': 1, 'label': 'A translation bureau', 'sub': 'the maktab-khana renders Sanskrit into Persian', 'color': '#6d28d9'},
          {'n': 2, 'label': 'The Hindu epics in Persian', 'sub': 'the Razmnama (Mahabharata), the Ramayana', 'color': '#b45309'},
          {'n': 3, 'label': 'A vast royal library', 'sub': 'thousands of manuscripts, read aloud to him', 'color': '#166534'},
      ], takeaway='Unable to read a word, he made his court the great meeting-place of Hindu and Islamic learning.', accent=AC),
      bg='Akbar’s tolerance had an intellectual dimension: a deliberate project to <b>translate and fuse the knowledge of India’s different traditions</b>.',
      people='The scholars of his <b>translation bureau</b>; the Hindu pandits and Muslim scholars who worked side by side; the artists who illustrated the manuscripts.',
      what='Akbar established a <b>translation bureau (maktab-khana)</b> that rendered Sanskrit classics — the <b>Mahabharata (as the <i>Razmnama</i>)</b> and the <b>Ramayana</b> — into Persian, and assembled an enormous, superbly illustrated <b>library</b>, all absorbed by an emperor who was read to because he could not read himself.',
      crux='He turned <b>cultural synthesis into a state project</b>, making his court the place where Hindu and Islamic civilisation were deliberately brought together.',
      conseq='This fusion shaped a distinctive Indo-Persian Mughal culture in art, literature and thought that outlasted him for generations.',
      matters='Openness of mind, not literacy, makes a great intellectual patron. Akbar’s translation project is a landmark of cross-cultural understanding.'),
]

# ==================================================================  PHASE 5 — SIKRI, THE GEMS, AND DEATH
PHASE_END = [
    E('sikri', '1571–1585', 'Fatehpur Sikri and the nine gems', ['REFORM', 'TRIUMPH'],
      'He builds a magnificent new capital, Fatehpur Sikri, and gathers around him the "Navaratnas" — nine gems of talent, from the witty Birbal to the musician Tansen — presiding over a golden age of art, music, and the great chronicle of his reign, the Akbarnama.',
      svg_stack('The court at its cultural height', [
          {'n': 1, 'label': 'Fatehpur Sikri', 'sub': 'a splendid new capital (soon abandoned for water)', 'color': '#6d28d9'},
          {'n': 2, 'label': 'The Navaratnas', 'sub': 'nine "gems": Birbal, Tansen, Todar Mal, Man Singh…', 'color': '#b45309'},
          {'n': 3, 'label': 'The Akbarnama', 'sub': 'Abu’l-Fazl’s great chronicle of the reign', 'color': '#166534'},
      ], takeaway='His court became the cultural summit of India — a magnet for the finest talent of the age.', accent=AC),
      bg='At the height of his reign Akbar patronised a brilliant flowering of architecture, painting, music and literature, and built a showpiece capital.',
      people='The <b>Navaratnas</b> (nine gems), including <b>Birbal</b>, the musician <b>Tansen</b>, <b>Todar Mal</b>, <b>Man Singh</b> and <b>Abu’l-Fazl</b>.',
      what='Akbar built <b>Fatehpur Sikri</b> (c. 1571, abandoned around 1585 due to water shortage), gathered the legendary <b>Navaratnas</b>, and had his reign recorded in the great chronicle <b>Akbarnama</b> by Abu’l-Fazl — a golden age of Mughal culture.',
      crux='He made his court a <b>meritocratic magnet for talent</b> of every background, fusing Persian, Indian and other traditions into a distinctive Mughal culture.',
      conseq='The art, architecture and administrative culture of his reign shaped the Mughal golden age that his successors continued.',
      matters='A great ruler builds a civilisation, not just an empire. Akbar’s court remains a byword for cultural brilliance and openness.'),

    E('abulfazl', '1590s–1602', 'Abu’l-Fazl — the mind that framed the reign', ['REFORM', 'POLITICS', 'TRAGEDY'],
      'Akbar’s closest intellectual companion, Abu’l-Fazl, gives the reign its philosophy and its record — writing the monumental Akbarnama and Ain-i-Akbari — until the emperor’s jealous son has him murdered on the road, striking at the father through the friend.',
      svg_stack('The thinker behind the throne — and his murder', [
          {'n': 1, 'label': 'Akbar’s friend and ideologue', 'sub': 'Abu’l-Fazl articulates sulh-i-kul and sacral kingship', 'color': '#6d28d9'},
          {'n': 2, 'label': 'Author of the Akbarnama', 'sub': 'the great chronicle and the Ain-i-Akbari gazetteer', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Assassinated, 1602', 'sub': 'killed by an agent of the rebellious Prince Salim', 'color': '#b91c1c'},
      ], takeaway='The reign’s guiding intellect was cut down by the heir — a wound to Akbar’s heart as much as his court.', accent=AC),
      bg='<b>Abu’l-Fazl</b> was Akbar’s friend, adviser and historian — the man who gave the reign its intellectual framework and its official memory.',
      people='<b>Abu’l-Fazl</b>, the scholar-statesman; his brother, the poet <b>Faizi</b>; Prince <b>Salim</b> (Jahangir), who ordered his death; <b>Bir Singh Bundela</b>, the assassin.',
      what='Abu’l-Fazl wrote the <b>Akbarnama</b> and the encyclopaedic <b>Ain-i-Akbari</b>, and shaped the ideology of tolerant, semi-divine kingship — until, in 1602, he was <b>murdered</b> on Salim’s orders as he returned from the Deccan.',
      crux='The reign’s <b>ideas and record</b> flowed through one brilliant companion — and killing him was a way for the heir to strike at the father.',
      conseq='Akbar was devastated; the murder poisoned his last years and his relationship with his heir, even as Abu’l-Fazl’s writings preserved the reign for posterity.',
      matters='Great rulers are often defined by a single indispensable mind beside them — and their loss cuts to the bone.'),

    E('death', '1601–1605', 'A rebellious son and the end', ['TRAGEDY', 'DEATH'],
      'His last years are shadowed by the revolt of his son Salim, who even has Akbar’s beloved friend and biographer Abu’l-Fazl murdered. Reconciled at the last, Akbar dies in 1605, leaving Salim — as Jahangir — the greatest and best-run empire in the world.',
      svg_row('The bitter close of a great reign', [
          {'n': 1, 'label': 'Salim rebels', 'sub': 'the heir revolts against his ageing father', 'color': '#b45309'},
          {'n': 2, 'label': 'Abu’l-Fazl murdered', 'sub': 'Salim has Akbar’s closest friend assassinated, 1602', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Death, 1605', 'sub': 'reconciled at the last; Salim succeeds as Jahangir', 'color': '#111827'},
      ], edge_labels=['then', 'then'], takeaway='Even the greatest of the Mughals could not escape the dynasty’s curse — a son’s revolt against his father.', accent=AC),
      bg='As Akbar aged, his heir <b>Salim</b> (the future <b>Jahangir</b>) grew impatient for power and rose in revolt — the recurring tragedy of Mughal successions.',
      people='His son and heir <b>Salim/Jahangir</b>; his murdered friend and biographer <b>Abu’l-Fazl</b>.',
      what='<b>Salim</b> rebelled in Akbar’s final years and, in <b>1602</b>, had <b>Abu’l-Fazl assassinated</b>. Father and son were reconciled before Akbar <b>died in 1605</b>, aged about 63, and Salim succeeded him as Emperor <b>Jahangir</b>.',
      crux='His empire, unlike those of Alexander or Timur, was built on <b>durable institutions and inclusive policy</b>, so it passed intact to his heir and endured for over a century more.',
      conseq='The Mughal Empire Akbar built remained the dominant power in India, its golden age continuing under Jahangir and Shah Jahan (builder of the Taj Mahal).',
      matters='The truest measure of a builder is what survives him. Akbar left not just conquests but a working empire — and a model of tolerant rule.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Akbar the Great turned a lost inheritance into the richest, best-governed empire of its age — and did it not only by conquest but by tolerance, alliance and administration. An illiterate emperor with a restless, questioning mind, he made Hindus partners in a Muslim empire, abolished the tax on non-believers, built a rational bureaucracy, and hosted the boldest religious debates of his century. He is a study in <b>inclusion as strategy, institutions over force, and an open mind at the summit of power.</b></p>
<div class="ov-quote">“Sulh-i-kul” — peace and reconciliation with all.<span>— the guiding principle of Akbar’s rule</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born in exile to a father with no throne → crowned at thirteen and saved at Panipat by a chance arrow → seizes real power from his regents → conquers Rajputana, Gujarat, Bengal, Kashmir and the Deccan → turns Rajput enemies into pillars and abolishes the jizya → builds the mansabdari state and Todar Mal’s revenue system → hosts all faiths in the House of Worship and proclaims universal peace → presides over a cultural golden age → dies in 1605 leaving the world’s greatest empire intact.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🤝</div><h4>Inclusion as strategy</h4><p>He made the conquered majority partners — the secret of Mughal stability.</p></div>
  <div class="ov-card"><div class="i">⚙️</div><h4>Institutions over force</h4><p>The mansabdari and revenue systems let a state outlast its founder.</p></div>
  <div class="ov-card"><div class="i">🕊️</div><h4>Radical tolerance</h4><p>Abolishing the jizya and hosting all faiths, centuries ahead of his time.</p></div>
  <div class="ov-card"><div class="i">🎨</div><h4>A golden age</h4><p>Fatehpur Sikri, the nine gems, and a distinctive Mughal culture.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Orphan Heir</b><small> 1542–62</small><p>Born in exile; crowned at 13; seizing power.</p></div>
  <div><b>2 · The Conqueror</b><small> 1568–1601</small><p>Rajputana, Gujarat, and a subcontinent.</p></div>
  <div><b>3 · The Statesman</b><small> 1562–80</small><p>The Rajput policy and the administrative machine.</p></div>
  <div><b>4 · Sulh-i-kul</b><small> 1575–82</small><p>The House of Worship and the Divine Faith.</p></div>
  <div><b>5 · Sikri and Death</b><small> 1571–1605</small><p>The golden-age court; a son’s revolt; the end.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Humayun', 'role': 'father / emperor', 'color': '#b45309',
     'bio': 'Akbar’s father, the second Mughal emperor, who lost the empire to Sher Shah Suri, spent years in exile, briefly regained Delhi, and died in 1556 in a fall down his library stairs.',
     'rel': 'The father whose lost empire Akbar reclaimed and transformed.'},
    {'name': 'Bairam Khan', 'role': 'regent / general', 'color': '#6d28d9',
     'bio': 'Akbar’s guardian and regent, who won Panipat and governed the empire during his minority — until Akbar dismissed him in 1560 to rule himself.',
     'rel': 'The regent who saved the throne and then had to be set aside.'},
    {'name': 'Todar Mal', 'role': 'finance minister', 'color': '#0369a1',
     'bio': 'A brilliant Hindu administrator who devised Akbar’s land-revenue system, assessing tax fairly on measured productivity — the financial backbone of the empire.',
     'rel': 'The Hindu minister who built the empire’s revenue machine.'},
    {'name': 'Raja Man Singh', 'role': 'Rajput general', 'color': '#166534',
     'bio': 'A leading Rajput prince of Amber who became one of Akbar’s greatest generals and governors — the embodiment of the Rajput alliance.',
     'rel': 'The Rajput noble who rose to the summit of Mughal service.'},
    {'name': 'Abu’l-Fazl', 'role': 'friend / biographer', 'color': '#7c3aed',
     'bio': 'Akbar’s closest friend, advisor and the author of the Akbarnama, the great chronicle of the reign; assassinated in 1602 on the orders of the rebellious prince Salim.',
     'rel': 'The chronicler and confidant whose murder darkened Akbar’s last years.'},
    {'name': 'Jahangir (Salim)', 'role': 'son and heir', 'color': '#7f1d1d',
     'bio': 'Akbar’s son, who rebelled against his ageing father and had Abu’l-Fazl killed, but was reconciled and succeeded in 1605 as Emperor Jahangir.',
     'rel': 'The heir whose revolt shadowed the reign’s end.'},
]

KEY_EVENTS = [
    ('1542', 'Born in exile in Sindh', 'While his father Humayun is a fugitive.'),
    ('1556', 'Crowned at thirteen', 'Humayun dies; the Mughal hold collapses.'),
    ('1556', 'Second Battle of Panipat', 'Hemu defeated; the empire reclaimed.'),
    ('1560', 'Dismisses Bairam Khan', 'Begins to rule in his own right.'),
    ('1564', 'Abolishes the jizya', 'Ends the tax on non-Muslims.'),
    ('1568', 'Storm of Chittorgarh', 'Rajputana subdued; most Rajputs allied.'),
    ('1573', 'Conquest of Gujarat', 'The famous eleven-day forced march.'),
    ('1575', 'The House of Worship', 'All-faith debates at Fatehpur Sikri.'),
    ('1582', 'Din-i-Ilahi proclaimed', 'His syncretic "Divine Faith."'),
    ('1586', 'Kashmir annexed', 'The empire nears its greatest extent.'),
    ('1602', 'Abu’l-Fazl murdered', 'On the orders of the rebel prince Salim.'),
    ('1605', 'Death of Akbar', 'Jahangir inherits the world’s greatest empire.'),
]

MASTER = [
    {'year': '1542', 'age': 'born', 'phase': 'The Heir', 'title': 'Born in exile', 'desc': 'Father Humayun a fugitive.'},
    {'year': '1556', 'age': 'age 13', 'phase': 'The Heir', 'title': 'Crowned; Panipat', 'desc': 'The empire reclaimed.'},
    {'year': '1560', 'age': 'age ~18', 'phase': 'The Heir', 'title': 'Takes real power', 'desc': 'Dismisses Bairam Khan.'},
    {'year': '1568', 'age': 'age ~26', 'phase': 'Conqueror', 'title': 'Chittorgarh', 'desc': 'Rajputana subdued.'},
    {'year': '1573', 'age': 'age ~31', 'phase': 'Conqueror', 'title': 'Gujarat', 'desc': 'The 11-day march.'},
    {'year': '1575', 'age': 'age ~33', 'phase': 'Sulh-i-kul', 'title': 'House of Worship', 'desc': 'All-faith debates.'},
    {'year': '1582', 'age': 'age ~40', 'phase': 'Sulh-i-kul', 'title': 'Din-i-Ilahi', 'desc': 'His syncretic faith.'},
    {'year': '1586', 'age': 'age ~44', 'phase': 'Conqueror', 'title': 'Kashmir', 'desc': 'The empire near its height.'},
    {'year': '1605', 'age': 'age ~63', 'phase': 'The End', 'title': 'Death of Akbar', 'desc': 'Jahangir succeeds.'},
]

SOURCES = [
    ('Britannica — Akbar', 'https://www.britannica.com/biography/Akbar'),
    ('World History Encyclopedia — Akbar I', 'https://www.worldhistory.org/Akbar_I/'),
    ('Britannica — Mughal dynasty', 'https://www.britannica.com/topic/Mughal-dynasty'),
    ('Wikipedia — Akbar', 'https://en.wikipedia.org/wiki/Akbar'),
]

def build_meta():
    return {
        'pid': 'gm-akbar.html', 'kind': 'man', 'emoji': '🕌', 'accent': AC,
        'name': 'Akbar', 'years': '1542–1605', 'group': 'Indian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The illiterate emperor who built the golden age of the Mughals on tolerance, alliance and administration — and made Hindus partners in a Muslim empire.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Orphan Heir', 'type': 'timeline',
             'intro': 'Born in exile to a father who had lost his throne, crowned at thirteen and saved by a chance arrow at Panipat, he seizes real power from his own regents while still a teenager.', 'events': PHASE_RISE},
            {'id': 'conquer', 'label': '2 · The Conqueror', 'type': 'timeline',
             'intro': 'He binds a subcontinent together — storming Chittorgarh, racing back to crush Gujarat’s revolt, and adding Bengal, Kashmir and the Deccan to forge the greatest Indian empire since Ashoka.', 'events': PHASE_CONQUER},
            {'id': 'state', 'label': '3 · The Statesman', 'type': 'timeline',
             'intro': 'His masterstroke is policy, not battle: turning Rajput enemies into pillars, abolishing the jizya, and building the mansabdari state and Todar Mal’s revenue system.', 'events': PHASE_STATE},
            {'id': 'truth', 'label': '4 · Sulh-i-kul', 'type': 'timeline',
             'intro': 'The illiterate emperor becomes the great questioner of his age — hosting scholars of every faith in the House of Worship, proclaiming universal peace, and founding his own Divine Faith.', 'events': PHASE_TRUTH},
            {'id': 'end', 'label': '5 · Sikri and Death', 'type': 'timeline',
             'intro': 'He presides over a cultural golden age at Fatehpur Sikri with his nine gems — before a rebellious son and the murder of his closest friend shadow his final years.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Some colourful details of Akbar’s reign come from the court chronicle Akbarnama, written by his friend Abu’l-Fazl and naturally favourable; the broad outline of his conquests, reforms and tolerance is well established.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
