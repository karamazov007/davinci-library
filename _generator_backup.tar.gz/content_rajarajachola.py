# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Raja Raja Chola I (Rajaraja the Great).
The Chola emperor who raised Tamil South India to imperial and maritime greatness."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#9a3412'  # Chola bronze

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING OF AN EMPEROR
PHASE_RISE = [
    E('origins', 'c. 947–969', 'Arulmozhi Varman — a prince of the reviving Chola house', ['RISE'],
      'Born around 947 as Arulmozhi Varman into the Chola royal house of Tamil South India, the future emperor grows up in a dynasty clawing its way back from centuries of eclipse — schooled in war and statecraft, and shaped by his formidable elder sister Kundavai.',
      svg_row('A prince of a rising dynasty', [
          {'n': 1, 'label': 'Born Arulmozhi Varman, c. 947', 'sub': 'son of Sundara Chola (Parantaka II)', 'color': '#9a3412'},
          {'n': 2, 'label': 'A dynasty reviving', 'sub': 'the Cholas clawing back to power in the Tamil land', 'color': '#a16207'},
          {'n': 3, 'label': 'Schooled by Kundavai', 'sub': 'his powerful elder sister and lifelong ally', 'color': '#166534'},
      ], edge_labels=['into', 'with'], takeaway='He was born into a house on the rise — and into a family that trusted him with its future.', accent=AC),
      bg='<b>Arulmozhi Varman</b> was born around 947 into the Chola dynasty of Tamil South India, son of <b>Sundara Chola (Parantaka II)</b>, as the family recovered its old imperial standing.',
      people='his father <b>Sundara Chola</b>; his mother <b>Vanavan Mahadevi</b>; his elder brother <b>Aditha II</b>; his sister <b>Kundavai</b>, a lifelong ally.',
      what='The young prince grew up amid the Chola revival, trained in warfare and administration, and closely bound to his sister <b>Kundavai</b>, who would remain an influential figure throughout his reign.',
      crux='He was groomed within a <b>dynasty on the ascent</b> — inheriting both its ambitions and its long memory of past greatness.',
      conseq='His talent marked him early as a natural heir, even as a succession crisis loomed over the Chola throne.',
      matters='Great reigns often begin in family and formation — the prince who would remake an empire was shaped by dynasty, war and kin.'),

    E('deferral', 'c. 969–985', 'A murdered heir and a crown set aside', ['RISE', 'TURNING POINT'],
      'When his elder brother Aditha II is murdered, the throne might have passed to Arulmozhi — but he steps aside in favour of his uncle Uttama Chola, biding his time as heir-apparent, a display of patience and restraint that steadies a fragile dynasty.',
      svg_stack('Patience before the throne', [
          {'n': 1, 'label': 'Aditha II murdered', 'sub': 'the heir killed, the succession thrown open', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Arulmozhi stands aside', 'sub': 'yields the crown to his uncle Uttama Chola', 'color': '#9a3412'},
          {'n': 3, 'label': 'Heir-apparent, biding his time', 'sub': 'restraint steadies a fragile dynasty', 'color': '#166534'},
      ], takeaway='He declined a crown he might have seized — patience that spared the dynasty a bloody feud.', accent=AC),
      bg='The murder of the crown prince <b>Aditha II</b> opened a dangerous succession. Rather than press his own claim, Arulmozhi deferred to his uncle.',
      people='<b>Aditha II</b>, the slain heir; <b>Uttama Chola</b>, the uncle who took the throne; Arulmozhi, the patient heir-apparent.',
      what='Arulmozhi <b>set aside his claim in favour of his uncle Uttama Chola</b>, serving as heir-apparent until Uttama’s death — an act of dynastic restraint that avoided a ruinous fight for the throne.',
      crux='He chose <b>continuity over ambition</b>, trusting that the crown would come to him in time without tearing the dynasty apart.',
      conseq='When Uttama Chola died, the throne passed smoothly to Arulmozhi in 985.',
      matters='Restraint can be its own form of strength — the ruler secure in his destiny need not grasp for it.'),

    E('accession', '985', 'Accession as Rajaraja — “king of kings”', ['POLITICS', 'TURNING POINT'],
      'In 985 Arulmozhi ascends the Chola throne, taking the resounding regnal name Rajaraja — “king of kings” — and inheriting a compact but recovering kingdom that he is determined to forge into an empire spanning the whole of the south.',
      svg_row('A new name, a new ambition', [
          {'n': 1, 'label': 'Ascends the throne, 985', 'sub': 'the crown passes to him at last', 'color': '#9a3412'},
          {'n': 2, 'label': 'Takes the name Rajaraja', 'sub': '“king of kings” — a statement of ambition', 'color': '#a16207'},
          {'n': 3, 'label': 'A kingdom to make imperial', 'sub': 'a compact realm he means to expand', 'color': '#166534'},
      ], edge_labels=['as', 'over'], takeaway='He crowned himself “king of kings” — and set out to make the title true across all of South India.', accent=AC),
      bg='In <b>985</b>, on the death of Uttama Chola, Arulmozhi Varman finally took the Chola throne.',
      people='the Chola court and nobility; the rival dynasties of the south he meant to master; Rajaraja, the new emperor.',
      what='He assumed the regnal name <b>Rajaraja</b> — “<b>king of kings</b>” — and began at once to transform a modest kingdom into the dominant power of the Tamil south and beyond.',
      crux='The name itself was a <b>programme</b> — Rajaraja announced from the start his intent to rule as an emperor, not merely a king.',
      conseq='Within a few years his armies were marching against every neighbouring power in the south.',
      matters='A ruler’s title can be a declaration of intent — Rajaraja named himself “king of kings” and spent his reign earning it.'),
]

# ==================================================================  PHASE 2 — CONQUEST OF THE SOUTH
PHASE_CONQUEST = [
    E('kandalur', 'c. 988', 'Kandalur Salai — shattering the southern alliance', ['BATTLE', 'TRIUMPH'],
      'Rajaraja opens his conquests with a resounding victory at Kandalur Salai on the Kerala coast, smashing a Chera naval base and breaking the confederacy of Cheras, Pandyas and Sinhalas ranged against him — a triumph he proclaims proudly in his inscriptions.',
      svg_stack('The first great victory', [
          {'n': 1, 'label': 'A southern confederacy', 'sub': 'Cheras, Pandyas and Sinhalas ranged against him', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Battle of Kandalur Salai', 'sub': 'smashes the Chera naval base, c. 988', 'color': '#9a3412'},
          {'n': 3, 'label': '“Destroyer of Kandalur Salai”', 'sub': 'the victory proclaimed in his inscriptions', 'color': '#166534'},
      ], takeaway='His opening campaign broke a coalition of enemies at sea — announcing a new power in the south.', accent=AC),
      bg='The <b>Cheras</b> of Kerala, allied with the <b>Pandyas</b> and the Sinhalas of Sri Lanka, formed a bloc against the rising Cholas.',
      people='the <b>Chera</b> ruler and his allies; the Pandya and Sinhala confederates; Rajaraja, the young conqueror.',
      what='Around <b>988</b> Rajaraja won a decisive battle at <b>Kandalur Salai</b> on the Kerala coast, destroying a Chera naval station and breaking the southern alliance — a feat commemorated in the title “<b>who destroyed the ships at Kandalur Salai</b>.”',
      crux='He struck first at the <b>coalition’s naval power</b>, shattering the alliance before it could combine against him.',
      conseq='The victory opened the way to the conquest of the Pandya and Chera heartlands.',
      matters='Break your enemies’ alliance early, and each falls in turn — Rajaraja’s first campaign set the pattern for his conquests.'),

    E('pandyacheras', 'c. 990s', 'Conquest of the Pandyas and Cheras — the Three-Crowned', ['BATTLE', 'TRIUMPH'],
      'Rajaraja overruns the ancient rival kingdoms of the Tamil land — taking the Pandya capital Madurai and subduing the Cheras — until he holds sway over all three of the classic Tamil crowns, proclaiming himself Mummudi Chola, the “Three-Crowned” lord of the south.',
      svg_row('Master of the three Tamil crowns', [
          {'n': 1, 'label': 'Takes Madurai from the Pandyas', 'sub': '“Thunderbolt to the Pandya race”', 'color': '#9a3412'},
          {'n': 2, 'label': 'Subdues the Cheras', 'sub': 'the Kerala kingdom brought to heel', 'color': '#a16207'},
          {'n': 3, 'label': 'Mummudi Chola', 'sub': 'the “Three-Crowned” lord of the Tamil land', 'color': '#166534'},
      ], edge_labels=['then', 'as'], takeaway='He conquered the two ancient rivals of the Cholas — uniting all three Tamil crowns under one throne.', accent=AC),
      bg='The <b>Pandyas</b> of Madurai and the <b>Cheras</b> of Kerala were the Cholas’ ancient rivals, the other two of the three classic Tamil dynasties.',
      people='the defeated <b>Pandya</b> and <b>Chera</b> rulers; Rajaraja, now overlord of the Tamil country.',
      what='Through the 990s Rajaraja <b>captured the Pandya capital Madurai</b> and subdued the Cheras, taking titles such as <b>Pandya Kulashani</b> (“thunderbolt to the Pandyas”) and <b>Mummudi Chola</b> — the “Three-Crowned,” lord of Cholas, Pandyas and Cheras alike.',
      crux='He <b>unified the whole Tamil land</b> under a single crown, ending centuries of three-way rivalry in his own favour.',
      conseq='With the south secured, Rajaraja turned his armies toward the Deccan plateau and the seas.',
      matters='He completed what generations of Cholas had sought — mastery of all three Tamil crowns under one emperor.'),

    E('deccan', 'c. 998–1004', 'Into the Deccan — the clash with the Western Chalukyas', ['BATTLE', 'POLITICS'],
      'Pushing north into the Deccan, Rajaraja annexes Gangapadi, Nolambapadi and Tadigaipadi in present-day Karnataka and collides with the great rival empire of the age — the Western Chalukyas of Kalyani — in a struggle for the plateau that would outlast his own reign.',
      svg_compare('Two empires collide on the Deccan', {
          'head': 'Chola empire', 'color': '#9a3412', 'items': [
              'Rajaraja pushing north from the Tamil land',
              'Annexes Gangapadi, Nolambapadi, Tadigaipadi',
              'Strikes at Chalukya territory in Karnataka',
              'Battle-hardened army and growing navy']},
          {'head': 'Western Chalukyas of Kalyani', 'color': '#3730a3', 'items': [
              'The dominant Deccan power under Satyashraya',
              'Contest the Vengi and Karnataka frontiers',
              'Long war for control of the plateau',
              'Rivalry unresolved at Rajaraja’s death']},
          verdict='A generational contest for the Deccan that neither side could finish',
          takeaway='Rajaraja carried Chola power onto the plateau — opening a rivalry with the Chalukyas that his heirs would inherit.', accent=AC),
      bg='North of the Tamil land lay the <b>Deccan plateau</b>, dominated by the <b>Western Chalukyas of Kalyani</b> — the other great power of southern India.',
      people='<b>Satyashraya</b>, the Western Chalukya king; the Gangas and Nolambas of Karnataka; Rajaraja’s northern armies.',
      what='Around <b>998–1004</b> Rajaraja annexed <b>Gangapadi, Nolambapadi and Tadigaipadi</b> in modern Karnataka and warred with the <b>Western Chalukyas</b> under Satyashraya for control of the Deccan and the eastern country of Vengi.',
      crux='He turned the Cholas into a <b>Deccan power</b>, contesting the plateau with the strongest rival empire of the south.',
      conseq='The Chalukya rivalry remained unresolved and would define Chola foreign policy for generations.',
      matters='Expansion breeds new rivalries — mastering the south drew Rajaraja into a longer contest for the whole of the peninsula.'),
]

# ==================================================================  PHASE 3 — MASTER OF THE SEAS
PHASE_SEA = [
    E('lanka', 'c. 993', 'The conquest of Sri Lanka — the fall of Anuradhapura', ['BATTLE', 'TRIUMPH'],
      'Rajaraja launches a naval invasion across the Palk Strait and conquers northern Sri Lanka, sacking the ancient royal capital of Anuradhapura and annexing the island’s north as a Chola province with its new capital renamed in his own honour.',
      svg_stack('Across the strait — the island subdued', [
          {'n': 1, 'label': 'A naval invasion of Lanka', 'sub': 'Chola fleets cross the Palk Strait, c. 993', 'color': '#9a3412'},
          {'n': 2, 'label': 'Anuradhapura sacked', 'sub': 'the ancient royal capital destroyed', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Northern Lanka annexed', 'sub': 'new capital renamed Jananathamangalam', 'color': '#166534'},
      ], takeaway='He carried Chola power overseas — ending Anuradhapura’s long reign and planting the empire on the island.', accent=AC),
      bg='Across the Palk Strait lay the kingdom of the Sinhalas, ruled from the ancient capital of <b>Anuradhapura</b> — long a rival and ally of the Cholas’ southern enemies.',
      people='the Sinhala king <b>Mahinda V</b>; the Chola fleets and armies; Rajaraja, directing the invasion.',
      what='Around <b>993</b> Rajaraja’s forces crossed to <b>Sri Lanka</b>, sacked <b>Anuradhapura</b>, and annexed the northern part of the island as a Chola province, shifting the capital to <b>Polonnaruwa</b>, renamed <b>Jananathamangalam</b> in his honour.',
      crux='He projected land power <b>across the sea</b>, turning the Chola realm into an overseas empire.',
      conseq='Chola rule over northern Lanka would endure and expand under his son Rajendra.',
      matters='Sea power lets an empire reach beyond its shores — Rajaraja made the Cholas masters of the waters around India.'),

    E('maldives', 'c. 1000s', 'The Maldives and the Indian Ocean — a great navy', ['BATTLE', 'REFORM'],
      'Rajaraja builds the most powerful navy India has yet seen and sends it far out into the Indian Ocean — seizing the Maldive and Laccadive islands and asserting Chola command of the sea lanes that carried the rich trade between the East and West.',
      svg_row('Command of the ocean', [
          {'n': 1, 'label': 'A great Chola navy', 'sub': 'the dominant sea power of the region', 'color': '#9a3412'},
          {'n': 2, 'label': 'The Maldives and Laccadives seized', 'sub': 'a naval expedition far into the ocean', 'color': '#a16207'},
          {'n': 3, 'label': 'The sea lanes commanded', 'sub': 'control of the East–West trade routes', 'color': '#166534'},
      ], edge_labels=['seizes', 'to'], takeaway='His fleets ranged far out to sea — making the Chola navy the master of the Indian Ocean trade.', accent=AC),
      bg='The <b>Indian Ocean</b> carried the wealth of trade between Arabia, India, Sri Lanka and Southeast Asia; command of its sea lanes meant command of that wealth.',
      people='the <b>Chola navy</b>, based at <b>Nagapattinam</b>; the island peoples of the Maldives and Laccadives; the merchant guilds of the coast.',
      what='Rajaraja built a powerful navy and sent a <b>naval expedition to the Maldive Islands</b> (and the Laccadives), projecting <b>Chola sea power across the Indian Ocean</b> and securing the maritime trade routes.',
      crux='He understood <b>naval power as imperial power</b> — dominating the ocean to control commerce and reach distant shores.',
      conseq='This maritime strength underpinned the great overseas expeditions of his son Rajendra to Southeast Asia.',
      matters='He built one of the earliest great blue-water navies of India — projecting power far beyond the subcontinent’s coasts.'),

    E('vengi', 'c. 1000–1012', 'Vengi, Kalinga and the reach of empire', ['POLITICS', 'BATTLE'],
      'To the northeast Rajaraja extends Chola influence over Vengi and up toward Kalinga, binding the Eastern Chalukyas by a marriage alliance and, at his empire’s height, ruling the whole of southern India from sea to sea.',
      svg_stack('The empire at its height', [
          {'n': 1, 'label': 'Vengi brought under influence', 'sub': 'the Telugu country on the east coast', 'color': '#9a3412'},
          {'n': 2, 'label': 'A marriage alliance', 'sub': 'his daughter Kundavai wed to Vimaladitya', 'color': '#a16207'},
          {'n': 3, 'label': 'From sea to sea', 'sub': 'reach extended toward Kalinga', 'color': '#166534'},
      ], takeaway='Diplomacy joined conquest — a marriage bound the east coast to the empire he had built from sea to sea.', accent=AC),
      bg='<b>Vengi</b>, the Telugu country between the Chola and Chalukya spheres, was a contested frontier ruled by the <b>Eastern Chalukyas</b>.',
      people='the Eastern Chalukya prince <b>Vimaladitya</b>; Rajaraja’s daughter <b>Kundavai</b>, given in marriage; the rival Western Chalukyas.',
      what='Rajaraja extended Chola influence over <b>Vengi</b> and toward <b>Kalinga</b>, securing the northeast partly by a <b>marriage alliance</b> — wedding his daughter Kundavai to the Eastern Chalukya prince Vimaladitya — so that at its height his empire spanned all of South India.',
      crux='He combined <b>conquest with dynastic diplomacy</b>, binding frontier powers to the Chola house by blood as well as arms.',
      conseq='The empire he assembled reached from the Deccan to the seas and passed intact to his son Rajendra.',
      matters='The greatest empires are held by marriage and alliance as much as by the sword — Rajaraja used both.'),
]

# ==================================================================  PHASE 4 — THE GREAT TEMPLE & THE STATE
PHASE_STATE = [
    E('survey', 'c. 1000', 'The great land survey — remaking the revenue state', ['REFORM', 'POLITICS'],
      'At the height of his power Rajaraja orders a vast survey of the land — measuring fields, assessing their yield, and reorganising the empire into new revenue divisions — building a centralised fiscal machine that turns conquest into durable, taxable order.',
      svg_row('Turning conquest into a state', [
          {'n': 1, 'label': 'A great land survey, c. 1000', 'sub': 'fields measured, yields assessed', 'color': '#9a3412'},
          {'n': 2, 'label': 'New revenue divisions', 'sub': 'the realm reorganised into valanadus', 'color': '#a16207'},
          {'n': 3, 'label': 'A centralised fiscal state', 'sub': 'conquest made taxable and durable', 'color': '#166534'},
      ], edge_labels=['into', 'as'], takeaway='He measured his empire to tax it — building the administrative machine that outlasted the conquests.', accent=AC),
      bg='A sprawling empire won by arms needed a system to <b>administer and finance it</b>; Rajaraja set out to build one.',
      people='the royal revenue officers and surveyors; the local landholders and assemblies; Rajaraja, the reforming emperor.',
      what='Around <b>1000</b> Rajaraja ordered a comprehensive <b>land survey and revenue assessment</b>, measuring fields and reorganising the empire into administrative units called <b>valanadus</b> — replacing older hereditary lordships with a more centralised fiscal order.',
      crux='He converted <b>military conquest into administrative order</b>, measuring the land so the state could tax and govern it reliably.',
      conseq='The reformed revenue system gave the Chola state the resources for war, navy and monumental building alike.',
      matters='Empires endure on administration, not just conquest — Rajaraja’s survey built the fiscal spine of the Chola state.'),

    E('selfgov', 'reign of Rajaraja', 'Local self-government — the village assemblies', ['REFORM', 'POLITICS'],
      'Beneath the centralised revenue state Rajaraja preserves and works through a remarkable system of local self-government — village and town assemblies that manage land, irrigation, temples and taxes, with elected committees and careful audit, one of the most sophisticated local governance systems of the medieval world.',
      svg_stack('Governing through the village', [
          {'n': 1, 'label': 'Village and town assemblies', 'sub': 'sabhas and urs managing local affairs', 'color': '#9a3412'},
          {'n': 2, 'label': 'Elected committees and audit', 'sub': 'land, irrigation, temples and taxes managed', 'color': '#a16207'},
          {'n': 3, 'label': 'Autonomy within the empire', 'sub': 'local self-rule under central oversight', 'color': '#166534'},
      ], takeaway='He ruled a vast empire through self-governing villages — central power resting on local assemblies.', accent=AC),
      bg='Chola society rested on largely self-governing <b>village and town assemblies</b> that managed local affairs — a tradition Rajaraja strengthened rather than swept aside.',
      people='the village <b>assemblies (sabhas and urs)</b> and their elected committees; the royal auditors; the local temples they administered.',
      what='Rajaraja worked through and refined a system of <b>local self-government</b> — village assemblies with <b>elected committees and formal audit</b> handling land, irrigation, temples and tax collection — while binding them to the central revenue administration.',
      crux='He balanced <b>central control with local autonomy</b>, governing an empire through the self-rule of its villages.',
      conseq='This durable local order helped the Chola state administer its vast lands for generations.',
      matters='One of the medieval world’s most developed systems of local self-government underpinned Rajaraja’s empire.'),

    E('brihadeeswarar', '1010', 'The Rajarajeswaram — the great temple at Thanjavur', ['TRIUMPH', 'REFORM'],
      'In 1010 Rajaraja completes his crowning monument — the vast granite Rajarajeswaram (Brihadeeswarar) Temple at his capital Thanjavur, crowned by a towering vimana and dedicated to Shiva: an unmatched masterpiece of Dravidian architecture and the emblem of his reign.',
      svg_row('A monument in granite', [
          {'n': 1, 'label': 'Built at Thanjavur', 'sub': 'the imperial capital, completed 1010', 'color': '#9a3412'},
          {'n': 2, 'label': 'A towering granite vimana', 'sub': 'a masterpiece of Dravidian architecture', 'color': '#a16207'},
          {'n': 3, 'label': 'Dedicated to Shiva', 'sub': 'the emblem of Rajaraja’s reign', 'color': '#166534'},
      ], edge_labels=['with', 'for'], takeaway='He raised the greatest temple of his age — a granite mountain to Shiva that still crowns Thanjavur.', accent=AC),
      bg='At his capital <b>Thanjavur</b>, Rajaraja set out to build a temple grander than any before it — a monument to Shiva and to his own imperial glory.',
      people='the architects, sculptors and thousands of workers; the temple’s vast endowed staff; Rajaraja, its royal builder.',
      what='In <b>1010</b> Rajaraja completed the <b>Rajarajeswaram</b> (later <b>Brihadeeswarar</b>) Temple — a colossal <b>granite</b> structure crowned by a soaring <b>vimana (tower) over 60 m tall</b>, dedicated to <b>Shiva</b> and richly endowed with lands, gold and staff, all recorded in its inscriptions.',
      crux='The temple fused <b>faith, art and imperial power</b> — a granite statement of the emperor’s devotion and might.',
      conseq='The temple stands today as a <b>UNESCO World Heritage Site</b>, the finest surviving monument of the Chola age.',
      matters='It is one of the supreme achievements of Indian architecture — a thousand-year-old masterpiece that still crowns Thanjavur.'),
]

# ==================================================================  PHASE 5 — FAITH, CULTURE AND LEGACY
PHASE_LEGACY = [
    E('shaivism', 'reign of Rajaraja', 'Patron of Shaivism and Tamil culture', ['REFORM', 'POLITICS'],
      'A devoted Shaivite who called himself “Shivapadasekhara,” Rajaraja is also a great patron of Tamil culture — sponsoring the recovery and collection of the sacred Tevaram hymns, and, in a mark of his tolerance, endowing a Buddhist monastery on his coast at the request of a Southeast Asian king.',
      svg_stack('Faith, tolerance and Tamil letters', [
          {'n': 1, 'label': 'A devoted Shaivite', 'sub': '“Shivapadasekhara” — crown at Shiva’s feet', 'color': '#9a3412'},
          {'n': 2, 'label': 'Recovers the Tevaram hymns', 'sub': 'the Tamil Shaiva canon collected anew', 'color': '#a16207'},
          {'n': 3, 'label': 'Endows a Buddhist vihara', 'sub': 'the Chudamani Vihara at Nagapattinam', 'color': '#166534'},
      ], takeaway='Fervent in his own faith yet tolerant of others, he nourished Tamil devotion and letters as few rulers had.', accent=AC),
      bg='Rajaraja was a fervent devotee of <b>Shiva</b>, yet ruled a realm of many faiths and traditions along its trading coasts.',
      people='the Shaiva saint-poets <b>Sambandar, Appar and Sundarar</b>; the collector <b>Nambiyandar Nambi</b>; the Srivijaya king who sought the vihara.',
      what='Styling himself <b>Shivapadasekhara</b>, Rajaraja sponsored the recovery and arrangement of the <b>Tevaram</b> hymns of the Tamil Shaiva canon (with Nambiyandar Nambi), while also — in a mark of tolerance — endowing the <b>Chudamani Vihara</b>, a Buddhist monastery at <b>Nagapattinam</b>, at the request of a Srivijaya king.',
      crux='He was <b>devout yet tolerant</b> — championing Shaivism and Tamil letters while patronising other faiths that served his realm.',
      conseq='His patronage helped shape the enduring canon of Tamil Shaiva devotion and the flowering of Chola art.',
      matters='Great rulers nourish culture as well as conquest — Rajaraja helped preserve the sacred literature of the Tamil people.'),

    E('death', '1014', 'Death and the succession of Rajendra', ['DEATH', 'TURNING POINT'],
      'Rajaraja dies in 1014 after nearly three decades on the throne, having already raised his able son Rajendra as co-regent — handing on an empire at the height of its power, secure, wealthy and poised to reach even further across the seas.',
      svg_row('The empire passes on', [
          {'n': 1, 'label': 'Dies in 1014', 'sub': 'after nearly thirty years of rule', 'color': '#9a3412'},
          {'n': 2, 'label': 'Rajendra already co-regent', 'sub': 'a trained and able heir prepared', 'color': '#a16207'},
          {'n': 3, 'label': 'An empire at its height', 'sub': 'secure, wealthy and poised to expand', 'color': '#166534'},
      ], edge_labels=['to', 'as'], takeaway='He died leaving not decline but an empire at its zenith — and a groomed heir to carry it further.', accent=AC),
      bg='After a reign of nearly thirty years, Rajaraja had already associated his son <b>Rajendra</b> with the throne as co-regent.',
      people='<b>Rajendra Chola I</b>, the heir; the great officers and generals of the empire; the mourning Chola realm.',
      what='Rajaraja died in <b>1014</b>, having prepared his son <b>Rajendra I</b> to succeed him, and passed on an empire at the peak of its strength — dominant on land and sea across the whole south.',
      crux='He bequeathed <b>strength, not decline</b> — an empire secure enough for his heir to expand still further.',
      conseq='Rajendra would carry Chola arms to the Ganges and across the sea to Southeast Asia, extending his father’s work.',
      matters='The measure of a builder is what survives him — Rajaraja left an empire poised for its greatest expansion.'),

    E('legacy', 'after 1014', 'Rajaraja the Great — a towering figure of Indian history', ['POLITICS', 'TRIUMPH'],
      'Rajaraja is remembered as the emperor who raised the Cholas to imperial greatness — uniting the south, mastering the seas, reforming the state, and building the great temple of Thanjavur — a towering figure of Tamil and Indian history whose reign marks the golden age of the Chola dynasty.',
      svg_stack('The measure of a great reign', [
          {'n': 1, 'label': 'United the south, mastered the seas', 'sub': 'an empire from the Deccan to the ocean', 'color': '#9a3412'},
          {'n': 2, 'label': 'Reformed the state, built the temple', 'sub': 'revenue survey and the Rajarajeswaram', 'color': '#a16207'},
          {'n': 3, 'label': 'The golden age of the Cholas', 'sub': 'a towering figure of Indian history', 'color': '#166534'},
      ], takeaway='Conqueror, administrator and builder — Rajaraja stands among the greatest rulers South India ever produced.', accent=AC),
      bg='By his death Rajaraja had transformed the Cholas from a reviving kingdom into the pre-eminent empire of southern India and the Indian Ocean.',
      people='his son <b>Rajendra I</b> and the later Chola emperors; the historians and Tamil tradition that revere him; the empire he built.',
      what='Rajaraja is remembered as <b>Rajaraja the Great</b> — the emperor who <b>united the Tamil south, projected Chola sea power across the Indian Ocean, reformed the state, and built the great temple of Thanjavur</b> — inaugurating the golden age of the Chola dynasty.',
      crux='He is celebrated as a rare <b>complete emperor</b> — conqueror, administrator, patron and builder in one.',
      conseq='His reign set the model of Chola greatness that his successors upheld and that Tamil memory still honours.',
      matters='He remains one of the towering figures of Tamil and Indian history — the maker of Chola imperial greatness.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Raja Raja Chola I raised the Chola dynasty of Tamil South India to imperial and maritime greatness. Born Arulmozhi Varman and crowned in 985 as “king of kings,” he united the Tamil land by conquering the Pandyas and Cheras, carried Chola arms into the Deccan against the Western Chalukyas, and projected sea power across the Indian Ocean — conquering northern Sri Lanka and sending a fleet to the Maldives. At home he remade the state with a great land survey and worked through remarkable village self-government, and crowned his reign with the colossal granite temple at Thanjavur. He is the ultimate study in <b>conquest, sea power, administration and monumental art fused in one reign.</b></p>
<div class="ov-quote">Rajaraja — “king of kings,” builder of the Rajarajeswaram at Thanjavur<span>— the golden age of the Cholas</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born a prince of a reviving dynasty and patient before the throne → crowned Rajaraja in 985 → shatters the southern alliance at Kandalur Salai and conquers the Pandyas and Cheras → pushes into the Deccan against the Chalukyas → conquers northern Sri Lanka and sends his navy to the Maldives → surveys the land and reforms the revenue state → builds the great temple of Thanjavur (1010) → patronises Shaivism and Tamil culture → and dies in 1014 leaving an empire at its height to his son Rajendra.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⚔️</div><h4>The conqueror of the south</h4><p>United the Tamil land and made the Cholas an empire.</p></div>
  <div class="ov-card"><div class="i">⛵</div><h4>Master of the seas</h4><p>Built a navy that dominated the Indian Ocean trade.</p></div>
  <div class="ov-card"><div class="i">📜</div><h4>The reforming state</h4><p>A land survey and village self-government at its base.</p></div>
  <div class="ov-card"><div class="i">🛕</div><h4>The great temple</h4><p>The granite Rajarajeswaram at Thanjavur, completed 1010.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Making of an Emperor</b><small> c. 947–985</small><p>Prince, patient heir, and accession as Rajaraja.</p></div>
  <div><b>2 · Conquest of the South</b><small> 985–1004</small><p>Kandalur, the Pandyas and Cheras, the Deccan.</p></div>
  <div><b>3 · Master of the Seas</b><small> 993–1012</small><p>Sri Lanka, the Maldives, Vengi and the navy.</p></div>
  <div><b>4 · The Great Temple & the State</b><small> 1000–1010</small><p>Land survey, self-government, and Thanjavur.</p></div>
  <div><b>5 · Faith, Culture and Legacy</b><small> 1010–1014</small><p>Shaivism, Tamil letters, and Rajaraja the Great.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Rajendra Chola I', 'role': 'son and successor', 'color': '#9a3412',
     'bio': 'Rajaraja’s able son, raised as co-regent, who succeeded him in 1014 and carried Chola arms to the Ganges and across the sea to Southeast Asia.',
     'rel': 'The heir who extended his father’s empire to its greatest reach.'},
    {'name': 'Kundavai', 'role': 'elder sister', 'color': '#a16207',
     'bio': 'Rajaraja’s influential elder sister, a powerful figure at court and a generous patron of temples throughout his reign.',
     'rel': 'His lifelong ally and a pillar of the dynasty.'},
    {'name': 'Uttama Chola', 'role': 'uncle and predecessor', 'color': '#166534',
     'bio': 'Rajaraja’s uncle, to whom he deferred the throne after the murder of his brother, ruling until his death cleared the way for Rajaraja in 985.',
     'rel': 'The predecessor whose crown Rajaraja patiently waited to inherit.'},
    {'name': 'Satyashraya', 'role': 'Chalukya rival', 'color': '#3730a3',
     'bio': 'The Western Chalukya king of Kalyani who contested the Deccan and Vengi with Rajaraja in a long, unresolved struggle for the plateau.',
     'rel': 'His chief rival among the powers of southern India.'},
    {'name': 'Nambiyandar Nambi', 'role': 'religious collector', 'color': '#7c2d12',
     'bio': 'The devotee who, under Rajaraja’s patronage, recovered and arranged the Tevaram hymns of the Tamil Shaiva saints.',
     'rel': 'The collaborator in preserving the Tamil Shaiva canon.'},
]

KEY_EVENTS = [
    ('c. 947', 'Arulmozhi Varman born', 'A prince of the reviving Chola house.'),
    ('985', 'Accession as Rajaraja', '“King of kings” takes the throne.'),
    ('c. 988', 'Kandalur Salai', 'Breaks the southern alliance.'),
    ('c. 993', 'Conquest of Sri Lanka', 'Anuradhapura sacked; the north annexed.'),
    ('990s', 'Pandyas and Cheras subdued', 'Master of the three Tamil crowns.'),
    ('c. 1000', 'The great land survey', 'Remaking the revenue state.'),
    ('998–1004', 'Deccan campaigns', 'War with the Western Chalukyas.'),
    ('1010', 'Rajarajeswaram completed', 'The great temple at Thanjavur.'),
    ('1014', 'Death of Rajaraja', 'An empire at its height passes to Rajendra.'),
]

MASTER = [
    {'year': 'c. 947', 'age': 'born', 'phase': 'The Making of an Emperor', 'title': 'Arulmozhi Varman born', 'desc': 'A prince of the reviving Cholas.'},
    {'year': '985', 'age': 'age ~38', 'phase': 'The Making of an Emperor', 'title': 'Accession as Rajaraja', 'desc': '“King of kings” crowned.'},
    {'year': 'c. 993', 'age': 'age ~46', 'phase': 'Master of the Seas', 'title': 'Conquest of Sri Lanka', 'desc': 'Anuradhapura sacked.'},
    {'year': 'c. 1000', 'age': 'age ~53', 'phase': 'The Great Temple & the State', 'title': 'The land survey', 'desc': 'Remaking the revenue state.'},
    {'year': '1010', 'age': 'age ~63', 'phase': 'The Great Temple & the State', 'title': 'Great temple completed', 'desc': 'The Rajarajeswaram at Thanjavur.'},
    {'year': '1014', 'age': 'age ~67', 'phase': 'Faith, Culture and Legacy', 'title': 'Death of Rajaraja', 'desc': 'An empire at its height.'},
]

SOURCES = [
    ('Britannica — Rajaraja I', 'https://www.britannica.com/biography/Rajaraja-I'),
    ('Wikipedia — Rajaraja I', 'https://en.wikipedia.org/wiki/Rajaraja_I'),
    ('Britannica — Chola dynasty', 'https://www.britannica.com/topic/Chola-dynasty'),
    ('UNESCO — Great Living Chola Temples', 'https://whc.unesco.org/en/list/250'),
    ('New World Encyclopedia — Raja Raja Chola I', 'https://www.newworldencyclopedia.org/entry/Raja_Raja_Chola_I'),
]

def build_meta():
    return {
        'pid': 'gm-rajarajachola.html', 'kind': 'man', 'emoji': '🛕', 'accent': AC,
        'name': 'Raja Raja Chola I', 'years': '947–1014', 'group': 'Indian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Chola emperor who raised Tamil South India to imperial greatness — conqueror of the south and Sri Lanka, master of the Indian Ocean, reformer of the state, and builder of the great granite temple at Thanjavur.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Making of an Emperor', 'type': 'timeline',
             'intro': 'Born Arulmozhi Varman into a reviving dynasty, he waits patiently through a bloody succession before ascending the throne in 985 as Rajaraja, “king of kings.”', 'events': PHASE_RISE},
            {'id': 'conquest', 'label': '2 · Conquest of the South', 'type': 'timeline',
             'intro': 'He shatters a southern alliance at Kandalur Salai, conquers the Pandyas and Cheras to unite the Tamil land, and pushes into the Deccan against the Western Chalukyas.', 'events': PHASE_CONQUEST},
            {'id': 'sea', 'label': '3 · Master of the Seas', 'type': 'timeline',
             'intro': 'He conquers northern Sri Lanka, sends his navy far into the Indian Ocean to the Maldives, and extends the empire over Vengi — commanding the seas around India.', 'events': PHASE_SEA},
            {'id': 'state', 'label': '4 · The Great Temple & the State', 'type': 'timeline',
             'intro': 'He remakes the state with a vast land survey and works through remarkable village self-government, and crowns his reign with the great granite temple at Thanjavur.', 'events': PHASE_STATE},
            {'id': 'legacy', 'label': '5 · Faith, Culture and Legacy', 'type': 'timeline',
             'intro': 'A devoted yet tolerant Shaivite and patron of Tamil letters, he dies in 1014 leaving an empire at its height — remembered as Rajaraja the Great.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies, Chola inscriptions and encyclopaedic sources; some dates are approximate and given as commonly reconstructed by historians.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
