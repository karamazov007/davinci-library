# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Gautama Buddha (Siddhartha Gautama).
The Shakya prince who renounced a kingdom, awakened under the Bodhi tree,
and founded one of the world’s great spiritual traditions.

Handled with respect for the Buddhist tradition’s own account and for the
historical record. Where devotional tradition and modern scholarship differ,
the difference is noted evenly, without adjudicating any truth claim."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b45309'  # saffron / monastic ochre

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE SHELTERED PRINCE
PHASE_PRINCE = [
    E('birth', 'c. 563 BC (trad.)', 'Born at Lumbini — a prince of the Shakyas', ['RISE'],
      'By tradition Siddhartha Gautama is born in a grove at Lumbini to Queen Maya and Suddhodana, chief of the Shakya clan of Kapilavastu; the sage Asita foretells that the child will become either a world-ruling king or a supremely enlightened teacher — and his father resolves to make him the former.',
      svg_row('A prince marked at birth', [
          {'n': 1, 'label': 'Born to the Shakyas', 'sub': 'Lumbini; father Suddhodana, mother Maya', 'color': '#b45309'},
          {'n': 2, 'label': 'The sage’s prophecy', 'sub': 'Asita: a great king — or a Buddha', 'color': '#a16207'},
          {'n': 3, 'label': 'A father’s resolve', 'sub': 'Suddhodana wills him to rule, not renounce', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='A prophecy split the child’s destiny in two — and set his father against the very path he would one day take.', accent=AC),
      bg='The <b>Shakyas</b> were a clan (an oligarchic republic in the accounts) of the Ganges foothills, seated at <b>Kapilavastu</b> near the present India–Nepal border. Their chief, <b>Suddhodana</b>, was Siddhartha’s father.',
      people='<b>Siddhartha Gautama</b>, the newborn prince; his father <b>Suddhodana</b>; his mother <b>Queen Maya</b>, who tradition says died soon after; the seer <b>Asita</b>.',
      what='Buddhist tradition places the birth in a grove at <b>Lumbini</b>. The sage <b>Asita</b> examined the infant and prophesied he would become either a <b>chakravartin</b> (universal monarch) or a <b>fully awakened Buddha</b>. His father, wanting an heir, determined to bind him to the throne.',
      crux='From the first, two futures pulled at him — <b>worldly kingship</b> or <b>spiritual awakening</b> — and his father’s whole strategy was to foreclose the second.',
      conseq='Suddhodana surrounded the boy with pleasure and shielded him from all suffering, hoping he would never feel the discontent that drives a man to renounce.',
      matters='The tradition frames his life as a choice between crown and truth — the arc of every following chapter is the slow victory of the second over the first.'),

    E('palace', 'boyhood', 'The gilded cage — a life without suffering', ['RISE'],
      'To keep the prophecy from coming true, Suddhodana raises Siddhartha inside a world engineered to hide age, sickness and death: three seasonal palaces, every pleasure, and orders that the old and ill be kept from his sight — a sheltered perfection that leaves the prince curious about the world beyond the walls.',
      svg_stack('Engineering a world without pain', [
          {'n': 1, 'label': 'Three palaces, every luxury', 'sub': 'one for each season; music, gardens, ease', 'color': '#b45309'},
          {'n': 2, 'label': 'Suffering hidden from sight', 'sub': 'the aged and sick kept from the prince', 'color': '#a16207'},
          {'n': 3, 'label': 'A restless curiosity grows', 'sub': 'he senses a world beyond the walls', 'color': '#166534'},
      ], takeaway='A life sealed against all pain could delay the great questions — but not silence them.', accent=AC),
      bg='Fearing the ascetic destiny Asita had named, Suddhodana built his son a life of <b>unbroken comfort</b>, keeping every reminder of mortality out of view.',
      people='<b>Siddhartha</b>, the sheltered prince; <b>Suddhodana</b>, the anxious father; the courtiers and attendants who maintained the illusion.',
      what='Tradition holds that the prince was raised amid <b>three seasonal palaces</b> and every refinement, deliberately screened from any sight of <b>old age, sickness, poverty or death</b>, so that no discontent would turn him toward renunciation.',
      crux='His father tried to defeat the prophecy by <b>removing its cause</b> — the encounter with suffering — a strategy that could only ever postpone it.',
      conseq='The very completeness of his shelter sharpened his eventual shock when reality broke through, giving the Four Sights their shattering force.',
      matters='Comfort can wall out suffering for a time, but the tradition’s point is that the great questions of existence cannot be permanently kept at bay.'),

    E('marriage', 'age 16 (trad.)', 'Yasodhara and Rahula — the ties that bind', ['LOVE'],
      'Siddhartha marries the princess Yasodhara and in time they have a son — whom he names Rahula, a word tradition reads as “fetter” — completing the golden chain of family, rank and pleasure that his father hoped would hold him to the palace forever.',
      svg_row('The last bonds to the world', [
          {'n': 1, 'label': 'Marriage to Yasodhara', 'sub': 'a princess; the family’s design fulfilled', 'color': '#b45309'},
          {'n': 2, 'label': 'A son is born', 'sub': 'named Rahula — read as “fetter”', 'color': '#a16207'},
          {'n': 3, 'label': 'The golden chain complete', 'sub': 'rank, love and heir bind him to the throne', 'color': '#166534'},
      ], edge_labels=['then', 'yet'], takeaway='Every tie meant to hold him — wife, son, kingdom — would become exactly what he had to leave behind.', accent=AC),
      bg='In keeping with his rank and his father’s plan, the prince was married young and given every reason to remain — a settled household to anchor him to worldly life.',
      people='<b>Siddhartha</b>; his wife <b>Yasodhara</b>; their son <b>Rahula</b>; his father <b>Suddhodana</b>, who saw the family as insurance against renunciation.',
      what='Siddhartha married <b>Yasodhara</b>, and they had a son, <b>Rahula</b> — a name the tradition glosses as “<b>fetter</b>” or “bond,” marking how the prince already felt the pull of attachment even as the child was born.',
      crux='The marriage and heir were meant to be <b>the final anchor</b> — yet the tradition turns them into the sharpest emblem of the attachments he would renounce.',
      conseq='It was on the very night of Rahula’s birth, the accounts say, that Siddhartha resolved to leave — the completion of his worldly life becoming the trigger for his departure.',
      matters='The story sets love and duty against the spiritual quest — the things that bind us to the world are exactly what the renunciant must be willing to release.'),
]

# ==================================================================  PHASE 2 — THE GREAT RENUNCIATION
PHASE_RENOUNCE = [
    E('foursights', 'age 29 (trad.)', 'The Four Sights — reality breaks through', ['TURNING POINT'],
      'Venturing beyond the palace, Siddhartha sees for the first time an old man, a sick man, and a corpse — the truth of aging, illness and death his father had hidden — and then a wandering ascetic, serene amid it all; the four encounters shatter his sheltered world and set him seeking a way beyond suffering.',
      svg_row('Four encounters that shattered a world', [
          {'n': 1, 'label': 'Age, sickness, death', 'sub': 'an old man, a sick man, a corpse', 'color': '#9f1239'},
          {'n': 2, 'label': 'The shock of mortality', 'sub': 'no rank escapes decay and death', 'color': '#78350f'},
          {'n': 3, 'label': 'The serene ascetic', 'sub': 'a seeker at peace points a way out', 'color': '#166534'},
      ], edge_labels=['reveal', 'then'], takeaway='Confronted at last with suffering, the prince could no longer un-see it — the search for release had begun.', accent=AC),
      bg='Growing restless, the prince rode out from the palace grounds — and encountered the realities of the human condition his father had spent a lifetime concealing.',
      people='<b>Siddhartha</b>; by tradition his charioteer <b>Channa</b>, who explains each sight; the anonymous old man, sick man, corpse and ascetic.',
      what='On successive outings Siddhartha saw the <b>Four Sights</b>: an <b>old man</b>, a <b>diseased man</b>, and a <b>decaying corpse</b> — teaching him that aging, sickness and death spare no one — and finally a calm <b>wandering ascetic</b>, who showed that a person might seek a way beyond suffering.',
      crux='The shelter broke in a single stroke: he grasped that <b>suffering, decay and death are universal</b>, and that pleasure and rank offer no exemption.',
      conseq='Unable to return to the palace in peace, he resolved to leave everything and seek a path to the end of suffering.',
      matters='The Four Sights are the tradition’s image of awakening to the human condition — the moment comfort gives way to the questions that define a life.'),

    E('renunciation', 'age 29 (trad.)', 'The Great Renunciation — leaving the palace', ['TURNING POINT', 'EXILE'],
      'In the night Siddhartha looks one last time on his sleeping wife and son, rides beyond the city with his charioteer Channa, sheds his princely ornaments and cuts his hair, and — at twenty-nine — becomes a homeless wanderer in search of an end to suffering: the Great Renunciation.',
      svg_stack('Trading a kingdom for the road', [
          {'n': 1, 'label': 'A last look, then away', 'sub': 'leaves Yasodhara and Rahula sleeping', 'color': '#b45309'},
          {'n': 2, 'label': 'Rank cast off', 'sub': 'sheds ornaments, cuts his hair, dons rags', 'color': '#a16207'},
          {'n': 3, 'label': 'A homeless seeker', 'sub': 'at 29 he takes up the wandering life', 'color': '#166534'},
      ], takeaway='He gave up a certain crown for an uncertain truth — the pivot on which the whole tradition turns.', accent=AC),
      bg='After the Four Sights, the prince could no longer accept a life of pleasure while suffering and death awaited all. He resolved to renounce his inheritance.',
      people='<b>Siddhartha</b>, now a seeker; his charioteer <b>Channa</b> and horse <b>Kanthaka</b>, who bear him away; the sleeping <b>Yasodhara</b> and <b>Rahula</b> he leaves behind.',
      what='At about <b>age 29</b> Siddhartha slipped from the palace by night, rode beyond Kapilavastu, sent back Channa and his horse, and <b>cut off his hair, exchanged his robes for a beggar’s, and became a wandering mendicant</b> — the event tradition calls the <b>Great Renunciation</b>.',
      crux='He chose the <b>homeless life of a seeker</b> over kingship, wealth and family — staking everything on the possibility of a way beyond suffering.',
      conseq='He now sought out the leading spiritual teachers of the day, entering the world of the Ganges-plain renunciants.',
      matters='The Great Renunciation is the founding act of the story — the deliberate surrender of every worldly good for the sake of the deepest question.'),

    E('asceticism', 'age 29–35 (trad.)', 'Six years of extreme asceticism', ['REFORM'],
      'Siddhartha masters the deep meditative states of the teachers Alara Kalama and Uddaka Ramaputta but finds they do not end suffering; joining five fellow ascetics, he drives self-mortification to its limit — near-starvation, until he can feel his spine through his belly — yet awakening still does not come.',
      svg_stack('Pushing renunciation to its limit', [
          {'n': 1, 'label': 'Masters the meditative teachers', 'sub': 'Alara Kalama, Uddaka Ramaputta — still unfree', 'color': '#b45309'},
          {'n': 2, 'label': 'Extreme self-mortification', 'sub': 'with five ascetics; near-starvation', 'color': '#78350f'},
          {'n': 3, 'label': 'The body fails, truth eludes', 'sub': 'emaciated to the bone; no awakening', 'color': '#9f1239'},
      ], takeaway='He took austerity as far as a body could go — and proved to himself that punishing the flesh was not the road to freedom.', accent=AC),
      bg='Renunciant India offered two chief methods — deep meditation and severe asceticism. Siddhartha pursued both to their extremes in his search for liberation.',
      people='<b>Siddhartha</b>; his teachers <b>Alara Kalama</b> and <b>Uddaka Ramaputta</b>; the <b>five ascetics</b> (led by Kondanna) who practised alongside him.',
      what='Siddhartha first attained the <b>highest formless meditative states</b> under two renowned teachers, but judged they did not end suffering. He then undertook <b>severe asceticism</b> with five companions, fasting until, the texts say, he was <b>emaciated to the bone</b> — yet awakening did not come.',
      crux='He tested the extreme of <b>self-denial</b> as rigorously as he had once known the extreme of indulgence — and found both wanting.',
      conseq='Near death and no closer to freedom, he abandoned mortification — a turn his five companions saw as failure, and they left him.',
      matters='His years of austerity are the tradition’s proof that neither indulgence nor self-torture liberates — clearing the ground for the Middle Way.'),
]

# ==================================================================  PHASE 3 — THE AWAKENING
PHASE_AWAKEN = [
    E('middleway', 'age 35 (trad.)', 'The Middle Way — rejecting both extremes', ['TURNING POINT'],
      'Starved and unfree, Siddhartha accepts a bowl of milk-rice from the village girl Sujata and recovers his strength — concluding that liberation lies neither in indulgence nor in mortification but on a Middle Way between them; his five companions, seeing him eat, take it for backsliding and abandon him.',
      svg_compare('Two dead ends — and the path between', {
          'head': 'The two extremes he rejected', 'color': '#9f1239',
          'items': ['Sensual indulgence — his palace life of pleasure',
                    'Severe self-mortification — his years of fasting',
                    'Each leaves craving and suffering intact'],
      }, {
          'head': 'The Middle Way he chose', 'color': '#166534',
          'items': ['Neither pleasure-seeking nor self-torture',
                    'A balanced path of discipline and insight',
                    'Restores the body; steadies the mind for awakening'],
      }, verdict='Reject both extremes: the Middle Way is the ground of the awakening to come.',
         takeaway='Between the palace and the fast lay a third road — moderation as the path to freedom.', accent=AC),
      bg='After six years, extreme asceticism had brought Siddhartha near death without liberation. He recalled a childhood moment of calm meditation and reconsidered his method.',
      people='<b>Siddhartha</b>; the milkmaid <b>Sujata</b>, whose offering revives him; the <b>five ascetics</b>, who leave in disgust when he eats.',
      what='Siddhartha accepted <b>milk-rice from Sujata</b>, ended his fast, and recovered his strength, having concluded that awakening comes not through pleasure or through self-torment but along a <b>Middle Way</b> between them. His five companions, taking this for a return to soft living, <b>departed for Sarnath</b>.',
      crux='He reframed the whole quest: the goal was not to punish the body but to <b>free the mind</b> — and a wasted body could not do that work.',
      conseq='Restored and resolved, he sat beneath a pipal tree at Bodh Gaya, determined not to rise until he had reached the truth.',
      matters='The Middle Way becomes a defining principle of the tradition — balance and non-extremism as the ground of both practice and ethics.'),

    E('bodhi', 'age 35 (trad.)', 'Enlightenment under the Bodhi tree at Bodh Gaya', ['TRIUMPH'],
      'Seated beneath a pipal tree at Bodh Gaya, Siddhartha vows not to rise until he is free; through a night in which tradition says the tempter Mara assails him, he passes into ever-deeper insight — recalling past lives, seeing the workings of karma, and grasping the origin and end of suffering — and at dawn awakens as the Buddha, “the Awakened One.”',
      svg_stack('The night of awakening', [
          {'n': 1, 'label': 'The vow beneath the tree', 'sub': 'Bodh Gaya; not to rise until free', 'color': '#b45309'},
          {'n': 2, 'label': 'Mara’s assault withstood', 'sub': 'temptation and fear, the tradition holds', 'color': '#78350f'},
          {'n': 3, 'label': 'Insight into suffering', 'sub': 'past lives, karma, its origin and end', 'color': '#a16207'},
          {'n': 4, 'label': 'Awakening at dawn', 'sub': 'he becomes the Buddha, “the Awakened One”', 'color': '#166534'},
      ], takeaway='After a night of struggle he saw the whole mechanism of suffering — and its ending — and rose awakened.', accent=AC),
      bg='Having found the Middle Way and recovered his strength, Siddhartha sat in meditation beneath a <b>pipal tree</b> (thereafter the “Bodhi tree”) at <b>Bodh Gaya</b> in what is now Bihar.',
      people='<b>Siddhartha</b>, on the verge of Buddhahood; <b>Mara</b>, the tempter who, in the accounts, tries to break his resolve; the earth itself, called as witness.',
      what='Through the night Siddhartha deepened in meditation — traditionally recalling his <b>former lives</b>, perceiving the <b>death and rebirth of beings by karma</b>, and comprehending the <b>Four Noble Truths</b> and <b>Dependent Origination</b>: how suffering arises and how it ceases. At dawn he attained <b>nirvana</b> and became the <b>Buddha</b>.',
      crux='The awakening was an <b>insight into the causal structure of suffering</b> — its arising through craving and ignorance, and the possibility of its complete cessation.',
      conseq='He remained near the tree for weeks savouring his liberation, then faced the question of whether so subtle a truth could be taught at all.',
      matters='The Enlightenment at Bodh Gaya is the pivot of the whole tradition — the moment that turns Siddhartha the seeker into the Buddha the teacher.'),

    E('decision', 'after enlightenment', 'To teach or to keep silence', ['REFORM'],
      'The Buddha hesitates: the truth he has found runs against the grain of craving and may be too subtle for a world in love with its attachments; but — tradition says at the plea of the god Brahma Sahampati — he resolves out of compassion to teach those “with little dust in their eyes,” and sets out to turn the wheel of the Dharma.',
      svg_row('Compassion answers doubt', [
          {'n': 1, 'label': 'A truth against the current', 'sub': 'subtle, and contrary to craving', 'color': '#78350f'},
          {'n': 2, 'label': 'The plea to teach', 'sub': 'Brahma Sahampati begs him, tradition says', 'color': '#a16207'},
          {'n': 3, 'label': 'Compassion prevails', 'sub': 'he will teach “those with little dust”', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He chose to teach — turning a private awakening into a path open to others.', accent=AC),
      bg='Newly awakened, the Buddha weighed whether his hard-won insight — so much against the current of ordinary desire — could be conveyed to others at all.',
      people='the <b>Buddha</b>; in the tradition, the god <b>Brahma Sahampati</b>, who entreats him to teach; the future disciples “with little dust in their eyes.”',
      what='Tradition records the Buddha’s hesitation that the <b>Dharma</b> was too deep for a craving-bound world, and then his decision — moved by <b>compassion</b> (prompted, the texts say, by <b>Brahma Sahampati</b>) — to teach those able to understand. He set out for Sarnath to find his former companions.',
      crux='The choice was between a <b>silent, solitary liberation</b> and a <b>shared path</b> — and compassion for others’ suffering decided it.',
      conseq='This resolve founded Buddhism as a teaching tradition rather than a single man’s private release.',
      matters='The decision to teach is what made the Buddha a world-figure — the moment an inner awakening became a way offered to all.'),
]

# ==================================================================  PHASE 4 — TURNING THE WHEEL
PHASE_WHEEL = [
    E('sarnath', 'age 35 (trad.)', 'The First Sermon at Sarnath', ['TURNING POINT', 'TRIUMPH'],
      'At the Deer Park in Sarnath, near Varanasi, the Buddha delivers his first sermon to the five ascetics who had left him — the “Setting in Motion of the Wheel of the Dharma” — teaching the Middle Way, the Four Noble Truths and the Noble Eightfold Path; his listener Kondanna grasps it, and the sangha is born.',
      svg_stack('Setting the wheel in motion', [
          {'n': 1, 'label': 'The Deer Park, Sarnath', 'sub': 'he rejoins the five ascetics', 'color': '#b45309'},
          {'n': 2, 'label': 'The Four Noble Truths', 'sub': 'suffering, its cause, its end, the path', 'color': '#a16207'},
          {'n': 3, 'label': 'The Noble Eightfold Path', 'sub': 'the Middle Way to the end of suffering', 'color': '#2563eb'},
          {'n': 4, 'label': 'Kondanna understands', 'sub': 'the first to “see” — the sangha begins', 'color': '#166534'},
      ], takeaway='In one sermon the Buddha laid out the whole diagnosis and cure of suffering — and gained his first follower.', accent=AC),
      bg='After his awakening the Buddha travelled to the <b>Deer Park at Sarnath</b>, near Varanasi, to teach the <b>five ascetics</b> who had shared his years of fasting.',
      people='the <b>Buddha</b>; the <b>five ascetics</b> — Kondanna, Vappa, Bhaddiya, Mahanama and Assaji; <b>Kondanna</b>, the first to understand.',
      what='In the <b>Dhammacakkappavattana</b> (“Setting the Wheel of Dharma in Motion”), the Buddha taught the <b>Middle Way</b>, the <b>Four Noble Truths</b> — that life involves <b>suffering (dukkha)</b>, that suffering arises from <b>craving</b>, that it can <b>cease</b>, and that the <b>Noble Eightfold Path</b> leads to that cessation.',
      crux='He framed liberation as a <b>diagnosis and cure</b>: name the disease (suffering), its cause (craving), its cure (cessation), and the treatment (the path).',
      conseq='Kondanna and then the others attained insight and were ordained — the first monks, and the beginning of the Buddhist community.',
      matters='The First Sermon is the foundational teaching of Buddhism, still recited today — the framework within which all later doctrine unfolds.'),

    E('dharma', 'the teaching', 'The Dharma — Dependent Origination and the marks of existence', ['REFORM'],
      'Beyond the first sermon, the Buddha unfolds a distinctive analysis of reality: Dependent Origination, that all things arise in dependence on causes and conditions; and the three marks — impermanence, suffering and non-self — from which follows the possibility of nirvana, the extinction of the craving that binds beings to rebirth.',
      svg_row('How suffering arises — and ends', [
          {'n': 1, 'label': 'Dependent Origination', 'sub': 'all arises through causes and conditions', 'color': '#b45309'},
          {'n': 2, 'label': 'The three marks', 'sub': 'impermanence, suffering, non-self', 'color': '#a16207'},
          {'n': 3, 'label': 'Craving cut, suffering ends', 'sub': 'nirvana — release from the round of rebirth', 'color': '#166534'},
      ], edge_labels=['imply', 'so'], takeaway='If everything is conditioned and impermanent, then cutting craving at its root ends the whole chain of suffering.', accent=AC),
      bg='The Buddha’s teaching answered the central question of the renunciants of his age: the cause of <b>suffering and rebirth</b>, and the way to release from it.',
      people='the <b>Buddha</b> as teacher; the growing <b>sangha</b> of monks who memorised and transmitted the teaching; later hearers across the Ganges plain.',
      what='The Buddha taught <b>Dependent Origination (paticca-samuppada)</b> — that phenomena arise in dependence on prior causes, so that ending the causes ends the result — and the <b>three marks of existence</b>: <b>impermanence (anicca)</b>, <b>suffering (dukkha)</b> and <b>non-self (anatta)</b>. Uprooting <b>craving and ignorance</b> brings <b>nirvana</b>.',
      crux='His core move was <b>causal</b>: because suffering arises through a chain of conditions rooted in craving, cutting that root ends suffering itself.',
      conseq='This framework — cause, impermanence, non-self, cessation — became the doctrinal core carried by the sangha across Asia over the centuries.',
      matters='Dependent Origination and the three marks are among the most influential ideas in the history of thought, shaping ethics, psychology and philosophy far beyond Buddhism.'),

    E('sangha', 'age 35 onward', 'Founding the sangha — the community of the path', ['RISE', 'REFORM'],
      'From the first five monks the community swells: the merchant’s son Yasa and his friends join, then hundreds more, and the Buddha sends his earliest disciples out to teach “for the welfare of the many”; the sangha of monks and lay followers — resting on the Three Jewels of Buddha, Dharma and Sangha — becomes the vehicle that carries the teaching forward.',
      svg_stack('From five monks to a movement', [
          {'n': 1, 'label': 'The first monks ordained', 'sub': 'the five ascetics, then Yasa and friends', 'color': '#b45309'},
          {'n': 2, 'label': 'Sent out to teach', 'sub': '“for the welfare and happiness of the many”', 'color': '#a16207'},
          {'n': 3, 'label': 'The Three Jewels', 'sub': 'refuge in Buddha, Dharma and Sangha', 'color': '#166534'},
      ], takeaway='He built not just a doctrine but a community to carry it — the institution that would outlast him by millennia.', accent=AC),
      bg='Having gained his first disciples at Sarnath, the Buddha set about forming an <b>ordered community</b> to preserve and spread the teaching.',
      people='the <b>Buddha</b>; the first five monks; <b>Yasa</b>, a wealthy young convert, and his companions; the earliest lay supporters.',
      what='The community grew from the first five to some sixty monks, whom the Buddha dispersed to <b>teach the Dharma widely</b>. He established the <b>sangha</b> of monks (and later nuns) and lay followers, ordered by a code of discipline (the <b>Vinaya</b>) and grounded in the <b>Three Jewels</b> — Buddha, Dharma, Sangha.',
      crux='He institutionalised the teaching in a <b>self-perpetuating community</b> — turning a personal insight into a durable, transmissible tradition.',
      conseq='The sangha became one of the oldest continuous institutions in human history, the carrier of Buddhism across Asia and the world.',
      matters='A teaching lasts only if it is embodied in a community — the Buddha’s sangha is why his awakening still reaches billions today.'),
]

# ==================================================================  PHASE 5 — THE MINISTRY AND THE PARINIRVANA
PHASE_MINISTRY = [
    E('ministry', 'age 35–80 (trad.)', 'Forty-five years across the Ganges plain', ['RISE'],
      'For some forty-five years the Buddha walks the towns and kingdoms of the middle Ganges — Rajagriha, Sravasti, Vaishali, Kosala and Magadha — teaching all who come, from kings to outcastes; patrons like King Bimbisara and the merchant Anathapindika endow monastic groves, and disciples such as Sariputta, Moggallana and his cousin Ananda gather around him.',
      svg_stack('A teaching life on the road', [
          {'n': 1, 'label': 'Wandering the Ganges kingdoms', 'sub': 'Rajagriha, Sravasti, Vaishali, and beyond', 'color': '#b45309'},
          {'n': 2, 'label': 'Kings and merchants as patrons', 'sub': 'Bimbisara; Anathapindika’s Jetavana grove', 'color': '#a16207'},
          {'n': 3, 'label': 'Great disciples gather', 'sub': 'Sariputta, Moggallana, Ananda', 'color': '#166534'},
      ], takeaway='Decade after decade he taught across northern India, building the network of people and places that carried the Dharma.', accent=AC),
      bg='After founding the sangha, the Buddha spent the rest of his long life as a <b>wandering teacher</b> across the kingdoms and republics of the <b>middle Ganges plain</b>.',
      people='the <b>Buddha</b>; royal patrons <b>King Bimbisara</b> of Magadha and <b>King Prasenajit</b> of Kosala; the merchant <b>Anathapindika</b>; disciples <b>Sariputta</b>, <b>Moggallana</b> and <b>Ananda</b>.',
      what='For roughly <b>40–45 years</b> the Buddha travelled and taught — spending rain-retreats at groves such as <b>Veluvana</b> (given by Bimbisara at Rajagriha) and <b>Jetavana</b> (given by Anathapindika at Sravasti) — reaching people of <b>every caste and station</b>, from monarchs to labourers.',
      crux='He carried the teaching <b>directly to the people</b>, adapting it to each hearer, and gathered lasting patrons and gifted disciples to sustain it.',
      conseq='By the end of his life the Dharma was established across several kingdoms, with a large ordained community and networks of lay support.',
      matters='The long ministry turned a single awakening into a broad movement — the human and institutional foundation on which Buddhism spread across Asia.'),

    E('order', 'the ministry', 'The order widens — nuns, kin and kings', ['REFORM'],
      'The community reaches beyond wandering monks: at the request of his aunt and foster-mother Mahapajapati, and with Ananda’s intercession, the Buddha establishes an order of nuns; and returning to Kapilavastu he draws in his own family — his son Rahula and many Shakyas ordained — widening the path to women and householders alike.',
      svg_row('A path opened wider', [
          {'n': 1, 'label': 'The order of nuns', 'sub': 'Mahapajapati; Ananda intercedes', 'color': '#b45309'},
          {'n': 2, 'label': 'His own family drawn in', 'sub': 'return to Kapilavastu; Rahula ordained', 'color': '#a16207'},
          {'n': 3, 'label': 'Monks, nuns and laity', 'sub': 'a fourfold community of followers', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He extended the path beyond the wandering monk — to women, to householders, and to his own kin.', accent=AC),
      bg='As the sangha grew, questions arose over who could take up the path — including the women of his own family and the household he had left behind.',
      people='the <b>Buddha</b>; his foster-mother <b>Mahapajapati Gotami</b>, who sought ordination; his attendant and cousin <b>Ananda</b>; his son <b>Rahula</b> and father <b>Suddhodana</b>.',
      what='Tradition holds that the Buddha, after initial reluctance and at <b>Ananda’s urging</b>, admitted women to the sangha, ordaining <b>Mahapajapati</b> as the first nun. Returning to <b>Kapilavastu</b>, he taught his kin; his son <b>Rahula</b> and many Shakyas joined the order.',
      crux='He widened the community into a <b>fourfold assembly</b> — monks, nuns, laymen and laywomen — extending the possibility of the path across society.',
      conseq='The order of nuns (bhikkhunis) became a lasting, if contested, part of the tradition, and the Buddha’s own family entered the sangha he had founded.',
      matters='The widening of the order shows the path offered, in principle, to all — a point of enduring significance in the tradition’s history and debates.'),

    E('parinirvana', 'age 80 (trad.)', 'The Parinirvana at Kushinagar', ['DEATH'],
      'Grown old, the Buddha falls ill after a final meal offered by Cunda the smith and, lying between two sal trees at Kushinagar, gives his last teachings, urges the sangha to “be a lamp unto yourselves,” and passes into parinirvana — final release from the round of rebirth — his last words, tradition holds, “all conditioned things are impermanent; strive on with diligence.”',
      svg_stack('The final release', [
          {'n': 1, 'label': 'A last meal, a last illness', 'sub': 'offered by Cunda the smith; he sickens', 'color': '#78350f'},
          {'n': 2, 'label': 'Between the sal trees', 'sub': 'at Kushinagar, he lies down to die', 'color': '#b45309'},
          {'n': 3, 'label': 'Final counsel to the sangha', 'sub': '“be a lamp unto yourselves”; strive with diligence', 'color': '#a16207'},
          {'n': 4, 'label': 'Parinirvana', 'sub': 'final release from rebirth, at 80', 'color': '#111827'},
      ], takeaway='He died as he taught — pointing his followers not to himself but to the Dharma and their own effort.', accent=AC),
      bg='After decades of teaching, the aged Buddha journeyed north through the kingdoms toward <b>Kushinagar</b>, in the land of the Mallas.',
      people='the <b>Buddha</b>, aged about 80; <b>Cunda</b> the smith, who gives the last meal; his attendant <b>Ananda</b>; the assembled monks.',
      what='The Buddha grew ill after a meal offered by <b>Cunda</b> and, lying <b>between two sal trees at Kushinagar</b>, gave final instructions — telling the monks to <b>rely on the Dharma and on themselves</b>, and, tradition records, uttering as his last words that <b>all conditioned things are impermanent</b> and they should <b>strive on with diligence</b>. He then entered <b>parinirvana</b>.',
      crux='In dying he pointed away from his own person to the <b>teaching and each seeker’s own effort</b> — the sangha was to carry on without a living founder.',
      conseq='His remains were cremated and the relics divided among claimants and enshrined in stupas; the sangha preserved and spread his teaching across Asia in the centuries after.',
      matters='The Parinirvana closes the life and opens the tradition — a death framed not as loss but as final release, and a charge to the community to keep the path alive.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Gautama Buddha — Siddhartha Gautama — was a prince of the Shakya clan who, according to the Buddhist tradition, renounced a throne to seek an end to human suffering, awakened under the Bodhi tree at Bodh Gaya, and spent some forty-five years teaching across the Ganges plain. From his insight grew one of the world’s great religious and philosophical traditions, built on the <b>Four Noble Truths, the Noble Eightfold Path, and the Middle Way</b>. This guide presents the tradition’s own account of his life alongside what historians can and cannot establish, noting evenly where the two differ.</p>
<div class="ov-quote">“All conditioned things are impermanent — strive on with diligence.”<span>— last words attributed to the Buddha in the tradition</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A sheltered Shakya prince is shielded from all suffering → the Four Sights reveal age, sickness and death → at 29 he renounces palace, wife and son → he masters meditation and drives asceticism to near-death → rejecting both extremes for the Middle Way, he awakens under the Bodhi tree at Bodh Gaya → he turns the wheel of the Dharma at Sarnath and founds the sangha → he teaches for forty-five years across northern India → and passes into parinirvana at Kushinagar at 80.</p>
<div class="ov-lbl">A note on tradition and history</div>
<p class="ov-lead" style="font-size:15px">No written records survive from the Buddha’s lifetime, and even his dates are debated — the traditional <b>c. 563–483 BC</b> sits beside scholarly proposals centring his death nearer <b>c. 400 BC</b>. Much of the familiar life-story (the Four Sights, Mara’s assault, the miracles of later texts) comes from devotional biographies composed centuries afterward. This guide relays that account faithfully <b>as the tradition’s own</b>, marks legendary elements as such, and does not adjudicate any religious claim.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">☸️</div><h4>The Four Noble Truths</h4><p>A diagnosis of suffering, its cause, its end, and the path.</p></div>
  <div class="ov-card"><div class="i">🌿</div><h4>The Middle Way</h4><p>Liberation through balance, between indulgence and self-denial.</p></div>
  <div class="ov-card"><div class="i">🔗</div><h4>Dependent Origination</h4><p>All things arise through causes — cut the cause, end the result.</p></div>
  <div class="ov-card"><div class="i">🪷</div><h4>A world tradition</h4><p>A sangha that carried the Dharma across Asia and the world.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Sheltered Prince</b><small> birth–age 29</small><p>Lumbini, the gilded palace, Yasodhara and Rahula.</p></div>
  <div><b>2 · The Great Renunciation</b><small> age 29–35</small><p>The Four Sights, leaving, and years of asceticism.</p></div>
  <div><b>3 · The Awakening</b><small> age 35</small><p>The Middle Way, the Bodhi tree, the choice to teach.</p></div>
  <div><b>4 · Turning the Wheel</b><small> age 35 on</small><p>Sarnath, the Dharma, and the founding of the sangha.</p></div>
  <div><b>5 · Ministry & Parinirvana</b><small> age 35–80</small><p>Forty-five years of teaching, then release at Kushinagar.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references. Dates marked “trad.” follow the traditional chronology.</p>
"""

WHO = [
    {'name': 'Suddhodana', 'role': 'his father', 'color': '#a16207',
     'bio': 'Chief of the Shakya clan at Kapilavastu, who raised Siddhartha in sheltered luxury hoping to keep him from the ascetic destiny the sage Asita had foretold.',
     'rel': 'The father who tried to bind him to the throne — and was later drawn into the sangha.'},
    {'name': 'Yasodhara', 'role': 'his wife', 'color': '#b45309',
     'bio': 'The princess Siddhartha married and left behind on the night of the Great Renunciation; in the tradition she later joined the order of nuns.',
     'rel': 'The wife he renounced — one of the ties his quest required him to release.'},
    {'name': 'Rahula', 'role': 'his son', 'color': '#166534',
     'bio': 'Siddhartha’s son, whose name the tradition reads as “fetter”; he was later ordained and became a monk of the sangha his father founded.',
     'rel': 'The son he left as an infant and who became one of his followers.'},
    {'name': 'Kondanna', 'role': 'first disciple', 'color': '#2563eb',
     'bio': 'Eldest of the five ascetics; the first to understand the First Sermon at Sarnath and be ordained, marking the birth of the sangha.',
     'rel': 'The first person to grasp the Dharma — the sangha’s first member.'},
    {'name': 'Ananda', 'role': 'attendant & cousin', 'color': '#3730a3',
     'bio': 'The Buddha’s cousin and devoted personal attendant, famed for his memory of the teachings and for interceding to establish the order of nuns.',
     'rel': 'His closest attendant, present at the Parinirvana and a key transmitter of the teaching.'},
]

KEY_EVENTS = [
    ('c. 563 BC', 'Born at Lumbini', 'A prince of the Shakya clan (traditional date).'),
    ('age 16', 'Marries Yasodhara', 'Later, a son, Rahula, is born.'),
    ('age 29', 'The Four Sights', 'Old man, sick man, corpse, ascetic.'),
    ('age 29', 'The Great Renunciation', 'Leaves the palace to seek an end to suffering.'),
    ('age 29–35', 'Years of asceticism', 'Extreme fasting, then rejected for the Middle Way.'),
    ('age 35', 'Enlightenment at Bodh Gaya', 'Awakens under the Bodhi tree.'),
    ('age 35', 'First Sermon at Sarnath', 'Four Noble Truths and the Eightfold Path.'),
    ('age 35–80', 'Forty-five years teaching', 'Across the Ganges plain; the sangha grows.'),
    ('c. 483 BC', 'Parinirvana at Kushinagar', 'Final release, at about age 80.'),
]

MASTER = [
    {'year': 'c. 563 BC', 'age': 'born', 'phase': 'The Sheltered Prince', 'title': 'Born at Lumbini', 'desc': 'A Shakya prince (traditional date).'},
    {'year': 'age 29', 'age': 'age 29', 'phase': 'The Great Renunciation', 'title': 'The Great Renunciation', 'desc': 'Leaves palace, wife and son.'},
    {'year': 'age 29–35', 'age': 'to age 35', 'phase': 'The Great Renunciation', 'title': 'Years of asceticism', 'desc': 'Fasting to near death.'},
    {'year': 'age 35', 'age': 'age 35', 'phase': 'The Awakening', 'title': 'Enlightenment at Bodh Gaya', 'desc': 'Awakens under the Bodhi tree.'},
    {'year': 'age 35', 'age': 'age 35', 'phase': 'Turning the Wheel', 'title': 'First Sermon at Sarnath', 'desc': 'Sets the wheel of Dharma in motion.'},
    {'year': 'c. 483 BC', 'age': 'age 80', 'phase': 'Ministry & Parinirvana', 'title': 'Parinirvana at Kushinagar', 'desc': 'Final release from rebirth.'},
]

SOURCES = [
    ('Wikipedia — The Buddha', 'https://en.wikipedia.org/wiki/The_Buddha'),
    ('Britannica — Buddha (founder of Buddhism)', 'https://www.britannica.com/biography/Buddha-founder-of-Buddhism'),
    ('World History Encyclopedia — Buddha', 'https://www.worldhistory.org/buddha/'),
    ('Britannica — Four Noble Truths', 'https://www.britannica.com/topic/Four-Noble-Truths'),
    ('Britannica — Eightfold Path', 'https://www.britannica.com/topic/Eightfold-Path'),
]

def build_meta():
    return {
        'pid': 'gm-buddha.html', 'kind': 'man', 'emoji': '☸️', 'accent': AC,
        'name': 'Gautama Buddha', 'years': 'c. 563–483 BC', 'group': 'Religious Founders',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Shakya prince who renounced a throne, awakened under the Bodhi tree at Bodh Gaya, and taught the Middle Way and the Four Noble Truths across the Ganges plain — founder of the Buddhist tradition.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'prince', 'label': '1 · The Sheltered Prince', 'type': 'timeline',
             'intro': 'By tradition, a prince of the Shakyas is born at Lumbini and raised in a palace world engineered to hide all suffering — married to Yasodhara, with a son, Rahula, to bind him to the throne.', 'events': PHASE_PRINCE},
            {'id': 'renounce', 'label': '2 · The Great Renunciation', 'type': 'timeline',
             'intro': 'The Four Sights break through his shelter with the truth of age, sickness and death; at 29 he renounces everything, and drives meditation and asceticism to their limits without finding release.', 'events': PHASE_RENOUNCE},
            {'id': 'awaken', 'label': '3 · The Awakening', 'type': 'timeline',
             'intro': 'Rejecting both indulgence and self-torment for the Middle Way, he awakens under the Bodhi tree at Bodh Gaya, grasping the origin and end of suffering — then resolves, out of compassion, to teach.', 'events': PHASE_AWAKEN},
            {'id': 'wheel', 'label': '4 · Turning the Wheel', 'type': 'timeline',
             'intro': 'At Sarnath he sets the wheel of the Dharma in motion — the Four Noble Truths and the Eightfold Path — unfolds Dependent Origination and the marks of existence, and founds the sangha.', 'events': PHASE_WHEEL},
            {'id': 'ministry', 'label': '5 · Ministry & Parinirvana', 'type': 'timeline',
             'intro': 'For forty-five years he teaches across the kingdoms of the Ganges plain, widening the community to nuns, kin and kings, before passing into parinirvana between the sal trees at Kushinagar.', 'events': PHASE_MINISTRY,
             'sources': SOURCES, 'srcnote': 'The life follows the Buddhist tradition’s own account as preserved in the early texts and later biographies; legendary elements (the Four Sights, Mara, later miracles) are presented as the tradition’s account, not as established history. Dates and even the century are debated: the traditional c. 563–483 BC sits beside scholarly datings that place the death nearer c. 400 BC.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
