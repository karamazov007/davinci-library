# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Henry Kissinger.
The German-Jewish refugee who became America’s grand strategist — and its most contested statesman."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#0e7490'  # Cold War steel-cyan

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING
PHASE_MAKING = [
    E('refugee', '1923–1938', 'A Jewish boy flees Nazi Germany', ['RISE', 'TRAGEDY'],
      'Born Heinz Alfred Kissinger in Fürth, Bavaria, in 1923, he grows up as the Nazi persecution of Jews closes in — barred from schools, beaten in the streets — until his family flees in 1938 for London and then New York, an uprooting that plants in him a lifelong conviction that order is fragile and chaos always near.',
      svg_row('Persecution makes a refugee', [
          {'n': 1, 'label': 'Born in Fürth, 1923', 'sub': 'a Jewish family in Bavaria', 'color': '#0e7490'},
          {'n': 2, 'label': 'Nazi persecution closes in', 'sub': 'barred from school, beaten by Hitler Youth', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Flees to America, 1938', 'sub': 'via London to New York', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='Watching a civilised nation collapse into savagery taught him that stability is precious and fragile — the lesson beneath all his statecraft.', accent=AC),
      bg='<b>Heinz Alfred Kissinger</b> was born in 1923 into a Jewish family in Fürth, Bavaria. As the Nazis rose, Jews were stripped of their rights and safety.',
      people='his father <b>Louis</b>, a teacher forced from his post; his mother <b>Paula</b>, who drove the escape; the Nazi regime they fled.',
      what='Under escalating persecution — barred from schools and assaulted by Hitler Youth gangs — the <b>Kissinger family fled Germany in 1938</b>, reaching New York; some dozen relatives who stayed behind were later murdered in the Holocaust.',
      crux='He learned in his bones that <b>civilisation is a thin crust over chaos</b> — that order, once broken, gives way to horror.',
      conseq='The refugee became an American, carrying a lifelong dread of instability into his life’s work.',
      matters='Formative catastrophe shapes conviction — the boy who watched a nation descend into barbarism spent his life prizing order above almost all.'),

    E('soldier', '1943–1947', 'An American soldier returns to Germany', ['RISE', 'WAR'],
      'Drafted into the US Army, the refugee becomes an American citizen and returns to the country that expelled him — serving in counter-intelligence, hunting Gestapo officers and administering an occupied town — an experience that turns a bookish immigrant into a confident man of affairs who has seen power and evil up close.',
      svg_stack('From refugee to American of affairs', [
          {'n': 1, 'label': 'Drafted; citizen, 1943', 'sub': 'the immigrant becomes American in uniform', 'color': '#0e7490'},
          {'n': 2, 'label': 'Counter-intelligence in Germany', 'sub': 'hunts Gestapo officers, administers occupied towns', 'color': '#a16207'},
          {'n': 3, 'label': 'Sees power and evil up close', 'sub': 'witnesses the aftermath of the camps', 'color': '#78350f'},
      ], takeaway='Returning to occupy the land that had cast him out, he learned how power is wielded and how a shattered order is rebuilt from ruin.', accent=AC),
      bg='Drafted in 1943, Kissinger became a US citizen and was sent back to the Germany he had fled as a boy.',
      people='<b>Fritz Kraemer</b>, the mentor who spotted his talent; the German civilians he administered; the defeated Reich he helped occupy.',
      what='Serving in <b>Army counter-intelligence</b>, Kissinger helped administer occupied German towns and tracked down Gestapo officers, and saw the aftermath of the concentration camps — turning a shy émigré into a self-assured man of affairs.',
      crux='He saw first-hand how <b>authority is exercised</b> and how a devastated order is painstakingly rebuilt.',
      conseq='The Army’s GI Bill then sent him to Harvard, launching an academic career.',
      matters='Experience of power at ground level shapes a statesman — Kissinger learned governance amid the ruins of the regime that had expelled him.'),

    E('harvard', '1950–1968', 'The Harvard realist and “A World Restored”', ['RISE', 'IDEAS'],
      'At Harvard, Kissinger becomes a star scholar of realpolitik — his doctoral thesis “A World Restored” celebrates the balance-of-power statecraft of Metternich and Castlereagh that gave Europe peace after Napoleon — and he builds a reputation as a hard-headed thinker on nuclear strategy, cultivating the powerful along the way.',
      svg_row('The scholar of realpolitik', [
          {'n': 1, 'label': 'Harvard PhD, 1954', 'sub': 'star student, then professor', 'color': '#0e7490'},
          {'n': 2, 'label': '“A World Restored”, 1957', 'sub': 'Metternich, Castlereagh, the balance of power', 'color': '#3730a3'},
          {'n': 3, 'label': 'Nuclear strategist', 'sub': '“Nuclear Weapons and Foreign Policy”, 1957', 'color': '#a16207'},
      ], edge_labels=['yields', 'and'], takeaway='He built a philosophy of statecraft — order, balance and national interest over ideology — that he would one day get to practise.', accent=AC),
      bg='On the GI Bill, Kissinger excelled at Harvard, earning his doctorate and joining the faculty as a scholar of diplomacy.',
      people='the 19th-century statesmen <b>Metternich</b> and <b>Castlereagh</b> he studied; <b>Nelson Rockefeller</b>, whom he advised; Harvard’s foreign-policy establishment.',
      what='His thesis, <b>“A World Restored” (1957)</b>, praised the post-Napoleonic order built by Metternich and Castlereagh; he also became a noted analyst of <b>nuclear strategy</b> and an adviser to Nelson Rockefeller.',
      crux='He embraced <b>realpolitik</b> — that peace rests on a stable balance of power and clear-eyed national interest, not on ideals or moral crusades.',
      conseq='This reputation brought him to the attention of Richard Nixon, who made him National Security Advisor.',
      matters='Ideas precede action — the scholar who theorised the balance of power would soon try to rebuild one for the nuclear age.'),
]

# ==================================================================  PHASE 2 — TO POWER
PHASE_POWER = [
    E('nsa', '1969', 'Into the White House — National Security Advisor', ['POLITICS', 'TURNING POINT'],
      'Richard Nixon names Kissinger National Security Advisor, and the professor swiftly makes himself the indispensable man — centralizing foreign policy in the White House through secret back channels, sidelining the State Department, and forging with Nixon a partnership that will remake America’s place in the Cold War world.',
      svg_stack('Concentrating foreign policy in his hands', [
          {'n': 1, 'label': 'Nixon’s NSA, 1969', 'sub': 'the academic enters power', 'color': '#0e7490'},
          {'n': 2, 'label': 'Back channels and secrecy', 'sub': 'bypasses the State Department', 'color': '#3730a3'},
          {'n': 3, 'label': 'The indispensable man', 'sub': 'runs policy from the White House', 'color': '#166534'},
      ], takeaway='He turned a staff job into the command post of American foreign policy — secrecy and access his instruments of power.', accent=AC),
      bg='In 1969 President Nixon appointed Kissinger <b>National Security Advisor</b>, an obscure staff role he would transform.',
      people='President <b>Richard Nixon</b>, his partner and patron; Secretary of State <b>William Rogers</b>, whom he outmanoeuvred; the NSC staff he built.',
      what='Kissinger <b>centralised foreign policy in the White House</b>, running secret back-channel negotiations with foreign powers and marginalising the State Department, making himself Nixon’s indispensable partner.',
      crux='He believed bold diplomacy required <b>secrecy and central control</b>, freed from bureaucratic and public constraint.',
      conseq='This concentrated power let him pursue the dramatic openings to China and the Soviet Union.',
      matters='Institutions can be bent to a single will — Kissinger showed how a determined operator can seize control of a nation’s foreign policy.'),

    E('china', '1971–1972', 'The opening to China', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'In July 1971 Kissinger slips secretly into Beijing — feigning illness on a trip to Pakistan to vanish for a clandestine meeting with Zhou Enlai — and sets the stage for Nixon’s epochal 1972 visit, ending two decades of Sino-American estrangement and transforming the Cold War by playing China against the Soviet Union.',
      svg_row('Splitting the communist world', [
          {'n': 1, 'label': 'Secret trip, July 1971', 'sub': 'feigns illness in Pakistan, flies to Beijing', 'color': '#0e7490'},
          {'n': 2, 'label': 'Meets Zhou Enlai', 'sub': 'prepares the ground in secret', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Nixon in China, Feb 1972', 'sub': 'ends two decades of estrangement', 'color': '#166534'},
      ], edge_labels=['then', 'yields'], takeaway='By opening to China he split the communist world and gave America the upper hand in the Cold War triangle — his greatest single stroke.', accent=AC),
      bg='Since 1949 the US and Communist China had no relations. Kissinger saw an opening to exploit the growing <b>Sino-Soviet split</b>.',
      people='Chinese premier <b>Zhou Enlai</b>, his negotiating partner; Chairman <b>Mao Zedong</b>; President Nixon, who made the historic visit.',
      what='Using a <b>secret trip via Pakistan in July 1971</b>, Kissinger met Zhou Enlai and arranged <b>Nixon’s landmark February 1972 visit</b> to China, beginning the normalisation of relations.',
      crux='He grasped that engaging China would <b>pressure Moscow</b> and give Washington leverage over both — triangular diplomacy.',
      conseq='The opening reshaped the Cold War balance and remains a foundation of the modern world order.',
      matters='A single diplomatic stroke can shift the global balance — Kissinger’s China opening is a textbook of grand strategy.'),

    E('detente', '1972', 'Détente and SALT with the Soviets', ['POLITICS', 'REFORM'],
      'With China in play, Kissinger drives détente with the Soviet Union — negotiating the SALT I arms-control agreement and the ABM Treaty at the 1972 Moscow summit — seeking to manage the superpower rivalry, slow the nuclear arms race, and entangle Moscow in a web of incentives to keep the peace.',
      svg_stack('Managing the superpower rivalry', [
          {'n': 1, 'label': 'Détente with Moscow', 'sub': 'relax tensions, engage the USSR', 'color': '#0e7490'},
          {'n': 2, 'label': 'SALT I & ABM Treaty, 1972', 'sub': 'first limits on strategic arms', 'color': '#3730a3'},
          {'n': 3, 'label': 'Peace through “linkage”', 'sub': 'bind Moscow with shared interests', 'color': '#166534'},
      ], takeaway='He tried to tame the arms race and the Cold War by negotiation — a structure of restraint between the superpowers.', accent=AC),
      bg='The US and USSR faced an escalating and ruinous nuclear arms race. Kissinger pursued <b>détente</b> to stabilise the rivalry.',
      people='Soviet leader <b>Leonid Brezhnev</b>; Ambassador <b>Anatoly Dobrynin</b>, his back-channel partner; President Nixon.',
      what='At the <b>1972 Moscow summit</b>, Kissinger negotiated the <b>SALT I agreement and the ABM Treaty</b>, the first curbs on the superpowers’ nuclear arsenals, as part of a broader policy of détente and “linkage.”',
      crux='He sought to <b>manage rather than win</b> the Cold War — restraining the arms race and binding Moscow into shared interests.',
      conseq='Détente eased tensions for a time, though critics on both left and right would later attack it as weakness.',
      matters='Rivals can bargain even under the threat of annihilation — Kissinger built the machinery of arms control that outlived him.'),
]

# ==================================================================  PHASE 3 — THE GRAND STRATEGIST
PHASE_STRATEGIST = [
    E('paris', '1973', 'The Paris Peace Accords', ['POLITICS', 'WAR', 'TURNING POINT'],
      'After years of secret talks with Hanoi’s Le Duc Tho — and a brutal Christmas bombing campaign to force terms — Kissinger signs the Paris Peace Accords in January 1973, ending direct American involvement in the Vietnam War and bringing US troops and prisoners home, though the peace it promised would not hold.',
      svg_stack('Ending America’s war in Vietnam', [
          {'n': 1, 'label': 'Secret talks with Le Duc Tho', 'sub': 'years of negotiation with Hanoi', 'color': '#0e7490'},
          {'n': 2, 'label': 'The Christmas bombing, 1972', 'sub': 'coercive force applied to win terms', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Paris Accords, Jan 1973', 'sub': 'US troops withdraw, POWs return', 'color': '#166534'},
      ], takeaway='He negotiated America’s exit from Vietnam — a peace that ended US involvement but not the war itself.', accent=AC),
      bg='The <b>Vietnam War</b> had become a national trauma. Kissinger conducted secret negotiations with North Vietnam’s <b>Le Duc Tho</b> to end US involvement.',
      people='North Vietnamese negotiator <b>Le Duc Tho</b>; President Nixon; the South Vietnamese government, left exposed.',
      what='After protracted talks, punctuated by the intense <b>“Christmas bombing” of December 1972</b>, Kissinger and Le Duc Tho concluded the <b>Paris Peace Accords in January 1973</b>, ending direct US military involvement and returning American prisoners.',
      crux='He used a mix of <b>diplomacy and coercive force</b> to extract terms that let America withdraw “with honour.”',
      conseq='The accords let the US leave, but the war continued and South Vietnam fell to the North in 1975.',
      matters='Ending a war is as hard as winning one — Kissinger got America out of Vietnam, but could not secure the peace.'),

    E('nobel', '1973', 'A contested Nobel Peace Prize', ['POLITICS', 'TRIUMPH'],
      'For the Paris Accords, Kissinger is awarded the 1973 Nobel Peace Prize jointly with Le Duc Tho — but the North Vietnamese negotiator declines it, saying no real peace exists, two Nobel Committee members resign in protest, and the prize becomes a lasting emblem of the gulf between Kissinger’s admirers and his critics.',
      svg_compare('The most controversial Nobel',
          {'head': 'The case for the prize', 'color': '#166534',
           'items': ['ended direct US involvement in Vietnam', 'brought American troops and POWs home', 'a negotiated settlement after years of war']},
          {'head': 'The case against', 'color': '#b91c1c',
           'items': ['Le Duc Tho refused it — no real “peace” existed', 'the war raged on; Saigon fell in 1975', 'two Nobel Committee members resigned in protest']},
          verdict='Awarded for a peace that never held, it became the most disputed prize in the award’s history.',
          takeaway='The prize crystallised the Kissinger paradox — celebrated peacemaker to some, cynical warmaker to others.', accent=AC),
      bg='The <b>1973 Nobel Peace Prize</b> was awarded jointly to Kissinger and Le Duc Tho for the Paris Accords.',
      people='co-laureate <b>Le Duc Tho</b>, who declined the award; the Norwegian Nobel Committee; Kissinger’s many critics.',
      what='Kissinger accepted the prize, but <b>Le Duc Tho refused his share</b>, saying peace had not truly been established; two committee members resigned, and the award drew widespread derision.',
      crux='The honour laid bare the central question about Kissinger — whether he was a <b>maker of peace or of war</b>.',
      conseq='The prize remains one of the most controversial ever given, forever tied to the collapse of the very peace it honoured.',
      matters='History’s verdict is contested in real time — the same act won Kissinger the world’s highest peace honour and its sharpest scorn.'),

    E('shuttle', '1973–1974', 'Yom Kippur War and shuttle diplomacy', ['POLITICS', 'WAR', 'TRIUMPH'],
      'Now Secretary of State, Kissinger responds to the 1973 Yom Kippur War with “shuttle diplomacy” — flying tirelessly between Middle Eastern capitals to broker disengagement agreements between Israel and its Arab foes — easing Egypt out of the Soviet orbit and establishing the United States as the indispensable broker in the region.',
      svg_row('Brokering peace between the lines', [
          {'n': 1, 'label': 'Yom Kippur War, Oct 1973', 'sub': 'Arab armies attack Israel', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Shuttle diplomacy', 'sub': 'flies between Cairo, Damascus, Jerusalem', 'color': '#0e7490'},
          {'n': 3, 'label': 'Disengagement accords', 'sub': 'US becomes the region’s broker', 'color': '#166534'},
      ], edge_labels=['met by', 'yields'], takeaway='His restless shuttle diplomacy made America the indispensable Middle East broker — and pulled Egypt away from Moscow.', accent=AC),
      bg='In October 1973, Egypt and Syria attacked Israel, igniting the <b>Yom Kippur War</b> and a superpower crisis. Kissinger, now Secretary of State, took charge.',
      people='Egyptian president <b>Anwar Sadat</b>; Israeli leaders <b>Golda Meir</b> and <b>Yitzhak Rabin</b>; Syrian president <b>Hafez al-Assad</b>.',
      what='Kissinger flew repeatedly between Middle Eastern capitals — <b>“shuttle diplomacy”</b> — to negotiate disengagement agreements between Israel, Egypt and Syria after the war.',
      crux='He seized the crisis to <b>reshape the region</b> — sidelining the USSR and making Washington the essential mediator.',
      conseq='His diplomacy set the stage for Egypt’s later peace with Israel and decades of US primacy in the Middle East.',
      matters='Personal diplomacy can turn a war into an opening — Kissinger’s shuttle recast the strategic map of the Middle East.'),
]

# ==================================================================  PHASE 4 — THE SHADOW SIDE
PHASE_SHADOW = [
    E('cambodia', '1969–1973', 'The secret war in Cambodia and Laos', ['POLITICS', 'WAR', 'TRAGEDY'],
      'To pressure North Vietnam, Kissinger helps direct a massive secret bombing campaign and ground incursion into neutral Cambodia and Laos — dropping vast tonnages of bombs, hidden from Congress and the public — a campaign critics call a war crime that destabilised Cambodia and helped open the way to the genocidal Khmer Rouge.',
      svg_stack('A hidden war on neutral ground', [
          {'n': 1, 'label': 'Secret bombing, from 1969', 'sub': 'Operation Menu, concealed from Congress', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Incursions, 1970', 'sub': 'the ground war spills into Cambodia and Laos', 'color': '#78350f'},
          {'n': 3, 'label': 'A nation destabilised', 'sub': 'critics link it to the Khmer Rouge’s rise', 'color': '#3730a3'},
      ], takeaway='Critics call the secret bombing a war crime; defenders call it grim military necessity — the darkest charge against him.', accent=AC),
      bg='North Vietnamese forces used sanctuaries in neutral <b>Cambodia and Laos</b>. Kissinger backed secret military action against them.',
      people='President <b>Nixon</b>, who ordered the campaign; the Cambodian and Laotian civilians under the bombs; the <b>Khmer Rouge</b> that followed.',
      what='Kissinger helped direct a covert bombing campaign (<b>Operation Menu</b>) and the <b>1970 ground incursions</b> into Cambodia and Laos, dropping vast tonnages of bombs while concealing the operations from Congress and the public.',
      crux='He judged that striking the sanctuaries was <b>militarily necessary</b>; critics say it was an illegal war on neutral nations that killed many thousands of civilians.',
      conseq='The campaign devastated Cambodia and is widely argued to have helped the genocidal Khmer Rouge seize power.',
      matters='Grand strategy carries a human cost — the Cambodia bombing is the central exhibit for those who call Kissinger a war criminal.'),

    E('bangladesh', '1971', 'The tilt toward Pakistan', ['POLITICS', 'TRAGEDY'],
      'During the 1971 Bangladesh war, Kissinger and Nixon “tilt” toward Pakistan — America’s secret conduit to China — backing a regime whose army was carrying out mass atrocities in East Pakistan, overruling the anguished protest of US diplomats on the ground, and sending a naval task force to intimidate India.',
      svg_row('Realpolitik over a slaughter', [
          {'n': 1, 'label': 'Atrocities in East Pakistan', 'sub': 'mass killing during the 1971 war', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The US “tilts” to Pakistan', 'sub': 'protecting the secret China channel', 'color': '#0e7490'},
          {'n': 3, 'label': 'Overrules the Blood Telegram', 'sub': 'US diplomats’ protest is dismissed', 'color': '#78350f'},
      ], edge_labels=['met by', 'despite'], takeaway='He backed a regime committing atrocities to protect the China opening — cold interest set above humanitarian outcry.', accent=AC),
      bg='In 1971 Pakistan’s army launched a brutal crackdown in <b>East Pakistan</b> (now Bangladesh); Pakistan was also Kissinger’s secret channel to China.',
      people='Pakistani leader <b>Yahya Khan</b>; US consul <b>Archer Blood</b>, who protested; India’s <b>Indira Gandhi</b>.',
      what='Kissinger and Nixon <b>backed Pakistan</b> despite its army’s mass atrocities, dismissing the <b>“Blood Telegram”</b> protest of US diplomats and dispatching a carrier group to pressure India during the war.',
      crux='He prioritised the <b>strategic relationship with Pakistan</b> — his conduit to China — over stopping or even condemning the killing.',
      conseq='The tilt is remembered as a moral failure that put geopolitics above a humanitarian catastrophe.',
      matters='Realpolitik can shade into complicity — the Bangladesh tilt shows the cost of subordinating human lives to strategic advantage.'),

    E('chiletimor', '1973–1975', 'Chile and East Timor', ['POLITICS', 'TRAGEDY'],
      'Kissinger’s cold-eyed realism extends to the developing world: the US works to undermine Chile’s elected Marxist president Salvador Allende, whose 1973 overthrow brings the brutal Pinochet dictatorship — and in 1975 Kissinger and President Ford give a green light to Indonesia’s bloody invasion of East Timor.',
      svg_stack('The cost of Cold War realism', [
          {'n': 1, 'label': 'Undermining Allende in Chile', 'sub': '“make the economy scream”', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Pinochet’s coup, Sept 1973', 'sub': 'a brutal dictatorship follows', 'color': '#78350f'},
          {'n': 3, 'label': 'East Timor green light, 1975', 'sub': 'Indonesia’s invasion approved', 'color': '#3730a3'},
      ], takeaway='To block the spread of the left he backed coups and invasions — grand strategy that critics count as complicity in atrocity.', accent=AC),
      bg='Kissinger viewed leftist movements in the developing world as <b>Cold War threats</b> to be countered by almost any means.',
      people='Chile’s elected president <b>Salvador Allende</b>; General <b>Augusto Pinochet</b>; Indonesia’s <b>Suharto</b>.',
      what='The US under Nixon and Kissinger worked to <b>destabilise Allende’s government</b> before his 1973 overthrow and the Pinochet dictatorship, and in 1975 Kissinger and President Ford signalled approval of <b>Indonesia’s invasion of East Timor</b>.',
      crux='He treated leftist and unaligned governments as <b>pieces on the Cold War board</b>, to be moved or removed for strategic advantage.',
      conseq='The resulting dictatorships and invasions cost tens of thousands of lives, deepening his reputation as an amoral operator.',
      matters='Superpower strategy reaches into small nations’ fates — Chile and East Timor are core charges in the case against Kissinger.'),
]

# ==================================================================  PHASE 5 — THE VERDICT
PHASE_VERDICT = [
    E('ford', '1974–1977', 'The Ford years and Helsinki', ['POLITICS', 'REFORM'],
      'After Nixon falls in Watergate, Kissinger stays on as Gerald Ford’s Secretary of State — presiding over the fall of Saigon in 1975, negotiating the Helsinki Accords that bound the Cold War blocs to human-rights principles, and remaining the towering, if increasingly criticised, figure of American diplomacy.',
      svg_row('Diplomacy after Watergate', [
          {'n': 1, 'label': 'Serves President Ford', 'sub': 'stays on after Nixon resigns, 1974', 'color': '#0e7490'},
          {'n': 2, 'label': 'Fall of Saigon, 1975', 'sub': 'South Vietnam collapses', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Helsinki Accords, 1975', 'sub': 'human rights enter the Cold War', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='He steered US diplomacy through Watergate’s wreckage — from the fall of Saigon to the human-rights promises of Helsinki.', accent=AC),
      bg='When Watergate forced Nixon from office in 1974, Kissinger continued as <b>Secretary of State</b> under President <b>Gerald Ford</b>.',
      people='President <b>Gerald Ford</b>; the collapsing South Vietnamese state; the Soviet and European signatories at Helsinki.',
      what='Under Ford, Kissinger presided over the <b>1975 fall of Saigon</b> and negotiated the <b>Helsinki Accords</b>, which recognised European borders while committing the blocs to human-rights principles later used against the Soviets.',
      crux='He sought to <b>preserve détente and stability</b> even as America’s Vietnam venture ended in defeat.',
      conseq='Helsinki’s human-rights clauses became, unexpectedly, a lever that helped erode the Soviet bloc from within.',
      matters='Statecraft plays a long game — Helsinki looked like a concession but seeded forces that outlasted the Cold War.'),

    E('elder', '1977–2023', 'The eternal elder statesman', ['POLITICS', 'LEGACY', 'DEATH'],
      'Out of office, Kissinger reinvents himself as the world’s most famous elder statesman — running the consultancy Kissinger Associates, writing weighty books on diplomacy and China, advising presidents of both parties and CEOs for decades, and remaining a sought-after oracle until his death in 2023 at the age of 100.',
      svg_stack('A half-century as global oracle', [
          {'n': 1, 'label': 'Kissinger Associates', 'sub': 'consultant to governments and firms', 'color': '#0e7490'},
          {'n': 2, 'label': 'Author and adviser', 'sub': 'books on diplomacy, China, world order', 'color': '#3730a3'},
          {'n': 3, 'label': 'Died 2023, aged 100', 'sub': 'courted and condemned to the very end', 'color': '#78350f'},
      ], takeaway='For nearly fifty years he remained the world’s most consulted — and most contested — statesman, working almost to his death at 100.', accent=AC),
      bg='Leaving government in 1977, Kissinger built a second career as a global consultant, author and adviser.',
      people='the presidents and CEOs who sought his counsel; the Chinese leaders he kept visiting; his enduring critics.',
      what='Kissinger founded the consultancy <b>Kissinger Associates</b>, wrote influential books (<b>“Diplomacy,” “On China,” “World Order”</b>), advised leaders of both parties, and remained active — visiting China at 100 — until his <b>death in November 2023</b>.',
      crux='He transformed a controversial record into <b>unmatched authority</b>, becoming the permanent grey eminence of foreign policy.',
      conseq='His death at 100 reopened the fierce debate over whether he was a great strategist or a war criminal.',
      matters='Reputation is a long argument — Kissinger outlasted nearly all his contemporaries and shaped how power itself is discussed.'),

    E('debate', '1923–2023', 'Strategist or war criminal? The debate', ['LEGACY'],
      'No modern statesman divides opinion like Kissinger. To admirers he was a peerless grand strategist who opened China, tamed the arms race and made America safer; to critics he was an amoral operator complicit in the deaths of untold civilians from Cambodia to Chile. The unsettling truth is that both portraits are drawn from the same career.',
      svg_compare('The two Kissingers',
          {'head': 'The brilliant strategist', 'color': '#166534',
           'items': ['opened China and split the communist world', 'détente and the first nuclear arms limits', 'shuttle diplomacy reshaped the Middle East', 'ended direct US involvement in Vietnam']},
          {'head': 'The accused war criminal', 'color': '#b91c1c',
           'items': ['the secret bombing of Cambodia and Laos', 'the 1971 tilt during Bangladesh’s atrocities', 'backing Chile’s coup and the Pinochet regime', 'the green light for the East Timor invasion']},
          verdict='Both portraits are painted from the same career — the enduring puzzle of Henry Kissinger.',
          takeaway='He forces a hard question: can great statecraft be judged apart from its human cost? On Kissinger, the world still cannot agree.', accent=AC),
      bg='More than almost any figure of his age, Kissinger provokes <b>radically opposed verdicts</b> that have never been reconciled.',
      people='the admirers who call him the greatest statesman of his era; the critics who would try him for war crimes; the historians still arguing.',
      what='Kissinger’s defenders credit him with <b>visionary grand strategy</b> — China, détente, the Middle East — while critics hold him responsible for <b>civilian deaths and dictatorships</b> from Cambodia to Chile to East Timor.',
      crux='The same <b>realpolitik</b> that produced his diplomatic masterstrokes also produced his gravest moral charges — the two are inseparable.',
      conseq='No consensus verdict has emerged; his name remains a byword for both strategic genius and moral controversy.',
      matters='Kissinger is the ultimate test of how we judge power — whether brilliant results can ever excuse their human price.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Henry Kissinger was the German-Jewish refugee who became America’s grand strategist — and its most contested statesman. Fleeing Nazi Germany as a boy, he rose through Harvard as a scholar of realpolitik, then, as Nixon’s National Security Advisor and Secretary of State, remade the Cold War: the secret opening to China, détente and arms control with the Soviets, and shuttle diplomacy in the Middle East. Yet the same cold calculation drove the secret bombing of Cambodia, the tilt toward Pakistan amid atrocity, and the backing of coups from Chile to East Timor. He is the ultimate study in <b>realpolitik, the balance of power, and whether brilliant statecraft can be judged apart from its human cost.</b></p>
<div class="ov-quote">“Power is the ultimate aphrodisiac.”<span>— attributed to Henry Kissinger</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A Jewish boy flees Nazi Germany and returns as an American soldier → he becomes Harvard’s scholar of realpolitik → seizes control of foreign policy as Nixon’s National Security Advisor → opens China and builds détente with Moscow → wins a contested Nobel for the Paris Accords and reshapes the Middle East by shuttle diplomacy → but is charged over Cambodia, Bangladesh, Chile and East Timor → and lives on as the world’s eternal elder statesman until his death at 100 in 2023.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🐉</div><h4>The opening to China</h4><p>Split the communist world and reshaped the Cold War balance.</p></div>
  <div class="ov-card"><div class="i">☢️</div><h4>Détente & arms control</h4><p>Sought to manage the superpower rivalry and slow the arms race.</p></div>
  <div class="ov-card"><div class="i">🕊️</div><h4>Shuttle diplomacy</h4><p>Made America the indispensable broker in the Middle East.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>The moral reckoning</h4><p>Cambodia, Bangladesh and Chile fuel the war-crimes charge.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Making</b><small> 1923–1968</small><p>Refugee, soldier, Harvard realist.</p></div>
  <div><b>2 · To Power</b><small> 1969–1972</small><p>The White House, China, and détente.</p></div>
  <div><b>3 · The Grand Strategist</b><small> 1973–1974</small><p>Paris, the Nobel, and shuttle diplomacy.</p></div>
  <div><b>4 · The Shadow Side</b><small> 1969–1975</small><p>Cambodia, Bangladesh, Chile, East Timor.</p></div>
  <div><b>5 · The Verdict</b><small> 1974–2023</small><p>Elder statesman, and the enduring debate.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Richard Nixon', 'role': 'patron and partner', 'color': '#3730a3',
     'bio': 'The president who elevated Kissinger and joined him in the epochal openings to China and the Soviet Union — until Watergate forced him out.',
     'rel': 'The president whose foreign policy he made his own.'},
    {'name': 'Zhou Enlai', 'role': 'negotiating partner', 'color': '#b91c1c',
     'bio': 'The Chinese premier who received Kissinger’s secret 1971 visit and opened the door to Nixon’s historic trip to Beijing.',
     'rel': 'His counterpart in the opening to China.'},
    {'name': 'Le Duc Tho', 'role': 'adversary', 'color': '#166534',
     'bio': 'The North Vietnamese negotiator across the table at the Paris talks, who declined to share the 1973 Nobel Peace Prize.',
     'rel': 'His adversary in the Vietnam negotiations.'},
    {'name': 'Leonid Brezhnev', 'role': 'great-power counterpart', 'color': '#a16207',
     'bio': 'The Soviet leader with whom Kissinger negotiated détente and the SALT arms-control accords at the 1972 Moscow summit.',
     'rel': 'The Soviet leader he engaged through détente.'},
    {'name': 'Gerald Ford', 'role': 'his second president', 'color': '#5b21b6',
     'bio': 'The president under whom Kissinger continued as Secretary of State after Watergate, through the fall of Saigon and Helsinki.',
     'rel': 'The president he served after Nixon’s fall.'},
]

KEY_EVENTS = [
    ('1923', 'Kissinger born', 'In Fürth, Germany; flees the Nazis in 1938.'),
    ('1943', 'US Army & citizen', 'Returns to Germany in counter-intelligence.'),
    ('1957', '“A World Restored”', 'The Harvard scholar of realpolitik.'),
    ('1969', 'National Security Advisor', 'Centralises power under Nixon.'),
    ('1971', 'Secret trip to China', 'Feigns illness, meets Zhou Enlai.'),
    ('1972', 'Nixon in China; SALT', 'Opening to Beijing and détente with Moscow.'),
    ('1973', 'Paris Accords & Nobel', 'Vietnam exit; a contested peace prize.'),
    ('1973', 'Yom Kippur & shuttle', 'Secretary of State; the Middle East broker.'),
    ('1975', 'Saigon falls; East Timor', 'The war ends; a green light in Asia.'),
    ('2023', 'Death at 100', 'The great debate reopens.'),
]

MASTER = [
    {'year': '1923', 'age': 'born', 'phase': 'The Making', 'title': 'Born in Fürth', 'desc': 'Flees Nazi Germany in 1938.'},
    {'year': '1957', 'age': 'age 34', 'phase': 'The Making', 'title': '“A World Restored”', 'desc': 'The Harvard realist.'},
    {'year': '1969', 'age': 'age 46', 'phase': 'To Power', 'title': 'National Security Advisor', 'desc': 'Seizes foreign policy.'},
    {'year': '1971', 'age': 'age 48', 'phase': 'To Power', 'title': 'Opening to China', 'desc': 'The secret Beijing trip.'},
    {'year': '1973', 'age': 'age 50', 'phase': 'Grand Strategist', 'title': 'Paris Accords & Nobel', 'desc': 'Vietnam exit; contested prize.'},
    {'year': '2023', 'age': 'died 100', 'phase': 'The Verdict', 'title': 'Death at 100', 'desc': 'Strategist or war criminal?'},
]

SOURCES = [
    ('Britannica — Henry Kissinger', 'https://www.britannica.com/biography/Henry-Kissinger'),
    ('Office of the Historian — Henry A. Kissinger', 'https://history.state.gov/departmenthistory/people/kissinger-henry-a'),
    ('The Nobel Prize — Henry Kissinger, Facts', 'https://www.nobelprize.org/prizes/peace/1973/kissinger/facts/'),
    ('National Security Archive — Kissinger’s Secret Trip to China', 'https://nsarchive2.gwu.edu/NSAEBB/NSAEBB66/'),
    ('Wikipedia — Henry Kissinger', 'https://en.wikipedia.org/wiki/Henry_Kissinger'),
]

def build_meta():
    return {
        'pid': 'gm-kissinger.html', 'kind': 'man', 'emoji': '🌐', 'accent': AC,
        'name': 'Henry Kissinger', 'years': '1923–2023', 'group': 'Diplomats & Strategists',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The German-Jewish refugee who became America’s grand strategist — architect of the opening to China, détente and shuttle diplomacy, and the most contested statesman of his age, hailed as a genius and accused as a war criminal.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'making', 'label': '1 · The Making', 'type': 'timeline',
             'intro': 'A Jewish boy flees Nazi Germany, returns as an American soldier, and rises at Harvard as a scholar of realpolitik and the balance of power.', 'events': PHASE_MAKING},
            {'id': 'power', 'label': '2 · To Power', 'type': 'timeline',
             'intro': 'As Nixon’s National Security Advisor he seizes control of foreign policy, then stuns the world with the secret opening to China and détente with Moscow.', 'events': PHASE_POWER},
            {'id': 'strategist', 'label': '3 · The Grand Strategist', 'type': 'timeline',
             'intro': 'He signs the Paris Peace Accords, wins a contested Nobel Prize, and — as Secretary of State — reshapes the Middle East through tireless shuttle diplomacy.', 'events': PHASE_STRATEGIST},
            {'id': 'shadow', 'label': '4 · The Shadow Side', 'type': 'timeline',
             'intro': 'The same cold realism drives the secret bombing of Cambodia and Laos, the tilt toward Pakistan amid atrocity, and the backing of coups from Chile to East Timor.', 'events': PHASE_SHADOW},
            {'id': 'verdict', 'label': '5 · The Verdict', 'type': 'timeline',
             'intro': 'He lives on for half a century as the world’s eternal elder statesman, dying at 100 — leaving behind an unresolved debate: brilliant strategist, or accused war criminal?', 'events': PHASE_VERDICT,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic and archival sources; the “strategist vs war criminal” debate is presented even-handedly, as the historical record remains genuinely contested.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
