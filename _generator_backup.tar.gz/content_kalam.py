# -*- coding: utf-8 -*-
"""Full, DEEP guide content for A.P.J. Abdul Kalam.
The boat-owner’s son who built India’s rockets and missiles and rose to become its “People’s President.”"""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#1d4ed8'  # aerospace blue

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — A BOAT-OWNER’S SON
PHASE_ROOTS = [
    E('origins', '1931', 'Born in Rameswaram, son of a boat-owner', ['RISE', 'ORIGINS'],
      'Avul Pakir Jainulabdeen Abdul Kalam is born on 15 October 1931 in the temple town of Rameswaram, on a small island off Tamil Nadu, into a modest Muslim family — his father Jainulabdeen a boat-owner and imam who ferries pilgrims across the strait, giving the boy a childhood of faith, simplicity and hard work.',
      svg_row('A humble island childhood', [
          {'n': 1, 'label': 'Born in Rameswaram, 15 Oct 1931', 'sub': 'a temple island off Tamil Nadu', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Father Jainulabdeen, a boat-owner', 'sub': 'an imam who ferried Hindu pilgrims', 'color': '#0f766e'},
          {'n': 3, 'label': 'Faith, thrift and hard work', 'sub': 'a large family of modest means', 'color': '#b45309'},
      ], edge_labels=['son of', 'raised in'], takeaway='He began at the very bottom — a poor boat-owner’s son on a remote island, worlds away from rockets.', accent=AC),
      bg='<b>Avul Pakir Jainulabdeen Abdul Kalam</b> was born on <b>15 October 1931</b> at Rameswaram, then in the Madras Presidency, into a devout Tamil Muslim household of limited means.',
      people='his father <b>Jainulabdeen</b>, a boat-owner and local mosque imam; his mother <b>Ashiamma</b>; the Hindu and Muslim neighbours of a shared temple town.',
      what='Kalam grew up in a <b>modest, close-knit family</b> in Rameswaram, where his father owned a boat that ferried pilgrims between the island and the mainland, and the household lived simply on hard work and faith.',
      crux='His origins were <b>ordinary and poor</b> — nothing in his birth marked him for science or high office.',
      conseq='The values of thrift, discipline and interfaith harmony he absorbed at home stayed with him for life.',
      matters='India’s greatest scientist-statesman rose from a fisherman’s island — proof that talent can come from anywhere.'),

    E('newspapers', '1930s–1940s', 'Selling newspapers to help the family', ['RISE', 'CHILDHOOD'],
      'As a boy Kalam wakes before dawn to distribute newspapers along Rameswaram’s streets, earning his first money to help his struggling family after the war disrupts the pilgrim trade — a discipline of early rising and honest labour that he would carry into his laboratories decades later.',
      svg_stack('Earning before sunrise', [
          {'n': 1, 'label': 'The war hits the pilgrim trade', 'sub': 'the family income grows tighter', 'color': '#b45309'},
          {'n': 2, 'label': 'A boy delivers newspapers', 'sub': 'up before dawn on Rameswaram’s streets', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'His first honest wages', 'sub': 'discipline and duty learned early', 'color': '#0f766e'},
      ], takeaway='He worked as a newspaper boy to help his family — the habit of pre-dawn effort never left him.', accent=AC),
      bg='During the Second World War, demand for the pilgrim ferry fell, and the young Kalam took up small jobs to <b>supplement the family income</b>.',
      people='his cousin <b>Samsuddin</b>, who ran a newspaper agency and gave him the work; his supportive elder brother and parents.',
      what='As a schoolboy Kalam <b>distributed newspapers</b> in Rameswaram each morning before class, earning his first wages and learning the value of <b>discipline and self-reliance</b>.',
      crux='He learned young that <b>effort and honesty</b> were the only capital his family could give him.',
      conseq='This ethic of relentless early-rising work underpinned the punishing pace of his later scientific career.',
      matters='Character forms in small duties — the newspaper boy’s discipline became the scientist’s.'),

    E('mit', '1950s', 'Aeronautical engineering at MIT Madras', ['RISE', 'EDUCATION'],
      'A gifted student, Kalam studies physics at St Joseph’s College in Tiruchirappalli and then aeronautical engineering at the Madras Institute of Technology — narrowly missing selection as an Air Force pilot, a disappointment he channels into a lifelong resolve to build the machines of flight rather than fly them.',
      svg_row('From physics to flight', [
          {'n': 1, 'label': 'Physics at St Joseph’s College', 'sub': 'Tiruchirappalli, University of Madras', 'color': '#0f766e'},
          {'n': 2, 'label': 'Aeronautics at MIT Madras', 'sub': 'the Madras Institute of Technology', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'Misses the IAF pilot cut', 'sub': 'turns from flying planes to building them', 'color': '#b45309'},
      ], edge_labels=['then', 'but'], takeaway='He trained as an aeronautical engineer — and a rejected pilot’s dream became a builder’s calling.', accent=AC),
      bg='After schooling in Rameswaram, Kalam graduated in <b>physics from St Joseph’s College</b> and enrolled in <b>aeronautical engineering at the Madras Institute of Technology (MIT)</b>.',
      people='his teachers at MIT who pushed him to finish a fighter-aircraft project on deadline; the IAF selection board that passed him over.',
      what='Kalam studied <b>aeronautical engineering at MIT Madras</b>, and though he narrowly missed becoming a fighter pilot in the Indian Air Force, he redirected his ambition toward a career in <b>aerospace engineering</b>.',
      crux='A closed door — the cockpit — opened another: he would <b>design and build</b> flying machines instead of piloting them.',
      conseq='He joined India’s fledgling defence and aerospace establishment as a young engineer.',
      matters='Setbacks reroute destinies — the pilot India rejected became the man who built its rockets and missiles.'),
]

# ==================================================================  PHASE 2 — THE ROCKET YEARS
PHASE_ROCKETS = [
    E('drdo', '1958', 'Joins DRDO — a young rocket engineer', ['RISE', 'SCIENCE'],
      'Kalam begins his career in 1958 at the Defence Research and Development Organisation, where he designs a small hovercraft and other projects — solid grounding, but work that leaves him restless, until a chance encounter with the space pioneer Vikram Sarabhai points him toward the stars.',
      svg_stack('First steps in defence science', [
          {'n': 1, 'label': 'Joins DRDO in 1958', 'sub': 'the Aeronautical Development Establishment', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Designs a hovercraft', 'sub': 'the “Nandi” ground-effect vehicle', 'color': '#0f766e'},
          {'n': 3, 'label': 'Restless for bigger things', 'sub': 'drawn toward India’s new space effort', 'color': '#b45309'},
      ], takeaway='He cut his teeth at DRDO on modest projects — but his eyes were already on rockets and space.', accent=AC),
      bg='In <b>1958</b> Kalam joined the <b>Defence Research and Development Organisation (DRDO)</b> at its Aeronautical Development Establishment as a scientist.',
      people='the DRDO engineers he worked among; <b>Vikram Sarabhai</b>, the father of India’s space programme, who would soon recruit him.',
      what='At DRDO Kalam worked on aeronautics projects including a small <b>hovercraft</b>, gaining engineering experience but feeling the pull of India’s ambitious new <b>space research</b> effort.',
      crux='His early years were a <b>proving ground</b> — competent work that convinced his seniors of his promise.',
      conseq='He was soon drawn into the orbit of Vikram Sarabhai and the Indian space programme.',
      matters='Every great career has an apprenticeship — Kalam’s began quietly in a defence lab.'),

    E('isro', '1969', 'Transfers to ISRO and the SLV dream', ['RISE', 'SPACE'],
      'In 1969 Kalam moves to the Indian Space Research Organisation, where he is entrusted with a formidable task — to serve as project director of India’s first indigenous Satellite Launch Vehicle, the SLV-III — leading a young team determined to put an Indian satellite into orbit with an Indian rocket.',
      svg_row('Chosen to build India’s rocket', [
          {'n': 1, 'label': 'Joins ISRO in 1969', 'sub': 'the Indian Space Research Organisation', 'color': '#0f766e'},
          {'n': 2, 'label': 'Project director, SLV-III', 'sub': 'India’s first indigenous launch vehicle', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'Leads a young team', 'sub': 'aiming to orbit a satellite indigenously', 'color': '#b45309'},
      ], edge_labels=['then', 'to lead'], takeaway='At ISRO he was handed the nation’s rocket dream — to reach orbit with wholly Indian technology.', accent=AC),
      bg='Kalam transferred to the <b>Indian Space Research Organisation (ISRO)</b> in 1969, joining the drive to give India its own space-launch capability.',
      people='<b>Vikram Sarabhai</b> and later ISRO leaders; the young corps of engineers Kalam directed on the SLV project.',
      what='Kalam was made <b>project director of the SLV-III</b>, India’s first indigenously designed and built <b>Satellite Launch Vehicle</b>, charged with placing a satellite into Earth orbit.',
      crux='He now carried <b>national responsibility</b> — the credibility of India’s whole space programme rested on his rocket.',
      conseq='After an early failure, the project would achieve a historic success in 1980.',
      matters='Leadership is trust under risk — India bet its space ambitions on a boat-owner’s son.'),

    E('slv3', '1980', 'SLV-III puts Rohini into orbit', ['TRIUMPH', 'TURNING POINT'],
      'On 18 July 1980, after an earlier launch failure, Kalam’s SLV-III roars off the pad at Sriharikota and places the Rohini satellite into orbit — making India only the sixth nation able to launch a satellite on its own rocket, and turning the once-obscure engineer into a national figure.',
      svg_stack('India reaches orbit on its own', [
          {'n': 1, 'label': 'SLV-III launch, 18 July 1980', 'sub': 'from Sriharikota, after a 1979 failure', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Rohini satellite in orbit', 'sub': 'placed by a wholly Indian rocket', 'color': '#0f766e'},
          {'n': 3, 'label': 'India joins the space club', 'sub': 'the sixth nation to orbit indigenously', 'color': '#b45309'},
      ], takeaway='His rocket put India in orbit under its own power — a landmark that made Kalam a national name.', accent=AC),
      bg='After a failed first attempt in 1979, the SLV-III team under Kalam prepared for a second launch from the <b>Sriharikota</b> range.',
      people='Kalam as project director; the ISRO launch team; the wider scientific establishment watching the outcome.',
      what='On <b>18 July 1980</b> the <b>SLV-III</b> successfully placed the <b>Rohini (RS-1) satellite</b> into orbit, making India one of a handful of nations able to launch satellites with <b>indigenous technology</b>.',
      crux='The success proved India could <b>master space launch on its own</b> — a matter of both technology and national pride.',
      conseq='Kalam’s reputation soared; he was soon recalled to DRDO to lead India’s missile effort.',
      matters='A single successful launch can vault a nation — and its engineer — into a new league.'),
]

# ==================================================================  PHASE 3 — THE MISSILE MAN
PHASE_MISSILES = [
    E('igmdp', '1983', 'The Integrated Guided Missile Programme', ['POLITICS', 'SCIENCE'],
      'Recalled to DRDO, Kalam is put in charge of the Integrated Guided Missile Development Programme, launched in 1983 — an audacious plan to build a whole family of Indian missiles at once: the Prithvi, Agni, Trishul, Akash and Nag — that will make him, in the public mind, the “Missile Man of India.”',
      svg_row('One programme, five missiles', [
          {'n': 1, 'label': 'Returns to DRDO, early 1980s', 'sub': 'to lead India’s missile effort', 'color': '#0f766e'},
          {'n': 2, 'label': 'IGMDP launched in 1983', 'sub': 'Prithvi, Agni, Trishul, Akash, Nag', 'color': '#1d4ed8'},
          {'n': 3, 'label': 'A family built in parallel', 'sub': 'from surface-to-air to ballistic', 'color': '#b45309'},
      ], edge_labels=['to run', 'building'], takeaway='He directed India’s whole missile family at once — an ambition that earned him a nation’s nickname.', accent=AC),
      bg='In the early 1980s Kalam returned to <b>DRDO</b> and was given charge of the <b>Integrated Guided Missile Development Programme (IGMDP)</b>, approved in 1983.',
      people='Kalam as programme director; the DRDO scientists and defence labs across India that he coordinated.',
      what='The IGMDP set out to develop <b>five missile systems together</b> — the <b>Prithvi</b> and <b>Agni</b> ballistic missiles, and the <b>Trishul, Akash and Nag</b> tactical missiles — an unusually ambitious, self-reliant defence project.',
      crux='He chose to build <b>a whole missile ecosystem</b> rather than one weapon — betting on breadth and indigenous capability.',
      conseq='The programme delivered India’s first home-grown ballistic and tactical missiles over the following decade.',
      matters='Strategic autonomy is built, not bought — the IGMDP gave India missiles it did not have to import.'),

    E('agniprithvi', '1988–1989', 'Prithvi and Agni take flight', ['TRIUMPH', 'SCIENCE'],
      'The programme bears fruit as the short-range Prithvi is first tested in 1988 and the longer-range Agni follows in 1989 — giving India its own tactical and strategic missile capability, and cementing Kalam’s standing as the architect of the nation’s guided-missile arsenal.',
      svg_stack('India’s own missiles fly', [
          {'n': 1, 'label': 'Prithvi tested, 1988', 'sub': 'India’s first indigenous ballistic missile', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Agni tested, 1989', 'sub': 'a longer-range strategic missile', 'color': '#0f766e'},
          {'n': 3, 'label': 'A home-grown arsenal', 'sub': 'tactical and strategic reach achieved', 'color': '#b45309'},
      ], takeaway='Prithvi and Agni proved the programme worked — India could now build its own missiles.', accent=AC),
      bg='The IGMDP’s flagship systems moved from design to flight test in the late 1980s under Kalam’s direction.',
      people='Kalam and his DRDO missile teams; the Indian armed forces who would field the weapons.',
      what='The <b>Prithvi</b> surface-to-surface missile was first flight-tested in <b>1988</b> and the <b>Agni</b> intermediate-range missile in <b>1989</b>, establishing India’s <b>indigenous ballistic-missile capability</b>.',
      crux='These flights showed India had crossed from <b>ambition to hardware</b> — real, working strategic missiles.',
      conseq='India’s missile deterrent took shape, and Kalam became a household name as its chief builder.',
      matters='Deterrence rests on demonstrated capability — the Agni test announced India as a missile power.'),

    E('bharatratna', '1997', 'The Bharat Ratna and the “Missile Man”', ['LEGACY', 'TRIUMPH'],
      'By the mid-1990s Kalam is celebrated across India as the “Missile Man,” and in 1997 he receives the Bharat Ratna, the nation’s highest civilian honour — a rare recognition of a working scientist, elevating him from technical eminence toward a place in the public imagination.',
      svg_row('A scientist honoured by the nation', [
          {'n': 1, 'label': 'Hailed as the “Missile Man”', 'sub': 'architect of India’s missile arsenal', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Bharat Ratna, 1997', 'sub': 'India’s highest civilian honour', 'color': '#b45309'},
          {'n': 3, 'label': 'A public figure emerges', 'sub': 'a scientist becomes a national icon', 'color': '#0f766e'},
      ], edge_labels=['earns', 'and'], takeaway='The nation’s highest civilian award crowned his missile work — and made a scientist into an icon.', accent=AC),
      bg='By 1997 Kalam’s missile and space achievements had made him one of the most respected figures in Indian science.',
      people='the Government of India, which conferred the award; the public that had adopted him as a hero.',
      what='In <b>1997</b> Kalam was awarded the <b>Bharat Ratna</b>, India’s highest civilian honour — an unusual distinction for a serving scientist — confirming his status as the celebrated <b>“Missile Man of India.”</b>',
      crux='The honour marked a shift: he was no longer only a scientist but a <b>national symbol</b> of self-reliant achievement.',
      conseq='His growing public stature laid the ground for his later, unexpected move into high office.',
      matters='A society signals its values by whom it honours — India crowned a scientist as a national hero.'),
]

# ==================================================================  PHASE 4 — SHAKTI AND SOCIETY
PHASE_SHAKTI = [
    E('adviser', '1992–1999', 'Scientific adviser to the government', ['POLITICS', 'REFORM'],
      'From 1992 Kalam serves as scientific adviser to the Defence Minister and head of DRDO, and later as Principal Scientific Adviser to the Government of India with cabinet rank — moving from the laboratory into the councils of national strategy and policy.',
      svg_stack('From lab bench to cabinet table', [
          {'n': 1, 'label': 'Scientific adviser from 1992', 'sub': 'to the Defence Minister; Secretary, DRDO', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Principal Scientific Adviser', 'sub': 'to the Government of India, cabinet rank', 'color': '#0f766e'},
          {'n': 3, 'label': 'Shaping national strategy', 'sub': 'technology at the heart of policy', 'color': '#b45309'},
      ], takeaway='He rose into the government’s inner councils — carrying science to the centre of the state.', accent=AC),
      bg='Through the 1990s Kalam took on senior advisory roles bridging <b>defence science and national policy</b>.',
      people='the defence ministers he advised; the DRDO he led as Secretary; the cabinet he later served as adviser.',
      what='Kalam served as <b>Scientific Adviser to the Defence Minister and Secretary of DRDO</b> from 1992, and in 1999 became <b>Principal Scientific Adviser to the Government of India</b> with the rank of a cabinet minister.',
      crux='He moved from <b>building technology to directing it</b> — steering the nation’s scientific priorities.',
      conseq='From this position he helped organise India’s decisive nuclear tests of 1998.',
      matters='Technical mastery can open the doors of the state — Kalam became science’s voice in government.'),

    E('pokhran', '1998', 'Pokhran-II — India goes nuclear', ['POLITICS', 'TURNING POINT'],
      'In May 1998 Kalam plays a central organising role in Operation Shakti — the Pokhran-II nuclear tests — coordinating with the Department of Atomic Energy as India detonates a series of devices in the Rajasthan desert and declares itself a full-fledged nuclear-weapons state.',
      svg_stack('The desert tests that changed India’s standing', [
          {'n': 1, 'label': 'Pokhran-II tests, May 1998', 'sub': 'Operation Shakti in the Rajasthan desert', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Kalam co-ordinates the effort', 'sub': 'DRDO with the Atomic Energy Department', 'color': '#0f766e'},
          {'n': 3, 'label': 'India declares nuclear status', 'sub': 'a full-fledged nuclear-weapons power', 'color': '#b45309'},
      ], takeaway='He helped organise the 1998 nuclear tests that announced India as a declared nuclear power.', accent=AC),
      bg='In May 1998 India conducted a series of underground <b>nuclear tests at Pokhran</b> in Rajasthan, known as <b>Pokhran-II</b> or Operation Shakti.',
      people='<b>Kalam</b>, coordinating the defence side; atomic scientist <b>R. Chidambaram</b>; Prime Minister <b>Atal Bihari Vajpayee</b>, who authorised the tests.',
      what='Kalam was a <b>key organiser of the Pokhran-II tests</b>, working with the <b>Department of Atomic Energy</b> as India detonated several nuclear devices and openly declared itself a <b>nuclear-weapons state</b>.',
      crux='The tests were a <b>strategic assertion</b> — India claiming its place among the nuclear powers, whatever the sanctions.',
      conseq='India faced international sanctions but emerged as a recognised nuclear power; Kalam’s prestige rose further.',
      matters='A handful of desert blasts redrew India’s standing — and Kalam stood at their organising centre.'),

    E('stent', '1998', 'The Kalam-Raju stent and rural technology', ['REFORM', 'LEGACY'],
      'Even amid weapons work, Kalam turns technology toward the poor — collaborating with the cardiologist B. Soma Raju to create the low-cost “Kalam-Raju” coronary stent, and later a rugged rural healthcare tablet, insisting that Indian science must serve ordinary lives as well as national defence.',
      svg_compare('Two faces of Kalam’s science', {
          'head': 'Technology for defence', 'color': '#1d4ed8',
          'items': ['Missiles and launch vehicles', 'Nuclear-weapons capability', 'Strategic autonomy', 'National security'],
      }, {
          'head': 'Technology for the people', 'color': '#0f766e',
          'items': ['Low-cost Kalam-Raju stent', 'Rugged rural healthcare tablet', 'Affordable medical devices', 'Development of the poor'],
      }, verdict='He wanted Indian science to serve the villager as much as the soldier — power and welfare together.',
         takeaway='The Missile Man also built cheap medical devices — technology, for him, had to reach the poor.', accent=AC),
      bg='Alongside his defence work, Kalam pursued projects applying <b>advanced technology to social needs</b>, especially affordable healthcare.',
      people='the cardiologist <b>B. Soma Raju</b>, his collaborator; the rural patients and villagers the work aimed to serve.',
      what='Kalam worked with Dr Soma Raju to develop the low-cost <b>“Kalam-Raju” coronary stent</b>, and later a rugged healthcare tablet for rural India, championing <b>technology for social development</b>.',
      crux='He believed <b>science must lift the poor</b>, not only arm the state — welfare was part of national strength.',
      conseq='This vision fed his later crusade, as president, for a developed India built on technology.',
      matters='The measure of a scientist is who benefits — Kalam pointed his genius at the villager as well as the missile.'),
]

# ==================================================================  PHASE 5 — THE PEOPLE’S PRESIDENT
PHASE_PRESIDENT = [
    E('books', '1998–1999', 'Wings of Fire and the vision of India 2020', ['IDEAS', 'LEGACY'],
      'Kalam becomes a best-selling author and visionary, publishing the road-map "India 2020" and the autobiography "Wings of Fire" — books that lay out a plan to turn India into a developed nation by 2020 and tell the story of his own rise, inspiring millions of young readers.',
      svg_row('The scientist as author and dreamer', [
          {'n': 1, 'label': '“India 2020” (1998)', 'sub': 'a road-map to a developed nation', 'color': '#1d4ed8'},
          {'n': 2, 'label': '“Wings of Fire” (1999)', 'sub': 'his best-selling autobiography', 'color': '#b45309'},
          {'n': 3, 'label': 'Millions of young readers', 'sub': 'a vision of national transformation', 'color': '#0f766e'},
      ], edge_labels=['then', 'reaching'], takeaway='His books turned a scientist into a national dreamer — a plan for India and the story of his own rise.', accent=AC),
      bg='In the late 1990s Kalam set out his ideas for national development and his own life story in a series of widely read books.',
      people='his co-authors, including <b>Y.S. Rajan</b> (India 2020) and <b>Arun Tiwari</b> (Wings of Fire); his vast readership of students.',
      what='Kalam co-wrote <b>“India 2020: A Vision for the New Millennium” (1998)</b>, mapping India’s path to developed-nation status, and the autobiography <b>“Wings of Fire” (1999)</b>, both becoming <b>hugely popular</b>.',
      crux='He recast national development as an <b>inspiring, achievable mission</b>, addressed above all to the young.',
      conseq='His writings and vision made him beloved by students and prepared the public for his presidency.',
      matters='A compelling vision, well told, can move a nation — Kalam gave India a date to aim for and a story to believe.'),

    E('election', '2002', 'Elected President of India', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'In 2002 the working scientist is elected the 11th President of India, sworn in on 25 July with support cutting across party lines — a rare non-politician raised to the nation’s highest office on the strength of his achievements and his standing with ordinary people.',
      svg_stack('A scientist enters Rashtrapati Bhavan', [
          {'n': 1, 'label': 'Elected President, 2002', 'sub': 'the 11th President of India', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Sworn in 25 July 2002', 'sub': 'backed across party lines', 'color': '#0f766e'},
          {'n': 3, 'label': 'A non-politician at the top', 'sub': 'raised on merit and popularity', 'color': '#b45309'},
      ], takeaway='India made its Missile Man head of state — a scientist, not a politician, in the highest office.', accent=AC),
      bg='In 2002 the ruling coalition and much of the opposition backed Kalam for the largely ceremonial but prestigious post of <b>President of India</b>.',
      people='Prime Minister <b>Atal Bihari Vajpayee</b>, who proposed him; the broad political coalition that elected him; his opponent <b>Lakshmi Sahgal</b>.',
      what='Kalam was elected the <b>11th President of India</b> and sworn in on <b>25 July 2002</b>, winning by a wide margin with <b>cross-party support</b> as a widely admired non-political figure.',
      crux='His election showed that <b>merit and public affection</b> could carry a scientist to the summit of the state.',
      conseq='He brought an unusually accessible, youth-focused style to the presidency.',
      matters='A nation reveals its aspirations in whom it elevates — India chose a scientist-teacher as its symbol.'),

    E('peoples', '2002–2007', 'The “People’s President”', ['POLITICS', 'LEGACY'],
      'As president Kalam becomes known as the "People’s President," throwing open Rashtrapati Bhavan, tirelessly meeting students, and urging the young to dream big — publishing "Ignited Minds" to fire a generation with his conviction that India can become a great developed nation.',
      svg_row('A presidency for the young', [
          {'n': 1, 'label': 'The “People’s President”', 'sub': 'accessible, warm, endlessly touring', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Meets millions of students', 'sub': 'urging them to “dream big”', 'color': '#b45309'},
          {'n': 3, 'label': '“Ignited Minds” (2002)', 'sub': 'a call to awaken India’s youth', 'color': '#0f766e'},
      ], edge_labels=['who', 'and wrote'], takeaway='He turned the presidency toward the young — meeting students everywhere and telling them to dream.', accent=AC),
      bg='Kalam served as president from 2002 to 2007, bringing a distinctive, <b>outward-facing style</b> to the office.',
      people='the countless <b>students</b> he addressed across India; the ordinary citizens who embraced him as their own.',
      what='Kalam became famous as the <b>“People’s President,”</b> devoting himself to <b>meeting and inspiring students</b>, and publishing <b>“Ignited Minds” (2002)</b> to rouse India’s youth toward national development.',
      crux='He used the ceremonial office as a <b>bully pulpit for aspiration</b>, especially among the young.',
      conseq='His popularity, particularly with students, reached heights rarely matched by any Indian public figure.',
      matters='Symbolic office can inspire when filled with sincerity — Kalam made the presidency a fountain of hope for the young.'),
]

# ==================================================================  PHASE 6 — TEACHER TO THE END
PHASE_LEGACY = [
    E('postpres', '2007–2015', 'Back to the classroom', ['LEGACY', 'IDEAS'],
      'Leaving office in 2007, Kalam returns happily to what he loved most — teaching — becoming a visiting professor at leading institutions from the IIMs to the IITs and IISc, and travelling ceaselessly to lecture the young, insisting that a former president’s truest role is that of a teacher.',
      svg_stack('A former president who chose to teach', [
          {'n': 1, 'label': 'Leaves office in 2007', 'sub': 'returns to teaching and writing', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Visiting professor', 'sub': 'at the IIMs, IITs, IISc and beyond', 'color': '#0f766e'},
          {'n': 3, 'label': 'Ceaseless lecturing to youth', 'sub': '“I am, above all, a teacher”', 'color': '#b45309'},
      ], takeaway='In retirement he went back to the classroom — teaching, for him, was the highest calling.', accent=AC),
      bg='After his presidency Kalam devoted himself to <b>education and public engagement</b> rather than politics.',
      people='the students and faculties of the many institutions he taught at; the young audiences he addressed nationwide.',
      what='Kalam became a <b>visiting professor</b> at institutions including the <b>Indian Institutes of Management and Technology and IISc</b>, and travelled constantly to <b>lecture and inspire students</b>, calling himself first and foremost a teacher.',
      crux='He held that his highest identity was not scientist or president but <b>teacher</b> — a shaper of young minds.',
      conseq='He remained among India’s most sought-after and beloved speakers until his death.',
      matters='Influence outlasts office — Kalam’s post-presidency was arguably his most far-reaching, one classroom at a time.'),

    E('death', '2015', 'Death while teaching at IIM Shillong', ['DEATH', 'TURNING POINT'],
      'On 27 July 2015, aged 83, Kalam collapses from a sudden cardiac arrest while delivering a lecture to students at the Indian Institute of Management in Shillong — dying, as he had lived, in the act of teaching the young — and a grieving nation mourns him as few of its leaders.',
      svg_row('The end comes mid-lecture', [
          {'n': 1, 'label': 'Lecturing at IIM Shillong', 'sub': '27 July 2015, speaking to students', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'Cardiac arrest on stage', 'sub': 'he collapses aged 83', 'color': '#b45309'},
          {'n': 3, 'label': 'A nation in mourning', 'sub': 'died as he lived — teaching', 'color': '#0f766e'},
      ], edge_labels=['when', 'and'], takeaway='He died on his feet before students — a fitting end for a man who called himself a teacher.', accent=AC),
      bg='Kalam remained active into his eighties, keeping a punishing schedule of lectures and public appearances.',
      people='the IIM Shillong students he was addressing; the millions of Indians who mourned him; the state that honoured him.',
      what='On <b>27 July 2015</b>, at the age of <b>83</b>, Kalam suffered a <b>fatal cardiac arrest while delivering a lecture</b> at the Indian Institute of Management in <b>Shillong</b>, dying in the act of teaching.',
      crux='His death, mid-lecture, seemed to <b>seal his identity</b> — a life given wholly to inspiring the young.',
      conseq='India declared national mourning; tributes poured in from across the political and social spectrum.',
      matters='Some deaths crystallise a life’s meaning — Kalam fell teaching, and the nation grieved a teacher.'),

    E('legacy', '2015–', 'The Missile Man who became a legend', ['LEGACY', 'TRIUMPH'],
      'Kalam endures as one of independent India’s most beloved figures — the poor boat-owner’s son who built its rockets and missiles, went nuclear, rose to the presidency, and gave his last years to the young — remembered as the "Missile Man" and "People’s President," a rare unifier admired across every divide.',
      svg_stack('An enduring national icon', [
          {'n': 1, 'label': 'The “Missile Man of India”', 'sub': 'architect of its space and missile power', 'color': '#1d4ed8'},
          {'n': 2, 'label': 'The “People’s President”', 'sub': 'beloved across every divide', 'color': '#b45309'},
          {'n': 3, 'label': 'An icon for the young', 'sub': 'a life of merit, service and hope', 'color': '#0f766e'},
      ], takeaway='He remains a rare unifying hero — the humble scientist who inspired a nation to dream bigger.', accent=AC),
      bg='After his death Kalam’s reputation only grew, his birthday marked as a day of youth and learning across India.',
      people='the generations of students who take him as a model; the institutions, awards and missiles that bear his name.',
      what='Kalam is remembered as the <b>“Missile Man of India”</b> and <b>“People’s President,”</b> the humble scientist who reached the highest office and devoted himself to the young — a <b>unifying icon</b> admired across religion, region and party.',
      crux='His legend rests on <b>merit married to humility and service</b> — achievement without arrogance.',
      conseq='He remains among the most respected and inspiring figures in modern Indian life.',
      matters='A nation needs heroes it can agree on — in Kalam, India found a unifier who told it to dream.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">A.P.J. Abdul Kalam was the boat-owner’s son from a Tamil island who rose to build India’s rockets and missiles and to become its “People’s President.” As project director he put a satellite into orbit on India’s first indigenous launch vehicle, then led the missile programme that made him the “Missile Man of India,” and helped organise the 1998 nuclear tests. Elected the 11th President of India in 2002, he became beloved above all by the young — and died, fittingly, while teaching. He is the ultimate study in <b>merit, humility, and technology in the service of a nation.</b></p>
<div class="ov-quote">“Dream, dream, dream. Dreams transform into thoughts and thoughts result in action.”<span>— A.P.J. Abdul Kalam</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born a poor boat-owner’s son in Rameswaram and trained as an aeronautical engineer → directs the SLV-III that puts Rohini into orbit in 1980 → leads the Integrated Guided Missile Programme, building Prithvi and Agni → helps organise the 1998 Pokhran-II nuclear tests → writes best-selling books of national vision → is elected President in 2002 and adored as the “People’s President” → and dies teaching students at IIM Shillong in 2015, an enduring icon.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🚀</div><h4>India’s rocket &amp; missile builder</h4><p>SLV-III to orbit; Prithvi and Agni; the “Missile Man.”</p></div>
  <div class="ov-card"><div class="i">⚛️</div><h4>A nuclear power</h4><p>Central organiser of the 1998 Pokhran-II tests.</p></div>
  <div class="ov-card"><div class="i">🇮🇳</div><h4>The People’s President</h4><p>A non-politician raised to the highest office on merit.</p></div>
  <div class="ov-card"><div class="i">📚</div><h4>Teacher to the young</h4><p>Books and lectures that told a generation to dream big.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Roots</b><small> 1931–1950s</small><p>Rameswaram, newspapers, aeronautics at MIT Madras.</p></div>
  <div><b>2 · The Rockets</b><small> 1958–1980</small><p>DRDO, ISRO, and SLV-III putting Rohini into orbit.</p></div>
  <div><b>3 · Missile Man</b><small> 1983–1997</small><p>The IGMDP, Prithvi and Agni, the Bharat Ratna.</p></div>
  <div><b>4 · Shakti</b><small> 1992–1998</small><p>Adviser, Pokhran-II, and technology for the poor.</p></div>
  <div><b>5 · President</b><small> 1998–2007</small><p>Best-selling vision, the presidency, the People’s President.</p></div>
  <div><b>6 · Teacher</b><small> 2007–</small><p>Back to the classroom, death mid-lecture, the legend.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Vikram Sarabhai', 'role': 'space pioneer', 'color': '#1d4ed8',
     'bio': 'The father of India’s space programme who drew Kalam into ISRO and set him on the path to building launch vehicles.',
     'rel': 'The mentor who brought him into India’s space effort.'},
    {'name': 'Atal Bihari Vajpayee', 'role': 'Prime Minister', 'color': '#0f766e',
     'bio': 'The Prime Minister who authorised the 1998 Pokhran-II nuclear tests and championed Kalam’s election as President in 2002.',
     'rel': 'The leader who backed both his nuclear tests and his presidency.'},
    {'name': 'R. Chidambaram', 'role': 'atomic scientist', 'color': '#b45309',
     'bio': 'The head of the Department of Atomic Energy who led the scientific side of the Pokhran-II tests alongside Kalam’s defence team.',
     'rel': 'His partner in organising the 1998 nuclear tests.'},
    {'name': 'B. Soma Raju', 'role': 'cardiologist', 'color': '#7c3aed',
     'bio': 'The cardiologist who collaborated with Kalam to develop the low-cost “Kalam-Raju” coronary stent for ordinary patients.',
     'rel': 'His collaborator on affordable medical technology.'},
    {'name': 'Jainulabdeen', 'role': 'his father', 'color': '#a16207',
     'bio': 'The Rameswaram boat-owner and mosque imam whose faith, thrift and simplicity shaped Kalam’s character for life.',
     'rel': 'The father whose values guided him from island boy to president.'},
]

KEY_EVENTS = [
    ('1931', 'Kalam born in Rameswaram', 'A boat-owner’s son on a Tamil island.'),
    ('1958', 'Joins DRDO', 'A young rocket and aeronautics engineer.'),
    ('1969', 'Transfers to ISRO', 'Made project director of the SLV-III.'),
    ('1980', 'SLV-III orbits Rohini', 'India launches a satellite indigenously.'),
    ('1983', 'IGMDP launched', 'Prithvi, Agni and a missile family.'),
    ('1989', 'Agni first tested', 'India gains strategic missile reach.'),
    ('1997', 'Bharat Ratna', 'India’s highest civilian honour.'),
    ('1998', 'Pokhran-II tests', 'India declares itself a nuclear power.'),
    ('1999', 'Wings of Fire', 'His best-selling autobiography.'),
    ('2002', 'Elected President', 'The 11th President; the “People’s President.”'),
    ('2015', 'Dies at IIM Shillong', 'Collapses while lecturing students.'),
]

MASTER = [
    {'year': '1931', 'age': 'born', 'phase': 'Roots', 'title': 'Born in Rameswaram', 'desc': 'A boat-owner’s son.'},
    {'year': '1958', 'age': 'age 27', 'phase': 'The Rockets', 'title': 'Joins DRDO', 'desc': 'A young aerospace engineer.'},
    {'year': '1980', 'age': 'age 48', 'phase': 'The Rockets', 'title': 'SLV-III to orbit', 'desc': 'Rohini launched indigenously.'},
    {'year': '1983', 'age': 'age 51', 'phase': 'Missile Man', 'title': 'IGMDP launched', 'desc': 'Prithvi, Agni and more.'},
    {'year': '1997', 'age': 'age 65', 'phase': 'Missile Man', 'title': 'Bharat Ratna', 'desc': 'The nation’s highest honour.'},
    {'year': '1998', 'age': 'age 66', 'phase': 'Shakti', 'title': 'Pokhran-II', 'desc': 'India goes nuclear.'},
    {'year': '2002', 'age': 'age 70', 'phase': 'President', 'title': 'Elected President', 'desc': 'The People’s President.'},
    {'year': '2007', 'age': 'age 75', 'phase': 'Teacher', 'title': 'Back to teaching', 'desc': 'Visiting professor to the young.'},
    {'year': '2015', 'age': 'age 83', 'phase': 'Teacher', 'title': 'Dies at IIM Shillong', 'desc': 'Collapses mid-lecture.'},
]

SOURCES = [
    ('Britannica — A.P.J. Abdul Kalam', 'https://www.britannica.com/biography/A-P-J-Abdul-Kalam'),
    ('Wikipedia — A.P.J. Abdul Kalam', 'https://en.wikipedia.org/wiki/A._P._J._Abdul_Kalam'),
    ('President of India — Dr A.P.J. Abdul Kalam profile', 'https://presidentofindia.nic.in/dr-apj-abdul-kalam-profile'),
    ('ISRO — Satellite Launch Vehicle (SLV)', 'https://www.isro.gov.in/SatelliteLaunchVehicle.html'),
    ('DRDO — Integrated Guided Missile Development Programme', 'https://www.drdo.gov.in/drdo/about-us'),
    ('Wikipedia — Integrated Guided Missile Development Programme', 'https://en.wikipedia.org/wiki/Integrated_Guided_Missile_Development_Programme'),
]

def build_meta():
    return {
        'pid': 'gm-kalam.html', 'kind': 'man', 'emoji': '🚀', 'accent': AC,
        'name': 'A.P.J. Abdul Kalam', 'years': '1931–2015', 'group': 'Independence & Nation-Building',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The boat-owner’s son who built India’s rockets and missiles — orbiting a satellite on the SLV-III, fathering the Prithvi and Agni, organising the 1998 nuclear tests, and rising to become the beloved “People’s President.”',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'roots', 'label': '1 · Roots', 'type': 'timeline',
             'intro': 'Born a poor boat-owner’s son in Rameswaram, the newspaper boy studies aeronautical engineering at MIT Madras and turns from a rejected pilot’s dream to building flying machines.', 'events': PHASE_ROOTS},
            {'id': 'rockets', 'label': '2 · The Rockets', 'type': 'timeline',
             'intro': 'From DRDO to ISRO, Kalam is made project director of the SLV-III — and in 1980 puts the Rohini satellite into orbit on India’s first indigenous launch vehicle.', 'events': PHASE_ROCKETS},
            {'id': 'missiles', 'label': '3 · Missile Man', 'type': 'timeline',
             'intro': 'Recalled to DRDO, he leads the Integrated Guided Missile Development Programme — building Prithvi and Agni and earning the Bharat Ratna and the name “Missile Man of India.”', 'events': PHASE_MISSILES},
            {'id': 'shakti', 'label': '4 · Shakti', 'type': 'timeline',
             'intro': 'As scientific adviser he helps organise the 1998 Pokhran-II nuclear tests — while also turning technology toward the poor with the low-cost Kalam-Raju stent.', 'events': PHASE_SHAKTI},
            {'id': 'president', 'label': '5 · President', 'type': 'timeline',
             'intro': 'His best-selling books of national vision carry him from the laboratory to Rashtrapati Bhavan — where, elected in 2002, he becomes the beloved “People’s President.”', 'events': PHASE_PRESIDENT},
            {'id': 'legacy', 'label': '6 · Teacher', 'type': 'timeline',
             'intro': 'Leaving office, he returns to the classroom he loved — and dies teaching students at IIM Shillong in 2015, remembered as a rare unifying icon of modern India.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Encyclopaedic and official biographies (Britannica, President of India, ISRO, DRDO); dates for launches, tests and offices follow the standard published record.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
