# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Robert Moses.
The unelected “master builder” who remade New York — and bulldozed its neighborhoods."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#9a3412'  # construction rust / brick

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE IDEALIST
PHASE_RISE = [
    E('origins', '1888–1919', 'The idealist — a reformer learns that ideals need power', ['RISE', 'REFORM'],
      'Born to wealth and educated at Yale and Oxford, the young Robert Moses is a high-minded Progressive who dreams of cleansing government of patronage — until Tammany Hall crushes his civil-service reform scheme, teaching him the bitter lesson that will define his life: ideals are useless without the raw power to impose them.',
      svg_row('From Oxford idealist to hard realist', [
          {'n': 1, 'label': 'Yale, Oxford, a doctorate', 'sub': 'brilliant idealist who disdains the machine', 'color': '#3730a3'},
          {'n': 2, 'label': 'His reform plan is crushed', 'sub': 'Tammany scraps his merit-rating scheme', 'color': '#b91c1c'},
          {'n': 3, 'label': 'He learns to wield power', 'sub': 'good intentions achieve nothing alone', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='The idealist who was defeated for having no power resolved never to be powerless again — the making of the Power Broker.', accent=AC),
      bg='<b>Robert Moses</b> was born in 1888 into a wealthy German-Jewish family, educated at Yale and Oxford and awarded a doctorate — a self-consciously idealistic Progressive reformer.',
      people='the <b>Tammany Hall</b> machine that defeated him; <b>Belle Moskowitz</b>, who would spot his talent; the reform movement he outgrew.',
      what='Moses’ early crusade to reform New York City’s <b>civil service on merit</b> was defeated and scrapped by the entrenched patronage machine — a humiliation that taught him good intentions without power achieve nothing.',
      crux='He absorbed the defining lesson of his life: <b>ideals are useless without the means to enforce them</b>.',
      conseq='He would spend the rest of his career accumulating power — first to build his dreams, and finally almost for its own sake.',
      matters='A famous case of a reformer’s disillusion hardening into ruthlessness — the origin of a man who would never again be powerless.'),

    E('smith', '1919–1928', 'Al Smith’s man — mastering the levers of the state', ['RISE', 'POLITICS'],
      'Moses attaches himself to Governor Al Smith and learns practical politics from a Tammany-bred master — becoming known as “the best bill drafter in Albany,” he writes the very laws that in 1924 hand him control of the state’s parks, embedding his power in statute where elected rivals cannot easily reach it.',
      svg_stack('Building the machine of his own power', [
          {'n': 1, 'label': 'Allies with Governor Al Smith', 'sub': 'the reformer learns from a master politician', 'color': '#3730a3'},
          {'n': 2, 'label': '“Best bill drafter in Albany”', 'sub': 'writes the laws that create his own agencies', 'color': '#a16207'},
          {'n': 3, 'label': 'Long Island parks, 1924', 'sub': 'president of the state park commission', 'color': '#166534'},
      ], takeaway='He learned to write his own authority into law — power an election could not grant and a governor could not easily strip.', accent=AC),
      bg='In 1919 Moses joined the circle of Governor <b>Al Smith</b> through Belle Moskowitz, learning hard practical politics from a Tammany-bred master.',
      people='Governor <b>Al Smith</b>, his patron and teacher; <b>Belle Moskowitz</b>; the state legislature whose bills he drafted.',
      what='Renowned as <b>“the best bill drafter in Albany,”</b> Moses wrote the legislation that in 1924 made him president of the <b>Long Island State Park Commission</b> and chairman of the State Council of Parks — posts he held until 1963.',
      crux='He drafted the very laws that gave him power, <b>embedding his authority in statute</b> where elected officials could not easily reach it.',
      conseq='Armed with legal control of parks, he began seizing Long Island land to build a public playground for the masses.',
      matters='True power often hides in the fine print — Moses grasped that whoever writes the rules can outlast whoever wins the votes.'),

    E('jonesbeach', '1924–1929', 'Jones Beach — the idealist’s masterpiece', ['TRIUMPH', 'REFORM'],
      'Battling wealthy estate owners for the land, Moses literally builds up Jones Beach and opens it in 1929 to national acclaim — a magnificent public beach for millions of ordinary families, reached by his gleaming new parkways. At his best, he is a genuine democratic idealist, building beauty for the crowds.',
      svg_row('A public masterpiece for the masses', [
          {'n': 1, 'label': 'Seizes Long Island land', 'sub': 'battles wealthy estate owners and baymen', 'color': '#a16207'},
          {'n': 2, 'label': 'Jones Beach opens, 1929', 'sub': 'a magnificent public beach for millions', 'color': '#166534'},
          {'n': 3, 'label': 'Parkways to reach it', 'sub': 'Northern & Southern State among America’s first', 'color': '#3730a3'},
      ], edge_labels=['then', 'plus'], takeaway='Jones Beach proved his method and his idealism at once — build big, build fast, and build for the ordinary crowds.', accent=AC),
      bg='Long Island’s south shore was inaccessible marsh and private estate; Moses envisioned a grand public beach open to all New Yorkers.',
      people='the <b>wealthy landowners</b> he fought for the land; the working families he wanted to serve; his engineers and designers.',
      what='Moses literally built up <b>Jones Beach State Park</b>, opening it in 1929 to national acclaim — with bathhouses, boardwalks and landscaped parkways (the Northern and Southern State) carrying city families to the sea.',
      crux='At his best, Moses was a <b>genuine democratic idealist</b>, creating beauty and recreation for ordinary people on a vast scale.',
      conseq='The triumph made him a public hero and proved his method — and gave him the momentum to build ever bigger.',
      matters='The Moses the public first loved was real — a builder of magnificent public goods, before power became its own end.'),
]

# ==================================================================  PHASE 2 — THE MACHINE OF POWER
PHASE_POWER = [
    E('commissioner', '1934', 'Parks Commissioner — uniting the city under one hand', ['POLITICS', 'TURNING POINT'],
      'Reform Mayor Fiorello LaGuardia makes Moses citywide Parks Commissioner in 1934, and he merges five squabbling borough departments into one command under himself — stacking a dozen city and state offices in a single pair of hands, gathering positions the way other men gather money.',
      svg_stack('Consolidating a fractured city', [
          {'n': 1, 'label': 'NYC Parks Commissioner, Jan 1934', 'sub': 'appointed by Mayor Fiorello LaGuardia', 'color': '#3730a3'},
          {'n': 2, 'label': 'Five borough systems merged', 'sub': 'one unified command under Moses', 'color': '#a16207'},
          {'n': 3, 'label': 'A dozen offices at once', 'sub': 'city and state posts stacked in one man', 'color': '#166534'},
      ], takeaway='He gathered offices the way others gather money — but his true engine of power was not an elected post at all.', accent=AC),
      bg='In 1934 reform Mayor <b>Fiorello LaGuardia</b> named Moses citywide Parks Commissioner, unifying five separate borough departments.',
      people='Mayor <b>Fiorello LaGuardia</b>, his new patron; the borough patronage bosses he displaced; the city bureaucracy.',
      what='Moses became <b>NYC Parks Commissioner on 18 January 1934</b> (holding it until 1960), merging the boroughs’ parks into one command and accumulating multiple simultaneous city and state offices.',
      crux='He gathered offices as sources of leverage — <b>each new post a new grip</b> on the city’s development.',
      conseq='Yet his real engine of power was not any of these elected-adjacent offices — it was the public authority.',
      matters='Concentrating many offices in one unelected hand is how bureaucratic power quietly escapes democratic control.'),

    E('authority', '1934–1968', 'The Triborough Authority — power without a ballot', ['POLITICS', 'TURNING POINT'],
      'Moses turns the Triborough Bridge Authority into the true engine of his empire: tolls pour in far past projection, and instead of retiring the bonds he writes covenants letting him issue new bonds for new projects forever — a self-perpetuating money machine whose contracts the courts must protect from any mayor or governor.',
      svg_row('The self-perpetuating money machine', [
          {'n': 1, 'label': 'Triborough Authority, 1934', 'sub': 'chairman for 34 years, effectively un-fireable', 'color': '#3730a3'},
          {'n': 2, 'label': 'Tolls pour in past projection', 'sub': 'a torrent of unaccountable cash', 'color': '#166534'},
          {'n': 3, 'label': 'Bond covenants lock in his rule', 'sub': 'contracts the courts must shield from politicians', 'color': '#b91c1c'},
      ], edge_labels=['yields', 'and'], takeaway='An unelected office, funded by tolls and armored by bond contracts, that no voter or governor could touch — the heart of The Power Broker.', accent=AC),
      bg='To finance the Triborough Bridge, a public authority was created in 1934 to sell bonds repaid by tolls. Moses became — and stayed — its chairman.',
      people='the <b>bondholders</b> whose contracts shielded him; the mayors and governors who could not remove him; <b>Robert Caro</b>, who later exposed the mechanism.',
      what='Moses built the <b>Triborough Bridge Authority</b> into an empire: toll revenues far exceeded projections, and rather than retire the bonds he wrote <b>covenants</b> letting him issue new bonds for new projects endlessly — a self-financing machine whose contracts were constitutionally shielded from elected interference.',
      crux='This was his masterstroke — an <b>unelected office, funded by tolls and armored by bond covenants</b>, beyond the reach of any voter or governor.',
      conseq='For three decades Moses held more real power over New York than any mayor or governor, without ever winning a single election.',
      matters='The central lesson of The Power Broker — how an unaccountable public authority can concentrate immense power outside democratic reach.'),

    E('newdeal', '1934–1939', 'The New Deal builder — pools, playgrounds and shovels ready', ['TRIUMPH', 'REFORM'],
      'When New Deal relief money floods out after 1933, most cities have no plans ready — but Moses has drawers full of them, and captures a huge share of the federal cash to build eleven monumental pools in 1936, hundreds of playgrounds and scores of parks: the greatest public-works spree any American city had seen.',
      svg_stack('The one man ready to build', [
          {'n': 1, 'label': 'New Deal money floods in, 1933', 'sub': 'few cities have plans ready — Moses does', 'color': '#a16207'},
          {'n': 2, 'label': 'Eleven grand pools open, 1936', 'sub': 'WPA labor; 49,000 swimmers a day', 'color': '#166534'},
          {'n': 3, 'label': 'Hundreds of playgrounds', 'sub': 'he captures the lion’s share of federal cash', 'color': '#3730a3'},
      ], takeaway='His genius for preparation turned a national crisis into the greatest municipal building spree in American history.', accent=AC),
      bg='When New Deal relief funds poured out after 1933, most cities lacked shovel-ready projects; Moses had <b>drawers full of finished plans</b>.',
      people='President <b>Roosevelt’s</b> federal agencies; Mayor LaGuardia; the WPA workers; the millions who used the new pools.',
      what='Moses harnessed <b>WPA and relief money</b> to build eleven monumental pools (opened summer 1936, seating 49,000 swimmers), hundreds of playgrounds and scores of parks — capturing a vast share of federal funds because he alone was ready to spend them.',
      crux='His genius for <b>preparation</b> let him convert a national crisis into the greatest public-works spree any American city had seen.',
      conseq='New Yorkers gained a vast recreational infrastructure — and Moses gained the reputation and momentum to build ever bigger.',
      matters='Opportunity favors the prepared — Moses’ readiness let him seize a moment of crisis to reshape a city.'),
]

# ==================================================================  PHASE 3 — THE GREAT BUILDER
PHASE_BUILDER = [
    E('bridges', '1936–1964', 'The bridge-builder — spanning the city', ['TRIUMPH'],
      'Using the authorities, Moses throws bridge after bridge across the city’s waterways — the Triborough in 1936, the Bronx-Whitestone and Throgs Neck, and in 1964 the Verrazzano-Narrows, then the longest suspension bridge on Earth — re-wiring the geography of New York and binding its boroughs to the automobile.',
      svg_row('Four decades of great spans', [
          {'n': 1, 'label': 'Triborough Bridge, 1936', 'sub': 'three spans linking three boroughs', 'color': '#3730a3'},
          {'n': 2, 'label': 'Whitestone & Throgs Neck', 'sub': '1939 and 1961, reaching the Bronx', 'color': '#a16207'},
          {'n': 3, 'label': 'Verrazzano-Narrows, 1964', 'sub': 'then the world’s longest suspension bridge', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He physically re-wired the map of New York — and each toll crossing fed the Authority that financed the next.', accent=AC),
      bg='Moses used his authorities to fling bridges and tunnels across the city’s waterways on an unprecedented scale.',
      people='his engineers (<b>Othmar Ammann</b> designed several great spans); the commuters who used them; the neighborhoods in their path.',
      what='Under Moses came the <b>Triborough (1936), Bronx-Whitestone (1939), Throgs Neck (1961)</b> and the record-setting <b>Verrazzano-Narrows (1964)</b> bridges, plus the Brooklyn-Battery and Queens-Midtown tunnels — reshaping how the whole region moved.',
      crux='He physically <b>re-wired the geography of New York</b>, binding its boroughs and suburbs to the automobile.',
      conseq='Each toll crossing also fed the Authority’s revenues, financing the next project in the endless cycle.',
      matters='Great infrastructure shapes a civilization for a century — Moses built more of it than anyone in American history.'),

    E('fairs', '1939–1966', 'Lincoln Center and the World’s Fairs — culture and spectacle', ['TRIUMPH', 'POLITICS'],
      'Moses reaches beyond roads into culture and spectacle: he turns the Flushing Meadows ash dump into the 1939 and 1964 World’s Fair sites, assembles Lincoln Center through slum clearance, and presides over the 1964 fair — which draws far fewer than his boasted 70 million and ends in deficit and scandal.',
      svg_stack('Beyond roads — culture and spectacle', [
          {'n': 1, 'label': '1939 World’s Fair, Flushing Meadows', 'sub': 'an ash dump remade into fairgrounds', 'color': '#166534'},
          {'n': 2, 'label': 'Lincoln Center rises', 'sub': 'the nation’s great arts complex, via clearance', 'color': '#3730a3'},
          {'n': 3, 'label': '1964 World’s Fair — president', 'sub': 'his grand finale, but a financial flop', 'color': '#a16207'},
      ], takeaway='The same clearance-and-build method that raised cultural monuments also erased the neighborhoods they replaced.', accent=AC),
      bg='Moses reached beyond infrastructure into culture and spectacle, wielding his renewal powers over the arts and great events.',
      people='the cultural institutions of <b>Lincoln Center</b>; the fair’s contractors; the international body (the BIE) whose rules he defied.',
      what='Moses turned the Flushing Meadows ash dump into the <b>1939 and 1964 World’s Fair</b> sites, helped assemble <b>Lincoln Center</b> through slum clearance, and presided over the 1964 fair — which drew far fewer than his projected 70 million and closed in deficit and scandal.',
      crux='The same <b>clearance-and-build method</b> that raised cultural monuments also erased the neighborhoods they replaced.',
      conseq='The 1964 fair’s failure dented his mystique and emboldened his growing ranks of critics.',
      matters='Even his cultural glories carried the shadow of his method — creation and demolition were two faces of the same act.'),

    E('tally', '1924–1968', 'The greatest builder in American history', ['TRIUMPH'],
      'By the end, the scale of what Moses built is without precedent: 658 playgrounds, 416 miles of parkways, 13 bridges, tunnels, some 2.5 million acres of state parks, Jones Beach, Lincoln Center, two World’s Fairs, dams and vast housing — a physical legacy no single American has ever matched.',
      svg_row('The sheer scale of what he built', [
          {'n': 1, 'label': '658 playgrounds · 416 mi parkways', 'sub': '13 bridges, tunnels, ~2.5M acres of parks', 'color': '#166534'},
          {'n': 2, 'label': 'Jones Beach to Lincoln Center', 'sub': 'beaches, pools, housing, dams, campuses', 'color': '#3730a3'},
          {'n': 3, 'label': 'Billions built in his day', 'sub': 'more construction than any person in US history', 'color': '#a16207'},
      ], edge_labels=['spanning', 'worth'], takeaway='No individual has ever shaped the physical form of a great city so completely — and none at such human cost.', accent=AC),
      bg='Over four decades Moses built on a scale without precedent for a single individual in American history.',
      people='the <b>millions</b> who used his works; the hundreds of thousands displaced by them; his army of engineers and lawyers.',
      what='By his fall Moses had built <b>658 playgrounds, 416 miles of parkways, 13 bridges</b>, tunnels, roughly <b>2.5 million acres</b> of state parks, Jones Beach, Lincoln Center, two World’s Fairs, dams and vast housing — a record no single American has matched.',
      crux='No individual has ever <b>shaped the physical form</b> of a great city and its region so completely.',
      conseq='This staggering record is inseparable from the human cost of achieving it.',
      matters='The measure of Moses is genuinely double — an unmatched builder whose achievement cannot be weighed apart from its victims.'),
]

# ==================================================================  PHASE 4 — THE BULLDOZER
PHASE_BULLDOZER = [
    E('slumclearance', '1946–1960', 'Slum clearance — the bulldozer and the exiled', ['TRAGEDY', 'POLITICS'],
      'After 1946 Moses gains federal urban-renewal power, and as construction coordinator and slum-clearance chairman he uses Title I to brand whole neighborhoods as “blight” — an almost unreviewable power — evicting an estimated 170,000 New Yorkers, disproportionately poor, Black and Puerto Rican, and replacing living streets with superblock towers-in-the-park.',
      svg_stack('Clearing the “slums,” clearing the people', [
          {'n': 1, 'label': 'Construction coordinator, 1946', 'sub': 'and chair of the Slum Clearance Committee', 'color': '#3730a3'},
          {'n': 2, 'label': 'Title I brands blocks “blight”', 'sub': 'a power to condemn that none could review', 'color': '#b91c1c'},
          {'n': 3, 'label': '~170,000 New Yorkers evicted', 'sub': 'towers-in-the-park replace living streets', 'color': '#78350f'},
      ], takeaway='He treated living communities as slums to be scraped away, prizing the clean superblock over the vitality of the street.', accent=AC),
      bg='After LaGuardia left in 1946, Moses gained federal urban-renewal powers under <b>Title I</b> of the housing programs.',
      people='the displaced — disproportionately poor, <b>Black and Puerto Rican</b> families; the developers he favored; Mayor <b>William O’Dwyer</b>.',
      what='As <b>construction coordinator (1946)</b> and slum-clearance chairman, Moses used Title I to condemn whole neighborhoods as <b>“blight”</b> — an almost unreviewable power — evicting an estimated <b>170,000 people</b> and replacing dense streets with superblock “towers-in-the-park.”',
      crux='He treated living communities as <b>“slums” to be scraped away</b>, prizing the clean superblock over the messy vitality of the street.',
      conseq='Tight-knit neighborhoods were shattered and their poorest residents scattered, often into worse conditions.',
      matters='Grand plans imposed from above can destroy the human fabric they claim to improve — the tragedy of top-down renewal.'),

    E('crossbronx', '1948–1963', 'The Cross-Bronx Expressway — a mile-wide wound', ['TRAGEDY', 'BATTLE'],
      'Moses rams the Cross-Bronx Expressway straight through the dense South Bronx, obliterating the settled community of East Tremont and evicting thousands — refusing an alternative route that would have spared it. It becomes the emblem of his method: a neighborhood is not a place to preserve but an obstacle to remove.',
      svg_stack('A highway driven through a living neighborhood', [
          {'n': 1, 'label': 'Cross-Bronx Expressway, 1948–63', 'sub': 'seven miles carved through the Bronx', 'color': '#b91c1c'},
          {'n': 2, 'label': 'East Tremont destroyed', 'sub': 'a stable community bulldozed for the road', 'color': '#78350f'},
          {'n': 3, 'label': 'Cars chosen over people', 'sub': 'a route that would have spared it refused', 'color': '#a16207'},
      ], takeaway='The expressway became the emblem of his method — a neighborhood was an obstacle to be removed, not a place to be preserved.', accent=AC),
      bg='Moses drove the <b>Cross-Bronx Expressway</b> straight through densely populated South Bronx neighborhoods.',
      people='the residents of <b>East Tremont</b> who fought and lost; the thousands of evicted tenants; <b>Robert Caro</b>, who chronicled their ordeal.',
      what='The <b>Cross-Bronx Expressway (built 1948–1963)</b> cut a seven-mile, mile-wide swath through the Bronx, obliterating the settled community of <b>East Tremont</b> and evicting thousands — Moses refusing an alternate route that would have spared it.',
      crux='It became the emblem of his method: a neighborhood was an <b>obstacle to be removed</b>, not a place to be preserved.',
      conseq='Historians link the expressway to the South Bronx’s later devastation and decades of decline.',
      matters='The most famous single act of the bulldozer — a monument to how highway-building could gut a living community.'),

    E('bias', '1929–1960s', 'Cars over transit — and the charge of bias', ['TRAGEDY', 'POLITICS'],
      'Moses builds overwhelmingly for the private car and against mass transit, omitting rail from his parkways and helping stall the subways — and Caro charges that low parkway overpasses kept buses, and thus poorer and often Black riders, away from his beaches, with biased pool siting and permits, though some scholars call the low-bridge story exaggerated.',
      svg_row('Building for the car, not the bus', [
          {'n': 1, 'label': 'Highways favored over transit', 'sub': 'no rail in his parkways; subways stalled', 'color': '#a16207'},
          {'n': 2, 'label': 'Low parkway overpasses', 'sub': 'Caro: too low for buses to reach the parks', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Allegations of racial bias', 'sub': 'pools, beaches and permits, says Caro', 'color': '#78350f'},
      ], edge_labels=['and', 'and'], takeaway='Whatever the intent, his car-centric design favored those who owned automobiles and shut out those who did not.', accent=AC),
      bg='Moses built overwhelmingly for the <b>private automobile</b> and against mass transit — and Caro alleged his designs carried a racial intent.',
      people='the car-less poor excluded from his parks; biographer <b>Robert Caro</b>; the scholars who dispute the “low bridges” claim.',
      what='Moses left <b>rail out of his parkways</b> and helped stall subway expansion; Caro charged that <b>low overpasses</b> kept buses — and poorer, often Black riders — away from beaches like Jones Beach, and cited biased pool siting and permit practices, though some scholars call the bridge story an exaggeration.',
      crux='Whatever the intent, his <b>car-centric design</b> systematically favored those who owned automobiles and disadvantaged those who did not.',
      conseq='The debate over how far racism drove his choices remains one of the most contested parts of his record.',
      matters='Infrastructure encodes who is included and excluded — Moses’ car-first city is the enduring case study in that truth.'),
]

# ==================================================================  PHASE 5 — THE FALL
PHASE_END = [
    E('jacobs', '1956–1964', 'The tide turns — mothers, Jane Jacobs, and defeat', ['BATTLE', 'TURNING POINT'],
      'The public that once revered Moses begins to fight back: Central Park mothers stop his parking lot in 1956, Jane Jacobs rallies Greenwich Village to save Washington Square and then defeats his Lower Manhattan Expressway — cracking the aura of inevitability and proving, at last, that the bulldozer can be stopped.',
      svg_stack('The public finally fights back', [
          {'n': 1, 'label': 'Central Park mothers, 1956', 'sub': 'block his lot at Tavern-on-the-Green', 'color': '#166534'},
          {'n': 2, 'label': 'Jane Jacobs rallies the Village', 'sub': 'saves Washington Square from his road', 'color': '#3730a3'},
          {'n': 3, 'label': 'Lower Manhattan Expressway killed', 'sub': 'his highway through SoHo defeated, 1964', 'color': '#b91c1c'},
      ], takeaway='Ordinary citizens cracked the aura of inevitability — the bulldozer, everyone learned, could finally be stopped.', accent=AC),
      bg='By the mid-1950s a public that had long revered Moses began to organize against him.',
      people='the <b>Central Park mothers</b>; <b>Jane Jacobs</b> and her Greenwich Village activists; the residents of SoHo and Little Italy.',
      what='A 1956 revolt by <b>Central Park mothers</b> over a Tavern-on-the-Green parking lot, then <b>Jane Jacobs’</b> fight to save Washington Square and defeat the <b>Lower Manhattan Expressway (rejected 1964)</b>, showed Moses could finally be beaten.',
      crux='The <b>aura of inevitability cracked</b> — ordinary citizens proved his bulldozer could be stopped.',
      conseq='Jacobs’ <b>The Death and Life of Great American Cities</b> recast Moses as the villain of a new urban philosophy.',
      matters='The birth of modern community resistance to top-down planning — the moment the citizen learned to fight the master builder.'),

    E('fall', '1968', 'The fall — Rockefeller strips his power', ['DEFEAT', 'TURNING POINT'],
      'Governor Nelson Rockefeller and Mayor Lindsay finally move on the un-fireable man, folding his Triborough Authority into the new MTA in 1968 to capture its toll billions for the failing subways — and lured by a promised senior role that never comes, Moses lets the merger pass and is reduced to a powerless consultant.',
      svg_row('The un-fireable man is finally removed', [
          {'n': 1, 'label': 'Rockefeller & Lindsay move, 1968', 'sub': 'to seize Triborough’s toll billions', 'color': '#3730a3'},
          {'n': 2, 'label': 'Triborough folded into the MTA', 'sub': 'his authority swallowed, 1 March 1968', 'color': '#a16207'},
          {'n': 3, 'label': 'Frozen out as a “consultant”', 'sub': 'the promised power never comes', 'color': '#b91c1c'},
      ], edge_labels=['so', 'then'], takeaway='The bond-covenant weapon that made him untouchable failed when the great bondholder declined to sue — and the empire ended.', accent=AC),
      bg='Governor <b>Nelson Rockefeller</b> and Mayor <b>John Lindsay</b> wanted Triborough’s toll surpluses to rescue the failing subways.',
      people='Governor <b>Nelson Rockefeller</b>; his brother <b>David</b> of Chase, the key bondholder; Mayor <b>John Lindsay</b>.',
      what='In 1968 Rockefeller engineered the merger of Moses’ <b>Triborough Authority into the new MTA</b>; lured by a promised senior role that never materialized, Moses did not push the bondholders’ potential suit — and was reduced to a powerless consultant.',
      crux='The very <b>bond-covenant weapon</b> that made him untouchable was neutralized when the great bondholder (David Rockefeller’s Chase) declined to sue.',
      conseq='At 79, after more than three decades of dominance, Moses was stripped of power at last.',
      matters='Even the most entrenched unelected power can fall — when a rival finally masters the machinery that protected it.'),

    E('legacy', '1974–1981', 'The Power Broker — builder or bulldozer?', ['DEATH', 'LEGACY'],
      'In 1974 Robert Caro’s The Power Broker recasts the once-heroic builder as a cautionary titan, and though Moses denounces it he never recovers his reputation before his death in 1981. His life stages a genuine, unresolved tension: the greatest builder in American history, and the man who bulldozed communities to build.',
      svg_compare('The two Robert Moses',
        {'head': 'The master builder', 'color': '#166534', 'items': ['Jones Beach, 658 playgrounds, 13 bridges', 'Lincoln Center and two World’s Fairs', 'beauty and recreation for millions']},
        {'head': 'The bulldozer', 'color': '#b91c1c', 'items': ['~170,000 people evicted from their homes', 'the Cross-Bronx Expressway’s mile-wide wound', 'cars over transit; the car-less shut out']},
        'Both are true at once — the greatest builder in American history, and the man who bulldozed communities to build it.',
        'Judge the whole record: the creation was monumental, and so was the destruction that came with it.', AC),
      bg='In 1974 <b>Robert Caro’s</b> Pulitzer-winning <b>The Power Broker</b> recast the once-heroic builder as a cautionary figure; Moses died in 1981.',
      people='<b>Robert Caro</b>, his biographer; the millions who use his works; the communities he displaced.',
      what='Caro’s <b>The Power Broker (1974)</b> indicted Moses’ methods and their human cost; Moses denounced it in a 23-page reply but never recovered his reputation. He died on <b>29 July 1981</b>, aged 92.',
      crux='His life stages a genuine, <b>unresolved tension</b> — monumental creation and monumental destruction bound together in one career.',
      conseq='Every debate since about power, cities, highways and displacement runs through Robert Moses.',
      matters='The ultimate study in the double edge of building — the same drive that raises a city’s greatest works can tear its communities apart.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Robert Moses was the “master builder” who remade New York across the twentieth century — and the ultimate study in unelected power. A defeated idealist who learned that ideals need force, he built himself an empire out of public authorities and toll revenue, financing an unmatched spree of parks, parkways, bridges, pools and cultural monuments. But the same drive bulldozed neighborhoods, displaced hundreds of thousands, and bent a whole city to the automobile. He is the enduring case study in <b>the double edge of building — creation and destruction, and how power escapes the ballot box.</b></p>
<div class="ov-quote">“Those who can, build. Those who can’t, criticize.”<span>— Robert Moses</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A defeated reformer learns that ideals need power → he masters the levers of the state under Al Smith and builds Jones Beach → turns the Triborough Authority and its tolls into power beyond any ballot → builds bridges, pools, playgrounds, Lincoln Center and two World’s Fairs on an unmatched scale → then bulldozes neighborhoods, evicts ~170,000, and drives the Cross-Bronx Expressway through the living Bronx → until Jane Jacobs and the public fight back and Rockefeller finally strips his power in 1968.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🏗️</div><h4>The master builder</h4><p>Built more of a great city than anyone in American history.</p></div>
  <div class="ov-card"><div class="i">🏦</div><h4>Power without a ballot</h4><p>Turned public authorities and toll bonds into unaccountable power.</p></div>
  <div class="ov-card"><div class="i">🚜</div><h4>The bulldozer</h4><p>Displaced hundreds of thousands in the name of “slum clearance.”</p></div>
  <div class="ov-card"><div class="i">🚗</div><h4>Cars over community</h4><p>Bent a city to the automobile, at the cost of its neighborhoods.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Idealist</b><small> 1888–1929</small><p>A reformer learns power; Jones Beach.</p></div>
  <div><b>2 · The Machine</b><small> 1934–1939</small><p>The Triborough Authority and toll power.</p></div>
  <div><b>3 · The Great Builder</b><small> 1936–1964</small><p>Bridges, fairs, and an unmatched scale.</p></div>
  <div><b>4 · The Bulldozer</b><small> 1946–1960s</small><p>Slum clearance and the Cross-Bronx.</p></div>
  <div><b>5 · The Fall</b><small> 1956–1981</small><p>Jacobs, Rockefeller, and The Power Broker.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Robert Caro', 'role': 'biographer', 'color': '#b91c1c',
     'bio': 'Author of the Pulitzer-winning The Power Broker (1974), which exposed how Moses amassed unelected power and recast him as a cautionary titan.',
     'rel': 'The chronicler who defined his reputation for posterity.'},
    {'name': 'Al Smith', 'role': 'patron', 'color': '#3730a3',
     'bio': 'The New York governor who took the young reformer into his circle and gave Moses his first great offices in the 1920s.',
     'rel': 'The mentor who launched his career and taught him practical power.'},
    {'name': 'Fiorello LaGuardia', 'role': 'mayor & ally', 'color': '#166534',
     'bio': 'The reform mayor who made Moses citywide Parks Commissioner in 1934 and partnered with him on the New Deal building spree.',
     'rel': 'The mayor who gave him command of the city’s parks.'},
    {'name': 'Jane Jacobs', 'role': 'nemesis', 'color': '#a16207',
     'bio': 'Urban activist and author whose Greenwich Village campaigns defeated the Lower Manhattan Expressway and whose ideas overturned his philosophy.',
     'rel': 'The activist who proved his bulldozer could be beaten.'},
    {'name': 'Nelson Rockefeller', 'role': 'the man who ended him', 'color': '#78350f',
     'bio': 'The New York governor who in 1968 folded Moses’ Triborough Authority into the MTA, finally stripping the un-fireable man of his power.',
     'rel': 'The rival who dismantled his empire at last.'},
]

KEY_EVENTS = [
    ('1888', 'Moses born', 'Wealth, Yale and Oxford; a Progressive idealist.'),
    ('1924', 'Long Island State Parks', 'First empire; drafts his own powers.'),
    ('1929', 'Jones Beach opens', 'A public masterpiece for the masses.'),
    ('1934', 'Parks Commissioner & Triborough', 'Elected office and toll power combined.'),
    ('1936', 'Pools and the Triborough Bridge', 'The New Deal building spree.'),
    ('1946', 'Construction coordinator', 'Title I slum-clearance power.'),
    ('1963', 'Cross-Bronx Expressway done', 'East Tremont bulldozed.'),
    ('1964', 'Verrazzano & the World’s Fair', 'The peak — and the flop.'),
    ('1968', 'Stripped of power', 'Rockefeller folds Triborough into the MTA.'),
    ('1974', 'The Power Broker', 'Caro recasts the builder as cautionary titan.'),
    ('1981', 'Death of Moses', 'Builder and bulldozer both.'),
]

MASTER = [
    {'year': '1888', 'age': 'born', 'phase': 'The Idealist', 'title': 'Born to wealth', 'desc': 'Yale, Oxford, a reformer.'},
    {'year': '1929', 'age': 'age 40', 'phase': 'The Idealist', 'title': 'Jones Beach', 'desc': 'A public masterpiece.'},
    {'year': '1934', 'age': 'age 45', 'phase': 'The Machine', 'title': 'Triborough Authority', 'desc': 'Power without a ballot.'},
    {'year': '1946', 'age': 'age 57', 'phase': 'The Bulldozer', 'title': 'Slum-clearance power', 'desc': 'Title I and the evictions.'},
    {'year': '1963', 'age': 'age 74', 'phase': 'The Bulldozer', 'title': 'Cross-Bronx Expressway', 'desc': 'A mile-wide wound.'},
    {'year': '1968', 'age': 'age 79', 'phase': 'The Fall', 'title': 'Stripped of power', 'desc': 'Rockefeller ends the empire.'},
]

SOURCES = [
    ('Britannica — Robert Moses', 'https://www.britannica.com/biography/Robert-Moses'),
    ('Wikipedia — Robert Moses', 'https://en.wikipedia.org/wiki/Robert_Moses'),
    ('Robert Caro — The Power Broker', 'https://www.robertcaro.com/the-books/the-power-broker/'),
    ('Wikipedia — The Power Broker', 'https://en.wikipedia.org/wiki/The_Power_Broker'),
    ('PBS American Experience — Robert Moses', 'https://www.pbs.org/wgbh/americanexperience/features/blackout-robert-moses/'),
]

def build_meta():
    return {
        'pid': 'gm-robertmoses.html', 'kind': 'man', 'emoji': '🏗️', 'accent': AC,
        'name': 'Robert Moses', 'years': '1888–1981', 'group': 'Business & Industry',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'New York’s unelected “master builder” — who turned public authorities and toll revenue into power beyond the ballot, built more of a great city than anyone in American history, and bulldozed its neighborhoods to do it.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Idealist', 'type': 'timeline',
             'intro': 'A high-minded reformer is crushed by Tammany and learns that ideals need power; allied with Al Smith he masters the state and builds Jones Beach.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · The Machine', 'type': 'timeline',
             'intro': 'He unifies the city’s parks, then turns the Triborough Bridge Authority and its toll revenue into a self-perpetuating power beyond any ballot.', 'events': PHASE_POWER},
            {'id': 'builder', 'label': '3 · The Great Builder', 'type': 'timeline',
             'intro': 'Using the authorities, Moses builds bridges, pools, playgrounds, Lincoln Center and two World’s Fairs — an unmatched physical legacy for a single American.', 'events': PHASE_BUILDER},
            {'id': 'bulldozer', 'label': '4 · The Bulldozer', 'type': 'timeline',
             'intro': 'The dark side: Title I “slum clearance” evicts ~170,000, the Cross-Bronx Expressway guts a living neighborhood, and the whole city is bent to the car.', 'events': PHASE_BULLDOZER},
            {'id': 'end', 'label': '5 · The Fall', 'type': 'timeline',
             'intro': 'The public and Jane Jacobs fight back, Rockefeller strips his power in 1968, and Caro’s The Power Broker seals the tension between builder and bulldozer.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Robert Caro’s The Power Broker is the key source, with standard encyclopaedic and documentary accounts; some disputed claims (e.g. the “low bridges”) are noted as contested.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
