# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Warren Buffett & Charlie Munger.
The partnership behind Berkshire Hathaway and the model of long-term rational investing."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#047857'  # Berkshire emerald

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING OF AN INVESTOR
PHASE_MAKING = [
    E('boyhood', '1930–1947', 'An Omaha boyhood and an early hustle', ['RISE', 'ORIGINS'],
      'Born in Omaha in the depths of the Depression, Warren Buffett is a numbers-obsessed boy who delivers newspapers, sells gum and Coca-Cola door to door, runs a pinball-machine business, buys his first stock at eleven and files his first tax return at thirteen — a compounding machine already whirring in his head.',
      svg_row('A boy who was born to compound', [
          {'n': 1, 'label': 'Born in Omaha, 1930', 'sub': 'son of stockbroker-congressman Howard Buffett', 'color': '#047857'},
          {'n': 2, 'label': 'A relentless young hustler', 'sub': 'paper routes, gum, Coke, pinball machines', 'color': '#a16207'},
          {'n': 3, 'label': 'Investor at eleven', 'sub': 'first stock at 11; first tax return at 13', 'color': '#3730a3'},
      ], edge_labels=['then', 'so'], takeaway='The obsession with money as numbers-that-grow was there from the start — Omaha made a compounding mind.', accent=AC),
      bg='<b>Warren Buffett</b> was born in Omaha, Nebraska, on 30 August 1930, son of the stockbroker and future congressman Howard Buffett, and grew up fascinated by numbers, odds and money.',
      people='his father <b>Howard Buffett</b>, a stockbroker and congressman; his boyhood business partners; the Omaha that shaped him.',
      what='As a boy Buffett ran a web of small enterprises — delivering the <b>Washington Post</b>, selling gum, Coca-Cola and magazines, and placing <b>pinball machines</b> in barbershops — bought his <b>first stock (Cities Service) at age 11</b>, and filed his <b>first tax return at 13</b>.',
      crux='He grasped early the magic of <b>compounding</b> — that money reinvested patiently grows on itself — and never let it go.',
      conseq='By his teens he had saved thousands and even bought a small Nebraska farm, hungry for the tools of serious investing.',
      matters='Great investors are often made young — Buffett’s lifelong edge was treating compounding as the central fact of finance.'),

    E('graham', '1949–1954', 'Studying under Benjamin Graham — value investing', ['RISE', 'IDEAS', 'TURNING POINT'],
      'Rejected by Harvard, Buffett finds his true teacher at Columbia — Benjamin Graham, father of value investing — who gives him a framework that will anchor his whole career: treat a stock as a piece of a business, exploit the moods of "Mr. Market", and always demand a "margin of safety".',
      svg_stack('The framework that anchored a career', [
          {'n': 1, 'label': 'Columbia, under Ben Graham', 'sub': 'the father of value investing, author of Security Analysis', 'color': '#3730a3'},
          {'n': 2, 'label': '“Mr. Market” and intrinsic value', 'sub': 'a stock is a piece of a business, not a ticker', 'color': '#047857'},
          {'n': 3, 'label': 'A “margin of safety”', 'sub': 'buy well below value; let price protect you', 'color': '#a16207'},
      ], takeaway='Graham handed Buffett a rational lens on markets — buy dollars for fifty cents, and let mood be your servant, not your master.', accent=AC),
      bg='Turned down by Harvard Business School, Buffett enrolled at <b>Columbia</b> to study under <b>Benjamin Graham</b> and David Dodd, authors of the value-investing bible <i>Security Analysis</i>.',
      people='<b>Benjamin Graham</b>, his mentor and the father of value investing; David Dodd; the classmates he outshone.',
      what='Graham taught Buffett to treat a share as <b>ownership of a business</b>, to see the market as an emotional “<b>Mr. Market</b>” whose swings create bargains, and to insist on a “<b>margin of safety</b>.” Buffett earned the only A+ Graham is said to have given.',
      crux='The heart of it was <b>rationality over emotion</b> — value is what a business is worth; price is merely what a moody market will pay.',
      conseq='Buffett worked briefly at Graham’s firm, Graham-Newman, absorbing the method before returning home to Omaha.',
      matters='A single great teacher can define a life’s work — Graham’s value discipline became the bedrock of Buffett’s entire philosophy.'),

    E('partnership', '1956–1969', 'The Buffett Partnership — proving the method', ['RISE', 'MONEY'],
      'Back in Omaha, Buffett launches an investment partnership with a handful of friends and family and a few thousand dollars, and over thirteen years compounds their money at roughly 30% a year — trouncing the market, quietly making his early backers rich, and building the reputation and capital that everything else will rest on.',
      svg_row('Compounding at extraordinary speed', [
          {'n': 1, 'label': 'Buffett Partnership Ltd, 1956', 'sub': 'starts in Omaha with family and friends’ money', 'color': '#047857'},
          {'n': 2, 'label': '~30% a year for 13 years', 'sub': 'buys undervalued “cigar-butt” bargains', 'color': '#a16207'},
          {'n': 3, 'label': 'Wound up rich, 1969', 'sub': 'beats the market by a mile; early backers enriched', 'color': '#3730a3'},
      ], edge_labels=['via', 'yields'], takeaway='He proved the method with his own investors’ money — a decade of market-beating returns that made his name.', accent=AC),
      bg='In 1956 Buffett returned to Omaha and founded <b>Buffett Partnership Ltd</b>, pooling money from relatives and friends to invest on Graham’s principles.',
      people='the early limited partners who trusted him; the undervalued companies he hunted; Graham’s method, now applied for profit.',
      what='Over 1956–1969 Buffett compounded the partnership at roughly <b>30% a year</b>, buying deeply undervalued “<b>cigar-butt</b>” stocks — cheap, unloved companies with one last “puff” of value left in them — and vastly outperforming the market.',
      crux='He turned Graham’s theory into a <b>track record</b>, showing that patient, unemotional value-buying could beat Wall Street decisively.',
      conseq='One of his partnership investments was a struggling textile maker called <b>Berkshire Hathaway</b> — soon to become his life’s vehicle.',
      matters='Reputation in investing is built on results — Buffett’s partnership years gave him the record and the capital for everything to come.'),
]

# ==================================================================  PHASE 2 — THE PARTNERSHIP FORMS
PHASE_PARTNERSHIP = [
    E('munger', '1924–1959', 'Charlie Munger — the other half of the mind', ['RISE', 'PEOPLE'],
      'Charlie Munger, born in Omaha six years before Buffett, takes a wholly different road — Harvard-trained lawyer, real-estate developer and voracious reader across every discipline — before running his own investment partnership, arriving at value investing on his own, and becoming the sharpest, most independent mind Buffett will ever meet.',
      svg_stack('A different road to the same destination', [
          {'n': 1, 'label': 'Omaha, 1924 — a lawyer’s path', 'sub': 'Harvard Law; founds Munger, Tolles & Olson', 'color': '#3730a3'},
          {'n': 2, 'label': 'A voracious multidisciplinary reader', 'sub': 'physics, biology, psychology, history — everything', 'color': '#a16207'},
          {'n': 3, 'label': 'His own investment partnership', 'sub': 'reaches value investing independently', 'color': '#047857'},
      ], takeaway='Munger came to the same truths by a different road — law, reading and reason — arriving as an equal, never a disciple.', accent=AC),
      bg='<b>Charlie Munger</b> was born in Omaha on 1 January 1924. As a boy he worked in a grocery owned by Buffett’s grandfather, then trained as a lawyer at <b>Harvard Law School</b>.',
      people='<b>Charlie Munger</b>, lawyer and investor; his law firm Munger, Tolles & Olson; the many thinkers he read across every field.',
      what='Before meeting Buffett, Munger built a career as a <b>Los Angeles lawyer and real-estate developer</b>, read obsessively across the sciences and humanities, and ran his own <b>investment partnership</b> — reaching value investing by his own path.',
      crux='Munger’s distinguishing trait was <b>multidisciplinary independence</b> — he thought from first principles, drawing on every field, and deferred to no one.',
      conseq='When he and Buffett finally met, each recognised in the other a rare intellectual equal.',
      matters='The best partnerships pair equals, not a leader and a follower — Munger arrived as a peer with a mind all his own.'),

    E('meeting', '1959', 'The meeting — two minds recognise each other', ['RISE', 'PARTNERSHIP', 'TURNING POINT'],
      'In 1959 a mutual friend introduces Buffett and Munger over dinner in Omaha, and the two hit it off instantly — finishing each other’s sentences, sharing the same rational cast of mind — beginning a friendship and partnership that will last more than sixty years and change how the world invests.',
      svg_row('The start of a sixty-year partnership', [
          {'n': 1, 'label': 'Introduced in Omaha, 1959', 'sub': 'a mutual friend sits them together at dinner', 'color': '#a16207'},
          {'n': 2, 'label': 'Instant intellectual rapport', 'sub': 'same rationality, same wit, endless talk', 'color': '#047857'},
          {'n': 3, 'label': 'A lifelong partnership begins', 'sub': '60+ years of thinking side by side', 'color': '#3730a3'},
      ], edge_labels=['sparks', 'into'], takeaway='One Omaha dinner in 1959 joined the two minds behind Berkshire — a meeting of equals that never dimmed.', accent=AC),
      bg='In 1959 mutual friends, the Davis family, arranged a dinner in Omaha for Buffett and the visiting Munger, expecting the two would get along.',
      people='<b>Warren Buffett</b> and <b>Charlie Munger</b>; the Davis family who introduced them; the decades of collaboration ahead.',
      what='The pair connected <b>instantly</b> — sharing a love of business, ideas and dry humour — and began a correspondence and friendship that grew into the <b>closest partnership in investing history</b>, spanning more than sixty years.',
      crux='Theirs was a meeting of <b>true intellectual equals</b> — Munger would push, challenge and sharpen Buffett rather than merely agree.',
      conseq='Munger slowly drew Buffett away from pure Graham bargain-hunting toward buying great businesses — and eventually joined Berkshire itself.',
      matters='The right partner multiplies a mind — Buffett and Munger became far more together than either could have been alone.'),

    E('berkshire', '1965', 'Taking over Berkshire Hathaway', ['MONEY', 'TURNING POINT'],
      'Buffett buys control of Berkshire Hathaway, a dying New England textile maker — a purchase he later calls his greatest mistake — but instead of trying to save the mills, he begins draining cash out of the failing business and redeploying it into insurance and stocks, turning a doomed textile firm into the shell of a vast holding company.',
      svg_stack('A dying mill becomes a holding company', [
          {'n': 1, 'label': 'Buys control of Berkshire, 1965', 'sub': 'a failing New England textile maker', 'color': '#78350f'},
          {'n': 2, 'label': 'Stops fighting a losing business', 'sub': 'redeploys the cash instead of saving the mills', 'color': '#a16207'},
          {'n': 3, 'label': 'A vehicle for compounding', 'sub': 'the shell of a future holding empire', 'color': '#047857'},
      ], takeaway='He turned a doomed textile mill into a machine for redeploying capital — the vehicle that would hold everything to come.', accent=AC),
      bg='<b>Berkshire Hathaway</b> was a struggling textile manufacturer. Buffett began buying its cheap shares in the early 1960s and <b>took control in 1965</b>.',
      people='the failing Berkshire textile mills; the managers Buffett kept and replaced; the insurance businesses he would soon buy.',
      what='Rather than pour money into the doomed textile operation, Buffett <b>extracted its cash and redeployed it</b> into insurance (National Indemnity, 1967) and stocks, gradually converting Berkshire into a <b>holding company</b> that owned other businesses.',
      crux='He treated Berkshire not as a textile firm to rescue but as a <b>capital-allocation vehicle</b> — a container into which he could pour better investments.',
      conseq='Berkshire became the permanent home for Buffett and Munger’s compounding, though Buffett called buying the textile business his costliest error.',
      matters='The genius was in the structure — a permanent holding company let them compound capital across decades without ever cashing out.'),
]

# ==================================================================  PHASE 3 — FROM CIGAR BUTTS TO WONDERFUL COMPANIES
PHASE_SHIFT = [
    E('sees', '1972', 'See’s Candies — the great conversion', ['MONEY', 'IDEAS', 'TURNING POINT'],
      'Pushed by Munger, Berkshire pays a rich price for See’s Candies — far more than Graham’s rules would allow — and the beloved California brand, with its power to raise prices year after year, teaches Buffett a career-changing lesson: a wonderful business with a durable brand is worth far more than a merely cheap one.',
      svg_compare('The lesson that changed everything',
          {'head': 'The old way — cigar butts', 'color': '#78350f', 'items': [
              'Buy cheap, mediocre businesses',
              'One last “puff” of value',
              'Sell when fairly priced',
              'A Graham bargain, nothing more']},
          {'head': 'The new way — See’s Candies', 'color': '#047857', 'items': [
              'Pay up for a wonderful business',
              'A beloved brand with pricing power',
              'Raise prices; hold forever',
              'Quality compounds over decades']},
          verdict='Munger’s insight: far better to buy a wonderful company at a fair price than a fair company at a wonderful price.',
          takeaway='See’s converted Buffett from bargain-hunter to buyer of quality — pricing power, not just cheapness, became the prize.', accent=AC),
      bg='In 1972 Berkshire, prompted by Munger, bought <b>See’s Candies</b>, a cherished California confectioner, for about $25 million — a premium to its book value that Graham’s rules would have forbidden.',
      people='<b>Charlie Munger</b>, who pushed to pay up for quality; <b>See’s Candies</b> and its loyal customers; the ghost of Graham’s cheapness rule.',
      what='See’s proved able to <b>raise prices year after year</b> without losing customers, throwing off far more cash than its price implied — teaching Buffett that a <b>durable brand and pricing power</b> are worth a premium.',
      crux='Munger shifted Buffett from cheap “<b>cigar-butt</b>” stocks to “<b>wonderful companies at fair prices</b>” — quality over mere bargain.',
      conseq='This conversion opened the door to Berkshire’s greatest investments — Coca-Cola, American Express, GEICO and later Apple.',
      matters='The single most important shift in Buffett’s method — from buying cheap to buying quality — came from Munger and a candy company.'),

    E('float', '1967–1996', 'The insurance float — the hidden engine', ['MONEY', 'IDEAS'],
      'The secret fuel of Berkshire is insurance "float" — the river of premiums an insurer holds before it must pay claims — which Buffett can invest for his own account, effectively borrowing billions at a negative cost, and pouring it into stocks and companies to supercharge the compounding.',
      svg_stack('Other people’s money, invested for free', [
          {'n': 1, 'label': 'Buy insurers — National Indemnity, GEICO', 'sub': '1967 onward; GEICO fully owned by 1996', 'color': '#3730a3'},
          {'n': 2, 'label': 'Hold the “float”', 'sub': 'premiums collected before claims are paid', 'color': '#047857'},
          {'n': 3, 'label': 'Invest it for Berkshire', 'sub': 'billions to compound at near-zero cost', 'color': '#a16207'},
      ], takeaway='Insurance let Berkshire invest other people’s money for years at almost no cost — the quiet engine behind the compounding.', accent=AC),
      bg='Buffett bought <b>National Indemnity in 1967</b> and steadily built Berkshire’s insurance arm, culminating in the full acquisition of <b>GEICO in 1996</b>, a company he had admired since his twenties.',
      people='the insurers <b>National Indemnity</b> and <b>GEICO</b>; the policyholders whose premiums became float; the businesses that float bought.',
      what='An insurer collects <b>premiums now</b> and pays claims later, holding a large pool of “<b>float</b>” in between. Buffett invested Berkshire’s float in stocks and whole companies, effectively <b>borrowing billions at negative cost</b> to compound.',
      crux='The engine was <b>leverage without the danger</b> — permanent, low-cost capital he could invest patiently rather than fickle borrowed money.',
      conseq='Insurance float funded decades of stock purchases and acquisitions, multiplying the power of every good investment decision.',
      matters='Behind the folksy image lay a brilliant financial engine — cheap, patient capital that let good investing compound into an empire.'),

    E('wonderful', '1988–2000s', 'Coca-Cola, American Express and the moat', ['MONEY', 'TRIUMPH'],
      'Armed with the new philosophy and a river of float, Buffett makes the defining bets of the Berkshire era — pouring billions into Coca-Cola, American Express and GEICO — great consumer brands with wide "moats" that he intends to hold, in his words, "forever", and that reward him with decades of dividends and gains.',
      svg_row('Buying moats and holding forever', [
          {'n': 1, 'label': 'Coca-Cola, from 1988', 'sub': 'a global brand bought after a market crash', 'color': '#b91c1c'},
          {'n': 2, 'label': 'American Express & GEICO', 'sub': 'brands rescued cheap; held for decades', 'color': '#3730a3'},
          {'n': 3, 'label': 'Hold “forever”', 'sub': 'wide moats compound tax-free while held', 'color': '#047857'},
      ], edge_labels=['plus', 'and'], takeaway='Great brands with wide moats, bought at fair prices and never sold — the strategy that defined Berkshire’s golden decades.', accent=AC),
      bg='By the late 1980s Buffett was hunting <b>dominant consumer brands</b> with durable competitive advantages — what he called economic “<b>moats</b>.”',
      people='<b>Coca-Cola</b>, <b>American Express</b> and <b>GEICO</b>; the millions of loyal customers behind their moats; Munger, endorsing the quality bets.',
      what='Berkshire bought a huge stake in <b>Coca-Cola from 1988</b>, had earlier scooped up <b>American Express</b> cheaply during the 1960s salad-oil scandal, and built out <b>GEICO</b> — all brands he intended to hold “<b>forever</b>,” letting them compound.',
      crux='He sought <b>wide-moat businesses</b> — companies protected by brand, habit and scale — and refused to sell them, letting gains build untaxed.',
      conseq='These holdings threw off billions in dividends and appreciation, becoming the core of Berkshire’s value for decades.',
      matters='Buy the best businesses and never sell — Buffett showed that patience with great companies beats endless trading.'),
]

# ==================================================================  PHASE 4 — THE COMPOUNDING MACHINE
PHASE_MACHINE = [
    E('models', '1980s–2000s', 'Munger’s mental models and “invert”', ['IDEAS', 'PHILOSOPHY'],
      'Charlie Munger becomes the philosopher of the partnership, preaching a "latticework of mental models" — borrowing the big ideas from every discipline, from physics to psychology — and the discipline of "invert, always invert": to solve a problem, first work out how to fail, then avoid it.',
      svg_stack('Worldly wisdom as a thinking system', [
          {'n': 1, 'label': 'A “latticework of mental models”', 'sub': 'borrow big ideas from every discipline', 'color': '#3730a3'},
          {'n': 2, 'label': 'Multidisciplinary “worldly wisdom”', 'sub': 'physics, biology, psychology, history', 'color': '#047857'},
          {'n': 3, 'label': '“Invert, always invert”', 'sub': 'study how to fail — then avoid it', 'color': '#a16207'},
      ], takeaway='Munger built thinking into a system — cross-disciplinary models plus inversion — that guarded them against folly and bias.', accent=AC),
      bg='Beyond stock-picking, <b>Munger</b> became the intellectual architect of their approach, later collected in <i>Poor Charlie’s Almanack</i> (2005).',
      people='<b>Charlie Munger</b>, its evangelist; the many thinkers he drew on; the biases and follies he catalogued.',
      what='Munger urged building a “<b>latticework of mental models</b>” — the key ideas from many fields — and applying <b>inversion</b> (“invert, always invert”): to succeed, first identify how you would fail, then avoid it. He dissected the “<b>psychology of human misjudgment</b>.”',
      crux='His method was <b>rationality as a discipline</b> — using cross-disciplinary models and inversion to defeat the biases that ruin most investors.',
      conseq='This mental toolkit guided every Berkshire decision and made Munger a revered teacher of clear thinking far beyond finance.',
      matters='Munger’s models turned investing into applied rationality — showing that avoiding stupidity beats chasing brilliance.'),

    E('apple', '2016–2020s', 'Apple and the ranks of the richest', ['MONEY', 'TRIUMPH'],
      'Long wary of technology, Buffett makes a late and enormous bet on Apple — reasoning that it is really a consumer-brand business with a fanatically loyal customer base — and it becomes Berkshire’s single largest and most profitable holding, cementing Buffett and Munger among the richest and most admired people alive.',
      svg_row('A late tech bet that paid enormously', [
          {'n': 1, 'label': 'Buys Apple from 2016', 'sub': 'treats it as a consumer brand, not a gadget maker', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Berkshire’s biggest holding', 'sub': 'a fanatically loyal customer base = a moat', 'color': '#3730a3'},
          {'n': 3, 'label': 'Among the world’s richest', 'sub': 'decades of compounding pay off', 'color': '#047857'},
      ], edge_labels=['becomes', 'and'], takeaway='Even a late, out-of-character bet fit the rule — a wide-moat brand — and became Berkshire’s most profitable investment ever.', accent=AC),
      bg='For most of his career Buffett avoided technology stocks as outside his “circle of competence,” but in <b>2016</b> Berkshire began buying <b>Apple</b>.',
      people='<b>Apple</b> and its loyal users; Buffett, reframing it as a consumer brand; the fortune the bet produced.',
      what='Buffett judged <b>Apple</b> not as a tech company but as a <b>consumer-products business</b> with an unrivalled brand and sticky customers. The stake grew into Berkshire’s <b>largest and most profitable holding</b>, worth well over $100 billion at its peak.',
      crux='Even his boldest late move obeyed the old rule — a <b>wide-moat brand</b> with pricing power and loyal customers, bought at a fair price.',
      conseq='Decades of compounding, crowned by Apple, left Buffett among the richest people alive and Berkshire worth close to a trillion dollars.',
      matters='Consistency of principle, not chasing fashion, built the fortune — Apple was the old philosophy applied to a new brand.'),

    E('woodstock', '1980s–present', 'Woodstock for Capitalists', ['LEGACY', 'CULTURE'],
      'The Berkshire annual meeting in Omaha swells into a cult event — "Woodstock for Capitalists" — drawing tens of thousands of shareholders to hear Buffett and Munger answer questions for hours with wit, candour and homespun wisdom, spreading their gospel of rational, patient investing to a devoted global following.',
      svg_stack('A gospel of rational investing goes public', [
          {'n': 1, 'label': 'The Berkshire annual meeting', 'sub': 'tens of thousands gather each May in Omaha', 'color': '#a16207'},
          {'n': 2, 'label': '“Woodstock for Capitalists”', 'sub': 'hours of candid, witty Q&A on stage', 'color': '#047857'},
          {'n': 3, 'label': 'A devoted global following', 'sub': 'the partnership’s philosophy spreads worldwide', 'color': '#3730a3'},
      ], takeaway='The double act on stage turned a shareholder meeting into a movement — patient, rational investing preached to the world.', accent=AC),
      bg='Berkshire’s <b>annual shareholder meeting</b> in Omaha grew from a small gathering into a vast pilgrimage nicknamed “<b>Woodstock for Capitalists</b>.”',
      people='the tens of thousands of shareholders; <b>Buffett and Munger</b> on stage; the investors worldwide who study their words.',
      what='Each spring, huge crowds fill an Omaha arena to watch Buffett and Munger field <b>hours of questions</b> with humour and candour — Buffett expansive, Munger sardonic — dispensing lessons on business, investing and life.',
      crux='The meeting made their <b>philosophy public property</b> — a folksy, rational counter-gospel to Wall Street’s churn and speculation.',
      conseq='Buffett’s annual letters and the meeting turned the pair into the most trusted teachers of long-term investing in the world.',
      matters='They became teachers as much as investors — spreading a durable philosophy of patience and rationality to millions.'),
]

# ==================================================================  PHASE 5 — LEGACY
PHASE_LEGACY = [
    E('giving', '2006–2010', 'The Giving Pledge — giving it all away', ['LEGACY', 'PHILANTHROPY'],
      'Having spent a lifetime accumulating, Buffett resolves to give nearly all of it away — pledging the bulk of his fortune to the Gates Foundation and family charities, and co-founding the Giving Pledge with Bill and Melinda Gates to persuade the world’s billionaires to donate the majority of their wealth.',
      svg_row('Compounding, then giving it away', [
          {'n': 1, 'label': 'Pledges his fortune, 2006', 'sub': 'most of it to the Gates Foundation over time', 'color': '#047857'},
          {'n': 2, 'label': 'The Giving Pledge, 2010', 'sub': 'co-founded with Bill and Melinda Gates', 'color': '#a16207'},
          {'n': 3, 'label': 'Billionaires urged to give', 'sub': 'promise away the majority of their wealth', 'color': '#3730a3'},
      ], edge_labels=['then', 'and'], takeaway='He built one of history’s great fortunes and vowed to give almost all of it away — compounding turned to philanthropy.', accent=AC),
      bg='Long a critic of dynastic wealth, Buffett decided his fortune should go to society rather than his heirs, beginning major gifts in <b>2006</b>.',
      people='<b>Bill and Melinda Gates</b> and their foundation; Buffett’s own children’s charities; the billionaires the pledge recruited.',
      what='Buffett pledged to give away <b>over 99% of his wealth</b>, directing most to the <b>Gates Foundation</b> and family charities, and in <b>2010</b> co-founded the <b>Giving Pledge</b> with Bill and Melinda Gates, asking the ultra-rich to donate the majority of their fortunes.',
      crux='He treated great wealth as a <b>social trust</b> to be returned, not a dynasty to be founded — rationality applied to giving as to earning.',
      conseq='The Giving Pledge drew commitments from hundreds of billionaires, and Buffett’s gifts became among the largest in history.',
      matters='The final act of the compounding story was to disperse it — Buffett made philanthropy, not inheritance, the point of the fortune.'),

    E('mungerdeath', '2023', 'The death of Charlie Munger at 99', ['LEGACY', 'DEATH'],
      'In November 2023, weeks short of his hundredth birthday, Charlie Munger dies — and Buffett, who had leaned on his partner’s judgment for over sixty years, declares that Berkshire Hathaway could not have been built to its present state without the man he called his partner and the "architect" of its philosophy.',
      svg_stack('The end of a sixty-four-year partnership', [
          {'n': 1, 'label': 'Munger dies, November 2023', 'sub': 'weeks short of his 100th birthday', 'color': '#78350f'},
          {'n': 2, 'label': '“The architect of Berkshire”', 'sub': 'Buffett’s tribute to his lifelong partner', 'color': '#3730a3'},
          {'n': 3, 'label': 'A partnership without equal', 'sub': '64 years of thinking side by side', 'color': '#047857'},
      ], takeaway='Munger’s death closed the longest and greatest partnership in investing — the mind that had shaped Berkshire from the start.', accent=AC),
      bg='<b>Charlie Munger</b> stayed sharp and active into his late nineties, serving as Berkshire’s vice chairman and a beloved sage of the annual meetings.',
      people='<b>Charlie Munger</b>, who died on 28 November 2023; <b>Warren Buffett</b>, his grieving partner; the millions who admired him.',
      what='Munger died at <b>99</b>, just weeks before turning 100. Buffett said Berkshire “could not have been built to its present status without <b>Charlie’s inspiration, wisdom and participation</b>,” crediting him as the architect of its philosophy.',
      crux='Their bond was a <b>true meeting of equals</b> across six decades — Munger the sharpener, Buffett the executor, neither complete alone.',
      conseq='Buffett, still leading Berkshire, named Greg Abel his successor, carrying the philosophy forward as his own retirement neared.',
      matters='The greatest partnership in business history rested on friendship and candour — proof that two rational minds outdo one.'),

    E('legacy', 'today', 'The model of long-term rational investing', ['LEGACY', 'INFLUENCE'],
      'Together Buffett and Munger stand as the definitive model of long-term, rational investing — buy wonderful businesses, hold them forever, let compounding and patience do the work, avoid folly and stay within your competence — and of partnership itself: two candid, disciplined minds who trusted each other for a lifetime.',
      svg_row('What the partnership stands for', [
          {'n': 1, 'label': 'Rational, patient investing', 'sub': 'value, moats, compounding, margin of safety', 'color': '#047857'},
          {'n': 2, 'label': 'Wonderful companies, held forever', 'sub': 'quality over cheapness; avoid folly', 'color': '#a16207'},
          {'n': 3, 'label': 'The power of partnership', 'sub': 'two candid, equal minds for a lifetime', 'color': '#3730a3'},
      ], edge_labels=['plus', 'and'], takeaway='Their legacy is a whole philosophy — rational, patient, quality-focused investing, carried by a partnership of equals.', accent=AC),
      bg='Over half a century, Buffett and Munger turned a failing textile mill into one of the most valuable companies on earth and became the world’s most studied investors.',
      people='<b>Buffett and Munger</b>; the generations of investors who follow them; Benjamin Graham, whose value ideas they carried forward and improved.',
      what='Their combined philosophy — <b>value, moats, compounding, margin of safety, staying within a circle of competence, and avoiding folly</b> — became the standard textbook of long-term investing, taught and imitated worldwide.',
      crux='They proved that <b>patience and rationality</b>, applied through a trusting partnership, beat cleverness, speed and speculation over the long run.',
      conseq='Berkshire’s decades of compounding and their shared wisdom made them the enduring model of both investing and partnership.',
      matters='Buffett and Munger are the archetype of the rational long-term investor — and of what two disciplined minds can build together.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Warren Buffett and Charlie Munger built the greatest partnership in the history of investing — and, from a dying textile mill called Berkshire Hathaway, one of the most valuable companies on earth. Buffett, the Omaha prodigy trained by Benjamin Graham, began as a hunter of cheap “cigar-butt” bargains; Munger, the multidisciplinary lawyer he met in 1959, converted him to buying <b>wonderful companies at fair prices</b> and holding them forever. Fuelled by insurance “float” and decades of patient compounding, they made themselves among the richest people alive, then pledged the fortune away. They are the definitive study in <b>rational long-term investing, the power of compounding, and partnership itself.</b></p>
<div class="ov-quote">“It’s far better to buy a wonderful company at a fair price than a fair company at a wonderful price.”<span>— Warren Buffett, on Munger’s influence</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">An Omaha boy obsessed with compounding studies value investing under Ben Graham → proves the method with the Buffett Partnership → meets Charlie Munger in 1959 and takes over Berkshire Hathaway → Munger converts him from cheap stocks to wonderful businesses like See’s Candies → insurance float and great brands (Coca-Cola, GEICO, Apple) supercharge decades of compounding → the pair become billionaire sages of “Woodstock for Capitalists” → and pledge their fortune away, until Munger’s death in 2023 closes a sixty-four-year partnership.</p>
<div class="ov-lbl">Why they still matter</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">📈</div><h4>The power of compounding</h4><p>Patient reinvestment over decades turned thousands into hundreds of billions.</p></div>
  <div class="ov-card"><div class="i">🏰</div><h4>Wonderful companies</h4><p>Buy wide-moat businesses at fair prices and hold them forever.</p></div>
  <div class="ov-card"><div class="i">🧠</div><h4>Rational thinking</h4><p>Mental models and “invert, always invert” to defeat bias and folly.</p></div>
  <div class="ov-card"><div class="i">🤝</div><h4>The power of partnership</h4><p>Two candid, equal minds who trusted each other for a lifetime.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Making of an Investor</b><small> 1930–1969</small><p>Omaha, Ben Graham, and the Buffett Partnership.</p></div>
  <div><b>2 · The Partnership Forms</b><small> 1924–1965</small><p>Munger, the 1959 meeting, and Berkshire.</p></div>
  <div><b>3 · Cigar Butts to Quality</b><small> 1972–2000s</small><p>See’s, float, and wonderful companies.</p></div>
  <div><b>4 · The Compounding Machine</b><small> 1980s–present</small><p>Mental models, Apple, and Woodstock for Capitalists.</p></div>
  <div><b>5 · Legacy</b><small> 2006–today</small><p>The Giving Pledge, Munger’s death, and the model.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Warren Buffett', 'role': 'the Oracle of Omaha', 'color': '#047857',
     'bio': 'The Omaha investor who studied under Ben Graham, took over Berkshire Hathaway in 1965, and compounded it into one of the world’s most valuable companies over sixty years.',
     'rel': 'The executor of the partnership — capital allocator and public face of Berkshire.'},
    {'name': 'Charlie Munger', 'role': 'the partner and sage', 'color': '#3730a3',
     'bio': 'The Harvard-trained lawyer and multidisciplinary thinker who became Berkshire’s vice chairman, converting Buffett from cheap stocks to wonderful businesses and preaching mental models until his death at 99 in 2023.',
     'rel': 'The intellectual architect and Buffett’s equal partner for sixty-four years.'},
    {'name': 'Benjamin Graham', 'role': 'the mentor', 'color': '#a16207',
     'bio': 'The father of value investing and author of Security Analysis and The Intelligent Investor, who taught Buffett at Columbia the ideas of Mr. Market and the margin of safety.',
     'rel': 'The teacher whose value discipline was the bedrock of Buffett’s method.'},
    {'name': 'Bill & Melinda Gates', 'role': 'philanthropic partners', 'color': '#166534',
     'bio': 'The founders of the Gates Foundation, to which Buffett pledged most of his fortune, and co-founders with him of the Giving Pledge in 2010.',
     'rel': 'The partners in giving the Berkshire fortune away.'},
    {'name': 'Greg Abel', 'role': 'the chosen successor', 'color': '#78350f',
     'bio': 'The Berkshire executive Buffett named as his successor to lead the company, entrusted with carrying the partnership’s philosophy forward.',
     'rel': 'The heir chosen to steward Berkshire after Buffett.'},
]

KEY_EVENTS = [
    ('1930', 'Buffett born in Omaha', 'A boy obsessed with numbers and compounding.'),
    ('1949–51', 'Studies under Ben Graham', 'Value investing at Columbia.'),
    ('1956', 'Buffett Partnership Ltd', 'Compounds at ~30% for thirteen years.'),
    ('1959', 'Meets Charlie Munger', 'The start of a sixty-year partnership.'),
    ('1965', 'Takes over Berkshire Hathaway', 'Turns a textile mill into a holding company.'),
    ('1972', 'Buys See’s Candies', 'Munger’s conversion to quality.'),
    ('1988', 'Buys Coca-Cola', 'Wide-moat brands held forever.'),
    ('2010', 'The Giving Pledge', 'Pledges the fortune away.'),
    ('2023', 'Munger dies at 99', 'The great partnership closes.'),
]

MASTER = [
    {'year': '1930', 'age': 'born', 'phase': 'Making of an Investor', 'title': 'Buffett born in Omaha', 'desc': 'A compounding mind from the start.'},
    {'year': '1949', 'age': 'age 19', 'phase': 'Making of an Investor', 'title': 'Studies under Graham', 'desc': 'Value investing at Columbia.'},
    {'year': '1959', 'age': 'age 29', 'phase': 'The Partnership Forms', 'title': 'Meets Munger', 'desc': 'Two minds recognise each other.'},
    {'year': '1965', 'age': 'age 34', 'phase': 'The Partnership Forms', 'title': 'Takes Berkshire', 'desc': 'A mill becomes a holding company.'},
    {'year': '1972', 'age': 'age 41', 'phase': 'Cigar Butts to Quality', 'title': 'See’s Candies', 'desc': 'The great conversion to quality.'},
    {'year': '1988', 'age': 'age 57', 'phase': 'Cigar Butts to Quality', 'title': 'Buys Coca-Cola', 'desc': 'Wide moats held forever.'},
    {'year': '2010', 'age': 'age 79', 'phase': 'The Compounding Machine', 'title': 'The Giving Pledge', 'desc': 'Vows to give it all away.'},
    {'year': '2023', 'age': 'Munger 99', 'phase': 'Legacy', 'title': 'Munger dies', 'desc': 'A sixty-four-year partnership ends.'},
]

SOURCES = [
    ('Britannica — Warren Buffett', 'https://www.britannica.com/money/Warren-Buffett'),
    ('Britannica — Berkshire Hathaway', 'https://www.britannica.com/money/Berkshire-Hathaway'),
    ('CNBC — Charlie Munger dies at 99', 'https://www.cnbc.com/2023/11/28/charlie-munger-investing-sage-and-warren-buffetts-confidant-dies.html'),
    ('Kiplinger — Timeline of Buffett & Berkshire', 'https://www.kiplinger.com/investing/a-timeline-of-warren-buffetts-life-and-berkshire-hathaway'),
    ('Wikipedia — Charlie Munger', 'https://en.wikipedia.org/wiki/Charlie_Munger'),
]

def build_meta():
    return {
        'pid': 'gm-buffettmunger.html', 'kind': 'man', 'emoji': '📈', 'accent': AC,
        'name': 'Warren Buffett & Charlie Munger', 'years': 'b. 1930 / 1924–2023', 'group': 'Modern Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The partnership behind Berkshire Hathaway — Buffett the Oracle of Omaha and Munger his lifelong partner, who turned a dying textile mill into an empire and became the model of rational, long-term investing.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'making', 'label': '1 · Making of an Investor', 'type': 'timeline',
             'intro': 'An Omaha boy obsessed with compounding studies value investing under Benjamin Graham, then proves the method with the Buffett Partnership — beating the market for thirteen years.', 'events': PHASE_MAKING},
            {'id': 'partnership', 'label': '2 · The Partnership Forms', 'type': 'timeline',
             'intro': 'Buffett meets Charlie Munger over an Omaha dinner in 1959 and takes over a failing textile maker, Berkshire Hathaway — turning it into the vehicle for a lifetime of compounding.', 'events': PHASE_PARTNERSHIP},
            {'id': 'shift', 'label': '3 · Cigar Butts to Quality', 'type': 'timeline',
             'intro': 'Prompted by Munger, Buffett shifts from cheap “cigar-butt” stocks to wonderful companies at fair prices — See’s Candies, Coca-Cola and GEICO — fuelled by the insurance float engine.', 'events': PHASE_SHIFT},
            {'id': 'machine', 'label': '4 · The Compounding Machine', 'type': 'timeline',
             'intro': 'Munger’s mental models and inversion sharpen every decision; a late bet on Apple crowns decades of compounding; and the pair become billionaire sages of “Woodstock for Capitalists.”', 'events': PHASE_MACHINE},
            {'id': 'legacy', 'label': '5 · Legacy', 'type': 'timeline',
             'intro': 'Buffett pledges his fortune away through the Giving Pledge; Munger dies at 99 in 2023, closing a sixty-four-year partnership; and together they endure as the model of rational long-term investing.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies, encyclopaedic sources and contemporary reporting; famous quips are attributed as such and capture the pair’s investing philosophy.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
