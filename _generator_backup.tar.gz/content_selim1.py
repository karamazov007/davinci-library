# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Selim I, the Grim (Yavuz)."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#713f12'  # dark bronze

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_abdication():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1512 · the son who took the throne from his living father</text>'
    boxes=[(40,'#713f12','Governor of Trabzon','a hard frontier prince, unlike his cautious father'),
           (270,'#b45309','Wins the Janissaries','the army backs the warlike son over peace'),
           (500,'#7f1d1d','Forces abdication','Bayezid II steps down; dies soon after')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Then he eliminated his brothers and nephews — securing the throne with total, cold finality.</text>'
    return _wrap(W, H, 'Seizing the throne — from his own father', _tk(b, W, H, 'He grasped that the army, not the old sultan, decided who ruled — and won it to his side first.'), '', AC)

def svg_chaldiran():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1514 · Chaldiran · why gunpowder beat the cavalry charge</text>'
    b += '<rect x="40" y="60" width="300" height="82" rx="12" fill="#fef3c7" stroke="#b45309" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#b45309">Safavid Qizilbash</text>'
    s1,_=_tspans(54,100,'fanatical, brave Shia cavalry under Shah Ismail — but almost no firearms',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="82" rx="12" fill="#f5ecd9" stroke="#713f12" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#713f12">Ottoman guns and muskets</text>'
    s2,_=_tspans(394,100,'chained cannon and Janissary matchlocks mow down the charging horsemen',10,'#713f12',600,12,44); b+=s2
    b += '<line x1="340" y1="101" x2="378" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Courage met firepower — and firepower won. Selim briefly took the Safavid capital, Tabriz.</text>'
    return _wrap(W, H, 'Chaldiran — firepower crushes the cavalry age', _tk(b, W, H, 'He proved again that disciplined gunpowder beats even the bravest traditional cavalry.'), '', AC)

def svg_caliphate():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1517 · what the conquest of Egypt made him</text>'
    rows=[('#166534','Guardian of the Holy Cities','Mecca and Medina submit; he is “Servant of the Two Sanctuaries”'),
          ('#713f12','Master of the Muslim heartland','Cairo, the Levant and the Hejaz added — the empire’s centre shifts'),
          ('#6b7280','Claim to the Caliphate','later tradition says the title passed to him — historically debated')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="42" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+21}" r="9" fill="{c}"/><text x="62" y="{y+25}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+18}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+34,s,9.3,'#5b6472',500,11,78); b+=ss
        y+=50
    return _wrap(W, H, 'From sultan to protector of Islam', _tk(b, W, H, 'By taking the holy cities he made the Ottoman sultan the foremost sovereign of the Sunni world.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE RUTHLESS RISE
PHASE_RISE = [
    E('birth', '1470–1512', 'The frontier prince who would not wait', ['RISE'],
      'Born a son of the peace-loving Bayezid II and hardened as governor of the tough Trabzon frontier, Selim watches his cautious father drift toward leaving the throne to a milder brother — and decides he will not allow it.',
      svg_stack('The making of the Grim', [
          {'n': 1, 'label': 'Son of Bayezid II', 'sub': 'a warlike prince under a peace-seeking sultan', 'color': '#713f12'},
          {'n': 2, 'label': 'Governor of Trabzon', 'sub': 'hardened fighting on the eastern frontier', 'color': '#b45309'},
          {'n': 3, 'label': 'Fears his brother’s peace', 'sub': 'rejects the drift toward accommodation with Persia', 'color': '#7f1d1d'},
      ], takeaway='He was the hard man of a soft reign — and refused to let the empire pass to a gentler heir.', accent=AC),
      bg='By the early 1500s the <b>Ottoman Empire</b> under the ageing, cautious <b>Bayezid II</b> faced a rising threat to its east: the militant new <b>Safavid</b> Shia state of <b>Shah Ismail</b>, whose preachers were turning Anatolia.',
      people='His father <b>Bayezid II</b>; his brothers <b>Ahmed</b> and <b>Korkut</b>, rivals for the succession; the <b>Janissaries</b>, whose loyalty would decide everything.',
      what='As governor of <b>Trabzon</b>, Selim grew into a fierce, disciplined soldier alarmed by the Safavid danger and by the likelihood that his brother <b>Ahmed</b> — favouring peace — would inherit.',
      crux='He judged that the empire needed a <b>warrior on the throne</b> to face the Safavids, and that his own survival depended on winning the succession by force rather than waiting to be sidelined or killed.',
      conseq='He moved against his own father, gambling everything on seizing power before his rivals could.',
      matters='In dynastic states, the succession is often decided by nerve and timing, not birth order. Selim had both in abundance.'),

    E('trabzon', '1487–1510', 'Prince of Trabzon — the frontier apprenticeship', ['RISE', 'BATTLE'],
      'As governor of the far northeastern city of Trabzon, the young Selim spends decades fighting Georgians and the rising Safavids on the empire’s most dangerous frontier — hardening into a warrior who despises his father’s cautious peace.',
      svg_stack('Where the “Grim” was forged', [
          {'n': 1, 'label': 'Governor of Trabzon', 'sub': 'a remote, war-torn frontier posting far from the capital', 'color': '#713f12'},
          {'n': 2, 'label': 'War on Georgia and the Safavids', 'sub': 'constant raiding builds his reputation and his army’s loyalty', 'color': '#b45309'},
          {'n': 3, 'label': 'Contempt for his father’s peace', 'sub': 'sees Bayezid II tolerate the Shia threat and seethes', 'color': '#b91c1c'},
      ], takeaway='The frontier made him — a fighting prince impatient with a throne he thought was going soft.', accent=AC),
      bg='Ottoman princes governed provinces as training for rule. Selim drew <b>Trabzon</b>, on the Black Sea near the Georgian and Persian frontiers — a hard, exposed command.',
      people='His father <b>Bayezid II</b>, whose caution he scorned; the <b>Safavids</b> under Shah Ismail, whose Shia revolution he watched spreading into Anatolia; the border troops who came to revere him.',
      what='For over two decades Selim <b>fought Georgians and Safavid partisans</b> from Trabzon, earning a name as a fierce, capable soldier while his father pursued a defensive, pious policy.',
      crux='The frontier taught him that the empire’s real enemy was the <b>Safavid Shia movement</b> — and that only force, not patience, would answer it.',
      conseq='His military reputation and army support became the base from which he would challenge his own father and brothers for the throne.',
      matters='Leaders are shaped by where they are seasoned — a frontier command breeds a very different ruler than a comfortable capital.'),

    E('crimea', '1510–1512', 'Raising an army in the Crimea', ['RISE', 'POLITICS'],
      'Denied the succession and ordered to a distant post, Selim instead bases himself among his Crimean Tatar in-laws, raises troops beyond his father’s reach, and marches on the capital — losing a first clash but refusing to yield.',
      svg_row('Building a power base outside reach', [
          {'n': 1, 'label': 'Sidelined for a softer brother', 'sub': 'Bayezid favours the peaceable Ahmed for the throne', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Bases in the Crimea', 'sub': 'shelters with his Tatar father-in-law, raises an army', 'color': '#713f12'},
          {'n': 3, 'label': 'Marches on Bayezid, 1511', 'sub': 'defeated in a first clash — but undeterred', 'color': '#b45309'},
      ], edge_labels=['so he', 'then'], takeaway='He refused to wait his turn, building independent force where his father could not touch it.', accent=AC),
      bg='Bayezid II leaned toward his gentler son <b>Ahmed</b> as heir. Selim, fearing exclusion — and death — resolved to force the issue rather than trust the succession.',
      people='His Crimean Tatar in-laws (his mother-in-law’s and wife’s kin) who sheltered and armed him; his father <b>Bayezid</b>; his brothers <b>Ahmed</b> and <b>Korkut</b>.',
      what='Selim withdrew to the <b>Crimea</b>, gathered an army among the Tatars, and marched into Ottoman Europe. He was <b>beaten in a first encounter with his father’s forces</b> in 1511 but escaped and kept manoeuvring.',
      crux='He grasped that the succession was a <b>contest of force</b>, not a matter of a father’s preference — and prepared accordingly.',
      conseq='Backed by the Janissaries, who wanted a warrior sultan, he soon forced Bayezid to abdicate in his favour.',
      matters='When a system will not give you power, some seize it by building strength where the system cannot reach.'),

    E('throne', '1512–1513', 'Taking the throne from a living father', ['POLITICS', 'TURNING POINT'],
      'Backed by the Janissaries, he forces his own father to abdicate — then methodically kills his brothers and their sons, leaving no rival alive. The empire has never seen a colder, more total seizure of power.',
      svg_abdication(),
      bg='Ottoman successions were open contests among a sultan’s sons. Whoever won the army and moved fastest took the throne — and usually killed the losers under the law of fratricide.',
      people='His father <b>Bayezid II</b>, forced out; his brothers <b>Ahmed</b> and <b>Korkut</b> and their sons, all eliminated; the <b>Janissaries</b> who backed Selim.',
      what='In <b>1512</b>, with Janissary support, Selim compelled <b>Bayezid II to abdicate</b> (the old sultan died shortly after). Selim then <b>defeated and executed his brothers and nephews</b>, removing every rival claimant.',
      crux='He applied the ruthless logic of Ottoman succession with unmatched thoroughness — <b>total elimination of rivals</b> — buying a rock-solid, uncontested throne at a terrible family cost.',
      conseq='In two years he was undisputed sultan, free to turn the whole force of the empire outward — first against the Safavids to his east.',
      matters='Ruthlessness, applied completely, can produce absolute security. Selim’s cold seizure gave him the free hand his conquests required.'),

    E('bayeziddeath', '1512', 'The old sultan dies on the road', ['POLITICS', 'DEATH', 'TRAGEDY'],
      'Forced to abdicate, the aged Bayezid II sets out for retirement in his birthplace — and dies within weeks, so conveniently that many whisper his warlike son had him poisoned to remove the last focus of loyalty to the old regime.',
      svg_stack('A convenient death', [
          {'n': 1, 'label': 'Bayezid abdicates, 1512', 'sub': 'the Janissaries force the peaceable sultan out', 'color': '#b45309'},
          {'n': 2, 'label': 'Sent to retire at Dimetoka', 'sub': 'the old man leaves the capital for his birthplace', 'color': '#713f12'},
          {'n': 3, 'label': 'Dead within weeks', 'sub': 'rumours of poison follow; a rival focus removed', 'color': '#b91c1c'},
      ], takeaway='Whether by nature or by poison, the father’s death erased the one legitimate figure Selim’s enemies could rally to.', accent=AC),
      bg='Having forced his father from the throne, Selim still faced brothers and their partisans. A living ex-sultan was a dangerous rallying point for opposition.',
      people='<b>Bayezid II</b>, the deposed and dying father; the Janissaries who had backed Selim; the courtiers who spread — and feared — the poisoning rumour.',
      what='Bayezid died on the journey to <b>Dimetoka</b> only weeks after abdicating. Contemporaries suspected <b>poisoning</b> on Selim’s orders, though it was never proven.',
      crux='Selim’s consolidation required <b>no surviving alternative</b> — and his father’s death, natural or not, served that need perfectly.',
      conseq='With his father gone, Selim turned his full attention to hunting down his brothers and their sons.',
      matters='Ruthless successions leave no rival standing — and the line between fortune and murder is deliberately left blurred.'),

    E('brothers', '1512–1513', 'The war of brothers', ['BATTLE', 'TRAGEDY', 'POLITICS'],
      'Seizing the throne is only the start; he must still destroy his brothers, who hold provinces and armies of their own. In a swift, merciless campaign he hunts down and eliminates Ahmed and Korkut and their sons, ensuring that not a single rival of the blood survives to challenge him.',
      svg_row('Eliminating every rival claimant', [
          {'n': 1, 'label': 'Brothers hold provinces', 'sub': 'Ahmed and Korkut have their own power bases', 'color': '#713f12'},
          {'n': 2, 'label': 'Swift civil war', 'sub': 'Selim defeats them in the field', 'color': '#b45309'},
          {'n': 3, 'label': 'All rivals killed', 'sub': 'brothers and nephews executed to the last', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He completed his seizure with total ruthlessness — leaving no brother or nephew alive to contest the throne.', accent=AC),
      bg='Even after forcing his father out, Selim faced his <b>brothers Ahmed and Korkut</b>, who commanded provinces and claimed the throne.',
      people='His brothers <b>Ahmed</b> and <b>Korkut</b>; their sons; the provincial forces that backed them.',
      what='In <b>1512–13</b> Selim waged a swift, ruthless <b>war against his brothers</b>, defeating and <b>executing Ahmed and Korkut and their sons</b>, extinguishing every rival line and securing an uncontested throne.',
      crux='He applied the logic of Ottoman succession with <b>absolute thoroughness</b> — no surviving rival meant no future civil war.',
      conseq='With the dynasty purged of rivals, Selim could turn the empire’s whole force outward against the Safavids.',
      matters='His reign began in fratricidal blood — the terrible price, under the Ottoman system, of a secure and united throne.'),
]

# ==================================================================  PHASE 2 — THE EAST: CHALDIRAN
PHASE_EAST = [
    E('fatwa', '1513–1514', 'Branding the enemy heretics — war as holy duty', ['POLITICS', 'TRAGEDY'],
      'Before marching east he prepares the ground ideologically: he obtains religious rulings declaring the Shia Safavids and their Qizilbash followers heretics, making war on them not just permissible but a sacred obligation — and casting his brutal crackdown at home as the defence of Sunni Islam.',
      svg_row('Turning a war into a religious duty', [
          {'n': 1, 'label': 'The Safavid threat', 'sub': 'Shia Safavid preaching spreads in Anatolia', 'color': '#713f12'},
          {'n': 2, 'label': 'Fatwas of heresy', 'sub': 'clerics declare the Qizilbash heretics', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Holy war justified', 'sub': 'the campaign framed as defence of Sunni Islam', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='He armed his war with religious sanction — turning a geopolitical rivalry into a holy duty.', accent=AC),
      bg='The <b>Safavid</b> challenge was religious as well as political; Selim answered it partly on religious grounds.',
      people='The Ottoman <b>ulama</b> who issued the rulings; the <b>Qizilbash</b> of Anatolia branded as heretics.',
      what='Selim secured <b>religious rulings (fatwas)</b> declaring the Shia Safavids and their <b>Qizilbash</b> followers heretics, making war against them a <b>sacred obligation</b> and lending his harsh Anatolian crackdown the sanction of defending Sunni orthodoxy.',
      crux='He <b>weaponised religious authority</b> to legitimise both his purge at home and his war abroad — ideology as an instrument of state.',
      conseq='The rulings deepened the Sunni-Shia divide and framed the Ottoman-Safavid rivalry in enduring sectarian terms.',
      matters='Selim helped harden a sectarian fault line still shaping the Middle East — religion enlisted as the banner of state conflict.'),

    E('letters', '1514', 'The war of letters with Shah Ismail', ['POLITICS'],
      'Before the armies meet, Selim and the Safavid Shah Ismail trade a furious correspondence — Selim heaping insults and religious contempt to goad the younger ruler into battle, while sending a woman’s dress to mock his manhood.',
      svg_row('Provocation as prelude to war', [
          {'n': 1, 'label': 'Selim’s insulting letters', 'sub': 'brands Ismail a heretic; demands he fight', 'color': '#713f12'},
          {'n': 2, 'label': 'Mockery of manhood', 'sub': 'reportedly sends a woman’s gown to taunt him', 'color': '#b45309'},
          {'n': 3, 'label': 'Ismail baited into battle', 'sub': 'pride draws the Safavid army onto Selim’s guns', 'color': '#b91c1c'},
      ], edge_labels=['plus', 'lures'], takeaway='He fought with words first — manipulating his enemy’s pride into meeting him where his firepower would win.', accent=AC),
      bg='<b>Shah Ismail</b>, the charismatic young Safavid, had swept Persia and drawn Anatolia’s Shia toward him. Selim needed to force a decisive battle on his own terms.',
      people='<b>Selim</b>, the older, colder ruler; <b>Ismail</b>, proud and hitherto undefeated; the qadis whose fatwas framed the war as righteous.',
      what='Selim sent a series of <b>contemptuous letters</b> — dismissing Ismail as an infidel and, by tradition, mocking his courage — deliberately goading him toward a set-piece confrontation.',
      crux='Psychological warfare set the stage: he manipulated Ismail’s <b>honour</b> to draw him into a battle against gunpowder Ismail could not win.',
      conseq='The stung shah marched to meet him at Chaldiran, exactly the pitched battle Selim’s artillery was built to fight.',
      matters='Wars are often won before the first shot — by choosing where and how the enemy will agree to fight.'),

    E('qizilbash', '1513–1514', 'The reckoning with the Safavids', ['POLITICS', 'TRAGEDY'],
      'Shah Ismail’s Shia revolution is seducing Ottoman Anatolia. Before marching east, Selim moves against the Qizilbash sympathisers at home — a brutal internal purge that fixes the Sunni-Shia fault line for centuries.',
      svg_row('Securing the home front before the war', [
          {'n': 1, 'label': 'Safavid preaching spreads', 'sub': 'Shah Ismail’s Shia message wins Anatolians', 'color': '#b45309'},
          {'n': 2, 'label': 'Selim purges the Qizilbash', 'sub': 'a harsh crackdown on Safavid sympathisers', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Marches east', 'sub': 'his rear secured, he invades Safavid Persia', 'color': '#713f12'},
      ], edge_labels=['so', 'then'], takeaway='He crushed the enemy within before facing the enemy abroad — and hardened a sectarian divide.', accent=AC),
      bg='The <b>Safavid</b> Shah <b>Ismail I</b> had built a militant Shia state and was spreading his faith among the <b>Qizilbash</b> — Turkmen followers inside Ottoman Anatolia — threatening Selim’s rear.',
      people='<b>Shah Ismail I</b>, the charismatic Safavid founder; the <b>Qizilbash</b> of Anatolia, caught between the two empires.',
      what='Selim regarded the Safavid movement as an existential ideological threat. He carried out a <b>severe crackdown on Qizilbash sympathisers</b> in Anatolia to secure his rear before launching his eastern campaign.',
      crux='He treated the war as <b>religious as well as territorial</b>: neutralising the internal Shia network first so it could not rise behind his army as he advanced into Persia.',
      conseq='With his home front cowed, Selim led his army east — and the Ottoman-Safavid, Sunni-Shia rivalry became a defining, lasting fault line of the Middle East.',
      matters='Great external wars are often preceded by hard internal ones. The Sunni-Shia geopolitics Selim helped set still shape the region today.'),

    E('chaldiran', '1514', 'Chaldiran — firepower against fanaticism', ['BATTLE', 'TRIUMPH'],
      'He meets Shah Ismail at Chaldiran and answers the Safavids’ fearless cavalry with massed cannon and Janissary muskets. The charge is shattered; Selim takes the Safavid capital, Tabriz, and proves gunpowder rules the age.',
      svg_chaldiran(),
      bg='In <b>1514</b> Selim marched deep into Safavid territory to force a decisive battle with <b>Shah Ismail</b>, whose army was built around superb but firearm-poor <b>Qizilbash cavalry</b>.',
      people='<b>Shah Ismail I</b>, who believed in the invincibility of his holy warriors; the Ottoman <b>Janissaries</b> and artillery corps.',
      what='At the <b>Battle of Chaldiran (1514)</b>, Selim’s <b>cannon and matchlock-armed Janissaries</b>, protected behind chained wagons, tore apart the charging Safavid cavalry. He won decisively and briefly occupied <b>Tabriz</b>.',
      crux='He exploited a <b>technological gap</b>: the Safavids scorned firearms as unmanly, while Selim built his army around them — and disciplined firepower destroyed even the bravest cavalry.',
      conseq='Safavid expansion westward was checked and Shah Ismail’s aura of invincibility broken; the eastern frontier stabilised in Ottoman favour.',
      matters='Ideology and courage are no match for superior technology used with discipline. Chaldiran is a textbook of the gunpowder revolution.'),

    E('kurdistan', '1514–1515', 'Winning the east by war and by diplomacy', ['REFORM', 'POLITICS'],
      'Rather than try to garrison the wild mountains of eastern Anatolia, he wins them cleverly — letting the scholar Idris of Bitlis rally the region’s Kurdish lords to the Ottoman side against the Safavids, and annexing the buffer principality of Dulkadir, securing his whole eastern frontier before turning south.',
      svg_row('Securing the eastern frontier smartly', [
          {'n': 1, 'label': 'Win over the Kurdish lords', 'sub': 'Idris of Bitlis rallies them against Persia', 'color': '#713f12'},
          {'n': 2, 'label': 'Annex Dulkadir', 'sub': 'absorbs the buffer principality in the southeast', 'color': '#b45309'},
          {'n': 3, 'label': 'A secured rear', 'sub': 'the east is safe before he strikes the Mamluks', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He held the hard eastern country not by garrisons but by alliance — buying loyalty against a shared Safavid enemy.', accent=AC),
      bg='After Chaldiran, the rugged Kurdish lands of eastern Anatolia sat between the Ottoman and Safavid empires, a hard region to hold by force.',
      people='The scholar-diplomat <b>Idris of Bitlis</b>, who won over the Kurdish emirs; the ruler of the buffer state of <b>Dulkadir</b>.',
      what='Selim consolidated the east largely by <b>diplomacy</b> — using <b>Idris of Bitlis</b> to bring the region’s <b>Kurdish emirates</b> voluntarily under Ottoman suzerainty against the Shia Safavids — and by annexing the principality of <b>Dulkadir (1515)</b>, securing his frontier.',
      crux='He grasped that in difficult terrain, <b>alliance and shared enmity are cheaper and firmer than conquest</b> — winning loyal buffer lords rather than garrisoning mountains.',
      conseq='With his eastern rear secured, Selim could commit his whole army to the great southern campaign against the Mamluks.',
      matters='The best conquerors know when not to conquer. Selim held the east by making its lords partners against a common foe.'),

    E('tabriz', '1514', 'Tabriz taken — and the mutiny that forced him home', ['BATTLE', 'DEFEAT'],
      'After Chaldiran he enters the Safavid capital Tabriz in triumph and carries off its finest artisans to Istanbul — but his exhausted Janissaries refuse to winter deep in hostile Persia and effectively mutiny, forcing even the fearsome Selim to abandon the occupation and turn back, a reminder that his own soldiers had limits he could not simply command away.',
      svg_row('Triumph checked by his own troops', [
          {'n': 1, 'label': 'Enters Tabriz', 'sub': 'occupies the Safavid capital after Chaldiran', 'color': '#713f12'},
          {'n': 2, 'label': 'Deports the artisans', 'sub': 'sends craftsmen and treasure to Istanbul', 'color': '#b45309'},
          {'n': 3, 'label': 'The Janissaries balk', 'sub': 'they refuse to winter in Persia; he must retreat', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='Even “the Grim” bowed to his soldiers’ limits — the Janissaries’ refusal forced him out of Persia.', accent=AC),
      bg='After the victory at Chaldiran, Selim occupied the Safavid capital <b>Tabriz</b>, but faced the practical limits of campaigning deep in enemy territory.',
      people='The artisans and scholars of Tabriz, deported to Istanbul; the <b>Janissaries</b>, who resisted a Persian winter.',
      what='Selim entered <b>Tabriz</b>, seized its wealth and sent its <b>finest craftsmen to Istanbul</b> — but his <b>Janissaries refused to winter</b> so far into hostile Persia, effectively mutinying and forcing Selim to <b>abandon the occupation</b> and withdraw.',
      crux='It exposed the <b>limits even a feared sultan faced</b>: the loyalty of the Janissaries was powerful but conditional, and logistics constrained conquest.',
      conseq='Selim held gains in eastern Anatolia but could not keep Tabriz; the Safavid state survived to remain a lasting rival.',
      matters='Power has limits even for the ruthless. Selim’s retreat from Tabriz shows that armies, and their willingness, bound even him.'),
]

# ==================================================================  PHASE 3 — THE SOUTH: THE MAMLUKS
PHASE_SOUTH = [
    E('dulkadir', '1515', 'Swallowing Dulkadir — and provoking Egypt', ['BATTLE', 'POLITICS', 'TURNING POINT'],
      'Selim annexes the buffer principality of Dulkadir between his empire and the Mamluks, sending the head of its ruler to Cairo — a deliberate insult that turns the old, uneasy peace with the Mamluk Sultanate into open war.',
      svg_row('Removing the buffer, picking the fight', [
          {'n': 1, 'label': 'Dulkadir annexed, 1515', 'sub': 'the buffer beylik between Ottomans and Mamluks seized', 'color': '#713f12'},
          {'n': 2, 'label': 'A severed head to Cairo', 'sub': 'the defeated ruler’s head sent as a calculated affront', 'color': '#b91c1c'},
          {'n': 3, 'label': 'War with the Mamluks', 'sub': 'the ancient rival is provoked into a fatal conflict', 'color': '#b45309'},
      ], edge_labels=['then', 'triggers'], takeaway='He eliminated the cushion between two empires precisely so the collision he wanted could happen.', accent=AC),
      bg='<b>Dulkadir</b> was a small principality buffering the Ottomans and the <b>Mamluk Sultanate</b> of Egypt and Syria — a rival power Selim now meant to destroy.',
      people='The <b>Dulkadirid</b> ruler (a Mamluk client) whom Selim crushed; the <b>Mamluk sultan Qansuh al-Ghawri</b>, alarmed by Ottoman expansion; Selim’s gunpowder army.',
      what='In 1515 Selim <b>conquered Dulkadir</b> and reportedly sent its ruler’s head to Cairo — a provocation that, with the Mamluks’ ties to the Safavids, opened the road to the Syrian and Egyptian campaigns.',
      crux='He engineered the <b>casus belli</b>: absorbing the buffer state both removed a threat and forced the war he intended to fight.',
      conseq='Within a year he marched south, destroying the Mamluk army at Marj Dabiq and beginning the conquest of the Arab heartlands.',
      matters='Aggressors often manufacture the pretext — removing the buffer that keeps the peace is itself an act of war.'),

    E('marjdabiq', '1516', 'Marj Dabiq — the old order falls', ['BATTLE', 'TRIUMPH'],
      'Turning south against the ancient Mamluk Sultanate of Egypt and Syria, he crushes their famed heavy cavalry at Marj Dabiq with the same firearms — and the Mamluk sultan dies on the field.',
      svg_row('The Mamluk world overturned', [
          {'n': 1, 'label': 'War with the Mamluks', 'sub': 'the old power ruling Syria, Egypt and the Hejaz', 'color': '#713f12'},
          {'n': 2, 'label': 'Marj Dabiq, 1516', 'sub': 'Ottoman guns break the Mamluk cavalry near Aleppo', 'color': '#b45309'},
          {'n': 3, 'label': 'Sultan al-Ghawri dies', 'sub': 'Syria falls open to Selim’s advance', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='The same firepower that beat the Safavids now toppled the greatest Muslim power of the age.', accent=AC),
      bg='The <b>Mamluk Sultanate</b> — a warrior-slave aristocracy famed for its cavalry — had ruled <b>Egypt, Syria and the holy cities</b> for centuries, but still relied on traditional cavalry and disdained firearms.',
      people='The Mamluk Sultan <b>Qansuh al-Ghawri</b>, who died at the battle; the elite Mamluk horsemen.',
      what='At <b>Marj Dabiq</b> (near Aleppo) in <b>1516</b>, Selim’s <b>artillery and musketry</b> shattered the Mamluk army; <b>Sultan al-Ghawri was killed</b>, and Syria fell to the Ottomans.',
      crux='Once again <b>gunpowder beat cavalry</b>: the Mamluks’ magnificent horsemen, like the Qizilbash, could not close with an enemy hidden behind cannon and matchlocks.',
      conseq='Syria was conquered; the road to <b>Egypt</b> — the richest prize in the Muslim world — lay open before him.',
      matters='Empires that refuse to modernise their armies fall to those that do. The Mamluks’ contempt for firearms cost them everything.'),

    E('khairbey', '1516', 'Won by treachery — the governor who switched sides', ['BATTLE', 'POLITICS'],
      'Selim’s stunning victory at Marj Dabiq is sealed not only by his guns but by treason: the Mamluk governor of Aleppo, secretly bought by Selim, deserts in mid-battle — a betrayal rewarded when Selim later makes him the Ottoman governor of Egypt.',
      svg_stack('Buying the enemy from within', [
          {'n': 1, 'label': 'Secret dealings before battle', 'sub': 'Selim suborns Mamluk commanders, chiefly Khair Bey', 'color': '#713f12'},
          {'n': 2, 'label': 'Defection at Marj Dabiq', 'sub': 'Khair Bey’s wing breaks; the Mamluk army collapses', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Rewarded with Egypt', 'sub': 'the traitor is made Ottoman governor of Cairo', 'color': '#b45309'},
      ], takeaway='He won as much by corrupting the enemy’s captains as by out-fighting them — treachery bought cheaply, paid richly.', accent=AC),
      bg='The <b>Mamluk</b> cavalry was among the finest in the world, but the sultanate was riddled with rivalries. Selim exploited them before a shot was fired.',
      people='<b>Khair Bey</b>, the Mamluk governor of Aleppo who betrayed his sultan; <b>Qansuh al-Ghawri</b>, who died in the rout; the disillusioned Mamluk emirs.',
      what='At <b>Marj Dabiq (1516)</b>, Ottoman firepower was decisive — but <b>Khair Bey’s treasonous defection</b> shattered the Mamluk line. Selim later installed him as <b>governor of Egypt</b> as his reward.',
      crux='He understood that a proud, brittle enemy could be <b>broken from inside</b> — subversion multiplying the effect of his guns.',
      conseq='The victory opened Syria; Khair Bey’s reward set the pattern of ruling Egypt through a co-opted Mamluk elite for centuries.',
      matters='The cheapest victory is the one arranged before the battle — an enemy divided against itself is half beaten already.'),

    E('ridaniya', '1517', 'The conquest of Egypt', ['BATTLE', 'TRIUMPH'],
      'He crosses the Sinai and destroys the last Mamluk army at Ridaniya outside Cairo. Egypt — the granary and treasure-house of the Muslim world — becomes Ottoman, and the empire’s centre of gravity shifts south.',
      svg_row('Taking the richest land in the Muslim world', [
          {'n': 1, 'label': 'Crosses the Sinai', 'sub': 'a hard desert march to reach Egypt', 'color': '#713f12'},
          {'n': 2, 'label': 'Ridaniya, 1517', 'sub': 'the last Mamluk army destroyed near Cairo', 'color': '#b45309'},
          {'n': 3, 'label': 'Egypt annexed', 'sub': 'the granary and treasury of Islam is his', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='In under a year he swallowed Syria and Egypt, doubling the empire’s wealth and reach.', accent=AC),
      bg='After Syria, only <b>Egypt</b> remained of the Mamluk state — the wealthiest region of the Islamic world, controlling grain, trade and the routes to the holy cities.',
      people='The last effective Mamluk sultan <b>Tuman bay II</b>, who resisted and was later executed; the people of <b>Cairo</b>.',
      what='In <b>1517</b> Selim crossed the <b>Sinai</b>, defeated the remaining Mamluks at <b>Ridaniya (Raydaniya)</b> outside Cairo, took the city and ended the Mamluk Sultanate, annexing <b>Egypt</b>.',
      crux='He completed the conquest of the entire <b>Mamluk realm</b> in a single lightning campaign, seizing the economic and religious heart of the Muslim world.',
      conseq='The Ottoman Empire now ruled Egypt, Syria and the Levant; its wealth and prestige soared, funding the golden age of his son Suleiman.',
      matters='One decisive campaign can reshape a civilisation. Selim turned the Ottomans from a Balkan-Anatolian power into the master of the Middle East.'),
]

# ==================================================================  PHASE 4 — GUARDIAN OF ISLAM
PHASE_ISLAM = [
    E('tumanbay', '1517', 'The last Mamluk sultan — resistance and the noose', ['BATTLE', 'TRAGEDY'],
      'After Cairo falls, the last Mamluk sultan Tuman Bay fights on as a guerrilla in the streets and countryside — until, betrayed and captured, he is hanged at the gate of Cairo, the final act in the death of a 300-year sultanate.',
      svg_stack('The end of the Mamluk Sultanate', [
          {'n': 1, 'label': 'Ridaniya lost, Cairo taken', 'sub': 'Ottoman guns break the last Mamluk field army, 1517', 'color': '#713f12'},
          {'n': 2, 'label': 'Tuman Bay fights on', 'sub': 'street fighting and guerrilla resistance around Cairo', 'color': '#b45309'},
          {'n': 3, 'label': 'Betrayed, captured, hanged', 'sub': 'executed at the Bab Zuwayla gate — the sultanate ends', 'color': '#b91c1c'},
      ], takeaway='He extinguished a 300-year dynasty completely — the last sultan swinging from the city gate.', accent=AC),
      bg='After the Mamluk defeats at Marj Dabiq and Ridaniya, the newly-raised sultan <b>Tuman Bay</b> refused to surrender Egypt without a desperate fight.',
      people='<b>Tuman Bay</b>, the brave last Mamluk sultan; the bedouin and citizens who sheltered then betrayed him; Selim, who is said to have regretted the execution.',
      what='Tuman Bay waged fierce <b>urban and guerrilla resistance</b> in and around Cairo before being betrayed and taken. Selim had him <b>hanged at the Bab Zuwayla</b>, ending the Mamluk Sultanate for good.',
      crux='Total conquest meant <b>obliterating the old sovereignty</b> — not just defeating it but publicly extinguishing its last claimant.',
      conseq='Egypt became an Ottoman province; its wealth and the guardianship of the holy cities passed to Selim.',
      matters='Conquest is not complete until the old order’s last champion is gone — and seen to be gone.'),

    E('holy', '1517', 'Servant of the Two Holy Cities', ['REFORM', 'TURNING POINT'],
      'With Egypt his, the guardianship of Mecca and Medina passes to the Ottoman sultan, and later tradition holds that the Caliphate itself came to him. In eight years he has tripled the empire and made its ruler the foremost sovereign of Sunni Islam.',
      svg_caliphate(),
      bg='Control of Egypt and the Hejaz meant guardianship of <b>Mecca and Medina</b> — the holiest cities of Islam — and a claim to leadership of the whole Sunni Muslim world.',
      people='The <b>Sharif of Mecca</b>, who submitted to Selim; the last Abbasid caliph in Cairo, <b>al-Mutawakkil III</b>, around whom the later caliphate-transfer story grew.',
      what='After conquering Egypt, Selim received the submission of the <b>Sharif of Mecca</b> and became protector of the <b>holy cities</b>, styled <b>“Servant of the Two Sanctuaries.”</b> A later, historically debated tradition says the <b>Caliphate</b> was formally transferred to him from the last Abbasid caliph.',
      crux='He shifted the empire’s <b>religious and moral centre of gravity</b>: the Ottoman sultan was now the paramount defender of Sunni Islam and custodian of its holiest sites.',
      conseq='In just eight years (1512–20) Selim had roughly <b>tripled the empire’s territory</b> and immensely enriched it — the springboard for Suleiman’s golden age.',
      matters='Legitimacy is as powerful as land. By taking the holy cities, Selim gave the Ottoman throne a religious authority that lasted until 1924.'),

    E('wealth', '1517–1520', 'How Egypt remade the empire', ['REFORM', 'TRIUMPH'],
      'The conquest is not just territory but treasure: Egypt’s vast grain and tax revenues, the trade of the Red Sea and the Levant, and the transfer of Cairo’s artisans and sacred relics to Istanbul transform the Ottoman state into the richest power of the Muslim world almost overnight.',
      svg_stack('The empire’s centre of gravity shifts south', [
          {'n': 1, 'label': 'Egypt’s wealth flows in', 'sub': 'grain, taxes and the trade of the Red Sea', 'color': '#713f12'},
          {'n': 2, 'label': 'Relics and prestige', 'sub': 'sacred relics and the caliphal aura move to Istanbul', 'color': '#b45309'},
          {'n': 3, 'label': 'A new superpower economy', 'sub': 'the treasury that will fund Suleiman’s golden age', 'color': '#166534'},
      ], takeaway='He didn’t just add land — he captured the economic and religious heart of the Muslim world.', accent=AC),
      bg='The conquest of the Mamluk realm gave the Ottomans not only Syria and Egypt but the <b>trade routes and revenues</b> of the richest region of the Islamic world.',
      people='The Cairo artisans and administrators absorbed into the empire; the merchants of the <b>Red Sea and Levant</b> trade.',
      what='Egypt’s enormous <b>grain and tax revenues</b>, the <b>Red Sea and Levantine trade</b>, and the transfer of sacred relics and skilled craftsmen to Istanbul <b>transformed the Ottoman economy and prestige</b>, filling the treasury that Suleiman would spend on war and splendour.',
      crux='He understood conquest as <b>economic as much as military</b>: seizing the Muslim world’s wealthiest region reshaped the empire’s finances and gravity for a century.',
      conseq='The Ottoman state entered its golden age flush with the wealth and legitimacy Selim’s conquests had won.',
      matters='The deepest fruit of Selim’s eight years was economic: he made the empire rich enough to be magnificent.'),

    E('relics', '1517', 'The sacred relics come to Istanbul', ['REFORM', 'TURNING POINT'],
      'With Egypt and the Hejaz won, Selim gathers the most sacred objects of Islam — the Prophet’s mantle, banner, sword and other relics — and carries them to Istanbul, physically anchoring the heart of the faith in the Ottoman capital.',
      svg_row('Moving the symbols of Islam itself', [
          {'n': 1, 'label': 'Custody of the holy places', 'sub': 'protector of Mecca and Medina after 1517', 'color': '#713f12'},
          {'n': 2, 'label': 'Relics gathered', 'sub': 'the Prophet’s mantle, banner, sword, hairs and more', 'color': '#b45309'},
          {'n': 3, 'label': 'Enshrined at Topkapı', 'sub': 'the Chamber of Sacred Relics — Istanbul as Islam’s centre', 'color': '#16a34a'},
      ], edge_labels=['then', 'housed at'], takeaway='He made Istanbul not just the seat of empire but the physical home of Islam’s holiest objects.', accent=AC),
      bg='Conquering the Mamluk realm gave the Ottomans guardianship of <b>Mecca and Medina</b> and access to the treasured relics long held in Cairo.',
      people='The <b>Sharif of Mecca</b>, who sent the keys of the Kaaba; the ulama who authenticated the relics; generations of later sultans who venerated them.',
      what='Selim brought the <b>Sacred Relics</b> — including the Prophet’s cloak (Hırka-i Şerif), standard, sword and other items — to Istanbul, where they were enshrined in the <b>Topkapı Palace</b>.',
      crux='Possession of the relics gave the dynasty an <b>unmatched aura of religious authority</b> — the sacred made tangible and Ottoman.',
      conseq='The Chamber of the Sacred Relics remains a revered site today; the relics reinforced the sultans’ later claim to the caliphate.',
      matters='Power seeks not only territory but the symbols of legitimacy — whoever holds the sacred objects holds a claim on the faithful.'),

    E('caliph', '1517', 'The Caliphate comes to Istanbul', ['REFORM', 'TURNING POINT'],
      'With Cairo his, he takes charge of the shadow Abbasid caliph living there and brings him to Istanbul — and from this act grows the later, hugely consequential claim that the title of Caliph itself, the leadership of all Sunni Islam, passed permanently to the Ottoman sultans.',
      svg_row('From sultan to would-be Caliph of Islam', [
          {'n': 1, 'label': 'The shadow caliph in Cairo', 'sub': 'the last Abbasid, a figurehead under the Mamluks', 'color': '#713f12'},
          {'n': 2, 'label': 'Brought to Istanbul', 'sub': 'Selim takes the caliph (and the relics) north', 'color': '#b45309'},
          {'n': 3, 'label': 'The caliphal claim', 'sub': 'the later tradition of a transferred Caliphate', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='From his conquest of Egypt grew the Ottomans’ claim to lead all Sunni Islam as Caliphs.', accent=AC),
      bg='A powerless <b>Abbasid caliph</b>, <b>al-Mutawakkil III</b>, lived under Mamluk protection in Cairo as a symbolic figurehead of Sunni Islam.',
      people='<b>al-Mutawakkil III</b>, the last shadow Abbasid caliph; the later Ottoman rulers who claimed the caliphal title.',
      what='After conquering Egypt, Selim took the shadow caliph <b>al-Mutawakkil III</b> and the Prophet’s <b>relics</b> to Istanbul. From this grew the later — historically disputed — tradition that the <b>Caliphate</b> was formally transferred to the Ottoman sultans, who thereafter claimed leadership of Sunni Islam.',
      crux='Whatever the legal reality, the act let the Ottomans <b>claim the supreme religious leadership of Sunni Islam</b>, an authority they invoked for four centuries.',
      conseq='The Ottoman sultans styled themselves Caliphs until the title was abolished in 1924 — a legacy rooted in Selim’s conquest.',
      matters='Selim’s Egyptian campaign gave the Ottoman throne a claim to universal Islamic leadership that shaped the Muslim world into the 20th century.'),

    E('poet', '1512–1520', 'The poet behind the terror', ['POLITICS', 'REFORM'],
      'The most fearsome of sultans has a startling other side: “the Grim” is also an accomplished poet who writes elegant verse in Persian and patronises scholars — a cultured, complex man behind the mask of ferocity, and a reminder that Ottoman power and high culture were intertwined.',
      svg_row('The cultured man inside the conqueror', [
          {'n': 1, 'label': 'A ferocious reputation', 'sub': '“the Grim,” feared executioner of viziers', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'An elegant Persian poet', 'sub': 'writes refined verse; patronises scholars', 'color': '#713f12'},
          {'n': 3, 'label': 'Power and culture entwined', 'sub': 'the warrior-sultan as a man of letters too', 'color': '#166534'},
      ], edge_labels=['yet', 'so'], takeaway='The empire’s most terrifying sultan was also a gifted poet — ferocity and refinement in one man.', accent=AC),
      bg='Ottoman sultans were often cultured patrons; Selim, for all his ferocity, was among the more accomplished as a poet.',
      people='The scholars and poets of his court; the Persian literary tradition he wrote in.',
      what='Behind his terrifying image, Selim was an <b>accomplished poet</b> who composed elegant verse (largely in <b>Persian</b>) and <b>patronised scholars and artists</b> — a cultured and complex man, not merely a warlord.',
      crux='He embodied the Ottoman fusion of <b>ruthless power and high culture</b>: the same man who executed viziers wrote refined poetry.',
      conseq='His cultural patronage, like his conquests, helped set the stage for the artistic golden age under his son Suleiman.',
      matters='People are rarely one thing. “The Grim” was also a poet — a caution against reducing even history’s hard men to a single dimension.'),

    E('spicetrade', '1517–1520', 'The spice road and the Portuguese threat', ['REFORM', 'POLITICS', 'TURNING POINT'],
      'Conquering Egypt hands Selim control of the Red Sea and the ancient spice route between Asia and Europe — but also inherits a new enemy, the Portuguese, whose ships are rounding Africa to seize that trade, driving Selim to plan a naval war in the Indian Ocean.',
      svg_stack('Inheriting a trade — and its rival', [
          {'n': 1, 'label': 'Master of the Red Sea', 'sub': 'Egypt controls the Asia–Europe spice route', 'color': '#713f12'},
          {'n': 2, 'label': 'The Portuguese arrive', 'sub': 'rounding Africa, they raid the Indian Ocean trade', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Plan a Red Sea fleet', 'sub': 'Ottoman naval power projected toward the Indian Ocean', 'color': '#0891b2'},
      ], takeaway='He saw that the empire’s new wealth depended on sea lanes — and that a distant European power now threatened them.', accent=AC),
      bg='For centuries the <b>spice trade</b> flowed through Egypt and the Red Sea to the Mediterranean. Portugal’s new sea route around Africa threatened to divert that wealth entirely.',
      people='Portuguese captains raiding the <b>Indian Ocean</b>; the merchants of Cairo and the Hejaz; the Ottoman admirals Selim tasked with contesting the southern seas.',
      what='Egypt’s conquest made the Ottomans a <b>Red Sea and Indian Ocean power</b> overnight. Selim began building a fleet to protect the spice route and challenge the Portuguese — a struggle his successors carried on.',
      crux='He recognised that <b>maritime commerce was now strategic</b> — and that Ottoman prosperity required contesting oceans, not just holding land.',
      conseq='It launched decades of Ottoman–Portuguese naval rivalry from Suez to India, and shaped Suleiman’s later campaigns and fleets.',
      matters='Empires built on land can find their fortunes hostage to distant seas — and to rivals who arrive by an unexpected route.'),

    E('administration', '1517–1520', 'Governing a suddenly vast empire', ['REFORM', 'POLITICS'],
      'Conquering an empire is one thing; ruling it is another — and in his last years Selim faces the harder task of integrating the immense new lands of Syria, Egypt and the holy cities into a single administration, laying the governing foundations his son would build a golden age upon.',
      svg_row('From conquest to coherent rule', [
          {'n': 1, 'label': 'Vast new provinces', 'sub': 'Syria, Egypt and the Hejaz to be governed', 'color': '#713f12'},
          {'n': 2, 'label': 'Integrate and administer', 'sub': 'set up governance, garrisons and revenue', 'color': '#b45309'},
          {'n': 3, 'label': 'Foundations for Suleiman', 'sub': 'a governable empire handed to his son', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He did the unglamorous work of turning lightning conquests into a governable empire.', accent=AC),
      bg='Selim’s eight years had roughly tripled the empire; the new lands had to be <b>integrated and administered</b>, not merely occupied.',
      people='The Ottoman administrators and governors sent to the new provinces; the existing elites of Egypt and Syria.',
      what='In his final years Selim worked to <b>integrate the enormous new territories</b> — Syria, Egypt, the Hejaz — into the Ottoman administrative and fiscal system, setting up governance and revenue structures that endured.',
      crux='He understood that <b>conquest must be followed by administration</b>, and left his son not just land but the beginnings of a system to govern it.',
      conseq='Suleiman inherited not only a vast empire but a workable framework for ruling it, enabling his golden age.',
      matters='Empires are kept by administration, not just won by arms. Selim’s last, quiet work made his conquests durable.'),
]

# ==================================================================  PHASE 5 — THE GRIM END
PHASE_END = [
    E('fleet', '1518–1520', 'Building a navy for the next war', ['REFORM', 'POLITICS'],
      'His final project points west: recognising that future battles will be fought at sea against Christian Europe and the Portuguese now menacing the Red Sea, he throws himself into building a great fleet — a war he means to fight but does not live to launch.',
      svg_row('Turning toward the sea', [
          {'n': 1, 'label': 'New threats at sea', 'sub': 'Christian Europe and the Portuguese in the Red Sea', 'color': '#713f12'},
          {'n': 2, 'label': 'A crash naval build-up', 'sub': 'expands the arsenal and fleet', 'color': '#b45309'},
          {'n': 3, 'label': 'A war left to his heir', 'sub': 'he dies before he can use it', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='Even the land-conqueror saw the future was naval — and began the fleet his son would wield.', accent=AC),
      bg='Master of the eastern Mediterranean coasts and the Red Sea, Selim saw that the next challenges — Christian Europe and Portuguese sea power — would be fought on water.',
      people='The Ottoman shipwrights and admirals; the <b>Portuguese</b> now threatening the Red Sea and Indian Ocean trade.',
      what='In his last years Selim launched a major <b>naval build-up</b>, expanding the arsenal and fleet in preparation for war against the Christian Mediterranean powers and to counter the <b>Portuguese</b> — a campaign cut short by his death.',
      crux='He anticipated the empire’s future strategic axis — the <b>sea</b> — and began building the tool his successors, above all Suleiman and Barbarossa, would use.',
      conseq='The fleet Selim started underpinned the naval dominance the Ottomans achieved under Suleiman.',
      matters='Great strategists prepare for the next war, not the last. Selim’s final act looked past his own conquests to the naval age ahead.'),

    E('death', '1520', 'The Grim dies — and leaves one heir', ['DEATH', 'TRIUMPH'],
      'Feared to the last — “may you be a vizier of Selim” was a curse, so many did he execute — he dies of an infection on campaign after only eight years, leaving a tripled empire and, unusually, just one son to inherit it: Suleiman.',
      svg_compare('A short, terrible, decisive reign',
          {'head': 'The terror', 'color': '#7f1d1d',
           'items': ['executed vizier after vizier', '“may you be Selim’s vizier” — a curse', 'ruled by fear and iron will']},
          {'head': 'The legacy', 'color': '#166534',
           'items': ['tripled the empire in 8 years', 'won Egypt, Syria and the holy cities', 'left one heir — no succession war']},
          verdict='Eight ruthless years that set up the Ottoman golden age under his son Suleiman.',
          takeaway='He was feared, brief and utterly decisive — and handed his son the greatest empire in Ottoman history.', accent=AC),
      bg='Selim ruled only eight years but transformed the empire. He was famously severe — executing officials so often that a curse invoked his name.',
      people='His many executed viziers; his sole surviving son and heir, <b>Suleiman</b>, who would be called “the Magnificent.”',
      what='In <b>1520</b> Selim died of a skin infection (often described as a plague-boil, <b>sirpence</b>) while on campaign, aged around 50. Unusually, he left <b>only one son</b>, so <b>Suleiman</b> succeeded without a fratricidal war.',
      crux='His reign was a study in <b>ruthless efficiency</b>: brief, feared, and astonishingly productive — he conquered more, faster, than almost any Ottoman before him.',
      conseq='Suleiman inherited a vast, wealthy, secure empire at its peak strength and used it to launch the Ottoman golden age.',
      matters='A short reign can outweigh a long one. Selim’s eight brutal years built the platform on which the empire’s greatest age was raised.'),

    E('legacy', '1520', 'Eight years that remade the empire', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'In just eight years Selim roughly tripled the Ottoman realm, shifted its centre of gravity from Europe to the Islamic heartlands, filled its treasury with Egypt’s wealth, and left his son Suleiman the strongest state in the world — the launchpad of a golden age.',
      svg_row('The inheritance he left Suleiman', [
          {'n': 1, 'label': 'The empire tripled', 'sub': 'Syria, Egypt, the Hejaz and the east added in 8 years', 'color': '#713f12'},
          {'n': 2, 'label': 'Leader of Sunni Islam', 'sub': 'holy cities, relics and caliphal prestige secured', 'color': '#b45309'},
          {'n': 3, 'label': 'A full treasury, a single heir', 'sub': 'Egypt’s riches and Suleiman ready to inherit', 'color': '#16a34a'},
      ], edge_labels=['plus', 'yields'], takeaway='A brief, brutal reign built the foundation on which the Ottoman golden age would rise.', accent=AC),
      bg='Selim reigned only from 1512 to 1520, yet transformed the empire’s size, wealth and identity more than almost any sultan before or after.',
      people='<b>Suleiman</b>, his sole surviving son and heir; the vast new populations of Arabs, Kurds and others now under Ottoman rule; the future viziers and admirals of the golden age.',
      what='By 1520 Selim had <b>roughly tripled the empire</b>, made it the foremost Sunni Muslim power, enriched it with Egyptian revenue, and — unusually — left <b>a single, capable heir</b>, avoiding a war of succession.',
      crux='His ferocity and speed built a <b>consolidated, wealthy, unrivalled state</b> — the platform Suleiman would use for conquest and splendour.',
      conseq='Suleiman the Magnificent inherited this base and presided over the Ottoman zenith; Selim’s conquests shaped the Middle East for four centuries.',
      matters='A short reign can matter more than a long one — what counts is the foundation it leaves for those who follow.'),

    E('viziers', '1512–1520', '“May you be a vizier of Selim” — rule by fear', ['POLITICS', 'TRAGEDY'],
      'He governs his own court by terror as surely as he conquers his enemies: he executes grand vizier after grand vizier on the slightest failure or suspicion, until to be named his chief minister is understood as something close to a death sentence — and the curse “may you be a vizier of Selim” enters the language.',
      svg_row('Terror turned on his own ministers', [
          {'n': 1, 'label': 'Demands total performance', 'sub': 'the smallest failure can be fatal', 'color': '#713f12'},
          {'n': 2, 'label': 'Executes his viziers', 'sub': 'chief ministers fall one after another', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'A proverbial curse', 'sub': '“may you be a vizier of Selim”', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='He ruled his court by fear as absolute as his conquests — the top job in his government was a death trap.', accent=AC),
      bg='Selim demanded absolute performance and loyalty from his ministers, and punished failure with death.',
      people='The <b>grand viziers</b> executed in quick succession under his reign.',
      what='Selim <b>executed a series of grand viziers</b> for failure or suspicion, making the office so dangerous that the phrase <b>“may you be a vizier of Selim”</b> became a proverbial curse.',
      crux='He extended his <b>ruthlessness inward</b>, ruling his own administration by the same fear he used against enemies — effective, but chilling.',
      conseq='His ministers served in terror; the reign, though brief, was marked by fear at the very top of the state.',
      matters='Selim’s terror was not reserved for enemies. Ruling by fear even over his own ministers is the darker face of his fearsome efficiency.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Selim I — <b>Yavuz</b>, “the Grim” or “the Stern” — ruled only eight years but roughly <b>tripled the Ottoman Empire</b>, crushing the Safavids in the east and conquering the entire Mamluk world — Syria, Egypt and the holy cities — in the south. He is a study in <b>ruthless focus, the gunpowder revolution, and how a short, terrible reign can build the platform for a golden age.</b></p>
<div class="ov-quote">“Ruling is a harsh trade; the throne has room for one.”<span>— sentiment associated with Selim I</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A warlike frontier prince forces his own father to abdicate and kills every rival → purges Safavid sympathisers at home → shatters Shah Ismail with firepower at Chaldiran → turns south and destroys the Mamluks at Marj Dabiq and Ridaniya → conquers Syria and Egypt → becomes guardian of Mecca and Medina → dies after just eight years, leaving a tripled empire to his son Suleiman.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🎯</div><h4>Ruthless focus</h4><p>Eight years, no wasted motion — he conquered more, faster, than almost any Ottoman before him.</p></div>
  <div class="ov-card"><div class="i">🔫</div><h4>The gunpowder edge</h4><p>Chaldiran and Marj Dabiq both show firepower destroying magnificent traditional cavalry.</p></div>
  <div class="ov-card"><div class="i">🕋</div><h4>Guardian of Islam</h4><p>Taking Mecca and Medina made the Ottoman sultan the foremost sovereign of the Sunni world.</p></div>
  <div class="ov-card"><div class="i">🌱</div><h4>Built the golden age</h4><p>His conquests and wealth were the platform for Suleiman the Magnificent.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Ruthless Rise</b><small> 1470–1513</small><p>Seizing the throne from his living father.</p></div>
  <div><b>2 · The East</b><small> 1513–14</small><p>The Safavid reckoning and Chaldiran.</p></div>
  <div><b>3 · The South</b><small> 1516–17</small><p>Destroying the Mamluks; taking Egypt.</p></div>
  <div><b>4 · Guardian of Islam</b><small> 1517</small><p>The holy cities and the caliphate.</p></div>
  <div><b>5 · The Grim End</b><small> 1520</small><p>Death, and one heir — Suleiman.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Bayezid II', 'role': 'father / sultan', 'color': '#6b7280',
     'bio': 'Selim’s cautious, peace-seeking father, whom Selim forced to abdicate in 1512 with Janissary backing; he died shortly afterward.',
     'rel': 'The father whose throne Selim seized while he still lived.'},
    {'name': 'Shah Ismail I', 'role': 'Safavid rival', 'color': '#b45309',
     'bio': 'The charismatic founder of Safavid Persia and its militant Shia state, whose army Selim shattered at Chaldiran in 1514, breaking his aura of invincibility.',
     'rel': 'The eastern rival whose Shia revolution Selim answered with fire.'},
    {'name': 'Qansuh al-Ghawri', 'role': 'Mamluk sultan', 'color': '#7f1d1d',
     'bio': 'The aged Mamluk sultan of Egypt and Syria, killed at Marj Dabiq in 1516 when Ottoman firepower broke his cavalry.',
     'rel': 'The old-order ruler whose death opened Syria to Selim.'},
    {'name': 'Tuman bay II', 'role': 'last Mamluk sultan', 'color': '#9a3412',
     'bio': 'The last Mamluk sultan, who resisted at Ridaniya and in Cairo; captured and executed by the Ottomans in 1517.',
     'rel': 'The last defender of the Mamluk world Selim destroyed.'},
    {'name': 'al-Mutawakkil III', 'role': 'last Abbasid caliph', 'color': '#166534',
     'bio': 'The shadow Abbasid caliph in Mamluk Cairo, around whom the later, disputed tradition of the Caliphate’s transfer to the Ottomans grew.',
     'rel': 'The figure tied to Selim’s claim on the Caliphate.'},
    {'name': 'Suleiman', 'role': 'son and heir', 'color': '#713f12',
     'bio': 'Selim’s sole surviving son, who inherited a vast, secure, wealthy empire without a succession war and became Suleiman the Magnificent.',
     'rel': 'The heir who turned Selim’s conquests into a golden age.'},
]

KEY_EVENTS = [
    ('1470', 'Born, son of Bayezid II', 'A warlike prince under a cautious father.'),
    ('1512', 'Forces his father to abdicate', 'Takes the throne with Janissary backing.'),
    ('1512–13', 'Eliminates his rivals', 'Brothers and nephews executed.'),
    ('1513–14', 'Purge of the Qizilbash', 'Secures Anatolia against Safavid preaching.'),
    ('1514', 'Battle of Chaldiran', 'Firepower shatters Shah Ismail; Tabriz taken.'),
    ('1516', 'Battle of Marj Dabiq', 'Mamluk cavalry broken; Sultan al-Ghawri killed.'),
    ('1517', 'Battle of Ridaniya', 'Cairo taken; the Mamluk Sultanate ends.'),
    ('1517', 'Guardian of the Holy Cities', 'Mecca and Medina submit; empire tripled.'),
    ('1520', 'Death of Selim', 'Dies of infection; his son Suleiman succeeds.'),
]

MASTER = [
    {'year': '1470', 'age': 'born', 'phase': 'The Rise', 'title': 'Born to Bayezid II', 'desc': 'A warlike frontier prince.'},
    {'year': '1512', 'age': 'age ~42', 'phase': 'The Rise', 'title': 'Seizes the throne', 'desc': 'Forces his father to abdicate.'},
    {'year': '1514', 'age': 'age ~44', 'phase': 'The East', 'title': 'Chaldiran', 'desc': 'Shatters the Safavids with firepower.'},
    {'year': '1516', 'age': 'age ~46', 'phase': 'The South', 'title': 'Marj Dabiq', 'desc': 'Breaks the Mamluks; takes Syria.'},
    {'year': '1517', 'age': 'age ~47', 'phase': 'The South', 'title': 'Conquest of Egypt', 'desc': 'Ridaniya; the Mamluk state ends.'},
    {'year': '1517', 'age': 'age ~47', 'phase': 'Guardian', 'title': 'Holy cities won', 'desc': 'The empire is tripled.'},
    {'year': '1520', 'age': 'age ~50', 'phase': 'The End', 'title': 'Death of Selim', 'desc': 'Leaves one heir — Suleiman.'},
]

SOURCES = [
    ('Britannica — Selim I', 'https://www.britannica.com/biography/Selim-I'),
    ('World History Encyclopedia — Selim I', 'https://www.worldhistory.org/Selim_I/'),
    ('Britannica — Battle of Chaldiran', 'https://www.britannica.com/event/Battle-of-Chaldiran'),
    ('Wikipedia — Selim I', 'https://en.wikipedia.org/wiki/Selim_I'),
]

def build_meta():
    return {
        'pid': 'gm-selim1.html', 'kind': 'man', 'emoji': '⚔️', 'accent': AC,
        'name': 'Selim I', 'years': '1470–1520', 'group': 'Ottoman Sultans',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'Yavuz — “the Grim.” In eight ruthless years he tripled the empire, crushed the Safavids, conquered the Mamluks, and made the Ottoman sultan the guardian of Islam.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Ruthless Rise', 'type': 'timeline',
             'intro': 'A warlike frontier prince refuses to let the throne pass to a gentler brother — and seizes it from his own living father, then eliminates every rival with cold finality.', 'events': PHASE_RISE},
            {'id': 'east', 'label': '2 · The East', 'type': 'timeline',
             'intro': 'He answers the Safavid Shia revolution first with a brutal purge at home, then with massed firepower at Chaldiran that shatters Shah Ismail’s famed cavalry.', 'events': PHASE_EAST},
            {'id': 'south', 'label': '3 · The South', 'type': 'timeline',
             'intro': 'Turning against the ancient Mamluk Sultanate, he destroys their magnificent cavalry with the same guns at Marj Dabiq and Ridaniya — and swallows Syria and Egypt.', 'events': PHASE_SOUTH},
            {'id': 'islam', 'label': '4 · Guardian of Islam', 'type': 'timeline',
             'intro': 'With Egypt and the Hejaz his, he becomes protector of Mecca and Medina and the foremost sovereign of the Sunni world — having tripled the empire in eight years.', 'events': PHASE_ISLAM},
            {'id': 'end', 'label': '5 · The Grim End', 'type': 'timeline',
             'intro': 'Feared to the last, he dies of an infection on campaign after only eight years — leaving, unusually, a single heir to inherit the greatest empire in Ottoman history.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'The formal “transfer of the Caliphate” from al-Mutawakkil III to Selim is a later, historically disputed tradition; what is certain is that Selim became guardian of the holy cities and the paramount Sunni ruler.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
