# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Subutai — the Mongol Empire's greatest general.
The blacksmith's son who conquered more territory than any commander in history."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#334155'  # steppe steel

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE HOUND
PHASE_RISE = [
    E('blacksmith', 'c. 1175–1197', 'A blacksmith’s son on the steppe', ['RISE'],
      'Subutai is born into the Uriankhai, a forest people of blacksmiths — with no noble blood and no claim to command — yet joins the young Temüjin (the future Genghis Khan) as a teenager and rises, on pure ability, to become the greatest general the Mongol Empire would ever produce.',
      svg_row('From forge to high command by merit', [
          {'n': 1, 'label': 'Uriankhai blacksmith family', 'sub': 'commoner birth, no aristocratic claim', 'color': '#334155'},
          {'n': 2, 'label': 'Joins Temüjin young', 'sub': 'follows his brother Jelme into Genghis’s service', 'color': '#0369a1'},
          {'n': 3, 'label': 'Rises on ability alone', 'sub': 'Genghis’s meritocracy lets talent command', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='In a system that rewarded ability over birth, a blacksmith’s son could rise to lead armies across a continent.', accent=AC),
      bg='<b>Subutai</b> was born around 1175 among the <b>Uriankhai</b>, a forest-dwelling people known as blacksmiths, with no aristocratic status in steppe society.',
      people='his brother <b>Jelme</b>, an early companion of Genghis; <b>Temüjin</b> (Genghis Khan), who prized ability over lineage.',
      what='Though of humble, commoner birth, Subutai joined <b>Temüjin’s</b> following as a young man and rose through Genghis Khan’s <b>merit-based command</b> to become one of his most trusted generals — one of the “<b>four hounds of war.</b>”',
      crux='His rise embodied Genghis’s revolution: <b>command by proven talent</b>, not by blood — impossible in most societies of the age.',
      conseq='Freed to command by merit, Subutai would go on to direct over twenty campaigns across Asia and into Europe.',
      matters='The greatest talent is wasted by systems that reward only birth — meritocracy is how a blacksmith’s son conquers half the world.'),

    E('merkit', '1197', 'First command — the deserter’s ruse', ['BATTLE', 'RISE', 'TURNING POINT'],
      'Given his first independent command against the Merkit, the young Subutai wins not by force but by cunning — riding into the enemy camp posing as a deserter, convincing them the Mongol army is far away, so that Genghis’s force falls on them by total surprise.',
      svg_stack('Winning by deception, not force', [
          {'n': 1, 'label': 'First independent command', 'sub': 'sent against the Merkit, c. 1197', 'color': '#334155'},
          {'n': 2, 'label': 'Poses as a deserter', 'sub': 'convinces the Merkit the Mongols are far off', 'color': '#a16207'},
          {'n': 3, 'label': 'Surprise annihilation', 'sub': 'Genghis’s army strikes the unready camp', 'color': '#166534'},
      ], takeaway='From his very first command he fought with the mind — deception and misdirection over brute assault.', accent=AC),
      bg='The <b>Merkit</b> were among Genghis’s bitterest early enemies. Subutai was entrusted with a mission against them around 1197.',
      people='the Merkit chiefs he deceived; <b>Genghis Khan</b>, who exploited the surprise; the young Subutai proving himself.',
      what='Subutai reportedly <b>rode into the Merkit camp as a fake deserter</b>, spreading word that the Mongol army was distant and disorganised — lulling them until Genghis’s forces <b>surprised and encircled</b> them.',
      crux='He grasped from the start that <b>information and deception</b> win battles before the fighting — shaping the enemy’s beliefs, then striking.',
      conseq='The success marked him as a commander of rare guile, launching a career of ever-greater responsibility.',
      matters='The finest generals win in the enemy’s mind first — controlling what the foe believes is more powerful than any charge.'),

    E('method', '1200s–1240s', 'The method — a war-machine run like clockwork', ['REFORM', 'BATTLE'],
      'Subutai turns Mongol warfare into something close to a modern science — coordinating armies hundreds of miles apart toward a single plan, using relentless intelligence and spies, feigned retreats and deception, and, uniquely among steppe generals, integrating siege engineers and gunpowder into a mobile system.',
      svg_stack('A system centuries ahead of its time', [
          {'n': 1, 'label': 'Coordinated separated armies', 'sub': 'columns hundreds of miles apart converging on plan', 'color': '#334155'},
          {'n': 2, 'label': 'Intelligence and deception', 'sub': 'spy networks, feigned retreats, sowing division', 'color': '#0369a1'},
          {'n': 3, 'label': 'Engineers and firepower', 'sub': 'trebuchets and gunpowder folded into cavalry warfare', 'color': '#166534'},
      ], takeaway='He ran war as an integrated system of intelligence, movement and firepower — anticipating modern operational warfare.', accent=AC),
      bg='Steppe armies were fast but traditionally poor at sieges and grand coordination. Subutai systematised Mongol warfare into a coordinated, all-arms machine.',
      people='the scouts and spies who fed his planning; the captured Chinese and Muslim engineers he employed; the commanders who executed his converging columns.',
      what='Subutai <b>coordinated forces separated by hundreds of miles</b>, ran extensive <b>intelligence and spy networks</b>, mastered the <b>feigned retreat</b>, and — unusually — <b>integrated siege engineers, trebuchets and gunpowder</b> into fast cavalry campaigns.',
      crux='He treated war as a <b>coordinated system</b> of information, movement and firepower — an approach military theorists would only formalise centuries later.',
      conseq='Modern strategists — Liddell Hart, Patton, Rommel, and Soviet “deep battle” theorists — studied his methods as precursors of modern operational warfare.',
      matters='Genius in war is often systematic, not just brave — Subutai’s coordination of intelligence, movement and firepower prefigured the modern age.'),
]

# ==================================================================  PHASE 2 — THE GREAT RAID
PHASE_RAID = [
    E('khwarezm', '1220–1221', 'The relentless pursuit — hunting a Shah to death', ['BATTLE', 'TRIUMPH'],
      'When the Khwarezmian empire collapses under Mongol assault, Subutai and Jebe are unleashed with about 30,000 men to hunt down the fleeing Shah Muhammad II — a relentless chase across Persia that never lets him rally an army, until the broken Shah dies, destitute, on an island in the Caspian Sea.',
      svg_row('A pursuit that gave the enemy no rest', [
          {'n': 1, 'label': 'Khwarezm shattered', 'sub': 'Genghis’s invasion breaks the empire, 1220', 'color': '#334155'},
          {'n': 2, 'label': 'Subutai & Jebe pursue', 'sub': '~30,000 men chase Shah Muhammad across Persia', 'color': '#0369a1'},
          {'n': 3, 'label': 'The Shah dies hunted', 'sub': 'never rallies; dies on a Caspian island, early 1221', 'color': '#b91c1c'},
      ], edge_labels=['then', 'until'], takeaway='He denied the Shah a single day to regroup — hunting the enemy leader to a lonely death.', accent=AC),
      bg='The <b>Khwarezmian Empire</b> of Shah <b>Muhammad II</b> stretched across Persia and Central Asia. Genghis’s 1219–20 invasion shattered it, and the Shah fled westward.',
      people='<b>Shah Muhammad II</b>, the fugitive; <b>Jebe</b>, Subutai’s fellow commander; the Persian cities in their path.',
      what='With about <b>30,000 men</b>, Subutai and Jebe <b>relentlessly pursued the Shah across Persia</b>, never letting him gather reserves. Broken and abandoned, <b>Muhammad II died in early 1221</b> on an island in the Caspian.',
      crux='He understood that <b>hunting the enemy leader without pause</b> prevents any recovery — the pursuit itself was the decisive weapon.',
      conseq='The pursuit rolled on into a legendary raid around the whole Caspian Sea.',
      matters='Relentless pursuit can destroy an enemy more surely than a battle — denying a beaten foe the time to recover.'),

    E('caspian', '1220–1223', 'The ride around the world', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'Rather than turn back, Subutai and Jebe ask permission to keep riding — circling the entire Caspian Sea through the Caucasus in a two-year reconnaissance-in-force of some 20,000 men, an expedition the historian Gibbon called one “which has never been attempted, and has never been repeated.”',
      svg_stack('An expedition without parallel', [
          {'n': 1, 'label': 'Ask to keep going', 'sub': 'seek Genghis’s leave to circle the Caspian', 'color': '#334155'},
          {'n': 2, 'label': 'Through the Caucasus', 'sub': '~20,000 men cross the mountains in winter', 'color': '#0369a1'},
          {'n': 3, 'label': 'Scout a whole new world', 'sub': 'map peoples and routes from Persia to Russia', 'color': '#166534'},
      ], takeaway='He turned a pursuit into a strategic reconnaissance of an entire unknown world — gathering the knowledge for future conquest.', accent=AC),
      bg='After the Shah’s death, Subutai and Jebe proposed an audacious continuation — a great loop around the <b>Caspian Sea</b> through the <b>Caucasus</b> and the southern Russian steppe.',
      people='the Alans, Circassians, Georgians and Cumans they fought; Genghis, who granted the extraordinary request; the ~20,000 Mongol riders.',
      what='Subutai and Jebe led roughly <b>20,000 men</b> on a two-year circuit around the Caspian, crossing the <b>Caucasus in winter</b> and defeating a succession of peoples — an expedition Edward Gibbon called one “which has never been attempted, and has never been repeated.”',
      crux='He converted a pursuit into a <b>strategic reconnaissance</b>, scouting the geography, peoples and politics of a world the Mongols would later conquer.',
      conseq='The intelligence gathered on the Rus and the western steppe underpinned the Mongol invasion of Europe fifteen years later.',
      matters='The boldest reconnaissance is an investment in future conquest — knowing the ground before you ever mean to take it.'),

    E('georgia', '1220–1221', 'Wrecking Georgia — deception as a weapon', ['BATTLE', 'TRIUMPH'],
      'Passing through the Caucasus, Subutai destroys the army of the Kingdom of Georgia with a classic ruse — luring the proud Georgian knights into a headlong pursuit with a feigned retreat, then enveloping and annihilating them — a blow so severe it cripples Georgia and helps doom the Fifth Crusade it might have reinforced.',
      svg_row('The feigned retreat perfected', [
          {'n': 1, 'label': 'Face the Georgian knights', 'sub': 'King George IV’s heavy cavalry, c. 1221', 'color': '#334155'},
          {'n': 2, 'label': 'Feign retreat', 'sub': 'lure the knights into a reckless pursuit', 'color': '#a16207'},
          {'n': 3, 'label': 'Envelop and destroy', 'sub': 'turn on the scattered pursuers and annihilate them', 'color': '#b91c1c'},
      ], edge_labels=['then', 'then'], takeaway='He beat heavy knights by using their own aggression against them — the feigned retreat as a trap.', accent=AC),
      bg='The <b>Kingdom of Georgia</b>, then a strong Christian power, lay in Subutai’s path through the Caucasus and was preparing to join the Fifth Crusade.',
      people='King <b>George IV</b> of Georgia; the Georgian heavy cavalry; the crusaders who never received their reinforcement.',
      what='Subutai used a <b>feigned retreat</b> to lure the Georgian knights into a disordered pursuit, then <b>turned and enveloped them</b>, destroying the army — a blow that <b>crippled Georgia</b> and denied the Fifth Crusade a key ally.',
      crux='He turned the enemy’s <b>strength and pride into a fatal weakness</b> — the disciplined feigned retreat drawing brave knights to their deaths.',
      conseq='Georgia never fully recovered; the raid’s effects rippled as far as the Crusades in the Holy Land.',
      matters='A disciplined army can weaponise the enemy’s aggression — the feigned retreat beats brave but rash opponents every time.'),

    E('kalka', '31 May 1223', 'The Kalka River — 20,000 destroy 80,000', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'At the Kalka River, Subutai faces a huge coalition of Rus princes and Cuman allies — perhaps 80,000 men against his 20,000 — and destroys them: a nine-day feigned retreat strings the enemy out, then he turns and shatters them with coordinated firepower and cavalry, the Mongols’ first great victory over the armies of Europe.',
      svg_stack('The masterclass on the Kalka', [
          {'n': 1, 'label': 'Outnumbered ~4 to 1', 'sub': '20,000 Mongols vs ~80,000 Rus and Cumans', 'color': '#334155'},
          {'n': 2, 'label': 'A nine-day feigned retreat', 'sub': 'strings the coalition out and exhausts it', 'color': '#a16207'},
          {'n': 3, 'label': 'Turn and annihilate', 'sub': 'firepower opens gaps; cavalry destroys them piecemeal', 'color': '#b91c1c'},
      ], takeaway='He beat a force four times his size by controlling time and space — retreating for nine days, then striking a strung-out enemy.', accent=AC),
      bg='A coalition of <b>Rus princes and Cuman</b> nomads, alarmed by the Mongol raiders, gathered a huge army to destroy Subutai’s smaller force in 1223.',
      people='the Rus princes and their <b>Cuman</b> allies; the Mongol commanders under Subutai and Jebe; the exhausted, strung-out coalition.',
      what='At the <b>Battle of the Kalka River</b> (31 May 1223), Subutai’s ~20,000 men <b>feigned retreat for nine days</b>, drawing the ~80,000-strong coalition into disorder, then <b>turned and destroyed it</b> with concentrated firepower and cavalry charges.',
      crux='He mastered <b>time and space</b> — using a long retreat to fragment and exhaust a superior enemy before striking the pieces.',
      conseq='Kalka was the Mongols’ first great defeat of European armies — and a chilling preview of the invasion to come.',
      matters='Numbers mean little against superior method — Subutai turned a 4-to-1 disadvantage into annihilation by controlling the tempo.'),
]

# ==================================================================  PHASE 3 — THE FALL OF CHINA
PHASE_CHINA = [
    E('xixia', '1226–1227', 'Xi Xia — attacking from the impossible direction', ['BATTLE', 'TRIUMPH'],
      'In the final campaign against the Tangut kingdom of Xi Xia, Subutai does the unexpected — striking from the west, over mountains and inhospitable desert no army was expected to cross — cutting Tangut resistance in two and helping bring down the kingdom.',
      svg_row('The unexpected axis of attack', [
          {'n': 1, 'label': 'Genghis attacks from the north', 'sub': 'the expected direction of assault', 'color': '#0369a1'},
          {'n': 2, 'label': 'Subutai strikes from the west', 'sub': 'over mountains and desert thought impassable', 'color': '#334155'},
          {'n': 3, 'label': 'Tangut resistance split', 'sub': 'the kingdom cut in two and overwhelmed', 'color': '#166534'},
      ], edge_labels=['while', 'so'], takeaway='He hit from the one direction the enemy thought safe — turning terrain itself into a weapon of surprise.', accent=AC),
      bg='The <b>Tangut kingdom of Xi Xia</b> was Genghis’s final target. While the Khan attacked from the north, Subutai was sent to find another way in.',
      people='the Tangut defenders; <b>Genghis Khan</b>, on his last campaign; the Mongol columns converging on Xi Xia.',
      what='Subutai <b>attacked over the western mountains and deserts</b> thought impassable for an army, <b>cutting Tangut resistance in two</b> and helping complete the conquest of Xi Xia in 1227.',
      crux='He again chose the <b>unexpected approach</b> — using forbidding terrain to appear where no defence was prepared.',
      conseq='Xi Xia fell; Genghis died during the campaign, and Subutai carried his methods into the service of the next Khan.',
      matters='The line of least expectation is often the line of least resistance — surprise is bought by daring the “impossible” route.'),

    E('jinfinal', '1230–1232', 'Breaking the Jin — the three-army trap', ['BATTLE', 'TRIUMPH'],
      'Against the powerful Jin dynasty of northern China, Subutai revives his grand-encirclement method — dividing his forces into three armies converging on the Jin heartland from different directions — and, after weeks of maneuver, annihilates the main Jin army at Sanfengshan, capturing its finest general.',
      svg_stack('Encirclement on a strategic scale', [
          {'n': 1, 'label': 'Three converging armies', 'sub': 'attack Henan from north, east and south', 'color': '#334155'},
          {'n': 2, 'label': 'Maneuver and attrition', 'sub': 'weeks of feints wear down the Jin', 'color': '#0369a1'},
          {'n': 3, 'label': 'Sanfengshan, 1232', 'sub': 'the main Jin army destroyed; its general captured', 'color': '#b91c1c'},
      ], takeaway='He applied at the scale of a whole theatre the encirclement others used on a battlefield — converging armies to trap an empire.', accent=AC),
      bg='The <b>Jin dynasty</b> was a formidable, populous Chinese state. After an earlier Mongol setback, Subutai was recalled to finish it off.',
      people='the Jin general <b>Wan Yen Heda</b>, whom he captured; <b>Ögedei Khan</b>, who sent reinforcements; the converging Mongol armies.',
      what='Subutai <b>divided his forces into three armies</b> converging on the Jin heartland, wore the enemy down through maneuver, then <b>destroyed the main Jin army at Sanfengshan (1232)</b> and captured their ablest commander.',
      crux='He practiced <b>encirclement at strategic scale</b> — coordinating separate armies across a theatre to trap and crush the enemy’s main force.',
      conseq='With its field army gone, the Jin dynasty was doomed; only its capital, Kaifeng, held out.',
      matters='The principles that win a battle can win a war when applied at scale — convergence and encirclement across a whole theatre.'),

    E('kaifeng', '1232–1234', 'The siege of Kaifeng — engineering the end of a dynasty', ['BATTLE', 'TRIUMPH', 'REFORM'],
      'Subutai — the steppe cavalryman — masters the most un-nomadic of arts, the great siege: ringing the vast Jin capital of Kaifeng with 87 kilometres of works, battering it with Muslim trebuchets and captured gunpowder weapons even as the defenders hurl thunder-crash bombs back, and dispersing his men to escape the plague raging within.',
      svg_stack('A cavalry general takes a mega-city', [
          {'n': 1, 'label': '87 km of siege works', 'sub': 'the great Jin capital ringed and cut off', 'color': '#334155'},
          {'n': 2, 'label': 'Trebuchets vs gunpowder bombs', 'sub': 'Muslim siege engines against Jin “thunder-crash” bombs', 'color': '#a16207'},
          {'n': 3, 'label': 'Disperse to dodge the plague', 'sub': 'spreads his army as disease ravages the city', 'color': '#166534'},
      ], takeaway='The nomad general became a master of siege engineering and gunpowder — the total warfare of his age.', accent=AC),
      bg='<b>Kaifeng</b>, the Jin capital, was one of the largest cities on earth, massively fortified and armed with early <b>gunpowder weapons</b>.',
      people='the Jin defenders with their “thunder-crash bombs”; the Muslim and Chinese engineers in Mongol service; the plague that swept the besieged city.',
      what='Subutai besieged Kaifeng (1232–34), building <b>circumvallation lines ~87 km long</b>, alternating bombardments from <b>Muslim trebuchets and captured gunpowder weapons</b> with periods of rest, and <b>dispersing his forces</b> to avoid the plague inside. The city fell and the Jin dynasty ended.',
      crux='He fully integrated <b>siege engineering and gunpowder</b> into Mongol warfare — mastering the one domain nomads traditionally lacked.',
      conseq='Kaifeng’s fall destroyed the Jin dynasty; the siege expertise fed directly into his later European campaign.',
      matters='The greatest commanders master the domains outside their tradition — a horseman who could also break the mightiest walls.'),
]

# ==================================================================  PHASE 4 — EUROPE
PHASE_EUROPE = [
    E('planning', '1235–1236', 'The mind behind the invasion of the West', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'When the Mongols resolve to conquer Europe, the campaign is nominally led by the young prince Batu — but its real architect is the aging Subutai, who plans the operation on the intelligence he gathered fifteen years earlier, coordinating multiple armies across a continent toward one design.',
      svg_row('The prince’s name, the general’s plan', [
          {'n': 1, 'label': 'Batu, the royal figurehead', 'sub': 'a grandson of Genghis nominally in command', 'color': '#0369a1'},
          {'n': 2, 'label': 'Subutai, the real planner', 'sub': 'designs the campaign on his 1220s reconnaissance', 'color': '#334155'},
          {'n': 3, 'label': 'Armies across a continent', 'sub': 'multiple columns coordinated to one strategic plan', 'color': '#166534'},
      ], edge_labels=['but', 'directs'], takeaway='The invasion of Europe was Subutai’s design, executed under a royal name — planning built on decades-old intelligence.', accent=AC),
      bg='In the 1230s the Mongols launched a great western campaign. Command formally belonged to Prince <b>Batu</b>, but strategic direction lay with Subutai.',
      people='Prince <b>Batu</b>, the nominal leader; the other Chinggisid princes commanding columns; Subutai, the operational mastermind.',
      what='Subutai <b>planned and directed the invasion of Europe</b>, drawing on the <b>intelligence he had gathered during the 1220s raid</b>, and coordinated multiple princely armies across the continent toward a single design.',
      crux='He combined <b>royal legitimacy (Batu) with professional command (himself)</b> — and executed a plan seeded by his own earlier reconnaissance.',
      conseq='The campaign swept away the Rus principalities and then struck into Central Europe.',
      matters='Great campaigns are often designed by the professional behind the prince — and built on intelligence gathered long in advance.'),

    E('rus', '1237–1240', 'The conquest of the Rus — war on frozen rivers', ['BATTLE', 'TRIUMPH', 'TRAGEDY'],
      'Subutai does what invaders of Russia are told is impossible — he campaigns in the depth of winter, using the frozen rivers as highways for his cavalry, and destroys the divided Rus principalities one by one: Ryazan, Vladimir, and a Grand Duke’s whole army surrounded at the Sit River before it even knows the enemy is near.',
      svg_stack('Winter turned into a weapon', [
          {'n': 1, 'label': 'Attacks in deep winter', 'sub': 'frozen rivers become cavalry highways', 'color': '#334155'},
          {'n': 2, 'label': 'Cities fall one by one', 'sub': 'Ryazan and Vladimir stormed; the Rus divided', 'color': '#a16207'},
          {'n': 3, 'label': 'Sit River, 1238', 'sub': 'Grand Duke Yuri’s army surrounded before it reacts', 'color': '#b91c1c'},
      ], takeaway='He inverted the usual rule — using the Russian winter, the invader’s traditional enemy, as his own ally.', accent=AC),
      bg='The <b>Rus principalities</b> were rich but disunited. Later invaders would be defeated by the Russian winter; Subutai used it.',
      people='the Rus princes, fatally divided; <b>Grand Duke Yuri</b> of Vladimir, surrounded at the Sit; the cities of Ryazan, Vladimir and Chernigov.',
      what='Campaigning in <b>deep winter</b> and using <b>frozen rivers as roads</b>, Subutai destroyed the Rus principalities in turn — storming <b>Ryazan and Vladimir</b> and <b>surrounding Grand Duke Yuri’s army at the Sit River (1238)</b> before he grasped the danger.',
      crux='He turned the season that defeats most invaders of Russia into an <b>advantage</b>, and exploited the Rus’s fatal disunity.',
      conseq='The Rus lands fell under the “Mongol yoke” for over two centuries; Kiev itself was next.',
      matters='The obstacle that stops others can be a weapon in the right hands — and disunity invites conquest.'),

    E('kiev', '1240', 'The sack of Kiev — the mother of Rus cities falls', ['BATTLE', 'TRAGEDY'],
      'In December 1240 Subutai storms Kiev, the greatest city of the Rus — its walls broken by concentrated bombardment, its population slaughtered on a scale that leaves the city a ruin for generations — completing the subjugation of the Rus and opening the road into Catholic Europe.',
      svg_row('The fall of a great city', [
          {'n': 1, 'label': 'Kiev besieged, Dec 1240', 'sub': 'the chief city of the Rus surrounded', 'color': '#334155'},
          {'n': 2, 'label': 'Walls smashed, city stormed', 'sub': 'concentrated siege engines breach the defences', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A ruin for generations', 'sub': 'massacre and destruction; the Rus subjugated', 'color': '#78350f'},
      ], edge_labels=['then', 'leaving'], takeaway='He erased the greatest Rus city — and with it the last barrier before Central Europe.', accent=AC),
      bg='<b>Kiev</b> was the historic heart and greatest city of the Rus. Its fall would complete the conquest and open the way west.',
      people='the defenders of Kiev; Subutai’s siege engineers; the Central European kingdoms next in the Mongols’ path.',
      what='In <b>December 1240</b> Subutai <b>stormed and sacked Kiev</b>, breaching its walls with concentrated bombardment and devastating the city so thoroughly it lay diminished for generations.',
      crux='He completed the <b>subjugation of the Rus</b> and cleared the last major obstacle before Poland and Hungary.',
      conseq='With Kiev fallen, Subutai turned his converging armies toward Catholic Europe.',
      matters='The fall of a civilisation’s central city can break its will — and open the road to everything beyond it.'),

    E('mohi', 'Apr 1241', 'Legnica and Mohi — Europe’s armies destroyed in two days', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'In a stunning two days of April 1241, coordinated Mongol armies destroy the chivalry of Central Europe on two fronts hundreds of miles apart — a Polish-German army at Legnica, and the main Hungarian army at Mohi, where Subutai’s own masterpiece unfolds: a secret night crossing, a deliberate escape-gap turned into a killing ground, and over ten thousand dead.',
      svg_stack('Two victories, one design', [
          {'n': 1, 'label': 'Legnica, 9 April 1241', 'sub': 'the Polish-German army destroyed in the north', 'color': '#0369a1'},
          {'n': 2, 'label': 'Mohi, 11 April 1241', 'sub': 'a secret night river-crossing traps the Hungarians', 'color': '#334155'},
          {'n': 3, 'label': 'The deliberate gap', 'sub': 'a left-open escape route becomes a slaughter ground', 'color': '#b91c1c'},
      ], takeaway='He shattered the armies of two kingdoms in two days — and at Mohi engineered the enemy’s destruction through a false hope of escape.', accent=AC),
      bg='In April 1241 the Mongols struck Central Europe on multiple axes. King <b>Béla IV</b> of Hungary had fortified a river line at <b>Mohi</b> on the Sajó.',
      people='the Polish and German knights destroyed at <b>Legnica</b>; King <b>Béla IV</b> of Hungary; the Hungarian army trapped at Mohi.',
      what='On <b>9 April</b> a Mongol army destroyed the Polish-German force at <b>Legnica</b>; on <b>11 April</b> Subutai smashed the Hungarians at <b>Mohi</b> — crossing the river secretly by pontoon to the enemy’s flank, using trebuchets as a barrage, and <b>leaving a deliberate gap</b> through which the Hungarians fled into a killing ground, losing over 10,000 men.',
      crux='He coordinated <b>victories hundreds of miles apart</b> to one timetable, and at Mohi turned the enemy’s <b>hope of escape into the instrument of their destruction</b>.',
      conseq='Hungary was devastated and Central Europe lay open — the high-water mark of the Mongol threat to the West.',
      matters='The deadliest trap can be a door left open — and coordinating distant victories to a single plan is the summit of generalship.'),

    E('withdrawal', '1242–1248', 'Saved by a death — the withdrawal and the end', ['POLITICS', 'DEATH', 'TURNING POINT'],
      'As Subutai plans to drive on into the heart of Europe, word arrives that the Great Khan Ögedei has died — and Mongol law requires the princes to return for the election, so the armies turn back, and Europe is spared not by any victory but by a death two thousand miles away. Subutai serves on to the end, dying in 1248 as history’s greatest conqueror-general.',
      svg_stack('Europe spared by a distant death', [
          {'n': 1, 'label': 'Poised to drive deeper west', 'sub': 'Central Europe open; further conquest planned', 'color': '#334155'},
          {'n': 2, 'label': 'Ögedei Khan dies, 1241', 'sub': 'the princes must return for the succession', 'color': '#a16207'},
          {'n': 3, 'label': 'The armies withdraw', 'sub': 'Europe saved by a death, not a battle', 'color': '#166534'},
      ], takeaway='The West escaped not by force of arms but by an accident of Mongol politics — the death of a Khan far away.', accent=AC),
      bg='After Mohi, Subutai and Batu were positioned to press further into Europe when news came of Great Khan <b>Ögedei’s death</b> in December 1241.',
      people='<b>Ögedei Khan</b>, whose death recalled the princes; <b>Batu</b>, who withdrew; the European kingdoms unknowingly reprieved.',
      what='Mongol custom required the princes to return for the <b>kurultai</b> to elect a new Khan, so the armies <b>withdrew from Europe</b> — which was spared by a death, not a defeat. Subutai served on into old age, directing more campaigns, and <b>died in 1248</b>.',
      crux='The greatest conquering army in history was halted not by any enemy but by <b>its own succession politics</b> — a quirk of fate that changed European history.',
      conseq='Subutai had directed over 20 campaigns and conquered more territory than any general in history; later strategists studied him for centuries.',
      matters='History can turn on accidents — the fate of a continent decided by a distant death rather than any battlefield.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Subutai was the greatest field commander of the Mongol Empire — and, by territory conquered, arguably the most successful general in history. A blacksmith’s son with no noble blood, he rose through Genghis Khan’s meritocracy to direct more than twenty campaigns across Asia and into Europe, coordinating armies hundreds of miles apart, mastering intelligence, deception and siege engineering centuries ahead of his time. He is the ultimate study in <b>the professional soldier’s genius, war as a coordinated system, and how method beats numbers.</b></p>
<div class="ov-quote">An expedition “which has never been attempted, and has never been repeated.”<span>— Edward Gibbon, on Subutai’s ride around the Caspian</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A blacksmith’s son rises by merit to Genghis’s inner circle → wins his first command by a deserter’s ruse → hunts the Shah of Khwarezm to death across Persia → circles the entire Caspian in a legendary raid → destroys an 80,000-strong Rus-Cuman army at the Kalka with 20,000 men → breaks Xi Xia and the Jin, mastering the great siege at Kaifeng → plans and directs the invasion of Europe → conquers the Rus on frozen rivers, sacks Kiev → destroys Europe’s armies at Legnica and Mohi in two days → and turns back only when a Khan’s death recalls the army.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">♟️</div><h4>War as a system</h4><p>Coordinated intelligence, movement and firepower — a forerunner of modern operational warfare.</p></div>
  <div class="ov-card"><div class="i">🏹</div><h4>Method over numbers</h4><p>At the Kalka he destroyed a force four times his size by controlling time and space.</p></div>
  <div class="ov-card"><div class="i">🧱</div><h4>The nomad engineer</h4><p>A cavalryman who mastered the great siege — trebuchets, gunpowder, 87 km of works.</p></div>
  <div class="ov-card"><div class="i">🌍</div><h4>The greatest conqueror</h4><p>Directed 20+ campaigns and took more territory than any general in history.</p></div>
</div>
<div class="ov-lbl">The four chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Hound</b><small> c.1175–1210s</small><p>A blacksmith’s son rises by merit and cunning.</p></div>
  <div><b>2 · The Great Raid</b><small> 1220–1223</small><p>Khwarezm, the Caspian circuit, and the Kalka.</p></div>
  <div><b>3 · The Fall of China</b><small> 1226–1234</small><p>Xi Xia, the Jin, and the great siege of Kaifeng.</p></div>
  <div><b>4 · Europe</b><small> 1235–1248</small><p>The Rus, Kiev, Legnica and Mohi — and withdrawal.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Genghis Khan', 'role': 'lord and patron', 'color': '#0369a1',
     'bio': 'The founder of the Mongol Empire, whose merit-based command let the low-born Subutai rise to lead armies; he trusted Subutai with his boldest expeditions.',
     'rel': 'The Khan whose meritocracy made Subutai’s career possible.'},
    {'name': 'Jebe', 'role': 'fellow general', 'color': '#166534',
     'bio': 'Another of Genghis’s great generals, Subutai’s partner in the pursuit of the Shah and the legendary Great Raid around the Caspian; he died on the return.',
     'rel': 'His partner in the Caspian raid and the Kalka victory.'},
    {'name': 'Batu Khan', 'role': 'royal commander', 'color': '#334155',
     'bio': 'A grandson of Genghis and nominal head of the invasion of Europe, under whose royal authority Subutai actually planned and directed the campaign.',
     'rel': 'The prince whose name led the campaigns Subutai designed.'},
    {'name': 'Ögedei Khan', 'role': 'Great Khan', 'color': '#a16207',
     'bio': 'Genghis’s son and successor as Great Khan, who backed Subutai’s campaigns; his death in 1241 recalled the Mongol armies and spared Central Europe.',
     'rel': 'The Khan whose death ended the European campaign.'},
    {'name': 'Béla IV of Hungary', 'role': 'adversary', 'color': '#b91c1c',
     'bio': 'King of Hungary, whose army Subutai destroyed at Mohi in 1241 and whom the Mongols hunted to the Adriatic coast before their withdrawal.',
     'rel': 'The king whose army fell to Subutai’s masterpiece at Mohi.'},
]

KEY_EVENTS = [
    ('c. 1175', 'Subutai born', 'Into a Uriankhai blacksmith family.'),
    ('1197', 'First command', 'Defeats the Merkit by a deserter’s ruse.'),
    ('1220–21', 'Pursuit of the Shah', 'Hunts Muhammad II to death across Persia.'),
    ('1223', 'Battle of the Kalka', '20,000 destroy an 80,000 Rus-Cuman army.'),
    ('1226–27', 'Xi Xia campaign', 'Attacks from the west over the desert.'),
    ('1232', 'Sanfengshan', 'Destroys the main Jin army.'),
    ('1232–34', 'Siege of Kaifeng', 'The Jin capital falls; the dynasty ends.'),
    ('1237–40', 'Conquest of the Rus', 'Winter war; Ryazan, Vladimir, Kiev fall.'),
    ('Apr 1241', 'Legnica & Mohi', 'Europe’s armies destroyed in two days.'),
    ('1248', 'Death of Subutai', 'History’s greatest conqueror-general.'),
]

MASTER = [
    {'year': 'c.1175', 'age': 'born', 'phase': 'The Hound', 'title': 'Born a blacksmith’s son', 'desc': 'Uriankhai commoner.'},
    {'year': '1223', 'age': 'age ~48', 'phase': 'The Great Raid', 'title': 'The Kalka River', 'desc': '20,000 beat 80,000.'},
    {'year': '1234', 'age': 'age ~59', 'phase': 'Fall of China', 'title': 'Kaifeng falls', 'desc': 'The Jin dynasty ends.'},
    {'year': '1240', 'age': 'age ~65', 'phase': 'Europe', 'title': 'Kiev sacked', 'desc': 'The Rus subjugated.'},
    {'year': '1241', 'age': 'age ~66', 'phase': 'Europe', 'title': 'Mohi', 'desc': 'His masterpiece.'},
    {'year': '1248', 'age': 'age ~72', 'phase': 'Europe', 'title': 'Death', 'desc': '20+ campaigns; unmatched conquest.'},
]

SOURCES = [
    ('Britannica — Subutai / Mongol Empire', 'https://www.britannica.com/topic/Mongol-empire'),
    ('World History Encyclopedia — Subutai', 'https://www.worldhistory.org/Subotai/'),
    ('Britannica — Battle of the Kalka River', 'https://www.britannica.com/event/Battle-of-the-Kalka-River'),
    ('World History Encyclopedia — Mongol Invasion of Europe', 'https://www.worldhistory.org/article/1453/'),
    ('Wikipedia — Subutai', 'https://en.wikipedia.org/wiki/Subutai'),
]

def build_meta():
    return {
        'pid': 'gm-subutai.html', 'kind': 'man', 'emoji': '🏹', 'accent': AC,
        'name': 'Subutai', 'years': 'c. 1175–1248', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The blacksmith’s son who became the Mongol Empire’s greatest general — master of intelligence, deception and the coordinated campaign, who conquered more territory than any commander in history.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Hound', 'type': 'timeline',
             'intro': 'A commoner blacksmith’s son rises through Genghis Khan’s meritocracy to become one of the “four hounds of war,” winning from his first command by cunning and building a war-machine run like a modern system.', 'events': PHASE_RISE},
            {'id': 'raid', 'label': '2 · The Great Raid', 'type': 'timeline',
             'intro': 'Unleashed with Jebe, he hunts the Shah of Khwarezm to death, circles the entire Caspian in a legendary reconnaissance, wrecks Georgia, and destroys a Rus-Cuman host four times his size at the Kalka River.', 'events': PHASE_RAID},
            {'id': 'china', 'label': '3 · The Fall of China', 'type': 'timeline',
             'intro': 'He brings down two Chinese states — attacking Xi Xia from the impossible direction, trapping the Jin with converging armies, and mastering the great siege at Kaifeng with trebuchets and gunpowder.', 'events': PHASE_CHINA},
            {'id': 'europe', 'label': '4 · Europe', 'type': 'timeline',
             'intro': 'The aging general plans and directs the invasion of Europe — conquering the Rus on frozen rivers, sacking Kiev, and destroying the armies of Poland and Hungary in two days at Legnica and Mohi — halted only by a Khan’s death.', 'events': PHASE_EUROPE,
             'sources': SOURCES, 'srcnote': 'Casualty and army-size figures from medieval chroniclers are often inflated and are read critically; Subutai’s campaigns are reconstructed from Chinese, Persian, Rus and Latin sources.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
