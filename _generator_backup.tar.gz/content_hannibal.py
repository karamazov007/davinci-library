# -*- coding: utf-8 -*-
"""Full, DEEP birth-to-death guide content for Hannibal Barca.
The great Carthaginian who nearly destroyed Rome — Alps, Cannae, and the long defeat."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#7e22ce'  # Tyrian purple

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE OATH
PHASE_RISE = [
    E('carthage', '264–241 BC', 'Carthage and Rome — the first great war', ['RISE', 'POLITICS'],
      'Hannibal is born into a Carthage humiliated by Rome: the two Mediterranean superpowers have just fought a 23-year war for Sicily that Carthage lost, surrendering its islands and its pride — a defeat that sets the stage for his life’s mission.',
      svg_row('Two superpowers collide', [
          {'n': 1, 'label': 'Carthage — the sea empire', 'sub': 'a rich Phoenician trading power ruling the western Mediterranean', 'color': '#7e22ce'},
          {'n': 2, 'label': 'The First Punic War', 'sub': '264–241 BC — 23 years of war over Sicily', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Carthage defeated', 'sub': 'loses Sicily, pays a huge indemnity, loses face', 'color': '#a16207'},
      ], edge_labels=['fights', 'ends in'], takeaway='Hannibal was born into the bitterness of a lost war — his life would be its sequel.', accent=AC),
      bg='<b>Carthage</b>, a Phoenician city in North Africa, was Rome’s great rival — a maritime and commercial empire. The <b>First Punic War (264–241 BC)</b> pitted them against each other over Sicily.',
      people='the Carthaginian Senate; the Roman Republic; <b>Hamilcar Barca</b>, Hannibal’s father, an undefeated general of that war.',
      what='After 23 years of war Carthage <b>lost Sicily</b>, paid a crushing indemnity, and later lost Sardinia and Corsica too — a humiliation Hamilcar and his faction never accepted.',
      crux='The defeat was <b>political, not personal</b> — Hamilcar’s army was never beaten in the field, breeding a sense of injustice that fuelled revenge.',
      conseq='The unresolved rivalry made a second war almost inevitable; Hannibal was raised as its instrument.',
      matters='Wars that end in humiliation without decisive defeat often merely postpone the next war — grievance outlives the treaty.'),

    E('oath', 'c. 237 BC', 'The oath of eternal enmity', ['RISE', 'TURNING POINT'],
      'As a boy of nine, about to leave for Spain with his father, Hannibal is made to swear an oath at the altar that he will never be a friend of Rome — a vow of lifelong enmity that becomes the animating purpose of his entire career.',
      svg_stack('A childhood vow that shaped a life', [
          {'n': 1, 'label': 'A boy asks to come to war', 'sub': 'nine-year-old Hannibal begs to join Hamilcar in Spain', 'color': '#7e22ce'},
          {'n': 2, 'label': 'The altar oath', 'sub': 'swears never to be a friend of Rome', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A purpose for life', 'sub': 'the vow becomes his defining, lifelong mission', 'color': '#a16207'},
      ], takeaway='A single childhood moment fixed the direction of his whole life — enmity to Rome as a sacred duty.', accent=AC),
      bg='After the First Punic War, <b>Hamilcar Barca</b> set out to build a new power base in <b>Spain</b> to compensate for the losses — and to prepare revenge.',
      people='<b>Hamilcar Barca</b>, the father; the boy <b>Hannibal</b>; the Carthaginian gods at whose altar the oath was sworn.',
      what='By the famous account, Hamilcar made the nine-year-old Hannibal <b>swear at the altar</b> that he would <b>never be a friend of Rome</b> — a story Hannibal himself later told a foreign king.',
      crux='He was raised from childhood with a <b>single, sacred purpose</b> — an unusual clarity of mission that drove decades of relentless effort.',
      conseq='Everything Hannibal did — Spain, the Alps, Cannae — flowed from this early-implanted vow of enmity.',
      matters='A purpose absorbed young and held as sacred can direct an entire life with rare and dangerous focus.'),

    E('spain', '237–228 BC', 'Building an empire in Spain', ['RISE', 'BATTLE', 'REFORM'],
      'The Barca family turns Spain into a private Carthaginian empire — conquering its tribes, mining its silver, and raising a superb professional army loyal to the family — creating the wealth and the war machine Hannibal will one day march on Rome.',
      svg_row('A family builds a war-base', [
          {'n': 1, 'label': 'Conquer the Spanish tribes', 'sub': 'Hamilcar and Hasdrubal subdue Iberia', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Silver and manpower', 'sub': 'rich mines fund a loyal, professional army', 'color': '#a16207'},
          {'n': 3, 'label': 'A Barcid power base', 'sub': 'an empire loyal to the family, not just Carthage', 'color': '#166534'},
      ], edge_labels=['yields', 'becomes'], takeaway='Spain gave the Barcas the money and army that made a second war with Rome possible.', accent=AC),
      bg='Denied Sicily, Carthage’s Barcid faction expanded into <b>Spain (Iberia)</b>, exploiting its silver mines and warlike peoples to rebuild Carthaginian power.',
      people='<b>Hamilcar Barca</b>, then his son-in-law <b>Hasdrubal the Fair</b>; the Iberian and Celtiberian tribes; Hannibal, growing up on campaign.',
      what='Over a decade the Barcas <b>conquered much of southern and eastern Spain</b>, founded cities (like New Carthage), exploited the <b>silver mines</b>, and raised a formidable army — a base of wealth and soldiers largely independent of the home government.',
      crux='They built a <b>self-funding military power</b> far from Carthage’s cautious Senate — the resources for war without the politicians’ leash.',
      conseq='This army and treasury were the foundation of Hannibal’s invasion of Italy; the family’s independence also worried Rome.',
      matters='Great campaigns rest on a hidden foundation of money and manpower built up long in advance — the war is won in the years before it starts.'),

    E('command', '221 BC', 'Command at twenty-six', ['RISE', 'POLITICS', 'TURNING POINT'],
      'When his brother-in-law is assassinated, the army in Spain acclaims Hannibal as its general — a charismatic, battle-hardened commander of twenty-six who shares every hardship with his men and inspires an almost fanatical loyalty.',
      svg_stack('The making of a beloved general', [
          {'n': 1, 'label': 'Hasdrubal assassinated, 221 BC', 'sub': 'the command in Spain falls vacant', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The army acclaims Hannibal', 'sub': 'the soldiers choose Hamilcar’s son, aged 26', 'color': '#7e22ce'},
          {'n': 3, 'label': 'First among his men', 'sub': 'shares their food, sleep and danger — inspires fierce loyalty', 'color': '#166534'},
      ], takeaway='He led not from behind but among his men — earning a devotion that held his multi-ethnic army together for 15 years.', accent=AC),
      bg='After Hamilcar’s death, his son-in-law <b>Hasdrubal the Fair</b> led the Spanish army until he was assassinated in 221 BC.',
      people='the soldiers of the Spanish army; <b>Hannibal</b>, now their acclaimed leader; his brothers <b>Hasdrubal</b> and <b>Mago</b>.',
      what='The army <b>proclaimed the 26-year-old Hannibal</b> its commander. Ancient writers describe him sharing his soldiers’ hardships, sleeping on the ground among them, first into battle and last to rest — inspiring extraordinary loyalty.',
      crux='His authority rested on <b>shared hardship and personal example</b>, not just birth — the source of the cohesion of his diverse army.',
      conseq='That loyalty let him hold together an army of Africans, Spaniards and Gauls, unpaid and unreinforced, on hostile soil for over a decade.',
      matters='The deepest loyalty is earned by leaders who share their followers’ dangers — presence, not rank, binds an army.'),

    E('saguntum', '219 BC', 'Saguntum — lighting the fuse', ['BATTLE', 'POLITICS', 'TURNING POINT'],
      'Hannibal deliberately besieges and storms Saguntum, a Spanish city under Rome’s protection — a calculated provocation that gives Rome no choice but war, exactly the war he has been preparing for all his life.',
      svg_row('Engineering the war he wanted', [
          {'n': 1, 'label': 'Saguntum, a Roman ally', 'sub': 'a city Rome had pledged to protect', 'color': '#a16207'},
          {'n': 2, 'label': 'Hannibal besieges it', 'sub': 'takes it after eight months, defying Rome', 'color': '#7e22ce'},
          {'n': 3, 'label': 'Rome declares war', 'sub': 'the Second Punic War begins, 218 BC', 'color': '#b91c1c'},
      ], edge_labels=['attacked', 'triggers'], takeaway='He chose the moment and the pretext — provoking the war on his own terms and timing.', accent=AC),
      bg='<b>Saguntum</b> was a city in eastern Spain allied to Rome, inside the sphere the Barcas were expanding into. Attacking it meant war.',
      people='the people of Saguntum, who resisted fiercely; the Roman Senate; Hannibal, who ignored Roman demands to desist.',
      what='In 219 BC Hannibal <b>besieged and, after about eight months, stormed Saguntum</b>. When Carthage refused to hand him over, Rome <b>declared war</b> — the Second Punic War had begun.',
      crux='He forced the war <b>at a time of his choosing</b>, with his army ready and Rome caught off guard — seizing the initiative before a shot was fired.',
      conseq='The war he provoked would rage for 17 years and bring Rome closer to destruction than any conflict before Hannibal.',
      matters='The side that chooses when and how a war begins holds a powerful edge — initiative is itself a weapon.'),
]

# ==================================================================  PHASE 2 — THE ALPS
PHASE_ALPS = [
    E('march', '218 BC', 'The march that stunned the world', ['BATTLE', 'TURNING POINT'],
      'Rather than wait to be invaded, Hannibal does the unthinkable — he marches his whole army overland from Spain, through southern Gaul, to strike Rome in its own homeland, seizing an initiative no one believed possible.',
      svg_stack('An offensive no one expected', [
          {'n': 1, 'label': 'Rome plans to invade', 'sub': 'expects to fight in Spain and Africa', 'color': '#a16207'},
          {'n': 2, 'label': 'Hannibal marches on Italy', 'sub': 'leaves Spain with ~50,000+ men and war elephants', 'color': '#7e22ce'},
          {'n': 3, 'label': 'The war comes to Italy', 'sub': 'he seizes the initiative and the whole strategy', 'color': '#b91c1c'},
      ], takeaway='He refused to fight the war Rome expected — and took it straight to the enemy’s heartland.', accent=AC),
      bg='Rome expected to fight the war in Spain and Africa, using its naval supremacy. Hannibal chose the opposite — a land invasion of Italy itself.',
      people='the Roman consuls preparing overseas expeditions; Hannibal’s multi-ethnic army; the Gallic tribes along the route.',
      what='In 218 BC Hannibal <b>set out overland from Spain</b> with a large army and war elephants, crossing the Pyrenees and heading for the Alps and Italy — upending Rome’s entire war plan.',
      crux='He grasped that <b>attacking the enemy’s homeland</b> would throw Rome onto the defensive and rally Italy’s discontented peoples.',
      conseq='The audacity dislocated Roman strategy and brought years of war to Italian soil.',
      matters='Doing the thing the enemy believes impossible can overturn their whole plan before battle is even joined.'),

    E('rhone', 'Aug 218 BC', 'Crossing the Rhône — elephants on rafts', ['BATTLE'],
      'Hannibal reaches the Rhône to find hostile Gauls barring the far bank — so he sends a force secretly upstream to attack from behind, then ferries his entire army and its terrified war elephants across the great river on rafts.',
      svg_row('Forcing a defended river', [
          {'n': 1, 'label': 'Gauls hold the far bank', 'sub': 'a hostile crossing under attack', 'color': '#a16207'},
          {'n': 2, 'label': 'A flanking force upstream', 'sub': 'crosses secretly and hits the Gauls from behind', 'color': '#7e22ce'},
          {'n': 3, 'label': 'Elephants ferried over', 'sub': 'the army and elephants crossed on rafts', 'color': '#166534'},
      ], edge_labels=['countered by', 'then'], takeaway='He solved a defended crossing with deception and engineering — a preview of his tactical style.', accent=AC),
      bg='To reach Italy, Hannibal had to cross the <b>Rhône</b>, where hostile Gallic tribes gathered to stop him at the water’s edge.',
      people='the local Gauls; Hannibal’s engineers and Numidian cavalry; the mahouts managing the elephants.',
      what='Hannibal sent a detachment <b>upstream to cross and attack the Gauls from the rear</b>, then ferried his army and <b>war elephants across on rafts</b> and boats, brushing aside the resistance.',
      crux='He met a defended obstacle not head-on but with <b>manoeuvre and surprise</b> — the hallmark of his generalship.',
      conseq='Across the Rhône, he pressed on toward the Alps, evading the Roman army sent to intercept him.',
      matters='Obstacles yield to the commander who attacks them indirectly — flank and surprise beat frontal force.'),

    E('alps', 'Autumn 218 BC', 'The crossing of the Alps', ['BATTLE', 'TRAGEDY', 'TRIUMPH'],
      'Hannibal leads his army over the Alps in early winter — through snow, ambushing tribes, landslides and precipices that swallow men and animals — an ordeal that costs him half his army but delivers him into Italy where Rome least expects him.',
      svg_stack('The ordeal that became legend', [
          {'n': 1, 'label': 'Into the mountains, early winter', 'sub': 'snow, cold, and treacherous paths', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Ambushes and landslides', 'sub': 'hostile tribes and the terrain itself kill thousands', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Descends into Italy', 'sub': 'arrives with perhaps half his army — but arrives', 'color': '#166534'},
      ], takeaway='He paid a terrible price to appear where Rome thought no army could come — surprise bought with blood.', accent=AC),
      bg='The <b>Alps</b> in early winter were considered an impassable barrier for an army with elephants and baggage. That is exactly why Hannibal chose the route.',
      people='the mountain tribes who ambushed him; his exhausted, freezing soldiers; the surviving elephants; his officers holding the column together.',
      what='Over roughly two weeks Hannibal crossed the Alps through <b>snow, ambushes, rockfalls and precipices</b>, losing perhaps <b>half his army and many animals</b> — but debouched into northern Italy, behind Rome’s defences.',
      crux='He accepted <b>catastrophic losses to achieve strategic surprise</b> — appearing in Italy itself, where no Roman army was ready.',
      conseq='His arrival stunned Rome and drew the Gauls of northern Italy, no friends of Rome, to his side, replenishing his ranks.',
      matters='Some victories require paying a fearful upfront price for surprise — the boldest move is often the one thought impossible.'),
]

# ==================================================================  PHASE 3 — THE VICTORIES
PHASE_ITALY = [
    E('trebia', 'Dec 218 BC', 'The Trebia — the first trap', ['BATTLE', 'TRIUMPH'],
      'In his first great battle in Italy, Hannibal lures an eager Roman consul across an icy river at dawn on an empty stomach, then springs a hidden force upon his rear — annihilating a Roman army and announcing a new kind of general.',
      svg_stack('Bait, cold, and a hidden ambush', [
          {'n': 1, 'label': 'Provoke the eager consul', 'sub': 'Numidian horsemen lure Sempronius out', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Cross an icy river, unfed', 'sub': 'Romans wade the freezing Trebia at dawn, hungry', 'color': '#a16207'},
          {'n': 3, 'label': 'Ambush from concealment', 'sub': 'Mago’s hidden force strikes the Roman rear', 'color': '#b91c1c'},
      ], takeaway='He engineered the enemy’s exhaustion and then ambushed him — winning before the main lines even clashed.', accent=AC),
      bg='In late 218 BC the impetuous consul <b>Sempronius Longus</b> was eager to fight. Hannibal set out to use that eagerness against him near the <b>Trebia</b> river.',
      people='the consul <b>Sempronius</b>; Hannibal’s brother <b>Mago</b>, who led the concealed ambush; the Numidian cavalry who baited the trap.',
      what='Hannibal lured the Romans across the <b>icy Trebia</b> at dawn, cold and unfed, then sprang <b>Mago’s hidden force on their rear</b>, destroying much of the Roman army.',
      crux='He fought with <b>terrain, weather, hunger and concealment</b> as weapons — shaping the battle before contact so the outcome was half-decided.',
      conseq='The victory secured his hold on northern Italy and swelled his army with Gallic recruits.',
      matters='The greatest tacticians win the battle in its setup — choosing conditions that beat the enemy before swords cross.'),

    E('trasimene', 'Jun 217 BC', 'Lake Trasimene — the perfect ambush', ['BATTLE', 'TRIUMPH'],
      'Hannibal hides his entire army in the mist along a lake shore and lets a whole Roman army march into the defile — then falls on them from the hills in one of the largest and most complete ambushes in military history.',
      svg_stack('An army swallowed whole', [
          {'n': 1, 'label': 'A road trapped by lake and hills', 'sub': 'a narrow defile beside Lake Trasimene', 'color': '#7e22ce'},
          {'n': 2, 'label': 'The army hidden in mist', 'sub': 'Hannibal conceals his whole force on the heights', 'color': '#a16207'},
          {'n': 3, 'label': 'The Romans marched in and destroyed', 'sub': '~15,000 killed, including the consul Flaminius', 'color': '#b91c1c'},
      ], takeaway='He ambushed not a detachment but an entire consular army — a feat almost without parallel.', accent=AC),
      bg='In 217 BC the consul <b>Flaminius</b> pursued Hannibal recklessly. Hannibal chose the shore of <b>Lake Trasimene</b>, where hills and water formed a natural trap.',
      people='the consul <b>Gaius Flaminius</b>, killed in the battle; Hannibal’s concealed army; the trapped Roman legions.',
      what='Hannibal <b>hid his army in the morning mist</b> along the lakeside road and let the Roman column march fully in, then <b>attacked from the heights</b>, destroying the army and killing Flaminius — perhaps 15,000 Romans died.',
      crux='He turned <b>terrain and weather into a cage</b>, ambushing an entire army — an almost unheard-of tactical achievement.',
      conseq='With two consular armies destroyed, panic gripped Rome; the road to the city seemed open.',
      matters='Discipline and patience in concealment can deliver total victory — the trap that is never sprung early is the deadliest.'),

    E('fabius', '217 BC', 'Fabius — the enemy who refused to fight', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'Rome answers Hannibal’s genius with a counter-intuitive strategy: the dictator Fabius shadows him, harasses his foragers, but refuses all battle — denying Hannibal the decisive victory he needs and inventing the “Fabian” strategy of exhaustion.',
      svg_compare('Two strategies collide',
        {'head': 'Hannibal', 'color': '#7e22ce', 'items': ['seeks a decisive battle', 'unbeatable in open field', 'needs Italy’s allies to defect']},
        {'head': 'Fabius “the Delayer”', 'color': '#166534', 'items': ['refuses pitched battle', 'harasses and shadows', 'trades space and time for survival']},
        'Fabius could not beat Hannibal — so he refused to let Hannibal beat him.',
        'Against a superior tactician, denying battle can be smarter than fighting it.', AC),
      bg='After Trasimene, Rome appointed <b>Quintus Fabius Maximus</b> dictator. Recognising he could not out-fight Hannibal, Fabius chose not to fight him at all.',
      people='<b>Fabius Maximus</b>, “Cunctator” (the Delayer); his impatient critics in Rome; Hannibal, hunting a battle he could not get.',
      what='Fabius <b>shadowed Hannibal, cut off foragers and stragglers, and refused open battle</b> — frustrating Hannibal’s need for a decisive win, though the strategy was unpopular and mocked at Rome.',
      crux='He understood that Hannibal’s strength was <b>the pitched battle</b> — so the counter was to deny him one and win by attrition and time.',
      conseq='Fabian caution kept Rome in the war, but Roman impatience with it led straight to the disaster of Cannae.',
      matters='Sometimes the wisest response to a superior opponent is to refuse the game they excel at — patience can defeat brilliance.'),

    E('cannae', 'Aug 216 BC', 'Cannae — the masterpiece of annihilation', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'At Cannae Hannibal faces the largest army Rome has ever fielded — and destroys it utterly, deliberately letting his centre give way so the Romans push into a trap, then closing his wings and cavalry around them in a total encirclement studied by soldiers ever since.',
      svg_stack('The double envelopment', [
          {'n': 1, 'label': 'A weak, bulging centre', 'sub': 'Hannibal’s middle gives ground on purpose', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Romans push in — and are surrounded', 'sub': 'the crescent folds around the massed legions', 'color': '#a16207'},
          {'n': 3, 'label': 'Cavalry closes the rear', 'sub': 'the trap seals; ~50,000+ Romans killed in a day', 'color': '#b91c1c'},
      ], takeaway='He turned the enemy’s greater numbers into a fatal weakness — packing them into a cauldron of their own making.', accent=AC),
      bg='In 216 BC Rome massed perhaps <b>80,000 men</b> under the consuls <b>Varro and Paullus</b> to crush Hannibal at <b>Cannae</b> in the south.',
      people='the consuls <b>Varro</b> and <b>Paullus</b> (Paullus died); Hannibal’s brother Mago and cavalry commander Hasdrubal; the encircled legions.',
      what='Hannibal formed a <b>convex line that deliberately gave way</b>, drawing the Romans in, while his cavalry routed the Roman horse and swept round the rear. His infantry wings closed the flanks — <b>encircling and destroying</b> the huge army; some 50,000–70,000 Romans died in a single day.',
      crux='He used the enemy’s <b>own mass and momentum against them</b>, converting superior numbers into a helpless, packed-in target — the perfect battle of annihilation.',
      conseq='Cannae was Rome’s worst defeat; southern Italian cities defected, and Rome faced its gravest crisis. Yet it did not surrender.',
      matters='The double envelopment at Cannae remains the model of the decisive battle — but even total tactical victory could not, alone, win the war.'),
]

# ==================================================================  PHASE 4 — THE LONG WAR
PHASE_STALEMATE = [
    E('aftercannae', '216 BC', '“You know how to win, not how to use a victory”', ['POLITICS', 'TURNING POINT'],
      'In the hours after Cannae, Hannibal’s cavalry commander urges him to march on Rome at once — but Hannibal hesitates, and the chance, if it ever existed, passes, prompting the famous rebuke that he knew how to win a battle but not how to exploit it.',
      svg_row('The victory that was not pressed home', [
          {'n': 1, 'label': 'Total victory at Cannae', 'sub': 'Rome’s army destroyed; the city reeling', 'color': '#7e22ce'},
          {'n': 2, 'label': '“March on Rome now!”', 'sub': 'Maharbal urges an immediate strike at the city', 'color': '#a16207'},
          {'n': 3, 'label': 'Hannibal hesitates', 'sub': 'no siege train, exhausted army — the moment passes', 'color': '#b91c1c'},
      ], edge_labels=['then', 'but'], takeaway='Whether or not Rome could have been taken, the failure to try became the war’s great “what if.”', accent=AC),
      bg='After Cannae, Hannibal’s cavalry general <b>Maharbal</b> reportedly urged an immediate march on Rome, promising Hannibal could dine on the Capitol in days.',
      people='<b>Maharbal</b>, the impatient cavalry commander; Hannibal, weighing his exhausted army and lack of siege equipment; the terrified but defiant Roman Senate.',
      what='Hannibal <b>declined to march directly on Rome</b>, lacking a siege train and a secure base. Maharbal’s alleged rebuke — “you know how to win a victory but not how to use one” — became legendary.',
      crux='His strategy depended on <b>Rome’s allies defecting and Rome suing for peace</b>, not on storming the city — but Rome did neither.',
      conseq='Rome refused to negotiate even after Cannae, and the war settled into a grinding stalemate Hannibal could not win alone.',
      matters='Winning battles is not the same as winning wars — a decisive victory unused, or unusable, can decide nothing.'),

    E('capua', '216–211 BC', 'The southern allies — and the winter of Capua', ['POLITICS', 'BATTLE'],
      'After Cannae many southern Italian cities defect to Hannibal, above all wealthy Capua, which becomes his base — but the comforts of the rich city are later blamed for softening his army, and Rome methodically besieges and retakes the defectors.',
      svg_stack('Allies gained, then lost', [
          {'n': 1, 'label': 'Cities defect after Cannae', 'sub': 'Capua and others join Hannibal', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Capua as winter base', 'sub': 'wealthy comforts — later blamed for softening the army', 'color': '#a16207'},
          {'n': 3, 'label': 'Rome retakes the defectors', 'sub': 'methodical sieges recover Capua (211 BC) and others', 'color': '#b91c1c'},
      ], takeaway='He won allies with victory but could not protect them — and Rome punished defection relentlessly.', accent=AC),
      bg='Hannibal’s strategy relied on peeling Italy’s cities away from Rome. After Cannae, several — most importantly <b>Capua</b> — defected to him.',
      people='the citizens of <b>Capua</b> and other defecting cities; the Roman armies that besieged them; Hannibal, unable to defend them all.',
      what='Capua became Hannibal’s chief ally and base; legend says its luxuries <b>weakened his army’s discipline</b>. Unable to be everywhere, Hannibal watched Rome <b>besiege and recapture</b> Capua (211 BC) and other defectors, punishing them harshly.',
      crux='He could <b>win allies by victory but not shield them</b> — one army could not defend a scattered coalition against Rome’s many legions.',
      conseq='As defectors were retaken and punished, others hesitated to join him — his strategy of unravelling Italy stalled.',
      matters='A coalition won by battlefield success collapses if you cannot protect its members — winning friends is easier than keeping them.'),

    E('attrition', '215–208 BC', 'The war of no reinforcements', ['BATTLE', 'TRAGEDY'],
      'Year after year Hannibal wins skirmishes and marches Italy’s length, but Carthage sends him almost no reinforcements, while Rome raises army after army — a war of attrition that slowly grinds down his irreplaceable veterans against an enemy that can always replace its losses.',
      svg_compare('The arithmetic that beat him',
        {'head': 'Hannibal', 'color': '#7e22ce', 'items': ['no reinforcements from home', 'irreplaceable veterans', 'wins battles, loses strength']},
        {'head': 'Rome', 'color': '#b91c1c', 'items': ['endless manpower reserves', 'raises new legions each year', 'absorbs defeats and continues']},
        'Rome could lose armies and go on; Hannibal could not replace a single veteran.',
        'Depth of resources can defeat brilliance if the war lasts long enough.', AC),
      bg='Cut off in Italy, Hannibal received little support from a divided Carthaginian government, while Rome’s vast Italian manpower let it rebuild after every defeat.',
      people='the Carthaginian Senate, cautious and distracted; Rome’s endless new legions; Hannibal’s dwindling band of veterans.',
      what='For years Hannibal roamed Italy <b>undefeated in the field but unreinforced</b>, while Rome <b>raised fresh armies</b> and reconquered his allies. His elite army slowly wore away with no means of replacement.',
      crux='The war became one of <b>attrition and resources</b>, where Rome’s depth beat Hannibal’s brilliance — a struggle his tactics could not win.',
      conseq='Rome shifted the war to Spain and Africa, aiming to cut Hannibal off from any hope of support.',
      matters='Tactical genius can be slowly strangled by an enemy with deeper resources — sustainable strength outlasts individual brilliance.'),

    E('metaurus', '207 BC', 'The Metaurus — a brother’s head', ['BATTLE', 'TRAGEDY', 'TURNING POINT'],
      'Hannibal’s brother Hasdrubal marches a second army over the Alps to reinforce him — but the Romans intercept and destroy it at the Metaurus before the brothers can join, and Hannibal learns of the disaster only when his brother’s severed head is thrown into his camp.',
      svg_stack('The reinforcement that never arrived', [
          {'n': 1, 'label': 'Hasdrubal crosses the Alps', 'sub': 'a second army marches to join Hannibal', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Intercepted at the Metaurus', 'sub': 'Romans destroy the army before the brothers unite', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A head thrown into camp', 'sub': 'Hannibal learns of it seeing his brother’s severed head', 'color': '#111827'},
      ], takeaway='The one chance to renew his strength was destroyed — and Hannibal saw in it “the doom of Carthage.”', accent=AC),
      bg='By 207 BC Hannibal’s only hope of reinforcement was his brother <b>Hasdrubal</b>, bringing a fresh army from Spain over the Alps.',
      people='<b>Hasdrubal Barca</b>, killed at the Metaurus; the Roman consuls <b>Nero</b> and <b>Livius</b>, who intercepted him; Hannibal, waiting in southern Italy.',
      what='The Romans intercepted and <b>destroyed Hasdrubal’s army at the Metaurus</b> river before it could reach Hannibal. They threw <b>Hasdrubal’s severed head</b> into Hannibal’s camp — his first news of the defeat. He reportedly said he saw in it the fate of Carthage.',
      crux='It ended his <b>last hope of reinforcement</b> and turned the strategic tide decisively against him.',
      conseq='Confined to the far south of Italy, Hannibal could now only wait as the war moved to Africa.',
      matters='A single interception can decide a war — the reinforcement that never arrives can matter more than any battle won.'),
]

# ==================================================================  PHASE 5 — THE FALL
PHASE_FALL = [
    E('scipio', '210–204 BC', 'The pupil — Scipio takes the war to Carthage', ['BATTLE', 'POLITICS', 'TURNING POINT'],
      'A young Roman general, Scipio, studies Hannibal’s methods, conquers Carthaginian Spain using Hannibal’s own tricks, then carries the war to Africa itself — forcing Carthage to recall Hannibal to defend his homeland.',
      svg_row('The student turns the tables', [
          {'n': 1, 'label': 'Scipio masters Spain', 'sub': 'takes New Carthage; drives Carthage from Iberia', 'color': '#166534'},
          {'n': 2, 'label': 'Invades Africa, 204 BC', 'sub': 'lands near Carthage; wins over Numidian allies', 'color': '#a16207'},
          {'n': 3, 'label': 'Hannibal recalled', 'sub': 'Carthage summons him home to defend the city', 'color': '#7e22ce'},
      ], edge_labels=['then', 'forces'], takeaway='Rome found its own Hannibal — a general who learned his methods and turned them against him.', accent=AC),
      bg='<b>Publius Cornelius Scipio</b> (later “Africanus”), whose father and uncle Hannibal’s forces had killed, rose as Rome’s answer — a general who studied and adapted Hannibal’s tactics.',
      people='<b>Scipio Africanus</b>; the Numidian king <b>Masinissa</b>, who allied with Rome; Carthage’s alarmed Senate.',
      what='Scipio <b>conquered Carthaginian Spain</b> (taking New Carthage by a bold coup), then <b>invaded Africa</b> in 204 BC and won over Numidian cavalry — forcing Carthage to <b>recall Hannibal</b> from Italy after 15 years.',
      crux='Rome won by producing a commander who could <b>match Hannibal’s methods</b> and strike at Carthage’s own heart.',
      conseq='Hannibal left Italy undefeated in the field but strategically beaten, to make a last stand for Carthage itself.',
      matters='Even the greatest innovator can be undone by a student who masters and adapts their methods — and attacks the home base.'),

    E('zama', '202 BC', 'Zama — the great general’s only defeat', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'On African soil Hannibal finally meets Scipio in open battle — but Scipio neutralises his elephants, and the superior Roman-allied Numidian cavalry wins the day, handing Hannibal the first and only decisive defeat of his career and ending the war.',
      svg_stack('How the master was finally beaten', [
          {'n': 1, 'label': 'Elephants neutralised', 'sub': 'Scipio opens lanes; the charge does little harm', 'color': '#a16207'},
          {'n': 2, 'label': 'Numidian cavalry decisive', 'sub': 'now allied to Rome, it wins the cavalry fight', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Hannibal defeated at last', 'sub': 'his veteran core destroyed; the war lost', 'color': '#7e22ce'},
      ], takeaway='Beaten with his own kind of tactics and robbed of his cavalry edge, Hannibal lost the one battle that mattered most.', accent=AC),
      bg='In 202 BC Hannibal, back in Africa, faced Scipio at <b>Zama</b>. Crucially, the superb <b>Numidian cavalry</b> that had won Hannibal’s battles now fought for Rome under Masinissa.',
      people='<b>Scipio Africanus</b>; <b>Masinissa</b>, whose Numidian horse decided the field; Hannibal, commanding a hastily-assembled army.',
      what='Scipio <b>opened lanes to let the elephant charge pass harmlessly</b>, matched Hannibal’s infantry, and his <b>Numidian cavalry returned to crush the Carthaginian rear</b> — destroying Hannibal’s army in his only decisive defeat.',
      crux='Deprived of his <b>cavalry superiority</b> and out-generalled by his own methods, Hannibal lost the battle that ended the war.',
      conseq='Carthage sued for peace on harsh terms, stripped of its empire and navy; Rome became the master of the western Mediterranean.',
      matters='Even the greatest can be beaten when their key advantage is taken away — and when the enemy has learned their game.'),

    E('statesman', '202–195 BC', 'The reformer — greatness in peace', ['POLITICS', 'REFORM'],
      'Defeated in war, Hannibal proves himself a brilliant statesman in peace — elected Carthage’s chief magistrate, he roots out corruption and reforms the finances so successfully that a recovering Carthage alarms Rome, which demands his removal.',
      svg_row('A second career in government', [
          {'n': 1, 'label': 'Elected chief magistrate (suffete)', 'sub': 'turns from war to governing Carthage', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Roots out corruption', 'sub': 'reforms finances; curbs the oligarchs’ graft', 'color': '#166534'},
          {'n': 3, 'label': 'Carthage recovers — Rome alarmed', 'sub': 'a reviving Carthage frightens Rome into acting', 'color': '#b91c1c'},
      ], edge_labels=['then', 'so'], takeaway='He was as gifted in reforming a state as in commanding an army — too gifted for Rome’s comfort.', accent=AC),
      bg='After the war, a defeated Carthage was burdened by indemnities and riddled with corruption among its ruling oligarchy.',
      people='the corrupt Carthaginian oligarchs he challenged; the citizens who elected him; the watchful Roman Senate.',
      what='Elected <b>suffete</b> (chief magistrate), Hannibal <b>attacked corruption and reformed the state finances</b> so effectively that Carthage could pay its indemnity early — a revival that alarmed Rome into demanding his surrender.',
      crux='He showed that his genius was <b>not only military</b> — his administrative reforms revived a broken state, which was precisely why Rome feared him still.',
      conseq='Rome’s pressure forced Hannibal to flee into exile rather than be handed over.',
      matters='Great ability is versatile — and a defeated enemy who proves brilliant in peace can seem as dangerous as in war.'),

    E('exile', '195–183 BC', 'Exile and the last cup', ['EXILE', 'DEATH', 'TRAGEDY'],
      'Hunted by Rome even in defeat, Hannibal spends his last years wandering the courts of the East, advising Rome’s enemies and winning a naval battle for a foreign king — until, cornered at last with no escape, he takes poison rather than be handed to Rome.',
      svg_stack('The long twilight of an exile', [
          {'n': 1, 'label': 'Flees to eastern kings', 'sub': 'serves Antiochus III, then others, against Rome', 'color': '#7e22ce'},
          {'n': 2, 'label': 'Still feared by Rome', 'sub': 'Rome pursues him from court to court', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Poison, c. 183 BC', 'sub': 'cornered at last, he takes his own life', 'color': '#111827'},
      ], takeaway='Rome never rested until the man who had terrified it was gone — and he denied them the satisfaction of his capture.', accent=AC),
      bg='After fleeing Carthage, Hannibal took service with Rome’s eastern enemies, above all the Seleucid king <b>Antiochus III</b>, always plotting against Rome.',
      people='<b>Antiochus III</b> and later kings who sheltered him; the Roman agents pursuing him; King <b>Prusias of Bithynia</b>, at whose court he died.',
      what='In exile Hannibal advised Rome’s enemies and even <b>won a naval battle</b> for a foreign king. Finally cornered by Roman demands at the court of <b>Prusias of Bithynia</b>, he <b>took poison</b> (c. 183 BC) rather than be surrendered — reportedly saying he would relieve Rome of its long fear.',
      crux='Even a defeated, exiled Hannibal was so feared that Rome <b>would not rest until he was dead</b> — a measure of the terror he had inspired.',
      conseq='He died free but landless; a generation later Rome destroyed Carthage itself, erasing his city from the earth.',
      matters='Some figures loom so large that their enemies fear them for life — Hannibal’s shadow outlasted his armies and his state.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Hannibal Barca marched an army with elephants over the Alps, shattered Rome’s legions in the greatest battles of the ancient world, and roamed Italy undefeated for over a decade — yet still lost the war, because Rome could replace its armies and he could not. He is the ultimate study in <b>tactical genius against strategic depth, the audacity of the impossible march, and the difference between winning battles and winning a war.</b></p>
<div class="ov-quote">“We will either find a way, or make one.”<span>— attributed to Hannibal, on crossing the Alps</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born to a father humiliated by Rome and sworn to eternal enmity → builds a war-base in Spain → provokes war at Saguntum → marches over the Alps into Italy → destroys Roman armies at the Trebia, Trasimene and, supremely, Cannae → cannot take Rome or hold his allies → is slowly ground down for want of reinforcement → loses his brother at the Metaurus → is recalled and beaten by his own pupil Scipio at Zama → reforms Carthage in peace → dies a hunted exile by his own hand.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🐘</div><h4>The impossible march</h4><p>Crossing the Alps with an army and elephants — audacity that redefined what was possible.</p></div>
  <div class="ov-card"><div class="i">⚔️</div><h4>Cannae</h4><p>The double envelopment remains the textbook model of the perfect battle of annihilation.</p></div>
  <div class="ov-card"><div class="i">🛡️</div><h4>Strategy beats tactics</h4><p>Rome’s depth and the Fabian strategy beat the greatest tactician of the age.</p></div>
  <div class="ov-card"><div class="i">🔥</div><h4>The feared enemy</h4><p>So dangerous that Rome hunted him to death in exile years after his defeat.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Oath</b><small> 264–219 BC</small><p>Carthage, Spain, and a boy’s vow against Rome.</p></div>
  <div><b>2 · The Alps</b><small> 218 BC</small><p>The march and crossing that stunned the world.</p></div>
  <div><b>3 · The Victories</b><small> 218–216 BC</small><p>Trebia, Trasimene and the masterpiece of Cannae.</p></div>
  <div><b>4 · The Long War</b><small> 216–207 BC</small><p>Stalemate, attrition, and a brother’s head.</p></div>
  <div><b>5 · The Fall</b><small> 210–183 BC</small><p>Scipio, Zama, reform, exile and the last cup.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Hamilcar Barca', 'role': 'father', 'color': '#7e22ce',
     'bio': 'The undefeated Carthaginian general of the First Punic War who built the family’s power base in Spain and instilled in Hannibal a lifelong enmity to Rome.',
     'rel': 'The father who made him swear eternal hatred of Rome.'},
    {'name': 'Hasdrubal Barca', 'role': 'brother', 'color': '#a16207',
     'bio': 'Hannibal’s brother, who held Spain and later led a second army over the Alps to reinforce him — only to be intercepted and killed at the Metaurus.',
     'rel': 'The brother whose death ended Hannibal’s last hope.'},
    {'name': 'Fabius Maximus', 'role': 'Roman adversary', 'color': '#166534',
     'bio': 'The Roman dictator “Cunctator” (the Delayer) who refused pitched battle with Hannibal, harassing him and trading time for survival — the Fabian strategy.',
     'rel': 'The enemy who beat him by refusing to fight.'},
    {'name': 'Scipio Africanus', 'role': 'Roman adversary', 'color': '#b91c1c',
     'bio': 'The brilliant young Roman who studied Hannibal’s methods, conquered Carthaginian Spain, invaded Africa, and defeated Hannibal at Zama.',
     'rel': 'The pupil who turned Hannibal’s own tactics against him.'},
    {'name': 'Maharbal', 'role': 'cavalry commander', 'color': '#0e7490',
     'bio': 'Hannibal’s Numidian cavalry commander, who reportedly urged him to march on Rome after Cannae with the famous rebuke about not knowing how to use a victory.',
     'rel': 'The lieutenant who begged him to finish Rome.'},
]

KEY_EVENTS = [
    ('247 BC', 'Hannibal born', 'Son of Hamilcar Barca, in a Carthage humbled by Rome.'),
    ('c. 237 BC', 'The oath', 'Swears eternal enmity to Rome as a boy.'),
    ('221 BC', 'Takes command in Spain', 'Acclaimed general at 26.'),
    ('219 BC', 'Siege of Saguntum', 'Provokes the Second Punic War.'),
    ('218 BC', 'Crosses the Alps', 'Invades Italy, losing half his army.'),
    ('218 BC', 'The Trebia', 'First great victory in Italy.'),
    ('217 BC', 'Lake Trasimene', 'Destroys an army in a total ambush.'),
    ('216 BC', 'Cannae', 'Annihilates Rome’s largest army.'),
    ('207 BC', 'The Metaurus', 'Hasdrubal killed; last hope lost.'),
    ('202 BC', 'Zama', 'Defeated by Scipio; the war lost.'),
    ('c. 183 BC', 'Death in exile', 'Takes poison to avoid capture.'),
]

MASTER = [
    {'year': '247 BC', 'age': 'born', 'phase': 'The Oath', 'title': 'Born in Carthage', 'desc': 'Son of Hamilcar Barca.'},
    {'year': '237 BC', 'age': 'age ~9', 'phase': 'The Oath', 'title': 'The oath against Rome', 'desc': 'Sworn as a boy.'},
    {'year': '221 BC', 'age': 'age 26', 'phase': 'The Oath', 'title': 'Command in Spain', 'desc': 'Acclaimed by the army.'},
    {'year': '218 BC', 'age': 'age 29', 'phase': 'The Alps', 'title': 'Crosses the Alps', 'desc': 'Invades Italy.'},
    {'year': '216 BC', 'age': 'age 31', 'phase': 'The Victories', 'title': 'Cannae', 'desc': 'His masterpiece.'},
    {'year': '207 BC', 'age': 'age 40', 'phase': 'The Long War', 'title': 'The Metaurus', 'desc': 'His brother killed.'},
    {'year': '202 BC', 'age': 'age 45', 'phase': 'The Fall', 'title': 'Zama', 'desc': 'His only defeat.'},
    {'year': '183 BC', 'age': 'age ~64', 'phase': 'The Fall', 'title': 'Death in exile', 'desc': 'Poison, to escape Rome.'},
]

SOURCES = [
    ('Britannica — Hannibal', 'https://www.britannica.com/biography/Hannibal-Carthaginian-general-247-183-BCE'),
    ('World History Encyclopedia — Hannibal', 'https://www.worldhistory.org/hannibal/'),
    ('Britannica — Second Punic War', 'https://www.britannica.com/event/Second-Punic-War'),
    ('Britannica — Battle of Cannae', 'https://www.britannica.com/event/Battle-of-Cannae'),
    ('World History Encyclopedia — Battle of Zama', 'https://www.worldhistory.org/Battle_of_Zama/'),
    ('Wikipedia — Hannibal', 'https://en.wikipedia.org/wiki/Hannibal'),
]

def build_meta():
    return {
        'pid': 'gm-hannibal.html', 'kind': 'man', 'emoji': '🐘', 'accent': AC,
        'name': 'Hannibal Barca', 'years': '247–183 BC', 'group': 'Ancient Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Carthaginian who crossed the Alps with elephants, annihilated Rome’s armies at Cannae, and roamed Italy undefeated for years — yet lost the war to Rome’s bottomless resources.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Oath', 'type': 'timeline',
             'intro': 'Born into a Carthage humiliated by Rome, raised in Spain and sworn from childhood to eternal enmity, he takes command at 26 and provokes the war he has prepared for all his life.', 'events': PHASE_RISE},
            {'id': 'alps', 'label': '2 · The Alps', 'type': 'timeline',
             'intro': 'He refuses the war Rome expects and marches overland from Spain, forcing the Rhône and crossing the Alps in winter — losing half his army to reach Italy where no one believed an army could come.', 'events': PHASE_ALPS},
            {'id': 'italy', 'label': '3 · The Victories', 'type': 'timeline',
             'intro': 'In three shattering battles — the Trebia, Trasimene and the immortal double-envelopment at Cannae — he destroys Rome’s armies and brings the Republic to the brink.', 'events': PHASE_ITALY},
            {'id': 'stalemate', 'label': '4 · The Long War', 'type': 'timeline',
             'intro': 'Unable to take Rome or hold his allies, and starved of reinforcements while Rome raises army after army, he is slowly ground down — until his brother’s severed head tells him the war is lost.', 'events': PHASE_STALEMATE},
            {'id': 'fall', 'label': '5 · The Fall', 'type': 'timeline',
             'intro': 'His own pupil Scipio carries the war to Africa and beats him at Zama; Hannibal reforms a broken Carthage in peace, then dies a hunted exile by his own hand.', 'events': PHASE_FALL,
             'sources': SOURCES, 'srcnote': 'Our knowledge comes mainly from the Greek Polybius and the Roman Livy; famous quotes and casualty figures are read critically.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
