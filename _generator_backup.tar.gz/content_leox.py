# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Giovanni de’ Medici — Pope Leo X.
The Medici pope who crowned Rome with Renaissance glory and let the Reformation slip his grasp."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#9f1239'  # Medici papal crimson

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MEDICI PRINCE
PHASE_PRINCE = [
    E('origins', '1475–1489', 'Son of the Magnificent — a Medici bred for the Church', ['RISE'],
      'Born the second son of Lorenzo the Magnificent, the ruler of Florence and greatest patron of the Renaissance, young Giovanni is destined from childhood not for trade or war but for the Church — the family’s ladder into the power and wealth of Rome.',
      svg_stack('A dynasty aims its son at Rome', [
          {'n': 1, 'label': 'Born a Medici prince, 1475', 'sub': 'second son of Lorenzo the Magnificent of Florence', 'color': '#9f1239'},
          {'n': 2, 'label': 'Groomed for the Church', 'sub': 'tonsured as a boy; a humanist education under Poliziano', 'color': '#a16207'},
          {'n': 3, 'label': 'A ladder into Rome', 'sub': 'the family destines him for high ecclesiastical office', 'color': '#166534'},
      ], takeaway='He was raised not to earn the Church but to inherit it — a Medici career in holy orders from the cradle.', accent=AC),
      bg='<b>Giovanni de’ Medici</b> was born in 1475, the second son of <b>Lorenzo the Magnificent</b>, the banker-statesman who ruled Florence and made it the beating heart of the Renaissance.',
      people='his father <b>Lorenzo the Magnificent</b>; the humanist tutors Poliziano and Pico della Mirandola; the Medici bank behind them all.',
      what='Marked early for the Church, Giovanni received a <b>brilliant humanist education</b> in Florence while his family engineered a swift ecclesiastical career for him — the surest route to Medici influence in Rome.',
      crux='For the Medici the Church was <b>a family asset</b> — a son in holy orders meant a foothold in the wealthiest court in Christendom.',
      conseq='Every honour was bent toward one end: a red hat, and one day the papal tiara itself.',
      matters='Great families invested sons in the Church as a career, not a calling — a truth that would shape, and later shame, the papacy.'),

    E('cardinal', '1489–1492', 'A cardinal at thirteen', ['RISE', 'POLITICS'],
      'Through his father’s influence Giovanni is made a cardinal at the astonishing age of thirteen — first in secret, then publicly enthroned in the College — the youngest prince of the Church, sent to Rome with his dying father’s warning to curb its excesses ringing in his ears.',
      svg_row('The boy who put on the red hat', [
          {'n': 1, 'label': 'Made cardinal in secret, 1489', 'sub': 'named in pectore by Innocent VIII, aged 13', 'color': '#9f1239'},
          {'n': 2, 'label': 'Publicly enthroned, 1492', 'sub': 'the youngest cardinal joins the Curia at sixteen', 'color': '#a16207'},
          {'n': 3, 'label': 'Lorenzo’s parting counsel', 'sub': 'his father warns him against Rome’s corruption', 'color': '#166534'},
      ], edge_labels=['then', 'with'], takeaway='A thirteen-year-old wore the cardinal’s red — proof of how far Medici money and favour could reach into the Church.', accent=AC),
      bg='In 1489 Pope Innocent VIII, bound to the Medici by marriage and money, named the boy Giovanni a cardinal <b>in pectore</b> — held in secret until he came of age.',
      people='Pope <b>Innocent VIII</b>, who granted the red hat; <b>Lorenzo the Magnificent</b>, whose diplomacy won it; the older cardinals of the Curia.',
      what='Giovanni was created a <b>cardinal at thirteen</b> and publicly admitted to the College in 1492, entering Rome as its youngest prince — his father sending a famous letter urging restraint amid the city’s vices.',
      crux='His elevation showed the papacy already <b>captured by dynastic politics</b>, dispensing its highest offices to children of the powerful.',
      conseq='Months later Lorenzo died, and the Medici world Giovanni knew began to crumble.',
      matters='A Church that sold its highest honours to teenagers had lost the moral ground it would soon need to defend against reformers.'),

    E('exile', '1494–1512', 'Exile and restoration — the Medici cast down and raised again', ['RISE', 'TRAGEDY', 'TURNING POINT'],
      'When the Medici are violently expelled from Florence, Giovanni spends eighteen years as a wandering exile — travelling Europe, biding his time — until, as a papal legate, he is captured at a great battle and then rides back into Florence on foreign arms as the family’s fortunes are restored.',
      svg_stack('Down into exile, back on foreign arms', [
          {'n': 1, 'label': 'Medici expelled from Florence, 1494', 'sub': 'the family driven out; Giovanni wanders Europe', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Captured at Ravenna, 1512', 'sub': 'taken as papal legate in battle, then escapes', 'color': '#78350f'},
          {'n': 3, 'label': 'Restored to Florence, 1512', 'sub': 'Spanish arms and the sack of Prato return the Medici', 'color': '#166534'},
      ], takeaway='Eighteen years of exile taught him patience — and that fortune, once lost, could be won back by allies and arms.', accent=AC),
      bg='In 1494, as French armies swept Italy, the Florentines rose and <b>expelled the Medici</b>. Giovanni fled into a long exile across Europe.',
      people='the Florentine republic that cast them out; his brother <b>Giuliano</b>; the Spanish and papal forces that restored them.',
      what='After years of wandering, Cardinal Giovanni served as <b>papal legate</b> and was captured at the Battle of Ravenna (1512); soon after, <b>Spanish troops and the brutal sack of Prato</b> restored the Medici to Florence.',
      crux='The family’s fortunes swung violently between <b>exile and triumph</b> — a lesson that power rested on patrons, armies and nerve.',
      conseq='With the Medici back in Florence and Giovanni its true master, he stood one step from the greatest prize of all.',
      matters='Dynastic power is never secure — Giovanni’s survival through disaster proved that patience and alliance could reverse even total defeat.'),
]

# ==================================================================  PHASE 2 — THE THRONE OF PETER
PHASE_THRONE = [
    E('conclave', '1513', 'Elected pope at thirty-seven — the first Medici pontiff', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'On the death of the warlike Julius II, the cardinals turn to the young, genial Giovanni de’ Medici — still not even a priest — and elect him pope. Ordained and consecrated within days, he takes the name Leo X, the first of his family ever to wear the tiara.',
      svg_row('A Medici ascends the throne of Peter', [
          {'n': 1, 'label': 'Julius II dies, 1513', 'sub': 'the warrior pope leaves the throne empty', 'color': '#78350f'},
          {'n': 2, 'label': 'Conclave elects Giovanni', 'sub': 'the young cardinal chosen, not yet a priest', 'color': '#9f1239'},
          {'n': 3, 'label': 'Crowned Leo X', 'sub': 'the first Medici pope, ordained days before', 'color': '#a16207'},
      ], edge_labels=['so', 'becomes'], takeaway='At thirty-seven a Medici sat on Peter’s throne — the family’s ancient ambition finally, dazzlingly fulfilled.', accent=AC),
      bg='In February 1513 the aggressive <b>Julius II</b> — the pope who had waged war across Italy and begun the new St Peter’s — died, leaving the throne vacant.',
      people='the late <b>Julius II</b>; the cardinals of the conclave weary of war; Giovanni’s cousin <b>Giulio</b>, his closest ally.',
      what='The conclave elected <b>Giovanni de’ Medici pope on 9 March 1513</b>, aged 37. Not yet ordained, he was made priest and bishop within days and crowned <b>Leo X</b> — the first Medici pontiff.',
      crux='After Julius’s wars the cardinals wanted a <b>peaceable, cultivated pope</b> — and got a Medici prince of pleasure and patronage.',
      conseq='Leo inherited a papacy rich in prestige, a half-built basilica, and a treasury he would swiftly exhaust.',
      matters='The choice of a genial patron over a reformer set the tone of a papacy that would charm Rome and misjudge the coming storm.'),

    E('enjoy', '1513', '“Let us enjoy it” — the pleasure-loving pope', ['POLITICS'],
      'Leo throws himself into the papacy as into a feast — genial, cultured and endlessly extravagant, turning Rome into a glittering Renaissance court of banquets, hunts, poets and pageantry, and (so the story goes) declaring that since God had given him the papacy, he meant to enjoy it.',
      svg_stack('The papacy as a Renaissance feast', [
          {'n': 1, 'label': 'A Medici on Peter’s throne', 'sub': 'genial, learned, extravagant, fond of the good life', 'color': '#9f1239'},
          {'n': 2, 'label': '“God has given us the papacy”', 'sub': '“…let us enjoy it” — the famous quip, attribution debated', 'color': '#a16207'},
          {'n': 3, 'label': 'Rome as a Renaissance court', 'sub': 'banquets, hunts, poets, music and pageantry', 'color': '#166534'},
      ], takeaway='He treated the throne as a gift to be savoured — brilliant patron, generous host, and heedless of the reckoning to come.', accent=AC),
      bg='Leo brought to the papacy the tastes of a Medici prince: a love of art, music, letters, hunting and lavish display.',
      people='the poets, musicians and scholars of his court; his cousin <b>Giulio de’ Medici</b>; the bankers who funded the spending.',
      what='Leo made Rome a <b>brilliant Renaissance court</b>. The line <b>“God has given us the papacy, let us enjoy it”</b> — long attributed to him though its authenticity is debated — captures his reputation for pleasure and generosity.',
      crux='He saw the papacy less as a burden of reform than as <b>a splendour to be enjoyed and shared</b> — culture over discipline.',
      conseq='His generosity dazzled contemporaries but drained the treasury and dulled the Church’s appetite for reform.',
      matters='A leader’s temperament sets an institution’s course — Leo’s ease and love of splendour left Rome radiant but unready.'),

    E('lateran', '1512–1517', 'Councils and concordats — the Church at his command', ['POLITICS', 'REFORM'],
      'Leo presides over the closing sessions of the Fifth Lateran Council and strikes the Concordat of Bologna with the King of France — measures that leave the papacy looking strong and centralized on paper, even as the real reforming energy the Church needed is smothered by complacency.',
      svg_row('Strong on paper, complacent in fact', [
          {'n': 1, 'label': 'Fifth Lateran Council closes, 1517', 'sub': 'reform decrees passed but weakly enforced', 'color': '#9f1239'},
          {'n': 2, 'label': 'Concordat of Bologna, 1516', 'sub': 'pact with Francis I over French Church appointments', 'color': '#a16207'},
          {'n': 3, 'label': 'Power gathered in Rome', 'sub': 'the papacy strong on paper, smug in practice', 'color': '#166534'},
      ], edge_labels=['and', 'yet'], takeaway='He tidied the Church’s paperwork and pacts while ignoring the deeper rot — reform decreed but never truly enforced.', accent=AC),
      bg='Leo inherited the <b>Fifth Lateran Council</b> (opened 1512) and Italy’s tangled diplomacy, including rivalry with France over the Church in French lands.',
      people='King <b>Francis I</b> of France, his partner in the Concordat; the council fathers; the Curia’s entrenched interests.',
      what='Leo closed the <b>Fifth Lateran Council (1517)</b> with reform decrees that were barely enforced, and signed the <b>Concordat of Bologna (1516)</b> with Francis I, sharing control of Church appointments in France.',
      crux='He secured <b>outward strength and settlements</b> while leaving the abuses that fed popular anger untouched.',
      conseq='The chance for real reform from within passed, just as a monk in Germany prepared to force the question from without.',
      matters='Reform announced but not enforced is worse than none — it advertised the gap between the Church’s words and its conduct.'),
]

# ==================================================================  PHASE 3 — THE GOLDEN AGE
PHASE_GOLD = [
    E('raphael', '1513–1520', 'Patron of Raphael — the papacy as art', ['CULTURE', 'TRIUMPH'],
      'Leo makes Raphael the ornament of his court — painter, and from 1514 architect of St Peter’s — commissioning the great Vatican frescoes, the tapestry cartoons and his own famous portrait, and marshalling the supreme artist of the age to glorify the Medici papacy.',
      svg_stack('Genius harnessed to papal glory', [
          {'n': 1, 'label': 'Raphael in papal service', 'sub': 'court painter and, from 1514, architect of St Peter’s', 'color': '#9f1239'},
          {'n': 2, 'label': 'The Vatican masterworks', 'sub': 'the Stanze, the tapestry cartoons, Leo’s portrait', 'color': '#a16207'},
          {'n': 3, 'label': 'Beauty as papal power', 'sub': 'art marshalled to exalt the Medici papacy', 'color': '#166534'},
      ], takeaway='He put the greatest artist of the age at the service of his throne — the papacy of Leo dressed in Raphael’s beauty.', accent=AC),
      bg='Rome under Leo became the capital of the High Renaissance, and <b>Raphael</b> its presiding genius, already at work in the Vatican.',
      people='<b>Raphael</b> of Urbino; his workshop of pupils; the humanist courtiers who devised the programmes.',
      what='Leo employed Raphael on the <b>Vatican Stanze</b>, the great <b>tapestry cartoons</b> for the Sistine Chapel, and the celebrated <b>portrait of Leo with two cardinals</b>, and named him architect of St Peter’s.',
      crux='For Leo, <b>art was the language of papal majesty</b> — beauty made the Medici throne radiant and unquestionable.',
      conseq='The patronage produced masterpieces still central to Western art, and costs that swelled the papal debt.',
      matters='Leo’s Rome shows culture as an instrument of power — and the priceless art it left outlived the papacy that paid for it.'),

    E('stpeters', '1506–1520', 'Rebuilding St Peter’s — the grandest work in Christendom', ['CULTURE'],
      'Leo carries forward Julius II’s staggering project to demolish and rebuild St Peter’s Basilica on a colossal new scale — the most ambitious and expensive building in Christendom — a monument to Rome’s glory whose ruinous cost drives the fatal hunt for money.',
      svg_row('A basilica whose cost consumed everything', [
          {'n': 1, 'label': 'The old basilica torn down', 'sub': 'Julius II began the vast new St Peter’s, 1506', 'color': '#78350f'},
          {'n': 2, 'label': 'Leo carries it forward', 'sub': 'Bramante, then Raphael, direct the works', 'color': '#9f1239'},
          {'n': 3, 'label': 'A ruinous ambition', 'sub': 'the immense cost demands ever more money', 'color': '#b91c1c'},
      ], edge_labels=['then', 'but'], takeaway='The grandest church in the world needed a bottomless purse — and the search for that money lit the Reformation.', accent=AC),
      bg='In 1506 <b>Julius II</b> began tearing down the thousand-year-old basilica of St Peter to raise a new one of unmatched scale. The work fell to Leo to continue.',
      people='the architects <b>Bramante</b> and <b>Raphael</b>; Julius II, who began it; the faithful of Europe, whose money would fund it.',
      what='Leo pressed on with the <b>new St Peter’s Basilica</b>, the costliest project in Christendom — but the enormous expense forced the papacy to seek vast new revenues.',
      crux='The basilica became <b>a monument of glory and a bottomless drain</b> — its cost the pressure behind the fatal fundraising.',
      conseq='To pay for St Peter’s, Leo turned to the sale of indulgences — the spark that would ignite the Reformation.',
      matters='The most glorious church in the world and the schism that shattered the Church sprang from the same source: the cost of St Peter’s.'),

    E('learning', '1513–1521', 'Rome reborn — patron of learning and the arts', ['CULTURE', 'REFORM'],
      'Beyond painting and building, Leo pours patronage into scholarship — reviving the Roman university, endowing Greek studies, and drawing poets, humanists and artists to his court — until his very name is given to a golden age of Renaissance culture.',
      svg_stack('A humanist pope, a golden age', [
          {'n': 1, 'label': 'A humanist on the throne', 'sub': 'poets, scholars and artists flock to his Rome', 'color': '#9f1239'},
          {'n': 2, 'label': 'The Roman university revived', 'sub': 'the Sapienza refounded; Greek studies endowed', 'color': '#a16207'},
          {'n': 3, 'label': 'The Age of Leo', 'sub': 'his name given to a golden age of culture', 'color': '#166534'},
      ], takeaway='His patronage reached from paint to philology — a reign so brilliant that later ages named the whole era after him.', accent=AC),
      bg='Raised among the humanists of Lorenzo’s Florence, Leo carried their love of classical learning into the papacy.',
      people='the humanist scholars and poets of the Curia; the professors of the revived Roman university; the printers and collectors of Rome.',
      what='Leo <b>revived the Roman university (the Sapienza)</b>, endowed chairs including <b>Greek studies</b>, and gathered writers and artists so that Rome eclipsed even Florence as a cultural capital.',
      crux='He believed the papacy should be <b>the greatest patron in Christendom</b> — protector of arts and letters as well as faith.',
      conseq='His court set a standard of Renaissance splendour, remembered as the “Age of Leo,” but at crushing expense.',
      matters='Leo’s reign is a peak of Renaissance civilization — a reminder that dazzling cultural achievement can coincide with institutional decay.'),
]

# ==================================================================  PHASE 4 — THE REFORMATION IGNITES
PHASE_REFORM = [
    E('indulgences', '1515–1517', 'Selling indulgences to build St Peter’s', ['POLITICS', 'TRAGEDY'],
      'To fund St Peter’s, Leo authorizes a great sale of indulgences — pardons for sin sold for money — preached in Germany by the friar Johann Tetzel, with half the takings secretly repaying a bishop’s debt to the Fugger bank: a scheme that outrages German piety and lights a fuse.',
      svg_compare('A fundraising scheme lights a fuse', {
          'head': 'The money machine', 'color': '#9f1239', 'items': [
              'Indulgences sold to fund St Peter’s',
              'Preached in Germany by the friar Johann Tetzel',
              'Half the proceeds repay Albert of Brandenburg’s debt',
              'Marketed with slogans on ringing coin',
          ]},
          {'head': 'The gathering storm', 'color': '#b91c1c', 'items': [
              'Sold as remission of sin for cash',
              'Outrages German piety and princes',
              'Seen as naked Roman greed',
              'Hands a monk his cause',
          ]},
          verdict='A scheme to finish a basilica became the trigger of the Reformation.',
          takeaway='Rome sold heaven to pay for stone — and in Germany that bargain looked like corruption worth defying.', accent=AC),
      bg='St Peter’s needed money. Leo proclaimed a special <b>indulgence</b> whose proceeds would help fund the basilica.',
      people='the friar <b>Johann Tetzel</b>, its star preacher; Archbishop <b>Albert of Brandenburg</b>, repaying his debts from the takings; the <b>Fugger</b> bankers behind it.',
      what='Leo authorized an <b>indulgence campaign</b> in Germany; Tetzel’s aggressive preaching — with half the money quietly repaying Albert’s loan to buy his archbishopric — made the sale of pardons a scandal.',
      crux='The scheme turned <b>salvation into a transaction</b>, exposing the papacy at its most worldly and corrupt.',
      conseq='In Wittenberg, an Augustinian monk named Martin Luther drafted his objections.',
      matters='The Reformation began not over doctrine alone but over money — the sale of grace to pay for Rome’s ambitions.'),

    E('theses', '1517', 'The 95 Theses — a monk defies Rome', ['POLITICS', 'TURNING POINT'],
      'In October 1517 the monk Martin Luther publishes his Ninety-five Theses attacking the sale of indulgences — and, carried on the new printing press across Germany, the challenge spreads like wildfire, while a complacent Leo dismisses it as a mere squabble among monks.',
      svg_stack('A local protest becomes a wildfire', [
          {'n': 1, 'label': 'Luther’s 95 Theses, Oct 1517', 'sub': 'an Augustinian monk attacks the indulgence trade', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Printed and spread', 'sub': 'the press carries the challenge across Germany', 'color': '#78350f'},
          {'n': 3, 'label': 'Leo shrugs it off', 'sub': 'dismissed as a mere quarrel among monks', 'color': '#9f1239'},
      ], takeaway='The pope treated an earthquake as a tremor — the fatal misjudgement that let a local protest grow into a movement.', accent=AC),
      bg='Provoked by Tetzel’s preaching, <b>Martin Luther</b>, a professor and Augustinian friar at Wittenberg, set out his objections for debate.',
      people='<b>Martin Luther</b>, the challenger; the German public and princes who rallied to him; Leo X, far away in Rome.',
      what='Luther issued his <b>Ninety-five Theses (October 1517)</b> condemning indulgences; <b>printing</b> spread them across Germany within weeks, igniting a debate Leo at first waved aside as a monkish dispute.',
      crux='Leo <b>underestimated the scale</b> of the challenge, mistaking a theological revolt with deep popular roots for a passing quarrel.',
      conseq='By the time Rome took Luther seriously, the movement had grown beyond containment.',
      matters='The gravest failures of leadership are failures of perception — Leo could not see a world-historical revolt for what it was.'),

    E('excommunication', '1520–1521', 'Exsurge Domine — excommunicating Luther, too late', ['POLITICS', 'TRAGEDY'],
      'When Rome finally acts, Leo issues the bull Exsurge Domine condemning Luther’s teachings and demanding recantation — but Luther defiantly burns the bull, and Leo’s formal excommunication in 1521 comes too late to stop a revolt that has already split the Church.',
      svg_row('Condemnation that came too late', [
          {'n': 1, 'label': 'Exsurge Domine, 1520', 'sub': 'the bull condemns 41 of Luther’s propositions', 'color': '#9f1239'},
          {'n': 2, 'label': 'Luther burns the bull', 'sub': 'defiance in public, not submission', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Decet Romanum, 1521', 'sub': 'Luther excommunicated — but the revolt has spread', 'color': '#78350f'},
      ], edge_labels=['met by', 'then'], takeaway='Rome’s thunderbolt fell on a movement already beyond its reach — excommunication only confirmed the break.', accent=AC),
      bg='By 1520 Luther’s writings had swept Germany. Leo could no longer ignore him and moved to condemn his teaching.',
      people='<b>Martin Luther</b>, defiant; Leo X and his theologians; the German princes now shielding the reformer.',
      what='Leo issued <b>Exsurge Domine (June 1520)</b>, condemning 41 of Luther’s propositions and threatening excommunication; Luther <b>publicly burned the bull</b>, and Leo excommunicated him with <b>Decet Romanum Pontificem (January 1521)</b>.',
      crux='The papacy answered a movement with <b>legal condemnation alone</b>, too late and too weak to halt a revolt with princes and people behind it.',
      conseq='Luther, condemned by pope and soon defiant before the Emperor at Worms, became the founder of a lasting schism.',
      matters='Authority that reacts too slowly forfeits control — Leo’s bulls proclaimed his power precisely as it was slipping away.'),
]

# ==================================================================  PHASE 5 — DEBTS AND DEATH
PHASE_END = [
    E('urbino', '1516–1517', 'The War of Urbino and the plot of the cardinals', ['POLITICS', 'BATTLE'],
      'Determined to carve out a princedom for his family, Leo wages a costly war to seize the Duchy of Urbino for his nephew — draining the treasury to enrich the Medici — and, when a conspiracy of cardinals plots to poison him, packs the College with dozens of loyal new members.',
      svg_stack('Family ambition drains the treasury', [
          {'n': 1, 'label': 'War for Urbino, 1516–17', 'sub': 'Leo seizes the duchy for his nephew Lorenzo', 'color': '#9f1239'},
          {'n': 2, 'label': 'A costly nepotist war', 'sub': 'the treasury drained to enrich the Medici', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The cardinals’ plot, 1517', 'sub': 'a conspiracy to poison him; he packs the College', 'color': '#78350f'},
      ], takeaway='He spent the Church’s money on his family’s ambitions — and met a murder plot by flooding the College with loyalists.', accent=AC),
      bg='Like the popes before him, Leo used the papacy to advance his family, seeking a state for his nephew <b>Lorenzo de’ Medici</b>.',
      people='his nephew <b>Lorenzo</b>, intended Duke of Urbino; the dispossessed <b>della Rovere</b> duke; the plotting cardinals led by Petrucci.',
      what='Leo fought an expensive <b>war to seize Urbino</b> for his nephew (1516–17), draining papal funds; exposing a <b>conspiracy of cardinals</b> to poison him, he executed a ringleader and created <b>31 new cardinals</b> to secure the College.',
      crux='He bent the papacy to <b>Medici dynastic gain</b>, spending its wealth and authority on his family’s fortunes.',
      conseq='The wars and nepotism deepened the debts and the cynicism just as Rome faced its greatest spiritual challenge.',
      matters='Nepotism and vanity wars hollowed the papacy from within — squandering on family the strength it needed for the Reformation.'),

    E('debts', '1517–1521', 'The bankrupt papacy — spending without end', ['POLITICS', 'TRAGEDY'],
      'Leo’s boundless generosity meets an empty purse: within a few years he has spent the treasury Julius II left him, run up a colossal debt, pawned the papal jewels and sold Church offices for cash — the most open-handed of popes leaving the papacy drowning in red ink.',
      svg_compare('The most generous pope, the emptiest purse', {
          'head': 'The spending', 'color': '#9f1239', 'items': [
              'A lavish court of banquets and hunts',
              'Patronage of artists and scholars',
              'The war for Urbino',
              'Building the new St Peter’s',
          ]},
          {'head': 'The reckoning', 'color': '#b91c1c', 'items': [
              'The treasury emptied within two years',
              'A debt near 400,000 ducats by 1521',
              'The papal jewels pawned',
              'Church offices sold to raise cash',
          ]},
          verdict='Leo spent faster than any pope could raise — and sold the Church itself to keep pace.',
          takeaway='His open hand exhausted a full treasury and left the papacy so deep in debt it had to sell its own offices.', accent=AC),
      bg='Leo inherited a well-filled treasury from Julius II, but his patronage, wars and court cost far more than the papacy could bear.',
      people='the <b>Fugger</b> and other bankers; the officials whose posts he sold; the creditors circling the Curia.',
      what='Leo <b>exhausted the treasury within two years</b> and ran up a debt approaching <b>400,000 ducats</b> by 1521, <b>pawning papal jewels and selling offices and cardinals’ hats</b> to stay solvent.',
      crux='His spending was <b>structurally ruinous</b> — the pursuit of glory and generosity with no regard for the accounts.',
      conseq='The financial desperation drove the very abuses — including indulgences and the sale of offices — that fed the Reformation.',
      matters='Fiscal recklessness has moral costs — Leo’s debts forced the sales of grace and office that discredited the Church.'),

    E('death', '1521', 'Sudden death — and a church already splitting', ['DEATH', 'DEFEAT'],
      'In December 1521, at only forty-five, Leo dies suddenly of a fever, without the last rites, his treasury so empty his funeral is modest — leaving behind a Rome crowned with Renaissance splendour and a Western Church breaking irrevocably apart behind him.',
      svg_stack('A sudden end amid the wreckage', [
          {'n': 1, 'label': 'Dies suddenly, Dec 1521', 'sub': 'a fever takes him at 45, without last rites', 'color': '#78350f'},
          {'n': 2, 'label': 'The treasury empty', 'sub': 'debts so vast his funeral was a modest affair', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The Reformation unstoppable', 'sub': 'the Western Church breaking apart behind him', 'color': '#9f1239'},
      ], takeaway='He left the world as he had ruled it — brilliant, bankrupt, and blind to the schism his reign had let loose.', accent=AC),
      bg='By late 1521 Leo had reigned for eight years of splendour and crisis, the Reformation spreading and the papacy deep in debt.',
      people='his cousin <b>Giulio de’ Medici</b>, soon to reign as Clement VII; the mourning Roman court; the reformers beyond the Alps.',
      what='Leo <b>died suddenly of a fever on 1 December 1521</b>, aged 45, without the last sacraments; the papacy was so indebted that his obsequies were meagre, and the Church he left was fracturing.',
      crux='He died having <b>adorned Rome and lost half of Christendom</b> — the split with Luther already beyond repair.',
      conseq='His cousin would become Pope Clement VII, under whom the Reformation and the Sack of Rome would only deepen the disaster.',
      matters='Leo’s reign is the great paradox of the Renaissance papacy: cultural glory and spiritual catastrophe bound together in one man.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Giovanni de’ Medici — <b>Pope Leo X</b> — was the Renaissance papacy at its most brilliant and most blind. Son of Lorenzo the Magnificent, made a cardinal at thirteen, and elected pope at thirty-seven, he turned Rome into the dazzling capital of the High Renaissance, patron of Raphael and builder of St Peter’s. Yet to pay for that splendour he sold indulgences that provoked Martin Luther’s revolt — and, mistaking a world-historical movement for a monkish quarrel, he let the Reformation split the Western Church. He is the ultimate study in <b>cultural glory bought at the price of spiritual catastrophe.</b></p>
<div class="ov-quote">“God has given us the papacy, let us enjoy it.”<span>— attributed to Leo X (authenticity debated)</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born a Medici prince and made a cardinal at thirteen → cast into exile and restored to Florence → elected the first Medici pope as Leo X → makes Rome a Renaissance glory under Raphael and rebuilds St Peter’s → sells indulgences to fund it, provoking Luther’s 95 Theses → excommunicates Luther too late to stop the schism → and dies in 1521 with the treasury empty and the Church splitting apart.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🎨</div><h4>Patron of the Renaissance</h4><p>Made Rome the capital of art and learning under Raphael.</p></div>
  <div class="ov-card"><div class="i">⛪</div><h4>Builder of St Peter’s</h4><p>Drove the grandest project in Christendom — and its ruinous cost.</p></div>
  <div class="ov-card"><div class="i">📜</div><h4>Spark of the Reformation</h4><p>His indulgences provoked Luther and split the Western Church.</p></div>
  <div class="ov-card"><div class="i">💰</div><h4>The bankrupt throne</h4><p>Spent the papacy into vast debt, pawning jewels and selling offices.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Medici Prince</b><small> 1475–1512</small><p>Son of the Magnificent; cardinal at thirteen; exile and return.</p></div>
  <div><b>2 · The Throne of Peter</b><small> 1513–1517</small><p>Elected pope; the pleasure-loving pontiff; councils and concordats.</p></div>
  <div><b>3 · The Golden Age</b><small> 1513–1521</small><p>Raphael, St Peter’s and a Rome reborn.</p></div>
  <div><b>4 · The Reformation</b><small> 1515–1521</small><p>Indulgences, the 95 Theses, and Luther condemned too late.</p></div>
  <div><b>5 · Debts and Death</b><small> 1516–1521</small><p>Nepotist wars, a bankrupt papacy, and a sudden end.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Lorenzo the Magnificent', 'role': 'his father', 'color': '#a16207',
     'bio': 'The banker-statesman who ruled Florence and led the Renaissance; he secured his son’s red hat and warned him against Rome’s corruption.',
     'rel': 'The father who bred him for the Church and its highest office.'},
    {'name': 'Martin Luther', 'role': 'the challenger', 'color': '#b91c1c',
     'bio': 'The Augustinian monk whose 95 Theses attacked Leo’s indulgences and grew into the Reformation; Leo condemned and excommunicated him too late.',
     'rel': 'The reformer whose revolt Leo failed to grasp or contain.'},
    {'name': 'Raphael', 'role': 'his artist', 'color': '#166534',
     'bio': 'The supreme painter of the High Renaissance, made Leo’s court artist and architect of St Peter’s, who left the Vatican Stanze and Leo’s portrait.',
     'rel': 'The genius through whom Leo made the papacy a work of art.'},
    {'name': 'Julius II', 'role': 'his predecessor', 'color': '#78350f',
     'bio': 'The warrior pope who fought across Italy and began the new St Peter’s; his wars and building both passed to Leo to continue and to pay for.',
     'rel': 'The predecessor whose basilica — and its costs — Leo inherited.'},
    {'name': 'Giulio de’ Medici', 'role': 'cousin and heir', 'color': '#9f1239',
     'bio': 'Leo’s cousin and closest adviser, whom he raised to cardinal; he would soon reign as Pope Clement VII amid the Reformation and the Sack of Rome.',
     'rel': 'The kinsman at his side and his successor in the Medici papacy.'},
]

KEY_EVENTS = [
    ('1475', 'Giovanni de’ Medici born', 'Son of Lorenzo the Magnificent of Florence.'),
    ('1489', 'Made a cardinal at 13', 'Named in secret by Innocent VIII.'),
    ('1494', 'Medici exiled from Florence', 'The family driven out for eighteen years.'),
    ('1512', 'Restored to Florence', 'Spanish arms return the Medici.'),
    ('1513', 'Elected Pope Leo X', 'The first Medici pope, aged 37.'),
    ('1516', 'Concordat of Bologna', 'Pact with France; Lateran Council near its close.'),
    ('1517', 'Luther’s 95 Theses', 'Indulgence sales for St Peter’s spark revolt.'),
    ('1520', 'Exsurge Domine', 'Bull condemns Luther’s teaching.'),
    ('1521', 'Excommunicates Luther', 'Decet Romanum Pontificem — too late.'),
    ('1521', 'Death of Leo X', 'A church splitting, a treasury empty.'),
]

MASTER = [
    {'year': '1475', 'age': 'born', 'phase': 'The Medici Prince', 'title': 'Born a Medici', 'desc': 'Son of Lorenzo the Magnificent.'},
    {'year': '1489', 'age': 'age 13', 'phase': 'The Medici Prince', 'title': 'Cardinal at thirteen', 'desc': 'Named in secret to the College.'},
    {'year': '1513', 'age': 'age 37', 'phase': 'The Throne of Peter', 'title': 'Elected Leo X', 'desc': 'The first Medici pope.'},
    {'year': '1516', 'age': 'age 40', 'phase': 'The Golden Age', 'title': 'Rome’s cultural peak', 'desc': 'Raphael and St Peter’s.'},
    {'year': '1517', 'age': 'age 41', 'phase': 'The Reformation', 'title': 'The 95 Theses', 'desc': 'Luther defies Rome.'},
    {'year': '1521', 'age': 'age 45', 'phase': 'Debts and Death', 'title': 'Excommunicates Luther, then dies', 'desc': 'The Church splits; the throne is bankrupt.'},
]

SOURCES = [
    ('Britannica — Leo X', 'https://www.britannica.com/biography/Leo-X'),
    ('Catholic Encyclopedia — Pope Leo X', 'https://www.newadvent.org/cathen/09162a.htm'),
    ('Wikipedia — Pope Leo X', 'https://en.wikipedia.org/wiki/Pope_Leo_X'),
    ('Britannica — Reformation', 'https://www.britannica.com/event/Reformation'),
    ('Wikipedia — Ninety-five Theses', 'https://en.wikipedia.org/wiki/Ninety-five_Theses'),
]

def build_meta():
    return {
        'pid': 'gm-leox.html', 'kind': 'man', 'emoji': '🦁', 'accent': AC,
        'name': 'Giovanni de’ Medici (Leo X)', 'years': '1475–1521', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Medici pope who made Rome the glory of the Renaissance — patron of Raphael and builder of St Peter’s — yet whose indulgences provoked Luther and let the Reformation split the Western Church.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'prince', 'label': '1 · The Medici Prince', 'type': 'timeline',
             'intro': 'Born the son of Lorenzo the Magnificent and made a cardinal at thirteen, Giovanni is cast into exile with his family, then rides back into Florence as the Medici are restored.', 'events': PHASE_PRINCE},
            {'id': 'throne', 'label': '2 · The Throne of Peter', 'type': 'timeline',
             'intro': 'Elected pope at thirty-seven as the first Medici pontiff, the genial, pleasure-loving Leo makes Rome his court and rules the Church through councils and concordats.', 'events': PHASE_THRONE},
            {'id': 'gold', 'label': '3 · The Golden Age', 'type': 'timeline',
             'intro': 'Leo makes his papacy a work of art — patron of Raphael, builder of the new St Peter’s, and reviver of learning — until his name marks a golden age of Renaissance culture.', 'events': PHASE_GOLD},
            {'id': 'reform', 'label': '4 · The Reformation', 'type': 'timeline',
             'intro': 'To fund St Peter’s he sells indulgences, provoking Luther’s 95 Theses; mistaking a world-historical revolt for a monkish quarrel, he condemns and excommunicates Luther too late.', 'events': PHASE_REFORM},
            {'id': 'end', 'label': '5 · Debts and Death', 'type': 'timeline',
             'intro': 'Nepotist wars and boundless spending bankrupt the papacy, and in 1521 Leo dies suddenly — leaving Rome crowned with splendour and the Western Church breaking apart.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; the famous quip “let us enjoy it” is traditionally attributed to Leo X and its authenticity is debated.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
