# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Babur.
The Timurid boy-king who lost Samarkand, conquered Kabul, and founded the Mughal Empire at Panipat."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc
from content_babur_p1 import EVENTS as BB1
from content_babur_p2 import EVENTS as BB2
from content_babur_p3 import EVENTS as BB3
from content_babur_p4 import EVENTS as BB4
from content_babur_p5 import EVENTS as BB5
from content_babur_p6 import EVENTS as BB6

AC = '#0f766e'  # Timurid teal

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE BOY-KING OF FERGHANA
PHASE_RISE = [
    E('birth', '1483–1494', 'Blood of Timur and Genghis — a prince of Ferghana', ['RISE', 'ORIGINS'],
      'Born in 1483 in the little kingdom of Ferghana, Babur is heir to the two greatest conqueror-bloodlines of Asia — descended from Timur on his father’s side and Genghis Khan on his mother’s — a boy raised on the memory of empire in a fractured world of quarrelling Timurid cousins.',
      svg_row('Heir to two conquerors', [
          {'n': 1, 'label': 'Descendant of Timur', 'sub': 'Timurid prince through his father Umar Shaikh', 'color': '#0f766e'},
          {'n': 2, 'label': 'Descendant of Genghis Khan', 'sub': 'Mongol blood through his mother’s line', 'color': '#6d28d9'},
          {'n': 3, 'label': 'Born in Ferghana, 1483', 'sub': 'heir to a small realm and a vast legacy', 'color': '#a16207'},
      ], edge_labels=['and', 'so'], takeaway='Two of history’s greatest conquerors met in his veins — a legacy of empire that Babur was born to reclaim.', accent=AC),
      bg='<b>Zahir-ud-din Muhammad Babur</b> was born in 1483 in <b>Ferghana</b> (in modern Uzbekistan), a minor kingdom in the fractured Timurid world of Central Asia.',
      people='his father <b>Umar Shaikh Mirza</b>, ruler of Ferghana; his Mongol mother’s line; the many Timurid cousins who fought over the region.',
      what='Babur was descended from <b>Timur (Tamerlane)</b> on his father’s side and from <b>Genghis Khan</b> on his mother’s — the twin inheritances that gave him both a claim to empire and the name “Mughal” (Persian for Mongol).',
      crux='He carried the <b>bloodline of empire</b> into a world of petty, warring principalities — a giant legacy in a shrunken realm.',
      conseq='The dream of restoring Timur’s empire, above all of ruling <b>Samarkand</b>, would drive and torment him for decades.',
      matters='Ancestry set the ambition — Babur measured himself against Timur and Genghis, and would not be content with Ferghana alone.'),

    E('ferghana', '1494', 'A throne at eleven — the boy on the pigeon-tower', ['RISE', 'TURNING POINT'],
      'When his father dies in a freak accident — the dovecote he stood on collapses into a ravine — the eleven-year-old Babur suddenly inherits the throne of Ferghana, and must instantly fight rival uncles and rebellious begs to hold a kingdom he is far too young to rule.',
      svg_stack('A boy inherits a throne under siege', [
          {'n': 1, 'label': 'His father dies, 1494', 'sub': 'Umar Shaikh falls with a collapsing dovecote', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Babur crowned at eleven', 'sub': 'a child inherits the throne of Ferghana', 'color': '#0f766e'},
          {'n': 3, 'label': 'Uncles and begs close in', 'sub': 'rivals move at once to seize the boy’s realm', 'color': '#a16207'},
      ], takeaway='He became a king before he was a man — and had to fight for his crown from the first day he wore it.', accent=AC),
      bg='In 1494, Babur’s father died when the pigeon-house on a cliff’s edge gave way and plunged into a ravine — one of the vivid scenes Babur later recorded himself.',
      people='the boy-king <b>Babur</b>; his ambitious uncles, the rulers of Samarkand and Tashkent; the local <b>begs</b> (nobles) he had to master.',
      what='At <b>age eleven Babur became ruler of Ferghana (1494)</b>, immediately beset by rival relatives and factious nobles who sought to depose or dominate the child.',
      crux='He learned rule as a <b>fight for survival</b> — holding a throne against grown men who all wanted it for themselves.',
      conseq='Surviving these first crises hardened Babur, but his eyes were already fixed on the greater prize of Samarkand.',
      matters='Adversity was his teacher from childhood — the boy who fought to keep Ferghana grew into a man who never stopped fighting for more.'),

    E('warrior', '1494–1497', 'Mastering the begs — a boy learns to command', ['RISE', 'POLITICS'],
      'To survive, the young Babur must master hardened warrior-nobles twice his age — suppressing revolts, holding his begs’ loyalty and learning generalship in the saddle — turning himself, campaign by campaign, from an endangered child into a capable commander with his eyes fixed on Samarkand.',
      svg_stack('A child turns himself into a commander', [
          {'n': 1, 'label': 'Revolts and rival kin', 'sub': 'uncles and nobles test the boy-king', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Wins his begs’ loyalty', 'sub': 'holds his warriors by will and reward', 'color': '#0f766e'},
          {'n': 3, 'label': 'Learns war in the saddle', 'sub': 'grows into a real field commander', 'color': '#166534'},
      ], takeaway='He had no boyhood — he learned command the hard way, mastering grown warriors before he could master a kingdom.', accent=AC),
      bg='A child on a contested throne, Babur had to control seasoned <b>begs</b> (noble warriors) and beat back relatives who scented weakness.',
      people='the boy-king <b>Babur</b>; his warrior <b>begs</b>, whose loyalty he had to earn; the rival Timurid kin circling Ferghana.',
      what='Through the mid-1490s Babur <b>suppressed revolts and held his nobles’ loyalty</b>, learning generalship on campaign and transforming himself from an imperilled child into a competent commander.',
      crux='He converted <b>vulnerability into skill</b> — every crisis a lesson in leading hard men and fighting to keep a throne.',
      conseq='By his teens he was ready to reach for the family’s great prize — Timur’s capital of Samarkand.',
      matters='Leaders are forged under pressure — Babur’s ruthless apprenticeship made him the soldier who would one day take India.'),
]

# ==================================================================  PHASE 2 — THE HEARTBREAK OF SAMARKAND
PHASE_SAMARKAND = [
    E('samarkand', '1497–1501', 'Winning and losing Samarkand — the prize that slips away', ['BATTLE', 'TRAGEDY'],
      'Babur twice seizes Timur’s fabled capital of Samarkand — the crown jewel of his dynasty — and twice loses it almost at once, undone by long sieges, mutinous troops and the rising power of the Uzbek warlord Shaybani Khan, learning the bitter lesson that taking a city and holding it are different things.',
      svg_stack('The prize won, the prize lost', [
          {'n': 1, 'label': 'Takes Samarkand, 1497', 'sub': 'the fifteen-year-old wins Timur’s capital', 'color': '#0f766e'},
          {'n': 2, 'label': 'Cannot hold it', 'sub': 'sieges, hunger and mutiny drain his men', 'color': '#a16207'},
          {'n': 3, 'label': 'Loses it — and Ferghana too', 'sub': 'Shaybani’s Uzbeks close in', 'color': '#b91c1c'},
      ], takeaway='He grasped his heart’s desire twice and it crumbled in his hands each time — glory without the strength to keep it.', accent=AC),
      bg='<b>Samarkand</b>, Timur’s magnificent capital, was Babur’s obsession — the throne he believed was his by right of blood.',
      people='<b>Babur</b>, the young conqueror; the rival Timurid princes; the Uzbek chief <b>Shaybani Khan</b>, his rising nemesis.',
      what='Babur <b>captured Samarkand in 1497</b> but could not hold it; while he besieged and held the city, he lost Ferghana, and was left with neither — a pattern of hard-won triumph dissolving into loss.',
      crux='He learned the brutal gap between <b>conquest and control</b> — that a throne seized by a weak hand does not stay seized.',
      conseq='Repeated failure at Samarkand pushed Babur toward the realization that his future might lie not in Central Asia but elsewhere.',
      matters='Winning is not keeping — Babur’s Samarkand years taught him that endurance, not just daring, makes a lasting realm.'),

    E('shaybani', '1501–1504', 'Hunted and homeless — a king without a kingdom', ['TRAGEDY', 'TURNING POINT'],
      'Crushed by Shaybani Khan and driven out of both Samarkand and Ferghana, Babur becomes a wandering fugitive — a landless prince with a handful of loyal followers, hiding in the mountains, his Central Asian inheritance lost, forced to look south for a new destiny.',
      svg_row('From king to fugitive', [
          {'n': 1, 'label': 'Shaybani Khan triumphant', 'sub': 'the Uzbeks overrun the Timurid lands', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Babur driven out', 'sub': 'loses Samarkand and Ferghana alike', 'color': '#a16207'},
          {'n': 3, 'label': 'A wandering prince', 'sub': 'a king without a throne, seeking a new land', 'color': '#0f766e'},
      ], edge_labels=['so', 'leaving'], takeaway='Stripped of everything his fathers had ruled, he was forced to stop looking back to Samarkand and start looking south.', accent=AC),
      bg='By the early 1500s <b>Shaybani Khan</b> and his Uzbeks had shattered the Timurid principalities, driving Babur from all his ancestral lands.',
      people='<b>Shaybani Khan</b>, the conquering Uzbek; the few faithful <b>begs</b> who stayed with Babur; his loyal followers in exile.',
      what='Defeated and dispossessed, Babur spent years as a <b>landless wanderer</b> with a small band of followers, his Central Asian inheritance gone — a low point that turned his gaze toward Afghanistan and India.',
      crux='Total loss became a <b>turning outward</b> — with no future in the north, Babur had to seek a kingdom in a new direction.',
      conseq='This desperation led him to strike south for <b>Kabul</b> — the move that would change the course of Indian history.',
      matters='Catastrophe can redirect a life — losing his homeland forced Babur onto the road that led, eventually, to an empire.'),

    E('sarepul', '1500–1501', 'The disaster at Sar-e-Pul — a bitter surrender', ['BATTLE', 'TRAGEDY'],
      'Babur snatches Samarkand a second time, only to be crushed by Shaybani Khan at the Battle of Sar-e-Pul and besieged into starvation — forced at last to abandon the city in a night flight, and, by tradition, to surrender his own sister Khanzada to the victorious Uzbek to secure his escape.',
      svg_row('A second Samarkand, a harder fall', [
          {'n': 1, 'label': 'Retakes Samarkand, 1500', 'sub': 'a daring second seizure of the capital', 'color': '#0f766e'},
          {'n': 2, 'label': 'Beaten at Sar-e-Pul', 'sub': 'Shaybani routs him; the city is besieged', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A bitter surrender', 'sub': 'flees by night; gives his sister to Shaybani', 'color': '#78350f'},
      ], edge_labels=['then', 'and'], takeaway='His second Samarkand ended worse than the first — in starvation, flight and a personal sacrifice he never forgot.', accent=AC),
      bg='Babur seized <b>Samarkand a second time in 1500</b>, but <b>Shaybani Khan</b> returned in force to contest it.',
      people='<b>Babur</b>, the besieged king; <b>Shaybani Khan</b>, the Uzbek victor; Babur’s sister <b>Khanzada Begum</b>, given up to secure his flight.',
      what='At the <b>Battle of Sar-e-Pul (1501)</b> Shaybani routed Babur and besieged Samarkand until hunger forced surrender; Babur escaped by night, and by tradition ceded his sister <b>Khanzada</b> to the conqueror.',
      crux='He tasted <b>the full price of failure</b> — not just a lost city but personal humiliation and sacrifice.',
      conseq='The catastrophe deepened his ruin in Central Asia and pushed him ever closer to seeking a future in the south.',
      matters='Some defeats cut to the bone — Babur’s losses at Samarkand were personal as well as political, and steeled his resolve.'),
]

# ==================================================================  PHASE 3 — THE KINGDOM OF KABUL
PHASE_KABUL = [
    E('kabul', '1504', 'The seizure of Kabul — a new base of power', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'With nothing left to lose, Babur marches south and seizes Kabul in 1504 — winning at last a secure kingdom of his own, a mountain base astride the roads between Central Asia and India, and the platform from which he will one day launch his conquest of Hindustan.',
      svg_stack('A landless prince wins a kingdom', [
          {'n': 1, 'label': 'Marches south, 1504', 'sub': 'abandons the north for Afghanistan', 'color': '#0f766e'},
          {'n': 2, 'label': 'Seizes Kabul', 'sub': 'takes the mountain city and its rich passes', 'color': '#a16207'},
          {'n': 3, 'label': 'A secure base at last', 'sub': 'a throne of his own, and a road to India', 'color': '#166534'},
      ], takeaway='Out of total defeat he carved a real kingdom — Kabul gave the wanderer a throne and pointed him toward Hindustan.', accent=AC),
      bg='Landless after his defeats in the north, Babur led his followers south through the mountains toward <b>Kabul</b>, then held by a weak Arghun regime.',
      people='<b>Babur</b>, now a hardened commander; the followers who had endured exile with him; the rulers of Kabul he displaced.',
      what='In <b>1504 Babur captured Kabul</b>, securing a rich, defensible kingdom astride the trade and invasion routes — his first stable, lasting realm and the true foundation of his fortunes.',
      crux='Kabul gave him what Samarkand never could: a <b>secure base of power</b> he could actually hold and build upon.',
      conseq='From Kabul, Babur would launch raids into India and eventually mount the full invasion that founded the Mughal Empire.',
      matters='A secure base is the foundation of conquest — Babur’s empire began not in glory but in the modest, hard-won kingdom of Kabul.'),

    E('india_raids', '1505–1524', 'Eyes on Hindustan — probing the road to India', ['RISE', 'POLITICS'],
      'From his Kabul base Babur launches a series of raids and expeditions into the Punjab, studying the wealth and weakness of the Delhi Sultanate under Ibrahim Lodi — and, invited by discontented Afghan nobles who resent Lodi’s harsh rule, he begins to see the conquest of all Hindustan as his destiny.',
      svg_row('Probing the wealth of Hindustan', [
          {'n': 1, 'label': 'Raids into the Punjab', 'sub': 'expeditions from Kabul test India’s defences', 'color': '#0f766e'},
          {'n': 2, 'label': 'The Lodi Sultanate weakens', 'sub': 'Ibrahim Lodi alienates his own nobles', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Invited to invade', 'sub': 'discontented Afghans call Babur south', 'color': '#a16207'},
      ], edge_labels=['as', 'so'], takeaway='He learned India by raiding it — and found a divided, resentful Sultanate ripe for a bold and better-armed invader.', accent=AC),
      bg='The <b>Delhi Sultanate</b> under <b>Ibrahim Lodi</b> was rich but riven — the Sultan’s harshness had alienated many of his Afghan nobles.',
      people='<b>Ibrahim Lodi</b>, Sultan of Delhi; the disaffected nobles (including Daulat Khan Lodi) who invited Babur; Rana Sanga of Mewar, watching from the wings.',
      what='From 1505 Babur mounted repeated <b>expeditions into the Punjab</b>, gauging India’s riches and the Sultanate’s divisions; discontented Afghan chiefs invited him to overthrow Ibrahim Lodi.',
      crux='He turned reconnaissance into opportunity — recognizing that a <b>divided, resentful India</b> could be conquered by a disciplined, well-led force.',
      conseq='These probes set the stage for the full invasion of 1526 and the decisive clash at Panipat.',
      matters='Great conquests are prepared, not improvised — Babur studied his target for two decades before he struck.'),

    E('lastsamarkand', '1511–1512', 'The last try for Samarkand — and letting go', ['BATTLE', 'TURNING POINT'],
      'Babur makes one final bid for his homeland — allying with the Safavid Shah Ismail to retake Samarkand a third time in 1511 — but the alliance is unpopular and short-lived, and after a crushing defeat at Ghazdewan in 1512 he loses the city forever, finally abandoning Central Asia to build his future in Kabul and India.',
      svg_row('The dream of Samarkand, laid to rest', [
          {'n': 1, 'label': 'Third seizure, 1511', 'sub': 'retakes Samarkand with Safavid help', 'color': '#0f766e'},
          {'n': 2, 'label': 'Defeat at Ghazdewan, 1512', 'sub': 'the Uzbeks drive him out for good', 'color': '#b91c1c'},
          {'n': 3, 'label': 'He lets Samarkand go', 'sub': 'turns finally to Kabul and Hindustan', 'color': '#a16207'},
      ], edge_labels=['but', 'so'], takeaway='His lifelong dream died at Ghazdewan — and only by abandoning Samarkand did he free himself to win an empire in India.', accent=AC),
      bg='Even from Kabul, Babur could not give up <b>Samarkand</b>; in 1511 he allied with the Shia <b>Safavid Shah Ismail</b> to take it a third time.',
      people='<b>Babur</b>, chasing his old dream; <b>Shah Ismail</b> of Persia, his controversial ally; the Uzbeks who expelled him at Ghazdewan.',
      what='Babur <b>retook Samarkand in 1511</b> with Safavid backing, but the alliance alienated the Sunni populace; defeat at <b>Ghazdewan (1512)</b> lost him the city for the last time.',
      crux='He finally accepted the <b>death of his Central Asian dream</b> — and only then turned his full energy toward India.',
      conseq='Freed from the obsession with Samarkand, Babur concentrated on Kabul and the conquest of Hindustan.',
      matters='Letting go of one dream can open a greater one — Babur’s empire began when he stopped chasing his lost homeland.'),
]

# ==================================================================  PHASE 4 — THE FOUNDING OF AN EMPIRE
PHASE_PANIPAT = [
    E('panipat', '1526', 'The First Battle of Panipat — gunpowder founds an empire', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'On the field of Panipat in 1526, Babur’s small army destroys the vast host of Ibrahim Lodi — using cannon and matchlock guns unfamiliar to the Indians, a fortified wagon line, and swift flanking cavalry to win one of history’s decisive battles, killing the Sultan and founding the Mughal Empire.',
      svg_compare('Panipat: how the smaller army won', {
          'head': 'Ibrahim Lodi’s host', 'color': '#b91c1c',
          'items': ['Vast army, perhaps 100,000 men', 'War elephants in the front', 'Traditional massed frontal charge', 'No answer to gunpowder']},
        {
          'head': 'Babur’s force', 'color': '#0f766e',
          'items': ['Far smaller, perhaps 12,000–15,000', 'Cannon and matchlock handguns', 'Wagons chained in a defensive line', 'Flanking cavalry (the tulughma)']},
        verdict='Firepower and manoeuvre shatter numbers — Lodi is killed and the Mughal Empire is born.',
        takeaway='A smaller army with cannon, matchlocks and clever tactics destroyed a host ten times its size — and founded a dynasty.', accent=AC),
      bg='In <b>April 1526</b> Babur advanced to <b>Panipat</b>, north of Delhi, to face <b>Ibrahim Lodi’s</b> far larger army of infantry, cavalry and war elephants.',
      people='<b>Babur</b>, the invader; <b>Ibrahim Lodi</b>, Sultan of Delhi, who died on the field; Babur’s gunners under his Ottoman-trained artillerist.',
      what='At the <b>First Battle of Panipat (1526)</b>, Babur used <b>cannon and matchlock firearms</b>, a fortified line of chained wagons, and encircling <b>flanking cavalry</b> to annihilate Lodi’s huge army and kill the Sultan — founding the <b>Mughal Empire</b>.',
      crux='He won by <b>technology and tactics over numbers</b> — gunpowder and manoeuvre beating a larger but old-fashioned host.',
      conseq='Delhi and Agra fell to Babur, but his victory brought new enemies — above all the Rajput confederacy under Rana Sanga.',
      matters='Panipat is a hinge of history — it introduced gunpowder warfare to North India and began three centuries of Mughal rule.'),

    E('khanwa', '1527', 'The Battle of Khanwa — breaking the Rajput challenge', ['BATTLE', 'TRIUMPH'],
      'A year after Panipat, Babur faces an even graver threat — the great Rajput confederacy led by Rana Sanga of Mewar — and at Khanwa he rallies his wavering men with a vow to renounce wine, then uses the same guns and tactics to win a crushing victory that secures Mughal rule in North India.',
      svg_stack('Securing the conquest against the Rajputs', [
          {'n': 1, 'label': 'Rana Sanga unites the Rajputs', 'sub': 'a vast Hindu confederacy challenges Babur', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Babur rallies his men', 'sub': 'renounces wine; declares a holy war', 'color': '#a16207'},
          {'n': 3, 'label': 'Victory at Khanwa, 1527', 'sub': 'guns and tactics crush the Rajput host', 'color': '#0f766e'},
      ], takeaway='He beat the one power that could have undone him — Khanwa turned the Panipat conquest into a lasting empire.', accent=AC),
      bg='After Panipat, the most formidable resistance came from <b>Rana Sanga of Mewar</b>, who forged a great <b>Rajput confederacy</b> to drive the invader out.',
      people='<b>Rana Sanga</b>, the Rajput leader of Mewar; <b>Babur</b>, rallying his anxious army; the allied Rajput and Afghan chiefs.',
      what='At the <b>Battle of Khanwa (1527)</b>, with his men frightened, Babur dramatically <b>renounced wine</b> and roused them; then, using his artillery and wagon-fort tactics again, he <b>decisively defeated Rana Sanga</b>, securing Mughal power in the north.',
      crux='He combined <b>morale and firepower</b> — inspiring a fearful army and then winning by the same gunpowder methods as at Panipat.',
      conseq='Khanwa broke the last great rival to Mughal supremacy in North India; a further victory at Ghaghra (1529) confirmed it.',
      matters='One battle wins a throne, the next secures it — Khanwa proved Panipat was no fluke and made the Mughal conquest permanent.'),

    E('ghaghra', '1529', 'The Battle of Ghaghra — securing the east', ['BATTLE', 'TRIUMPH'],
      'Babur turns east to face the last great threat — the Afghan chiefs of Bihar and Bengal who still resist Mughal rule — and at the confluence of the Ghaghra river in 1529 he defeats their confederacy, using river-borne artillery, to secure the eastern frontier and complete his conquest of North India.',
      svg_stack('Completing the conquest of the north', [
          {'n': 1, 'label': 'The Afghans regroup east', 'sub': 'chiefs of Bihar and Bengal defy the Mughals', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Babur marches to the Ghaghra', 'sub': 'confronts them at the river confluence', 'color': '#0f766e'},
          {'n': 3, 'label': 'Victory, 1529', 'sub': 'guns and boats secure the eastern frontier', 'color': '#166534'},
      ], takeaway='He beat the last coalition against him — Ghaghra sealed the northern conquest and defined the empire’s eastern edge.', accent=AC),
      bg='After Khanwa, resistance shifted east to the <b>Afghan chiefs of Bihar and Bengal</b>, who backed a rival to Mughal rule.',
      people='<b>Babur</b>, campaigning east; the eastern <b>Afghan confederacy</b>; the Sultan of Bengal, whose forces joined them.',
      what='At the <b>Battle of Ghaghra (1529)</b>, fought at the river’s confluence with the Ganges, Babur used <b>artillery and a river flotilla</b> to defeat the Afghan-Bengal alliance and secure his eastern frontier.',
      crux='He extended his gunpowder edge to <b>river warfare</b>, finishing the last organized resistance in the north.',
      conseq='With the east secured, Babur ruled an empire stretching from Kabul across the Gangetic plain — his conquest complete.',
      matters='A conquest is only done when its frontiers are secure — Ghaghra rounded off the realm Babur left to his heirs.'),
]

# ==================================================================  PHASE 5 — THE MEMOIRIST AND HIS END
PHASE_END = [
    E('baburnama', '1494–1529', 'The Baburnama — the most candid memoir of a conqueror', ['REFORM', 'LEGACY'],
      'Amid all his wars, Babur writes the Baburnama — a strikingly honest, vivid memoir in his native Turkish that records his victories and humiliations, his loves and losses, and his sharp observations of nature, cities and men — a self-portrait unlike anything else left by a medieval conqueror.',
      svg_row('A conqueror who told the truth about himself', [
          {'n': 1, 'label': 'Writes his own memoir', 'sub': 'the Baburnama, in Chagatai Turkish', 'color': '#0f766e'},
          {'n': 2, 'label': 'Candid and observant', 'sub': 'records failures, feelings, nature and men', 'color': '#a16207'},
          {'n': 3, 'label': 'A window into his world', 'sub': 'a self-portrait rare among conquerors', 'color': '#166534'},
      ], edge_labels=['being', 'giving'], takeaway='He conquered an empire and also chronicled himself — leaving one of the most honest autobiographies in history.', accent=AC),
      bg='Throughout his campaigns Babur kept a personal memoir, the <b>Baburnama</b>, written in his native <b>Chagatai Turkish</b>.',
      people='<b>Babur</b> the author; the readers and later translators who prized the work; his descendants who cherished it.',
      what='The <b>Baburnama</b> is a remarkably <b>candid and vivid autobiography</b> — Babur records his defeats and embarrassments as frankly as his triumphs, alongside sharp observations of landscapes, flora, fauna, cities and personalities.',
      crux='He wrote with rare <b>honesty and curiosity</b> — a ruler willing to record his own failings and to observe the world closely.',
      conseq='The memoir became a treasured classic of world literature and the richest first-hand source for his age.',
      matters='Self-knowledge outlives conquest — the Baburnama keeps Babur human and vivid five centuries on, in his own voice.'),

    E('empire', '1526–1530', 'Ruling Hindustan — a homesick emperor', ['POLITICS', 'REFORM'],
      'Master now of North India from Kabul to Bengal’s borders, Babur governs his new empire — but he never loves the hot Indian plains, missing the cool gardens, melons and running streams of Kabul, and laying out Persian-style gardens to bring a piece of his lost homeland to Hindustan.',
      svg_stack('An empire won, a homeland missed', [
          {'n': 1, 'label': 'Master of North India', 'sub': 'rules from Kabul across the Gangetic plain', 'color': '#0f766e'},
          {'n': 2, 'label': 'But he pines for Kabul', 'sub': 'dislikes India’s heat; misses its melons and streams', 'color': '#a16207'},
          {'n': 3, 'label': 'Builds Persian gardens', 'sub': 'brings order and beauty to a foreign land', 'color': '#166534'},
      ], takeaway='He held a vast new empire yet longed for home — a conqueror who watered his conquest with gardens from Kabul.', accent=AC),
      bg='After Panipat, Khanwa and Ghaghra, Babur ruled a broad empire across <b>North India</b>, from Kabul to the borders of Bengal.',
      people='<b>Babur</b> the new emperor; his son and heir <b>Humayun</b>; the Afghan and Rajput subjects of his conquered realm.',
      what='Babur governed his new dominions but <b>never reconciled to India</b>, missing the climate, fruit and gardens of Kabul; he laid out <b>Persian-style char-bagh gardens</b> in Hindustan to recreate the homeland he loved.',
      crux='He founded an empire he did not truly enjoy — a ruler whose heart remained in the <b>cool highlands of Kabul</b>.',
      conseq='His short reign left the empire’s consolidation to his heirs, above all Humayun, whose hold on it was fragile.',
      matters='Conquest and contentment are not the same — Babur’s longing for Kabul shows the human cost of a life spent in war and exile.'),

    E('death', '1530', 'A father’s sacrifice — the legend of Babur’s death', ['DEATH', 'LEGACY'],
      'When his beloved son and heir Humayun falls gravely ill, Babur — by the famous legend — walks three times around the sickbed praying to take the illness upon himself in exchange for his son’s life; Humayun recovers, Babur sickens and dies in 1530, and is later buried, as he wished, in his beloved Kabul.',
      svg_stack('The legend of the offered life', [
          {'n': 1, 'label': 'Humayun falls deathly ill', 'sub': 'the heir to the new empire is dying', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Babur offers his own life', 'sub': 'circles the sickbed, praying to take the illness', 'color': '#0f766e'},
          {'n': 3, 'label': 'The son lives, the father dies', 'sub': 'Humayun recovers; Babur dies in 1530', 'color': '#78350f'},
      ], takeaway='By legend he gave his own life for his son’s — and was buried, as he longed to be, in the gardens of Kabul.', accent=AC),
      bg='In 1530 Babur’s son and heir <b>Humayun</b> fell gravely ill, threatening the succession of the young Mughal Empire.',
      people='<b>Babur</b>, the dying emperor; his son <b>Humayun</b>, the heir he loved; the court that recorded the famous story.',
      what='By the celebrated legend, Babur <b>circled Humayun’s sickbed praying to take the illness onto himself</b>; Humayun recovered, Babur sickened and <b>died in 1530</b>, and was in time buried in <b>Kabul</b>, the land he loved best.',
      crux='He is remembered dying in an act of <b>a father’s self-sacrifice</b> — devotion to his son and dynasty above his own life.',
      conseq='Humayun inherited a still-fragile empire; the Mughal dynasty Babur founded would flower under his grandson Akbar and rule for three centuries.',
      matters='A dynasty rests on succession — Babur’s legend crowns his story with the founder’s ultimate gift: his life for his heir’s.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Babur was the founder of the Mughal Empire — a Timurid prince descended from both Timur and Genghis Khan who inherited a throne at eleven, lost his homeland to the Uzbeks, and turned catastrophe into conquest. Driven from Samarkand and Ferghana, he built a new kingdom at Kabul and then swept into India, where cannon and matchlocks won him an empire at Panipat in 1526. Restless, honest and observant, he left in the Baburnama one of history’s most candid memoirs. He is the ultimate study in <b>resilience, gunpowder warfare, and building empire out of exile.</b></p>
<div class="ov-quote">“The throne of Samarkand was my heart’s desire.”<span>— the spirit of the Baburnama</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born heir to Timur and Genghis Khan → crowned king of Ferghana at eleven → wins and loses Samarkand again and again → is driven out, a landless fugitive → seizes Kabul and builds a secure base → invades India and destroys Ibrahim Lodi at Panipat with cannon → breaks the Rajputs at Khanwa → rules a homesick empire while writing the Baburnama → and dies in 1530, by legend giving his life for his son Humayun.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🐅</div><h4>Empire from exile</h4><p>Turned the loss of his homeland into the conquest of India.</p></div>
  <div class="ov-card"><div class="i">💥</div><h4>Gunpowder warfare</h4><p>Cannon and matchlocks at Panipat changed Indian warfare forever.</p></div>
  <div class="ov-card"><div class="i">📖</div><h4>The Baburnama</h4><p>Left one of history’s most candid conqueror’s memoirs.</p></div>
  <div class="ov-card"><div class="i">👑</div><h4>Founder of a dynasty</h4><p>Began the Mughal Empire that ruled India for three centuries.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Boy-King</b><small> 1483–1494</small><p>Blood of Timur and Genghis; a throne at eleven.</p></div>
  <div><b>2 · Losing Samarkand</b><small> 1497–1504</small><p>Winning, losing, and being driven into exile.</p></div>
  <div><b>3 · The Kingdom of Kabul</b><small> 1504–1524</small><p>A secure base, and eyes on Hindustan.</p></div>
  <div><b>4 · Founding an Empire</b><small> 1526–1527</small><p>Panipat and Khanwa win North India.</p></div>
  <div><b>5 · Memoir and End</b><small> 1526–1530</small><p>The Baburnama, and a father’s sacrifice.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Ibrahim Lodi', 'role': 'defeated Sultan', 'color': '#b91c1c',
     'bio': 'The last Sultan of Delhi of the Lodi dynasty, whose huge army Babur destroyed at Panipat in 1526 and who died on the field.',
     'rel': 'The ruler Babur overthrew to found the Mughal Empire.'},
    {'name': 'Rana Sanga', 'role': 'Rajput rival', 'color': '#a16207',
     'bio': 'The powerful Rana of Mewar who united a great Rajput confederacy to resist Babur, only to be crushed at Khanwa in 1527.',
     'rel': 'The gravest challenge to Mughal rule after Panipat.'},
    {'name': 'Shaybani Khan', 'role': 'Uzbek nemesis', 'color': '#6d28d9',
     'bio': 'The Uzbek conqueror who shattered the Timurid principalities and drove Babur out of Samarkand and Ferghana into exile.',
     'rel': 'The enemy who cost Babur his Central Asian homeland.'},
    {'name': 'Humayun', 'role': 'son and heir', 'color': '#0f766e',
     'bio': 'Babur’s beloved eldest son, for whose life Babur is said to have prayed away his own, and who inherited the fragile new empire.',
     'rel': 'The heir Babur died to save, by legend, in 1530.'},
    {'name': 'Timur (Tamerlane)', 'role': 'ancestor and model', 'color': '#166534',
     'bio': 'The great fourteenth-century conqueror from whom Babur descended on his father’s side, and whose capital Samarkand Babur longed to rule.',
     'rel': 'The forefather whose empire Babur dreamed of restoring.'},
]

KEY_EVENTS = [
    ('1483', 'Babur born', 'Timurid prince of Ferghana, heir to Timur and Genghis.'),
    ('1494', 'King at eleven', 'Inherits Ferghana on his father’s death.'),
    ('1497', 'Takes Samarkand', 'Wins Timur’s capital — then loses it.'),
    ('1504', 'Seizes Kabul', 'A secure kingdom and base at last.'),
    ('1526', 'First Battle of Panipat', 'Cannon defeat Ibrahim Lodi; empire founded.'),
    ('1527', 'Battle of Khanwa', 'Crushes Rana Sanga’s Rajput confederacy.'),
    ('1529', 'Battle of Ghaghra', 'Defeats the Afghans; secures the east.'),
    ('1494–1529', 'The Baburnama', 'His candid memoir of a life at war.'),
    ('1530', 'Death of Babur', 'By legend, his life for Humayun’s.'),
]

MASTER = [
    {'year': '1483', 'age': 'born', 'phase': 'The Boy-King', 'title': 'Born in Ferghana', 'desc': 'Heir to Timur and Genghis Khan.'},
    {'year': '1494', 'age': 'age 11', 'phase': 'The Boy-King', 'title': 'King of Ferghana', 'desc': 'Inherits a throne under siege.'},
    {'year': '1504', 'age': 'age 21', 'phase': 'Kingdom of Kabul', 'title': 'Seizes Kabul', 'desc': 'A secure base at last.'},
    {'year': '1526', 'age': 'age 43', 'phase': 'Founding an Empire', 'title': 'Panipat', 'desc': 'Founds the Mughal Empire.'},
    {'year': '1527', 'age': 'age 44', 'phase': 'Founding an Empire', 'title': 'Khanwa', 'desc': 'Breaks the Rajputs.'},
    {'year': '1530', 'age': 'age 47', 'phase': 'Memoir and End', 'title': 'Death of Babur', 'desc': 'A father’s sacrifice.'},
]

SOURCES = [
    ('Britannica — Babur', 'https://www.britannica.com/biography/Babur'),
    ('World History Encyclopedia — Babur', 'https://www.worldhistory.org/Babur/'),
    ('Britannica — First Battle of Panipat', 'https://www.britannica.com/event/First-Battle-of-Panipat'),
    ('Britannica — Baburnama', 'https://www.britannica.com/topic/Baburnama'),
    ('Wikipedia — Babur', 'https://en.wikipedia.org/wiki/Babur'),
]

def build_meta():
    return {
        'pid': 'gm-babur.html', 'kind': 'man', 'emoji': '🐅', 'accent': AC,
        'name': 'Babur', 'years': '1483–1530', 'group': 'Indian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Timurid boy-king who lost Samarkand and won an empire — descendant of Timur and Genghis Khan, conqueror of Kabul and victor of Panipat, founder of the Mughal Empire and author of the candid Baburnama.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Boy-King', 'type': 'timeline',
             'intro': 'Born heir to Timur and Genghis Khan, Babur inherits the throne of Ferghana at eleven and must fight uncles and nobles to hold it.', 'events': PHASE_RISE + BB1},
            {'id': 'samarkand', 'label': '2 · Losing Samarkand', 'type': 'timeline',
             'intro': 'He wins and loses Timur’s capital Samarkand again and again, until the Uzbek Shaybani Khan drives him from his homeland into landless exile.', 'events': PHASE_SAMARKAND + BB2},
            {'id': 'kabul', 'label': '3 · The Kingdom of Kabul', 'type': 'timeline',
             'intro': 'Out of total defeat he seizes Kabul, winning a secure base at last — and from it he probes the wealth and weakness of Lodi’s India.', 'events': PHASE_KABUL + BB3},
            {'id': 'panipat', 'label': '4 · Founding an Empire', 'type': 'timeline',
             'intro': 'With cannon and matchlocks he destroys Ibrahim Lodi at Panipat in 1526, then breaks Rana Sanga’s Rajputs at Khanwa — founding and securing the Mughal Empire.', 'events': PHASE_PANIPAT + BB4 + BB5},
            {'id': 'end', 'label': '5 · Memoir and End', 'type': 'timeline',
             'intro': 'He rules a homesick empire and writes the candid Baburnama — and dies in 1530, by legend offering his own life for his ailing son Humayun.', 'events': PHASE_END + BB6,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources, together with Babur’s own memoir the Baburnama; the deathbed story is a cherished tradition and is read as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER, 'auto': True},
        ],
    }
