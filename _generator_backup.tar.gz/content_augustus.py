# -*- coding: utf-8 -*-
"""Full, DEEP birth-to-death guide content for Augustus (Octavian).
The heir of Caesar who ended the Republic and founded the Roman Empire."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#854d0e'  # imperial laurel-gold

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE HEIR
PHASE_RISE = [
    E('heir', '44 BC', 'The teenager named in Caesar’s will', ['RISE', 'TURNING POINT'],
      'An unremarkable, sickly grand-nephew of Julius Caesar suddenly learns that the murdered dictator has adopted him as his son and heir — handing an 18-year-old both a magic name and a claim to the loyalty of Caesar’s soldiers.',
      svg_stack('An inheritance that was really a weapon', [
          {'n': 1, 'label': 'Caesar assassinated, Mar 44 BC', 'sub': 'the dictator killed; Rome in chaos', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The will names Octavian heir', 'sub': 'adopts his grand-nephew as son and heir', 'color': '#854d0e'},
          {'n': 3, 'label': 'A name worth an army', 'sub': 'the name “Caesar” commands the legions’ loyalty', 'color': '#166534'},
      ], takeaway='He inherited not just money but the most powerful name in Rome — and grasped its value instantly.', accent=AC),
      bg='<b>Julius Caesar</b> was murdered by senators in March 44 BC. His will revealed he had <b>adopted his grand-nephew Gaius Octavius</b> as his son and principal heir.',
      people='the assassins (Brutus, Cassius); <b>Mark Antony</b>, Caesar’s lieutenant; the 18-year-old <b>Octavian</b>, studying in Illyria when the news came.',
      what='Octavian returned to Italy, <b>accepted the inheritance and the name Caesar</b>, and began rallying his adoptive father’s veterans and political friends — despite having no official standing.',
      crux='He understood at once that the <b>name “Caesar” was itself a power</b>, commanding the devotion of legions and the plebs alike.',
      conseq='Overnight an obscure teenager became a magnet for Caesar’s partisans, upending the calculations of Antony and the Senate.',
      matters='Inheritance can be far more than property — a name, a claim, or a following can be the real bequest.'),

    E('army', '44–43 BC', 'Raising a private army at nineteen', ['RISE', 'POLITICS', 'BATTLE'],
      'With no legal authority, the teenaged Octavian uses Caesar’s money and name to raise a private army from the veterans, then lets the Senate use him against Antony — before turning on the Senate itself and marching on Rome to seize the consulship by force.',
      svg_row('From outsider to consul by force', [
          {'n': 1, 'label': 'Buys a private army', 'sub': 'raises veterans with Caesar’s name and cash', 'color': '#854d0e'},
          {'n': 2, 'label': 'Used against Antony', 'sub': 'the Senate deploys him, then tries to discard him', 'color': '#a16207'},
          {'n': 3, 'label': 'Marches on Rome, 43 BC', 'sub': 'seizes the consulship at just nineteen', 'color': '#b91c1c'},
      ], edge_labels=['then', 'so'], takeaway='He out-manoeuvred senators three times his age — using and then discarding each ally in turn.', accent=AC),
      bg='After Caesar’s death, the Senate (led by <b>Cicero</b>) hoped to use the young Octavian against the dangerous Antony, then set him aside.',
      people='<b>Cicero</b>, who patronised then underestimated him; <b>Mark Antony</b>, the rival; the veteran soldiers loyal to Caesar’s heir.',
      what='Octavian <b>raised troops privately</b>, helped defeat Antony at Mutina, then — snubbed by the Senate — <b>marched on Rome and forced his election as consul</b> at nineteen, extorting the office at swordpoint.',
      crux='He showed ruthless political instinct young: <b>use each ally against the next</b>, then take power by force once strong enough.',
      conseq='Now consul and commander, he was ready to deal with Antony not as an enemy but as a partner — for the moment.',
      matters='The ruthless newcomer who lets others fight his early battles, then seizes the prize, can outplay far more experienced rivals.'),

    E('divus', '42 BC', 'Making Caesar a god — “son of the divine”', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'Octavian has the Senate formally deify the murdered Caesar — which makes Octavian, as Caesar’s adopted son, the “son of a god,” a title of unmatched propaganda power that he stamps on his coins and carries for the rest of his life.',
      svg_stack('Manufacturing sacred legitimacy', [
          {'n': 1, 'label': 'Caesar deified, 42 BC', 'sub': 'the Senate proclaims him “Divus Julius”', 'color': '#854d0e'},
          {'n': 2, 'label': 'Octavian = “Divi Filius”', 'sub': 'son of the deified — a divine pedigree', 'color': '#a16207'},
          {'n': 3, 'label': 'Stamped on coins and cult', 'sub': 'the title broadcast across the empire', 'color': '#166534'},
      ], takeaway='He turned his adoptive father’s murder into a religious asset — becoming, in effect, the son of a god.', accent=AC),
      bg='A comet during Caesar’s funeral games was taken as his soul ascending. Octavian encouraged the idea and pressed for official deification.',
      people='the Senate that voted the deification; the Roman public receptive to Caesar’s cult; Octavian, styling himself accordingly.',
      what='Caesar was formally <b>deified as “Divus Julius”</b> in 42 BC. Octavian took the title <b>“Divi Filius”</b> (“son of the divine”) and publicised it relentlessly on coins and monuments.',
      crux='He grasped that <b>religious legitimacy</b> — divine descent — placed him above ordinary rivals in the Roman imagination.',
      conseq='The divine pedigree became a cornerstone of his authority and of the later imperial cult.',
      matters='Legitimacy can be manufactured from symbolism — sacred descent is a claim no ordinary politician can match.'),
]

# ==================================================================  PHASE 2 — THE TRIUMVIRATE
PHASE_TRIUMVIRATE = [
    E('triumvirate', '43 BC', 'The Second Triumvirate — carving up Rome', ['POLITICS', 'TURNING POINT'],
      'Rather than fight Antony, Octavian joins him and Lepidus in a legalised dictatorship of three — the Second Triumvirate — that divides the Roman world among them and sets out to destroy Caesar’s assassins.',
      svg_row('Three men seize the state', [
          {'n': 1, 'label': 'Octavian, Antony, Lepidus', 'sub': 'Caesar’s heirs and lieutenants unite', 'color': '#854d0e'},
          {'n': 2, 'label': 'A legal dictatorship of three', 'sub': 'the Triumvirate given sweeping powers, 43 BC', 'color': '#a16207'},
          {'n': 3, 'label': 'Divide the Roman world', 'sub': 'provinces and armies split between them', 'color': '#166534'},
      ], edge_labels=['form', 'then'], takeaway='He allied with his rival to master the state — cooperation now, reckoning later.', accent=AC),
      bg='With Caesar’s assassins raising armies in the East, the Caesarian leaders had more to gain from union than from feud.',
      people='<b>Mark Antony</b>, the senior partner; <b>Lepidus</b>, the junior; <b>Octavian</b>, the youngest but most ambitious.',
      what='In 43 BC the three formed the <b>Second Triumvirate</b>, a formally legalised three-man dictatorship to “restore the Republic,” <b>dividing the provinces</b> and preparing to avenge Caesar.',
      crux='He set aside rivalry for a <b>shared object</b> — power and revenge — knowing the partnership would not last.',
      conseq='The Triumvirate’s first act was a bloody purge of its enemies at home.',
      matters='Ambitious rivals often cooperate to seize power together — the struggle among them is merely deferred.'),

    E('proscriptions', '43 BC', 'The proscriptions — murder for money and revenge', ['POLITICS', 'TRAGEDY'],
      'To fund their armies and destroy their enemies, the triumvirs publish death-lists of Romans to be killed and their property seized — including the great orator Cicero, whose severed hands and head are nailed up in the Forum.',
      svg_stack('State terror to fund a war', [
          {'n': 1, 'label': 'Death-lists published', 'sub': 'named citizens outlawed; killers rewarded', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Property seized', 'sub': 'confiscations fund the triumvirs’ legions', 'color': '#854d0e'},
          {'n': 3, 'label': 'Cicero murdered', 'sub': 'the great orator killed; his hands nailed in the Forum', 'color': '#111827'},
      ], takeaway='The young Octavian assented to killing hundreds, including men who had once helped him — ruthlessness in cold blood.', accent=AC),
      bg='The triumvirs needed money and security. They revived the terror-tactic of <b>proscription</b> — publishing lists of citizens to be killed and robbed.',
      people='<b>Cicero</b>, whom Octavian allowed to be killed despite past support; hundreds of senators and knights; the informers and killers who profited.',
      what='The triumvirs <b>proscribed and murdered</b> perhaps 300 senators and 2,000 knights, seizing their wealth. Octavian consented to the death of <b>Cicero</b>, his former patron.',
      crux='He proved capable of <b>cold, calculated ruthlessness</b> when power and money required it — a chilling side of the later benevolent emperor.',
      conseq='The proscriptions funded the campaign against the assassins and removed political enemies wholesale.',
      matters='The path to power is often paved with acts the powerful later prefer forgotten — early ruthlessness enabling later magnanimity.'),

    E('philippi', '42 BC', 'Philippi — avenging Caesar', ['BATTLE', 'TRIUMPH'],
      'The triumvirs hunt down Caesar’s assassins in Greece, and at Philippi Brutus and Cassius are defeated and driven to suicide — fulfilling the oath of vengeance, though it is Antony, not the often-ailing Octavian, who wins the military glory.',
      svg_row('The reckoning with the assassins', [
          {'n': 1, 'label': 'Brutus & Cassius in the East', 'sub': 'the assassins raise a Republican army', 'color': '#a16207'},
          {'n': 2, 'label': 'Two battles at Philippi', 'sub': 'the Caesarians prevail; Cassius then Brutus die', 'color': '#854d0e'},
          {'n': 3, 'label': 'Antony gets the glory', 'sub': 'the ill Octavian shares victory but not the laurels', 'color': '#166534'},
      ], edge_labels=['fought', 'and'], takeaway='Caesar was avenged — but the campaign exposed Octavian as the politician, Antony as the soldier.', accent=AC),
      bg='Caesar’s assassins, <b>Brutus and Cassius</b>, had gathered a large army in the eastern provinces to defend the Republic.',
      people='<b>Brutus</b> and <b>Cassius</b>, the lead assassins, both of whom died; <b>Antony</b>, the victorious general; Octavian, reportedly unwell during the fighting.',
      what='At <b>Philippi</b> (42 BC) the triumvirs defeated the Republicans in two battles; <b>Cassius and then Brutus took their own lives</b>. Antony won the chief military credit; Octavian’s role was less glorious.',
      crux='The oath to avenge Caesar was <b>fulfilled</b>, but the campaign highlighted the contrast between Antony the warrior and Octavian the strategist-politician.',
      conseq='With the Republicans crushed, only the triumvirs remained — and their alliance now began to fray.',
      matters='Shared victory among allies often clarifies their rivalry — winning together sets the stage for the final contest.'),
]

# ==================================================================  PHASE 3 — THE LAST WAR
PHASE_WAR = [
    E('divide', '40–36 BC', 'Dividing the world — and consolidating the West', ['POLITICS', 'BATTLE'],
      'The triumvirs split the Roman world — Antony takes the rich East, Octavian the West — and over the next years Octavian patiently secures Italy, defeats Pompey’s son at sea, and quietly sidelines Lepidus, leaving just two men standing.',
      svg_stack('Patiently clearing the board', [
          {'n': 1, 'label': 'East to Antony, West to Octavian', 'sub': 'the world divided; Octavian holds Italy and Rome', 'color': '#854d0e'},
          {'n': 2, 'label': 'Defeats Sextus Pompey', 'sub': 'clears the seas with Agrippa’s new fleet, 36 BC', 'color': '#a16207'},
          {'n': 3, 'label': 'Lepidus discarded', 'sub': 'the third triumvir stripped of power', 'color': '#166534'},
      ], takeaway='While Antony pursued glory in the East, Octavian quietly consolidated the West and removed every other rival.', accent=AC),
      bg='After Philippi the triumvirs divided their spheres. Octavian faced revolts, a naval threat from <b>Sextus Pompey</b>, and the delicate task of settling veterans in Italy.',
      people='<b>Agrippa</b>, Octavian’s brilliant admiral and right hand; <b>Sextus Pompey</b>, defeated at sea; <b>Lepidus</b>, sidelined; <b>Antony</b>, absorbed in the East.',
      what='Octavian secured Italy, and with <b>Agrippa’s</b> fleet <b>defeated Sextus Pompey</b> (36 BC), then <b>stripped Lepidus</b> of his powers — leaving the Roman world split between himself and Antony.',
      crux='He played the <b>long, patient game</b> in the West while Antony chased eastern glory — steadily narrowing the field to two.',
      conseq='The stage was set for the final showdown between Octavian and Antony.',
      matters='Patience and consolidation can beat flashier rivals — clearing lesser threats first leaves only the decisive one.'),

    E('propaganda', '35–32 BC', 'The propaganda war — Rome versus the “Eastern queen”', ['POLITICS', 'TURNING POINT'],
      'Octavian wins the war of images before the war of ships: he paints Antony as a man bewitched by the foreign queen Cleopatra, betraying Rome for Egypt — and reads out Antony’s will to prove it, uniting Italy behind himself.',
      svg_row('Winning the story before the battle', [
          {'n': 1, 'label': 'Antony with Cleopatra', 'sub': 'his eastern alliance and children with the Egyptian queen', 'color': '#a16207'},
          {'n': 2, 'label': '“Un-Roman” and bewitched', 'sub': 'Octavian brands him a traitor to Rome’s values', 'color': '#854d0e'},
          {'n': 3, 'label': 'Reads out Antony’s will', 'sub': 'seizes and publicises it to inflame opinion', 'color': '#b91c1c'},
      ], edge_labels=['spun as', 'proved by'], takeaway='He framed a Roman civil war as Rome defending itself against a foreign queen — a masterstroke of spin.', accent=AC),
      bg='Antony’s open partnership with <b>Cleopatra</b> of Egypt, and his gifts of Roman territory to their children, gave Octavian priceless propaganda material.',
      people='<b>Mark Antony</b>; <b>Cleopatra VII</b> of Egypt; the Roman public and Senate, whose loyalty Octavian courted.',
      what='Octavian portrayed Antony as <b>enslaved by a foreign queen</b> and betraying Rome, and <b>illegally seized and read his will</b> (revealing eastern bequests) to inflame opinion — declaring war on Cleopatra, not on a fellow Roman.',
      crux='He reframed a <b>civil war as a patriotic war</b> against a foreign threat, uniting Italy behind him and isolating Antony.',
      conseq='With Italy sworn to him, Octavian went to war with overwhelming moral and political advantage.',
      matters='Controlling the narrative can decide a conflict — define your enemy first, and you fight on your own terms.'),

    E('actium', '31 BC', 'Actium — the battle that made an emperor', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'At Actium, Agrippa’s fleet blockades and defeats Antony and Cleopatra at sea; the lovers break out and flee to Egypt, their cause collapsing — leaving Octavian the sole master of the Roman world.',
      svg_stack('The naval battle that decided the world', [
          {'n': 1, 'label': 'Antony’s fleet blockaded', 'sub': 'Agrippa traps his ships and cuts supplies', 'color': '#854d0e'},
          {'n': 2, 'label': 'Battle off Actium, 31 BC', 'sub': 'the sea fight breaks Antony’s power', 'color': '#a16207'},
          {'n': 3, 'label': 'Antony & Cleopatra flee', 'sub': 'they escape to Egypt; their army surrenders', 'color': '#b91c1c'},
      ], takeaway='One naval victory left Octavian without a rival anywhere in the Roman world.', accent=AC),
      bg='In 31 BC the forces of Octavian and Antony met near <b>Actium</b> in western Greece, where Agrippa had manoeuvred Antony’s fleet into a trap.',
      people='<b>Agrippa</b>, the winning admiral; <b>Antony</b> and <b>Cleopatra</b>, who fled; the legions that surrendered afterward.',
      what='At the <b>naval Battle of Actium</b>, Agrippa’s fleet defeated Antony’s; Antony and Cleopatra <b>broke out and fled to Egypt</b>, and their remaining forces soon surrendered.',
      crux='The victory left Octavian the <b>sole ruler of the Roman world</b>, ending a century of civil wars.',
      conseq='Octavian pursued the pair to Egypt; within a year both were dead and Egypt was his.',
      matters='A single decisive battle can end an age — Actium closed the Roman Republic’s long death and opened the Empire.'),

    E('egypt', '30 BC', 'The end of Antony and Cleopatra — and Egypt’s treasure', ['BATTLE', 'TRIUMPH', 'TRAGEDY'],
      'Octavian invades Egypt; Antony and then Cleopatra take their own lives rather than be paraded in Rome, and Octavian annexes the fabulously rich kingdom as his personal domain — its treasure paying his debts and his soldiers, and making him unassailable.',
      svg_row('Sole master, and immensely rich', [
          {'n': 1, 'label': 'Egypt invaded, 30 BC', 'sub': 'Octavian’s forces close in on Alexandria', 'color': '#854d0e'},
          {'n': 2, 'label': 'Antony & Cleopatra die', 'sub': 'both take their own lives; the dynasty ends', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Egypt’s wealth seized', 'sub': 'its treasure pays his armies and debts', 'color': '#166534'},
      ], edge_labels=['then', 'yields'], takeaway='He gained not just victory but Egypt’s bottomless wealth — the economic foundation of his new order.', accent=AC),
      bg='After Actium, Octavian invaded Egypt, the last great independent power and the richest kingdom in the Mediterranean.',
      people='<b>Antony</b> and <b>Cleopatra</b>, who died by their own hands; <b>Caesarion</b> (Caesar’s son by Cleopatra), whom Octavian had killed; the people of Egypt.',
      what='In 30 BC Octavian took Egypt; <b>Antony and Cleopatra committed suicide</b>. He <b>annexed Egypt as his personal possession</b>, seizing its vast treasure to pay his soldiers and settle his debts.',
      crux='Egypt’s <b>wealth made him financially untouchable</b> and its grain fed Rome — power grounded in money as well as arms.',
      conseq='Sole ruler and immensely rich, Octavian now faced the harder task: holding power without provoking the fate of Caesar.',
      matters='Final victory is secured by resources as much as arms — controlling the wealth removes rivals’ means to resist.'),
]

# ==================================================================  PHASE 4 — THE PRINCIPATE
PHASE_PRINCIPATE = [
    E('settlement', '27 BC', 'The great illusion — “restoring the Republic”', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'Having learned from Caesar’s murder, Octavian theatrically hands his powers back to the Senate — which, as arranged, begs him to keep them and grants him the revered name Augustus, letting him rule as “first citizen” while pretending the Republic lives on.',
      svg_stack('Absolute power dressed as restoration', [
          {'n': 1, 'label': '“Restores” the Republic, 27 BC', 'sub': 'ostentatiously returns his powers to the Senate', 'color': '#854d0e'},
          {'n': 2, 'label': 'The Senate begs him to stay', 'sub': 'grants him provinces, armies and the name Augustus', 'color': '#a16207'},
          {'n': 3, 'label': 'Rules as “first citizen”', 'sub': 'princeps — power without the hated title of king', 'color': '#166534'},
      ], takeaway='He kept every real power while giving the forms of the Republic back — ruling by seeming not to rule.', accent=AC),
      bg='Caesar had been killed for appearing to become a king. Octavian resolved to hold supreme power <b>without its dangerous trappings</b>.',
      people='the compliant <b>Senate</b>; his advisers <b>Agrippa</b> and <b>Maecenas</b>; the Roman elite, relieved by the appearance of legality.',
      what='In 27 BC Octavian <b>“restored the Republic,”</b> returning his powers — and the Senate, by prior arrangement, <b>gave them back</b>, along with control of the key provinces and armies and the honorific <b>“Augustus.”</b> He styled himself <b>princeps</b> (“first citizen”).',
      crux='He grasped that <b>the appearance of legality</b> was survival — real power hidden behind Republican forms would not provoke assassination.',
      conseq='This “Principate” became the constitutional fiction that let one man rule Rome for centuries as “first among equals.”',
      matters='The subtlest power disguises itself — rule that looks like restoration provokes far less resistance than open domination.'),

    E('powers', '27–23 BC', 'The machinery of one-man rule', ['POLITICS', 'REFORM'],
      'Augustus assembles a wardrobe of ordinary Republican offices and powers — command of the armies, the tribune’s inviolability and veto, control of the treasury — that, worn together, make him master of everything while no single title reveals a monarch.',
      svg_row('Monarchy assembled from Republican parts', [
          {'n': 1, 'label': 'Imperium over the armies', 'sub': 'command of the provinces where the legions are', 'color': '#854d0e'},
          {'n': 2, 'label': 'Tribunician power', 'sub': 'personal inviolability and the veto, for life', 'color': '#a16207'},
          {'n': 3, 'label': 'Control of money & religion', 'sub': 'treasury, grain, and later chief priest', 'color': '#166534'},
      ], edge_labels=['plus', 'plus'], takeaway='No one office made him king — but the bundle of them made him unchallengeable.', accent=AC),
      bg='Rather than invent a monarchy, Augustus accumulated <b>traditional Republican powers</b> in his own person, adjusting the arrangement in 23 BC.',
      people='the Senate that granted the powers; <b>Agrippa</b>, given parallel powers as a partner; the magistrates who nominally still governed.',
      what='He held <b>proconsular imperium</b> over the army-heavy provinces and <b>tribunician power</b> (inviolability and veto) for life, plus control of finances and, later, the office of <b>pontifex maximus</b> — a monarch built from Republican pieces.',
      crux='He ruled through <b>familiar, legal instruments stacked together</b>, so that no one part looked like tyranny though the whole was absolute.',
      conseq='This flexible framework of powers became the template of Roman emperors for generations.',
      matters='Power is most durable when built from accepted, familiar parts — legitimacy assembled from tradition outlasts naked force.'),

    E('army', '27 BC–14 AD', 'A professional army loyal to him alone', ['REFORM', 'BATTLE'],
      'Augustus turns Rome’s armies from the private followings of warlords into a standing professional force — with fixed terms, state pensions, and an oath to him personally — and creates the elite Praetorian Guard at his side, monopolising military force.',
      svg_stack('Ending the age of warlord armies', [
          {'n': 1, 'label': 'A permanent standing army', 'sub': 'fixed service terms and a state pension fund', 'color': '#854d0e'},
          {'n': 2, 'label': 'Loyalty to Augustus', 'sub': 'soldiers swear personal allegiance to him', 'color': '#a16207'},
          {'n': 3, 'label': 'The Praetorian Guard', 'sub': 'an elite corps stationed near the emperor', 'color': '#b91c1c'},
      ], takeaway='He removed the very thing that had destroyed the Republic — armies loyal to generals rather than the state.', accent=AC),
      bg='The civil wars had been fought by armies loyal to individual generals. Augustus set out to make the military answer to him — and only him.',
      people='the legionary soldiers, now career professionals; the <b>Praetorian Guard</b>; the generals whose independent armies were disbanded.',
      what='He fixed <b>terms of service and pensions</b> (funded by a new treasury), had soldiers <b>swear loyalty to him personally</b>, and created the <b>Praetorian Guard</b> — professionalising the army and monopolising armed force.',
      crux='He cured the Republic’s fatal disease — <b>private warlord armies</b> — by making the whole military his own dependent institution.',
      conseq='A professional, loyal army gave the Principate stability, though the Praetorians would later make and unmake emperors.',
      matters='Lasting order requires monopolising force — a state where soldiers serve leaders rather than the state cannot hold.'),

    E('provinces', '27 BC–14 AD', 'Governing an empire — census, roads and law', ['REFORM', 'POLITICS'],
      'Augustus rebuilds the machinery of empire: a census to tax fairly, professional governors under his eye, a network of roads and couriers, and settled law — replacing the corrupt plunder of the Republic with orderly administration.',
      svg_row('From plunder to administration', [
          {'n': 1, 'label': 'Census and taxation', 'sub': 'counts people and property for fair, regular taxes', 'color': '#854d0e'},
          {'n': 2, 'label': 'Accountable governors', 'sub': 'salaried officials answerable to the emperor', 'color': '#a16207'},
          {'n': 3, 'label': 'Roads and posts', 'sub': 'a communications network binds the provinces', 'color': '#166534'},
      ], edge_labels=['plus', 'plus'], takeaway='He replaced the Republic’s corrupt, extractive rule of the provinces with orderly, professional government.', accent=AC),
      bg='Under the Republic, provinces had been plundered by governors seeking quick fortunes. Augustus aimed at stable, sustainable administration.',
      people='the provincial subjects; the salaried governors and equestrian officials; the tax-collectors now more closely supervised.',
      what='Augustus ordered <b>censuses</b> for fair taxation, appointed <b>accountable governors</b>, built <b>roads and an imperial post</b>, and standardised administration — turning conquest into durable government.',
      crux='He understood that empire must be <b>administered, not just conquered</b> — orderly rule secures what force wins.',
      conseq='The reforms underpinned two centuries of relative stability and prosperity across the Mediterranean world.',
      matters='Conquest is only the beginning — lasting empire depends on the unglamorous machinery of administration.'),
]

# ==================================================================  PHASE 5 — THE GOLDEN AGE
PHASE_GOLDEN = [
    E('paxromana', '27 BC–14 AD', 'The Pax Romana — peace as achievement', ['POLITICS', 'TRIUMPH'],
      'After a century of civil war, Augustus gives the Roman world something it has not known in living memory: peace — the Pax Romana — allowing trade, travel and prosperity to flourish, and closing the temple of Janus, shut only in times of total peace.',
      svg_stack('Peace after a century of blood', [
          {'n': 1, 'label': 'A century of civil war ends', 'sub': 'the killing that destroyed the Republic stops', 'color': '#854d0e'},
          {'n': 2, 'label': 'Trade and travel flourish', 'sub': 'safe roads and seas bring prosperity', 'color': '#166534'},
          {'n': 3, 'label': 'The gates of Janus closed', 'sub': 'the war-temple shut, marking total peace', 'color': '#a16207'},
      ], takeaway='His greatest gift was simply peace — and the prosperity that a war-ravaged world had almost forgotten.', accent=AC),
      bg='Romans had endured decades of civil war and proscription. Augustus made <b>internal peace</b> the foundation and selling-point of his rule.',
      people='the war-weary Roman people; the traders and provincials who prospered; the poets who celebrated the new age.',
      what='Augustus inaugurated the <b>Pax Romana</b> — a long internal peace that let commerce and culture flourish. He ceremonially <b>closed the temple of Janus</b>, shut only when Rome was wholly at peace, several times.',
      crux='He converted his supremacy into a <b>public good — peace</b> — the achievement that reconciled Romans to one-man rule.',
      conseq='The Pax Romana lasted roughly two centuries, an era of unmatched Mediterranean stability and growth.',
      matters='Enduring authority is often bought with peace and prosperity — people forgive much in a ruler who ends the killing.'),

    E('marble', '27 BC–14 AD', '“I found Rome brick and left it marble”', ['REFORM', 'TRIUMPH'],
      'Augustus rebuilds the city of Rome into a capital worthy of an empire — temples, forums, theatres and monuments in gleaming marble — while broadcasting his achievements in a great public account, the Res Gestae, inscribed for all posterity.',
      svg_row('Building an imperial capital', [
          {'n': 1, 'label': 'A city rebuilt in marble', 'sub': 'temples, forums, theatres and aqueducts', 'color': '#854d0e'},
          {'n': 2, 'label': 'Monuments of the new age', 'sub': 'the Ara Pacis, his forum and mausoleum', 'color': '#a16207'},
          {'n': 3, 'label': 'The Res Gestae', 'sub': 'his deeds inscribed for posterity', 'color': '#166534'},
      ], edge_labels=['plus', 'plus'], takeaway='He made the physical city a monument to the new order — power written in stone.', accent=AC),
      bg='Rome’s public buildings were shabby for a capital of empire. Augustus, with Agrippa, undertook a vast building programme.',
      people='<b>Agrippa</b>, who built aqueducts and the original Pantheon; the architects and craftsmen; the citizens who used the new amenities.',
      what='Augustus <b>rebuilt Rome in marble</b> — temples, the Forum of Augustus, the Ara Pacis, theatres, aqueducts — and left the <b>Res Gestae</b>, a first-person record of his achievements, inscribed across the empire.',
      crux='He used <b>architecture and self-record</b> to make his rule visible, permanent and glorious — propaganda in stone and text.',
      conseq='The rebuilt city and his monuments shaped Rome for centuries and fixed the image of his reign for history.',
      matters='The powerful shape how they are remembered — building and self-documentation are instruments of lasting image.'),

    E('culture', '27 BC–14 AD', 'The Augustan golden age of letters', ['REFORM', 'TRIUMPH'],
      'Under Augustus’s patronage — channelled through his friend Maecenas — Rome enjoys a literary golden age, as Virgil writes the Aeneid to give Rome a founding epic, Horace and Ovid flourish, and Livy chronicles the city, all subtly glorifying the new order.',
      svg_stack('Art in the service of the state', [
          {'n': 1, 'label': 'Maecenas, the patron', 'sub': 'Augustus’s friend cultivates the great poets', 'color': '#854d0e'},
          {'n': 2, 'label': 'Virgil’s Aeneid', 'sub': 'a founding epic linking Rome — and Augustus — to Troy', 'color': '#a16207'},
          {'n': 3, 'label': 'Horace, Ovid, Livy', 'sub': 'a flowering of poetry and history', 'color': '#166534'},
      ], takeaway='He harnessed the greatest literature of the age to legitimise and glorify the new Rome.', accent=AC),
      bg='Augustus and his circle understood that <b>culture could legitimise power</b>, and patronised writers who would celebrate Rome and its restorer.',
      people='<b>Maecenas</b>, the great patron; <b>Virgil</b>, <b>Horace</b>, <b>Ovid</b> and the historian <b>Livy</b>; Augustus himself, the ultimate sponsor.',
      what='The <b>Augustan Age</b> produced Virgil’s <b>Aeneid</b> (a national epic tying Rome and Augustus to divine and Trojan origins), the poetry of <b>Horace</b> and <b>Ovid</b>, and <b>Livy’s</b> history — much of it subtly glorifying the new order.',
      crux='He grasped that <b>enduring legitimacy is cultural</b> — great art woven around the regime outlasts any decree.',
      conseq='The literature of his age became the classical canon, carrying his image of Rome down the centuries.',
      matters='Power that captures the culture of its time secures a legitimacy that mere force never can.'),

    E('succession', '2 BC–14 AD', 'The lonely search for an heir — and death', ['POLITICS', 'TRAGEDY', 'DEATH'],
      'For all his mastery, Augustus is repeatedly robbed by death of his chosen heirs — his nephew, his friend Agrippa, his grandsons — until he is left with the reluctant Tiberius; he dies in 14 AD, is declared a god, and hands on the empire he built.',
      svg_stack('An empire in search of an heir', [
          {'n': 1, 'label': 'Heir after heir dies', 'sub': 'Marcellus, Agrippa, and his grandsons Gaius & Lucius', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Tiberius adopted', 'sub': 'the able but grim stepson made successor', 'color': '#854d0e'},
          {'n': 3, 'label': 'Death and deification, 14 AD', 'sub': 'dies at 75; declared a god; the empire endures', 'color': '#a16207'},
      ], takeaway='He solved every problem but mortality — building a monarchy while struggling to pass it on.', accent=AC),
      bg='Augustus needed to ensure the succession without admitting he had founded a monarchy. Death repeatedly took the heirs he groomed.',
      people='<b>Marcellus</b>, <b>Agrippa</b>, and grandsons <b>Gaius</b> and <b>Lucius</b>, all of whom died; his wife <b>Livia</b>; his stepson and heir <b>Tiberius</b>.',
      what='One chosen successor after another <b>died</b>, leaving Augustus to adopt <b>Tiberius</b>. He <b>died in 14 AD</b>, aged 75, was <b>declared a god</b>, and passed on a stable empire — reportedly asking if he had played his part in life’s comedy well.',
      crux='He had built an enduring system, but the <b>problem of succession</b> — passing on power that was legally not a throne — haunted him to the end.',
      conseq='Tiberius inherited smoothly; the Principate Augustus founded lasted, in form, for centuries.',
      matters='The hardest task for any founder is succession — building power to outlast oneself is harder than winning it.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Augustus inherited nothing but a name — and turned it into the Roman Empire. A sickly teenager when Julius Caesar was murdered, he out-manoeuvred hardened generals and orators, avenged Caesar, destroyed Antony and Cleopatra, and then did what Caesar could not: he made himself absolute master of Rome while carefully pretending to restore the Republic, dying peacefully in his bed after 40 years of rule. He is the ultimate study in <b>patience over flash, power disguised as legality, and building a system that outlives its founder.</b></p>
<div class="ov-quote">“I found Rome a city of brick and left it a city of marble.”<span>— attributed to Augustus</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">An obscure grand-nephew named Caesar’s heir → raises a private army at 19 and seizes the consulship → joins Antony and Lepidus in the Triumvirate and purges his enemies → avenges Caesar at Philippi → consolidates the West while Antony chases the East → wins the propaganda war, then Actium → takes Egypt and its treasure → “restores the Republic” while keeping every real power as Augustus → builds a professional army, an administered empire, and the Pax Romana → rebuilds Rome in marble and patronises its golden age → struggles for an heir and dies a god.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🏛️</div><h4>Founder of empire</h4><p>He turned the Roman Republic into an empire that lasted centuries.</p></div>
  <div class="ov-card"><div class="i">🎭</div><h4>Power in disguise</h4><p>Absolute rule dressed as restoration — the subtlest political architecture in history.</p></div>
  <div class="ov-card"><div class="i">🕊️</div><h4>The Pax Romana</h4><p>Peace and prosperity after a century of civil war — his enduring gift.</p></div>
  <div class="ov-card"><div class="i">📜</div><h4>The system that lasted</h4><p>He built institutions — army, administration, succession — meant to outlive him.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Heir</b><small> 44–42 BC</small><p>Caesar’s name, a private army, and a god for a father.</p></div>
  <div><b>2 · The Triumvirate</b><small> 43–42 BC</small><p>Alliance, proscriptions, and vengeance at Philippi.</p></div>
  <div><b>3 · The Last War</b><small> 40–30 BC</small><p>Consolidation, propaganda, Actium and Egypt.</p></div>
  <div><b>4 · The Principate</b><small> 27–23 BC</small><p>“Restoring” the Republic while keeping all power.</p></div>
  <div><b>5 · The Golden Age</b><small> 27 BC–14 AD</small><p>Peace, marble, letters, and the search for an heir.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Julius Caesar', 'role': 'adoptive father', 'color': '#854d0e',
     'bio': 'The murdered dictator whose will adopted Octavian as son and heir, giving him the name, wealth and following that launched his career.',
     'rel': 'The name and inheritance that made everything possible.'},
    {'name': 'Mark Antony', 'role': 'ally then rival', 'color': '#b91c1c',
     'bio': 'Caesar’s great lieutenant and the finest soldier of the age; first Octavian’s partner in the Triumvirate, then his rival, destroyed at Actium.',
     'rel': 'The partner-turned-enemy he had to defeat for sole power.'},
    {'name': 'Marcus Agrippa', 'role': 'general and right hand', 'color': '#166534',
     'bio': 'Augustus’s brilliant admiral and closest ally, who won his great battles (Actium) and built much of Rome; briefly his intended successor.',
     'rel': 'The indispensable friend who won his wars and built his city.'},
    {'name': 'Livia Drusilla', 'role': 'wife and adviser', 'color': '#7c3aed',
     'bio': 'Augustus’s influential wife for over 50 years, a trusted counsellor and the mother, by a previous marriage, of his successor Tiberius.',
     'rel': 'The lifelong partner and political adviser at his side.'},
    {'name': 'Cleopatra VII', 'role': 'adversary', 'color': '#a16207',
     'bio': 'The last pharaoh of Egypt, allied with Antony against Octavian; her defeat and death delivered Egypt and its wealth to Rome.',
     'rel': 'The “foreign queen” he made the face of the enemy.'},
]

KEY_EVENTS = [
    ('63 BC', 'Born Gaius Octavius', 'A minor but well-connected Roman family.'),
    ('44 BC', 'Named Caesar’s heir', 'Caesar assassinated; adopts Octavian in his will.'),
    ('43 BC', 'The Second Triumvirate', 'Allies with Antony and Lepidus; proscriptions.'),
    ('42 BC', 'Philippi', 'Caesar’s assassins defeated.'),
    ('31 BC', 'Actium', 'Defeats Antony and Cleopatra at sea.'),
    ('30 BC', 'Egypt annexed', 'Antony and Cleopatra die; Egypt’s treasure seized.'),
    ('27 BC', '“Restores” the Republic', 'Given the name Augustus; founds the Principate.'),
    ('27 BC–14 AD', 'The Pax Romana', 'Peace, administration and rebuilding.'),
    ('2 BC–4 AD', 'Succession crises', 'His chosen heirs die; adopts Tiberius.'),
    ('14 AD', 'Death of Augustus', 'Dies at 75; declared a god.'),
]

MASTER = [
    {'year': '63 BC', 'age': 'born', 'phase': 'The Heir', 'title': 'Born Gaius Octavius', 'desc': 'A modest Roman family.'},
    {'year': '44 BC', 'age': 'age 18', 'phase': 'The Heir', 'title': 'Named Caesar’s heir', 'desc': 'Inherits the name.'},
    {'year': '43 BC', 'age': 'age 19', 'phase': 'The Triumvirate', 'title': 'Triumvirate & consulship', 'desc': 'Seizes power young.'},
    {'year': '31 BC', 'age': 'age 32', 'phase': 'The Last War', 'title': 'Actium', 'desc': 'Sole master of Rome.'},
    {'year': '27 BC', 'age': 'age 36', 'phase': 'The Principate', 'title': 'Becomes Augustus', 'desc': 'Founds the Empire.'},
    {'year': '14 AD', 'age': 'age 75', 'phase': 'The Golden Age', 'title': 'Death and deification', 'desc': 'The system endures.'},
]

SOURCES = [
    ('Britannica — Augustus', 'https://www.britannica.com/biography/Augustus-Roman-emperor'),
    ('World History Encyclopedia — Augustus', 'https://www.worldhistory.org/Augustus/'),
    ('Britannica — Battle of Actium', 'https://www.britannica.com/event/Battle-of-Actium-31-BC'),
    ('World History Encyclopedia — Second Triumvirate', 'https://www.worldhistory.org/Second_Triumvirate/'),
    ('Augustus — Res Gestae (Livius.org)', 'https://www.livius.org/sources/content/augustus-res-gestae/'),
    ('Wikipedia — Augustus', 'https://en.wikipedia.org/wiki/Augustus'),
]

def build_meta():
    return {
        'pid': 'gm-augustus.html', 'kind': 'man', 'emoji': '🏛️', 'accent': AC,
        'name': 'Augustus', 'years': '63 BC–14 AD', 'group': 'Ancient Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The teenager who inherited Caesar’s name and turned it into the Roman Empire — ending the Republic while pretending to restore it, and ruling for 40 years of peace.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Heir', 'type': 'timeline',
             'intro': 'A sickly, obscure teenager is suddenly named heir to the murdered Caesar — and turns a magic name into a private army, the consulship, and a claim to be the son of a god.', 'events': PHASE_RISE},
            {'id': 'triumvirate', 'label': '2 · The Triumvirate', 'type': 'timeline',
             'intro': 'Rather than fight Antony, he joins him and Lepidus in a legalised dictatorship of three — purging their enemies in the proscriptions and avenging Caesar at Philippi.', 'events': PHASE_TRIUMVIRATE},
            {'id': 'war', 'label': '3 · The Last War', 'type': 'timeline',
             'intro': 'While Antony chases glory in the East, he consolidates the West, wins the war of propaganda, and destroys Antony and Cleopatra at Actium — seizing Egypt and its treasure to become sole master of Rome.', 'events': PHASE_WAR},
            {'id': 'principate', 'label': '4 · The Principate', 'type': 'timeline',
             'intro': 'Learning from Caesar’s murder, he keeps every real power while theatrically “restoring the Republic” — building a professional army, an administered empire, and a monarchy disguised as first-citizenship.', 'events': PHASE_PRINCIPATE},
            {'id': 'golden', 'label': '5 · The Golden Age', 'type': 'timeline',
             'intro': 'He gives Rome the Pax Romana, rebuilds the city in marble, patronises a literary golden age — and struggles, as death takes heir after heir, to pass on the empire he has built.', 'events': PHASE_GOLDEN,
             'sources': SOURCES, 'srcnote': 'Main sources include Augustus’s own Res Gestae (self-serving), Suetonius, Cassius Dio and Tacitus — read critically, as ancient accounts mix fact, rumour and propaganda.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
