# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Chandragupta Maurya.
The obscure adventurer who overthrew the Nandas and forged the first empire to unite India."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b45309'  # Mauryan imperial gold

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — OBSCURE ORIGINS & THE MENTOR
PHASE_RISE = [
    E('origins', 'c. 340 BC', 'An obscure boy in a fractured land', ['RISE', 'TRAGEDY'],
      'Chandragupta is born around 340 BC into origins so obscure that the sources cannot agree on them — Greek writers call him a man of humble birth, Buddhists claim a Kshatriya clan, Jains a peacock-taming (Maurya) lineage — a nobody who would rise from nothing to found the greatest empire India had known.',
      svg_row('Humble, contested beginnings', [
          {'n': 1, 'label': 'Born c. 340 BC', 'sub': 'origins genuinely obscure and disputed', 'color': '#b45309'},
          {'n': 2, 'label': 'Called of low or humble birth', 'sub': 'Greek sources; rival Indian traditions differ', 'color': '#78350f'},
          {'n': 3, 'label': 'A subcontinent in pieces', 'sub': 'many warring kingdoms; Alexander at the Indus', 'color': '#166534'},
      ], edge_labels=['so', 'into'], takeaway='From obscure, contested beginnings rose the man who would first unite most of India.', accent=AC),
      bg='<b>Chandragupta Maurya</b> was born around 340 BC. His origins are genuinely uncertain — Greek writers describe humble birth, while later Buddhist and Jain traditions supply grander (and conflicting) lineages.',
      people='the young <b>Chandragupta</b> himself; the later Buddhist, Jain and Greek chroniclers who told rival stories of his birth.',
      what='Almost nothing certain is known of his childhood. What the sources agree on is that he began <b>outside the ruling houses</b> — a man of obscure or modest origin in a northern India split among rival kingdoms.',
      crux='His rise owed <b>nothing to inheritance</b> — it was built on ambition, a brilliant mentor, and the chaos of his age.',
      conseq='That obscure beginning makes his ascent to a subcontinental throne all the more extraordinary.',
      matters='Origin is not destiny — the founder of India’s first great empire began as a man the record can barely place.'),

    E('chanakya', 'c. 340–322 BC', 'Chanakya — the mentor who made a king', ['RISE', 'POLITICS'],
      'The Brahmin scholar Chanakya (also called Kautilya), master of statecraft and — by tradition — author of the Arthashastra, discovers the young Chandragupta and grooms him to seize power, becoming the strategic brain behind the throne in a partnership that would topple a dynasty.',
      svg_stack('The strategist behind the throne', [
          {'n': 1, 'label': 'Chanakya (Kautilya)', 'sub': 'Brahmin scholar of statecraft, linked to Takshashila', 'color': '#b45309'},
          {'n': 2, 'label': 'Sworn against the Nandas', 'sub': 'by legend, humiliated at the Nanda court', 'color': '#78350f'},
          {'n': 3, 'label': 'Finds and trains Chandragupta', 'sub': 'grooms an obscure youth to take Magadha', 'color': '#166534'},
      ], takeaway='A ruthless political genius chose and moulded the man who would be emperor — mind and ambition combined.', accent=AC),
      bg='<b>Chanakya</b>, a learned Brahmin associated with the university city of Takshashila (Taxila), is remembered as the mastermind of Chandragupta’s rise and, by tradition, author of the <b>Arthashastra</b>, a manual of realpolitik.',
      people='<b>Chanakya (Kautilya)</b>, the mentor and chief minister; <b>Chandragupta</b>, his chosen instrument.',
      what='Chanakya took the obscure Chandragupta under his wing, training him in war and statecraft and directing the campaign to <b>overthrow the ruling Nanda dynasty</b> of Magadha.',
      crux='The empire was the fruit of a <b>partnership</b> — Chandragupta’s energy and arms joined to Chanakya’s cold strategic mind.',
      conseq='Together they built the plan and the army that would seize the richest throne in India.',
      matters='Great founders are rarely alone — behind Chandragupta stood a strategist whose statecraft outlived them both.'),

    E('alexander', 'c. 326–322 BC', 'The Greek storm and the opening it left', ['RISE', 'BATTLE'],
      'Alexander the Great smashes into the northwest of India in 326 BC — young Chandragupta is said by Plutarch to have seen him — and when the Greeks withdraw, they leave behind a power vacuum in Punjab and the northwest that an ambitious adventurer could exploit.',
      svg_row('A vacuum an adventurer could seize', [
          {'n': 1, 'label': 'Alexander reaches the Indus, 326 BC', 'sub': 'Greek armies storm the northwest', 'color': '#b91c1c'},
          {'n': 2, 'label': '“Chandragupta saw Alexander”', 'sub': 'so Plutarch reports of the young man', 'color': '#b45309'},
          {'n': 3, 'label': 'The Greeks withdraw', 'sub': 'leaving a power vacuum in Punjab', 'color': '#166534'},
      ], edge_labels=['and', 'then'], takeaway='The chaos left by Alexander’s invasion and retreat gave a bold outsider his opening.', accent=AC),
      bg='In 326 BC <b>Alexander the Great</b> invaded northwestern India, then turned back at the Beas; his death in 323 BC and the Greek withdrawal destabilised the region.',
      people='<b>Alexander the Great</b>, the invader; the young <b>Chandragupta</b>, said to have observed him; the local rulers left exposed.',
      what='Plutarch records that Chandragupta, as a youth, <b>saw Alexander</b> — the anchor for dating his life. Alexander’s retreat and death left the northwest in flux, ripe for a new power.',
      crux='He read the moment — <b>disorder is opportunity</b> for the ambitious — and moved to fill the vacuum.',
      conseq='Building support in the northwest, he gathered the strength to strike at the heart of Magadha.',
      matters='Empires often rise in the wreckage of others’ collapse — Chandragupta seized the opening Alexander left behind.'),
]

# ==================================================================  PHASE 2 — OVERTHROWING THE NANDAS
PHASE_POWER = [
    E('nanda', 'c. 325 BC', 'The hated Nandas — rich, mighty, and loathed', ['POLITICS', 'BATTLE'],
      'The Nanda dynasty rules Magadha from Pataliputra as the greatest power in the Ganges plain — fabulously wealthy and fielding a vast army — but its low-born kings are widely despised, and their unpopularity is the crack Chandragupta and Chanakya aim to prise open.',
      svg_stack('A mighty throne, widely hated', [
          {'n': 1, 'label': 'The Nanda dynasty of Magadha', 'sub': 'rules the Ganges plain from Pataliputra', 'color': '#78350f'},
          {'n': 2, 'label': 'Immense wealth and army', 'sub': 'reputedly vast infantry, cavalry and elephants', 'color': '#b45309'},
          {'n': 3, 'label': 'But widely despised', 'sub': 'low-born kings, resented rule — a fatal weakness', 'color': '#b91c1c'},
      ], takeaway='The Nandas were strong on paper but hollow in loyalty — and that hollowness was their undoing.', accent=AC),
      bg='The <b>Nanda dynasty</b>, centred on Magadha and its capital <b>Pataliputra</b>, was the dominant power of the eastern Ganges — enormously rich and militarily formidable, yet its rulers were widely disliked.',
      people='<b>Dhana Nanda</b>, the last and much-resented Nanda king; the discontented subjects Chandragupta would rally.',
      what='The Nandas commanded the largest army in India but ruled without affection. Their <b>unpopularity</b> was the strategic weakness Chanakya identified as the path to power.',
      crux='Raw strength is not the same as legitimacy — a <b>hated regime</b> can be toppled where a loved one cannot.',
      conseq='Chandragupta and Chanakya built a coalition and a campaign aimed squarely at the Nanda throne.',
      matters='Power without loyalty is brittle — the mightiest army could not save a dynasty its people would not defend.'),

    E('conquest', 'c. 322 BC', 'The throne of Magadha seized', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'Around 322 BC, after a campaign that by tradition first probed the frontiers before striking at the core, Chandragupta and Chanakya overthrow the Nanda dynasty and take Pataliputra — a nobody now sits on the richest throne in India.',
      svg_row('From frontier to capital', [
          {'n': 1, 'label': 'Raise forces in the northwest', 'sub': 'build an army from the frontier lands', 'color': '#b45309'},
          {'n': 2, 'label': 'Strike at Magadha’s heart', 'sub': 'campaign against the Nanda power, c. 322 BC', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Take Pataliputra', 'sub': 'the Nanda dynasty overthrown; the throne won', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='In one decisive campaign the obscure adventurer became master of the Ganges plain.', accent=AC),
      bg='By tradition Chanakya first advised attacking the frontiers and working inward. Around <b>322 BC</b> the campaign brought down the Nandas.',
      people='<b>Chandragupta</b>, the conqueror; <b>Chanakya</b>, the strategist; <b>Dhana Nanda</b>, the deposed king.',
      what='Chandragupta defeated the Nanda dynasty and captured its capital <b>Pataliputra</b> around 322 BC, ending Nanda rule and placing himself on the throne of Magadha.',
      crux='He turned a hated regime’s weakness into its fall — <b>legitimacy won by conquest</b>, backed by Chanakya’s plan.',
      conseq='Master of Magadha, he now held the base from which to build an empire across the subcontinent.',
      matters='This was the hinge of his life — the moment an obscure man became a king and India’s first true empire began.'),

    E('empire', 'c. 322–320 BC', 'Founding the Mauryan Empire', ['POLITICS', 'TRIUMPH'],
      'On the Nanda throne Chandragupta founds the Mauryan Empire, ruling from Pataliputra — establishing the dynasty that will, under his grandson Ashoka, come to command almost the whole of the Indian subcontinent.',
      svg_stack('A dynasty is born', [
          {'n': 1, 'label': 'The Mauryan Empire founded', 'sub': 'c. 322 BC, capital at Pataliputra', 'color': '#b45309'},
          {'n': 2, 'label': 'A centralised imperial base', 'sub': 'Magadha’s wealth and army harnessed', 'color': '#78350f'},
          {'n': 3, 'label': 'A dynasty to endure', 'sub': 'line of Bindusara and Ashoka after him', 'color': '#166534'},
      ], takeaway='He did not merely take a throne — he founded a dynasty and a state that would outlast him for generations.', accent=AC),
      bg='Having overthrown the Nandas, Chandragupta established the <b>Maurya dynasty</b>, taking Pataliputra as his imperial capital.',
      people='<b>Chandragupta</b>, the founder; <b>Chanakya</b>, his chief minister; the future emperors <b>Bindusara</b> and <b>Ashoka</b>.',
      what='He founded the <b>Mauryan Empire</b> around 322 BC, building on Magadha’s resources a centralised state ruled from <b>Pataliputra</b> — the first empire to unite the greater part of India.',
      crux='He converted a single conquest into a <b>lasting institution</b> — a dynasty, an administration, a capital.',
      conseq='From this base he expanded across northern and central India and confronted the Greek successor kingdoms to the west.',
      matters='Founders are measured by what endures — Chandragupta’s empire, not just his victory, is his monument.'),
]

# ==================================================================  PHASE 3 — SELEUCUS AND THE GREEK WORLD
PHASE_ORDER = [
    E('seleucus', 'c. 305 BC', 'Facing down Seleucus I Nicator', ['BATTLE', 'POLITICS', 'TURNING POINT'],
      'Around 305 BC Chandragupta clashes with Seleucus I Nicator, Alexander’s general who now rules a vast eastern empire and seeks to recover India — but the confrontation ends not in Greek reconquest but in a settlement heavily favouring the Mauryan.',
      svg_row('The Greek recovery repulsed', [
          {'n': 1, 'label': 'Seleucus I Nicator', 'sub': 'Alexander’s heir in the east, seeks India', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Confrontation, c. 305–303 BC', 'sub': 'Seleucid army meets Mauryan power', 'color': '#b45309'},
          {'n': 3, 'label': 'Settled in Chandragupta’s favour', 'sub': 'no reconquest; terms tilt Mauryan', 'color': '#166534'},
      ], edge_labels=['meets', 'ends'], takeaway='The heir of Alexander tried to retake India — and came away the weaker party.', accent=AC),
      bg='<b>Seleucus I Nicator</b>, a general of Alexander, had built a huge empire in the east and moved to reassert Greek control over the Indus lands around 305 BC.',
      people='<b>Seleucus I Nicator</b>, the Greek king; <b>Chandragupta</b>, now the dominant Indian power.',
      what='The two powers confronted each other <b>c. 305–303 BC</b>. The details of fighting are thin, but the outcome is clear: Seleucus abandoned his eastern ambitions and came to terms.',
      crux='Chandragupta met a would-be conqueror from a <b>position of strength</b> — and dictated much of the peace.',
      conseq='The clash was resolved by a famous treaty that redrew the frontier and bound the two dynasties together.',
      matters='He proved the new Indian empire could face the Hellenistic world as an equal — and prevail.'),

    E('treaty', 'c. 305–303 BC', 'The treaty — satrapies for elephants', ['POLITICS', 'TRIUMPH'],
      'The treaty with Seleucus is a triumph: Seleucus cedes vast eastern territories — including Arachosia, Gedrosia, the Paropamisadae and Gandhara — while Chandragupta gives 500 war elephants and the two seal a marriage alliance, fixing a durable western frontier.',
      svg_compare('What each side gave', {
          'head': 'Chandragupta gives', 'color': '#b45309',
          'items': ['500 Indian war elephants', 'A marriage alliance (epigamia)', 'Peace on the western frontier'],
      }, {
          'head': 'Seleucus cedes', 'color': '#166534',
          'items': ['Arachosia and eastern Gedrosia', 'Paropamisadae and Gandhara', 'The Indus borderlands to the Maurya'],
      }, verdict='A frontier fixed for a generation — and 500 elephants that would fight at Ipsus.',
         takeaway='He traded elephants for provinces — extending his empire to the edge of the Iranian plateau.', accent=AC),
      bg='To end the confrontation, Seleucus and Chandragupta struck a settlement around 305–303 BC that transferred large eastern satrapies to the Maurya.',
      people='<b>Seleucus I Nicator</b> and <b>Chandragupta</b>; the Greek ambassador <b>Megasthenes</b>, sent to seal relations.',
      what='Seleucus ceded territories including <b>Arachosia, the Paropamisadae, Gandhara and eastern Gedrosia</b>; in return Chandragupta gave <b>500 war elephants</b> and the powers agreed a <b>marriage alliance</b>.',
      crux='He converted military strength into <b>permanent territorial gain</b> — provinces for elephants, and a stable border.',
      conseq='The elephants soon fought for Seleucus at the Battle of Ipsus (301 BC); the frontier held for generations.',
      matters='One of antiquity’s great diplomatic bargains — the young Indian empire won lands from Alexander’s heir.'),

    E('megasthenes', 'c. 302 BC', 'Megasthenes and the Indica', ['REFORM', 'POLITICS'],
      'Seleucus sends the ambassador Megasthenes to Chandragupta’s court at Pataliputra, and his lost account — the Indica — becomes the West’s first detailed portrait of India, describing a magnificent capital, a vast army, and an elaborate administration.',
      svg_row('The West’s first window on India', [
          {'n': 1, 'label': 'Megasthenes, Greek ambassador', 'sub': 'sent by Seleucus to Pataliputra', 'color': '#b45309'},
          {'n': 2, 'label': 'Writes the “Indica”', 'sub': 'now lost, survives only in later quotations', 'color': '#78350f'},
          {'n': 3, 'label': 'Describes court, army, society', 'sub': 'a great capital and a vast administration', 'color': '#166534'},
      ], edge_labels=['who', 'that'], takeaway='A Greek diplomat left the earliest outside record of Mauryan India — our window onto Chandragupta’s state.', accent=AC),
      bg='As part of the settlement, <b>Megasthenes</b> came as Seleucid ambassador to Chandragupta’s court, spending time at <b>Pataliputra</b>.',
      people='<b>Megasthenes</b>, the ambassador and author; <b>Chandragupta</b>, whose court and empire he described.',
      what='Megasthenes wrote the <b>Indica</b>, a detailed account of Mauryan India. Though the original is lost, later Greek writers quote it — describing a great walled capital, castes, and imperial administration.',
      crux='His account is <b>our chief outside source</b> — a foreign eyewitness where Indian records are thin.',
      conseq='Through Megasthenes (and Chanakya’s Arthashastra) we glimpse the scale and machinery of the Mauryan state.',
      matters='Much of what we know of Chandragupta’s empire survives only because a Greek ambassador wrote it down.'),
]

# ==================================================================  PHASE 4 — THE MAURYAN STATE
PHASE_STATE = [
    E('administration', 'c. 320–300 BC', 'The machinery of empire', ['REFORM', 'POLITICS'],
      'Guided by Chanakya’s Arthashastra, Chandragupta builds an elaborate centralised state — provinces and governors, a council of ministers, tax and irrigation systems, and a famous network of spies and informers to hold the vast realm together.',
      svg_stack('A centralised, watchful state', [
          {'n': 1, 'label': 'Provinces and a council of ministers', 'sub': 'the realm divided and governed from the centre', 'color': '#b45309'},
          {'n': 2, 'label': 'Taxation, roads and irrigation', 'sub': 'revenue and infrastructure sustain the empire', 'color': '#78350f'},
          {'n': 3, 'label': 'Spies and informers', 'sub': 'a network of surveillance guards the throne', 'color': '#b91c1c'},
      ], takeaway='He ruled not by conquest alone but by administration — a bureaucratic machine to bind a subcontinent.', accent=AC),
      bg='The <b>Arthashastra</b> attributed to Chanakya, together with Megasthenes, describes a highly organised Mauryan state built to govern an enormous territory.',
      people='<b>Chanakya</b>, architect of the system; the ministers, governors, tax officials and spies who ran it.',
      what='Chandragupta established a <b>centralised administration</b> — provinces under governors, a council of ministers, systems of taxation, roads and irrigation, and an extensive <b>intelligence network</b>.',
      crux='He understood that empire is <b>held by institutions</b>, not just armies — bureaucracy, revenue and surveillance.',
      conseq='This machinery let the Maurya rule far more of India, and rule it more firmly, than any before.',
      matters='The first Indian empire was also the first Indian administrative state — governance, not just conquest.'),

    E('army', 'c. 320–300 BC', 'The vast Mauryan army', ['BATTLE', 'TRIUMPH'],
      'Ancient sources report a Mauryan army of staggering size — by figures preserved from Megasthenes, on the order of 600,000 infantry, 30,000 cavalry, and 9,000 war elephants — a force that made Chandragupta the paramount power of the subcontinent.',
      svg_row('A force without rival in India', [
          {'n': 1, 'label': '~600,000 infantry', 'sub': 'as reported by ancient sources from Megasthenes', 'color': '#b45309'},
          {'n': 2, 'label': '~30,000 cavalry', 'sub': 'and thousands of chariots', 'color': '#78350f'},
          {'n': 3, 'label': '~9,000 war elephants', 'sub': 'the terror weapon of Indian warfare', 'color': '#b91c1c'},
      ], edge_labels=['plus', 'plus'], takeaway='Whatever the exact numbers, no Indian power could match the army Chandragupta commanded.', accent=AC),
      bg='Greek writers, drawing on <b>Megasthenes</b>, recorded very large figures for the Mauryan army — numbers likely rounded or exaggerated, but signalling a genuinely huge force.',
      people='<b>Chandragupta</b>, the commander; the ancient authors (Pliny, Plutarch) who transmit the figures from Megasthenes.',
      what='The sources report roughly <b>600,000 foot, 30,000 horse and 9,000 elephants</b> — figures to be treated with caution, but reflecting an army far larger than any rival’s.',
      crux='Overwhelming force underwrote everything — the state, the treaty with Seleucus, the unification of India.',
      conseq='This military dominance let him extend Mauryan rule across most of the subcontinent.',
      matters='The exact numbers are legend as much as record — but the reality of unmatched military power is not in doubt.'),

    E('unification', 'c. 320–298 BC', 'Uniting the subcontinent', ['TRIUMPH', 'POLITICS'],
      'Through conquest and consolidation Chandragupta extends his rule across northern and central India from sea to sea — creating the first state to bring most of the Indian subcontinent under a single sovereign, a unity later completed by his grandson Ashoka.',
      svg_stack('One empire, from sea to sea', [
          {'n': 1, 'label': 'North India secured', 'sub': 'the Ganges plain and the northwest', 'color': '#b45309'},
          {'n': 2, 'label': 'Expansion into central India', 'sub': 'and toward the western coast', 'color': '#78350f'},
          {'n': 3, 'label': 'Most of the subcontinent united', 'sub': 'the first pan-Indian empire', 'color': '#166534'},
      ], takeaway='For the first time one ruler’s writ ran across most of India — the map of Indian empire was drawn by Chandragupta.', accent=AC),
      bg='From his Magadhan base and the western lands won from Seleucus, Chandragupta pushed Mauryan rule across the north and into central India.',
      people='<b>Chandragupta</b>, the unifier; his son <b>Bindusara</b> and grandson <b>Ashoka</b>, who extended the empire further.',
      what='He brought <b>most of the Indian subcontinent</b> under a single administration — from the northwest frontier across the Ganges plain toward the peninsula — the first such unification in Indian history.',
      crux='He replaced a patchwork of kingdoms with <b>one imperial order</b> — a political idea of India that would echo for millennia.',
      conseq='The empire reached its greatest extent under Ashoka, but its foundation and framework were Chandragupta’s.',
      matters='He created the first pan-Indian empire — the template for the very idea of a united India.'),
]

# ==================================================================  PHASE 5 — RENUNCIATION & DEATH
PHASE_END = [
    E('abdication', 'c. 298 BC', 'The emperor renounces the throne', ['POLITICS', 'TURNING POINT'],
      'By Jain tradition, at the height of his power Chandragupta abdicates his throne — handing the empire to his son Bindusara — and becomes a Jain ascetic, a spiritual conversion so complete it turned the master of India into a wandering monk.',
      svg_row('From emperor to ascetic', [
          {'n': 1, 'label': 'At the height of power', 'sub': 'master of the subcontinent, c. 298 BC', 'color': '#b45309'},
          {'n': 2, 'label': 'Abdicates the throne', 'sub': 'hands the empire to his son Bindusara', 'color': '#78350f'},
          {'n': 3, 'label': 'Becomes a Jain monk', 'sub': 'renounces the world for asceticism', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='At his zenith he walked away from it all — power surrendered for the renunciation of a Jain ascetic.', accent=AC),
      bg='<b>Digambara Jain tradition</b> holds that Chandragupta, late in life, embraced Jainism and gave up his throne — though these accounts were written centuries later and are debated by historians.',
      people='<b>Chandragupta</b>, the abdicating emperor; his son and heir <b>Bindusara</b>; the Jain teacher <b>Bhadrabahu</b>.',
      what='According to Jain sources, Chandragupta <b>abdicated around 298 BC</b>, passing the empire to Bindusara, and became a monk under the Jain sage Bhadrabahu.',
      crux='He treated worldly power as something to be <b>renounced</b> — the opposite of the ambition that had built his empire.',
      conseq='As a monk he is said to have journeyed south with Bhadrabahu to Shravanabelagola in Karnataka.',
      matters='A story of astonishing reversal — the man who seized everything chose, at the end, to give it all up.'),

    E('sallekhana', 'c. 297 BC', 'Death by sallekhana at Shravanabelagola', ['DEATH', 'TRAGEDY'],
      'By tradition Chandragupta ends his life as a Jain ascetic at Shravanabelagola in southern India, dying around 297 BC by sallekhana — the Jain rite of fasting unto death — a serene, self-willed end for the founder of an empire.',
      svg_stack('A self-willed end', [
          {'n': 1, 'label': 'Migrates south to Shravanabelagola', 'sub': 'in modern Karnataka, with Bhadrabahu', 'color': '#b45309'},
          {'n': 2, 'label': 'Undertakes sallekhana', 'sub': 'the Jain ritual of fasting unto death', 'color': '#78350f'},
          {'n': 3, 'label': 'Dies c. 297 BC', 'sub': 'a serene, self-chosen death', 'color': '#111827'},
      ], takeaway='He met death as he had met power — on his own terms, fasting quietly to the end.', accent=AC),
      bg='Jain tradition places Chandragupta’s final years at <b>Shravanabelagola</b>, where sites long associated with him still stand — though Greek notices of Vedic rites at his court complicate the picture.',
      people='<b>Chandragupta</b>, the ascetic; <b>Bhadrabahu</b>, his Jain teacher; the monks of Shravanabelagola.',
      what='He is said to have died around <b>297 BC by sallekhana</b> — voluntarily fasting to death, the revered Jain manner of dying — at Shravanabelagola in the south.',
      crux='His end embodied the Jain ideal — <b>mastery of the self</b> and calm acceptance of death, far from any throne.',
      conseq='The story made him a revered figure in Jain memory and tied the Maurya founder to the far south of India.',
      matters='Legend and record blur here — but the image endures: an emperor who died a fasting monk, having renounced the world.'),

    E('legacy', 'after 297 BC', 'The founder’s long shadow', ['TRIUMPH', 'POLITICS'],
      'Chandragupta leaves behind the first empire to unite most of India, an administrative model that shaped Indian statecraft, and a dynasty that under his grandson Ashoka would reach its zenith — a founder whose achievement outlasted the man by centuries.',
      svg_row('An achievement that outlasted him', [
          {'n': 1, 'label': 'First pan-Indian empire', 'sub': 'the map of Indian unity he first drew', 'color': '#b45309'},
          {'n': 2, 'label': 'A model of statecraft', 'sub': 'the Arthashastra state and its administration', 'color': '#78350f'},
          {'n': 3, 'label': 'The line of Ashoka', 'sub': 'his grandson brings the empire to its height', 'color': '#166534'},
      ], edge_labels=['and', 'and'], takeaway='He is remembered as the founder — the man who first made the idea of a united India a reality.', accent=AC),
      bg='Chandragupta’s empire passed to <b>Bindusara</b> and then to <b>Ashoka</b>, under whom the Maurya reached its greatest extent and fame.',
      people='<b>Bindusara</b>, his son; <b>Ashoka</b>, his grandson; and Chandragupta himself, revered as founder.',
      what='He bequeathed the <b>first great Indian empire</b>, a centralised administrative model, and a dynasty that would dominate the subcontinent for over a century.',
      crux='His true legacy is <b>the precedent itself</b> — that India could be one empire under one ruler.',
      conseq='The Mauryan example shaped Indian ideas of empire and statecraft long after the dynasty fell.',
      matters='From obscure origins he founded the first empire of India — the ancestor of every later vision of Indian unity.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Chandragupta Maurya rose from origins so obscure the record can barely place him to become the founder of the <b>Mauryan Empire</b> — the first state to unite most of the Indian subcontinent. Guided by the ruthless strategist <b>Chanakya</b>, he overthrew the hated Nanda dynasty of Magadha around 322 BC, took the capital Pataliputra, faced down Alexander’s heir <b>Seleucus I Nicator</b> and won vast western provinces by treaty, and built an elaborate administrative state described by the Greek ambassador <b>Megasthenes</b>. Then, at his zenith, tradition says he renounced it all — becoming a Jain monk and dying by ritual fasting. He is the ultimate study in <b>the self-made founder, the union of ambition and strategy, and the empire that first made India one.</b></p>
<div class="ov-quote">“Chandragupta, when he was a stripling, saw Alexander himself.”<span>— Plutarch, Life of Alexander</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">An obscure youth in a fractured land is found and moulded by the strategist Chanakya → they exploit the chaos left by Alexander to overthrow the hated Nandas and take Pataliputra (~322 BC) → he founds the Mauryan Empire → faces Seleucus and wins great western satrapies for 500 elephants and a marriage alliance → builds a vast army and administrative state chronicled by Megasthenes → unites most of the subcontinent → and, at the height of power, renounces the throne to die a fasting Jain monk.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">👑</div><h4>The self-made founder</h4><p>Rose from obscurity to found India’s first empire.</p></div>
  <div class="ov-card"><div class="i">🧠</div><h4>Ambition plus strategy</h4><p>His energy joined to Chanakya’s statecraft toppled a dynasty.</p></div>
  <div class="ov-card"><div class="i">🐘</div><h4>Facing the Greek world</h4><p>Won provinces from Seleucus, Alexander’s own heir.</p></div>
  <div class="ov-card"><div class="i">🕊️</div><h4>Power renounced</h4><p>At his zenith gave up all to die a fasting Jain monk.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Obscure Origins</b><small> c. 340–322 BC</small><p>A nobody, a mentor, and Alexander’s vacuum.</p></div>
  <div><b>2 · Overthrowing the Nandas</b><small> c. 325–320 BC</small><p>Seizing Magadha and founding an empire.</p></div>
  <div><b>3 · Seleucus &amp; the Greeks</b><small> c. 305–302 BC</small><p>Treaty, satrapies, and Megasthenes.</p></div>
  <div><b>4 · The Mauryan State</b><small> c. 320–298 BC</small><p>Administration, army, and unification.</p></div>
  <div><b>5 · Renunciation &amp; Death</b><small> c. 298–297 BC</small><p>Abdication and death by sallekhana.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references. Much of Chandragupta’s life is known only through later or foreign sources; where legend and record diverge, this guide says so.</p>
"""

WHO = [
    {'name': 'Chanakya (Kautilya)', 'role': 'mentor & chief minister', 'color': '#b45309',
     'bio': 'The Brahmin strategist who discovered Chandragupta, engineered the overthrow of the Nandas, and — by tradition — wrote the Arthashastra, the manual of Mauryan statecraft.',
     'rel': 'The mastermind who made him a king and ran his state.'},
    {'name': 'Seleucus I Nicator', 'role': 'adversary turned ally', 'color': '#b91c1c',
     'bio': 'Alexander’s general and founder of the Seleucid Empire, who sought to recover India but ceded vast eastern satrapies to Chandragupta in exchange for 500 war elephants.',
     'rel': 'The Greek king he faced down and bound by treaty and marriage.'},
    {'name': 'Megasthenes', 'role': 'Greek ambassador', 'color': '#166534',
     'bio': 'The Seleucid envoy to Pataliputra whose lost work, the Indica, is the earliest detailed outside account of India and the Mauryan state.',
     'rel': 'The ambassador who chronicled his court and empire.'},
    {'name': 'Dhana Nanda', 'role': 'the deposed king', 'color': '#78350f',
     'bio': 'The last, much-resented ruler of the wealthy Nanda dynasty of Magadha, whose unpopularity Chandragupta and Chanakya exploited to seize the throne.',
     'rel': 'The hated king he overthrew to found his empire.'},
    {'name': 'Bhadrabahu', 'role': 'Jain teacher', 'color': '#4f46e5',
     'bio': 'The revered Jain sage under whom, by tradition, Chandragupta became a monk, migrating south to Shravanabelagola where the emperor died by sallekhana.',
     'rel': 'The spiritual guide of his final renunciation.'},
]

KEY_EVENTS = [
    ('c. 340 BC', 'Chandragupta born', 'Obscure origins in a fractured India.'),
    ('c. 322 BC', 'Nanda dynasty overthrown', 'Takes Pataliputra; founds the Maurya.'),
    ('c. 322 BC', 'Mauryan Empire founded', 'Capital at Pataliputra in Magadha.'),
    ('c. 305 BC', 'Confronts Seleucus I', 'The Greek recovery of India repulsed.'),
    ('c. 303 BC', 'Treaty with Seleucus', 'Satrapies won for 500 elephants; marriage alliance.'),
    ('c. 302 BC', 'Megasthenes at court', 'The Indica records Mauryan India.'),
    ('c. 320–298 BC', 'Subcontinent unified', 'First pan-Indian empire built.'),
    ('c. 298 BC', 'Abdicates the throne', 'Becomes a Jain monk under Bhadrabahu.'),
    ('c. 297 BC', 'Death by sallekhana', 'Fasts to death at Shravanabelagola.'),
]

MASTER = [
    {'year': 'c. 340 BC', 'age': 'born', 'phase': 'Obscure Origins', 'title': 'Born in obscurity', 'desc': 'A nobody in a divided India.'},
    {'year': 'c. 322 BC', 'age': 'age ~18', 'phase': 'Overthrowing the Nandas', 'title': 'Seizes Magadha', 'desc': 'Overthrows the Nandas; founds the Maurya.'},
    {'year': 'c. 305 BC', 'age': 'age ~35', 'phase': 'Seleucus & the Greeks', 'title': 'Treaty with Seleucus', 'desc': 'Wins the western satrapies.'},
    {'year': 'c. 302 BC', 'age': 'age ~38', 'phase': 'The Mauryan State', 'title': 'Megasthenes at court', 'desc': 'The empire chronicled and consolidated.'},
    {'year': 'c. 298 BC', 'age': 'age ~42', 'phase': 'Renunciation & Death', 'title': 'Abdicates', 'desc': 'Becomes a Jain monk.'},
    {'year': 'c. 297 BC', 'age': 'age ~43', 'phase': 'Renunciation & Death', 'title': 'Dies by sallekhana', 'desc': 'Fasts to death at Shravanabelagola.'},
]

SOURCES = [
    ('Britannica — Chandragupta', 'https://www.britannica.com/biography/Chandragupta'),
    ('World History Encyclopedia — Chandragupta Maurya', 'https://www.worldhistory.org/Chandragupta_Maurya/'),
    ('Wikipedia — Chandragupta Maurya', 'https://en.wikipedia.org/wiki/Chandragupta_Maurya'),
    ('Wikipedia — Seleucid–Mauryan War', 'https://en.wikipedia.org/wiki/Seleucid%E2%80%93Mauryan_War'),
    ('Britannica — Mauryan Empire', 'https://www.britannica.com/place/Mauryan-Empire'),
]

def build_meta():
    return {
        'pid': 'gm-chandraguptamaurya.html', 'kind': 'man', 'emoji': '🦚', 'accent': AC,
        'name': 'Chandragupta Maurya', 'years': 'c. 340–297 BC', 'group': 'Indian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The obscure adventurer who, guided by the strategist Chanakya, overthrew the Nandas and forged the Mauryan Empire — the first state to unite most of India — before renouncing the throne to die a fasting Jain monk.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · Obscure Origins', 'type': 'timeline',
             'intro': 'A youth of obscure birth in a fractured India is found and moulded by the strategist Chanakya, as Alexander’s invasion and retreat leave a power vacuum ripe for the taking.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · Overthrowing the Nandas', 'type': 'timeline',
             'intro': 'Exploiting the unpopularity of the mighty Nanda dynasty, Chandragupta and Chanakya seize Magadha and its capital Pataliputra, founding the Mauryan Empire.', 'events': PHASE_POWER},
            {'id': 'order', 'label': '3 · Seleucus & the Greeks', 'type': 'timeline',
             'intro': 'He faces down Seleucus I Nicator, Alexander’s heir, winning vast western satrapies for 500 elephants and a marriage alliance — and hosts the Greek ambassador Megasthenes.', 'events': PHASE_ORDER},
            {'id': 'state', 'label': '4 · The Mauryan State', 'type': 'timeline',
             'intro': 'Guided by Chanakya’s Arthashastra, he builds an elaborate administration, commands a vast army, and unites most of the subcontinent under a single sovereign.', 'events': PHASE_STATE},
            {'id': 'end', 'label': '5 · Renunciation & Death', 'type': 'timeline',
             'intro': 'At the height of power, tradition says he abdicates, becomes a Jain monk under Bhadrabahu, and dies by sallekhana — ritual fasting — at Shravanabelagola.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Chandragupta’s life is known mainly through later Indian traditions (Buddhist, Jain, Puranic) and Greek notices (Megasthenes via Strabo, Arrian, Pliny, Plutarch); dates are approximate and legend and record often diverge, as noted throughout.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
