# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Tang Taizong (Li Shimin).
The soldier-emperor whose bloody path to the throne opened the model reign of Zhenguan."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b45309'  # Tang imperial gold

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE FOUNDING GENERAL
PHASE_RISE = [
    E('origins', '598–617', 'A restless young aristocrat urges his father to rebel', ['RISE', 'TURNING POINT'],
      'Born in 598 into the powerful Longxi Li aristocracy on the Sui frontier, Li Shimin grows up amid the collapse of the Sui dynasty — and it is he, still a teenager, who pushes his cautious father, the garrison commander Li Yuan, to raise the banner of rebellion from their base at Taiyuan in 617.',
      svg_row('A dynasty collapses and a young man seizes the moment', [
          {'n': 1, 'label': 'Born to the Longxi Li, 598', 'sub': 'mixed Han–Xianbei military aristocracy', 'color': '#b45309'},
          {'n': 2, 'label': 'The Sui dynasty implodes', 'sub': 'revolts erupt after failed Goguryeo wars', 'color': '#b91c1c'},
          {'n': 3, 'label': 'He pushes his father to rise', 'sub': 'urges Li Yuan to rebel from Taiyuan, 617', 'color': '#166534'},
      ], edge_labels=['amid', 'so'], takeaway='The second son, not the heir, was the driving force who turned a hesitant father into a dynasty-founder.', accent=AC),
      bg='<b>Li Shimin</b> was born in 598 into the <b>Longxi Li</b>, a mixed Han–Xianbei military aristocracy that had served the northern dynasties and the Sui.',
      people='his father <b>Li Yuan</b> (Duke of Tang, Sui garrison commander at Taiyuan); the crumbling <b>Sui</b> court of Emperor Yang; rebel warlords across the empire.',
      what='As the Sui dynasty collapsed under rebellion after its ruinous Goguryeo campaigns, the young Li Shimin <b>urged his hesitant father to raise a revolt from Taiyuan in 617</b> and march on the capital.',
      crux='He supplied the <b>nerve and ambition</b> his cautious father lacked — the junior son driving the family to seize a throne.',
      conseq='Li Yuan committed, and the Tang cause was launched toward the Sui capital at Chang’an.',
      matters='Great turns of history often hinge on one bold voice — here a teenager who saw opportunity where his elders saw only risk.'),

    E('founding', '617–618', 'The Tang dynasty is founded', ['RISE', 'BATTLE'],
      'The Li army takes the great Sui capital of Chang’an, and in 618 Li Yuan proclaims himself emperor — the founder Gaozu of a new Tang dynasty. Li Shimin, made Prince of Qin, emerges as its most brilliant field commander, the sword-arm of the young regime.',
      svg_stack('From rebel march to imperial dynasty', [
          {'n': 1, 'label': 'Chang’an falls to the Li army', 'sub': 'the Sui capital taken, 617', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Li Yuan proclaimed Emperor Gaozu, 618', 'sub': 'the Tang dynasty founded', 'color': '#b45309'},
          {'n': 3, 'label': 'Li Shimin made Prince of Qin', 'sub': 'the dynasty’s foremost general', 'color': '#166534'},
      ], takeaway='The Tang was founded in 618 — but it was still a small state ringed by rival warlords, and Li Shimin its sharpest weapon.', accent=AC),
      bg='After seizing Chang’an, the Li family deposed the Sui and, in <b>618</b>, Li Yuan took the throne as <b>Emperor Gaozu</b>, first ruler of the Tang.',
      people='<b>Emperor Gaozu</b> (Li Yuan); his eldest son and heir <b>Li Jiancheng</b>; <b>Li Shimin</b>, now Prince of Qin; the third son Li Yuanji.',
      what='In 618 the Tang dynasty was proclaimed with Li Yuan as emperor. His second son was made <b>Prince of Qin</b> and given command of the armies that would fight for control of a fractured China.',
      crux='The new dynasty ruled only a fraction of China; its survival depended on <b>military conquest</b>, and that fell largely to Li Shimin.',
      conseq='Over the next years he led the campaigns that turned a regional Tang state into master of the empire.',
      matters='Founding a dynasty is only the start — holding and expanding it takes a general, and the Tang had a formidable one.'),

    E('unification', '618–624', 'Winning the empire at Hulao and beyond', ['RISE', 'BATTLE', 'TRIUMPH'],
      'Li Shimin wins a string of decisive campaigns that unify China under the Tang — crushing rival warlords, and in 621 at the Battle of Hulao capturing two enemies at once by defeating Dou Jiande’s relief army and forcing the surrender of Wang Shichong’s Luoyang. He becomes the indispensable, glory-laden hero of the dynasty.',
      svg_row('The general who unified China', [
          {'n': 1, 'label': 'Serial campaigns, 618–24', 'sub': 'defeats Xue Rengao, Liu Wuzhou and others', 'color': '#b45309'},
          {'n': 2, 'label': 'Battle of Hulao, 621', 'sub': 'beats Dou Jiande, takes Wang Shichong’s Luoyang', 'color': '#b91c1c'},
          {'n': 3, 'label': 'China reunified under Tang', 'sub': 'Li Shimin the dynasty’s celebrated hero', 'color': '#166534'},
      ], edge_labels=['at', 'yields'], takeaway='At Hulao he destroyed two rival regimes in one stroke — the campaign that made the Tang supreme and made his own fame dangerous.', accent=AC),
      bg='The early Tang faced a ring of rival warlords. Li Shimin took the field against them, winning victory after victory.',
      people='the warlords <b>Wang Shichong</b> (holding Luoyang) and <b>Dou Jiande</b> (his would-be rescuer); Li Shimin’s veteran officers; his watchful brothers at court.',
      what='At the <b>Battle of Hulao (621)</b> Li Shimin blocked and smashed Dou Jiande’s relief army, then forced Wang Shichong’s surrender — <b>eliminating two rival states in a single campaign</b> and effectively reunifying China under the Tang.',
      crux='His victories made him <b>the empire’s indispensable man</b> — and his towering prestige made him a threat to his elder brother the heir.',
      conseq='Showered with unprecedented honours, Li Shimin now overshadowed the crown prince, setting brother against brother.',
      matters='The very success that saves a dynasty can poison its succession — a general too glorious becomes a rival to the throne.'),
]

# ==================================================================  PHASE 2 — THE XUANWU GATE
PHASE_POWER = [
    E('rivalry', '624–626', 'Brother against brother — the poisoned succession', ['POLITICS', 'TRAGEDY'],
      'Peace turns the brothers on one another. The crown prince Li Jiancheng, fearing his brilliant younger brother, allies with the third brother Li Yuanji to isolate and destroy Li Shimin — court intrigue, poisonings and plots — while the Prince of Qin builds his own faction of loyal generals and scholars.',
      svg_compare('Two factions at a single court', {
          'head': 'The heir’s camp', 'color': '#b91c1c',
          'items': ['Crown Prince Li Jiancheng, the legitimate heir',
                    'Allied with third brother Li Yuanji',
                    'Backed by much of the palace and their father’s favour',
                    'Aim: strip Li Shimin of troops and allies'],
      }, {
          'head': 'The Prince of Qin’s camp', 'color': '#b45309',
          'items': ['Li Shimin, the victorious general',
                    'Loyal warriors — Yuchi Jingde, Zhangsun Wuji',
                    'Scholars of his own Institute of Literature',
                    'Aim: survive, then strike first'],
      }, verdict='A zero-sum struggle in which only one brother could live to rule', takeaway='By 626 the contest was no longer for honour but for survival — one side had to destroy the other.', accent=AC),
      bg='With the wars won, the rivalry between the heir and the war-hero turned deadly. Neither could feel safe while the other lived.',
      people='<b>Li Jiancheng</b>, the crown prince; <b>Li Yuanji</b>, the third brother allied to him; <b>Li Shimin</b> and his faction; their father <b>Gaozu</b>, caught between his sons.',
      what='From 624 the <b>crown prince and Li Yuanji schemed to isolate and eliminate Li Shimin</b> — reassigning his officers, alleging plots, reportedly even attempting poison — while Li Shimin gathered his own loyal party.',
      crux='It became a <b>zero-sum fight for survival</b>: with the throne at stake, the loser would not merely lose office but his life.',
      conseq='Convinced he would be killed first, Li Shimin resolved to strike before his brothers could.',
      matters='Unresolved succession is a dynasty’s deadliest flaw — ambiguity between an heir and a hero breeds fratricide.'),

    E('xuanwu', '626', 'The Xuanwu Gate Incident — a fratricide for the throne', ['BATTLE', 'TRAGEDY', 'TURNING POINT'],
      'On a summer morning in 626, Li Shimin ambushes his two brothers at the Xuanwu Gate of the palace. He kills the crown prince Li Jiancheng with his own bow; his warrior Yuchi Jingde kills Li Yuanji. Their households — including nephews — are put to death. It is a naked, bloody coup, and the darkest deed of his life.',
      svg_stack('A palace ambush that seized the empire', [
          {'n': 1, 'label': 'Ambush at the Xuanwu Gate, 626', 'sub': 'Li Shimin strikes first, at the palace’s north gate', 'color': '#111827'},
          {'n': 2, 'label': 'Both brothers killed', 'sub': 'Li Jiancheng shot by Li Shimin; Li Yuanji by Yuchi Jingde', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Their heirs purged', 'sub': 'the brothers’ sons executed to end all rival claims', 'color': '#78350f'},
      ], takeaway='He won the throne by murdering his brothers and their sons — an act of ruthless bloodshed no later virtue would erase.', accent=AC),
      bg='Believing his brothers were about to move against him, Li Shimin pre-empted them at the palace’s northern <b>Xuanwu Gate</b>.',
      people='<b>Li Jiancheng</b> and <b>Li Yuanji</b>, the murdered brothers; the loyal general <b>Yuchi Jingde</b>; the stunned <b>Emperor Gaozu</b>, still on the throne.',
      what='In the summer of 626 Li Shimin <b>ambushed and killed both his brothers at the Xuanwu Gate</b> — personally shooting Li Jiancheng dead — and had their sons executed, wiping out rival lines to the succession.',
      crux='It was a <b>coup by fratricide</b>: raw violence, not law or seniority, that put him within reach of the throne.',
      conseq='With his brothers dead, Li Shimin controlled the palace and dictated terms to his own father.',
      matters='The founder of a golden age began it with murder — a permanent reminder that great rulers are not always good men.'),

    E('accession', '626–627', 'Forcing his father aside — Emperor Taizong', ['POLITICS', 'TRIUMPH'],
      'Days after the killings, the cowed Gaozu names Li Shimin crown prince; within two months the old emperor abdicates. Li Shimin takes the throne as Emperor Taizong, and in 627 proclaims the era name Zhenguan — under which he will rule for the rest of his life.',
      svg_row('From fratricide to the throne', [
          {'n': 1, 'label': 'Named crown prince', 'sub': 'Gaozu bows to the new reality, 626', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Gaozu abdicates', 'sub': 'the father retires; Li Shimin becomes Emperor Taizong', 'color': '#b45309'},
          {'n': 3, 'label': 'The Zhenguan era begins, 627', 'sub': 'the reign name of a coming golden age', 'color': '#166534'},
      ], edge_labels=['then', 'as'], takeaway='He seized power through blood — then set out to prove himself, through governing, the greatest ruler China had known.', accent=AC),
      bg='After the Xuanwu Gate killings, real power lay with Li Shimin; his father’s reign was over in all but name.',
      people='<b>Emperor Gaozu</b>, pressured into retirement; <b>Li Shimin</b>, now Emperor Taizong; the ministers who rallied to the new sovereign.',
      what='Gaozu named Li Shimin crown prince within days, and <b>abdicated within two months</b>. Li Shimin ascended as <b>Emperor Taizong</b>, proclaiming the <b>Zhenguan era</b> from 627.',
      crux='He converted a violent coup into <b>settled legitimacy</b> — and immediately turned to the harder task of ruling well.',
      conseq='The blood-soaked accession opened onto one of the most admired reigns in Chinese history.',
      matters='How power is won and how it is used are separate questions — Taizong’s answer to the second would define his fame.'),
]

# ==================================================================  PHASE 3 — THE REIGN OF ZHENGUAN
PHASE_ORDER = [
    E('remonstrance', '627–643', 'Welcoming criticism — the mirror of Wei Zheng', ['POLITICS', 'REFORM'],
      'Taizong makes a virtue of listening. He surrounds himself with frank advisers — above all Wei Zheng, who had served his dead rival — and demands honest remonstrance rather than flattery. When Wei dies in 643, Taizong mourns that he has lost a mirror in which to see his own faults.',
      svg_stack('A ruler who invited to be corrected', [
          {'n': 1, 'label': 'Employs his enemy’s adviser', 'sub': 'Wei Zheng, once the crown prince’s man', 'color': '#b45309'},
          {'n': 2, 'label': 'Demands frank remonstrance', 'sub': 'blunt criticism valued over flattery', 'color': '#2563eb'},
          {'n': 3, 'label': '“I have lost my mirror”', 'sub': 'Taizong mourns Wei Zheng’s death, 643', 'color': '#166534'},
      ], takeaway='He treated candid criticism as a mirror — the rarest and most valuable thing a powerful ruler can seek out.', accent=AC),
      bg='Taizong believed a ruler could not see his own errors and needed honest men unafraid to point them out.',
      people='<b>Wei Zheng</b>, his celebrated remonstrating minister; capable chancellors like <b>Fang Xuanling</b> and <b>Du Ruhui</b>; his wise consort Empress <b>Zhangsun</b>.',
      what='Taizong <b>actively solicited criticism</b>, retaining and promoting <b>Wei Zheng</b> — who had served his slain brother — precisely because he spoke bluntly. On Wei’s death in 643 the emperor lamented losing “a mirror” to reflect his faults.',
      crux='He understood that <b>power isolates</b>, and made honest counsel an institution rather than a threat.',
      conseq='This culture of remonstrance became the moral core of the Zhenguan reign and its lasting reputation.',
      matters='The mark of a secure ruler is the ability to hear criticism — Taizong made that willingness the heart of good government.'),

    E('institutions', '627–649', 'Good government — laws, ministries and merit', ['POLITICS', 'REFORM', 'TRIUMPH'],
      'Taizong builds the machinery of a model state: the streamlined Three Departments and Six Ministries, a humane and enduring legal code, and an expanded examination system that recruits officials by talent rather than birth — the institutional foundations that later dynasties would copy for a thousand years.',
      svg_row('The scaffolding of an efficient empire', [
          {'n': 1, 'label': 'Three Departments, Six Ministries', 'sub': 'a rationalised central government', 'color': '#b45309'},
          {'n': 2, 'label': 'The Tang Code', 'sub': 'a humane, systematic law later dynasties copied', 'color': '#2563eb'},
          {'n': 3, 'label': 'Examinations by merit', 'sub': 'recruiting talent over aristocratic birth', 'color': '#166534'},
      ], edge_labels=['plus', 'plus'], takeaway='He institutionalised competent, merit-based government — the durable machinery that outlasted the man by centuries.', accent=AC),
      bg='Taizong inherited institutions from the Sui and refined them into a lasting system of imperial administration.',
      people='his scholar-officials and legal drafters; the aspiring gentry who sat the examinations; chancellors <b>Fang Xuanling</b> and <b>Du Ruhui</b>.',
      what='He consolidated the <b>Three Departments and Six Ministries</b>, promulgated a systematic <b>Tang legal code</b> famed for its relative humanity, and expanded the <b>imperial examinations</b> to draw officials from the talented, not only the well-born.',
      crux='He governed through <b>strong institutions and merit</b>, not personal whim — building a state that could run well beyond his lifetime.',
      conseq='The Tang administrative and legal model became the template for East Asian statecraft for over a millennium.',
      matters='The deepest legacy of a great reign is not conquest but institutions — systems of law and merit that outlive their founder.'),

    E('prosperity', '627–649', 'Light taxes and a prosperous people', ['REFORM', 'TRIUMPH'],
      'Taizong governs frugally and lightens the burden on ordinary people. Through the equal-field system land is redistributed to peasant households, taxes and forced labour are reduced, granaries are filled, and — in the legend of the Zhenguan reign — the empire grows so orderly that prices are low and prisons nearly empty.',
      svg_stack('Prosperity built on a light hand', [
          {'n': 1, 'label': 'The equal-field system', 'sub': 'land allotted to peasant households', 'color': '#b45309'},
          {'n': 2, 'label': 'Reduced taxes and corvée', 'sub': 'a lighter burden on the farming people', 'color': '#2563eb'},
          {'n': 3, 'label': 'The “Zhenguan prosperity”', 'sub': 'full granaries, low prices, order in the land', 'color': '#166534'},
      ], takeaway='He measured success by the well-being of ordinary farmers — light taxes and land reform that made the reign a byword for good times.', accent=AC),
      bg='After decades of war and Sui overreach, the population was reduced and exhausted; recovery meant relieving the peasantry.',
      people='the peasant households who received land; the officials who administered the granaries; a frugal court led by Taizong’s example.',
      what='Under the <b>equal-field system</b> land was allotted to farming households, while <b>taxes and forced labour were kept light</b> and state granaries stocked against famine — the basis of the celebrated <b>Zhenguan prosperity</b>.',
      crux='He grasped that <b>a contented, productive peasantry</b> was the true foundation of a strong and stable state.',
      conseq='The reign became the enduring Chinese ideal of good times — a golden age later rulers were measured against.',
      matters='Real strength grows from the bottom up — a ruler who eases the burden on ordinary people builds a durable prosperity.'),
]

# ==================================================================  PHASE 4 — THE HEAVENLY KHAN
PHASE_WAR = [
    E('gokturks', '629–630', 'Breaking the Eastern Turks — the Heavenly Khan', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'Taizong turns on the Eastern Göktürks who had long menaced the Tang, and in a lightning winter campaign in 630 his generals shatter their khaganate and capture their khan. The nomadic peoples of the steppe acclaim Taizong as their “Heavenly Khan” — a Chinese emperor recognised as overlord of the grasslands.',
      svg_row('The emperor who became khan of the steppe', [
          {'n': 1, 'label': 'The Eastern Göktürks threaten Tang', 'sub': 'they had raided to the gates of Chang’an', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Their khaganate shattered, 630', 'sub': 'Tang armies capture Ashina Duobi', 'color': '#b45309'},
          {'n': 3, 'label': 'Acclaimed “Heavenly Khan”', 'sub': 'steppe peoples accept him as overlord', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He did what no Chinese emperor had — was accepted as khan by the nomads themselves, uniting settled and steppe under one ruler.', accent=AC),
      bg='The <b>Eastern Göktürks</b> had raided deep into Tang territory, once reaching near Chang’an itself, humiliating the young dynasty.',
      people='the Turkic khan <b>Ashina Duobi</b> (Jiali Khan); Taizong’s generals, notably <b>Li Jing</b>; the steppe chieftains who submitted.',
      what='In <b>630</b> a swift Tang campaign under Li Jing <b>destroyed the Eastern Göktürk khaganate</b> and captured its khan; the steppe leaders then honoured Taizong with the title <b>“Heavenly Khan” (Tian Kehan)</b>.',
      crux='He fused two roles — <b>Chinese Son of Heaven and steppe overlord</b> — an authority spanning both the sown lands and the grasslands.',
      conseq='Tang power and prestige surged across Inner Asia, opening the way to expansion along the Silk Road.',
      matters='Taizong’s dual title symbolised a cosmopolitan empire — power built on recognition from conquered peoples, not just their submission.'),

    E('westernregions', '635–646', 'Opening the Silk Road — campaigns in the west', ['BATTLE', 'POLITICS'],
      'Taizong extends Tang power deep into Central Asia. His armies subdue the Tuyuhun, annex the oasis kingdom of Gaochang in 640, and destroy the Xueyantuo confederation by 646 — securing the Silk Road trade routes and planting Tang garrisons far out along the roads to the west.',
      svg_stack('Projecting power into Central Asia', [
          {'n': 1, 'label': 'Subdues the Tuyuhun', 'sub': 'campaigns secure the western approaches', 'color': '#b45309'},
          {'n': 2, 'label': 'Annexes Gaochang, 640', 'sub': 'the Silk Road oasis brought under Tang rule', 'color': '#2563eb'},
          {'n': 3, 'label': 'Destroys the Xueyantuo, 646', 'sub': 'the last great steppe rival broken', 'color': '#166534'},
      ], takeaway='He pushed the Tang frontier and its garrisons far west, making the Silk Road a Tang highway and Chang’an its terminus.', accent=AC),
      bg='Beyond the steppe lay the oasis city-states and trade routes of Central Asia, the arteries of the Silk Road.',
      people='the oasis kingdom of <b>Gaochang</b>; the <b>Tuyuhun</b> and the <b>Xueyantuo</b> confederation; Taizong’s far-ranging commanders.',
      what='Tang forces <b>subdued the Tuyuhun</b>, <b>annexed Gaochang in 640</b> (organising protectorates over the Western Regions), and <b>crushed the Xueyantuo by 646</b>, securing the Silk Road corridor.',
      crux='He turned military reach into <b>commercial and cultural connection</b> — an empire plugged into the great trans-Asian trade routes.',
      conseq='Goods, envoys and ideas flowed into Chang’an, making it perhaps the largest and most cosmopolitan city on earth.',
      matters='Frontier power and open trade reinforced each other — conquest along the Silk Road made the Tang a hub of a connected world.'),

    E('goguryeo', '645', 'The limit of conquest — the Goguryeo campaign', ['BATTLE', 'DEFEAT'],
      'Not every campaign succeeds. In 645 Taizong personally leads a great army against the Korean kingdom of Goguryeo; he takes several fortresses but is halted at the siege of Ansi, and with winter closing in and supplies failing he is forced to withdraw — a rare and chastening failure for the conqueror.',
      svg_row('Where the conqueror was stopped', [
          {'n': 1, 'label': 'Invades Goguryeo, 645', 'sub': 'Taizong leads the army in person', 'color': '#b45309'},
          {'n': 2, 'label': 'Halted at Ansi fortress', 'sub': 'a stubborn siege he cannot break', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Forced to withdraw', 'sub': 'winter and failing supplies end the campaign', 'color': '#78350f'},
      ], edge_labels=['but', 'so'], takeaway='Even the Heavenly Khan met his limits — Goguryeo held, and the great soldier-emperor had to retreat.', accent=AC),
      bg='The Korean kingdom of <b>Goguryeo</b>, which had broken the mighty Sui a generation earlier, was Taizong’s unfinished frontier.',
      people='the defenders of <b>Ansi fortress</b>; the Goguryeo strongman Yeon Gaesomun; Taizong, commanding in the field.',
      what='In <b>645</b> Taizong led a personal invasion of Goguryeo, capturing several fortresses but <b>failing to take Ansi</b>; with winter approaching and supplies exhausted, he <b>withdrew</b> without a decisive victory.',
      crux='It exposed the <b>limits of even his generalship</b> — logistics and a determined defence defeating the greatest commander of the age.',
      conseq='Goguryeo would not fall until his son Gaozong’s reign; the failure haunted Taizong’s final years.',
      matters='Even the most gifted conqueror meets ground he cannot take — a reminder that ambition always runs up against hard limits.'),
]

# ==================================================================  PHASE 5 — CULTURE AND LEGACY
PHASE_END = [
    E('openness', '627–649', 'A cosmopolitan golden age — Xuanzang returns', ['REFORM', 'TRIUMPH'],
      'Under Taizong, Chang’an becomes a dazzling, open capital where foreign merchants, envoys and faiths mingle. The monk Xuanzang returns in 645 from his epic pilgrimage to India, and Taizong — impressed — sponsors the translation of the Buddhist scriptures he brings, a symbol of the reign’s cultural confidence and openness.',
      svg_stack('An open capital at the world’s crossroads', [
          {'n': 1, 'label': 'Chang’an, a cosmopolitan capital', 'sub': 'foreign traders, envoys and religions welcomed', 'color': '#b45309'},
          {'n': 2, 'label': 'Xuanzang returns from India, 645', 'sub': 'back from a 16-year pilgrimage with scriptures', 'color': '#2563eb'},
          {'n': 3, 'label': 'Taizong sponsors the translations', 'sub': 'state support for learning and Buddhism', 'color': '#166534'},
      ], takeaway='His confident openness made Chang’an a world city — and turned a returning pilgrim’s scriptures into a state cultural project.', accent=AC),
      bg='Secure and prosperous, the Tang under Taizong drew people and ideas from across Asia into its capital.',
      people='the pilgrim-monk <b>Xuanzang</b>, returned from India; the foreign merchants and envoys of Chang’an; scholars and translators under imperial patronage.',
      what='Taizong presided over a <b>cosmopolitan, tolerant capital</b>; when <b>Xuanzang returned in 645</b> from years in India, the emperor received him warmly and <b>sponsored the translation</b> of the Buddhist texts he carried back.',
      crux='He treated <b>cultural openness as a strength</b>, welcoming foreign faiths, peoples and learning rather than fearing them.',
      conseq='The Zhenguan reign became a high point of Chinese cultural confidence and cosmopolitan splendour.',
      matters='Confident empires open their doors — Taizong’s tolerance of foreign ideas was inseparable from the greatness of his age.'),

    E('death', '636–649', 'Empress Zhangsun, succession, and death', ['POLITICS', 'DEATH'],
      'Taizong’s later years bring loss and worry: his wise Empress Zhangsun dies in 636, and a bitter contest among his sons forces him to pass over others for the mild Li Zhi as heir. Aging and ailing after the Goguryeo strain, Taizong dies in 649 — leaving the throne to Li Zhi, the future Emperor Gaozong.',
      svg_row('The close of a great reign', [
          {'n': 1, 'label': 'Empress Zhangsun dies, 636', 'sub': 'the loss of his wise, restraining consort', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Li Zhi named heir', 'sub': 'chosen after his sons’ rivalry', 'color': '#b45309'},
          {'n': 3, 'label': 'Taizong dies, 649', 'sub': 'the throne passes to Emperor Gaozong', 'color': '#111827'},
      ], edge_labels=['then', 'and'], takeaway='He who had killed his brothers for the throne watched his own sons fight over it — the succession he never fully escaped.', accent=AC),
      bg='Taizong’s trusted consort Empress Zhangsun had counselled restraint; her death in 636 removed a steadying influence.',
      people='<b>Empress Zhangsun</b>, his admired wife; his quarrelling sons, among them the deposed Li Chengqian; the chosen heir <b>Li Zhi</b> (Gaozong).',
      what='After Empress Zhangsun’s death in 636 and a <b>destructive rivalry among his sons</b>, Taizong settled on the gentle <b>Li Zhi</b> as heir. Worn down and ill, the emperor <b>died in 649</b>, succeeded by Li Zhi as Emperor Gaozong.',
      crux='The man who seized power by fratricide found <b>his own succession poisoned by rivalry</b> — the family curse he could not fully break.',
      conseq='Under Gaozong and his consort Wu Zetian the Tang would rise further still, on the foundations Taizong laid.',
      matters='A ruler can master an empire yet not his own family — the succession that made Taizong returned to trouble his old age.'),

    E('legacy', '649–present', 'The model emperor — brilliance beside the blood', ['POLITICS', 'TRIUMPH', 'TRAGEDY'],
      'History remembers Taizong as the near-ideal Confucian emperor — the ruler of the Zhenguan golden age, held up for a thousand years as the model of wise, benevolent government. Yet the same man began his reign by murdering his brothers. His legacy is the enduring tension between how power was seized and how nobly it was then used.',
      svg_compare('One emperor, two verdicts', {
          'head': 'The blood at the gate', 'color': '#b91c1c',
          'items': ['Killed both brothers at Xuanwu Gate, 626',
                    'Had their sons executed to secure the throne',
                    'Forced his own father to abdicate',
                    'Reportedly edited the official histories'],
      }, {
          'head': 'The model reign', 'color': '#b45309',
          'items': ['The Zhenguan golden age of good government',
                    'Invited criticism; ruled by law and merit',
                    'Light taxes and a prosperous people',
                    'A cosmopolitan empire and the Heavenly Khan'],
      }, verdict='Chinese tradition honours him as a model ruler while never forgetting the fratricide', takeaway='He is the enduring paradox: a man who came to power by murder and then governed as one of history’s finest emperors.', accent=AC),
      bg='Taizong himself wrote a manual for his heir, the <b>Difan</b> (“Model for an Emperor”), conscious of how rulers would be judged.',
      people='the Confucian historians who idealised him; his heirs and later emperors measured against his standard; the brothers his coup erased.',
      what='Taizong became the <b>archetypal “good emperor”</b> of Chinese tradition — the Zhenguan reign a template of benevolent rule — even as histories recorded the <b>fratricide</b> that opened it and his reputed meddling with the records.',
      crux='His legacy holds a permanent tension: <b>ruthless in seizing power, exemplary in wielding it</b> — greatness and guilt in one man.',
      conseq='For over a millennium, East Asian rulers were urged to govern “as in the Zhenguan reign,” his shadow long over Chinese statecraft.',
      matters='The greatest rulers are rarely simple — Taizong shows that a model reign and a bloody crime can belong to the very same man.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Tang Taizong — Li Shimin — is remembered as one of the greatest emperors in Chinese history, yet he reached the throne by murdering his brothers. The brilliant general who helped his father found the Tang dynasty in 618, he slew his rivals at the Xuanwu Gate in 626 and forced his father to abdicate — then ruled so wisely that his Zhenguan reign became the enduring Chinese ideal of good government: honest counsel, light taxes, merit and law, a cosmopolitan capital, and an empire so powerful the steppe hailed him as “Heavenly Khan.” He is the ultimate study in <b>the gap between how power is seized and how nobly it can then be used.</b></p>
<div class="ov-quote">“Water can carry a boat, yet water can also capsize it.”<span>— a maxim of the Zhenguan reign, on ruler and people</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A restless young aristocrat pushes his father to rebel and wins the empire as the Tang’s greatest general → poisoned rivalry with his brothers drives him to ambush and kill them at the Xuanwu Gate → he forces his father to abdicate and takes the throne as Emperor Taizong → and then governs so well — welcoming criticism, lightening taxes, building law and merit, breaking the Turks as “Heavenly Khan,” and opening a cosmopolitan golden age — that the Zhenguan reign becomes the model of Chinese rule.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🪞</div><h4>Rule by remonstrance</h4><p>Invited honest criticism — Wei Zheng as his “mirror.”</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>Law and merit</h4><p>The Tang Code and examinations, copied for a millennium.</p></div>
  <div class="ov-card"><div class="i">🐎</div><h4>The Heavenly Khan</h4><p>Broke the Eastern Turks and ruled settled and steppe alike.</p></div>
  <div class="ov-card"><div class="i">🗡️</div><h4>Blood at the gate</h4><p>A model reign begun by killing his own brothers.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Founding General</b><small> 598–624</small><p>Wins the empire for the young Tang.</p></div>
  <div><b>2 · The Xuanwu Gate</b><small> 624–627</small><p>Fratricide and the seizure of the throne.</p></div>
  <div><b>3 · The Reign of Zhenguan</b><small> 627–649</small><p>Criticism, law, merit and prosperity.</p></div>
  <div><b>4 · The Heavenly Khan</b><small> 629–645</small><p>Breaking the Turks; the Silk Road; Goguryeo.</p></div>
  <div><b>5 · Culture and Legacy</b><small> 627–present</small><p>A cosmopolitan golden age and its paradox.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Li Yuan (Emperor Gaozu)', 'role': 'his father', 'color': '#b45309',
     'bio': 'The Sui garrison commander whom Li Shimin pushed to rebel, founder of the Tang in 618 — and the father his son forced to abdicate in 626.',
     'rel': 'The father he raised to the throne, then pushed aside.'},
    {'name': 'Li Jiancheng', 'role': 'brother and rival', 'color': '#b91c1c',
     'bio': 'The eldest son and crown prince, Taizong’s chief rival for the succession, killed by Li Shimin himself at the Xuanwu Gate in 626.',
     'rel': 'The heir he murdered to reach the throne.'},
    {'name': 'Wei Zheng', 'role': 'remonstrating minister', 'color': '#166534',
     'bio': 'Once an adviser to the slain crown prince, retained by Taizong for his blunt honesty; the emperor called him the “mirror” in which he saw his own faults.',
     'rel': 'The fearless critic he prized above flatterers.'},
    {'name': 'Empress Zhangsun', 'role': 'his consort', 'color': '#db2777',
     'bio': 'Taizong’s admired and politically astute wife, a voice for restraint at court; her death in 636 removed a steadying influence on the emperor.',
     'rel': 'The wise consort who tempered his rule.'},
    {'name': 'Li Jing', 'role': 'his great general', 'color': '#3730a3',
     'bio': 'The brilliant commander whose lightning winter campaign of 630 shattered the Eastern Göktürk khaganate and won Taizong the title of Heavenly Khan.',
     'rel': 'The general who broke the Turks for him.'},
]

KEY_EVENTS = [
    ('598', 'Li Shimin born', 'Into the Longxi Li military aristocracy.'),
    ('617', 'Urges his father to rebel', 'The Tang rising begins at Taiyuan.'),
    ('618', 'Tang dynasty founded', 'Li Yuan becomes Emperor Gaozu.'),
    ('621', 'Battle of Hulao', 'Two rival regimes crushed in one stroke.'),
    ('626', 'Xuanwu Gate Incident', 'Kills his brothers; seizes the succession.'),
    ('627', 'Zhenguan era begins', 'Reigns as Emperor Taizong.'),
    ('630', 'Eastern Turks broken', 'Acclaimed the “Heavenly Khan.”'),
    ('640', 'Gaochang annexed', 'Tang power reaches the Silk Road.'),
    ('645', 'Xuanzang returns; Goguryeo fails', 'A golden age, and a rare defeat.'),
    ('649', 'Death of Taizong', 'Succeeded by his son Gaozong.'),
]

MASTER = [
    {'year': '598', 'age': 'born', 'phase': 'Founding General', 'title': 'Born Li Shimin', 'desc': 'Of the Longxi Li aristocracy.'},
    {'year': '618', 'age': 'age 20', 'phase': 'Founding General', 'title': 'Tang founded', 'desc': 'His father takes the throne.'},
    {'year': '621', 'age': 'age 23', 'phase': 'Founding General', 'title': 'Battle of Hulao', 'desc': 'He unifies China for the Tang.'},
    {'year': '626', 'age': 'age 28', 'phase': 'The Xuanwu Gate', 'title': 'Xuanwu Gate Incident', 'desc': 'Kills his brothers; seizes power.'},
    {'year': '627', 'age': 'age 29', 'phase': 'Reign of Zhenguan', 'title': 'Zhenguan era begins', 'desc': 'The model reign opens.'},
    {'year': '630', 'age': 'age 32', 'phase': 'Heavenly Khan', 'title': 'Breaks the Eastern Turks', 'desc': 'Hailed the Heavenly Khan.'},
    {'year': '645', 'age': 'age 47', 'phase': 'Heavenly Khan', 'title': 'Xuanzang; Goguryeo', 'desc': 'Golden age, and a checked campaign.'},
    {'year': '649', 'age': 'age 51', 'phase': 'Culture and Legacy', 'title': 'Death of Taizong', 'desc': 'The Zhenguan ideal endures.'},
]

SOURCES = [
    ('Britannica — Taizong (emperor of Tang dynasty)', 'https://www.britannica.com/biography/Taizong-emperor-of-Tang-dynasty'),
    ('Wikipedia — Emperor Taizong of Tang', 'https://en.wikipedia.org/wiki/Emperor_Taizong_of_Tang'),
    ('Wikipedia — Xuanwu Gate Incident', 'https://en.wikipedia.org/wiki/Xuanwu_Gate_Incident'),
    ('World History Encyclopedia — Tang Dynasty', 'https://www.worldhistory.org/Tang_Dynasty/'),
    ('Wikipedia — Tang campaign against the Eastern Turks', 'https://en.wikipedia.org/wiki/Tang_campaign_against_the_Eastern_Turks'),
]

def build_meta():
    return {
        'pid': 'gm-tangtaizong.html', 'kind': 'man', 'emoji': '🐉', 'accent': AC,
        'name': 'Tang Taizong', 'years': '598–649', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The soldier-emperor who helped found the Tang and seized its throne by killing his brothers — then ruled so wisely that his Zhenguan reign became the enduring Chinese model of good government.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Founding General', 'type': 'timeline',
             'intro': 'A restless young aristocrat pushes his father to rebel against the collapsing Sui, and wins the empire for the new Tang dynasty as its most brilliant general.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · The Xuanwu Gate', 'type': 'timeline',
             'intro': 'Peace turns the brothers on one another; Li Shimin ambushes and kills his rivals at the Xuanwu Gate, then forces his father to abdicate and takes the throne as Emperor Taizong.', 'events': PHASE_POWER},
            {'id': 'order', 'label': '3 · The Reign of Zhenguan', 'type': 'timeline',
             'intro': 'On the throne he governs as a model ruler — welcoming honest criticism, building law and merit, and lightening the burden on the people in the celebrated Zhenguan reign.', 'events': PHASE_ORDER},
            {'id': 'war', 'label': '4 · The Heavenly Khan', 'type': 'timeline',
             'intro': 'His armies break the Eastern Turks and open the Silk Road, and the steppe hails him as Heavenly Khan — though Goguryeo shows the limits of even his conquest.', 'events': PHASE_WAR},
            {'id': 'end', 'label': '5 · Culture and Legacy', 'type': 'timeline',
             'intro': 'A cosmopolitan golden age welcomes the pilgrim Xuanzang home; loss and succession trouble his final years, and history remembers him as a model emperor beside the blood of his rise.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; the Zhenguan reign is partly known through official histories Taizong is thought to have influenced, and famous maxims of the reign are read as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
