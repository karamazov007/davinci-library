# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Mahatma Gandhi.
The lawyer who forged nonviolent resistance into a weapon and led a subcontinent to freedom."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b45309'  # khadi ochre

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING
PHASE_MAKING = [
    E('porbandar', '1869–1888', 'A merchant’s son in Porbandar', ['RISE', 'ORIGINS'],
      'Mohandas Karamchand Gandhi is born in 1869 in the coastal town of Porbandar, into a devout Hindu family of the merchant caste — shaped by his father’s service as a local official, his mother’s intense piety and vegetarianism, and a child marriage at thirteen to Kasturba, all of which plant the seeds of the values he would later make world-famous.',
      svg_row('The roots of a reformer', [
          {'n': 1, 'label': 'Born in Porbandar, 1869', 'sub': 'merchant-caste family; father a local dewan', 'color': '#b45309'},
          {'n': 2, 'label': 'A pious, plural household', 'sub': 'mother’s vows and fasts; Jain and Hindu influences', 'color': '#166534'},
          {'n': 3, 'label': 'Married at thirteen', 'sub': 'wed to Kasturba by custom of the day', 'color': '#a16207'},
      ], edge_labels=['shaped by', 'and'], takeaway='An ordinary, shy provincial boy — steeped in a household of faith, fasting and tolerance that would echo through his whole life.', accent=AC),
      bg='<b>Mohandas Karamchand Gandhi</b> was born on 2 October 1869 in <b>Porbandar</b>, in western India’s Gujarat, into a family of the Vaishya (merchant) caste; his father served as dewan (chief minister) of the small princely state.',
      people='his father <b>Karamchand Gandhi</b>; his devout mother <b>Putlibai</b>; his wife <b>Kasturba</b>, married to him in childhood.',
      what='Gandhi grew up in a pious Hindu home touched by <b>Jain ideals of nonviolence and vegetarianism</b>, and was <b>married at about thirteen</b> to Kasturba — customs he later criticised even as they shaped him. He was by his own account a shy, unremarkable student.',
      crux='His moral universe — <b>ahimsa, fasting, self-restraint and religious tolerance</b> — was absorbed at home long before it became a political method.',
      conseq='At eighteen, restless and ambitious, he resolved to leave India to study law in England.',
      matters='The greatest movements often begin in ordinary homes — Gandhi’s revolutionary method grew from the everyday faith of a provincial merchant family.'),

    E('london', '1888–1891', 'Studying law in London', ['RISE', 'POLITICS'],
      'Gandhi sails to London to train as a barrister at the Inner Temple — a homesick, awkward young man who keeps a vow to his mother to shun meat and drink, discovers vegetarian societies and comparative religion, and returns to India in 1891 a qualified but painfully diffident lawyer.',
      svg_stack('An awkward apprenticeship abroad', [
          {'n': 1, 'label': 'To London for the bar, 1888', 'sub': 'trains as a barrister at the Inner Temple', 'color': '#b45309'},
          {'n': 2, 'label': 'Keeps his vows abroad', 'sub': 'vegetarianism; reads the Gita and the Gospels', 'color': '#166534'},
          {'n': 3, 'label': 'Called to the bar, 1891', 'sub': 'returns to India a qualified but shy lawyer', 'color': '#a16207'},
      ], takeaway='England made him a lawyer and, unexpectedly, a seeker — he left with a profession and the first stirrings of a philosophy.', accent=AC),
      bg='In 1888 Gandhi travelled to <b>London to study law</b>, defying caste elders who opposed the sea voyage. He had promised his mother to abstain from meat, alcohol and women.',
      people='the London <b>vegetarian societies</b> he joined; the Theosophists who introduced him to the <b>Bhagavad Gita</b>; his patient wife and family back home.',
      what='Gandhi qualified as a <b>barrister at the Inner Temple in 1891</b>. Struggling with English manners, he found community among vegetarians and read widely across religions — the Gita, the Sermon on the Mount — beginning a lifelong search for a moral core.',
      crux='He learned that <b>keeping a difficult vow</b> could be a source of strength, not weakness — a lesson central to his later self-discipline.',
      conseq='Back in India his legal career flopped; too timid to argue in court, he jumped at an offer of work in South Africa.',
      matters='Formative years abroad can plant ideas that lie dormant for decades — Gandhi’s London reading seeded the philosophy he would later act upon.'),

    E('sailstosa', '1893', 'A briefless lawyer sails for South Africa', ['RISE', 'TURNING POINT'],
      'Unable to make a living at the Indian bar, Gandhi accepts a one-year contract to handle a lawsuit for an Indian firm in South Africa — a modest commercial errand that would, unexpectedly, become the crucible in which he discovered his life’s calling.',
      svg_row('An errand that changed a life', [
          {'n': 1, 'label': 'Failure at the Indian bar', 'sub': 'too shy to plead; briefless in Bombay', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A contract in South Africa', 'sub': 'a year’s work for an Indian trading firm', 'color': '#b45309'},
          {'n': 3, 'label': 'Sails east, 1893', 'sub': 'expecting a brief job, not a mission', 'color': '#a16207'},
      ], edge_labels=['so', 'and'], takeaway='He went abroad for a paycheque and a single case — and stayed twenty-one years to become a leader of men.', accent=AC),
      bg='Gandhi’s attempt to practise law in Bombay failed; he could barely speak in court. In 1893 an Indian Muslim firm, Dada Abdulla &amp; Co., offered him a year’s legal work in <b>Natal, South Africa</b>.',
      people='the merchant firm that hired him; the large community of <b>Indian traders and indentured labourers</b> in South Africa he would come to champion.',
      what='Gandhi accepted the modest assignment and <b>sailed for South Africa in 1893</b>, intending to stay a single year and return. Instead he encountered a rigid system of racial discrimination against Indians that would transform him.',
      crux='A career dead-end pushed him toward the arena where he would <b>find his true vocation</b> — chance and character combined.',
      conseq='Within days of arriving, an act of racial humiliation would set him on the path to political activism.',
      matters='A life’s turning point can wear the disguise of an ordinary job — Gandhi’s greatest chapter began as a one-year contract.'),
]

# ==================================================================  PHASE 2 — THE SOUTH AFRICAN CRUCIBLE
PHASE_SA = [
    E('train', '1893', 'Thrown off the train at Pietermaritzburg', ['TURNING POINT', 'TRAGEDY'],
      'Holding a valid first-class ticket, Gandhi is ordered to a third-class carriage because he is Indian, refuses, and is thrown off the train into the cold night at Pietermaritzburg station — a night of humiliation he later called the most creative experience of his life, and the moment his political awakening began.',
      svg_stack('The night that made an activist', [
          {'n': 1, 'label': 'A first-class ticket, denied', 'sub': 'ordered out because of his race', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Thrown off at Pietermaritzburg', 'sub': 'left on the platform in the cold, 1893', 'color': '#b45309'},
          {'n': 3, 'label': 'A resolve is born', 'sub': 'decides to resist injustice, not flee it', 'color': '#166534'},
      ], takeaway='A private humiliation became a public calling — that cold platform is where the shy lawyer resolved to fight.', accent=AC),
      bg='Soon after arriving, Gandhi travelled by rail from Durban toward Pretoria. Racial rules in South Africa barred Indians (and Africans) from privileges reserved for whites, regardless of ticket or class.',
      people='the white official and passengers who ejected him; the countless <b>Indians</b> subject to the same daily indignities he now shared.',
      what='At <b>Pietermaritzburg station</b>, Gandhi was thrown off the train for refusing to leave a first-class carriage. Sitting through the night in the cold waiting room, he resolved not to accept injustice but to <b>fight it</b>.',
      crux='He chose to stay and <b>confront discrimination</b> rather than pocket his fee and go home — turning personal grievance into principled resistance.',
      conseq='He extended his stay to organise Natal’s Indians, founding the Natal Indian Congress in 1894 and building a movement.',
      matters='One act of injustice, met with resolve instead of resignation, can ignite a lifetime of struggle — and history.'),

    E('satyagraha', '1894–1910', 'Forging satyagraha — the force of truth', ['POLITICS', 'REFORM'],
      'Over two decades in South Africa Gandhi builds and names his signature method — satyagraha, or “truth-force”: disciplined, nonviolent civil resistance rooted in ahimsa and self-suffering — and lives it out in the communes of Phoenix Settlement and Tolstoy Farm, testing simplicity, self-reliance and shared toil.',
      svg_stack('Truth-force takes shape', [
          {'n': 1, 'label': 'From grievance to method', 'sub': 'nonviolent resistance rooted in ahimsa', 'color': '#b45309'},
          {'n': 2, 'label': 'Named “satyagraha”', 'sub': 'truth-force: resist injustice, accept suffering', 'color': '#166534'},
          {'n': 3, 'label': 'Lived on the communes', 'sub': 'Phoenix Settlement and Tolstoy Farm', 'color': '#a16207'},
      ], takeaway='He did not invent nonviolence, but he forged it into a disciplined political weapon — and named it.', accent=AC),
      bg='Facing escalating anti-Indian laws, Gandhi developed a philosophy of resistance drawing on Hindu and Jain <b>ahimsa</b>, the Gita, Tolstoy and Thoreau. He coined the term <b>satyagraha</b> to distinguish it from mere “passive resistance.”',
      people='the Indian labourers and traders he mobilised; influences like <b>Leo Tolstoy</b> and <b>Henry David Thoreau</b>; his co-workers on the communal farms.',
      what='Gandhi defined <b>satyagraha</b> as nonviolent insistence on truth — breaking unjust laws openly and accepting the penalty without retaliation. He founded the <b>Phoenix Settlement (1904)</b> and <b>Tolstoy Farm (1910)</b> to live simply and train resisters.',
      crux='His core insight: <b>moral force and voluntary suffering</b> could confront state power more effectively than violence, converting rather than crushing the opponent.',
      conseq='Satyagraha gave Indians a disciplined tool to defy discriminatory laws — and gave Gandhi a method he would carry to India.',
      matters='Gandhi turned a moral ideal into a practical technique of struggle — nonviolence as organised political action, not passivity.'),

    E('salaws', '1906–1914', 'Defying the anti-Indian laws — and a first victory', ['BATTLE', 'TRIUMPH'],
      'Gandhi leads mass campaigns against South Africa’s discriminatory laws — burning the compulsory registration certificates of the “Black Act,” resisting the poll tax and a ruling that invalidated Indian marriages, filling the jails — until a settlement with General Smuts in 1914 wins real concessions and he returns to India in 1915, tested and transformed.',
      svg_row('Filling the jails to win reform', [
          {'n': 1, 'label': 'Unjust laws imposed', 'sub': 'registration passes, poll tax, marriage ban', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Mass nonviolent defiance', 'sub': 'certificates burned; thousands court arrest', 'color': '#b45309'},
          {'n': 3, 'label': 'The Gandhi–Smuts pact, 1914', 'sub': 'concessions won; he sails for India', 'color': '#166534'},
      ], edge_labels=['met by', 'yields'], takeaway='He proved satyagraha could actually win — disciplined mass defiance forced a hostile government to the table.', accent=AC),
      bg='From 1906, South Africa tightened controls on Indians: compulsory registration (the “<b>Black Act</b>”), a poll tax on ex-indentured labourers, and a 1913 court ruling that nullified non-Christian marriages, insulting Indian women.',
      people='the Boer statesman <b>Jan Smuts</b>, his adversary and negotiating partner; the thousands of Indian men and women, including Kasturba, who courted arrest.',
      what='Gandhi led Indians to <b>publicly burn registration certificates</b>, cross provincial borders illegally, and strike — enduring imprisonment and violence. The <b>1913–14 campaign</b> forced the <b>Gandhi–Smuts agreement</b>, easing the tax, recognising Indian marriages, and softening the pass laws.',
      crux='He showed that <b>sustained, disciplined mass suffering</b> could extract concrete political concessions from a powerful state.',
      conseq='Vindicated, Gandhi left South Africa in 1914 and returned to India in <b>January 1915</b> as a proven leader. (His early attitudes toward Black Africans, narrower than his later universalism, remain debated by historians.)',
      matters='South Africa was Gandhi’s laboratory — he arrived a timid lawyer and left a seasoned leader with a tested weapon.'),
]

# ==================================================================  PHASE 3 — THE INDIAN LEADER EMERGES
PHASE_RISE = [
    E('return', '1915–1919', 'Return to India — finding the pulse of the nation', ['POLITICS', 'RISE'],
      'Gandhi returns to India in 1915 on the advice of his political mentor Gokhale, who urges him to spend a year travelling third-class and simply listening before speaking — and he founds the Sabarmati ashram, adopts the dress and idiom of the Indian poor, and prepares to make the Indian National Congress a mass movement.',
      svg_stack('Learning India before leading it', [
          {'n': 1, 'label': 'Returns to India, 1915', 'sub': 'mentored by Gopal Krishna Gokhale', 'color': '#b45309'},
          {'n': 2, 'label': 'Travels and listens', 'sub': 'third-class trains; the ashram at Sabarmati', 'color': '#166534'},
          {'n': 3, 'label': 'Speaks the people’s language', 'sub': 'plain dress, plain living, mass idiom', 'color': '#a16207'},
      ], takeaway='He earned leadership by first understanding the led — a year of listening before a lifetime of leading.', accent=AC),
      bg='Already famous for South Africa, Gandhi returned home in <b>January 1915</b>. His mentor <b>Gokhale</b> of the Indian National Congress advised him to travel and observe India for a year before entering politics.',
      people='his mentor <b>Gokhale</b>; the mass membership of the <b>Indian National Congress</b>, then a genteel elite body; the ordinary peasants he would mobilise.',
      what='Gandhi criss-crossed India, founded the <b>Sabarmati ashram</b> near Ahmedabad, and adopted simple homespun dress — positioning himself to transform the Congress from a lawyers’ debating society into a <b>mass movement</b> rooted in the villages.',
      crux='He grasped that Indian freedom required <b>mobilising the peasant masses</b>, not just petitioning in English — a shift in the whole scale of the movement.',
      conseq='He soon put satyagraha to the test in India for the first time, in Champaran and Kheda.',
      matters='Great leaders study their ground before they act — Gandhi rebuilt his method for India by first learning India.'),

    E('champaran', '1917–1918', 'Champaran and Kheda — satyagraha comes home', ['BATTLE', 'REFORM'],
      'Gandhi wins his first Indian victories by leading the indigo farmers of Champaran against exploitative planters and the peasants of Kheda against unfair taxes during famine — modest, local, nonviolent campaigns that prove satyagraha works on Indian soil and win him the trust and the title of the masses.',
      svg_row('First Indian satyagrahas', [
          {'n': 1, 'label': 'Champaran indigo, 1917', 'sub': 'ryots forced to grow indigo for planters', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Kheda tax revolt, 1918', 'sub': 'famine-hit peasants refuse unjust land tax', 'color': '#b45309'},
          {'n': 3, 'label': 'The people’s Mahatma', 'sub': 'concessions won; nationwide trust earned', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='Local wins for the poorest peasants proved satyagraha worked in India — and made Gandhi a national figure.', accent=AC),
      bg='In <b>Champaran</b> (Bihar), British planters forced tenant farmers to grow indigo on ruinous terms. In <b>Kheda</b> (Gujarat), a failed harvest left peasants unable to pay the land tax, which authorities refused to suspend.',
      people='the exploited <b>indigo ryots</b> and Kheda peasants; young lieutenants like <b>Vallabhbhai Patel</b> and Rajendra Prasad who joined him; the colonial officials he pressed.',
      what='In <b>Champaran (1917)</b> Gandhi organised inquiry and nonviolent protest that won the farmers relief; in <b>Kheda (1918)</b> he led a tax-refusal campaign that gained concessions. Both used disciplined satyagraha and local organisation.',
      crux='He proved the method could <b>redress concrete local grievances</b> in India, building credibility from the ground up rather than the top down.',
      conseq='These successes vaulted Gandhi to the front rank of the nationalist movement, poised to lead its first all-India campaign.',
      matters='He built a mass movement one local victory at a time — trust for a national struggle earned in the fields of Bihar and Gujarat.'),

    E('noncooperation', '1920–1922', 'The Non-Cooperation Movement', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'Enraged by the Rowlatt Act and the Amritsar massacre, Gandhi launches the Non-Cooperation Movement — urging Indians to boycott British schools, courts, titles and goods and to spin their own cloth — turning the Congress into a mass force, until mob violence at Chauri Chaura leads him to call the whole campaign off.',
      svg_stack('Withdrawing consent from the Raj', [
          {'n': 1, 'label': 'Outrage at repression', 'sub': 'Rowlatt Act; the Amritsar massacre, 1919', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Non-Cooperation launched, 1920', 'sub': 'boycott schools, courts, titles, foreign cloth', 'color': '#b45309'},
          {'n': 3, 'label': 'Called off after Chauri Chaura', 'sub': 'mob violence prompts Gandhi to halt, 1922', 'color': '#78350f'},
      ], takeaway='He mobilised millions to simply withdraw their cooperation — then stopped it all when it turned violent, prizing means over speed.', accent=AC),
      bg='The repressive <b>Rowlatt Act (1919)</b> and the <b>Jallianwala Bagh (Amritsar) massacre</b>, where troops fired on an unarmed crowd, destroyed Indian faith in British reform and radicalised the nationalist movement.',
      people='the millions who joined the boycott; Congress leaders like <b>Motilal and Jawaharlal Nehru</b>; the Khilafat Muslims who allied with him; the police killed at Chauri Chaura.',
      what='From <b>1920</b> Gandhi led the <b>Non-Cooperation Movement</b>: boycotting British institutions and goods, surrendering titles, and promoting <b>khadi</b> (homespun cloth). When a mob burned a police station killing officers at <b>Chauri Chaura (Feb 1922)</b>, he suspended the campaign, insisting nonviolence was non-negotiable.',
      crux='He held that <b>a just end could not be won by unjust means</b> — even at the cost of momentum, the movement had to stay nonviolent.',
      conseq='Gandhi was arrested and jailed for sedition; critics faulted him for halting a rising tide, but his moral authority endured. He now dominated the Congress.',
      matters='Gandhi’s insistence that means and ends are inseparable defined his leadership — and set his movement apart from ordinary revolutions.'),
]

# ==================================================================  PHASE 4 — THE MAHATMA'S CREED AND MASS DEFIANCE
PHASE_DEFIANCE = [
    E('creed', '1920s–1940s', 'Ahimsa, swaraj and the spinning wheel', ['POLITICS', 'REFORM'],
      'At the heart of Gandhi’s programme lies a distinctive creed — ahimsa (nonviolence) as the highest law, swaraj (self-rule) as the goal, and khadi and the charkha (the spinning wheel) as the daily practice of self-reliance — a vision that fuses political freedom with moral and economic self-discipline.',
      svg_compare('A political creed, and its rival', {
          'head': 'Gandhi’s way',
          'color': '#166534',
          'items': ['Ahimsa: nonviolence as the highest duty', 'Swaraj: self-rule, moral and political', 'Khadi and the charkha: self-reliance', 'Convert the opponent, not destroy him', 'Village-rooted, plain living']},
        {
          'head': 'The violent path he rejected',
          'color': '#b91c1c',
          'items': ['Armed revolt against the Raj', 'Terror and assassination', 'Dependence on modern industry', 'Crush the opponent by force', 'Power seized, not conscience won']},
        verdict='Gandhi wagered that self-suffering and self-reliance would outlast the gun.',
        takeaway='His creed made economics and ethics part of the freedom struggle — the spinning wheel was a political act.', accent=AC),
      bg='Gandhi wove his politics into a whole philosophy of life. <b>Ahimsa</b> (nonviolence) and <b>satya</b> (truth) were its foundation; <b>swaraj</b> (self-rule) its aim; and <b>khadi</b>, hand-spun cloth, its everyday discipline.',
      people='the millions who took up the <b>charkha</b>; critics who thought hand-spinning economically naive; admirers worldwide who adopted his ideals.',
      what='Gandhi urged Indians to <b>spin their own cloth</b>, boycott British textiles, and build village self-reliance, making the <b>spinning wheel</b> the emblem of the movement. He tied political freedom to <b>moral self-discipline and economic independence</b>.',
      crux='He insisted that <b>how a nation frees itself shapes what it becomes</b> — swaraj meant self-mastery, not merely a change of rulers.',
      conseq='The charkha became the symbol on the Congress flag; khadi remains a badge of Indian nationalism. Some allies doubted its economics even as they embraced its symbolism.',
      matters='Gandhi fused ends and means, politics and ethics — freedom, for him, was inseparable from self-reliance and nonviolence.'),

    E('saltmarch', '1930–1931', 'The Salt March to Dandi', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'Gandhi launches civil disobedience with a stroke of genius — a 240-mile march to the sea at Dandi to make salt in defiance of the British monopoly — a simple, universal act that electrifies India, fills the jails with tens of thousands, and dramatises the injustice of the Raj before the whole world.',
      svg_stack('Breaking the salt law', [
          {'n': 1, 'label': 'The march begins, March 1930', 'sub': 'Gandhi walks ~240 miles from Sabarmati', 'color': '#b45309'},
          {'n': 2, 'label': 'Salt made at Dandi', 'sub': 'defies the British salt monopoly, 6 April', 'color': '#166534'},
          {'n': 3, 'label': 'Mass civil disobedience', 'sub': 'tens of thousands jailed; world attention', 'color': '#a16207'},
      ], takeaway='He chose the humblest possible symbol — a pinch of salt — and turned it into a challenge that shook an empire.', accent=AC),
      bg='By 1930 the Congress had declared <b>purna swaraj</b> (complete independence) its goal. Gandhi sought a single, vivid act of defiance every Indian could join. He fixed on <b>salt</b>, taxed and monopolised by the British though it was free from the sea.',
      people='the marchers who set out with him; his lieutenants across India who led parallel protests; Viceroy <b>Lord Irwin</b>, his eventual negotiating partner.',
      what='On <b>12 March 1930</b> Gandhi began the <b>Salt March</b> from Sabarmati, reaching the coast at <b>Dandi on 6 April</b> and picking up salt in symbolic breach of the law. Mass salt-making and boycotts followed; roughly <b>60,000 were jailed</b>, and images of nonviolent protesters beaten at Dharasana appalled world opinion.',
      crux='He turned an <b>abstract injustice into a concrete, universal act</b> — anyone could make salt, so anyone could resist.',
      conseq='The campaign forced the British to negotiate; the <b>Gandhi–Irwin Pact (1931)</b> freed prisoners and brought Gandhi to the Round Table Conference in London as the Congress’s sole representative.',
      matters='The Salt March is a masterclass in symbolic politics — dramatising a cause so simply that the whole world grasped its justice.'),

    E('fasts', '1932–1944', 'Fasts and imprisonments — the weapon of self-suffering', ['POLITICS', 'TRAGEDY'],
      'Gandhi spends years of his life in British jails and turns the fast into a political and moral weapon — most controversially his 1932 “fast unto death” against separate electorates for the Dalits, which forces the Poona Pact with Ambedkar — wielding self-suffering to move consciences even as critics call it moral coercion.',
      svg_row('Self-suffering as a weapon', [
          {'n': 1, 'label': 'Years behind bars', 'sub': 'repeatedly jailed across three decades', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The fast unto death, 1932', 'sub': 'against separate electorates for Dalits', 'color': '#b45309'},
          {'n': 3, 'label': 'The Poona Pact', 'sub': 'agreement with Ambedkar; debated ever since', 'color': '#78350f'},
      ], edge_labels=['and', 'yields'], takeaway='He made his own body the battleground — a method of immense moral power that critics called coercion by conscience.', accent=AC),
      bg='Gandhi was imprisoned many times by the British and used <b>fasting</b> both to purify himself and to press political demands. In 1932 the British granted a <b>separate electorate</b> for the “Depressed Classes” (Dalits), which Gandhi feared would splinter Hindu society.',
      people='<b>B. R. Ambedkar</b>, the Dalit leader who championed separate electorates; the British authorities; the Congress ranks who rallied to save his life.',
      what='Gandhi undertook a <b>“fast unto death” in 1932</b> against the separate electorate. The crisis produced the <b>Poona Pact</b>, replacing it with reserved seats within a joint electorate. He fasted on many occasions — against untouchability, and to quell communal violence.',
      crux='He believed <b>voluntary suffering could awaken the conscience</b> of opponents; critics, Ambedkar among them, saw the fast as <b>moral blackmail</b> that overrode Dalit self-determination.',
      conseq='The Poona Pact shaped Dalit political representation but left a lasting dispute over whether Gandhi helped or hindered their emancipation. He also campaigned against untouchability, calling Dalits <b>Harijan</b> (“children of God”).',
      matters='Gandhi’s fasts show both the power and the ambiguity of moral force — a weapon that could move nations yet raise hard questions about coercion.'),
]

# ==================================================================  PHASE 5 — FREEDOM, PARTITION AND MARTYRDOM
PHASE_END = [
    E('quitindia', '1942–1944', 'Quit India — “Do or Die”', ['BATTLE', 'TRAGEDY'],
      'With Britain at war and Indian patience exhausted, Gandhi launches the Quit India Movement in 1942, demanding an immediate end to British rule with the cry “Do or Die” — provoking the largest uprising since 1857 and a brutal crackdown that jails the entire Congress leadership, and costs Gandhi his wife Kasturba, who dies in detention.',
      svg_stack('The final demand for freedom', [
          {'n': 1, 'label': 'Quit India launched, Aug 1942', 'sub': '“Do or Die”: immediate independence demanded', 'color': '#b45309'},
          {'n': 2, 'label': 'Mass revolt and crackdown', 'sub': 'Congress leaders jailed en masse', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Loss in detention', 'sub': 'Kasturba dies in prison, 1944', 'color': '#78350f'},
      ], takeaway='His last great campaign made British rule untenable — at a heavy personal and national cost.', accent=AC),
      bg='During the Second World War, Britain sought Indian support but offered no firm promise of freedom. In August 1942 the Congress, at Gandhi’s urging, demanded that the British <b>“Quit India”</b> at once.',
      people='his wife <b>Kasturba</b>, who died in prison; the Congress leaders jailed with him; the millions who rose across India; the British authorities.',
      what='Gandhi launched the <b>Quit India Movement</b> on <b>8 August 1942</b> with the slogan <b>“Do or Die.”</b> The British responded by arresting the entire Congress leadership; a massive, partly violent uprising was crushed. Gandhi was held at the Aga Khan Palace, where <b>Kasturba died in 1944</b>.',
      crux='He staked everything on a <b>final, uncompromising demand</b> — convinced that Britain’s hold had become morally and practically untenable.',
      conseq='Though suppressed, Quit India showed that British rule could no longer be sustained; independence became a question of when, not if.',
      matters='Quit India was the last great push — a movement that broke the Raj’s legitimacy even as it broke Gandhi’s heart.'),

    E('partition', '1946–1947', 'Independence — and the agony of Partition', ['POLITICS', 'TRAGEDY', 'TRIUMPH'],
      'India wins independence in August 1947 — the crowning triumph of Gandhi’s life — but it comes as a bloody Partition into India and Pakistan that he had fought to prevent, unleashing horrific Hindu–Muslim violence; while others celebrate in Delhi, a grieving Gandhi walks the killing grounds of Bengal and fasts to stop the slaughter.',
      svg_row('Freedom bought with a broken land', [
          {'n': 1, 'label': 'Independence, August 1947', 'sub': 'British rule ends; the goal achieved', 'color': '#166534'},
          {'n': 2, 'label': 'Partition and carnage', 'sub': 'India and Pakistan split; mass communal killing', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Gandhi walks the riots', 'sub': 'fasts and pilgrimages to halt the violence', 'color': '#b45309'},
      ], edge_labels=['brings', 'so'], takeaway='His life’s aim was won and betrayed in the same moment — freedom arrived drenched in the communal blood he had dreaded.', accent=AC),
      bg='As independence neared, the <b>Muslim League</b> under <b>Jinnah</b> demanded a separate Pakistan. Gandhi opposed dividing India but could not prevent it; the 1947 Partition triggered vast migrations and communal massacres.',
      people='<b>Jawaharlal Nehru</b>, independent India’s first prime minister; <b>Muhammad Ali Jinnah</b>, founder of Pakistan; the millions uprooted and killed in the Partition violence.',
      what='On <b>15 August 1947</b> India became independent, partitioned into India and Pakistan. Amid appalling <b>Hindu–Muslim violence</b>, Gandhi refused to celebrate; he toured riot-torn <b>Bengal and Bihar</b> and undertook <b>fasts</b> that helped quell the killing in Calcutta and Delhi.',
      crux='He saw his greatest victory <b>marred by the very communal hatred</b> he had spent his life trying to overcome — a triumph shadowed by tragedy.',
      conseq='His pleas for tolerance and his fasts to protect Muslims enraged Hindu extremists, who came to regard him as a traitor to their cause.',
      matters='Gandhi’s final days show the tragic limits of even the greatest moral leadership — he freed a nation he could not keep whole.'),

    E('assassination', '1948', 'Assassination — the martyr of nonviolence', ['DEATH', 'TRAGEDY'],
      'On 30 January 1948, walking to his evening prayer meeting in Delhi, Gandhi is shot dead by Nathuram Godse, a Hindu nationalist who blamed him for the Partition and for appeasing Muslims — a martyrdom that stuns the world, and seals Gandhi’s stature as the apostle of nonviolence.',
      svg_stack('The apostle of nonviolence falls', [
          {'n': 1, 'label': 'Walking to prayer', 'sub': 'Birla House, Delhi, 30 January 1948', 'color': '#b45309'},
          {'n': 2, 'label': 'Shot by Nathuram Godse', 'sub': 'Hindu nationalist enraged by Partition', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A martyr of nonviolence', 'sub': 'mourned worldwide; the Mahatma enshrined', 'color': '#78350f'},
      ], takeaway='The prophet of nonviolence was killed by violence — a death that sealed his legend and indicted the hatreds he fought.', accent=AC),
      bg='Gandhi’s insistence on protecting India’s Muslims and honouring commitments to Pakistan infuriated Hindu extremists, who accused him of betraying Hindus during the Partition bloodshed.',
      people='the assassin <b>Nathuram Godse</b> and his co-conspirators; <b>Nehru</b>, who announced the death to a grieving nation; the millions who mourned worldwide.',
      what='On <b>30 January 1948</b>, as Gandhi walked to a prayer meeting at Birla House in Delhi, <b>Nathuram Godse</b> shot him three times at close range. Gandhi died almost instantly. Godse, unrepentant, was tried and executed in 1949.',
      crux='The man who preached <b>ahimsa was killed by a bullet</b> — a final, bitter irony that made him a martyr to his own creed.',
      conseq='Gandhi’s death shocked the world and shamed the communal hatreds tearing India apart; he became a global symbol of nonviolent resistance, inspiring figures from Martin Luther King Jr. to Nelson Mandela.',
      matters='Gandhi’s martyrdom fixed his legacy — the frail man in homespun who showed that nonviolence could free a nation, and whose ideas outlived his killers.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Mohandas Karamchand Gandhi — the <b>Mahatma</b>, or “great soul” — was the frail, homespun-clad lawyer who forged nonviolence into a political weapon and led India to independence. From a humiliating night on a South African railway platform he built <b>satyagraha</b>, the disciplined force of truth, and carried it home to turn the Indian National Congress into a mass movement of millions. He preached <b>ahimsa</b>, self-reliance and the spinning wheel; he marched to the sea for salt; he fasted, was jailed for years, and finally won a nation’s freedom — only to see it torn by Partition, and to fall to an assassin’s bullet. He remains the twentieth century’s great study in <b>nonviolence, moral courage, and the power and limits of conscience in politics.</b></p>
<div class="ov-quote">“An eye for an eye only ends up making the whole world blind.”<span>— attributed to Gandhi</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A shy merchant’s son studies law in London → is thrown off a South African train and forges satyagraha against anti-Indian laws → returns to India in 1915 and wins the peasants of Champaran and Kheda → leads Non-Cooperation, then the Salt March, then Quit India → fasts and is jailed for the cause of ahimsa and swaraj → wins independence in 1947 amid the agony of Partition → and is martyred by an assassin in 1948.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🕊️</div><h4>Satyagraha</h4><p>Turned nonviolence into a disciplined, winning method of struggle.</p></div>
  <div class="ov-card"><div class="i">🧂</div><h4>The Salt March</h4><p>A masterclass in dramatising injustice for the whole world.</p></div>
  <div class="ov-card"><div class="i">🧵</div><h4>Swaraj and khadi</h4><p>Fused political freedom with moral and economic self-reliance.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>Conscience and its limits</h4><p>Freed a nation he could not keep whole — a triumph shadowed by Partition.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Making</b><small> 1869–1893</small><p>Porbandar, London law, and a fateful voyage.</p></div>
  <div><b>2 · The South African Crucible</b><small> 1893–1915</small><p>The train, satyagraha, and a first victory.</p></div>
  <div><b>3 · The Indian Leader</b><small> 1915–1922</small><p>Champaran, Kheda, and Non-Cooperation.</p></div>
  <div><b>4 · Creed and Defiance</b><small> 1920s–1944</small><p>Ahimsa, the Salt March, fasts and jail.</p></div>
  <div><b>5 · Freedom and Martyrdom</b><small> 1942–1948</small><p>Quit India, Partition, assassination.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Kasturba Gandhi', 'role': 'his wife', 'color': '#166534',
     'bio': 'Married to Gandhi in childhood, she became his partner in struggle, courting arrest with him in South Africa and India, and died in British detention in 1944.',
     'rel': 'His lifelong companion and fellow satyagrahi.'},
    {'name': 'Jawaharlal Nehru', 'role': 'protégé and heir', 'color': '#b45309',
     'bio': 'Gandhi’s chosen political heir, leader of the Congress left, and independent India’s first prime minister, who announced Gandhi’s death to the nation.',
     'rel': 'The disciple to whom he passed the nation.'},
    {'name': 'Muhammad Ali Jinnah', 'role': 'rival', 'color': '#b91c1c',
     'bio': 'Leader of the Muslim League and founder of Pakistan, whose demand for a separate Muslim state Gandhi opposed but could not prevent.',
     'rel': 'His great adversary over the unity of India.'},
    {'name': 'B. R. Ambedkar', 'role': 'rival reformer', 'color': '#3730a3',
     'bio': 'The Dalit leader and jurist who clashed with Gandhi over separate electorates and the path to Dalit emancipation, forcing the 1932 Poona Pact.',
     'rel': 'His principled opponent on caste and representation.'},
    {'name': 'Nathuram Godse', 'role': 'his assassin', 'color': '#78350f',
     'bio': 'A Hindu nationalist who blamed Gandhi for Partition and for appeasing Muslims, and shot him dead in Delhi on 30 January 1948.',
     'rel': 'The extremist who ended his life.'},
]

KEY_EVENTS = [
    ('1869', 'Gandhi born in Porbandar', 'A merchant-caste family in Gujarat.'),
    ('1893', 'Thrown off the train', 'Pietermaritzburg; his political awakening.'),
    ('1906–14', 'Satyagraha in South Africa', 'Nonviolent resistance forged and won.'),
    ('1915', 'Returns to India', 'Founds Sabarmati; learns the nation.'),
    ('1917–18', 'Champaran and Kheda', 'First Indian satyagrahas succeed.'),
    ('1920–22', 'Non-Cooperation Movement', 'Called off after Chauri Chaura.'),
    ('1930', 'The Salt March to Dandi', 'Civil disobedience electrifies India.'),
    ('1942', 'Quit India — “Do or Die”', 'The final demand for freedom.'),
    ('1947', 'Independence and Partition', 'Triumph marred by communal bloodshed.'),
    ('1948', 'Assassinated by Godse', 'The martyr of nonviolence falls.'),
]

MASTER = [
    {'year': '1869', 'age': 'born', 'phase': 'The Making', 'title': 'Born in Porbandar', 'desc': 'A shy merchant’s son.'},
    {'year': '1893', 'age': 'age 23', 'phase': 'South African Crucible', 'title': 'The train at Pietermaritzburg', 'desc': 'His awakening.'},
    {'year': '1915', 'age': 'age 45', 'phase': 'The Indian Leader', 'title': 'Returns to India', 'desc': 'Builds a mass movement.'},
    {'year': '1930', 'age': 'age 60', 'phase': 'Creed and Defiance', 'title': 'The Salt March', 'desc': 'Civil disobedience.'},
    {'year': '1942', 'age': 'age 72', 'phase': 'Freedom and Martyrdom', 'title': 'Quit India', 'desc': 'The final push.'},
    {'year': '1948', 'age': 'age 78', 'phase': 'Freedom and Martyrdom', 'title': 'Assassinated', 'desc': 'The Mahatma martyred.'},
]

SOURCES = [
    ('Britannica — Mahatma Gandhi', 'https://www.britannica.com/biography/Mahatma-Gandhi'),
    ('Wikipedia — Mahatma Gandhi', 'https://en.wikipedia.org/wiki/Mahatma_Gandhi'),
    ('History.com — Mohandas Gandhi', 'https://www.history.com/articles/mahatma-gandhi'),
    ('Britannica — Salt March', 'https://www.britannica.com/event/Salt-March'),
    ('South African History Online — Mohandas Karamchand Gandhi', 'https://sahistory.org.za/people/mohandas-karamchand-gandhi'),
]

def build_meta():
    return {
        'pid': 'gm-gandhi.html', 'kind': 'man', 'emoji': '🕊️', 'accent': AC,
        'name': 'Mahatma Gandhi', 'years': '1869–1948', 'group': 'Independence & Nation-Building',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The lawyer who forged nonviolence into a political weapon and led India to freedom — apostle of satyagraha, ahimsa and swaraj, martyred at the moment of his nation’s birth.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'making', 'label': '1 · The Making', 'type': 'timeline',
             'intro': 'A shy merchant’s son is born in Porbandar, studies law in London, and — failing at the Indian bar — sails for South Africa on a one-year contract that will change his life.', 'events': PHASE_MAKING},
            {'id': 'sa', 'label': '2 · The South African Crucible', 'type': 'timeline',
             'intro': 'Thrown off a train for being Indian, Gandhi forges satyagraha — disciplined nonviolent resistance — and leads campaigns against South Africa’s anti-Indian laws to a first real victory.', 'events': PHASE_SA},
            {'id': 'rise', 'label': '3 · The Indian Leader', 'type': 'timeline',
             'intro': 'Returning to India in 1915, Gandhi learns the nation, wins the peasants of Champaran and Kheda, and transforms the Congress with the Non-Cooperation Movement.', 'events': PHASE_RISE},
            {'id': 'defiance', 'label': '4 · Creed and Defiance', 'type': 'timeline',
             'intro': 'His creed of ahimsa, swaraj and the spinning wheel powers the epic Salt March and civil disobedience, while fasts and years in jail turn self-suffering into a weapon.', 'events': PHASE_DEFIANCE},
            {'id': 'end', 'label': '5 · Freedom and Martyrdom', 'type': 'timeline',
             'intro': 'Quit India breaks the Raj; independence arrives in 1947 amid the agony of Partition; and the apostle of nonviolence is martyred by an assassin’s bullet in 1948.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; a widely quoted line is marked as attributed. Debated aspects — his early views in South Africa, the caste dispute with Ambedkar, and his personal experiments — are noted even-handedly.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
