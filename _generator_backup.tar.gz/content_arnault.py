# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Bernard Arnault (living figure; researched to 2026).
The engineer who became the ruthless architect of the world’s largest luxury empire."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#831843'  # deep couture wine

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE ENGINEER
PHASE_RISE = [
    E('origins', '1949–1971', 'A northern industrial son turned Polytechnique engineer', ['RISE', 'ORIGINS'],
      'Born in the textile city of Roubaix into a prosperous industrial family, the young Arnault is a disciplined, numbers-minded student who trains as an engineer at France’s elite École Polytechnique — a formation that gives him a lifelong faith in rigour, planning and the cold logic of the balance sheet, tools he will later turn on the intuitive world of fashion.',
      svg_row('An engineer’s mind is formed', [
          {'n': 1, 'label': 'Roubaix industrialist family, 1949', 'sub': 'raised amid the mills of northern France', 'color': '#831843'},
          {'n': 2, 'label': 'École Polytechnique engineer', 'sub': 'trained in mathematics and rigour, to 1971', 'color': '#3730a3'},
          {'n': 3, 'label': 'A balance-sheet mind', 'sub': 'discipline and cold analysis become his creed', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He came to luxury not as an aesthete but as an engineer — bringing the rigour of the balance sheet to the world of taste.', accent=AC),
      bg='<b>Bernard Arnault</b> was born in 1949 in <b>Roubaix</b>, a northern French textile town, into a family that ran a successful construction and engineering business.',
      people='his industrialist father Jean Arnault; the family firm <b>Ferret-Savinel</b>; the engineering elite of the École Polytechnique.',
      what='Arnault trained as an <b>engineer at the École Polytechnique</b>, France’s most prestigious grande école, graduating in 1971 with a mind shaped by <b>mathematics, planning and analytical rigour</b> rather than art or design.',
      crux='He approached everything as an <b>engineer and calculator</b> — a temperament utterly unlike the artisans and creatives he would one day command.',
      conseq='This analytical formation let him see luxury houses as under-managed assets ripe for disciplined value creation.',
      matters='The outsider’s eye can reframe an industry — an engineer saw in fashion the numbers others ignored.'),

    E('property', '1971–1981', 'Learning the deal in the family construction business', ['RISE', 'BUSINESS'],
      'Joining his father’s construction firm straight from Polytechnique, Arnault swiftly persuades him to abandon industrial building and pivot the whole company into profitable real estate — his first act of decisive restructuring, and his first taste of the acquisitive, unsentimental deal-making that will define him.',
      svg_stack('The first restructuring', [
          {'n': 1, 'label': 'Joins Ferret-Savinel, 1971', 'sub': 'enters the family construction business', 'color': '#831843'},
          {'n': 2, 'label': 'Pivots to real estate', 'sub': 'convinces his father to sell the industrial arm', 'color': '#a16207'},
          {'n': 3, 'label': 'Renames it Férinel, runs it', 'sub': 'takes the helm; learns to buy, cut and sell', 'color': '#166534'},
      ], takeaway='Before he ever touched fashion, he had already reinvented a company by cold analysis — buying, cutting and repurposing to build value.', accent=AC),
      bg='Arnault entered his family’s construction company, <b>Ferret-Savinel</b>, where he quickly showed a taste for bold strategic change.',
      people='his father Jean, whom he persuaded; the family firm, soon renamed <b>Férinel</b>; the French property market of the 1970s.',
      what='He convinced his father to <b>sell the industrial construction division</b> and redirect the firm into <b>real estate development</b>, then took over as head — reshaping the business around property and profit.',
      crux='He showed early the instinct to <b>reinvent a company by decisive surgery</b> — shedding the old core to chase a more lucrative one.',
      conseq='Running Férinel gave him capital, confidence and a template of restructuring he would apply on a far grander stage.',
      matters='Great fortunes often begin with a willingness to remake even the family business without sentiment.'),

    E('america', '1981–1983', 'Exile in America and the lesson of the brand', ['RISE', 'INSIGHT'],
      'When François Mitterrand’s socialist government takes power in 1981, Arnault decamps to the United States to develop real estate in Florida — and there, famously told by a New York taxi driver that he knew nothing of France but knew Christian Dior, he grasps the immense global power of a French luxury name, and returns determined to build an empire on it.',
      svg_row('The taxi-driver epiphany', [
          {'n': 1, 'label': 'Leaves for the US, 1981', 'sub': 'develops Florida property under a socialist France', 'color': '#3730a3'},
          {'n': 2, 'label': 'A cabbie knows only “Dior”', 'sub': 'the taxi-driver knew France by its luxury name', 'color': '#a16207'},
          {'n': 3, 'label': 'Sees the power of the brand', 'sub': 'a heritage name is a global asset', 'color': '#166534'},
      ], edge_labels=['and', 'so'], takeaway='In America he glimpsed the prize — a great French name could conquer the world where French politics could not.', accent=AC),
      bg='After the socialist victory of 1981 unsettled French business, Arnault moved to the <b>United States</b> to pursue real estate development.',
      people='the Mitterrand government he fled; American developers; the New York taxi driver of Arnault’s famous anecdote.',
      what='Developing property in <b>Florida</b>, Arnault reportedly learned from a cab driver who knew nothing of France’s president but knew <b>Christian Dior</b> — crystallising his conviction that a <b>French luxury brand is a globally powerful asset</b>.',
      crux='He grasped that <b>heritage names carry worldwide recognition and pricing power</b> that few other assets can match.',
      conseq='He returned to France hunting for a great brand to acquire — and found one in a bankrupt textile empire.',
      matters='A single insight can redirect a life — Arnault bet everything on the enduring global magnetism of the brand.'),
]

# ==================================================================  PHASE 2 — THE DIOR GAMBIT
PHASE_POWER = [
    E('boussac', '1984', 'Seizing Boussac to capture Christian Dior', ['BUSINESS', 'TURNING POINT'],
      'Arnault spots his opening in Boussac Saint-Frères, a bankrupt textile conglomerate that happens to own the crown jewel of French couture, Christian Dior — and with the banker Antoine Bernheim and Lazard behind him, he puts up a fraction of his own money to seize control of the whole group, gambling that one legendary brand is worth a mountain of failing factories.',
      svg_row('Buying an empire for its jewel', [
          {'n': 1, 'label': 'Boussac in bankruptcy', 'sub': 'a failing textile group nobody wanted', 'color': '#b91c1c'},
          {'n': 2, 'label': 'It owns Christian Dior', 'sub': 'the crown jewel of French couture', 'color': '#a16207'},
          {'n': 3, 'label': 'Arnault seizes control, 1984', 'sub': 'backed by Bernheim and Lazard', 'color': '#831843'},
      ], edge_labels=['but', 'so'], takeaway='He bought a mountain of failing factories to get one priceless name — the whole gamble was for Dior alone.', accent=AC),
      bg='In 1984 the state was seeking a buyer for <b>Boussac Saint-Frères</b>, a bankrupt textile empire that owned <b>Christian Dior</b> and the Le Bon Marché department store.',
      people='the banker <b>Antoine Bernheim</b>, his mentor; the Lazard bank; the French government eager to offload the failing group.',
      what='Arnault led a group that <b>acquired Boussac in 1984</b>, putting up only a fraction of the roughly $80 million price himself, in order to <b>capture Christian Dior</b> — the brand he judged the real prize.',
      crux='He saw that <b>one legendary brand outweighed a whole bankrupt conglomerate</b> — and structured a deal to seize it cheaply.',
      conseq='Control of Dior gave him a foothold in luxury and a platform from which to conquer the entire industry.',
      matters='Vision means valuing the hidden jewel over the visible wreckage — Arnault paid for factories to own a name.'),

    E('wolf', '1984–1987', 'The wolf in cashmere — ruthless restructuring', ['BUSINESS', 'TRAGEDY'],
      'Having promised to preserve jobs, Arnault instead guts Boussac — selling off nearly everything but Dior and the Bon Marché and cutting some 9,000 jobs — a brutal restructuring that returns the group to profit within years, earns him a fortune and the enduring nickname "the wolf in cashmere," and marks him forever as brilliant and cold in equal measure.',
      svg_compare('Two verdicts on the same man',
          {'head': 'The admirers see genius', 'color': '#166534', 'items': [
              'Rescued a bankrupt group from collapse',
              'Restored Dior and Bon Marché to profit',
              'Proved luxury could be run with rigour',
              'Turned a fraction of capital into a fortune']},
          {'head': 'The critics see the wolf', 'color': '#b91c1c', 'items': [
              'Cut roughly 9,000 jobs after pledging otherwise',
              'Sold off historic mills and assets',
              'Earned the name “the wolf in cashmere”',
              'Left whole towns without their factories']},
      verdict='Brilliant and ruthless at once — the restructuring that made him also defined his reputation.',
      takeaway='He saved the group and gutted it in the same stroke — genius and coldness fused into a single method.', accent=AC),
      bg='Boussac was hemorrhaging money. To save it, Arnault imposed drastic cuts, despite assurances given during the takeover about preserving employment.',
      people='the <b>9,000 workers</b> laid off; the mill towns of northern France; the financial press that coined his nickname.',
      what='Arnault <b>sold off most of Boussac’s assets</b>, keeping chiefly <b>Christian Dior and Le Bon Marché</b>, and <b>cut roughly 9,000 jobs</b> — returning the group to profit but earning the label <b>“the wolf in cashmere.”</b>',
      crux='He was willing to be <b>hated to be right</b> — accepting a ruthless reputation as the price of a rescued, profitable business.',
      conseq='The restructuring produced huge gains that funded his next and greatest move — the conquest of LVMH.',
      matters='The line between saviour and predator is thin — the same cuts that rescue a company can scar a community.'),

    E('method', '1985–1987', 'The Arnault method — heritage brand, star designer', ['BUSINESS', 'REFORM'],
      'At Dior, Arnault refines the formula that will build his empire — take a dormant heritage house, invest heavily in its craft and image, and install a bold star designer to make it desirable again — proving that a great old name, properly managed and creatively reignited, can command premium prices and vast global demand.',
      svg_stack('The formula that would scale', [
          {'n': 1, 'label': 'Take a sleeping heritage house', 'sub': 'a great name dulled by neglect', 'color': '#a16207'},
          {'n': 2, 'label': 'Invest in craft and image', 'sub': 'quality, stores and marketing at scale', 'color': '#831843'},
          {'n': 3, 'label': 'Install a star designer', 'sub': 'creative daring to make it desired again', 'color': '#166534'},
      ], takeaway='He built a repeatable machine — heritage plus capital plus a star creator — and would run it dozens of times over.', accent=AC),
      bg='With Dior under his control, Arnault set about proving that disciplined ownership could reawaken a storied but under-exploited brand.',
      people='the designers he would elevate; Dior’s ateliers and craftspeople; the global luxury consumer he aimed to seduce.',
      what='Arnault developed his signature <b>method</b>: pair a <b>heritage house</b> with <b>heavy investment</b> and a <b>bold creative director</b>, marrying commercial rigour to artistic risk to <b>reignite desire and pricing power</b>.',
      crux='He fused <b>the manager and the artist</b> — protecting creative daring while ruthlessly controlling the numbers behind it.',
      conseq='This template — repeated across dozens of maisons — became the engine of the largest luxury group on earth.',
      matters='Enduring brands are rebuilt by balancing art and discipline — creativity to desire, control to profit.'),
]

# ==================================================================  PHASE 3 — CONQUERING LVMH
PHASE_ORDER = [
    E('lvmh', '1987', 'LVMH is born — and its founders soon feud', ['BUSINESS', 'TURNING POINT'],
      'In 1987 Louis Vuitton and Moët Hennessy merge to form LVMH, the largest luxury group in the world — but the marriage of the two proud houses is unhappy, and the feud between their chiefs, Henry Racamier of Vuitton and Alain Chevalier of Moët Hennessy, opens the very crack through which Arnault will drive.',
      svg_row('A shaky merger invites a raider', [
          {'n': 1, 'label': 'Vuitton + Moët Hennessy, 1987', 'sub': 'merge into the giant LVMH', 'color': '#a16207'},
          {'n': 2, 'label': 'The founders feud', 'sub': 'Racamier and Chevalier clash for control', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A crack opens', 'sub': 'a divided house invites an outsider', 'color': '#831843'},
      ], edge_labels=['but', 'so'], takeaway='The very merger meant to build a fortress left a divided leadership — and a door for a patient predator.', accent=AC),
      bg='In 1987 <b>Louis Vuitton</b> and <b>Moët Hennessy</b> merged to create <b>LVMH</b>, uniting champagne, cognac and leather goods into the world’s largest luxury group.',
      people='<b>Henry Racamier</b>, head of Louis Vuitton; <b>Alain Chevalier</b>, head of Moët Hennessy; the two camps of a divided board.',
      what='The <b>1987 merger</b> created LVMH but united two proud managements uneasily; a bitter <b>power struggle between Racamier and Chevalier</b> soon left the group vulnerable and its leadership split.',
      crux='A house divided against itself is weak — the founders’ feud created the <b>opening</b> a determined outsider could exploit.',
      conseq='Racamier, seeking an ally against Chevalier, invited Arnault in — a fateful miscalculation.',
      matters='Internal division is the classic invitation to a takeover — disunity at the top is a strategic vulnerability.'),

    E('trojan', '1988', 'Invited in as an ally, arming as a raider', ['BUSINESS', 'POLITICS'],
      'Racamier invites Arnault to buy into LVMH as a friendly shareholder to help him beat his rival — but Arnault, allied with the drinks giant Guinness, quietly pours in his Dior fortune to accumulate shares far beyond what his host imagined, turning a defensive alliance into the beachhead for a hostile conquest.',
      svg_stack('The ally who came to conquer', [
          {'n': 1, 'label': 'Racamier invites him in', 'sub': 'wants a friendly ally against Chevalier', 'color': '#3730a3'},
          {'n': 2, 'label': 'Allies with Guinness', 'sub': 'pools capital to buy LVMH stock', 'color': '#a16207'},
          {'n': 3, 'label': 'Buys far beyond expectation', 'sub': 'pours the Dior fortune into a growing stake', 'color': '#831843'},
      ], takeaway='He accepted an invitation to help — and used it to arm himself against the very man who let him in.', accent=AC),
      bg='Seeking leverage against Chevalier, Racamier welcomed Arnault as a supposedly friendly investor in LVMH.',
      people='<b>Henry Racamier</b>, who opened the door; the drinks group <b>Guinness</b>, Arnault’s ally; the bankers financing the raid.',
      what='Arnault entered as an <b>invited shareholder</b>, then, partnering with <b>Guinness</b>, deployed his Dior wealth to <b>accumulate LVMH stock far beyond</b> what Racamier had anticipated — building a springboard for control.',
      crux='He turned <b>a defensive alliance into an offensive weapon</b> — accepting a role as helper while preparing to take the whole.',
      conseq='By early 1989 his stake was large enough to seize the chairmanship and begin ousting the founders.',
      matters='The most dangerous rival is the one invited through the front door — trust misjudged is a fatal opening.'),

    E('conquest', '1989–1990', 'Seizing the empire and ousting its founders', ['BUSINESS', 'TRIUMPH', 'TURNING POINT'],
      'Through a bruising two-year battle fought in boardrooms and courts, Arnault builds a controlling stake of some 43.5 percent, becomes chairman of LVMH in January 1989, and by 1990 has driven both founders from the company they built — a conquest so audacious it makes him the master of the luxury world and confirms his reputation as its most ruthless operator.',
      svg_row('The takeover completed', [
          {'n': 1, 'label': 'Builds ~43.5% control', 'sub': 'a commanding stake through two years of battle', 'color': '#831843'},
          {'n': 2, 'label': 'Chairman of LVMH, Jan 1989', 'sub': 'seizes the top of the empire', 'color': '#166534'},
          {'n': 3, 'label': 'Founders driven out by 1990', 'sub': 'Racamier and Chevalier forced from LVMH', 'color': '#b91c1c'},
      ], edge_labels=['then', 'and'], takeaway='In two ferocious years he took the whole group and cast out the men who built it — luxury had a new sole master.', accent=AC),
      bg='The struggle for LVMH became one of France’s most notorious corporate battles, waged through share raids, alliances and lawsuits.',
      people='<b>Henry Racamier</b> and <b>Alain Chevalier</b>, the ousted founders; the courts and bankers; the shareholders who backed Arnault.',
      what='Arnault assembled a <b>controlling stake of about 43.5%</b>, became <b>chairman of LVMH in January 1989</b>, and by <b>1990 had forced both founders out</b> — winning outright control after a punishing legal and financial war.',
      crux='He pursued <b>total control, not partnership</b> — prepared to break allies and endure years of litigation to own the whole.',
      conseq='As undisputed master of LVMH, he now had the platform to assemble the largest luxury empire in history.',
      matters='Decisive conquest rewards the player who wants it most — Arnault would share the summit with no one.'),
]

# ==================================================================  PHASE 4 — THE EMPIRE
PHASE_REPRESSION = [
    E('maisons', '1990s–2011', 'Assembling the maisons — a luxury conglomerate', ['BUSINESS', 'REFORM'],
      'From his LVMH base Arnault goes on a decades-long acquisition spree, absorbing Givenchy, Kenzo, Loewe, Céline, Guerlain and dozens more, then landing Fendi and, in 2011, Bulgari — building a diversified portfolio of scores of storied houses spanning fashion, jewellery, watches, wines and spirits under one disciplined roof.',
      svg_stack('Building the house of houses', [
          {'n': 1, 'label': 'Absorbs house after house', 'sub': 'Givenchy, Kenzo, Loewe, Céline, Guerlain', 'color': '#831843'},
          {'n': 2, 'label': 'Adds Fendi and Bulgari', 'sub': 'Fendi (2003), Bulgari jewellery (2011)', 'color': '#a16207'},
          {'n': 3, 'label': 'Scores of maisons, one group', 'sub': 'fashion, jewels, watches, wines, spirits', 'color': '#166534'},
      ], takeaway='Brand by brand he built a conglomerate of dozens of houses — diversified, disciplined, and unmatched in scale.', accent=AC),
      bg='With LVMH as his engine, Arnault pursued a relentless strategy of acquiring and elevating heritage luxury houses across every category.',
      people='the founding families he bought out; the maisons of Paris, Rome and beyond; his growing bench of managers and designers.',
      what='Arnault acquired and revived <b>dozens of houses</b> — including <b>Givenchy, Kenzo, Loewe, Céline and Guerlain</b>, then <b>Fendi (2003)</b> and <b>Bulgari (2011)</b> — assembling a diversified empire across fashion, jewellery, wines and spirits.',
      crux='He built <b>strength through breadth</b> — a portfolio of iconic names whose scale gave pricing power, resilience and reach.',
      conseq='LVMH became the dominant force in global luxury, big enough to shape the industry and outbid nearly any rival.',
      matters='Diversified scale is its own moat — a house of many houses withstands what would sink a single brand.'),

    E('designers', '1996–2010s', 'Star designers and the retail machine', ['BUSINESS', 'CULTURE'],
      'Arnault turns his maisons into engines of desire by pairing them with audacious creative talent — John Galliano at Dior, Marc Jacobs at Louis Vuitton, Alexander McQueen at Givenchy — while building a retail juggernaut through Sephora and DFS, mastering both the art that creates demand and the distribution that captures it.',
      svg_row('Art to create demand, retail to capture it', [
          {'n': 1, 'label': 'Installs star designers', 'sub': 'Galliano, Marc Jacobs, McQueen', 'color': '#831843'},
          {'n': 2, 'label': 'Builds a retail machine', 'sub': 'Sephora and DFS control distribution', 'color': '#a16207'},
          {'n': 3, 'label': 'Owns desire end to end', 'sub': 'from runway spectacle to store shelf', 'color': '#166534'},
      ], edge_labels=['plus', 'yields'], takeaway='He mastered both halves of luxury — the creativity that makes people want, and the retail that makes them buy.', accent=AC),
      bg='Arnault understood that luxury profits flow from both creative desire and controlled distribution, and pursued both aggressively.',
      people='designers <b>John Galliano</b>, <b>Marc Jacobs</b> and <b>Alexander McQueen</b>; the Sephora and DFS retail networks; the global luxury shopper.',
      what='Arnault appointed <b>daring star designers</b> to modernise his houses — Galliano at Dior, Jacobs at Vuitton, McQueen at Givenchy — while acquiring <b>Sephora and DFS</b> to command <b>retail and distribution</b>.',
      crux='He controlled the <b>whole chain of desire</b> — the spectacle that creates demand and the stores that convert it to sales.',
      conseq='This dual mastery of creativity and retail entrenched LVMH’s dominance and its extraordinary margins.',
      matters='In luxury, owning both the dream and the counter is decisive — desire and distribution together are the true moat.'),

    E('tiffany', '2021', 'The Tiffany conquest — the crown of jewellery', ['BUSINESS', 'TRIUMPH'],
      'In 2021 Arnault completes his largest acquisition ever, buying the American jeweller Tiffany & Co. for some $15.8 billion after a hard-fought, pandemic-era renegotiation — a deal that crowns LVMH’s push into hard luxury and demonstrates that, even at seventy-two, his appetite for the audacious acquisition is undimmed.',
      svg_row('The biggest deal of all', [
          {'n': 1, 'label': 'Targets Tiffany & Co.', 'sub': 'the iconic American jeweller', 'color': '#a16207'},
          {'n': 2, 'label': 'Renegotiates through Covid', 'sub': 'a hard fight over price amid the pandemic', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Buys it for ~$15.8bn, 2021', 'sub': 'LVMH’s largest acquisition ever', 'color': '#831843'},
      ], edge_labels=['through', 'to'], takeaway='His biggest deal came in his eighth decade — proof the appetite that took LVMH had never dulled.', accent=AC),
      bg='By 2019 Arnault sought to strengthen LVMH in jewellery — “hard luxury” — and set his sights on the American icon Tiffany & Co.',
      people='the board of <b>Tiffany & Co.</b>; LVMH’s dealmakers; the lawyers of the pandemic-era renegotiation.',
      what='After a <b>bruising renegotiation during the Covid-19 pandemic</b>, LVMH bought <b>Tiffany & Co. in 2021 for about $15.8 billion</b> — its <b>largest acquisition ever</b> and the crown of its jewellery arm.',
      crux='He remained the <b>relentless acquirer</b> even at the top — willing to fight hard over terms to land a defining prize.',
      conseq='Tiffany gave LVMH commanding scale in jewellery and a flagship American brand, reinforcing its global lead.',
      matters='The instinct that built the empire never rested — the greatest builders keep making the audacious bet.'),
]

# ==================================================================  PHASE 5 — LEGACY & SUCCESSION
PHASE_END = [
    E('richest', '2021–2024', 'At times the richest person in the world', ['BUSINESS', 'TRIUMPH'],
      'The soaring value of LVMH lifts Arnault, at various points in the early 2020s, to the title of the richest person on earth — his fortune surpassing those of the American tech titans and cresting around two hundred billion dollars — a summit that measures the scale of the empire he built from a single bankrupt textile group.',
      svg_row('The summit of global wealth', [
          {'n': 1, 'label': 'LVMH’s value soars', 'sub': 'the luxury giant’s shares climb for years', 'color': '#a16207'},
          {'n': 2, 'label': 'World’s richest person', 'sub': 'tops the tech titans in the early 2020s', 'color': '#831843'},
          {'n': 3, 'label': 'Fortune near $200bn', 'sub': 'a peak measuring the empire’s scale', 'color': '#166534'},
      ], edge_labels=['makes', 'of'], takeaway='The engineer from Roubaix reached the very top of global wealth — built entirely on the power of the brand.', accent=AC),
      bg='As LVMH’s market value climbed through the early 2020s, so did Arnault’s personal fortune, tied largely to his controlling family stake.',
      people='rival billionaires <b>Elon Musk</b> and <b>Jeff Bezos</b>; the markets valuing LVMH; the Arnault family holding companies.',
      what='Driven by LVMH’s surging shares, Arnault became at times the <b>richest person in the world</b> in the early 2020s, with a fortune cresting around <b>$200 billion</b> and rivalling the great American tech magnates.',
      crux='His wealth rested not on technology but on <b>brands, heritage and desire</b> — a different foundation for a colossal fortune.',
      conseq='His dominance raised inevitable questions of succession and the future of the family’s control of LVMH.',
      matters='Enduring value can be built on culture and craft — luxury proved a match for technology at the summit of wealth.'),

    E('foundation', '2014', 'The patron — the Fondation Louis Vuitton', ['CULTURE', 'LEGACY'],
      'Seeking a legacy beyond commerce, Arnault opens the Fondation Louis Vuitton in 2014, a spectacular Frank Gehry building in Paris that houses his contemporary art collection and mounts blockbuster exhibitions — casting the ruthless dealmaker also as a great modern patron of the arts in the tradition of the Medici.',
      svg_stack('The dealmaker as art patron', [
          {'n': 1, 'label': 'Commissions Frank Gehry', 'sub': 'a soaring glass building in Paris', 'color': '#831843'},
          {'n': 2, 'label': 'Opens the Fondation, 2014', 'sub': 'houses his contemporary art collection', 'color': '#a16207'},
          {'n': 3, 'label': 'A modern Medici', 'sub': 'blockbuster shows and cultural prestige', 'color': '#166534'},
      ], takeaway='He sought a legacy in stone and art — the hard-edged conqueror recast as patron in the Medici mould.', accent=AC),
      bg='Alongside his commercial empire, Arnault cultivated a role as a collector and patron of contemporary art.',
      people='the architect <b>Frank Gehry</b>; the artists in his collection; the Parisian public and the wider art world.',
      what='In 2014 Arnault opened the <b>Fondation Louis Vuitton</b> — a striking <b>Frank Gehry building</b> in Paris housing his <b>contemporary art collection</b> and staging major exhibitions — establishing him as a leading modern patron of the arts.',
      crux='He tied his name to <b>culture as well as commerce</b> — building prestige and legacy beyond the balance sheet.',
      conseq='The foundation burnished the Arnault and LVMH image, linking the empire to art, beauty and permanence.',
      matters='The powerful have always sought legacy through patronage — Arnault followed the Medici path from wealth to culture.'),

    E('succession', '2022–2026', 'The dynasty question — five children in line', ['BUSINESS', 'LEGACY'],
      'As he passes seventy and then seventy-five, Arnault knits his five children into the leadership of LVMH — Delphine at Dior, Antoine, Alexandre, Frédéric and Jean across the group and its holding companies — while raising the age limit for chairman and installing them on the board, engineering a dynastic succession to keep the empire in family hands for generations.',
      svg_row('Engineering a dynasty', [
          {'n': 1, 'label': 'Five children placed across LVMH', 'sub': 'Delphine, Antoine, Alexandre, Frédéric, Jean', 'color': '#831843'},
          {'n': 2, 'label': 'Board seats and holdings', 'sub': 'family control locked through the structure', 'color': '#a16207'},
          {'n': 3, 'label': 'A succession built to last', 'sub': 'the empire kept in family hands', 'color': '#166534'},
      ], edge_labels=['plus', 'yields'], takeaway='The final act is dynastic — Arnault engineering his empire, like his deals, to endure in his family’s grip.', accent=AC),
      bg='Now in his seventies but still chairman, Arnault turned to the greatest challenge of any founder — succession without loss of control.',
      people='his children <b>Delphine</b> (Dior), <b>Antoine</b>, <b>Alexandre</b>, <b>Frédéric</b> and <b>Jean</b> Arnault; the LVMH board and family holdings.',
      what='Arnault placed his <b>five children</b> in senior roles across LVMH and its brands, added them to the <b>board</b>, and reworked governance (including raising the chairman age limit) to <b>engineer a dynastic succession</b> that keeps control in the family.',
      crux='He treats <b>succession as his final deal</b> — structuring ownership and leadership so the empire outlasts him under family rule.',
      conseq='The arrangement positions the Arnault family to dominate LVMH for a generation, though the ultimate heir remains unnamed.',
      matters='The hardest task for any builder is continuity — Arnault engineered his legacy as carefully as his conquests.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Bernard Arnault is the engineer who built the world’s largest luxury empire and became, at times, the richest person on earth. Trained at the École Polytechnique and schooled in his family’s construction business, he grasped early the global power of a great French brand — and seized it, capturing Christian Dior through the bankrupt Boussac group in 1984 and gutting it so ruthlessly he was dubbed “the wolf in cashmere.” From that base he conquered LVMH in a bruising takeover, ousted its founders, and spent three decades assembling scores of storied houses — Dior, Louis Vuitton, Tiffany, Sephora and dozens more. He is the ultimate study in <b>brand power, disciplined acquisition, and the fusion of cold rigour with creative daring.</b></p>
<div class="ov-quote">“The essential thing is to have great products — and to be feared a little.”<span>— the spirit of Arnault’s method</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">An engineer’s son trains at Polytechnique and reinvents the family firm → in America he grasps the global power of the brand → seizes Boussac to capture Dior and guts it as “the wolf in cashmere” → conquers LVMH and casts out its founders → assembles dozens of maisons with star designers and a retail machine → lands Tiffany and becomes the world’s richest person → and engineers a dynastic succession among his five children.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">👜</div><h4>The power of the brand</h4><p>Proved a heritage name is among the most valuable assets on earth.</p></div>
  <div class="ov-card"><div class="i">🐺</div><h4>The disciplined acquirer</h4><p>Bought, cut and elevated dozens of houses into one empire.</p></div>
  <div class="ov-card"><div class="i">🎨</div><h4>Art meets the balance sheet</h4><p>Fused creative daring with the rigour of an engineer.</p></div>
  <div class="ov-card"><div class="i">🏛️</div><h4>Empire and dynasty</h4><p>Built the largest luxury group and a family succession to hold it.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Engineer</b><small> 1949–1983</small><p>Polytechnique, property, and the brand epiphany.</p></div>
  <div><b>2 · The Dior Gambit</b><small> 1984–1987</small><p>Seizing Boussac; the wolf in cashmere.</p></div>
  <div><b>3 · Conquering LVMH</b><small> 1987–1990</small><p>The takeover and the ousted founders.</p></div>
  <div><b>4 · The Empire</b><small> 1990–2021</small><p>Dozens of maisons; Tiffany; the summit.</p></div>
  <div><b>5 · Legacy & Succession</b><small> 2014–2026</small><p>Richest man, patron, and the dynasty.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Antoine Bernheim', 'role': 'mentor and banker', 'color': '#a16207',
     'bio': 'The Lazard banker who backed the young Arnault’s seizure of Boussac and Dior, opening the door to the luxury world.',
     'rel': 'The financier who made his first great conquest possible.'},
    {'name': 'Henry Racamier', 'role': 'ousted rival', 'color': '#b91c1c',
     'bio': 'The head of Louis Vuitton who invited Arnault into LVMH as an ally against Chevalier — and was driven from the company he had built.',
     'rel': 'The founder who let him in and lost everything to him.'},
    {'name': 'Alain Chevalier', 'role': 'ousted founder', 'color': '#78350f',
     'bio': 'The chief of Moët Hennessy and first chairman of LVMH, forced out in the takeover battle that gave Arnault control.',
     'rel': 'The other founder swept aside in the conquest of LVMH.'},
    {'name': 'John Galliano', 'role': 'star designer', 'color': '#3730a3',
     'bio': 'The flamboyant British designer Arnault installed at Christian Dior, embodying his strategy of pairing heritage houses with bold creative talent.',
     'rel': 'The creative daring behind the revival of Dior.'},
    {'name': 'Delphine Arnault', 'role': 'daughter and heir', 'color': '#166534',
     'bio': 'His eldest child, made CEO of Christian Dior, and a leading figure in the succession that aims to keep LVMH in family hands.',
     'rel': 'The child placed at the head of the original crown jewel.'},
]

KEY_EVENTS = [
    ('1949', 'Arnault born in Roubaix', 'Into a northern industrial family.'),
    ('1971', 'Graduates Polytechnique', 'Enters the family construction firm.'),
    ('1984', 'Seizes Boussac and Dior', 'Captures the crown jewel of couture.'),
    ('1984–87', 'The wolf in cashmere', 'Ruthless restructuring; ~9,000 jobs cut.'),
    ('1987', 'LVMH is created', 'Vuitton and Moët Hennessy merge.'),
    ('1989', 'Chairman of LVMH', 'Seizes control; founders ousted by 1990.'),
    ('2011', 'Bulgari acquired', 'Empire expands into hard luxury.'),
    ('2021', 'Tiffany bought for ~$15.8bn', 'LVMH’s largest acquisition ever.'),
    ('2022–24', 'World’s richest person', 'Fortune crests around $200 billion.'),
]

MASTER = [
    {'year': '1949', 'age': 'born', 'phase': 'The Engineer', 'title': 'Born in Roubaix', 'desc': 'An industrial family; a future engineer.'},
    {'year': '1984', 'age': 'age 35', 'phase': 'The Dior Gambit', 'title': 'Seizes Dior', 'desc': 'Captures it via bankrupt Boussac.'},
    {'year': '1989', 'age': 'age 40', 'phase': 'Conquering LVMH', 'title': 'Chairman of LVMH', 'desc': 'Takes control; ousts the founders.'},
    {'year': '2011', 'age': 'age 62', 'phase': 'The Empire', 'title': 'Bulgari and beyond', 'desc': 'Dozens of maisons under one roof.'},
    {'year': '2021', 'age': 'age 72', 'phase': 'The Empire', 'title': 'Buys Tiffany', 'desc': 'Largest acquisition ever, ~$15.8bn.'},
    {'year': '2023', 'age': 'age 74', 'phase': 'Legacy & Succession', 'title': 'The dynasty forms', 'desc': 'Five children placed across LVMH.'},
]

SOURCES = [
    ('Britannica — Bernard Arnault', 'https://www.britannica.com/money/Bernard-Arnault'),
    ('Wikipedia — Bernard Arnault', 'https://en.wikipedia.org/wiki/Bernard_Arnault'),
    ('LVMH — Bernard Arnault, Chairman and CEO', 'https://www.lvmh.com/en/our-group/governance/bernard-arnault'),
    ('Forbes — Behind The Billions: Bernard Arnault', 'https://www.forbes.com/sites/forbeswealthteam/article/behind-the-billions-bernard-arnault/'),
    ('Wikipedia — LVMH', 'https://en.wikipedia.org/wiki/LVMH'),
]

def build_meta():
    return {
        'pid': 'gm-arnault.html', 'kind': 'man', 'emoji': '👜', 'accent': AC,
        'name': 'Bernard Arnault', 'years': 'b. 1949', 'group': 'Business & Industry',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The engineer who built the world’s largest luxury empire — “the wolf in cashmere” who captured Dior, conquered LVMH, and became at times the richest person on earth.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Engineer', 'type': 'timeline',
             'intro': 'A Polytechnique-trained engineer reinvents his family’s construction firm, then in America grasps the global power of the French luxury brand.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · The Dior Gambit', 'type': 'timeline',
             'intro': 'He seizes the bankrupt Boussac group to capture Christian Dior, guts it so ruthlessly he is dubbed “the wolf in cashmere,” and forges the method that will build his empire.', 'events': PHASE_POWER},
            {'id': 'order', 'label': '3 · Conquering LVMH', 'type': 'timeline',
             'intro': 'Invited into a divided LVMH as an ally, he arms himself instead as a raider — seizing control, becoming chairman, and driving out the founders.', 'events': PHASE_ORDER},
            {'id': 'repression', 'label': '4 · The Empire', 'type': 'timeline',
             'intro': 'From his LVMH base he assembles scores of storied houses, pairs them with star designers and a retail machine, and lands Tiffany in the largest luxury deal ever.', 'events': PHASE_REPRESSION},
            {'id': 'end', 'label': '5 · Legacy & Succession', 'type': 'timeline',
             'intro': 'The soaring empire makes him at times the richest person alive; he builds the Fondation Louis Vuitton as patron, and engineers a dynastic succession among his five children.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies, encyclopaedic sources and reputable business press on a living figure; figures and dates reflect widely reported accounts and are presented as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
