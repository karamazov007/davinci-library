# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Rodrigo Borgia — Pope Alexander VI.
The Valencian churchman whose worldly genius and dynastic ambition made the Borgia name a byword for Renaissance power and corruption."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#9f1239'  # Borgia crimson

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE RISE
PHASE_RISE = [
    E('origins', '1431–1455', 'A Valencian outsider in the Roman Church', ['RISE', 'ORIGINS'],
      'Rodrigo de Borja is born in 1431 at Xàtiva in the Kingdom of Valencia, a Spaniard in an Italian church — clever, charming and ambitious, he studies law at Bologna and waits for the family fortune to turn.',
      svg_row('A Spaniard bound for Rome', [
          {'n': 1, 'label': 'Born at Xàtiva, 1431', 'sub': 'lesser nobility of Valencia, Crown of Aragon', 'color': '#9f1239'},
          {'n': 2, 'label': 'Studies law at Bologna', 'sub': 'a sharp, worldly education in canon law', 'color': '#b45309'},
          {'n': 3, 'label': 'A Spaniard among Italians', 'sub': 'an outsider in the Roman Curia', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He began as a provincial Spaniard in an Italian church — an outsider who would climb to its very summit.', accent=AC),
      bg='<b>Rodrigo de Borja</b> was born in 1431 at Xàtiva near Valencia, into the lesser nobility of the Crown of Aragon — a Spaniard in a church dominated by Italians.',
      people='the Borja (Borgia) family of Valencia; his uncle <b>Alonso de Borja</b>, a rising Spanish cardinal; the Italian nobility of the Curia.',
      what='Rodrigo was a <b>clever, charming and ambitious young Spaniard</b> who studied <b>canon law at Bologna</b>, positioning himself for a career in the Church while his uncle rose through its ranks.',
      crux='He entered a Roman world that saw Spaniards as <b>outsiders</b> — a barrier he would overcome through his uncle, his abilities and sheer determination.',
      conseq='When his uncle reached the papacy, Rodrigo was ready to be lifted to the heights of the Church.',
      matters='Talent and opportunity together open doors — an outsider with ability, backed by family, could rise to the top of the Renaissance Church.'),

    E('cardinal', '1456–1458', 'Nepotism opens the door — cardinal and vice-chancellor', ['RISE', 'POLITICS'],
      'Rodrigo’s uncle becomes Pope Callixtus III and swiftly showers his nephew with power — a cardinal’s hat at twenty-five and then the vice-chancellorship of the Church, the richest and most powerful administrative office in Rome.',
      svg_stack('Lifted by an uncle’s hand', [
          {'n': 1, 'label': 'Uncle elected Callixtus III, 1455', 'sub': 'a Borja becomes pope', 'color': '#b45309'},
          {'n': 2, 'label': 'Made a cardinal, 1456', 'sub': 'the red hat at just twenty-five', 'color': '#9f1239'},
          {'n': 3, 'label': 'Vice-chancellor, 1457', 'sub': 'the richest office in the Curia', 'color': '#3730a3'},
      ], takeaway='Naked nepotism launched him — but he turned the gift into a base of power he would hold for thirty-five years.', accent=AC),
      bg='In 1455 Rodrigo’s uncle Alonso de Borja was elected <b>Pope Callixtus III</b>, the first Borgia pope, and at once advanced his kinsmen.',
      people='<b>Pope Callixtus III</b> (his uncle Alonso de Borja); Rodrigo’s brother Pedro Luis; the resentful Italian cardinals.',
      what='Callixtus made Rodrigo a <b>cardinal in 1456</b> and, in 1457, <b>vice-chancellor of the Holy Roman Church</b> — the most lucrative and powerful administrative post in the Curia.',
      crux='This was <b>nepotism in its literal sense</b> (from <i>nipote</i>, nephew) — but Rodrigo proved a gifted administrator who made the office genuinely his own.',
      conseq='He would hold the vice-chancellorship for over three decades, amassing wealth and influence under a succession of popes.',
      matters='Advancement by family was the rule of the age — but keeping and building on it demanded real ability, which Rodrigo had in abundance.'),

    E('vicechancellor', '1458–1492', 'Thirty-five years amassing wealth and power', ['RISE', 'POLITICS'],
      'For over three decades Cardinal Borgia serves as vice-chancellor under a string of popes — accumulating benefices, palaces and a vast fortune, fathering children by his mistresses, and mastering the machinery of the Curia while patiently biding his time.',
      svg_stack('Building a base under five popes', [
          {'n': 1, 'label': 'Vice-chancellor for 35 years', 'sub': 'serves through five successive popes', 'color': '#3730a3'},
          {'n': 2, 'label': 'Amasses immense wealth', 'sub': 'benefices, palaces, one of Rome’s great fortunes', 'color': '#b45309'},
          {'n': 3, 'label': 'A worldly cardinal', 'sub': 'children by Vannozza dei Cattanei', 'color': '#9f1239'},
      ], takeaway='Patience and administration made him the richest cardinal in Rome — and the obvious man to watch when the throne fell vacant.', accent=AC),
      bg='After Callixtus died, Rodrigo kept the vice-chancellorship, serving popes from Pius II to Innocent VIII across more than thirty years.',
      people='the popes he served; his mistress <b>Vannozza dei Cattanei</b>, mother of his children; his growing brood, including <b>Cesare</b> and <b>Lucrezia</b>.',
      what='Borgia mastered the <b>administration and finances of the Curia</b>, amassing benefices and one of the largest fortunes in Rome, while openly fathering children — a worldliness common among Renaissance prelates but pursued on a grand scale.',
      crux='He combined <b>administrative brilliance with unabashed worldliness</b> — building both a fortune and a family he intended to elevate.',
      conseq='By 1492 he was the wealthiest and most experienced cardinal in Rome, ideally placed for the ultimate prize.',
      matters='Long patience and command of the machinery of power lay the groundwork for a leap to the top when the moment comes.'),
]

# ==================================================================  PHASE 2 — THE TIARA
PHASE_TIARA = [
    E('conclave', '1492', 'Buying the throne of Saint Peter', ['POLITICS', 'TURNING POINT', 'SCANDAL'],
      'On the death of Innocent VIII in 1492, Cardinal Borgia wins the papal conclave amid widespread accusations of simony — reportedly buying the votes of rival cardinals with money and offices — and takes the throne as Pope Alexander VI.',
      svg_row('Election by gold and bargaining', [
          {'n': 1, 'label': 'Innocent VIII dies, 1492', 'sub': 'the throne of Peter falls vacant', 'color': '#78350f'},
          {'n': 2, 'label': 'Votes bought and traded', 'sub': 'offices and gold to rivals — accusations of simony', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Elected Alexander VI', 'sub': 'crowned pope, 11 August 1492', 'color': '#9f1239'},
      ], edge_labels=['then', 'so'], takeaway='He reached the summit through bribery and bargaining — a triumph of ambition that stained the office from the first day.', accent=AC),
      bg='When <b>Pope Innocent VIII</b> died in 1492, the cardinals gathered in conclave. Borgia was the most powerful and richest candidate.',
      people='the rival cardinals, notably <b>Ascanio Sforza</b>, reportedly won over with the vice-chancellorship; the young <b>Giovanni de’ Medici</b>, future Leo X.',
      what='Borgia was <b>elected Pope Alexander VI on 11 August 1492</b> amid open accusations that he had <b>bought votes with money and offices</b> — the sin of simony — most notably rewarding Ascanio Sforza with his own former post.',
      crux='He gained the papacy through <b>bribery and hard bargaining</b> rather than sanctity — power politics dressed in sacred robes.',
      conseq='He entered the papacy under a cloud of scandal that would shadow his entire reign and blacken the Borgia name.',
      matters='The Renaissance papacy was as much a prize of politics as of faith — and Alexander won it by mastering that ruthless game.'),

    E('familymachine', '1493', 'Turning the papacy into a family enterprise', ['POLITICS', 'SCANDAL'],
      'Once enthroned, Alexander sets the papal machine to work for the Borgia dynasty — making his teenage son Cesare a cardinal, showering relatives with offices and lands, and bending the resources of the Church to build Borgia power in Italy.',
      svg_stack('The Church in the family’s service', [
          {'n': 1, 'label': 'Cesare a cardinal at 18', 'sub': 'the pope’s son given the red hat, 1493', 'color': '#9f1239'},
          {'n': 2, 'label': 'Kin showered with offices', 'sub': 'Borgias placed across the Church and Italy', 'color': '#b45309'},
          {'n': 3, 'label': 'A dynasty-building papacy', 'sub': 'Church resources bent to Borgia power', 'color': '#3730a3'},
      ], takeaway='He ran the papacy as a family firm — every office and alliance harnessed to raise the house of Borgia.', accent=AC),
      bg='From the moment of his election, Alexander aimed to convert the papacy into a permanent power base for his own children.',
      people='his son <b>Cesare Borgia</b>, made cardinal at eighteen; his son <b>Juan</b>, Duke of Gandia; the wider Borgia clan.',
      what='Alexander made the <b>eighteen-year-old Cesare a cardinal in 1493</b>, granted his relatives offices, titles and lands, and directed the <b>wealth and influence of the Church toward building a Borgia dynasty</b> in Italy.',
      crux='He treated the papacy as a <b>family enterprise</b> — its spiritual authority a means to secular, dynastic ends.',
      conseq='Borgia power grew rapidly, but the naked nepotism deepened his reputation for corruption.',
      matters='Alexander’s papacy is the classic case of using sacred office for family aggrandisement — brilliantly effective and morally corrosive.'),

    E('tordesillas', '1493–1494', 'Dividing the New World with a stroke of the pen', ['POLITICS', 'TRIUMPH'],
      'When Spain and Portugal quarrel over Columbus’s discoveries, Alexander issues the bulls of 1493 drawing a line across the ocean — and, refined into the Treaty of Tordesillas, this papal division splits the entire New World between the two Iberian crowns.',
      svg_row('A line drawn across the globe', [
          {'n': 1, 'label': 'Columbus returns, 1493', 'sub': 'Spain and Portugal contest the new lands', 'color': '#166534'},
          {'n': 2, 'label': 'Bull Inter caetera, 1493', 'sub': 'a line of demarcation across the Atlantic', 'color': '#9f1239'},
          {'n': 3, 'label': 'Treaty of Tordesillas, 1494', 'sub': 'the New World split between Spain and Portugal', 'color': '#b45309'},
      ], edge_labels=['so', 'yields'], takeaway='A Spanish pope divided the newly discovered world between two crowns — an extraordinary assertion of papal authority.', accent=AC),
      bg='In 1493 Columbus returned from the Americas, and Spain and Portugal both claimed the new-found lands, appealing to the pope to arbitrate.',
      people='<b>Ferdinand and Isabella</b> of Spain; <b>John II</b> of Portugal; Columbus, whose voyage set off the dispute.',
      what='Alexander issued the bulls <b>Inter caetera (1493)</b> drawing a line of demarcation across the Atlantic, awarding lands west of it to Spain; renegotiated by the crowns as the <b>Treaty of Tordesillas (1494)</b>, this divided the New World between the two Iberian powers.',
      crux='He asserted the pope’s authority to <b>partition the whole newly discovered world</b> — a claim of universal spiritual sovereignty with vast worldly consequences.',
      conseq='The line shaped centuries of colonial history, giving Spain most of the Americas and Portugal a route to Brazil, Africa and Asia.',
      matters='One of the most consequential acts of any pope — a stroke of the pen that helped carve up continents and shape the modern world.'),
]

# ==================================================================  PHASE 3 — THE BORGIA DYNASTY
PHASE_FAMILY = [
    E('lucrezia', '1493–1502', 'Lucrezia — a daughter married for dynasty', ['POLITICS', 'FAMILY', 'SCANDAL'],
      'Alexander uses his daughter Lucrezia as a dynastic instrument, marrying her three times as Borgia alliances shift — a Sforza, then an Aragonese prince, then the heir of Ferrara — each match made and unmade to serve the family’s changing political needs.',
      svg_stack('A daughter wed to policy', [
          {'n': 1, 'label': 'Giovanni Sforza, 1493', 'sub': 'marriage annulled once the alliance cooled', 'color': '#b45309'},
          {'n': 2, 'label': 'Alfonso of Aragon, 1498', 'sub': 'a Naples match — the husband later murdered', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Alfonso d’Este of Ferrara, 1502', 'sub': 'a grand dynastic alliance secured', 'color': '#9f1239'},
      ], takeaway='He married his daughter three times to serve shifting alliances — Lucrezia the pawn of Borgia strategy, though she rose above it.', accent=AC),
      bg='Alexander treated marriages as instruments of policy, and his beautiful, intelligent daughter Lucrezia was his most valuable dynastic asset.',
      people='<b>Lucrezia Borgia</b>, his daughter; her successive husbands — Giovanni Sforza, Alfonso of Aragon and Alfonso d’Este; her brother Cesare.',
      what='Alexander married Lucrezia to <b>Giovanni Sforza (1493)</b>, annulling the union when the alliance lost value; then to <b>Alfonso of Aragon (1498)</b>, murdered as policy shifted; and finally to <b>Alfonso d’Este of Ferrara (1502)</b>, a prestigious dynastic prize.',
      crux='He used marriage as a <b>weapon of diplomacy</b> — making and breaking Lucrezia’s unions as the family’s alliances demanded.',
      conseq='Lucrezia, long slandered by rumour, became a respected duchess of Ferrara and patron of the arts, outliving the scandal.',
      matters='Dynastic marriage was cold statecraft — but Lucrezia’s later life shows a woman who transcended her father’s ruthless calculations.'),

    E('juan', '1497', 'Murder in the family — the death of Juan', ['FAMILY', 'TRAGEDY', 'DEATH'],
      'Alexander’s favourite son Juan, Duke of Gandia, is found murdered in the Tiber — a killing that plunges the pope into genuine grief and never-solved suspicion, with dark rumour falling on his own brother Cesare.',
      svg_stack('A favourite son struck down', [
          {'n': 1, 'label': 'Juan, Duke of Gandia', 'sub': 'the pope’s cherished eldest son', 'color': '#b45309'},
          {'n': 2, 'label': 'Murdered in the Tiber, 1497', 'sub': 'body found stabbed in the river', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Suspicion falls on Cesare', 'sub': 'the killing never solved', 'color': '#78350f'},
      ], takeaway='The murder of his favourite son shattered Alexander — and cast a shadow of fratricide over the Borgia household.', accent=AC),
      bg='Juan (Giovanni), Duke of Gandia, was Alexander’s favourite son, marked out for secular greatness at the head of the Borgia enterprise.',
      people='<b>Juan Borgia</b>, Duke of Gandia; his brother <b>Cesare</b>, the chief suspect in rumour; the grieving pope.',
      what='In 1497 Juan was <b>found murdered in the Tiber</b>, stabbed and thrown into the river. The crime was never solved, but suspicion fell heavily — though unproven — on his brother <b>Cesare</b>.',
      crux='The murder revealed the <b>violence at the heart of the Borgia household</b> and left the pope in genuine, prostrating grief.',
      conseq='With Juan dead, Alexander increasingly rested the family’s worldly ambitions on Cesare, who now stepped forward.',
      matters='Even at the summit of power, the Borgias were riven by the same violence and suspicion they used against others.'),

    E('cesareprince', '1498–1502', 'Cesare — the sword of the Borgias and Machiavelli’s Prince', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'Cesare Borgia renounces his cardinal’s hat to become a soldier-prince, and with his father’s backing carves out a Borgia state by conquering the Romagna — a campaign of ruthless brilliance that made him the model for Machiavelli’s Prince.',
      svg_row('From red hat to warlord’s sword', [
          {'n': 1, 'label': 'Cesare quits the cardinalate, 1498', 'sub': 'the first cardinal ever to resign the office', 'color': '#9f1239'},
          {'n': 2, 'label': 'Conquers the Romagna', 'sub': 'carves a Borgia state in central Italy', 'color': '#b45309'},
          {'n': 3, 'label': 'Model for The Prince', 'sub': 'Machiavelli studies his ruthless method', 'color': '#3730a3'},
      ], edge_labels=['then', 'so'], takeaway='Father and son together built a Borgia principality by force and cunning — the very embodiment of Machiavellian statecraft.', accent=AC),
      bg='After Juan’s death, Alexander’s ambitions centred on Cesare, who abandoned the Church for a career of arms and conquest.',
      people='<b>Cesare Borgia</b>, Duke of Valentinois (“il Valentino”); <b>Niccolò Machiavelli</b>, who observed him as a Florentine envoy; the lords of the Romagna he displaced.',
      what='Cesare <b>resigned his cardinalate in 1498</b> — the first ever to do so — and, backed by papal money and French alliance, <b>conquered the Romagna</b> to build a Borgia state, his ruthless efficiency making him the <b>model for Machiavelli’s The Prince</b>.',
      crux='The Borgias pursued a <b>secular principality</b> through force, guile and terror — statecraft stripped of scruple.',
      conseq='By 1502 Cesare had built a formidable territory, but it depended entirely on his father’s life and the papacy’s support.',
      matters='Cesare’s career gave Machiavelli his archetype of the new prince — power pursued by any means, admired and feared in equal measure.'),
]

# ==================================================================  PHASE 4 — POWER, ART AND ENEMIES
PHASE_POWER = [
    E('savonarola', '1495–1498', 'The pope and the prophet — crushing Savonarola', ['POLITICS', 'BATTLE'],
      'In Florence the fiery friar Savonarola denounces the corruption of Alexander’s court and calls for reform — and the pope answers by excommunicating him, until the prophet is condemned, hanged and burned.',
      svg_compare('Worldly pope versus zealous friar', {
          'head': 'Alexander VI', 'color': '#9f1239', 'items': [
              'Worldly, political, dynastic pope',
              'Wields excommunication and Church power',
              'Defends the papacy against reform',
              'Outlasts and destroys his critic']},
      {
          'head': 'Savonarola', 'color': '#166534', 'items': [
              'Puritan Dominican friar of Florence',
              'Denounces papal corruption and vice',
              'Preaches repentance and reform',
              'Condemned, hanged and burned, 1498']},
      verdict='The worldly pope crushed the reforming prophet — but the demand for reform did not die with him.',
      takeaway='Alexander destroyed the friar who condemned his corruption — yet Savonarola’s cry for reform foreshadowed the coming storm.', accent=AC),
      bg='The Dominican friar <b>Girolamo Savonarola</b> had made himself master of Florence, thundering against the vice and corruption of the age — and of Alexander’s Rome.',
      people='<b>Girolamo Savonarola</b>, the reforming friar; the people of Florence; Alexander, the target of his sermons.',
      what='When Savonarola’s attacks on papal corruption grew unbearable, Alexander <b>excommunicated him (1497)</b> and pressed for his suppression; in 1498 the friar was <b>condemned, hanged and burned</b> in Florence.',
      crux='It was a collision between <b>worldly power and moral reform</b> — the political pope against the puritan prophet.',
      conseq='Alexander won the immediate contest, but the appetite for reform he mocked would erupt within a generation as the Reformation.',
      matters='The clash foreshadowed the great reckoning to come — the corruption Savonarola denounced would soon split Western Christianity.'),

    E('patronage', '1492–1503', 'Splendour and the arts of the Renaissance', ['CULTURE', 'REFORM'],
      'For all his sins, Alexander is a true Renaissance prince — a lavish patron who commissions Pinturicchio to fresco the sumptuous Borgia Apartments, presides over the great Jubilee of 1500, and fills Rome with spectacle and art.',
      svg_stack('A patron of Renaissance magnificence', [
          {'n': 1, 'label': 'The Borgia Apartments', 'sub': 'frescoed in splendour by Pinturicchio', 'color': '#9f1239'},
          {'n': 2, 'label': 'The Jubilee of 1500', 'sub': 'a vast holy year draws pilgrims to Rome', 'color': '#b45309'},
          {'n': 3, 'label': 'Spectacle and the arts', 'sub': 'a Renaissance court of pomp and patronage', 'color': '#3730a3'},
      ], takeaway='He clothed his corruption in beauty — a patron of high Renaissance art even as scandal swirled around his throne.', accent=AC),
      bg='Alexander governed at the height of the Italian Renaissance, and like other princes of the age he made his court a centre of art and display.',
      people='the painter <b>Pinturicchio</b>, who frescoed his apartments; the artists, poets and pilgrims of Renaissance Rome.',
      what='Alexander commissioned <b>Pinturicchio to decorate the Borgia Apartments</b> in the Vatican with brilliant frescoes, presided over the <b>Jubilee (Holy Year) of 1500</b>, and sustained a court of Renaissance <b>magnificence and spectacle</b>.',
      crux='He embodied the <b>Renaissance prince</b> — combining worldly corruption with genuine patronage of art and learning.',
      conseq='The art of his reign endures in the Vatican, a lasting monument to a papacy remembered chiefly for its scandals.',
      matters='The Borgia story is not only corruption — Alexander was a patron of a dazzling cultural age whose beauty outlived his sins.'),

    E('italianwars', '1494–1503', 'Alliances and betrayals in the Italian Wars', ['POLITICS', 'BATTLE'],
      'As French and Spanish armies pour into a divided Italy, Alexander plays the great powers against one another with cold skill — allying, betraying and re-allying with France, Spain, Naples and Venice to shield the papacy and advance the Borgia cause.',
      svg_row('Playing the powers against each other', [
          {'n': 1, 'label': 'Foreign armies invade Italy', 'sub': 'France and Spain contest the peninsula', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Shifting alliances', 'sub': 'leagues made and broken with France and Spain', 'color': '#b45309'},
          {'n': 3, 'label': 'Borgia power advanced', 'sub': 'the papacy shielded, Cesare’s state backed', 'color': '#9f1239'},
      ], edge_labels=['met by', 'to'], takeaway='He survived the wars of Italy by ceaseless manoeuvre — allying and betraying with a diplomat’s ruthless flexibility.', accent=AC),
      bg='In 1494 <b>Charles VIII of France</b> invaded Italy, opening the long Italian Wars that made the peninsula a battleground for France and Spain.',
      people='<b>Charles VIII</b> and <b>Louis XII</b> of France; <b>Ferdinand of Spain</b>; the states of Naples, Milan, Venice and Florence.',
      what='Through the Italian Wars, Alexander <b>allied and broke with the great powers in turn</b> — welcoming, then opposing France; leaning on Spain; using each shift to <b>protect the papacy and build Cesare’s state</b> in the Romagna.',
      crux='He practised <b>flexible, unsentimental diplomacy</b> — no permanent friends or enemies, only Borgia interest.',
      conseq='His manoeuvres kept the papacy afloat amid chaos and expanded Borgia power, but rested on the shifting sands of foreign arms.',
      matters='Alexander was a master of realpolitik — steering a weak state through great-power wars by cunning alliance and timely betrayal.'),
]

# ==================================================================  PHASE 5 — THE FALL
PHASE_FALL = [
    E('peak', '1500–1503', 'The Borgias at their zenith', ['POLITICS', 'TRIUMPH'],
      'By the early 1500s the Borgias tower over Italy — Cesare’s conquered state spreads across the Romagna, papal coffers swell, and enemies are cowed or crushed, the family’s power greater than any could have imagined at Alexander’s election.',
      svg_stack('The house of Borgia at its height', [
          {'n': 1, 'label': 'Cesare’s state expands', 'sub': 'the Romagna consolidated under Borgia rule', 'color': '#9f1239'},
          {'n': 2, 'label': 'Wealth and dominance', 'sub': 'papal power and Borgia fortune at their peak', 'color': '#b45309'},
          {'n': 3, 'label': 'Enemies crushed or cowed', 'sub': 'rivals broken, alliances secured', 'color': '#3730a3'},
      ], takeaway='At its zenith the Borgia enterprise dominated central Italy — but its whole edifice rested on one aging life.', accent=AC),
      bg='By 1500–1503 the combined skill of father and son had made the Borgias the dominant force in central Italy.',
      people='<b>Alexander VI</b>, directing from Rome; <b>Cesare Borgia</b>, conquering in the field; the cowed lords of Italy.',
      what='The Borgias reached their <b>zenith</b>: Cesare’s state stretched across the <b>Romagna</b>, papal wealth and influence were immense, and rivals were broken — a family power unimaginable at Alexander’s election.',
      crux='The Borgia edifice was <b>brilliant but fragile</b> — everything depended on Alexander’s continued life and the papacy in his hands.',
      conseq='This dependence was the enterprise’s fatal weakness, as the sudden events of 1503 would reveal.',
      matters='Power built on one man’s office is only as durable as his life — a lesson the Borgias were about to learn catastrophically.'),

    E('death', '1503', 'Death in the summer heat — and rumours of poison', ['DEATH', 'TURNING POINT'],
      'In August 1503 Alexander falls suddenly ill and dies, most likely of malarial fever in the Roman summer — though the age at once whispered of poison, imagining the poisoner poisoned by his own cup.',
      svg_stack('The sudden fall of the pope', [
          {'n': 1, 'label': 'Struck down by fever, 1503', 'sub': 'sudden illness in the Roman summer', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Dies 18 August 1503', 'sub': 'most likely malaria — Cesare also gravely ill', 'color': '#78350f'},
          {'n': 3, 'label': 'Rumours of poison', 'sub': 'legend of a poisoned cup, unproven', 'color': '#9f1239'},
      ], takeaway='He died as suddenly as he had risen — probably of fever, though legend insisted the great poisoner met his own poison.', accent=AC),
      bg='In the summer of 1503 Alexander and Cesare both fell suddenly and gravely ill in the fever-ridden heat of Rome.',
      people='<b>Alexander VI</b>, dying; <b>Cesare Borgia</b>, stricken at the same time; the Roman crowd, quick to believe the worst.',
      what='Alexander <b>died on 18 August 1503</b>, almost certainly of <b>malarial fever</b>. Rumour immediately claimed <b>poison</b> — a colourful legend of the poisoner accidentally drinking his own cup — but the evidence points to disease.',
      crux='His death was <b>sudden and catastrophically timed</b>, striking down both pope and son together and paralysing the Borgia state.',
      conseq='With Alexander gone and Cesare bedridden, the whole Borgia enterprise, resting on the papacy, began at once to unravel.',
      matters='The lurid poison legend endures, but the truth — death by common fever at the worst possible moment — undid an empire in days.'),

    E('legacy', '1503–after', 'The verdict — corruption and cold genius', ['LEGACY', 'REFORM'],
      'Alexander leaves a double legacy: remembered as the most notorious of popes, a byword for corruption and worldliness — yet also a formidable statesman and patron whose political skill, for good and ill, marked the age of the Renaissance papacy.',
      svg_compare('The two faces of Alexander VI', {
          'head': 'The scandal', 'color': '#b91c1c', 'items': [
              'Simony, nepotism and vast worldliness',
              'The papacy bent to family power',
              'Byword for Renaissance corruption',
              'Neglect that fed calls for reform']},
      {
          'head': 'The statecraft', 'color': '#166534', 'items': [
              'Formidable administrator and diplomat',
              'Divided the New World by the Tordesillas line',
              'Patron of high Renaissance art',
              'Master of realpolitik in a violent age']},
      verdict='A pope of genuine political genius and genuine corruption — both must be held in view to see him whole.',
      takeaway='He was neither cartoon villain nor able reformer, but both scandal and skill at once — the Renaissance papacy in one man.', accent=AC),
      bg='After his death the Borgia name became legend — magnified by enemies and later fiction into a byword for depravity.',
      people='<b>Cesare</b>, whose fall soon followed; <b>Lucrezia</b>, redeemed as a duchess of Ferrara; the reformers and rivals who shaped his dark reputation.',
      what='Alexander is remembered as the most <b>notorious of popes</b> — corrupt, nepotistic and worldly — yet also a <b>capable administrator, shrewd diplomat and generous patron</b> whose reign shaped the Renaissance Church for good and ill.',
      crux='His legacy demands a <b>double judgement</b>: real corruption and real political skill, held together rather than one erasing the other.',
      conseq='Within a generation the abuses of popes like Alexander helped provoke the Reformation that shattered the unity of the Western Church.',
      matters='Alexander VI is the great study in the Renaissance papacy — where sacred office, family ambition, art and corruption were fused in a single reign.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Rodrigo Borgia — Pope Alexander VI — is the most notorious of the Renaissance popes, and one of the most capable. A Spaniard from Valencia raised by an uncle’s nepotism, he spent thirty-five years as vice-chancellor amassing wealth and mastering the Curia before buying his way to the throne of Saint Peter in 1492. As pope he bent the Church to the glory of his own family — making his son Cesare a warlord-prince and marrying his daughter Lucrezia for dynastic advantage — while dividing the New World between Spain and Portugal, patronising Renaissance art, crushing the reformer Savonarola, and steering the papacy through the wars of Italy with cold, brilliant realpolitik. He is the ultimate study in <b>sacred office and worldly ambition, family power and Renaissance corruption — the papacy as a game of state.</b></p>
<div class="ov-quote">“Now we are in the power of a wolf, the most rapacious perhaps that this world has ever seen.”<span>— attributed to Giovanni de’ Medici, the future Pope Leo X, on Alexander’s election</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A Valencian outsider is lifted by his uncle Callixtus III to cardinal and vice-chancellor → he spends decades amassing wealth and power in the Curia → buys the papacy in 1492 amid accusations of simony → turns the Church into a Borgia family enterprise and divides the New World by the Treaty of Tordesillas → raises Cesare into Machiavelli’s Prince and marries Lucrezia for dynasty → crushes Savonarola, patronises the arts, and plays the powers of Italy against one another → and dies suddenly in 1503, leaving a legacy of both corruption and cold genius.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⛪</div><h4>The family papacy</h4><p>Bent the sacred office to the power of the house of Borgia.</p></div>
  <div class="ov-card"><div class="i">🌍</div><h4>Dividing the world</h4><p>His Tordesillas line split the New World between Spain and Portugal.</p></div>
  <div class="ov-card"><div class="i">🗡️</div><h4>Machiavelli’s model</h4><p>His son Cesare became the archetype of The Prince.</p></div>
  <div class="ov-card"><div class="i">🎭</div><h4>Corruption and art</h4><p>A byword for scandal — and a patron of the high Renaissance.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Rise</b><small> 1431–1492</small><p>A Spaniard lifted by nepotism to master the Curia.</p></div>
  <div><b>2 · The Tiara</b><small> 1492–1494</small><p>Buying the papacy; a family machine; dividing the world.</p></div>
  <div><b>3 · The Dynasty</b><small> 1493–1502</small><p>Lucrezia, Cesare and the murder of Juan.</p></div>
  <div><b>4 · Power &amp; Enemies</b><small> 1494–1503</small><p>Savonarola, patronage and the Italian Wars.</p></div>
  <div><b>5 · The Fall</b><small> 1500–1503</small><p>Zenith, sudden death, and a double legacy.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Cesare Borgia', 'role': 'son and sword', 'color': '#9f1239',
     'bio': 'Alexander’s ruthless son, who quit the cardinalate to conquer the Romagna as a soldier-prince and became the model for Machiavelli’s The Prince.',
     'rel': 'The son on whom he staked the family’s worldly ambitions.'},
    {'name': 'Lucrezia Borgia', 'role': 'daughter and pawn', 'color': '#b45309',
     'bio': 'Alexander’s daughter, married three times for shifting alliances and long slandered by rumour, who rose above it as a respected duchess of Ferrara.',
     'rel': 'The daughter he wed and re-wed as an instrument of policy.'},
    {'name': 'Pope Callixtus III', 'role': 'uncle and patron', 'color': '#166534',
     'bio': 'The first Borgia pope, Alexander’s uncle Alonso de Borja, whose nepotism raised the young Rodrigo to cardinal and vice-chancellor.',
     'rel': 'The uncle whose favour launched his whole career.'},
    {'name': 'Girolamo Savonarola', 'role': 'reforming adversary', 'color': '#3730a3',
     'bio': 'The puritan Dominican friar of Florence who denounced papal corruption, was excommunicated by Alexander, and was hanged and burned in 1498.',
     'rel': 'The prophet of reform he excommunicated and destroyed.'},
    {'name': 'Vannozza dei Cattanei', 'role': 'mistress and mother', 'color': '#78350f',
     'bio': 'Alexander’s long-term mistress and mother of his principal children — Cesare, Juan, Lucrezia and Gioffre — the matriarch of the Borgia line.',
     'rel': 'The mother of the children through whom he built his dynasty.'},
]

KEY_EVENTS = [
    ('1431', 'Rodrigo Borgia born', 'At Xàtiva in Valencia, Spain.'),
    ('1456', 'Made a cardinal', 'By his uncle Pope Callixtus III.'),
    ('1457', 'Vice-chancellor', 'The richest office in the Curia.'),
    ('1492', 'Elected Alexander VI', 'Amid accusations of simony.'),
    ('1493', 'Inter caetera bulls', 'Dividing the New World.'),
    ('1494', 'Treaty of Tordesillas', 'Spain and Portugal split the globe.'),
    ('1497', 'Murder of Juan', 'His favourite son killed.'),
    ('1498', 'Savonarola executed', 'The reformer hanged and burned.'),
    ('1503', 'Death of Alexander', 'Fever, and rumours of poison.'),
]

MASTER = [
    {'year': '1431', 'age': 'born', 'phase': 'The Rise', 'title': 'Born at Xàtiva', 'desc': 'A Spaniard bound for Rome.'},
    {'year': '1456', 'age': 'age 25', 'phase': 'The Rise', 'title': 'Cardinal & vice-chancellor', 'desc': 'Lifted by his uncle.'},
    {'year': '1492', 'age': 'age 61', 'phase': 'The Tiara', 'title': 'Elected Alexander VI', 'desc': 'Buys the papacy.'},
    {'year': '1493', 'age': 'age 62', 'phase': 'The Tiara', 'title': 'Dividing the New World', 'desc': 'The Tordesillas line.'},
    {'year': '1498', 'age': 'age 67', 'phase': 'Power & Enemies', 'title': 'Savonarola destroyed', 'desc': 'Cesare turns warlord.'},
    {'year': '1503', 'age': 'age 72', 'phase': 'The Fall', 'title': 'Sudden death', 'desc': 'The Borgia state unravels.'},
]

SOURCES = [
    ('Britannica — Alexander VI', 'https://www.britannica.com/biography/Alexander-VI'),
    ('World History Encyclopedia — Pope Alexander VI', 'https://www.worldhistory.org/Alexander_VI/'),
    ('Britannica — Treaty of Tordesillas', 'https://www.britannica.com/event/Treaty-of-Tordesillas'),
    ('Britannica — Cesare Borgia', 'https://www.britannica.com/biography/Cesare-Borgia'),
    ('Wikipedia — Pope Alexander VI', 'https://en.wikipedia.org/wiki/Pope_Alexander_VI'),
]

def build_meta():
    return {
        'pid': 'gm-borgia.html', 'kind': 'man', 'emoji': '🐂', 'accent': AC,
        'name': 'Rodrigo Borgia (Alexander VI)', 'years': '1431–1503', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The most notorious of the Renaissance popes — a Valencian churchman of cold political genius who bought the papacy, bent it to his family’s power, divided the New World, and made the Borgia name a byword for scandal and statecraft alike.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Rise', 'type': 'timeline',
             'intro': 'A Spaniard from Valencia, lifted by his uncle Callixtus III to cardinal and vice-chancellor, spends thirty-five years amassing wealth and mastering the Curia.', 'events': PHASE_RISE},
            {'id': 'tiara', 'label': '2 · The Tiara', 'type': 'timeline',
             'intro': 'He buys the papacy amid accusations of simony, turns the Church into a Borgia family enterprise, and divides the New World between Spain and Portugal.', 'events': PHASE_TIARA},
            {'id': 'family', 'label': '3 · The Dynasty', 'type': 'timeline',
             'intro': 'He builds Borgia power through his children — marrying Lucrezia for dynasty and raising Cesare into Machiavelli’s Prince — amid the murder of his favourite son.', 'events': PHASE_FAMILY},
            {'id': 'power', 'label': '4 · Power & Enemies', 'type': 'timeline',
             'intro': 'He crushes the reformer Savonarola, patronises the high Renaissance, and steers the papacy through the Italian Wars with alliances made and broken.', 'events': PHASE_POWER},
            {'id': 'fall', 'label': '5 · The Fall', 'type': 'timeline',
             'intro': 'The Borgias reach their zenith before Alexander dies suddenly in 1503 — probably of fever, though legend cried poison — leaving a legacy of corruption and cold genius.', 'events': PHASE_FALL,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; lurid Borgia legends (poison, and worse) are treated as later embellishment and set apart from the documented record.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
