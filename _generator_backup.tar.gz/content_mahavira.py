# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Lord Mahavira (Vardhamana).
The 24th Tirthankara of Jainism, who revived the eternal path of non-violence and self-conquest.
Presented with respect for the Jain tradition and even attention to tradition and scholarship."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#7c3aed'  # meditative amethyst

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE PRINCE
PHASE_PRINCE = [
    E('eternal', 'timeless', 'The 24th Tirthankara — reviver of an eternal path', ['TRADITION', 'FAITH'],
      'In the Jain tradition Mahavira is not the founder of a new religion but the twenty-fourth and last Tirthankara — a “ford-maker” who, like the twenty-three before him, rediscovers and re-proclaims an eternal, beginningless teaching for the present age, restoring a path that scholars and tradition alike trace back at least to his predecessor Parshvanatha.',
      svg_row('Not a founder, but a reviver', [
          {'n': 1, 'label': 'An eternal teaching', 'sub': 'the Jain path is held to be beginningless', 'color': '#7c3aed'},
          {'n': 2, 'label': 'A line of Tirthankaras', 'sub': 'twenty-four ford-makers across the ages', 'color': '#a16207'},
          {'n': 3, 'label': 'Mahavira the 24th', 'sub': 'the last to revive the path in this age', 'color': '#166534'},
      ], edge_labels=['renewed by', 'as'], takeaway='In Jain belief Mahavira revives an eternal dharma rather than inventing one — the last in a long line of enlightened teachers.', accent=AC),
      bg='Jain cosmology holds the true teaching to be eternal, revealed anew in each age by a succession of <b>Tirthankaras</b> (“ford-makers”) who show the way across the river of rebirth.',
      people='the twenty-three earlier Tirthankaras, especially <b>Parshvanatha</b>, the 23rd; the Jain community that preserved the tradition; Mahavira, its last reviver in this age.',
      what='Jain tradition regards Mahavira as the <b>24th and final Tirthankara</b> of the present cosmic cycle — not the originator of Jainism but the one who <b>revived and re-taught its eternal path</b>, building on the lineage of Parshvanatha before him.',
      crux='He is honoured as a <b>reviver and reformer</b>, giving the ancient teaching its enduring classical form rather than founding it from nothing.',
      conseq='This framing shapes how Jains understand him — one link, however luminous, in a timeless chain of liberated teachers.',
      matters='A tradition can see its greatest figure as a restorer of ancient truth rather than an inventor — continuity, not novelty, is its claim.'),

    E('birth', 'c. 599 BC', 'Born a prince at Kundagrama', ['LIFE', 'ORIGINS'],
      'Vardhamana — “the one who grows” — is born a prince of the Kshatriya Jnatrika clan at Kundagrama near Vaishali, son of the chieftain Siddhartha and Queen Trishala, into a household that already followed the teaching of Parshvanatha; tradition surrounds his birth with auspicious dreams and signs of a great soul.',
      svg_row('A prince of the Jnatrika clan', [
          {'n': 1, 'label': 'Kundagrama, near Vaishali', 'sub': 'in the republics of the Ganges plain', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Prince Vardhamana', 'sub': 'son of chief Siddhartha and Queen Trishala', 'color': '#a16207'},
          {'n': 3, 'label': 'A devout Kshatriya house', 'sub': 'his parents followed Parshvanatha', 'color': '#166534'},
      ], edge_labels=['a', 'in'], takeaway='He was born to rank and comfort in a devout warrior-noble house — the worldly starting point of a life he would renounce.', accent=AC),
      bg='In the sixth century BC the Ganges plain held prosperous kingdoms and clan-republics. Near <b>Vaishali</b> lay Kundagrama, seat of the <b>Jnatrika</b> Kshatriya clan.',
      people='<b>Vardhamana</b>, the prince; his father the chieftain <b>Siddhartha</b>; his mother <b>Queen Trishala</b>, kin to the ruling house of Vaishali.',
      what='Mahavira was born <b>Vardhamana</b>, a prince of the <b>Jnatrika Kshatriya clan</b> at Kundagrama near Vaishali (traditionally c. 599 BC), into a family that already revered <b>Parshvanatha’s</b> teaching.',
      crux='He began life amid <b>wealth, rank and comfort</b> — the very things his later renunciation would set aside.',
      conseq='His princely upbringing gave him every worldly advantage, sharpening the meaning of the sacrifice he would later make.',
      matters='The starting point measures the renunciation — a prince who gives up a throne renounces more than a pauper ever could.'),

    E('youth', 'youth', 'A prince amid plenty — and inward detachment', ['LIFE', 'FORMATION'],
      'Raised in the ease and refinement of a princely court, Vardhamana grows in learning and, by the Svetambara account, marries and has a daughter — yet the tradition remembers a young man inwardly detached from luxury even as he lives among it, waiting on his parents’ wishes before turning to the path he already senses.',
      svg_stack('Plenty without attachment', [
          {'n': 1, 'label': 'Princely education and ease', 'sub': 'raised in courtly refinement and learning', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Worldly life fulfilled', 'sub': 'Svetambara: marries Yashoda, a daughter', 'color': '#a16207'},
          {'n': 3, 'label': 'Inwardly unattached', 'sub': 'detached from luxury while living within it', 'color': '#166534'},
      ], takeaway='He lived in the world without being bound by it — a detachment that would ripen into total renunciation.', accent=AC),
      bg='Traditions differ on his early life: the <b>Svetambara</b> account has him marry and raise a daughter, while the <b>Digambara</b> account holds he never married. Both remember an inward detachment.',
      people='the young <b>Vardhamana</b>; his parents, whose wishes he honoured; in the Svetambara telling, his wife <b>Yashoda</b> and daughter.',
      what='Vardhamana grew up in the <b>comfort of a princely court</b>, accomplished and honoured, yet — the tradition holds — <b>inwardly detached</b> from pleasures, waiting out of duty to his parents before renouncing the world.',
      crux='He embodied a life <b>in the world but not of it</b> — enjoying no hold over him even amid abundance.',
      conseq='On his parents’ passing, freed of his last worldly duty, he was ready to renounce all.',
      matters='True detachment is tested amid plenty, not poverty — the harder renunciation is of what one already holds.'),
]

# ==================================================================  PHASE 2 — THE GREAT RENUNCIATION
PHASE_RENOUNCE = [
    E('renunciation', 'c. 569 BC · age 30', 'The Great Renunciation', ['TURNING POINT', 'FAITH'],
      'At about the age of thirty, Vardhamana makes the Great Renunciation — giving away his wealth and possessions, casting off his fine garments, plucking out his hair, and walking away from palace and rank to become a homeless wandering ascetic in search of the truth that ends all suffering.',
      svg_row('Casting off the world', [
          {'n': 1, 'label': 'Free of worldly duty', 'sub': 'at about thirty, he chooses the path', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Gives away everything', 'sub': 'wealth, garments, rank — all renounced', 'color': '#9a3412'},
          {'n': 3, 'label': 'A homeless ascetic', 'sub': 'walks out to seek liberation', 'color': '#166534'},
      ], edge_labels=['he', 'becoming'], takeaway='He abandoned a prince’s every comfort for the hardest of roads — the Great Renunciation that begins the spiritual quest.', accent=AC),
      bg='Freed of his final worldly obligation, Vardhamana resolved to seek the release from suffering and rebirth that the ascetic path promised.',
      people='<b>Vardhamana</b>, now a renunciant; the kin and household he left behind; the wider world of wandering seekers he joined.',
      what='At around <b>age 30</b>, Vardhamana made the <b>Great Renunciation</b> — distributing his possessions, discarding his fine clothes, plucking out his hair by hand, and leaving home to live as a <b>homeless wandering ascetic</b>.',
      crux='He chose <b>total renunciation</b> — not a partial retreat but the complete surrender of wealth, status and comfort.',
      conseq='So began twelve and a half years of severe austerity in pursuit of enlightenment.',
      matters='The spiritual quest can demand everything — Mahavira’s renunciation set the pattern of the Jain monk who owns nothing at all.'),

    E('austerity', '12.5 years', 'Twelve and a half years of austerity', ['FAITH', 'ORDEAL'],
      'For twelve and a half years Mahavira wanders as an ascetic in unbroken discipline — enduring long fasts, silence and exposure, meditating for days on end, bearing hardship and hostility without complaint, and above all practising ahimsa so scrupulously that he takes care to harm no living being, however small.',
      svg_stack('The long discipline', [
          {'n': 1, 'label': 'Severe fasting and silence', 'sub': 'long fasts, deep meditation, exposure', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Hardship borne calmly', 'sub': 'endures suffering without anger', 'color': '#9a3412'},
          {'n': 3, 'label': 'Utmost non-violence', 'sub': 'careful to harm no living thing', 'color': '#166534'},
      ], takeaway='Through years of severe austerity he disciplined body and mind — enduring all with equanimity and harming nothing.', accent=AC),
      bg='Ascetic seekers of the age pursued liberation through renunciation and self-discipline. Mahavira embraced this path with exceptional rigour.',
      people='Mahavira the ascetic; the people and hardships he met on his wanderings; the fellow-seekers of the sramana tradition.',
      what='For about <b>twelve and a half years</b> Mahavira practised <b>severe austerity</b> — prolonged fasting, silence, deep meditation and exposure — enduring every hardship <b>calmly</b> while taking scrupulous care to <b>harm no living being</b>.',
      crux='He pursued liberation through <b>self-mastery and non-violence</b> carried to their utmost, conquering desire and aversion alike.',
      conseq='This long discipline prepared him for the breakthrough of omniscience.',
      matters='Mastery of the self is portrayed as the hardest conquest of all — Mahavira’s austerity became the model of Jain ascetic life.'),

    E('jina', 'the conquest', 'Conqueror of the self — “Jina” and “Mahavira”', ['FAITH', 'MEANING'],
      'Through his long discipline Vardhamana conquers the passions — desire, hatred, fear — that bind the soul to suffering, earning the titles by which he is remembered: Jina, “the conqueror” who gives Jainism its name, and Mahavira, “the great hero” whose victory is won not over armies but over himself.',
      svg_compare('Two kinds of conquest', {
          'head': 'The worldly conqueror', 'color': '#9a3412',
          'items': ['Wins power over others', 'Rules lands and armies', 'Bound still to desire and fear', 'Victory fades with fortune'],
      }, {
          'head': 'The inner conqueror (Jina)', 'color': '#166534',
          'items': ['Wins mastery over the self', 'Conquers desire, hatred, fear', 'Freed from the bonds of the soul', 'Victory is final and serene'],
      }, verdict='The Jain ideal exalts the conquest of the self above the conquest of the world.',
         takeaway='His was a victory over the passions within — the “great hero” who conquered himself, giving Jainism (“the path of the Jina”) its name.', accent=AC),
      bg='The Jain and wider Indian traditions prized <b>self-conquest</b> — mastery over the passions — as a higher victory than any won in the world.',
      people='<b>Vardhamana</b>, now the <b>Jina</b> and <b>Mahavira</b>; the tradition that would take its name from his title.',
      what='By subduing the passions of <b>desire, hatred and fear</b>, Vardhamana earned the titles <b>Jina</b> (“conqueror”), from which <b>Jainism</b> takes its name, and <b>Mahavira</b> (“great hero”) — the hero of an inward victory.',
      crux='The victory celebrated is <b>over the self</b>, not over others — the conquest of one’s own passions as the highest heroism.',
      conseq='Freed of the passions, he stood at the threshold of omniscience.',
      matters='A whole tradition can define greatness as self-mastery rather than domination — the hero who conquers himself.'),
]

# ==================================================================  PHASE 3 — ENLIGHTENMENT AND THE PATH
PHASE_ENLIGHT = [
    E('kevala', 'c. 557 BC · age 42', 'Kevala jnana — the dawn of omniscience', ['TURNING POINT', 'FAITH'],
      'After twelve and a half years of striving, seated in deep meditation under a sala tree on the bank of the Rijubalika river, Mahavira attains kevala jnana — the perfect, infinite knowledge of omniscience in which, the tradition holds, all things past, present and future are known, and the soul is fully liberated from ignorance.',
      svg_row('The breakthrough to perfect knowledge', [
          {'n': 1, 'label': 'Deep meditation', 'sub': 'under a sala tree by the Rijubalika', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Kevala jnana attained', 'sub': 'perfect, infinite knowledge dawns', 'color': '#a16207'},
          {'n': 3, 'label': 'A liberated omniscient', 'sub': 'a Kevalin, freed from ignorance', 'color': '#166534'},
      ], edge_labels=['yields', 'as'], takeaway='Under the sala tree his long striving bore fruit in kevala jnana — the omniscience that Jains hold to be perfect and complete knowledge.', accent=AC),
      bg='In Jain teaching, the soul’s innate infinite knowledge is obscured by karma; perfect discipline burns this away to reveal <b>kevala jnana</b>, omniscience.',
      people='Mahavira, now a <b>Kevalin</b> (omniscient one); the sala tree and Rijubalika river of the tradition’s account.',
      what='At about <b>age 42</b>, meditating <b>under a sala tree by the Rijubalika river</b>, Mahavira attained <b>kevala jnana</b> — the perfect omniscient knowledge that, in Jain belief, comprehends all reality and marks full liberation from ignorance.',
      crux='This is the <b>climax of the ascetic path</b> — the soul, cleansed of karmic obscuration, realising its own infinite knowledge.',
      conseq='As an omniscient teacher he now turned to guide others, proclaiming the path for the remaining thirty years of his life.',
      matters='The tradition frames enlightenment as the soul’s own light uncovered — knowledge already within, revealed by discipline rather than granted from without.'),

    E('vows', 'the teaching', 'The five great vows — a life of ahimsa', ['TEACHING', 'ETHICS'],
      'At the heart of Mahavira’s teaching stand the five great vows — the mahavratas — that shape the whole Jain ethical life: ahimsa (non-violence toward every living being), satya (truthfulness), asteya (not taking what is not given), brahmacharya (chastity), and aparigraha (non-attachment to possessions) — with ahimsa, non-violence, held supreme.',
      svg_stack('The five great vows (mahavratas)', [
          {'n': 1, 'label': 'Ahimsa — non-violence', 'sub': 'harm no living being; the supreme vow', 'color': '#166534'},
          {'n': 2, 'label': 'Satya · Asteya', 'sub': 'truthfulness; taking nothing not given', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Brahmacharya · Aparigraha', 'sub': 'chastity; non-attachment to possessions', 'color': '#a16207'},
      ], takeaway='Five vows govern the Jain life — with ahimsa, non-violence toward all beings, first and greatest among them.', accent=AC),
      bg='Mahavira gave the Jain ethical path its classic form in <b>five great vows</b> binding on ascetics, taken in gentler form by the laity.',
      people='Mahavira, the teacher; the monks and nuns who took the vows fully; the lay followers who took them in part.',
      what='Mahavira taught the <b>five great vows</b>: <b>ahimsa</b> (non-violence), <b>satya</b> (truth), <b>asteya</b> (non-stealing), <b>brahmacharya</b> (celibacy) and <b>aparigraha</b> (non-attachment) — with <b>ahimsa held supreme</b>, extended to every living being.',
      crux='The whole ethic radiates from <b>ahimsa</b> — a reverence for all life so complete that non-violence orders every other duty.',
      conseq='These vows became the enduring moral core of Jain life, monastic and lay alike.',
      matters='A single principle — non-violence toward all that lives — can anchor an entire ethical system and a way of life.'),

    E('anekanta', 'the philosophy', 'Anekantavada — the many-sidedness of truth', ['TEACHING', 'PHILOSOPHY'],
      'Mahavira teaches that reality is many-sided and truth complex: anekantavada, the doctrine that any thing may be viewed from many valid standpoints, and syadvada, the discipline of qualifying every assertion with “in some respect” — a philosophy of intellectual humility that no single view captures the whole truth.',
      svg_row('Truth has many sides', [
          {'n': 1, 'label': 'Anekantavada', 'sub': 'reality is many-sided; no one view is whole', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Syadvada', 'sub': '“in some respect” — qualified assertion', 'color': '#a16207'},
          {'n': 3, 'label': 'Intellectual humility', 'sub': 'many standpoints, each partly true', 'color': '#166534'},
      ], edge_labels=['expressed by', 'yielding'], takeaway='He taught that truth is many-sided — every claim conditional, no single viewpoint the whole — a striking doctrine of intellectual humility.', accent=AC),
      bg='Amid the many contending philosophies of his age, Mahavira offered a way to hold complexity without dogmatism.',
      people='Mahavira, the teacher; the rival schools whose one-sided claims his doctrine set in perspective.',
      what='Mahavira taught <b>anekantavada</b> — that reality has <b>many aspects</b> and no single viewpoint grasps it whole — and <b>syadvada</b>, the practice of qualifying assertions with “in some respect,” affirming truth as <b>conditional and many-sided</b>.',
      crux='He treated <b>dogmatic one-sidedness</b> as a kind of error — truth being too many-sided for any lone perspective to exhaust.',
      conseq='Anekantavada became a distinctive hallmark of Jain thought and a resource for tolerance and dialogue.',
      matters='A doctrine of many-sidedness models intellectual humility — the recognition that others may see a part of the truth we miss.'),
]

# ==================================================================  PHASE 4 — THE SANGHA
PHASE_SANGHA = [
    E('fourfold', 'the community', 'The fourfold sangha — a community of the path', ['COMMUNITY', 'ORGANISATION'],
      'Mahavira organises his followers into the chaturvidha sangha, the fourfold community that gives Jainism its enduring social form: monks (sadhus) and nuns (sadhvis) who take the great vows in full, and laymen (shravakas) and laywomen (shravikas) who support them and follow the vows in lesser measure — a whole society bound to the path.',
      svg_stack('The fourfold community', [
          {'n': 1, 'label': 'Monks and nuns', 'sub': 'sadhus and sadhvis take the vows in full', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Laymen and laywomen', 'sub': 'shravakas and shravikas follow in part', 'color': '#a16207'},
          {'n': 3, 'label': 'One bound community', 'sub': 'ascetics and laity sustain each other', 'color': '#166534'},
      ], takeaway='He wove his followers into a fourfold community of monks, nuns, laymen and laywomen — the social framework that carried Jainism across the centuries.', accent=AC),
      bg='To carry the teaching beyond his lifetime, Mahavira gave it an <b>organised community</b> rather than leaving it to scattered seekers.',
      people='the <b>monks (sadhus)</b> and <b>nuns (sadhvis)</b>; the <b>laymen (shravakas)</b> and <b>laywomen (shravikas)</b>; Mahavira, who bound them into one order.',
      what='Mahavira founded the <b>chaturvidha (fourfold) sangha</b> — monks, nuns, laymen and laywomen — the ascetics taking the great vows in full and the laity in lesser measure, forming a <b>single interdependent community</b>.',
      crux='He gave the path a <b>durable social structure</b> — a community in which ascetic and lay life sustained one another.',
      conseq='This organisation allowed Jainism to survive and transmit its teaching unbroken for over two millennia.',
      matters='A teaching endures when it is embodied in a community — organisation, not doctrine alone, carries a faith through the centuries.'),

    E('ganadharas', 'the disciples', 'The ganadharas — Indrabhuti Gautama and the chief disciples', ['COMMUNITY', 'LEGACY'],
      'Mahavira gathers eleven chief disciples, the ganadharas — learned brahmins won over to the path — foremost among them Indrabhuti Gautama, who becomes his principal disciple; it is they who receive, memorise and systematise his teachings, transmitting them to later generations as the basis of the Jain scriptures.',
      svg_row('Disciples who carried the teaching', [
          {'n': 1, 'label': 'Eleven ganadharas', 'sub': 'learned disciples, chiefs of the order', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Indrabhuti Gautama', 'sub': 'the foremost, his principal disciple', 'color': '#a16207'},
          {'n': 3, 'label': 'The teaching transmitted', 'sub': 'systematised into the scriptures', 'color': '#166534'},
      ], edge_labels=['led by', 'who'], takeaway='His eleven chief disciples, led by Indrabhuti Gautama, gathered and passed on his teaching — the human link to every later generation of Jains.', accent=AC),
      bg='A teacher’s words endure through disciples who preserve them. Mahavira drew <b>learned followers</b> capable of holding and ordering his teaching.',
      people='the <b>eleven ganadharas</b> (chief disciples); <b>Indrabhuti Gautama</b>, the foremost; the later teachers who inherited the transmission.',
      what='Mahavira’s <b>eleven ganadharas</b> — learned disciples who became heads of the order, led by <b>Indrabhuti Gautama</b> — <b>received, memorised and systematised his teachings</b>, forming the basis of the Jain scriptural tradition.',
      crux='The teaching passed through <b>trusted, learned disciples</b> — living vessels who ordered an oral teaching for posterity.',
      conseq='Through this transmission Mahavira’s words reached later generations and were eventually set down as scripture.',
      matters='Great teachings survive through disciples — the ganadharas are the bridge between Mahavira and every Jain who came after.'),

    E('women', 'the sangha', 'Chandanabala and the order of nuns', ['COMMUNITY', 'INCLUSION'],
      'Mahavira opens the ascetic path to women as fully as to men, ordaining an order of nuns led by Chandanabala; the tradition records that the women who joined his community far outnumbered the men — a striking openness that made the sangha of nuns and laywomen the larger part of his following.',
      svg_stack('An order open to women', [
          {'n': 1, 'label': 'Nuns led by Chandanabala', 'sub': 'the head of the order of sadhvis', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Women outnumber men', 'sub': 'tradition: far more nuns than monks', 'color': '#a16207'},
          {'n': 3, 'label': 'The path open to all', 'sub': 'renunciation offered to women fully', 'color': '#166534'},
      ], takeaway='He ordained an order of nuns under Chandanabala, and by tradition the women in his community outnumbered the men — a notable openness for his age.', accent=AC),
      bg='Mahavira admitted <b>women</b> to the renunciant life on the same path as men, an openness recorded prominently in the tradition.',
      people='<b>Chandanabala</b>, first and chief among the nuns; the many <b>sadhvis</b> and <b>laywomen</b> of the community; Mahavira, who ordained them.',
      what='Mahavira established an <b>order of nuns led by Chandanabala</b>, and the tradition records that his female followers — nuns and laywomen — <b>far outnumbered the men</b>, making women the larger part of his sangha.',
      crux='He extended the <b>full ascetic path to women</b>, a notable inclusiveness in the society of his time.',
      conseq='The order of nuns became, and remains, a central and numerous part of the Jain community.',
      matters='Openness to women within a demanding ascetic order marked Mahavira’s sangha and shaped Jainism’s enduring character.'),
]

# ==================================================================  PHASE 5 — MOKSHA AND LEGACY
PHASE_LEGACY = [
    E('buddha', 'the age', 'A contemporary of the Buddha — an age of seekers', ['CONTEXT', 'HISTORY'],
      'Mahavira lives in the same era as Gautama Buddha, amid a great ferment of the sramana movements — wandering seekers across the Ganges plain who, dissatisfied with the old ritual order, pursued liberation through renunciation, discipline and inner realisation; two of the age’s greatest teachers, offering distinct but parallel paths.',
      svg_compare('Two great teachers of one age', {
          'head': 'Mahavira (Jainism)', 'color': '#7c3aed',
          'items': ['24th Tirthankara of Jainism', 'Extreme ascetic self-discipline', 'Ahimsa and the five great vows', 'Anekantavada — many-sided truth'],
      }, {
          'head': 'The Buddha (Buddhism)', 'color': '#a16207',
          'items': ['Founder of the Buddhist path', 'The middle way between extremes', 'Four Noble Truths, Eightfold Path', 'Liberation from suffering (nirvana)'],
      }, verdict='Contemporaries of the sramana age, offering distinct but parallel paths to liberation.',
         takeaway='Mahavira and the Buddha taught in the same era and region — two towering figures of the sramana ferment, each with his own path.', accent=AC),
      bg='The sixth–fifth centuries BC saw a wave of <b>sramana</b> (renunciant) movements in the Ganges plain, seeking liberation outside the older ritual order.',
      people='<b>Mahavira</b> and <b>Gautama Buddha</b>, contemporaries; the wandering seekers and teachers of the age.',
      what='Mahavira was a <b>contemporary of the Buddha</b>, both teaching in the Ganges plain amid the <b>sramana movements</b> — offering <b>distinct but parallel paths</b> of renunciation and inner liberation.',
      crux='He was one of <b>two supreme teachers of a single age of seekers</b>, each shaping a lasting tradition of his own.',
      conseq='Jainism and Buddhism arose side by side, together reshaping the religious life of India.',
      matters='Great ages of thought can produce more than one master at once — Mahavira and the Buddha stand as twin summits of their era.'),

    E('moksha', 'c. 527 BC · Pavapuri', 'Moksha at Pavapuri — the final liberation', ['DEATH', 'FAITH'],
      'After some thirty years of teaching, Mahavira attains his final liberation — nirvana or moksha — at Pavapuri, his soul freed forever from the cycle of rebirth; the Jain tradition remembers the night of his passing with lamps, and links it to the festival of Diwali, kept ever since in his memory.',
      svg_row('The soul’s final release', [
          {'n': 1, 'label': 'Thirty years of teaching', 'sub': 'proclaiming the path across the region', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Moksha at Pavapuri', 'sub': 'final liberation from rebirth', 'color': '#a16207'},
          {'n': 3, 'label': 'Remembered at Diwali', 'sub': 'lamps mark the night of his passing', 'color': '#166534'},
      ], edge_labels=['end in', 'kept at'], takeaway='At Pavapuri his soul reached final liberation — a passing Jains commemorate at Diwali, with lamps for the light he left behind.', accent=AC),
      bg='Having taught for about thirty years after his enlightenment, Mahavira reached the end of his earthly life at <b>Pavapuri</b>.',
      people='Mahavira, at his final liberation; the disciples and community who mourned and honoured him; the Jains who keep his memory.',
      what='At about <b>527 BC</b> (Svetambara tradition), after some thirty years of teaching, Mahavira attained <b>moksha</b> — final liberation from rebirth — at <b>Pavapuri</b>; Jain tradition links the night of his passing to the festival of <b>Diwali</b>.',
      crux='His death is remembered not as an ending but as a <b>final liberation</b> — the soul’s release from the cycle of birth and death.',
      conseq='Pavapuri became a place of pilgrimage, and his passing an annual observance among Jains.',
      matters='A tradition can mark its founder’s death as a triumph — the soul’s liberation — and keep it in living memory with light.'),

    E('legacy', 'ever since', 'The enduring path — Mahavira’s legacy', ['LEGACY', 'INFLUENCE'],
      'The path Mahavira revived endures for more than two and a half millennia: Jainism preserves his teaching through its Digambara and Svetambara traditions, its ascetics and lay community; and above all his principle of ahimsa — non-violence toward all life — flows on through Indian thought, later inspiring figures such as Mahatma Gandhi.',
      svg_stack('A living tradition', [
          {'n': 1, 'label': 'Jainism endures', 'sub': 'Digambara and Svetambara traditions', 'color': '#7c3aed'},
          {'n': 2, 'label': 'A community of the vows', 'sub': 'ascetics and laity keep the path', 'color': '#a16207'},
          {'n': 3, 'label': 'Ahimsa lives on', 'sub': 'non-violence shaping later thought', 'color': '#166534'},
      ], takeaway='His revived path lives on in the Jain community — and his supreme principle of ahimsa flows through Indian thought to the present day.', accent=AC),
      bg='Mahavira’s teaching was carried forward by an organised community and, in time, by written scripture, dividing into the <b>Digambara</b> and <b>Svetambara</b> traditions.',
      people='the Jain community across the ages; later heirs of his ethic of non-violence, such as <b>Mahatma Gandhi</b>.',
      what='Mahavira’s revived path became <b>Jainism</b>, sustained for over 2,500 years through its <b>Digambara and Svetambara</b> traditions and its fourfold community; his principle of <b>ahimsa</b> profoundly shaped Indian thought and later figures like <b>Gandhi</b>.',
      crux='His deepest legacy is <b>ahimsa</b> — a reverence for all life that reached far beyond Jainism itself.',
      conseq='Jainism remains a living tradition, and non-violence a principle of enduring moral force.',
      matters='An idea can outlast every institution — Mahavira’s ahimsa became one of the great moral principles of human history.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Lord Mahavira (Vardhamana) is revered in Jainism as the twenty-fourth and last Tirthankara — the “ford-maker” who, in the tradition’s account, revived and gave classical form to an eternal path of non-violence and self-conquest. Born a prince of the Kshatriya Jnatrika clan near Vaishali, he renounced wealth and rank at about thirty, spent twelve and a half years in severe austerity, and attained kevala jnana, the perfect knowledge of omniscience. For some thirty years he taught the five great vows — with ahimsa, non-violence, supreme — and the doctrine of anekantavada, the many-sidedness of truth, organising a fourfold community of monks, nuns, laymen and laywomen before attaining final liberation at Pavapuri. He is a study in <b>renunciation, non-violence toward all life, and the conquest of the self.</b></p>
<div class="ov-quote">“Non-violence and kindness to living beings is kindness to oneself.”<span>— a teaching of the Jain tradition</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born a prince and revered as the 24th Tirthankara reviving an eternal path → he makes the Great Renunciation at about thirty → endures twelve and a half years of austerity, conquering the passions → attains kevala jnana, omniscience → teaches the five great vows and the many-sidedness of truth → gathers a fourfold community under disciples such as Indrabhuti Gautama → and attains final liberation at Pavapuri, remembered ever since at Diwali.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🕊️</div><h4>Ahimsa</h4><p>Non-violence toward every living being as the supreme principle.</p></div>
  <div class="ov-card"><div class="i">🪷</div><h4>Self-conquest</h4><p>The “great hero” whose victory was over his own passions.</p></div>
  <div class="ov-card"><div class="i">☯️</div><h4>Many-sided truth</h4><p>Anekantavada — intellectual humility before a complex reality.</p></div>
  <div class="ov-card"><div class="i">🤝</div><h4>A living community</h4><p>A fourfold sangha that carried the path for over two millennia.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Prince</b><small> c. 599 BC</small><p>Vardhamana, born to rank; the 24th Tirthankara.</p></div>
  <div><b>2 · The Great Renunciation</b><small> age 30+</small><p>Renunciation and twelve and a half years of austerity.</p></div>
  <div><b>3 · Enlightenment & Path</b><small> age 42+</small><p>Kevala jnana, the five vows, many-sided truth.</p></div>
  <div><b>4 · The Sangha</b><small> the community</small><p>Fourfold order, disciples, nuns under Chandanabala.</p></div>
  <div><b>5 · Moksha & Legacy</b><small> c. 527 BC</small><p>Pavapuri, Diwali, and the enduring path of ahimsa.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Traditional accounts and historical scholarship are noted evenly. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Parshvanatha', 'role': '23rd Tirthankara', 'color': '#7c3aed',
     'bio': 'The Tirthankara before Mahavira, whose teaching Mahavira’s own family followed and whose eternal path Mahavira revived and reformed.',
     'rel': 'His predecessor in the line of ford-makers, whose path he renewed.'},
    {'name': 'Indrabhuti Gautama', 'role': 'chief disciple', 'color': '#166534',
     'bio': 'A learned brahmin who became Mahavira’s foremost disciple and first ganadhara, receiving and systematising his teaching for later generations.',
     'rel': 'The principal disciple who transmitted the teaching.'},
    {'name': 'Trishala', 'role': 'his mother', 'color': '#a16207',
     'bio': 'Queen of the Jnatrika clan and mother of Vardhamana; a devout follower, with her husband, of the teaching of Parshvanatha.',
     'rel': 'The mother into whose devout royal house he was born.'},
    {'name': 'Chandanabala', 'role': 'head of the nuns', 'color': '#9d174d',
     'bio': 'The first and chief of Mahavira’s order of nuns (sadhvis), leading the female ascetics who, by tradition, outnumbered the monks.',
     'rel': 'The leader of the order of nuns he established.'},
    {'name': 'Gautama Buddha', 'role': 'contemporary', 'color': '#0e7490',
     'bio': 'The founder of Buddhism, a contemporary of Mahavira in the same Ganges plain, teaching a distinct but parallel path amid the sramana movements.',
     'rel': 'The other great teacher of his age and region.'},
]

KEY_EVENTS = [
    ('c. 599 BC', 'Birth of Vardhamana', 'A prince of the Jnatrika clan near Vaishali.'),
    ('c. 569 BC', 'The Great Renunciation', 'Renounces wealth and rank at about thirty.'),
    ('12.5 yrs', 'Years of austerity', 'Severe fasting, meditation and non-violence.'),
    ('c. 557 BC', 'Kevala jnana', 'Attains omniscience under a sala tree.'),
    ('the path', 'The five great vows', 'Ahimsa, satya, asteya, brahmacharya, aparigraha.'),
    ('the path', 'Anekantavada', 'The doctrine of many-sided truth.'),
    ('community', 'The fourfold sangha', 'Monks, nuns, laymen and laywomen.'),
    ('disciples', 'The ganadharas', 'Indrabhuti Gautama and the chief disciples.'),
    ('c. 527 BC', 'Moksha at Pavapuri', 'Final liberation; remembered at Diwali.'),
]

MASTER = [
    {'year': 'c. 599 BC', 'age': 'born', 'phase': 'The Prince', 'title': 'Born at Kundagrama', 'desc': 'Prince Vardhamana of the Jnatrika clan.'},
    {'year': 'c. 569 BC', 'age': 'age ~30', 'phase': 'Great Renunciation', 'title': 'Renounces the world', 'desc': 'Leaves palace for the ascetic path.'},
    {'year': 'c. 557 BC', 'age': 'age ~42', 'phase': 'Enlightenment', 'title': 'Kevala jnana', 'desc': 'Attains omniscience.'},
    {'year': 'the path', 'age': 'teaching', 'phase': 'The Sangha', 'title': 'The fourfold community', 'desc': 'Monks, nuns and laity organised.'},
    {'year': 'c. 527 BC', 'age': 'age ~72', 'phase': 'Moksha', 'title': 'Liberation at Pavapuri', 'desc': 'Final release; linked to Diwali.'},
    {'year': 'ever since', 'age': 'legacy', 'phase': 'Legacy', 'title': 'The path endures', 'desc': 'Jainism and the ideal of ahimsa.'},
]

SOURCES = [
    ('Britannica — Mahavira', 'https://www.britannica.com/biography/Mahavira'),
    ('World History Encyclopedia — Mahavira', 'https://www.worldhistory.org/Mahavira/'),
    ('Britannica — Jainism', 'https://www.britannica.com/topic/Jainism'),
    ('Britannica — Tirthankara', 'https://www.britannica.com/topic/Tirthankara'),
    ('Wikipedia — Mahavira', 'https://en.wikipedia.org/wiki/Mahavira'),
]

def build_meta():
    return {
        'pid': 'gm-mahavira.html', 'kind': 'man', 'emoji': '🙏', 'accent': AC,
        'name': 'Mahavira (Vardhamana)', 'years': 'c. 599–527 BC', 'group': 'Religious Founders',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The 24th and last Tirthankara of Jainism — a prince who renounced all to revive an eternal path of non-violence, self-conquest and the many-sidedness of truth.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'prince', 'label': '1 · The Prince', 'type': 'timeline',
             'intro': 'Revered as the 24th Tirthankara reviving an eternal teaching, Vardhamana is born a prince of the Jnatrika clan near Vaishali — living amid plenty yet inwardly detached.', 'events': PHASE_PRINCE},
            {'id': 'renounce', 'label': '2 · The Great Renunciation', 'type': 'timeline',
             'intro': 'At about thirty he gives up wealth and rank for the homeless ascetic life, enduring twelve and a half years of severe austerity and conquering the passions of the self.', 'events': PHASE_RENOUNCE},
            {'id': 'enlight', 'label': '3 · Enlightenment & Path', 'type': 'timeline',
             'intro': 'He attains kevala jnana, the omniscience that crowns the ascetic path, and teaches the five great vows of non-violence and the doctrine of the many-sidedness of truth.', 'events': PHASE_ENLIGHT},
            {'id': 'sangha', 'label': '4 · The Sangha', 'type': 'timeline',
             'intro': 'He organises a fourfold community of monks, nuns, laymen and laywomen, drawing chief disciples such as Indrabhuti Gautama and ordaining an order of nuns under Chandanabala.', 'events': PHASE_SANGHA},
            {'id': 'legacy', 'label': '5 · Moksha & Legacy', 'type': 'timeline',
             'intro': 'A contemporary of the Buddha, he attains final liberation at Pavapuri — remembered ever since at Diwali — leaving a living tradition and the enduring principle of ahimsa.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Traditional Jain accounts (Svetambara and Digambara) and encyclopaedic and scholarly sources; dates and biographical details follow tradition where scholarship is uncertain, and the two are noted evenly.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
