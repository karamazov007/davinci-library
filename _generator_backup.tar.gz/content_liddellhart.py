# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Basil Henry Liddell Hart.
The British theorist of mobility and the indirect approach — prophet of mechanised war, and its most disputed self-historian."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#4d532b'  # military olive drab

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE TRENCHES
PHASE_TRENCHES = [
    E('origins', '1895–1914', 'A parson’s son marches to war', ['RISE'],
      'Born in Paris in 1895 to an English Methodist minister, Basil Liddell Hart is a bookish, unmilitary young man when the Great War erupts — yet in August 1914 he volunteers at once, is commissioned into the King’s Own Yorkshire Light Infantry, and goes out to a Western Front that will shatter and remake him.',
      svg_row('An unmilitary man goes to the front', [
          {'n': 1, 'label': 'Born Paris, 1895', 'sub': 'son of an English Methodist minister', 'color': '#4d532b'},
          {'n': 2, 'label': 'Volunteers, August 1914', 'sub': 'commissioned into the KOYLI', 'color': '#a16207'},
          {'n': 3, 'label': 'Off to the Western Front', 'sub': 'a bookish youth meets industrial war', 'color': '#b91c1c'},
      ], edge_labels=['then', 'into'], takeaway='A studious parson’s son threw himself into the war of 1914 — and the trenches would forge the theorist he became.', accent=AC),
      bg='<b>Basil Henry Liddell Hart</b> was born in Paris in 1895 into the family of an English Methodist minister, a studious youth with no soldierly background.',
      people='his clergyman father; the <b>King’s Own Yorkshire Light Infantry</b> he joined; the volunteer generation of 1914.',
      what='On the outbreak of war in <b>August 1914</b> Liddell Hart volunteered and was commissioned into the <b>KOYLI</b>, going out to the Western Front as a young infantry officer.',
      crux='He entered the army not as a career soldier but as a <b>thinking amateur</b> — an outsider’s eye that would later question everything the professionals took for granted.',
      conseq='His brief front-line service would give him the searing experience from which all his later theory grew.',
      matters='The most radical critics of an institution often come from its edges — Liddell Hart met war as an outsider, and never stopped questioning it.'),

    E('somme', '1916', 'The Somme — wounded, gassed, and changed forever', ['TRAGEDY', 'TURNING POINT'],
      'On the Somme in 1916 Liddell Hart sees his battalion torn apart, is wounded, and on 19 July is badly gassed and evacuated for good — a trauma that haunts him for life and plants a lifelong horror of the slaughter of attritional trench warfare, the pointless frontal assault that feeds men into machine guns.',
      svg_stack('Attrition’s survivor turns against it', [
          {'n': 1, 'label': 'The Somme, July 1916', 'sub': 'his battalion is cut to pieces', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Wounded and gassed, 19 July', 'sub': 'evacuated permanently; trauma for life', 'color': '#78350f'},
          {'n': 3, 'label': 'A horror of attrition', 'sub': 'the frontal assault becomes his enemy', 'color': '#4d532b'},
      ], takeaway='He survived the meat-grinder of the Somme and spent the rest of his life trying to make sure no army fought that way again.', accent=AC),
      bg='In 1916 Liddell Hart fought on the <b>Somme</b>, where British infantry were massacred in frontal assaults against entrenched machine guns and artillery.',
      people='the men of his battalion, killed in droves; the generals whose attritional doctrine he came to despise.',
      what='On the Somme his battalion was devastated; Liddell Hart was wounded and, on <b>19 July 1916, badly gassed</b> and evacuated for good — an ordeal that scarred him physically and psychologically for life.',
      crux='He emerged with a <b>lifelong horror of attritional trench warfare</b> — the frontal assault that traded lives for yards, which he judged both barbaric and militarily bankrupt.',
      conseq='That revulsion became the driving force of his career: to find a way of war that won without the slaughter he had witnessed.',
      matters='Conviction is often born of trauma — the man who lived through the Somme devoted his life to making such battles unnecessary.'),

    E('lessons', '1918–1927', 'From the manuals to the writing desk', ['RISE', 'REFORM'],
      'Kept in the army after the war, Liddell Hart rewrites the infantry training manuals, sketches early ideas of battle drill and his “man-in-the-dark” theory of combat — but two heart attacks, lingering effects of the gassing, force him onto half-pay and then out of uniform in 1927, pushing him toward the pen that will make his name.',
      svg_row('The soldier becomes a writer', [
          {'n': 1, 'label': 'Rewrites the manuals', 'sub': 'infantry training, battle drill, “man-in-the-dark”', 'color': '#4d532b'},
          {'n': 2, 'label': 'Health broken by the war', 'sub': 'heart attacks; on half-pay from 1924', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Leaves the army, 1927', 'sub': 'turns fully to writing and theory', 'color': '#a16207'},
      ], edge_labels=['but', 'so'], takeaway='Forced out of uniform by his broken health, he found a far larger battlefield — the printed page.', accent=AC),
      bg='After 1918 Liddell Hart transferred to the <b>Royal Army Educational Corps</b> and worked on doctrine, distilling the war’s lessons into new training material.',
      people='the army establishment he was reforming from within; the wartime injuries that dogged his health.',
      what='He rewrote parts of the <b>Infantry Training</b> manual and developed early ideas of <b>battle drill</b> and his “man-in-the-dark” model of tactics, but <b>heart attacks</b> — linked to his gassing — put him on half-pay and forced <b>retirement in 1927</b>.',
      crux='Barred by ill health from a soldier’s career, he reinvented himself as a <b>military thinker and journalist</b> — influencing armies with words rather than command.',
      conseq='Free of the uniform, he could criticise the military establishment openly and build a public platform for his ideas.',
      matters='A closed door can open a wider one — losing his army career made Liddell Hart one of the most influential un-uniformed strategists of the century.'),
]

# ==================================================================  PHASE 2 — THE MILITARY PROPHET
PHASE_PROPHET = [
    E('journalist', '1924–1935', 'The most influential military pen in Britain', ['RISE', 'POLITICS'],
      'Liddell Hart becomes a celebrated military correspondent — for the Morning Post, then the Daily Telegraph — writing with a clarity and boldness that make him the best-known military commentator in Britain, a civilian critic whose verdicts on strategy generals cannot ignore.',
      svg_stack('Building a public platform', [
          {'n': 1, 'label': 'Correspondent, Morning Post', 'sub': 'writes on tactics — and on tennis at Wimbledon', 'color': '#a16207'},
          {'n': 2, 'label': 'Daily Telegraph, 1925–35', 'sub': 'Britain’s leading military commentator', 'color': '#4d532b'},
          {'n': 3, 'label': 'A civilian voice generals heed', 'sub': 'clear, bold, widely read verdicts on war', 'color': '#166534'},
      ], takeaway='From outside the army he built an authority few insiders could match — the pen became his command.', accent=AC),
      bg='From 1924 Liddell Hart wrote for the <b>Morning Post</b> and, from 1925, the <b>Daily Telegraph</b>, quickly becoming Britain’s most prominent military journalist.',
      people='the editors who prized his prose; the serving officers who read and resented him; his rival theorist <b>J. F. C. Fuller</b>.',
      what='As <b>military correspondent</b> for the Morning Post and then the Daily Telegraph (1925–35), he wrote lucid, provocative analysis that made him the <b>best-known military commentator in Britain</b>.',
      crux='He wielded <b>influence through publicity</b> — shaping opinion and prodding the army from the outside, without holding any command.',
      conseq='This platform carried his theories of mobility and the indirect approach to a wide public and, eventually, to men in power.',
      matters='Ideas need a megaphone — Liddell Hart’s journalism turned private theory into national debate about how Britain should fight.'),

    E('indirect', '1925–1929', 'The indirect approach — victory without slaughter', ['REFORM', 'TURNING POINT'],
      'Studying history for the pattern the Somme had denied him, Liddell Hart formulates his central idea: the “indirect approach.” Rather than smashing head-on into an enemy’s strength, the wise commander dislocates him — striking where he is unbalanced, unhinging his mind and rear by manoeuvre, speed and surprise before a shot need be fired.',
      svg_compare('Two ways to seek victory', {
          'head': 'The direct approach', 'color': '#b91c1c', 'items': [
              'Frontal assault on the enemy’s strength',
              'Battles of attrition; lives traded for ground',
              'The bloody logic of the Somme',
              'Costly even in victory',
          ]}, {
          'head': 'The indirect approach', 'color': '#166534', 'items': [
              'Strike where the enemy is unbalanced',
              'Dislocate mind, rear and morale first',
              'Speed, surprise and manoeuvre over mass',
              'Win before the killing begins',
          ]},
      verdict='The aim is to unbalance the enemy so the battle is half-won before it is joined.',
      takeaway='He turned his horror of the frontal assault into a doctrine — win by dislocation, not destruction.', accent=AC),
      bg='Ranging across military history, Liddell Hart sought the common thread of decisive victories — and found it in the avoidance of head-on collision.',
      people='the great captains he studied (Scipio, Sherman, Napoleon at his best); the attritional generals he wrote against.',
      what='He formulated the <b>“indirect approach”</b>: instead of attacking an enemy’s strength head-on, dislocate him by <b>manoeuvre, mobility and surprise</b> — striking where he is unbalanced and unhinging his rear and morale.',
      crux='He argued that <b>psychological and physical dislocation</b>, not brute attrition, is the true path to victory — the line of least expectation.',
      conseq='The idea became the spine of his whole body of work, expounded most fully in his book <b>Strategy</b>.',
      matters='The indirect approach reframed strategy as an art of dislocation — one of the most cited ideas in modern military thought.'),

    E('armour', '1925–1935', 'Prophet of the tank and the mobile war', ['REFORM', 'BATTLE'],
      'Seizing on the tank as the answer to the trench, Liddell Hart champions mechanised, armoured warfare and mobility — from his 1925 vision in “Paris, or the Future of War” to ideas of fast armoured divisions, “tank marines” riding into battle, and an “expanding torrent” of penetration that pours through a broken front rather than grinding against it.',
      svg_row('Machines to break the deadlock', [
          {'n': 1, 'label': '“Paris, or the Future of War”, 1925', 'sub': 'a new mobile way of war', 'color': '#4d532b'},
          {'n': 2, 'label': 'Armour, speed, deep penetration', 'sub': 'fast tank divisions; “tank marines”', 'color': '#a16207'},
          {'n': 3, 'label': 'The “expanding torrent”', 'sub': 'pour through the gap, not against the wall', 'color': '#166534'},
      ], edge_labels=['into', 'as'], takeaway='He saw in the tank the escape from the trenches — mobility and penetration in place of attrition.', accent=AC),
      bg='The static horror of 1914–18 convinced Liddell Hart that <b>mobility</b>, restored by the tank, was the way out of the deadlock of the trenches.',
      people='fellow armour prophet <b>J. F. C. Fuller</b>; the cavalry-minded traditionalists who resisted mechanisation; motorised infantry he dubbed “tank marines”.',
      what='In <b>“Paris, or the Future of War” (1925)</b> and later writings he championed <b>mechanised, armoured warfare</b> — fast tank divisions, combined arms, and an <b>“expanding torrent”</b> of penetration flooding through a broken front.',
      crux='He insisted the future belonged to <b>mobility and deep penetration by armour</b>, not to the trench line and the set-piece battle of attrition.',
      conseq='These ideas — overlapping with Fuller’s and with continental thinking — anticipated much of the armoured warfare of the coming war.',
      matters='He was among the earliest and clearest prophets of mechanised war — though who learned what from whom would become fiercely disputed.'),
]

# ==================================================================  PHASE 3 — INFLUENCE AND POWER
PHASE_INFLUENCE = [
    E('thetimes', '1935–1937', 'At the height — “the Captain who teaches Generals”', ['POLITICS', 'TRIUMPH'],
      'Moving to The Times in 1935, Liddell Hart reaches the peak of his authority — a military oracle whose columns are read in cabinet rooms and general staffs alike, the civilian theorist who, in a later quip, is “the Captain who teaches Generals.”',
      svg_stack('The oracle of British strategy', [
          {'n': 1, 'label': 'Joins The Times, 1935', 'sub': 'the nation’s paper of record', 'color': '#4d532b'},
          {'n': 2, 'label': 'Read at the summit', 'sub': 'cabinet, War Office and general staff take note', 'color': '#a16207'},
          {'n': 3, 'label': '“The Captain who teaches Generals”', 'sub': 'a civilian at the peak of influence', 'color': '#166534'},
      ], takeaway='By the mid-1930s a former captain, invalided out, was shaping how Britain thought about its next war.', accent=AC),
      bg='In <b>1935</b> Liddell Hart moved to <b>The Times</b>, the most authoritative newspaper in Britain, at the height of his fame and influence.',
      people='the editors and ministers who sought his views; the generals who bristled at a civilian’s tutelage; later admirers who coined the “Captain who teaches Generals” phrase.',
      what='As military correspondent of <b>The Times (1935–39)</b> he reached the <b>peak of his authority</b>, his analysis read and weighed at the highest levels of government and the army.',
      crux='He had turned journalism into <b>real strategic influence</b> — an unofficial adviser to the nation on how it should prepare for war.',
      conseq='This standing brought him, briefly, into the corridors of power beside the Secretary of State for War.',
      matters='Reputation is leverage — at his zenith Liddell Hart could move policy with a column, a rare reach for any writer.'),

    E('horebelisha', '1937–1938', 'Whispering to the War Minister', ['POLITICS', 'REFORM'],
      'For a heady spell in 1937–38 Liddell Hart becomes the unofficial, confidential adviser to Leslie Hore-Belisha, the reforming Secretary of State for War — feeding him schemes to modernise and mechanise the army, an outsider suddenly shaping policy from the minister’s ear.',
      svg_row('An adviser behind the minister', [
          {'n': 1, 'label': 'Hore-Belisha at the War Office', 'sub': 'a reforming Secretary of State for War', 'color': '#a16207'},
          {'n': 2, 'label': 'Liddell Hart his confidant', 'sub': 'unofficial adviser, 1937–38', 'color': '#4d532b'},
          {'n': 3, 'label': 'Schemes to modernise the army', 'sub': 'mechanisation and reorganisation', 'color': '#166534'},
      ], edge_labels=['takes', 'to push'], takeaway='For a moment the theorist sat at the minister’s elbow, translating ideas into army policy.', accent=AC),
      bg='<b>Leslie Hore-Belisha</b>, appointed <b>Secretary of State for War in 1937</b>, wanted to shake up a hidebound army — and turned to Liddell Hart for ideas.',
      people='<b>Hore-Belisha</b>, the energetic war minister; the senior generals who resented the civilian intruder; Prime Minister <b>Neville Chamberlain</b>, whose government he advised.',
      what='In <b>1937–38</b> Liddell Hart became Hore-Belisha’s <b>unofficial, close adviser</b>, supplying schemes for <b>army reorganisation and mechanisation</b> and shaping reform from behind the scenes.',
      crux='He briefly enjoyed <b>direct access to power</b> — his theories translated into actual War Office policy.',
      conseq='The arrangement bred resentment among the generals and could not last; his fall from favour soon followed.',
      matters='Influence at court is fragile — an outsider whispering to the minister makes enemies of the establishment he bypasses.'),

    E('blitzkrieg', '1930s', 'His ideas and the birth of blitzkrieg', ['REFORM', 'BATTLE'],
      'Liddell Hart’s pre-war writings on armour and penetration circulate in Germany as its officers build the panzer arm — and after the war several will credit him with influencing their thinking. Yet the extent of that influence is genuinely disputed, and Liddell Hart’s own hand in promoting the claim would later come under sharp scrutiny.',
      svg_stack('An anticipation — and a contested claim', [
          {'n': 1, 'label': 'Pre-war writings on armour', 'sub': 'penetration, mobility, the mechanised division', 'color': '#4d532b'},
          {'n': 2, 'label': 'Germany builds its panzers', 'sub': 'Guderian and others develop the panzer arm', 'color': '#a16207'},
          {'n': 3, 'label': 'Influence — but how much?', 'sub': 'genuinely disputed; the claim itself contested', 'color': '#b91c1c'},
      ], takeaway='His ideas plainly anticipated blitzkrieg — but the size of his direct influence on the Germans remains an open, contested question.', accent=AC),
      bg='As Germany rebuilt its army in the 1930s and developed the <b>panzer division</b>, foreign theorists of armour — Liddell Hart and Fuller among them — were read and debated abroad.',
      people='<b>Heinz Guderian</b> and the German panzer pioneers; <b>J. F. C. Fuller</b>, the other British armour prophet; later historians who weighed the influence.',
      what='Liddell Hart’s <b>writings on mobile armoured warfare</b> anticipated key elements of what became <b>blitzkrieg</b>, and some German generals later credited him — though the <b>real extent of his influence is disputed</b>, and how the claim arose is contested.',
      crux='The honest verdict sits <b>between two poles</b>: he was a genuine prophet of armoured war, yet the direct German debt to him is far less certain than the legend suggests.',
      conseq='The question would flare into open controversy after 1945, when captured German generals and Liddell Hart himself shaped the story.',
      matters='Attributing the paternity of an idea is treacherous — parallel thinkers, national doctrines and self-interested memory all muddy the record.'),
]

# ==================================================================  PHASE 4 — THE FALL
PHASE_FALL = [
    E('limitedliability', '1936–1939', 'Air power, “limited liability,” and appeasement’s shadow', ['POLITICS', 'TRAGEDY'],
      'As war looms, Liddell Hart argues that Britain should lean on the Royal Air Force and naval power rather than send a great army to bleed on the Continent again — a doctrine of “limited liability” that chimes with Chamberlain and appeasement, and that his critics brand as defeatist as the danger grows.',
      svg_compare('How should Britain prepare?', {
          'head': 'Liddell Hart’s “limited liability”', 'color': '#4d532b', 'items': [
              'Rely on the RAF and the Royal Navy',
              'Avoid a mass continental army',
              'Defence favours the defender',
              'Spare Britain another Somme',
          ]}, {
          'head': 'The case against', 'color': '#b91c1c', 'items': [
              'A continental commitment may be unavoidable',
              'Allies need British troops on the ground',
              'Reads as pessimism — even appeasement',
              'Poland 1939 forces a mass army after all',
          ]},
      verdict='His horror of another bloodbath shaded into a pessimism that events would overtake.',
      takeaway='The lesson of the Somme — spare the infantry — hardened into a doctrine that looked like defeatism as war neared.', accent=AC),
      bg='Through the late 1930s Liddell Hart argued in <b>The Times</b> that Britain should avoid a large continental army and rely on <b>air and sea power</b> — a policy of “limited liability.”',
      people='<b>Neville Chamberlain</b>, whose government found the argument congenial; critics who saw defeatism; the Somme generation he wished to spare.',
      what='He pressed the doctrine of <b>“limited liability”</b> — leaning on the RAF and navy rather than a mass army — a view aligned with <b>appeasement</b> and increasingly attacked as <b>pessimistic and defeatist</b>.',
      crux='His deep dread of another attritional slaughter shaded into a <b>strategic pessimism</b> that the coming war would render obsolete.',
      conseq='When Germany invaded Poland in 1939, Britain committed to a continental army after all — and his stock fell sharply.',
      matters='A hard-won lesson can become a blind spot — Liddell Hart’s wisdom about attrition curdled into a misjudgement about the coming war.'),

    E('fall', '1938–1940', 'Out of favour on the eve of war', ['DEFEAT', 'TURNING POINT'],
      'His influence collapses as fast as it rose: the generals close ranks, his tie to Hore-Belisha frays, his pessimism jars with a nation girding for war, and by 1939 Liddell Hart has left The Times — sidelined and out of favour just as the war he had theorised about for twenty years breaks over Europe.',
      svg_stack('The prophet cast aside', [
          {'n': 1, 'label': 'The establishment recoils', 'sub': 'generals resent the civilian oracle', 'color': '#b91c1c'},
          {'n': 2, 'label': 'His pessimism jars', 'sub': 'out of step with a nation arming for war', 'color': '#78350f'},
          {'n': 3, 'label': 'Leaves The Times, 1939', 'sub': 'sidelined as the war he foresaw begins', 'color': '#4d532b'},
      ], takeaway='At the very moment his subject arrived, the great theorist found himself pushed to the margins.', accent=AC),
      bg='By the late 1930s Liddell Hart’s brief ascendancy was crumbling under establishment resentment and the poor fit of his ideas with a rearming Britain.',
      people='the hostile senior generals; <b>Hore-Belisha</b>, himself soon forced from office; the wartime leadership that had little use for him.',
      what='His influence <b>collapsed</b>: the army establishment shut him out, his link to Hore-Belisha frayed, his pessimism grated, and he <b>left The Times in 1939</b>, sidelined as war began.',
      crux='The very traits that made him influential — his outsider status and contrarian judgement — now left him <b>isolated and discredited</b> when war came.',
      conseq='He spent the war years largely on the outside, writing history rather than shaping strategy.',
      matters='Reputations rise and fall on timing — the theorist of mobile war was benched precisely when mobile war arrived.'),

    E('vindication', '1940', 'Vindicated by the enemy in the fall of France', ['BATTLE', 'TRAGEDY'],
      'In 1940 the German panzers pour through the Ardennes and shatter France in six weeks — a lightning campaign of armour, speed and deep penetration that looks like the very war Liddell Hart had preached for two decades, now unleashed by the enemy while he sits ignored at home.',
      svg_row('His doctrine, in enemy hands', [
          {'n': 1, 'label': 'Panzers through the Ardennes', 'sub': 'armour, speed, deep penetration', 'color': '#b91c1c'},
          {'n': 2, 'label': 'France falls in six weeks', 'sub': 'blitzkrieg shatters the Allied front, 1940', 'color': '#78350f'},
          {'n': 3, 'label': 'The mobile war he foresaw', 'sub': 'vindicated — by the wrong side', 'color': '#4d532b'},
      ], edge_labels=['brings', 'echoing'], takeaway='The war of movement he had championed arrived at last — driven by German tanks, while its British prophet looked on ignored.', accent=AC),
      bg='In May–June 1940 Germany’s <b>armoured spearheads</b> broke through the Ardennes and overran France in a matter of weeks, stunning the Allied armies.',
      people='<b>Guderian</b> and the panzer commanders; the shattered French army; Liddell Hart, watching from the sidelines in Britain.',
      what='The <b>fall of France (1940)</b> was a triumph of <b>armour, speed and deep penetration</b> — strikingly like the mobile, indirect warfare Liddell Hart had advocated for twenty years, now waged by the enemy.',
      crux='The bitter irony was complete: his ideas seemed <b>vindicated by the Wehrmacht</b> just as his own country had cast him aside.',
      conseq='After the war, this apparent vindication became the foundation of his rehabilitation — and of the disputed blitzkrieg-influence claim.',
      matters='A prophet can be proved right and still go unheeded — and vindication by an enemy is a double-edged sword.'),
]

# ==================================================================  PHASE 5 — REHABILITATION AND LEGACY
PHASE_LEGACY = [
    E('otherside', '1945–1948', '“The Other Side of the Hill” — the generals talk', ['TRIUMPH', 'REFORM'],
      'After the war Liddell Hart interviews captured German generals in captivity and turns their testimony into “The Other Side of the Hill” (1948) — a landmark of history from the enemy’s viewpoint. In these pages several officers credit his pre-war writings, beginning his rehabilitation and the blitzkrieg story that would later be questioned.',
      svg_stack('History from the enemy’s side', [
          {'n': 1, 'label': 'Interviews captured German generals', 'sub': 'debriefs the men who ran the war', 'color': '#4d532b'},
          {'n': 2, 'label': '“The Other Side of the Hill”, 1948', 'sub': 'the war seen from the German command', 'color': '#a16207'},
          {'n': 3, 'label': 'Generals credit his influence', 'sub': 'his rehabilitation begins', 'color': '#166534'},
      ], takeaway='By giving the defeated enemy a voice, he wrote a landmark history — and began rebuilding his own reputation.', accent=AC),
      bg='With Germany defeated, its senior commanders sat in Allied captivity, and Liddell Hart set out to <b>interview them</b> about how they had fought the war.',
      people='the captured <b>German generals</b> he questioned; readers hungry for the enemy’s account; the publishers of his post-war histories.',
      what='He published <b>“The Other Side of the Hill” (1948)</b> — the war told from the German high command — in which several generals <b>credited his pre-war ideas</b>, beginning his post-war rehabilitation.',
      crux='He pioneered <b>history from the loser’s perspective</b>, a genuine scholarly contribution that also, conveniently, burnished his own record.',
      conseq='The generals’ tributes fed a narrative of his decisive influence on blitzkrieg — one historians would soon scrutinise.',
      matters='The victors write history, but the vanquished can reshape it — and the historian who collects their words holds great power over the record.'),

    E('selfpromotion', '1948–1953', 'The reputation game — did he write his own legend?', ['POLITICS', 'TRAGEDY'],
      'Liddell Hart’s post-war rehabilitation raises an uncomfortable question. Historians such as John Mearsheimer charge that he cultivated the German generals — and even coaxed Rommel’s widow — to magnify his influence and rebuild a battered reputation. Defenders, and scholars like Jay Luvaas, answer that he sincerely overestimated an influence that was real if smaller than claimed.',
      svg_compare('Prophet or self-promoter?', {
          'head': 'The critics (Mearsheimer, Naveh)', 'color': '#b91c1c', 'items': [
              'He “put words in the generals’ mouths”',
              'Coaxed Rommel’s widow to add flattering lines',
              'Rebuilt a reputation damaged before 1940',
              'Retrospectively “created” the blitzkrieg story',
          ]}, {
          'head': 'The defence (Luvaas, others)', 'color': '#166534', 'items': [
              'His anticipation of armoured war was genuine',
              'He sincerely overestimated his own influence',
              'The generals had reasons of their own to credit him',
              'A real if smaller debt, honestly misjudged',
          ]},
      verdict='Somewhere between self-made legend and genuine prophet lies the contested truth.',
      takeaway='The debate is not whether he shaped his own legend, but how far — and how knowingly.', accent=AC),
      bg='As his fame revived, questions arose about how far Liddell Hart had <b>engineered his own rehabilitation</b> through his post-war contacts and writings.',
      people='the critic <b>John Mearsheimer</b>; the theorist <b>Shimon Naveh</b>; the sympathetic historian <b>Jay Luvaas</b>; <b>Rommel</b>’s widow, whom he corresponded with over <b>The Rommel Papers</b> (1953).',
      what='Critics charge he <b>cultivated German generals — and Rommel’s widow — to inflate his influence</b> and mend his reputation; defenders reply that his anticipation of armoured war was <b>real</b> and that he <b>sincerely overestimated</b>, rather than invented, his role.',
      crux='The controversy turns on <b>motive and degree</b> — genuine prophet, self-serving myth-maker, or a sincere man who honestly mistook the size of his own shadow.',
      conseq='Historians still weigh his legacy against this charge, presenting the blitzkrieg-influence claim with caution.',
      matters='Even great thinkers curate their legends — the self-historian must be read as sceptically as any other source.'),

    E('legacy', '1954–1970', '“Strategy,” a knighthood, and the final word', ['TRIUMPH', 'DEATH'],
      'Rehabilitated and revered, Liddell Hart crowns his life with “Strategy” (1954), the fullest statement of the indirect approach; is knighted in 1966; is hailed by admirers as “the Captain who teaches Generals”; and dies in 1970, leaving one of the most influential — and most debated — bodies of military thought of the century.',
      svg_row('The theorist enters the pantheon', [
          {'n': 1, 'label': '“Strategy”, 1954', 'sub': 'the indirect approach, fully argued', 'color': '#4d532b'},
          {'n': 2, 'label': 'Knighted, 1966', 'sub': 'honours and worldwide renown', 'color': '#a16207'},
          {'n': 3, 'label': 'Dies 1970', 'sub': 'an influential — and contested — legacy', 'color': '#166534'},
      ], edge_labels=['then', 'leaving'], takeaway='He ended as an honoured sage of strategy — his ideas enduring, his self-history forever debated.', accent=AC),
      bg='In his final decades Liddell Hart wrote prolifically on strategy and history, his reputation restored and his ideas taught in war colleges around the world.',
      people='the statesmen and soldiers who read him (admirers even quoted him as “the Captain who teaches Generals”); the historians who both revere and question him.',
      what='He published <b>“Strategy” (1954)</b>, the definitive exposition of the <b>indirect approach</b>; was made a <b>Knight Bachelor in 1966</b>; and <b>died in 1970</b>, leaving a vast and influential body of military thought.',
      crux='His enduring legacy is twofold — a <b>genuinely influential theory of mobility and dislocation</b>, shadowed by lasting doubts about how he told his own story.',
      conseq='His papers formed the Liddell Hart Centre for Military Archives, and his ideas still shape doctrines of manoeuvre warfare.',
      matters='A thinker can be both indispensable and unreliable about himself — Liddell Hart’s ideas outlived the controversies over his legend.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Basil Henry Liddell Hart was the twentieth century’s most influential — and most disputed — theorist of mobile warfare. Gassed and scarred on the Somme, he spent his life in revolt against the frontal assault, preaching the <b>indirect approach</b> and the war of armour, speed and dislocation. As a civilian journalist he became Britain’s military oracle, briefly advised a War Minister, then fell from favour for a pessimism that shaded into appeasement — only to see his ideas seemingly vindicated by the German blitzkrieg of 1940. Rehabilitated after the war through his interviews with captured German generals, he remains a study in <b>the power of ideas, the perils of self-promotion, and how a thinker writes his own legend.</b></p>
<div class="ov-quote">“The profoundest truth of war is that the issue of battle is usually decided in the minds of the opposing commanders, not in the bodies of their men.”<span>— B. H. Liddell Hart</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Gassed on the Somme, he turns against attrition → builds a platform as Britain’s leading military writer → formulates the indirect approach and champions the tank → advises War Minister Hore-Belisha at the height of his fame → falls from favour for “limited liability” and pessimism → watches the German blitzkrieg vindicate his ideas in 1940 → and is rehabilitated after the war through the generals’ testimony, amid lasting debate over how far he wrote his own legend.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">♟️</div><h4>The indirect approach</h4><p>Win by dislocating the enemy’s balance, not smashing his strength.</p></div>
  <div class="ov-card"><div class="i">⚙️</div><h4>Prophet of mobility</h4><p>Championed armour, speed and penetration against the trench.</p></div>
  <div class="ov-card"><div class="i">🗣️</div><h4>Ideas as power</h4><p>A civilian pen that shaped how a nation thought about war.</p></div>
  <div class="ov-card"><div class="i">🔍</div><h4>The self-made legend</h4><p>A cautionary case in how thinkers curate their own history.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Trenches</b><small> 1895–1927</small><p>The Somme, gassing, and a horror of attrition.</p></div>
  <div><b>2 · The Military Prophet</b><small> 1924–1935</small><p>Journalist, the indirect approach, the tank.</p></div>
  <div><b>3 · Influence & Power</b><small> 1935–1938</small><p>The Times, Hore-Belisha, and the blitzkrieg question.</p></div>
  <div><b>4 · The Fall</b><small> 1936–1940</small><p>“Limited liability,” disgrace, and enemy vindication.</p></div>
  <div><b>5 · Rehabilitation & Legacy</b><small> 1945–1970</small><p>The generals talk; “Strategy”; a knighthood; the debate.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'J. F. C. Fuller', 'role': 'fellow armour prophet', 'color': '#4d532b',
     'bio': 'The other great British theorist of tank warfare, whose ideas ran parallel to — and sometimes ahead of — Liddell Hart’s advocacy of mechanised war.',
     'rel': 'His rival and counterpart in preaching the mobile, armoured war.'},
    {'name': 'Leslie Hore-Belisha', 'role': 'the War Minister he advised', 'color': '#a16207',
     'bio': 'The reforming Secretary of State for War (1937) who took Liddell Hart as his unofficial adviser, giving the theorist a brief taste of real power.',
     'rel': 'The minister whose ear he held at the height of his influence.'},
    {'name': 'Heinz Guderian', 'role': 'German panzer pioneer', 'color': '#b91c1c',
     'bio': 'The architect of Germany’s panzer arm, later said to have credited Liddell Hart’s ideas — a claim central to the disputed blitzkrieg-influence story.',
     'rel': 'The general at the heart of the contested blitzkrieg-credit claim.'},
    {'name': 'John Mearsheimer', 'role': 'his sharpest critic', 'color': '#78350f',
     'bio': 'The political scientist whose biography charged that Liddell Hart cultivated the German generals to inflate his influence and rebuild his reputation.',
     'rel': 'The scholar who most forcefully questioned his self-promotion.'},
    {'name': 'Erwin Rommel', 'role': 'subject of his history', 'color': '#166534',
     'bio': 'The German field marshal whose papers Liddell Hart edited; his handling of the Rommel material became a flashpoint in the self-promotion debate.',
     'rel': 'The commander whose legend, and his own, Liddell Hart helped shape.'},
]

KEY_EVENTS = [
    ('1895', 'Liddell Hart born', 'In Paris, son of a Methodist minister.'),
    ('1914', 'Volunteers for war', 'Commissioned into the KOYLI.'),
    ('1916', 'Gassed on the Somme', 'A lifelong horror of attrition.'),
    ('1925', 'Paris, or the Future of War', 'Prophet of the mobile, armoured war.'),
    ('1935', 'Joins The Times', 'At the height of his influence.'),
    ('1937–38', 'Advises Hore-Belisha', 'Unofficial adviser to the War Minister.'),
    ('1939', 'Leaves The Times', 'Out of favour as war begins.'),
    ('1940', 'Blitzkrieg in France', 'His ideas vindicated by the enemy.'),
    ('1948', 'The Other Side of the Hill', 'The German generals talk.'),
    ('1966', 'Knighted', 'Rehabilitated; dies 1970.'),
]

MASTER = [
    {'year': '1895', 'age': 'born', 'phase': 'The Trenches', 'title': 'Born in Paris', 'desc': 'A parson’s son.'},
    {'year': '1916', 'age': 'age 20', 'phase': 'The Trenches', 'title': 'Gassed on the Somme', 'desc': 'Turns against attrition.'},
    {'year': '1925', 'age': 'age 29', 'phase': 'The Military Prophet', 'title': 'Future of War', 'desc': 'Prophet of mobility.'},
    {'year': '1935', 'age': 'age 39', 'phase': 'Influence & Power', 'title': 'Joins The Times', 'desc': 'Peak of influence.'},
    {'year': '1940', 'age': 'age 44', 'phase': 'The Fall', 'title': 'Blitzkrieg in France', 'desc': 'Vindicated by the enemy.'},
    {'year': '1966', 'age': 'age 70', 'phase': 'Rehabilitation & Legacy', 'title': 'Knighthood', 'desc': 'Honoured; dies 1970.'},
]

SOURCES = [
    ('Wikipedia — B. H. Liddell Hart', 'https://en.wikipedia.org/wiki/B._H._Liddell_Hart'),
    ('Britannica — B. H. Liddell Hart', 'https://www.britannica.com/biography/B-H-Liddell-Hart'),
    ('Wikipedia — Indirect approach', 'https://en.wikipedia.org/wiki/Indirect_approach'),
    ('Wikipedia — Strategy (Liddell Hart book)', 'https://en.wikipedia.org/wiki/Strategy_(Liddell_Hart_book)'),
    ('Liddell Hart Centre for Military Archives, King’s College London', 'https://www.kcl.ac.uk/lhcma'),
]

def build_meta():
    return {
        'pid': 'gm-liddellhart.html', 'kind': 'man', 'emoji': '🎖️', 'accent': AC,
        'name': 'B. H. Liddell Hart', 'years': '1895–1970', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The British theorist of mobility and the indirect approach — gassed on the Somme, prophet of armoured war, and the most disputed self-historian of the blitzkrieg age.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'trenches', 'label': '1 · The Trenches', 'type': 'timeline',
             'intro': 'A bookish parson’s son volunteers in 1914, is wounded and gassed on the Somme, and emerges with a lifelong horror of attritional trench warfare that drives all his later thought.', 'events': PHASE_TRENCHES},
            {'id': 'prophet', 'label': '2 · The Military Prophet', 'type': 'timeline',
             'intro': 'Forced out of the army, he becomes Britain’s leading military journalist and formulates his great ideas — the indirect approach and the mobile, armoured war of the future.', 'events': PHASE_PROPHET},
            {'id': 'influence', 'label': '3 · Influence & Power', 'type': 'timeline',
             'intro': 'At the height of his fame at The Times, he advises War Minister Hore-Belisha — and his ideas circulate as Germany builds the panzer arm, raising the disputed question of his influence on blitzkrieg.', 'events': PHASE_INFLUENCE},
            {'id': 'fall', 'label': '4 · The Fall', 'type': 'timeline',
             'intro': 'His doctrine of “limited liability,” shading into pessimism and appeasement, costs him his standing on the eve of war — and then the German blitzkrieg of 1940 seems to vindicate him while he sits ignored.', 'events': PHASE_FALL},
            {'id': 'legacy', 'label': '5 · Rehabilitation & Legacy', 'type': 'timeline',
             'intro': 'After the war he interviews captured German generals, is rehabilitated and knighted, and leaves an enduring body of strategic thought — shadowed by lasting debate over how far he wrote his own legend.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; the blitzkrieg-influence claim and the charge of self-promotion are matters of genuine historical debate and are presented here as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
