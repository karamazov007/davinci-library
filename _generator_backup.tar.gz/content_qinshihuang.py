# -*- coding: utf-8 -*-
"""Full, DEEP birth-to-death guide content for Qin Shi Huang, First Emperor of China.
The Legalist unifier who forged China — and whose empire died within a few years of him."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#1f2937'  # Qin black (their dynastic colour)

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE KING OF QIN
PHASE_RISE = [
    E('hostage', '259–246 BC', 'Born a hostage’s son — and a merchant’s gamble', ['RISE', 'POLITICS'],
      'The future First Emperor is born Ying Zheng in the enemy state of Zhao, where his father is a minor Qin prince held as a hostage — and his path to the throne is engineered by a rich merchant, Lü Buwei, who backs the obscure prince as a calculated investment in power.',
      svg_stack('A throne arranged by a merchant', [
          {'n': 1, 'label': 'Born in Zhao, 259 BC', 'sub': 'son of a Qin prince held hostage in an enemy state', 'color': '#1f2937'},
          {'n': 2, 'label': 'Lü Buwei’s investment', 'sub': 'a merchant bankrolls the obscure prince’s rise', 'color': '#a16207'},
          {'n': 3, 'label': 'The prince becomes king', 'sub': 'the gamble pays off — the family gains the throne', 'color': '#166534'},
      ], takeaway='His rise began as a rich merchant’s speculation on an obscure prince — power as an investment.', accent=AC),
      bg='In the <b>Warring States</b> era, China was divided among rival kingdoms. <b>Ying Zheng</b> was born in 259 BC in <b>Zhao</b>, where his father was a hostage-prince of <b>Qin</b>.',
      people='<b>Lü Buwei</b>, the wealthy merchant-strategist who financed the family’s rise; his father, the hostage prince; his mother, once Lü Buwei’s concubine.',
      what='Ying Zheng’s father was an unregarded Qin prince until <b>Lü Buwei</b> bankrolled his advancement as a political investment. The family gained the Qin throne, and Ying Zheng became <b>King of Qin in 246 BC</b>, aged about 13.',
      crux='His ascent was <b>engineered by wealth and calculation</b>, not birthright alone — the merchant Lü Buwei treated a prince as an asset.',
      conseq='A boy-king inherited the most powerful of the warring states, with Lü Buwei as regent and power behind the throne.',
      matters='Power is often manufactured by those who back the right outsider early — the merchant’s gamble made an emperor.'),

    E('laoai', '238 BC', 'Crushing a coup — seizing full power', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'As the young king comes of age, a palace scandal explodes: his mother’s lover Lao Ai, granted power and titles, launches an armed rebellion — and Ying Zheng crushes it ruthlessly, executing the conspirators, purging his mother’s faction, and soon forcing out even the regent Lü Buwei, taking total control himself.',
      svg_row('The king takes the reins by force', [
          {'n': 1, 'label': 'The Lao Ai affair', 'sub': 'the queen mother’s lover gains power and plots', 'color': '#a16207'},
          {'n': 2, 'label': 'Armed rebellion, 238 BC', 'sub': 'Lao Ai revolts as the king comes of age', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Ruthless purge', 'sub': 'Lao Ai executed; Lü Buwei ousted; the king rules alone', 'color': '#1f2937'},
      ], edge_labels=['then', 'so'], takeaway='He announced his character early — crushing a coup and purging even his own backers to rule alone.', accent=AC),
      bg='As Ying Zheng approached adulthood, his mother’s favourite <b>Lao Ai</b> had amassed power and titles and feared the king’s coming majority.',
      people='<b>Lao Ai</b>, the rebel favourite; the <b>queen mother</b>, whose faction was purged; <b>Lü Buwei</b>, the regent soon forced out.',
      what='In 238 BC <b>Lao Ai launched a revolt</b>. Ying Zheng <b>crushed it</b>, had Lao Ai executed (by tearing apart) and his faction destroyed, confined his mother, and within two years <b>forced Lü Buwei from power</b> (who later killed himself) — taking sole control.',
      crux='He demonstrated at the outset a willingness to use <b>total ruthlessness against anyone</b>, including his mother’s circle and his own patron.',
      conseq='Now in full command of Qin’s formidable state, he turned to the conquest of all China.',
      matters='The ruthless consolidation of power at home comes first — a ruler who cannot control his own court cannot conquer a world.'),

    E('legalism', '246–221 BC', 'The Legalist machine — Li Si and the state as a weapon', ['REFORM', 'POLITICS'],
      'Qin’s terrifying strength rests on Legalism — a cold philosophy of strict laws, harsh punishments, rewards for farming and war, and total subordination of the individual to the state — refined by the chancellor Li Si into a ruthless engine for conquest that no rival kingdom can match.',
      svg_stack('A philosophy built for total power', [
          {'n': 1, 'label': 'Legalism', 'sub': 'strict law, harsh punishment, reward for war and farming', 'color': '#1f2937'},
          {'n': 2, 'label': 'Li Si, the chancellor', 'sub': 'sharpens the Legalist state into a conquest machine', 'color': '#a16207'},
          {'n': 3, 'label': 'The individual subordinated', 'sub': 'everything organised for the power of the state', 'color': '#b91c1c'},
      ], takeaway='Qin out-competed every rival by making the state itself a ruthless, all-consuming machine for war and control.', accent=AC),
      bg='For over a century, Qin had followed <b>Legalism</b> — the doctrine of the reformer <b>Shang Yang</b> — organising society entirely around law, punishment, agriculture and war.',
      people='<b>Li Si</b>, the brilliant, ruthless chancellor; the Legalist philosophers; the officials who ran the machine.',
      what='Under Ying Zheng and <b>Li Si</b>, Qin perfected the <b>Legalist state</b>: rigid laws, collective punishment, rewards tied to battlefield and farm output, and the subordination of everything to state power — a system built for conquest.',
      crux='He wielded a <b>philosophy engineered for total mobilisation</b> — Legalism made Qin a war-machine that the other states, softer and divided, could not resist.',
      conseq='This machine allowed Qin to conquer the six rival kingdoms in a single decade.',
      matters='Ideas shape power — a doctrine that organises an entire society for one purpose can overwhelm looser, freer rivals.'),
]

# ==================================================================  PHASE 2 — THE CONQUEST
PHASE_CONQUER = [
    E('jingke', '227 BC', 'The dagger in the map — surviving assassination', ['BATTLE', 'POLITICS', 'TRAGEDY'],
      'As Qin devours its neighbours, the desperate state of Yan sends the assassin Jing Ke to kill the king — hiding a poisoned dagger inside a rolled map presented as tribute — and in a famous scene of a chase around the throne pillars, Ying Zheng narrowly survives, and Yan is doomed in revenge.',
      svg_row('The most famous assassination attempt in Chinese history', [
          {'n': 1, 'label': 'Yan sends Jing Ke', 'sub': 'a desperate bid to stop Qin’s conquest', 'color': '#a16207'},
          {'n': 2, 'label': 'A dagger in the map', 'sub': 'a poisoned blade hidden in a tribute map', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The king escapes', 'sub': 'survives the attack; Yan is destroyed in reprisal', 'color': '#1f2937'},
      ], edge_labels=['then', 'so'], takeaway='He survived the age’s most famous assassination attempt — and answered it by annihilating the state behind it.', accent=AC),
      bg='By 227 BC Qin’s conquests terrified the remaining states. The kingdom of <b>Yan</b> plotted to kill the king before it was swallowed.',
      people='<b>Jing Ke</b>, the assassin; the Yan prince <b>Dan</b>, who sent him; Ying Zheng, who narrowly survived.',
      what='<b>Jing Ke</b> approached with a <b>poisoned dagger concealed in a rolled map</b>. When he struck, the king fled around the pillars, drew his own long sword, and killed the assassin — then <b>destroyed Yan</b> in revenge.',
      crux='He met the ultimate threat and survived by nerve — and turned the attempt into a justification for <b>total destruction of his enemy</b>.',
      conseq='The failed assassination hardened his ruthlessness and his lifelong fear of death — later feeding his obsession with immortality.',
      matters='Surviving an attempt on your life can harden a ruler — brushes with death shaped his character and his fears.'),

    E('unification', '230–221 BC', 'Ten years, six kingdoms — the first unification of China', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'In a single relentless decade, the armies of Qin conquer the six rival kingdoms one by one — Han, Zhao, Wei, Chu, Yan, and finally Qi — ending centuries of warfare and, in 221 BC, uniting China under one ruler for the first time in its history.',
      svg_stack('Swallowing the warring states', [
          {'n': 1, 'label': 'Han, Zhao, Wei fall', 'sub': 'the nearer states conquered, 230–225 BC', 'color': '#1f2937'},
          {'n': 2, 'label': 'Chu, Yan destroyed', 'sub': 'the great southern and northern states crushed', 'color': '#a16207'},
          {'n': 3, 'label': 'Qi surrenders, 221 BC', 'sub': 'the last kingdom falls; China is unified', 'color': '#166534'},
      ], takeaway='In ten years he ended centuries of division — conquering all rivals and uniting China for the first time.', accent=AC),
      bg='For centuries China had been divided among warring kingdoms. Qin, the strongest, set out under Ying Zheng to conquer them all.',
      people='the six conquered states — <b>Han, Zhao, Wei, Chu, Yan, Qi</b>; the Qin generals (Wang Jian and others); Li Si, directing strategy.',
      what='Between <b>230 and 221 BC</b> Qin conquered the six rival kingdoms in turn, ending with <b>Qi in 221 BC</b> — completing the <b>first unification of China</b> and ending the Warring States period.',
      crux='He achieved what no one had before — <b>welding the whole Chinese world into one state</b> by relentless, systematic conquest.',
      conseq='Ying Zheng now ruled a united China and set about remaking it, taking a title no one had held.',
      matters='Some achievements redraw the map of civilisation — the unification of China created a political entity that endures to this day.'),
]

# ==================================================================  PHASE 3 — THE FIRST EMPEROR
PHASE_EMPEROR = [
    E('firstemperor', '221 BC', 'A new title for a new kind of ruler', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'Deciding that “king” is no longer adequate, Ying Zheng invents a grander title — Shi Huangdi, “First Emperor” — and declares that his dynasty will rule for ten thousand generations, founding the imperial system that would govern China for the next two thousand years.',
      svg_row('Inventing the office of Emperor', [
          {'n': 1, 'label': '“King” is not enough', 'sub': 'no existing title fits the ruler of all China', 'color': '#1f2937'},
          {'n': 2, 'label': 'Shi Huangdi — First Emperor', 'sub': 'a new supreme title combining ancient god-king words', 'color': '#a16207'},
          {'n': 3, 'label': '“Ten thousand generations”', 'sub': 'a dynasty meant to last forever', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='He created the very office of Chinese emperor — a title and system that outlasted his dynasty by millennia.', accent=AC),
      bg='Having united China, Ying Zheng felt the title <b>“king” (wang)</b> — shared by the rulers he had conquered — was beneath him.',
      people='<b>Li Si</b> and the court, who devised the new title; the officials of the new imperial administration.',
      what='He took the title <b>Shi Huangdi</b> (“First August Emperor”), combining words for legendary sage-kings and gods, and proclaimed his line would rule for <b>“ten thousand generations.”</b> He founded the <b>imperial system</b> of China.',
      crux='He didn’t just rule — he <b>invented a new kind of sovereignty</b>, the emperorship, that would frame Chinese government for over 2,000 years.',
      conseq='Every later Chinese emperor, down to 1912, ruled in the office he created — though his own dynasty lasted only fifteen years.',
      matters='The greatest founders create institutions that outlive them — the office of emperor endured for two millennia.'),

    E('standardize', '221–210 BC', 'One China — one script, one measure, one coin', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'To fuse a patchwork of conquered kingdoms into a single nation, the First Emperor imposes uniformity on everything — one writing system, one currency, one set of weights and measures, even a standard axle-width so carts fit the same ruts — binding China together in ways that survive to this day.',
      svg_stack('Forging unity by standardisation', [
          {'n': 1, 'label': 'One script', 'sub': 'a single writing system across all China', 'color': '#1f2937'},
          {'n': 2, 'label': 'One currency, weights & measures', 'sub': 'the round Qin coin; standard units everywhere', 'color': '#a16207'},
          {'n': 3, 'label': 'Even standard axle-widths', 'sub': 'carts fit the same road-ruts nationwide', 'color': '#166534'},
      ], takeaway='He made a nation out of conquests by standardising the very tools of daily life — writing, money, measurement.', accent=AC),
      bg='The conquered kingdoms had used <b>different scripts, coins, weights and measures</b> — a barrier to unity and control.',
      people='<b>Li Si</b>, who oversaw the standardisation (including the script reform); the merchants, scholars and officials across China.',
      what='The First Emperor <b>standardised the writing system</b>, <b>currency</b> (the round coin with a square hole), <b>weights and measures</b>, and even <b>cart axle-widths</b> — imposing uniformity that helped bind China into one civilisation.',
      crux='He understood that <b>true unity is infrastructural</b> — a shared script and shared measures knit a country together more deeply than any conquest.',
      conseq='The standardised script in particular gave China a lasting cultural unity across its many spoken languages.',
      matters='Nations are forged by common standards as much as common rule — shared writing and measures outlast any dynasty.'),

    E('centralize', '221 BC', 'Abolishing the old order — 36 commanderies', ['REFORM', 'POLITICS', 'TURNING POINT'],
      'The First Emperor destroys the feudal system root and branch — abolishing hereditary lords, dividing China into 36 centrally-governed commanderies run by appointed, dismissible officials, moving the old aristocracy to his capital under his eye, and melting down the empire’s weapons to disarm the population.',
      svg_row('Replacing feudal lords with a bureaucracy', [
          {'n': 1, 'label': 'Abolish hereditary lords', 'sub': 'no more feudal aristocracy with their own lands', 'color': '#1f2937'},
          {'n': 2, 'label': '36 commanderies', 'sub': 'appointed, dismissible officials govern each region', 'color': '#a16207'},
          {'n': 3, 'label': 'Disarm and relocate', 'sub': 'weapons melted down; the old elite moved to the capital', 'color': '#b91c1c'},
      ], edge_labels=['then', 'and'], takeaway='He replaced a thousand years of feudalism with a centralised bureaucracy answerable only to him.', accent=AC),
      bg='China had been ruled through <b>hereditary feudal lords</b>. The First Emperor saw them as rival power centres to be destroyed.',
      people='the dispossessed aristocracy, relocated to the capital <b>Xianyang</b>; the appointed governors of the new commanderies; Li Si.',
      what='He <b>abolished feudalism</b>, divided China into <b>36 commanderies</b> under appointed, salaried, dismissible officials, <b>relocated the old aristocratic families</b> to the capital, and <b>confiscated and melted down weapons</b> (cast into bells and statues) to disarm the population.',
      crux='He built a <b>centralised bureaucratic empire</b>, concentrating all power in the throne and stripping regional lords of any independent base.',
      conseq='The centralised, bureaucratic model of governance he created became the template for imperial China for two millennia.',
      matters='Lasting central power means destroying rival centres — replacing hereditary lords with appointed, removable officials.'),

    E('walls', '221–210 BC', 'Walls, roads and canals — building on the backs of millions', ['REFORM', 'TRIUMPH', 'TRAGEDY'],
      'The First Emperor binds and defends his empire with colossal public works — a vast network of roads, a canal linking China’s river systems, and the connection of northern frontier walls into an early Great Wall against the Xiongnu nomads — all built by forced labour on a scale that costs countless lives.',
      svg_stack('Empire built by forced labour', [
          {'n': 1, 'label': 'The Great Wall begun', 'sub': 'General Meng Tian links northern walls vs the Xiongnu', 'color': '#1f2937'},
          {'n': 2, 'label': 'Roads and the Lingqu canal', 'sub': 'a national road net; a canal joining river systems', 'color': '#a16207'},
          {'n': 3, 'label': 'Countless dead', 'sub': 'hundreds of thousands of conscripts perish', 'color': '#b91c1c'},
      ], takeaway='He physically bound and defended China with works of staggering scale — and staggering human cost.', accent=AC),
      bg='To defend and integrate the empire, the First Emperor launched vast <b>infrastructure projects</b> using enormous levies of forced labour.',
      people='General <b>Meng Tian</b>, who drove back the Xiongnu and built the frontier wall; the hundreds of thousands of conscripted labourers; the Xiongnu nomads.',
      what='He built a <b>national road network</b>, the <b>Lingqu canal</b> linking major river systems, and connected existing northern walls into an early <b>Great Wall</b> against the <b>Xiongnu</b> — all through mass forced labour that killed vast numbers.',
      crux='He integrated and defended the empire through <b>public works of unprecedented scale</b> — at a human cost that fed deep resentment.',
      conseq='The works bound China together but the brutal labour demands helped provoke the revolts that destroyed his dynasty.',
      matters='Great infrastructure can unify a nation — but built on forced labour and cruelty, it can also sow the seeds of collapse.'),
]

# ==================================================================  PHASE 4 — CONTROL AND OBSESSION
PHASE_CONTROL = [
    E('bookburning', '213–212 BC', 'Burning the books, burying the scholars', ['POLITICS', 'TRAGEDY', 'TURNING POINT'],
      'To crush dissent and erase rival ideas, the First Emperor and Li Si order the burning of books — histories and philosophy that might inspire criticism — and, by tradition, the burying alive of scholars who defy him, one of history’s most infamous acts of intellectual repression.',
      svg_stack('War on ideas and memory', [
          {'n': 1, 'label': 'Burn the books, 213 BC', 'sub': 'histories and philosophy destroyed; only practical texts spared', 'color': '#1f2937'},
          {'n': 2, 'label': 'Bury the scholars, 212 BC', 'sub': 'by tradition, hundreds of scholars executed', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Control the past & thought', 'sub': 'erase rival ideas and the memory of the old states', 'color': '#78350f'},
      ], takeaway='He tried to control not just the empire but the minds within it — erasing the ideas and history that could inspire resistance.', accent=AC),
      bg='Confucian and other scholars looked back to the old feudal order and criticised Legalist rule. The First Emperor and <b>Li Si</b> moved to silence them.',
      people='<b>Li Si</b>, who proposed the burning; the Confucian and other scholars targeted; the historians whose records were destroyed.',
      what='In <b>213 BC</b> the regime ordered the <b>burning of books</b> — histories, poetry and philosophy (sparing practical texts like medicine and agriculture) — and, by the traditional account, in <b>212 BC buried alive some 460 scholars</b> who opposed him.',
      crux='He sought <b>total control over thought and memory</b>, destroying the intellectual inheritance that might legitimise resistance.',
      conseq='The acts made him a byword for tyranny in later (especially Confucian) tradition — though the scale is debated by historians.',
      matters='Tyranny reaches for the mind as well as the body — controlling ideas and history is the deepest form of domination.'),

    E('terracotta', '246–210 BC', 'An army for eternity — the tomb and the terracotta legions', ['REFORM', 'TRIUMPH', 'TRAGEDY'],
      'From the moment he took the throne, the First Emperor builds a tomb of staggering scale at Mount Li — guarded, it is said, by rivers of mercury and by an underground army of thousands of individually-crafted, life-sized terracotta soldiers, the greatest funerary complex ever attempted, built by perhaps 700,000 labourers.',
      svg_stack('Power projected into the afterlife', [
          {'n': 1, 'label': 'A tomb-city at Mount Li', 'sub': 'begun at his accession; ~700,000 labourers', 'color': '#1f2937'},
          {'n': 2, 'label': 'The Terracotta Army', 'sub': 'thousands of unique life-sized clay soldiers to guard him', 'color': '#a16207'},
          {'n': 3, 'label': 'Rivers of mercury', 'sub': 'a model empire with flowing mercury “rivers,” per the histories', 'color': '#166534'},
      ], takeaway='He built an entire underground empire to rule in death as he had in life — a monument of unmatched scale.', accent=AC),
      bg='The First Emperor devoted enormous resources to his <b>mausoleum</b> near modern Xi’an from the start of his reign, intending to command in the afterlife.',
      people='the ~700,000 conscripted labourers; the craftsmen of the terracotta figures; the historian Sima Qian, who described the tomb’s mercury rivers.',
      what='His tomb complex at <b>Mount Li</b> included a buried <b>army of thousands of unique, life-sized terracotta warriors</b> (rediscovered in 1974) and, according to the histories, a scale model of the empire with <b>rivers of mercury</b> — built by an estimated <b>700,000 workers</b>.',
      crux='He extended his <b>will to control into eternity itself</b> — a funerary project of a scale no ruler had ever attempted.',
      conseq='The Terracotta Army, unearthed in 1974, became one of the greatest archaeological discoveries in history and a symbol of his power.',
      matters='The scale of a ruler’s monuments reveals the scale of their ambition — his reached past death into eternity.'),
]

# ==================================================================  PHASE 5 — DEATH AND COLLAPSE
PHASE_FALL = [
    E('immortality', '219–210 BC', 'The hunt for immortality — poisoned by his own cure', ['POLITICS', 'TRAGEDY'],
      'Terrified of death, the First Emperor becomes obsessed with finding an elixir of immortality — dispatching expeditions to seek magic islands, patronising alchemists, and consuming “medicines” containing mercury that historians believe may have slowly poisoned and killed the very man they were meant to make eternal.',
      svg_stack('Chasing eternal life to an early grave', [
          {'n': 1, 'label': 'Obsessed with immortality', 'sub': 'terrified of death after assassination attempts', 'color': '#1f2937'},
          {'n': 2, 'label': 'Expeditions and alchemists', 'sub': 'Xu Fu sent to find the islands of the immortals', 'color': '#a16207'},
          {'n': 3, 'label': 'Mercury “elixirs”', 'sub': 'immortality pills that may have hastened his death', 'color': '#b91c1c'},
      ], takeaway='The most powerful man in the world could not command the one thing he wanted — and his cure may have killed him.', accent=AC),
      bg='Having survived assassination and holding absolute power, the First Emperor came to dread the one thing he could not conquer: <b>death</b>.',
      people='the alchemist <b>Xu Fu</b>, sent with hundreds of youths to find the elixir (and never returning); the court magicians; his physicians.',
      what='He funded <b>expeditions</b> (famously Xu Fu’s voyage to find the “islands of the immortals”) and consumed <b>alchemical elixirs containing mercury</b> — which historians suspect <b>slowly poisoned him</b>.',
      crux='His absolute power ran into an absolute limit — <b>mortality</b> — and his frantic remedies may have hastened the end.',
      conseq='He died on tour in 210 BC, still seeking the elixir; the empire’s fate hung on how his death was handled.',
      matters='No power can buy immortality — and the desperate pursuit of it can destroy the very life it seeks to preserve.'),

    E('death', '210 BC', 'Death on the road — and the rotting-fish cover-up', ['DEATH', 'POLITICS', 'TRAGEDY'],
      'The First Emperor dies suddenly while touring the east — and his death is hidden by two conspirators, the eunuch Zhao Gao and the chancellor Li Si, who conceal the rotting corpse with carts of salted fish, forge his will to install a weak younger son, and order the rightful heir and the great general Meng Tian to kill themselves.',
      svg_stack('A death turned into a coup', [
          {'n': 1, 'label': 'Dies on tour, 210 BC', 'sub': 'sudden death far from the capital', 'color': '#1f2937'},
          {'n': 2, 'label': 'Death concealed', 'sub': 'Zhao Gao & Li Si mask the corpse’s smell with salted fish', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The succession forged', 'sub': 'the heir Fusu and general Meng Tian forced to suicide', 'color': '#78350f'},
      ], takeaway='His empire, built on his person, was hijacked the instant he died — by a forged will and a hidden corpse.', accent=AC),
      bg='The First Emperor died suddenly during an <b>inspection tour of the east</b> in 210 BC, far from the capital, with the succession unsettled.',
      people='the eunuch <b>Zhao Gao</b> and chancellor <b>Li Si</b>, the conspirators; the rightful heir <b>Fusu</b> and general <b>Meng Tian</b>, forced to die; the weak younger son <b>Huhai</b>.',
      what='<b>Zhao Gao and Li Si concealed the death</b> — masking the decomposing body with <b>carts of salted fish</b> — <b>forged the will</b> to enthrone the pliable <b>Huhai</b>, and ordered the capable heir <b>Fusu</b> and general <b>Meng Tian to commit suicide</b>.',
      crux='An empire resting on <b>one man’s absolute person</b> was seized the moment he died — by those closest to him.',
      conseq='The weak Second Emperor and the scheming Zhao Gao presided over rapid misrule and terror.',
      matters='Absolute personal power is fatally fragile at the moment of death — with no institutions of succession, it is stolen instantly.'),

    E('collapse', '210–206 BC', 'Ten thousand generations — that lasted fifteen years', ['POLITICS', 'TRAGEDY', 'TURNING POINT'],
      'The dynasty meant to rule for ten thousand generations collapses within four years of the First Emperor’s death — as harsh Legalist rule, forced labour and the murderous intrigues of Zhao Gao spark mass rebellion, and the Qin is swept away, replaced by the Han, whose founder rises from a peasant rebel.',
      svg_row('The paradox of the First Emperor', [
          {'n': 1, 'label': 'Misrule and terror', 'sub': 'Second Emperor and Zhao Gao; brutal Legalism continues', 'color': '#1f2937'},
          {'n': 2, 'label': 'Mass rebellion, 209 BC', 'sub': 'Chen Sheng’s revolt ignites the empire', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Qin falls; Han rises', 'sub': 'the dynasty gone by 206 BC; the Han founder a former peasant', 'color': '#166534'},
      ], edge_labels=['sparks', 'then'], takeaway='The empire built to last forever died in fifteen years — but the unified China it created endured for two millennia.', accent=AC),
      bg='After the First Emperor’s death, the harshness of Qin rule, crushing labour demands, and the deadly intrigues of <b>Zhao Gao</b> pushed the empire toward revolt.',
      people='the rebel <b>Chen Sheng</b>, who lit the fuse; <b>Zhao Gao</b>, whose terror destroyed the court; <b>Liu Bang</b>, the peasant-rebel who founded the Han.',
      what='Rebellion erupted in <b>209 BC</b> (Chen Sheng’s revolt); amid misrule and Zhao Gao’s murders, the <b>Qin dynasty collapsed by 206 BC</b>, replaced after further war by the <b>Han dynasty</b> under the former peasant <b>Liu Bang</b>.',
      crux='The great paradox: the dynasty meant to last <b>“ten thousand generations” lasted about fifteen years</b> — yet the unified, centralised China it forged endured for over two thousand.',
      conseq='The Han kept the First Emperor’s unified, centralised empire while softening its harshness — the model of China ever after.',
      matters='A creation can far outlive its creator’s dynasty — Qin Shi Huang’s empire fell fast, but the China he forged is still here.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Qin Shi Huang forged China. In a single decade his Legalist war-machine conquered the six warring kingdoms and united the Chinese world for the first time; he then invented the office of emperor, standardised the script, currency and measures, abolished feudalism for a centralised bureaucracy, began the Great Wall, and built the Terracotta Army to guard him in eternity. Terrified of death, he chased an immortality elixir that may have killed him — and the dynasty he meant to last ten thousand generations collapsed within fifteen years, even as the unified China he created endured for two millennia. He is the ultimate study in <b>ruthless unification, power built for control, and the fragility of personal empire against the permanence of institutions.</b></p>
<div class="ov-quote">A dynasty for “ten thousand generations” — that lasted fifteen years.<span>— the paradox of the First Emperor</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born a hostage’s son and made king by a merchant’s gamble → crushes a coup to rule alone → wields the Legalist machine to conquer the six kingdoms → survives Jing Ke’s dagger → unites China in 221 BC and invents the title of Emperor → standardises script, coin and measures, abolishes feudalism, builds roads, canal and the Great Wall → burns the books and buries the scholars → raises the Terracotta Army for his tomb → chases immortality and is perhaps poisoned by its elixir → dies on tour, his death hidden with salted fish and his succession forged → and his eternal empire collapses within four years.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🀄</div><h4>He forged China</h4><p>United the warring states into one civilisation-state that still exists.</p></div>
  <div class="ov-card"><div class="i">👑</div><h4>Invented the Emperor</h4><p>Created the imperial office and centralised bureaucracy that ruled China for 2,000 years.</p></div>
  <div class="ov-card"><div class="i">🧱</div><h4>Standardised a nation</h4><p>One script, one coin, one measure — the infrastructure of unity.</p></div>
  <div class="ov-card"><div class="i">⏳</div><h4>The fragile eternal</h4><p>The “ten thousand generation” dynasty fell in fifteen years — but China endured.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The King of Qin</b><small> 259–221 BC</small><p>A merchant’s gamble, a crushed coup, the Legalist machine.</p></div>
  <div><b>2 · The Conquest</b><small> 230–221 BC</small><p>Surviving the dagger; uniting China in a decade.</p></div>
  <div><b>3 · The First Emperor</b><small> 221–210 BC</small><p>The imperial title, standardisation, walls and roads.</p></div>
  <div><b>4 · Control & Obsession</b><small> 213–210 BC</small><p>Burning books, the Terracotta Army.</p></div>
  <div><b>5 · Death & Collapse</b><small> 210–206 BC</small><p>Immortality, the cover-up, and the fall of Qin.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Li Si', 'role': 'chancellor', 'color': '#a16207',
     'bio': 'The brilliant, ruthless Legalist chancellor who guided the conquest, engineered the standardisation of China, proposed the burning of books — and later joined the fatal succession plot.',
     'rel': 'The mastermind minister behind unification and reform.'},
    {'name': 'Lü Buwei', 'role': 'merchant-regent', 'color': '#166534',
     'bio': 'The wealthy merchant who financed the family’s rise to the Qin throne and served as regent, before being forced out by the young king he had helped make.',
     'rel': 'The merchant whose gamble made him king — then was discarded.'},
    {'name': 'Zhao Gao', 'role': 'eunuch conspirator', 'color': '#b91c1c',
     'bio': 'The scheming eunuch who, with Li Si, concealed the Emperor’s death, forged the succession, and whose subsequent terror helped destroy the dynasty within years.',
     'rel': 'The plotter whose intrigues doomed the empire after the Emperor’s death.'},
    {'name': 'Meng Tian', 'role': 'general', 'color': '#334155',
     'bio': 'The great Qin general who drove back the Xiongnu and built the frontier Great Wall — forced to commit suicide by the forged succession after the Emperor’s death.',
     'rel': 'The general who built the Wall and died to the coup.'},
    {'name': 'Jing Ke', 'role': 'assassin', 'color': '#78350f',
     'bio': 'The assassin sent by the state of Yan, who hid a poisoned dagger in a map and nearly killed the king in 221’s most famous attempt — and failed.',
     'rel': 'The assassin whose failed attempt hardened the Emperor.'},
]

KEY_EVENTS = [
    ('259 BC', 'Ying Zheng born', 'In Zhao, son of a Qin hostage-prince.'),
    ('246 BC', 'King of Qin', 'Takes the throne at about 13.'),
    ('238 BC', 'Crushes the Lao Ai revolt', 'Seizes full personal power.'),
    ('227 BC', 'Jing Ke’s assassination attempt', 'The dagger in the map; survives.'),
    ('221 BC', 'Unifies China', 'Conquers the last state; becomes First Emperor.'),
    ('221 BC', 'Standardisation & 36 commanderies', 'One script, coin, measure; feudalism abolished.'),
    ('213 BC', 'Burning of the books', 'Legalist suppression of ideas.'),
    ('210 BC', 'Death on tour', 'Concealed; the succession forged.'),
    ('206 BC', 'Fall of Qin', 'The dynasty collapses; the Han rise.'),
]

MASTER = [
    {'year': '259 BC', 'age': 'born', 'phase': 'King of Qin', 'title': 'Born in Zhao', 'desc': 'A hostage-prince’s son.'},
    {'year': '246 BC', 'age': 'age ~13', 'phase': 'King of Qin', 'title': 'King of Qin', 'desc': 'Inherits the strongest state.'},
    {'year': '221 BC', 'age': 'age ~38', 'phase': 'The Conquest', 'title': 'Unifies China', 'desc': 'Becomes First Emperor.'},
    {'year': '221 BC', 'age': 'age ~38', 'phase': 'First Emperor', 'title': 'Standardises China', 'desc': 'Script, coin, measure.'},
    {'year': '213 BC', 'age': 'age ~46', 'phase': 'Control', 'title': 'Burns the books', 'desc': 'War on ideas.'},
    {'year': '210 BC', 'age': 'age ~49', 'phase': 'Death & Collapse', 'title': 'Death', 'desc': 'The empire soon falls.'},
]

SOURCES = [
    ('Britannica — Qin Shi Huang', 'https://www.britannica.com/biography/Qin-Shi-Huang'),
    ('World History Encyclopedia — Shi Huangdi', 'https://www.worldhistory.org/Shi_Huangdi/'),
    ('Britannica — Qin dynasty', 'https://www.britannica.com/topic/Qin-dynasty'),
    ('World History Encyclopedia — Terracotta Army', 'https://www.worldhistory.org/Terracotta_Army/'),
    ('Wikipedia — Qin Shi Huang', 'https://en.wikipedia.org/wiki/Qin_Shi_Huang'),
]

def build_meta():
    return {
        'pid': 'gm-qinshihuang.html', 'kind': 'man', 'emoji': '🀄', 'accent': AC,
        'name': 'Qin Shi Huang', 'years': '259–210 BC', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The First Emperor of China — the Legalist conqueror who united the warring states, invented the imperial office, standardised a civilisation, and built the Terracotta Army, only for his eternal dynasty to fall within fifteen years.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The King of Qin', 'type': 'timeline',
             'intro': 'Born a hostage-prince’s son and made king by a merchant’s gamble, he crushes a coup to take sole power and inherits the terrifying Legalist war-machine of Qin.', 'events': PHASE_RISE},
            {'id': 'conquer', 'label': '2 · The Conquest', 'type': 'timeline',
             'intro': 'He survives the most famous assassination attempt in Chinese history and, in a single relentless decade, conquers the six rival kingdoms to unite China for the first time.', 'events': PHASE_CONQUER},
            {'id': 'emperor', 'label': '3 · The First Emperor', 'type': 'timeline',
             'intro': 'He invents the very office of emperor, standardises the script, coin and measures, abolishes feudalism for a centralised bureaucracy, and binds the empire with roads, a canal and the Great Wall.', 'events': PHASE_EMPEROR},
            {'id': 'control', 'label': '4 · Control & Obsession', 'type': 'timeline',
             'intro': 'He reaches for total control — burning books and burying scholars to master thought itself — and builds a tomb-city guarded by the Terracotta Army to rule in eternity.', 'events': PHASE_CONTROL},
            {'id': 'fall', 'label': '5 · Death & Collapse', 'type': 'timeline',
             'intro': 'Terrified of death, he chases an immortality elixir that may have poisoned him; his death on tour is hidden and his succession forged — and the dynasty meant for ten thousand generations collapses within four years.', 'events': PHASE_FALL,
             'sources': SOURCES, 'srcnote': 'Much of the record comes from the Han historian Sima Qian, writing under the succeeding dynasty; some episodes (the buried scholars, the tomb’s mercury rivers) blend documented fact with hostile tradition and are read critically.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
