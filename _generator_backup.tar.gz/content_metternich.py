# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Klemens von Metternich.
The Austrian architect of the conservative order that held Europe for a generation."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#3730a3'  # Habsburg indigo

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE RISE
PHASE_RISE = [
    E('origins', '1773–1801', 'A homeland overrun — the making of a counter-revolutionary', ['RISE', 'TRAGEDY'],
      'Born into the Rhineland nobility, young Metternich watches the French Revolution overrun and dispossess his family — an experience that plants in him a lifelong horror of revolution, upheaval and the mob, and a conviction that order and legitimacy must be defended at all costs.',
      svg_row('Revolution makes its lifelong enemy', [
          {'n': 1, 'label': 'Rhineland noble, 1773', 'sub': 'raised in the old order of the Holy Roman Empire', 'color': '#3730a3'},
          {'n': 2, 'label': 'The Revolution overruns his home', 'sub': 'French armies dispossess the family', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A lifelong horror of chaos', 'sub': 'order and legitimacy become his creed', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='The chaos that destroyed his world made him its most determined enemy — order became his one great cause.', accent=AC),
      bg='<b>Klemens von Metternich</b> was born in 1773 into the Rhineland aristocracy of the Holy Roman Empire, whose lands the French Revolution soon overran.',
      people='his displaced noble family; the revolutionary France he came to loathe; the Habsburg Austria he would serve.',
      what='The <b>French Revolution</b> dispossessed Metternich’s family and shattered the old order of his youth — searing into him a <b>lifelong dread of revolution</b> and a devotion to stability and legitimacy.',
      crux='His politics were forged in <b>reaction to chaos</b> — he would spend his life building dams against the revolutionary tide.',
      conseq='He entered Austrian service determined to preserve the old order against the forces the Revolution had unleashed.',
      matters='Formative catastrophe shapes conviction — the man who watched revolution destroy his world devoted his life to preventing more.'),

    E('diplomat', '1801–1809', 'The rising diplomat — and a front-row study of Napoleon', ['RISE', 'POLITICS'],
      'Metternich climbs the Austrian diplomatic ladder through charm, intelligence and a brilliant marriage, culminating as ambassador to Napoleon’s Paris — where he studies the emperor up close, takes his measure, and concludes that Napoleon can be beaten only by patience and cunning, never by force alone.',
      svg_stack('Learning the enemy at close range', [
          {'n': 1, 'label': 'Rises through charm and marriage', 'sub': 'weds into the powerful Kaunitz family', 'color': '#3730a3'},
          {'n': 2, 'label': 'Ambassador to Napoleon’s Paris', 'sub': 'studies the emperor face to face, 1806–09', 'color': '#a16207'},
          {'n': 3, 'label': 'Takes his measure', 'sub': 'concludes Napoleon must be beaten by cunning, not force', 'color': '#166534'},
      ], takeaway='He learned his great adversary in person — and decided that patience and guile, not armies alone, would bring him down.', accent=AC),
      bg='Metternich rose in Austrian diplomacy through wit, elegance and a marriage into the family of the former chancellor Kaunitz, gaining key ambassadorships.',
      people='<b>Napoleon</b>, whom he observed as ambassador; the Austrian court; the European statesmen he cultivated.',
      what='As <b>ambassador to Paris (1806–09)</b>, Metternich studied Napoleon at close quarters, judging that the emperor’s power, though immense, could be undone by <b>patience, diplomacy and timing</b> rather than direct confrontation.',
      crux='He believed in <b>outlasting and out-thinking</b> a stronger enemy — the diplomat’s art over the soldier’s.',
      conseq='This assessment guided his strategy when he took charge of Austrian foreign policy.',
      matters='Knowing your adversary intimately shapes your strategy — Metternich planned to beat Napoleon at the game of patience.'),
]

# ==================================================================  PHASE 2 — SURVIVING NAPOLEON
PHASE_POWER = [
    E('foreignminister', '1809', 'Foreign Minister of a defeated empire', ['POLITICS', 'TURNING POINT'],
      'Metternich becomes Austrian Foreign Minister just after Austria’s crushing defeat by Napoleon — and, judging that Austria cannot beat France by arms, sets out to preserve the empire by cunning: appeasing Napoleon, buying time, and waiting for the moment to strike.',
      svg_stack('Preserving a beaten empire by guile', [
          {'n': 1, 'label': 'Austria defeated again, 1809', 'sub': 'Napoleon humbles the Habsburgs', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Metternich takes the helm', 'sub': 'Foreign Minister of a weakened Austria', 'color': '#3730a3'},
          {'n': 3, 'label': 'Survive by cunning, not force', 'sub': 'appease Napoleon, buy time, wait', 'color': '#a16207'},
      ], takeaway='He took charge at Austria’s lowest point and chose patience over pride — survival first, revenge later.', accent=AC),
      bg='In 1809 Napoleon defeated Austria yet again. Metternich took over foreign policy with the empire weak and encircled.',
      people='Emperor <b>Francis I</b> of Austria; <b>Napoleon</b>, the dominant power; the exhausted Habsburg state.',
      what='As <b>Foreign Minister from 1809</b>, Metternich judged Austria too weak to defy Napoleon directly, and pursued a policy of <b>appeasement and patience</b> to preserve the empire until circumstances changed.',
      crux='He put <b>survival above pride</b> — accepting humiliation now to keep Austria alive for a better moment.',
      conseq='His first great stroke of this policy was to bind Napoleon to Austria by marriage.',
      matters='The weak survive by patience — accepting short-term humiliation to preserve the strength to act later.'),

    E('marielouise', '1810', 'Marrying an archduchess to the emperor', ['POLITICS', 'REFORM'],
      'Metternich arranges the marriage of Napoleon to the Austrian archduchess Marie Louise — a cynical masterstroke that ties the conqueror to the Habsburg dynasty, buys Austria years of peace to rebuild, and places a Habsburg at the very heart of Napoleon’s empire.',
      svg_row('A dynastic marriage as strategy', [
          {'n': 1, 'label': 'Napoleon seeks an heir', 'sub': 'divorces Joséphine; wants a royal bride', 'color': '#a16207'},
          {'n': 2, 'label': 'An Austrian archduchess', 'sub': 'Marie Louise wed to Napoleon, 1810', 'color': '#3730a3'},
          {'n': 3, 'label': 'Austria buys time', 'sub': 'peace to rebuild; a Habsburg in Napoleon’s bed', 'color': '#166534'},
      ], edge_labels=['so', 'yields'], takeaway='He bound the conqueror to Austria by marriage — buying the years of peace his empire needed to recover.', accent=AC),
      bg='Napoleon, having divorced Joséphine, sought a dynastic marriage to a royal house. Metternich saw an opportunity for Austria.',
      people='<b>Napoleon</b>, the bridegroom; the archduchess <b>Marie Louise</b>; Emperor Francis I, her father.',
      what='Metternich engineered the <b>marriage of Marie Louise to Napoleon (1810)</b>, tying the emperor to the Habsburg dynasty and winning Austria <b>years of peace</b> to rebuild its strength.',
      crux='He used a <b>dynastic marriage as a strategic weapon</b> — turning the enemy’s need into Austria’s breathing space.',
      conseq='The alliance was cynical and temporary; when Napoleon faltered, Metternich would turn on him.',
      matters='Diplomacy can achieve with a wedding what armies cannot — binding a stronger power and buying precious time.'),

    E('switch', '1813', 'The armed mediator — turning on Napoleon', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'As Napoleon reels from the Russian catastrophe, Metternich plays his masterstroke — posing as a neutral mediator while secretly preparing for war, then bringing Austria into the coalition against Napoleon at the decisive moment, tipping the balance and helping to bring the emperor down.',
      svg_stack('Neutrality as a weapon', [
          {'n': 1, 'label': 'Napoleon weakened after Russia', 'sub': 'the 1812 disaster shifts the balance', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Poses as neutral mediator', 'sub': 'buys time and terms while arming', 'color': '#3730a3'},
          {'n': 3, 'label': 'Joins the coalition, 1813', 'sub': 'Austria tips the balance against Napoleon', 'color': '#166534'},
      ], takeaway='He waited for exactly the right moment, then threw Austria’s weight in — patience rewarded with decisive influence.', accent=AC),
      bg='After Napoleon’s catastrophe in Russia (1812), the balance of power shifted. Metternich manoeuvred to make Austria the decisive player.',
      people='<b>Napoleon</b>, now vulnerable; the allied powers (Russia, Prussia); Metternich, the calculating mediator.',
      what='Metternich posed as a <b>neutral mediator</b> while preparing for war, then brought <b>Austria into the coalition against Napoleon in 1813</b>, tipping the balance toward the emperor’s defeat.',
      crux='He timed his move perfectly — <b>joining the winning side at the decisive moment</b> to maximise Austria’s influence over the peace.',
      conseq='Napoleon’s defeat left Metternich the leading statesman of Europe, ready to reshape the continent.',
      matters='Timing is the essence of statecraft — the patient player who commits at the pivotal moment shapes the outcome.'),
]

# ==================================================================  PHASE 3 — THE CONSERVATIVE ORDER
PHASE_ORDER = [
    E('vienna', '1814–1815', 'The Congress of Vienna — remaking Europe', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'Metternich hosts and dominates the Congress of Vienna, the great conference that reorders Europe after Napoleon — restoring monarchies, balancing the powers so no one can dominate again, and placing Austria at the center of a conservative peace designed to last.',
      svg_stack('Architect of the post-Napoleonic peace', [
          {'n': 1, 'label': 'Hosts the Congress, 1814–15', 'sub': 'the powers gather in Vienna to reorder Europe', 'color': '#3730a3'},
          {'n': 2, 'label': 'Restore and balance', 'sub': 'legitimate monarchies restored; powers balanced', 'color': '#a16207'},
          {'n': 3, 'label': 'Austria at the center', 'sub': 'a conservative peace built to last', 'color': '#166534'},
      ], takeaway='He rebuilt Europe on balance and legitimacy — a settlement that prevented general war for a generation.', accent=AC),
      bg='With Napoleon defeated, the powers met at the <b>Congress of Vienna (1814–15)</b> to reconstruct Europe. Metternich, as host, was its central figure.',
      people='<b>Talleyrand</b> of France, <b>Castlereagh</b> of Britain, <b>Tsar Alexander</b> of Russia; Metternich, orchestrating.',
      what='Metternich dominated the Congress, restoring <b>legitimate monarchies</b>, establishing a <b>balance of power</b> so no state could dominate, and placing Austria at the heart of the new order.',
      crux='He built a peace on <b>balance and legitimacy</b> rather than revenge — a stable order rather than a punitive one.',
      conseq='The Vienna settlement kept Europe free of general war for nearly a century, though at the cost of suppressing change.',
      matters='A durable peace balances power rather than punishing the loser — Metternich’s order lasted precisely because it was not vindictive.'),

    E('concert', '1815–1848', 'The Concert of Europe — managing the peace', ['POLITICS', 'REFORM'],
      'Metternich institutionalizes his order as the Concert of Europe — the great powers meeting in congresses to manage disputes and preserve the status quo together — a pioneering system of collective diplomacy that keeps the peace, so long as the powers agree to defend the established order.',
      svg_row('Great-power cooperation to keep the peace', [
          {'n': 1, 'label': 'The Concert of Europe', 'sub': 'the powers meet in congress to manage disputes', 'color': '#3730a3'},
          {'n': 2, 'label': 'Defend the status quo', 'sub': 'cooperate to preserve the established order', 'color': '#a16207'},
          {'n': 3, 'label': 'Collective diplomacy', 'sub': 'a pioneering system of managed peace', 'color': '#166534'},
      ], edge_labels=['to', 'via'], takeaway='He pioneered collective great-power diplomacy — nations cooperating to manage crises rather than fight over them.', accent=AC),
      bg='To sustain the Vienna settlement, Metternich promoted regular congresses of the powers to resolve disputes and coordinate against threats to the order.',
      people='the great powers of the <b>Concert</b>; the revolutionaries and nationalists it aimed to suppress; Metternich, its guiding spirit.',
      what='Metternich helped build the <b>Concert of Europe</b> — a system of periodic great-power congresses (Aix-la-Chapelle, Troppau, Verona) to <b>manage disputes and defend the status quo</b> collectively.',
      crux='He understood that <b>a shared order needs shared management</b> — the powers cooperating to preserve peace and suppress upheaval.',
      conseq='The Concert kept general peace for decades, a forerunner of later international systems, but rested on suppressing liberalism and nationalism.',
      matters='Collective security is an old idea — great powers can keep the peace by managing crises together, if they share an interest in order.'),
]

# ==================================================================  PHASE 4 — THE POLICEMAN OF EUROPE
PHASE_REPRESSION = [
    E('carlsbad', '1819', 'The Carlsbad Decrees — a war on ideas', ['POLITICS', 'TRAGEDY'],
      'To choke off the liberalism and nationalism he dreads, Metternich pushes through the Carlsbad Decrees — imposing press censorship, surveillance of universities, and suppression of student societies across the German states — building a system of political policing that gives the age its name.',
      svg_stack('Repression as a system', [
          {'n': 1, 'label': 'Fear of liberal nationalism', 'sub': 'student movements and free press alarm him', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The Carlsbad Decrees, 1819', 'sub': 'censorship, university surveillance, banned societies', 'color': '#3730a3'},
          {'n': 3, 'label': 'The “Metternich system”', 'sub': 'political policing across the German states', 'color': '#78350f'},
      ], takeaway='He fought ideas with censorship and spies — a repressive machine that held the lid down but never solved the pressure.', accent=AC),
      bg='Liberalism and German nationalism, especially among students, alarmed Metternich as threats to the multi-ethnic Habsburg order.',
      people='the liberal students and writers he suppressed; the German princes who enforced the decrees; Metternich, their architect.',
      what='Metternich engineered the <b>Carlsbad Decrees (1819)</b> — imposing <b>press censorship, surveillance of universities and the banning of nationalist student societies</b> across the German Confederation — the core of his repressive “system.”',
      crux='He tried to <b>suppress the ideas of liberalism and nationalism</b> by force, treating dissent as a contagion to be policed.',
      conseq='The repression bought decades of surface calm but bottled up pressures that would burst in 1848.',
      matters='Repressing ideas can delay change but not prevent it — a dam against the tide holds only until it breaks.'),

    E('interventions', '1820–1846', 'The policeman of Europe — crushing the revolutions', ['POLITICS', 'BATTLE', 'TRAGEDY'],
      'Metternich becomes the policeman of Europe, using the Congress system to authorize armed intervention against liberal revolutions wherever they erupt — sending Austrian troops to crush uprisings in Italy and backing the suppression of revolts across the continent to hold the conservative order together.',
      svg_row('Intervention to preserve the order', [
          {'n': 1, 'label': 'Revolutions erupt', 'sub': 'liberal uprisings in Italy, Spain and beyond', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Congresses authorize force', 'sub': 'Troppau, Laibach, Verona sanction intervention', 'color': '#3730a3'},
          {'n': 3, 'label': 'Austria crushes revolts', 'sub': 'troops sent to suppress the uprisings', 'color': '#78350f'},
      ], edge_labels=['met by', 'and'], takeaway='He made Austria the armed guardian of the status quo — crushing each revolution to preserve the whole order.', accent=AC),
      bg='Through the 1820s, liberal and nationalist revolutions broke out across Europe. Metternich used the Concert to justify suppressing them.',
      people='the Italian and Spanish revolutionaries; the powers of the Congress system; the Austrian armies of intervention.',
      what='At congresses like <b>Troppau, Laibach and Verona</b>, Metternich secured sanction for <b>armed intervention against revolutions</b>, sending Austrian troops to crush uprisings (notably in <b>Italy</b>) and upholding the conservative order across Europe.',
      crux='He treated every revolution as a threat to the whole system, to be <b>stamped out by force</b> before it could spread.',
      conseq='He held the order together for a generation, earning both the peace and the reputation of a reactionary tyrant.',
      matters='Guardians of a status quo can suppress its challengers for a time — but force cannot indefinitely hold back a rising age.'),
]

# ==================================================================  PHASE 5 — THE FALL
PHASE_END = [
    E('1848', '1848–1859', 'The deluge — 1848 sweeps him away', ['POLITICS', 'DEFEAT', 'DEATH'],
      'The revolutions of 1848 erupt across Europe and overwhelm the order Metternich built — and the man who had policed the continent for a generation is forced to flee Vienna in disguise for exile in England, his system in ruins, though the age would forever bear his name.',
      svg_stack('The dam finally bursts', [
          {'n': 1, 'label': 'Revolutions of 1848', 'sub': 'liberal and national uprisings sweep Europe', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Metternich flees Vienna', 'sub': 'the policeman of Europe escapes in disguise', 'color': '#3730a3'},
          {'n': 3, 'label': 'The Age of Metternich ends', 'sub': 'exile in England; his system in ruins', 'color': '#78350f'},
      ], takeaway='The forces he spent his life suppressing finally burst through — and swept the great conservative away.', accent=AC),
      bg='By 1848 the pressures Metternich had bottled up — liberalism, nationalism, demands for reform — exploded across Europe at once.',
      people='the revolutionaries of 1848; the Habsburg court that abandoned him; the England that gave him refuge.',
      what='The <b>Revolutions of 1848</b> overwhelmed the conservative order; Metternich was forced to <b>resign and flee Vienna in disguise</b>, going into exile in England. He returned later but never regained power, and died in 1859.',
      crux='The forces he had suppressed for decades <b>burst through all at once</b> — proof that repression defers but cannot cancel change.',
      conseq='Though his system fell, the balance-of-power peace he built at Vienna outlasted him, and the era bears his name.',
      matters='No one can hold back an age forever — Metternich’s fall showed that suppressed change returns with redoubled force.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Klemens von Metternich was the architect of the conservative order that held Europe together for a generation after Napoleon. Scarred by watching the French Revolution destroy his world, the Austrian statesman devoted his life to order, balance and legitimacy — dominating the Congress of Vienna, building the Concert of Europe, and policing the continent against the liberalism and nationalism he dreaded. He kept the general peace for decades, but only by suppressing the forces of change that finally swept him away in 1848. He is the ultimate study in <b>order over liberty, the balance of power, and the limits of holding back an age.</b></p>
<div class="ov-quote">“When Paris sneezes, Europe catches cold.”<span>— attributed to Metternich</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Revolution overruns his homeland and makes him its lifelong enemy → he rises as a diplomat and studies Napoleon in Paris → becomes Foreign Minister of a beaten Austria and survives by cunning → marries an archduchess to Napoleon, then turns on him at the decisive moment → dominates the Congress of Vienna and builds the Concert of Europe → polices the continent with censorship and armed intervention → and is finally swept away by the revolutions of 1848.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⚖️</div><h4>The balance of power</h4><p>Built a peace on balance and legitimacy that lasted a generation.</p></div>
  <div class="ov-card"><div class="i">🤝</div><h4>The Concert of Europe</h4><p>Pioneered collective great-power diplomacy to manage crises.</p></div>
  <div class="ov-card"><div class="i">🚨</div><h4>The policeman of Europe</h4><p>Suppressed liberalism and nationalism with censorship and force.</p></div>
  <div class="ov-card"><div class="i">🌊</div><h4>The limits of order</h4><p>1848 proved that repression defers but cannot cancel change.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Rise</b><small> 1773–1809</small><p>Revolution’s enemy; a diplomat studies Napoleon.</p></div>
  <div><b>2 · Surviving Napoleon</b><small> 1809–1813</small><p>Cunning, a royal marriage, and the decisive switch.</p></div>
  <div><b>3 · The Conservative Order</b><small> 1814–1848</small><p>Vienna and the Concert of Europe.</p></div>
  <div><b>4 · Policeman of Europe</b><small> 1819–1846</small><p>Censorship, and crushing the revolutions.</p></div>
  <div><b>5 · The Fall</b><small> 1848–1859</small><p>The deluge sweeps him away.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Napoleon Bonaparte', 'role': 'adversary', 'color': '#b91c1c',
     'bio': 'The emperor Metternich appeased, married to a Habsburg archduchess, and then helped bring down at the decisive moment in 1813.',
     'rel': 'The conqueror he survived by cunning and then defeated.'},
    {'name': 'Talleyrand', 'role': 'fellow diplomat', 'color': '#5b21b6',
     'bio': 'The French statesman who, at the Congress of Vienna, both rivalled and combined with Metternich in reordering Europe.',
     'rel': 'His counterpart and sometime partner at Vienna.'},
    {'name': 'Tsar Alexander I', 'role': 'great-power rival', 'color': '#166534',
     'bio': 'The Russian emperor whose ambitions Metternich balanced at Vienna and within the Concert of Europe.',
     'rel': 'The powerful monarch he balanced within the new order.'},
    {'name': 'Emperor Francis I', 'role': 'his sovereign', 'color': '#a16207',
     'bio': 'The Habsburg emperor Metternich served as foreign minister and chancellor for nearly four decades.',
     'rel': 'The monarch whose empire he devoted his life to preserving.'},
    {'name': 'Viscount Castlereagh', 'role': 'British ally', 'color': '#3730a3',
     'bio': 'The British foreign secretary who worked with Metternich to build the balance-of-power settlement at Vienna.',
     'rel': 'The British partner in constructing the Vienna order.'},
]

KEY_EVENTS = [
    ('1773', 'Metternich born', 'Rhineland nobility; revolution overruns his home.'),
    ('1806', 'Ambassador to Paris', 'Studies Napoleon at close range.'),
    ('1809', 'Austrian Foreign Minister', 'Survives a beaten empire by cunning.'),
    ('1810', 'Marie Louise weds Napoleon', 'A dynastic marriage buys time.'),
    ('1813', 'Austria joins the coalition', 'Tips the balance against Napoleon.'),
    ('1814–15', 'Congress of Vienna', 'Architect of the conservative order.'),
    ('1819', 'Carlsbad Decrees', 'Censorship and repression.'),
    ('1820s', 'Congresses & interventions', 'The policeman of Europe.'),
    ('1848', 'Revolutions sweep him away', 'Flees to exile in England.'),
    ('1859', 'Death of Metternich', 'The age still bears his name.'),
]

MASTER = [
    {'year': '1773', 'age': 'born', 'phase': 'The Rise', 'title': 'Born in the Rhineland', 'desc': 'Revolution overruns his home.'},
    {'year': '1809', 'age': 'age 36', 'phase': 'Surviving Napoleon', 'title': 'Foreign Minister', 'desc': 'Survives by cunning.'},
    {'year': '1813', 'age': 'age 40', 'phase': 'Surviving Napoleon', 'title': 'Turns on Napoleon', 'desc': 'Tips the balance.'},
    {'year': '1815', 'age': 'age 42', 'phase': 'Conservative Order', 'title': 'Congress of Vienna', 'desc': 'Remakes Europe.'},
    {'year': '1819', 'age': 'age 46', 'phase': 'Policeman of Europe', 'title': 'Carlsbad Decrees', 'desc': 'Repression as a system.'},
    {'year': '1848', 'age': 'age 75', 'phase': 'The Fall', 'title': 'Swept away', 'desc': 'The order collapses.'},
]

SOURCES = [
    ('Britannica — Klemens von Metternich', 'https://www.britannica.com/biography/Klemens-von-Metternich'),
    ('World History Encyclopedia — Klemens von Metternich', 'https://www.worldhistory.org/Klemens_von_Metternich/'),
    ('Britannica — Congress of Vienna', 'https://www.britannica.com/event/Congress-of-Vienna'),
    ('Britannica — Concert of Europe', 'https://www.britannica.com/topic/Concert-of-Europe'),
    ('Wikipedia — Klemens von Metternich', 'https://en.wikipedia.org/wiki/Klemens_von_Metternich'),
]

def build_meta():
    return {
        'pid': 'gm-metternich.html', 'kind': 'man', 'emoji': '⚖️', 'accent': AC,
        'name': 'Klemens von Metternich', 'years': '1773–1859', 'group': 'Diplomats & Strategists',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Austrian architect of the conservative order after Napoleon — master of the Congress of Vienna and the balance of power, who policed Europe against revolution for a generation until 1848 swept him away.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Rise', 'type': 'timeline',
             'intro': 'Watching the French Revolution destroy his homeland makes him its lifelong enemy; he rises as a diplomat and studies Napoleon face to face in Paris.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · Surviving Napoleon', 'type': 'timeline',
             'intro': 'Taking charge of a beaten Austria, he survives Napoleon by cunning — appeasing him, marrying an archduchess to him, then turning on him at the decisive moment.', 'events': PHASE_POWER},
            {'id': 'order', 'label': '3 · The Conservative Order', 'type': 'timeline',
             'intro': 'He dominates the Congress of Vienna and builds the Concert of Europe — a peace of balance and legitimacy, and a system of collective great-power diplomacy.', 'events': PHASE_ORDER},
            {'id': 'repression', 'label': '4 · Policeman of Europe', 'type': 'timeline',
             'intro': 'To defend his order he becomes the policeman of Europe — imposing censorship and surveillance through the Carlsbad Decrees, and crushing liberal revolutions by force.', 'events': PHASE_REPRESSION},
            {'id': 'end', 'label': '5 · The Fall', 'type': 'timeline',
             'intro': 'The revolutions of 1848 burst through the dam he built, forcing the policeman of Europe to flee Vienna in disguise — though the balance-of-power peace, and the age’s name, endure.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; famous quips attributed to Metternich capture his outlook and are read as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
