# -*- coding: utf-8 -*-
"""Full, DEEP guide content for John D. Rockefeller.
The oil titan who built the greatest monopoly in history, then reinvented philanthropy."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#134e4a'  # petroleum teal

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING
PHASE_RISE = [
    E('origins', '1839–1855', 'A devout mother, a con-man father — the making of a self-made man', ['RISE', 'ORIGINS'],
      'Born on a hardscrabble New York farm in 1839, John D. Rockefeller is shaped by two opposites — a pious, thrifty Baptist mother who drills into him discipline and duty, and a flamboyant huckster father, “Devil Bill,” a travelling quack who teaches him to drive a hard bargain and trust no one. From this split inheritance comes a boy of icy self-control who tithes and saves from his earliest pennies.',
      svg_row('Two parents, one iron discipline', [
          {'n': 1, 'label': 'Born poor, 1839', 'sub': 'a farm in Richford, upstate New York', 'color': '#134e4a'},
          {'n': 2, 'label': '“Devil Bill” & devout Eliza', 'sub': 'a con-man father, a Baptist mother', 'color': '#a16207'},
          {'n': 3, 'label': 'Thrift, faith, self-control', 'sub': 'saves and tithes from his first pennies', 'color': '#166534'},
      ], edge_labels=['forge', 'into'], takeaway='A huckster’s cunning married to a Baptist’s discipline produced a boy who worshipped both God and the account book.', accent=AC),
      bg='<b>John Davison Rockefeller</b> was born on <b>8 July 1839</b> in Richford, New York, the second of six children in a struggling farm family that moved often to escape his father’s debts and schemes.',
      people='His mother <b>Eliza Davison</b>, pious and frugal; his father <b>William “Devil Bill” Rockefeller</b>, a travelling seller of quack medicines and a bigamist; his devout Baptist community.',
      what='Rockefeller absorbed <b>rigid discipline and thrift from his mother</b> and <b>sharp bargaining from his father</b>, who once boasted he cheated his sons to “make ’em sharp.” Deeply religious, John kept a ledger of every cent and tithed to the Baptist church from boyhood.',
      crux='His character fused <b>moral austerity with commercial ruthlessness</b> — he saw money-making as a calling blessed by God.',
      conseq='This union of piety and calculation would define both his monopoly-building and his later giving.',
      matters='Formative contradictions can make a formidable character — Rockefeller’s discipline and his hard edge both trace to childhood.'),

    E('bookkeeper', '1855', 'Job Day — a sixteen-year-old bookkeeper finds his vocation', ['RISE', 'TURNING POINT'],
      'At sixteen, after a short business course, Rockefeller lands his first job as an assistant bookkeeper at the Cleveland commission house Hewitt & Tuttle. He is so proud of it that he celebrates 26 September as “Job Day” for the rest of his life. He masters the ledger, worships order and precision, and lives with almost monastic frugality — the numbers, he finds, never lie.',
      svg_stack('A ledger becomes a religion', [
          {'n': 1, 'label': 'First job, 26 Sept 1855', 'sub': 'assistant bookkeeper at Hewitt & Tuttle, Cleveland', 'color': '#134e4a'},
          {'n': 2, 'label': 'Master of the ledger', 'sub': 'worships accuracy, order and cost control', 'color': '#a16207'},
          {'n': 3, 'label': '“Job Day” for life', 'sub': 'celebrates the anniversary every year', 'color': '#166534'},
      ], takeaway='He learned in a clerk’s chair the lesson of his life — that whoever masters the numbers controls the business.', accent=AC),
      bg='After the family moved to Cleveland, Rockefeller took a ten-week business course and hunted doggedly for work before <b>Hewitt & Tuttle</b>, produce commission merchants, hired him.',
      people='His employers at <b>Hewitt & Tuttle</b>; his frugal self, who tracked every expense in a little book he called <b>Ledger A</b>.',
      what='Starting on <b>26 September 1855</b>, Rockefeller kept the firm’s accounts with obsessive care, catching errors and controlling costs to the penny. He revered the job so much he honoured its anniversary as <b>“Job Day”</b> all his life.',
      crux='He discovered that <b>command of the books was command of the enterprise</b> — an insight that made him the coldest cost-cutter of his age.',
      conseq='Within a few years he had saved enough, and learned enough, to go into business for himself.',
      matters='Great fortunes often begin with fanatical attention to detail — Rockefeller built an empire on the humble discipline of the ledger.'),

    E('firstbusiness', '1859–1863', 'From produce to petroleum — entering the oil trade', ['RISE', 'BUSINESS'],
      'At nineteen Rockefeller goes into business for himself as a produce commission merchant, and the Civil War brings a boom in trade. But he sees a bigger opportunity in the chaotic new oil rush spilling out of Pennsylvania, and in 1863 he plunges into oil refining in Cleveland — betting not on the wild drilling fields but on the steadier, more controllable business of refining crude into kerosene.',
      svg_row('Choosing refining over the wildcat rush', [
          {'n': 1, 'label': 'Clark & Rockefeller, 1859', 'sub': 'his own produce commission house', 'color': '#134e4a'},
          {'n': 2, 'label': 'Civil War boom', 'sub': 'trade profits build his capital', 'color': '#a16207'},
          {'n': 3, 'label': 'Into oil refining, 1863', 'sub': 'bets on refining kerosene, not drilling', 'color': '#166534'},
      ], edge_labels=['funds', 'pivot to'], takeaway='He shunned the gambler’s drilling fields for the refiner’s bottleneck — the choke point where fortunes would really be made.', accent=AC),
      bg='In 1859, aged 19, Rockefeller and partner Maurice Clark founded a produce firm. That same year Edwin Drake struck oil in Titusville, Pennsylvania, igniting the world’s first oil rush.',
      people='His partner <b>Maurice Clark</b>; the chemist <b>Samuel Andrews</b>, who knew refining; the reckless drillers of the Pennsylvania oil fields.',
      what='After profiting from wartime trade, Rockefeller entered <b>oil refining in Cleveland in 1863</b> with the firm Andrews, Clark & Co., judging that refining — not chaotic, boom-and-bust drilling — was the controllable heart of the industry.',
      crux='He targeted the <b>strategic choke point</b> — control refining and transport, and you control the whole oil trade.',
      conseq='In 1865 he bought out his partners for $72,500 to take full command, then set about dominating the business.',
      matters='Fortunes are made at bottlenecks — Rockefeller grasped early that whoever controls the choke point controls the industry.'),
]

# ==================================================================  PHASE 2 — BUILDING STANDARD OIL
PHASE_POWER = [
    E('standardoil', '1870', 'Standard Oil is born — efficiency as a weapon', ['BUSINESS', 'TURNING POINT'],
      'In 1870 Rockefeller incorporates the Standard Oil Company of Ohio, capitalized at a million dollars. The name is a promise — a “standard,” uniform, reliable quality of kerosene. Obsessed with wringing out every scrap of waste, he makes his own barrels, buys his own wagons and tank cars, and drives costs so low that no rival can match him. Ruthless efficiency, not luck, is his edge.',
      svg_stack('A company built to crush waste', [
          {'n': 1, 'label': 'Standard Oil of Ohio, 1870', 'sub': '$1 million capital; Flagler, William Rockefeller', 'color': '#134e4a'},
          {'n': 2, 'label': 'War on every cost', 'sub': 'own barrels, wagons, tank cars, plumbers', 'color': '#a16207'},
          {'n': 3, 'label': 'Undercut all rivals', 'sub': 'lowest cost per gallon in the industry', 'color': '#166534'},
      ], takeaway='He turned efficiency into a weapon — costs so low that competitors bled while Standard Oil profited.', accent=AC),
      bg='By 1870 Cleveland had dozens of small refiners in a chaotic, overbuilt industry of violent price swings. Rockefeller meant to bring order — under his control.',
      people='His partner <b>Henry Flagler</b>, who structured the deals; his brother <b>William Rockefeller</b>; the chemist <b>Samuel Andrews</b>.',
      what='On <b>10 January 1870</b> Rockefeller founded the <b>Standard Oil Company of Ohio</b> with $1 million in capital. He obsessively cut costs — manufacturing his own barrels, employing his own coopers and mechanics — to achieve the lowest production cost in the industry.',
      crux='He believed the industry’s cutthroat chaos was <b>“ruinous competition”</b> to be replaced by order, scale and relentless efficiency — under one hand, his.',
      conseq='His cost advantage let him dictate terms to rivals and railroads alike, setting the stage for conquest.',
      matters='Operational excellence is a form of power — Rockefeller out-organised rather than merely out-fought his competitors.'),

    E('rebates', '1871–1872', 'The secret weapon — railroad rebates and the South Improvement scheme', ['BUSINESS', 'CONTROVERSY'],
      'Rockefeller’s deadliest tool is secret. Because Standard ships more oil than anyone, he extracts hidden rebates from the railroads — and, through the notorious South Improvement Company scheme, even “drawbacks,” a cut of the freight his rivals pay. It is a devastating, ethically dubious edge: his competitors are literally subsidising the machine that will devour them.',
      svg_row('Turning size into a secret price weapon', [
          {'n': 1, 'label': 'Standard ships the most oil', 'sub': 'volume gives it leverage over railroads', 'color': '#134e4a'},
          {'n': 2, 'label': 'Secret rebates & drawbacks', 'sub': 'the South Improvement Company, 1872', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Rivals subsidise their killer', 'sub': 'competitors pay a cut of freight to Standard', 'color': '#78350f'},
      ], edge_labels=['buys', 'so'], takeaway='By making his own size the lever, he turned the railroads into a hidden weapon aimed at his own competitors.', accent=AC),
      bg='Railroads feared ruinous rate wars and craved steady, high-volume shippers. Rockefeller, the biggest, could play them against one another for secret discounts.',
      people='The railroad magnates (<b>the Erie, the New York Central, the Pennsylvania</b>); the enraged independent refiners of the oil regions.',
      what='Standard secured <b>secret rebates</b> on its freight, and through the <b>South Improvement Company (1872)</b> arranged even to collect <b>“drawbacks”</b> — a portion of the higher rates its competitors paid. The scheme, once exposed, provoked fury and was quickly killed — but the rebate weapon endured.',
      crux='He weaponised <b>scale itself</b> — the more Standard shipped, the cheaper its transport and the higher its rivals’ costs, a self-reinforcing spiral.',
      conseq='Armed with this hidden advantage, Rockefeller moved to swallow Cleveland’s refiners whole.',
      matters='Market power compounds — an advantage in scale can be levered into an advantage no competitor can survive.'),

    E('cleveland', '1872', 'The Cleveland Massacre — swallowing the rivals whole', ['BUSINESS', 'TRIUMPH', 'TURNING POINT'],
      'In a few brutal weeks in early 1872, Rockefeller confronts Cleveland’s refiners one by one: sell to me, or be destroyed. Backed by his crushing cost and freight advantages, he absorbs twenty-two of the city’s twenty-six rivals in what becomes known as the “Cleveland Massacre.” It is a terrifying demonstration of the pattern he will repeat across the nation — absorb the willing, ruin the rest.',
      svg_stack('Absorb the willing, ruin the rest', [
          {'n': 1, 'label': 'The ultimatum, early 1872', 'sub': '“sell to us or be crushed”', 'color': '#b91c1c'},
          {'n': 2, 'label': '22 of 26 rivals absorbed', 'sub': 'in weeks — the “Cleveland Massacre”', 'color': '#134e4a'},
          {'n': 3, 'label': 'A template for conquest', 'sub': 'repeated across the whole industry', 'color': '#78350f'},
      ], takeaway='In a matter of weeks he devoured a city’s worth of competitors — a blueprint he would carry across America.', accent=AC),
      bg='With his cost and rebate advantages in place, Rockefeller turned on Cleveland’s independent refiners, offering to buy them out — from a position of overwhelming strength.',
      people='The <b>twenty-odd Cleveland refiners</b> he confronted; his partner Flagler; the rivals who sold, and the few who resisted and were broken.',
      what='In roughly <b>six weeks in 1872</b>, Rockefeller acquired <b>22 of Cleveland’s 26 competing refineries</b> — the <b>“Cleveland Massacre.”</b> Owners were shown Standard’s books and told resistance was hopeless; most sold, some for a fraction of value.',
      crux='He offered a stark choice: <b>join or be destroyed</b> — backed by advantages that made the threat entirely credible.',
      conseq='Standard now dominated Cleveland, then the greatest refining centre on earth, and moved to conquer the rest of the country the same way.',
      matters='Consolidation can be swift and merciless — Rockefeller showed how a decisive cost edge converts into total market control.'),
]

# ==================================================================  PHASE 3 — THE MONOPOLY
PHASE_ORDER = [
    E('monopoly', '1872–1882', 'Ninety percent — building a near-total monopoly', ['BUSINESS', 'TRIUMPH'],
      'City by city, Rockefeller repeats the Cleveland pattern until Standard Oil controls the American oil industry almost completely. He integrates horizontally — buying up refiners everywhere — and then vertically, seizing pipelines, tank cars, terminals and barrel-works, so that oil can barely move in America without passing through his hands. By the early 1880s he commands roughly ninety percent of the nation’s refining.',
      svg_stack('From one city to a whole industry', [
          {'n': 1, 'label': 'Horizontal integration', 'sub': 'absorbs refiners city by city, nationwide', 'color': '#134e4a'},
          {'n': 2, 'label': 'Vertical integration', 'sub': 'pipelines, tank cars, terminals, cooperage', 'color': '#a16207'},
          {'n': 3, 'label': '~90% of US refining', 'sub': 'near-total control by the early 1880s', 'color': '#166534'},
      ], takeaway='He owned not just the refineries but the arteries of oil itself — a stranglehold on an entire industry.', accent=AC),
      bg='After Cleveland, Rockefeller extended his campaign to Pittsburgh, Philadelphia, New York and the oil regions, buying or crushing refiners everywhere.',
      people='The scores of refiners absorbed into Standard; the pipeline and railroad interests he mastered; his lieutenants Flagler, Archbold and others.',
      what='Through relentless <b>horizontal integration</b> (buying rival refiners) and <b>vertical integration</b> (owning pipelines, tank cars, terminals, even the timber for barrels), Standard came to control roughly <b>90% of US oil refining</b> by the early 1880s.',
      crux='He aimed at <b>total control of the flow of oil</b> — not just refining, but every link from well to lamp.',
      conseq='Such concentration demanded a new legal form to manage it, and posed a mounting threat to which the public would eventually react.',
      matters='Monopoly is built by controlling a chain end to end — Rockefeller pioneered integration on a scale never before seen.'),

    E('trust', '1882', 'The Trust — inventing the modern corporation', ['BUSINESS', 'REFORM'],
      'To manage his sprawling empire of companies scattered across many states, Rockefeller’s lawyers devise a revolutionary legal instrument in 1882 — the Standard Oil Trust. Shareholders hand their stock to a board of trustees who control everything centrally. It is a landmark in corporate history, the template for the giant modern corporation, and it gives a whole era of concentrated capital its name: the age of the trusts.',
      svg_row('A new machine for controlling capital', [
          {'n': 1, 'label': 'An empire across many states', 'sub': 'dozens of firms, hard to control legally', 'color': '#134e4a'},
          {'n': 2, 'label': 'The Standard Oil Trust, 1882', 'sub': 'stock held by central trustees', 'color': '#a16207'},
          {'n': 3, 'label': 'The template for big business', 'sub': 'names an era — the age of trusts', 'color': '#166534'},
      ], edge_labels=['needs', 'creates'], takeaway='He didn’t just build a monopoly — he invented the legal machine that let monopoly operate at national scale.', accent=AC),
      bg='By 1882 Standard was a tangle of companies in different states, legally awkward to run as one. Rockefeller’s counsel <b>Samuel Dodd</b> devised a solution.',
      people='The lawyer <b>Samuel C. T. Dodd</b>, architect of the trust; the nine trustees, led by Rockefeller, who controlled the whole.',
      what='The <b>Standard Oil Trust (1882)</b>, with initial capital of about <b>$70 million</b>, pooled the stock of some 40 companies under nine trustees, centralising control of the entire empire. It became the model imitated across American industry.',
      crux='He turned a legal problem into an <b>organisational innovation</b> — a structure that could command capital and enterprise on a continental scale.',
      conseq='The trust made Standard even more powerful, but its very name became a byword for monopoly, spurring the antitrust backlash.',
      matters='Rockefeller helped invent the modern corporation — the organisational form is itself one of his lasting legacies.'),

    E('richest', '1880s–1913', 'The richest man in modern history', ['WEALTH', 'TRIUMPH'],
      'Standard Oil’s dividends pour a river of gold into Rockefeller’s hands. He becomes the richest American, and by many measures the wealthiest person in modern history — his peak fortune, adjusted to today’s money, is often estimated near four hundred billion dollars, a share of the national economy no later billionaire has matched. In 1916 he is reckoned the world’s first billionaire in nominal dollars.',
      svg_stack('A fortune without modern equal', [
          {'n': 1, 'label': 'Standard Oil’s golden river', 'sub': 'dividends make him staggeringly rich', 'color': '#134e4a'},
          {'n': 2, 'label': 'Richest American ever', 'sub': 'peak fortune ~$400B in today’s money', 'color': '#a16207'},
          {'n': 3, 'label': 'First US billionaire, 1916', 'sub': 'a share of GDP no billionaire since has matched', 'color': '#166534'},
      ], takeaway='Measured against the economy of his day, no Gilded Age rival — and no modern tycoon — has ever been as rich.', accent=AC),
      bg='As Standard’s monopoly matured, its profits flowed overwhelmingly to Rockefeller, who held the largest block of its stock.',
      people='His fellow Gilded Age titans — <b>Carnegie, Vanderbilt, Morgan</b> — none of whom rivalled his fortune relative to the economy.',
      what='Rockefeller became the <b>richest man in America</b> and, by the yardstick of national wealth, likely <b>the richest person in modern history</b>. His peak fortune is often estimated at about <b>$900 million in 1913</b> — on the order of <b>$400 billion today</b> — and he was reckoned the <b>first US-dollar billionaire around 1916</b>.',
      crux='His wealth was extraordinary not just in size but as a <b>share of the whole economy</b> — a concentration of capital rarely seen before or since.',
      conseq='Such visible, colossal wealth made him a lightning rod for public anger and the target of muckrakers and trustbusters.',
      matters='Rockefeller sets the historical benchmark for wealth — the standard against which all later fortunes are measured.'),
]

# ==================================================================  PHASE 4 — THE RECKONING
PHASE_REPRESSION = [
    E('tarbell', '1902–1904', 'Ida Tarbell — the muckraker who exposed the octopus', ['CONTROVERSY', 'TURNING POINT'],
      'The journalist Ida Tarbell, whose own father had been ruined by Standard Oil, spends years investigating the company and publishes a devastating exposé in McClure’s Magazine. Meticulous and damning, “The History of the Standard Oil Company” lays bare the rebates, the ruthless tactics and the crushing of rivals. It turns public opinion decisively against Rockefeller and helps make “monopoly” a dirty word in America.',
      svg_row('Journalism turns the public against the trust', [
          {'n': 1, 'label': 'Tarbell’s long investigation', 'sub': 'her father ruined by Standard Oil', 'color': '#134e4a'},
          {'n': 2, 'label': 'The McClure’s exposé, 1902–04', 'sub': '“The History of the Standard Oil Company”', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Public opinion turns', 'sub': 'Rockefeller becomes the great villain', 'color': '#78350f'},
      ], edge_labels=['yields', 'so'], takeaway='One dogged reporter did what rival businessmen could not — she turned the whole nation against the octopus.', accent=AC),
      bg='By the 1900s a wave of investigative “muckraking” journalism was exposing Gilded Age abuses. Standard Oil was its greatest target.',
      people='<b>Ida Tarbell</b>, the pioneering investigative journalist; <b>Samuel McClure</b>, her editor; Rockefeller, whom she portrayed as cold and predatory.',
      what='In <b>McClure’s Magazine (1902–1904)</b>, Tarbell serialised <b>“The History of the Standard Oil Company,”</b> a meticulous, 19-part exposé of Standard’s rebates and ruthless methods. It became a classic of investigative journalism and cast Rockefeller as the archetypal robber baron.',
      crux='She reframed Standard not as efficient enterprise but as <b>predatory monopoly</b> — and did so with facts too detailed to dismiss.',
      conseq='Her work galvanised public and government pressure that led directly toward the antitrust reckoning.',
      matters='A free press can hold even the mightiest to account — Tarbell’s exposé is a founding example of investigative journalism’s power.'),

    E('antitrust', '1890–1909', 'The law closes in — the Sherman Act and the federal suit', ['CONTROVERSY', 'BATTLE'],
      'Public anger hardens into law. Congress passes the Sherman Antitrust Act in 1890, and after years of mounting pressure the federal government sues Standard Oil under it. Rockefeller, long retired from daily management, watches as the state he had once outmanoeuvred with rebates and trusts now marshals its full power to break his creation apart.',
      svg_stack('The state turns on the trust', [
          {'n': 1, 'label': 'Sherman Antitrust Act, 1890', 'sub': 'a new weapon against monopoly', 'color': '#134e4a'},
          {'n': 2, 'label': 'Federal suit filed, 1909', 'sub': 'US government vs Standard Oil', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Trust-busting era', 'sub': 'Roosevelt and Taft take on big business', 'color': '#78350f'},
      ], takeaway='The very concentration of power he pioneered summoned the countervailing power of the state to break it.', accent=AC),
      bg='The rise of the trusts spurred a political reaction. The <b>Sherman Antitrust Act of 1890</b> outlawed combinations “in restraint of trade,” and Progressive-era presidents took up trust-busting.',
      people='Presidents <b>Theodore Roosevelt</b> and <b>William Howard Taft</b>; the federal prosecutors; Rockefeller, semi-retired since the mid-1890s.',
      what='After public outrage crystallised, the <b>US government sued Standard Oil in 1909</b> under the <b>Sherman Act</b>, charging illegal monopoly. Standard had by 1899 reorganised as a holding company, Standard Oil of New Jersey, but could not escape the reckoning.',
      crux='The case pitted <b>private economic power against public political power</b> — and the state, roused at last, would prevail.',
      conseq='The suit climbed to the Supreme Court, whose 1911 verdict would dismember the empire.',
      matters='Concentrated power provokes its own check — Standard Oil’s dominance called forth the modern law of antitrust.'),

    E('breakup', '1911', 'Broken into 34 — the paradox of the great breakup', ['CONTROVERSY', 'TURNING POINT'],
      'In 1911 the Supreme Court rules that Standard Oil is an illegal monopoly and orders it dissolved into thirty-four separate companies. It is the most famous antitrust ruling in history. But in a delicious irony, Rockefeller — who held stock in every piece — grows even richer as the shares of the newly freed companies soar. The breakup that was meant to punish him instead multiplies his fortune.',
      svg_row('The breakup that made him richer', [
          {'n': 1, 'label': 'Supreme Court ruling, 1911', 'sub': 'Standard Oil an illegal monopoly', 'color': '#134e4a'},
          {'n': 2, 'label': 'Split into 34 companies', 'sub': 'Exxon, Mobil, Chevron, Amoco and more', 'color': '#a16207'},
          {'n': 3, 'label': 'His fortune soars', 'sub': 'he owns shares in every one — they surge', 'color': '#166534'},
      ], edge_labels=['orders', 'but'], takeaway='The state broke his empire into pieces — and each piece, rising in value, made the old man richer than ever.', accent=AC),
      bg='In <b>May 1911</b> the Supreme Court, in <i>Standard Oil Co. of New Jersey v. United States</i>, upheld the government and ordered the trust dissolved as an unreasonable restraint of trade.',
      people='Chief Justice <b>Edward White</b>, who wrote the opinion; the successor companies — ancestors of <b>Exxon, Mobil, Chevron, Amoco</b> and others; Rockefeller, shareholder in all.',
      what='The Court broke Standard Oil into <b>34 independent companies</b>. Because Rockefeller held stock across the whole, and the market valued the parts higher than the whole, his personal fortune <b>rose sharply</b> — the breakup enriched the man it was meant to humble.',
      crux='The verdict aimed to end his monopoly, but by <b>unlocking the value of the parts</b> it deepened his wealth — a lasting historical irony.',
      conseq='Freed of the fight and richer than ever, Rockefeller turned his full energies to giving his fortune away.',
      matters='Outcomes defy intentions — the greatest antitrust action in history handed its target his largest windfall.'),
]

# ==================================================================  PHASE 5 — THE SECOND ACT
PHASE_END = [
    E('philanthropy', '1890s–1913', 'Scientific philanthropy — giving as an industry', ['LEGACY', 'REFORM'],
      'In his second act, Rockefeller applies the same genius for system to giving it away. Guided by his adviser Frederick Gates, he rejects scattered “retail” charity for “wholesale” philanthropy — attacking the root causes of human misery through large, professionally managed institutions. He all but invents modern scientific philanthropy, the model later followed by every great foundation.',
      svg_stack('Charity remade as a science', [
          {'n': 1, 'label': 'Frederick Gates, adviser', 'sub': 'urges systematic, “wholesale” giving', 'color': '#134e4a'},
          {'n': 2, 'label': 'Attack root causes', 'sub': 'fund research and institutions, not alms', 'color': '#a16207'},
          {'n': 3, 'label': 'Scientific philanthropy', 'sub': 'the model for every modern foundation', 'color': '#166534'},
      ], takeaway='He gave as methodically as he had earned — turning charity from impulse into a disciplined, world-changing enterprise.', accent=AC),
      bg='Rockefeller had tithed all his life, but the sheer scale of his fortune demanded a new approach. His Baptist conviction that wealth was a trust to be used well drove him on.',
      people='His shrewd philanthropic adviser <b>Frederick T. Gates</b>; his son <b>John D. Rockefeller Jr.</b>, who devoted his life to the giving.',
      what='Guided by <b>Gates</b>, Rockefeller pioneered <b>“scientific philanthropy”</b> — large, expert-run institutions attacking the root causes of disease, ignorance and poverty, rather than piecemeal charity. It set the template for the modern foundation.',
      crux='He applied <b>business method to benevolence</b> — leverage, root causes, professional management, measurable results.',
      conseq='This philosophy produced a cascade of institutions that reshaped medicine, education and public health worldwide.',
      matters='Modern philanthropy is largely Rockefeller’s invention — the idea that giving should be strategic, systematic and root-directed.'),

    E('institutions', '1890–1913', 'The University, the Institute, the Foundation', ['LEGACY', 'TRIUMPH'],
      'Rockefeller’s money builds enduring monuments of learning and science. He founds the University of Chicago in 1890 and endows it into a great research university; he creates the Rockefeller Institute for Medical Research in 1901, America’s first great biomedical research centre; and in 1913 he charters the Rockefeller Foundation “to promote the well-being of mankind throughout the world.”',
      svg_row('Three pillars of a philanthropic empire', [
          {'n': 1, 'label': 'University of Chicago, 1890', 'sub': 'endowed into a great research university', 'color': '#134e4a'},
          {'n': 2, 'label': 'Rockefeller Institute, 1901', 'sub': 'first US biomedical research centre', 'color': '#a16207'},
          {'n': 3, 'label': 'Rockefeller Foundation, 1913', 'sub': '“the well-being of mankind throughout the world”', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He built institutions meant to outlast him by centuries — and they have, shaping science and learning to this day.', accent=AC),
      bg='Rockefeller sought permanent institutions, run by experts, that would carry his purposes far beyond his own life.',
      people='University president <b>William Rainey Harper</b>; the scientists of the Rockefeller Institute; the trustees of the Foundation.',
      what='He founded the <b>University of Chicago (1890)</b>, giving some <b>$35 million</b> by 1910; the <b>Rockefeller Institute for Medical Research (1901)</b>, now Rockefeller University; the <b>General Education Board (1902)</b>; and the <b>Rockefeller Foundation (1913)</b>, one of the largest philanthropies on earth.',
      crux='He endowed <b>institutions, not causes</b> — self-perpetuating engines of research and education that would do good long after he was gone.',
      conseq='These bodies drove breakthroughs in medicine, agriculture and public health across the globe for a century and more.',
      matters='Institutions outlive founders — Rockefeller’s greatest gifts were the organisations that still advance knowledge today.'),

    E('legacy', '1909–1937', 'Curing the hookworm — the two verdicts on a titan', ['LEGACY', 'DEATH'],
      'Rockefeller’s philanthropy attacks disease head-on: his Sanitary Commission campaigns to eradicate hookworm across the American South, and his Foundation funds pioneering work against yellow fever and builds public health worldwide. He gives away well over half a billion dollars before he dies in 1937, aged 97. History renders a divided verdict — ruthless monopolist, and great benefactor — and both are true.',
      svg_compare('The divided verdict on Rockefeller', {
          'head': 'The ruthless monopolist',
          'color': '#b91c1c',
          'items': [
              'Crushed and absorbed rivals — the Cleveland Massacre',
              'Secret railroad rebates and drawbacks',
              'Near-total ~90% monopoly of US oil',
              'Broke competitors who refused to sell',
              'Cast as the archetypal robber baron',
          ],
      }, {
          'head': 'The great philanthropist',
          'color': '#166534',
          'items': [
              'Pioneered modern scientific philanthropy',
              'Founded University of Chicago, the Foundation',
              'Helped eradicate hookworm; funded yellow-fever work',
              'Advanced medical research and public health',
              'Gave away over $530 million in his lifetime',
          ],
      }, verdict='Both verdicts are true — the same relentless will built the monopoly and the philanthropy.',
         takeaway='The coldest monopolist of his age became the greatest giver of his age — and history must hold both truths at once.', accent=AC),
      bg='In his long retirement Rockefeller poured his fortune and his organising genius into fighting disease and ignorance across America and the world.',
      people='The public-health workers of the <b>Rockefeller Sanitary Commission</b>; the researchers who battled <b>yellow fever</b>; his son and heir <b>John D. Rockefeller Jr.</b>',
      what='The <b>Rockefeller Sanitary Commission (1909–15)</b> waged a landmark campaign to eradicate <b>hookworm</b> across eleven Southern states; the Foundation funded pioneering work on <b>yellow fever</b> and global public health. Rockefeller gave away an estimated <b>$530–540 million</b>, and died on <b>23 May 1937</b>, aged 97, at Ormond Beach, Florida.',
      crux='The same <b>iron will and system</b> that built the monopoly built the philanthropy — the two acts are one character, not two.',
      conseq='He left a double legacy: the modern integrated corporation and antitrust law on one hand, modern scientific philanthropy and public health on the other.',
      matters='Great historical figures resist simple verdicts — Rockefeller was at once the era’s most ruthless monopolist and its most transformative philanthropist.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">John D. Rockefeller was the richest man in modern history and the most consequential businessman America ever produced. From a devout, frugal boyhood he rose through the ledger to build Standard Oil into a near-total monopoly — by ruthless efficiency, secret railroad rebates, and the crushing or absorbing of every rival. Reviled as the archetypal robber baron and broken up by the Supreme Court in 1911, he then reinvented himself as the pioneer of modern scientific philanthropy, giving away over half a billion dollars and reshaping medicine, education and public health. He is the ultimate study in <b>monopoly and efficiency, the concentration of wealth, and the duality of the ruthless builder and the great benefactor.</b></p>
<div class="ov-quote">“The ability to deal with people is as purchasable a commodity as sugar or coffee. And I pay more for that ability than for any other under the sun.”<span>— John D. Rockefeller</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A devout, frugal boy becomes a bookkeeper who worships the ledger → enters Cleveland oil refining and founds Standard Oil in 1870 → wields secret rebates and the Cleveland Massacre to build a ~90% monopoly → invents the Trust and becomes the richest man in modern history → is exposed by Ida Tarbell and broken into 34 companies in 1911 (which makes him richer still) → and spends his second act pioneering scientific philanthropy, giving away over $500 million.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🛢️</div><h4>The monopoly</h4><p>Built the greatest monopoly in history through efficiency and ruthlessness.</p></div>
  <div class="ov-card"><div class="i">🏛️</div><h4>Antitrust &amp; the corporation</h4><p>The Trust and its 1911 breakup shaped modern corporate law.</p></div>
  <div class="ov-card"><div class="i">💰</div><h4>The richest ever</h4><p>A fortune, relative to the economy, no one since has matched.</p></div>
  <div class="ov-card"><div class="i">🩺</div><h4>Scientific philanthropy</h4><p>Reinvented giving; funded medicine, education and public health.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Making</b><small> 1839–1863</small><p>A devout boy, a bookkeeper, into oil.</p></div>
  <div><b>2 · Building Standard Oil</b><small> 1870–1872</small><p>Efficiency, rebates, the Cleveland Massacre.</p></div>
  <div><b>3 · The Monopoly</b><small> 1872–1913</small><p>Ninety percent, the Trust, the richest man ever.</p></div>
  <div><b>4 · The Reckoning</b><small> 1890–1911</small><p>Tarbell, antitrust, the breakup into 34.</p></div>
  <div><b>5 · The Second Act</b><small> 1890–1937</small><p>Scientific philanthropy and public health.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Henry Flagler', 'role': 'partner & co-founder', 'color': '#134e4a',
     'bio': 'Rockefeller’s closest early partner, who helped structure Standard Oil and the crucial railroad rebate deals before building the Florida railways and resorts.',
     'rel': 'The indispensable partner in founding and building Standard Oil.'},
    {'name': 'Ida Tarbell', 'role': 'muckraking nemesis', 'color': '#b91c1c',
     'bio': 'The pioneering investigative journalist whose 1902–04 McClure’s exposé, “The History of the Standard Oil Company,” turned the nation against Rockefeller.',
     'rel': 'The reporter who exposed his methods and made him a villain.'},
    {'name': 'Frederick T. Gates', 'role': 'philanthropic adviser', 'color': '#166534',
     'bio': 'The Baptist minister turned adviser who shaped Rockefeller’s giving into systematic, “wholesale” scientific philanthropy.',
     'rel': 'The architect of his second act as a great philanthropist.'},
    {'name': 'John D. Rockefeller Jr.', 'role': 'son & heir', 'color': '#a16207',
     'bio': 'His only son, who devoted his life to managing and giving away the family fortune and to institutions like the Rockefeller Foundation.',
     'rel': 'The heir who carried on the philanthropy and the name.'},
    {'name': 'Samuel C. T. Dodd', 'role': 'company lawyer', 'color': '#3730a3',
     'bio': 'Standard Oil’s general counsel, who in 1882 devised the Standard Oil Trust — the legal innovation that became the template for big business.',
     'rel': 'The lawyer who invented the Trust that ran the empire.'},
]

KEY_EVENTS = [
    ('1839', 'Rockefeller born', 'A poor, devout family in upstate New York.'),
    ('1855', '“Job Day”', 'First job as a bookkeeper in Cleveland.'),
    ('1863', 'Enters oil refining', 'Bets on refining over drilling.'),
    ('1870', 'Standard Oil founded', 'Efficiency as a weapon.'),
    ('1872', 'Cleveland Massacre', 'Absorbs 22 of 26 rivals in weeks.'),
    ('1882', 'The Standard Oil Trust', 'Invents the modern corporation.'),
    ('1902–04', 'Tarbell’s exposé', 'Public opinion turns against him.'),
    ('1911', 'Supreme Court breakup', 'Split into 34 companies — he grows richer.'),
    ('1913', 'Rockefeller Foundation', 'Scientific philanthropy at global scale.'),
    ('1937', 'Death at Ormond Beach', 'Aged 97; gave away over $530 million.'),
]

MASTER = [
    {'year': '1839', 'age': 'born', 'phase': 'The Making', 'title': 'Born in New York', 'desc': 'A devout, frugal boyhood.'},
    {'year': '1870', 'age': 'age 31', 'phase': 'Building Standard Oil', 'title': 'Standard Oil founded', 'desc': 'Efficiency as a weapon.'},
    {'year': '1872', 'age': 'age 33', 'phase': 'Building Standard Oil', 'title': 'Cleveland Massacre', 'desc': 'Swallows the rivals whole.'},
    {'year': '1882', 'age': 'age 43', 'phase': 'The Monopoly', 'title': 'The Standard Oil Trust', 'desc': 'Invents the modern corporation.'},
    {'year': '1911', 'age': 'age 71', 'phase': 'The Reckoning', 'title': 'Broken into 34', 'desc': 'The breakup makes him richer.'},
    {'year': '1937', 'age': 'age 97', 'phase': 'The Second Act', 'title': 'Death of a titan', 'desc': 'Over $530 million given away.'},
]

SOURCES = [
    ('Britannica — John D. Rockefeller', 'https://www.britannica.com/biography/John-D-Rockefeller'),
    ('Rockefeller Archive Center — John D. Rockefeller Sr.', 'https://rockarch.org/resources/about-the-rockefellers/john-d-rockefeller-sr/'),
    ('Ron Chernow, “Titan: The Life of John D. Rockefeller, Sr.”', 'https://en.wikipedia.org/wiki/Titan:_The_Life_of_John_D._Rockefeller,_Sr.'),
    ('Britannica — Standard Oil', 'https://www.britannica.com/topic/Standard-Oil'),
    ('Wikipedia — John D. Rockefeller', 'https://en.wikipedia.org/wiki/John_D._Rockefeller'),
]

def build_meta():
    return {
        'pid': 'gm-rockefeller.html', 'kind': 'man', 'emoji': '🛢️', 'accent': AC,
        'name': 'John D. Rockefeller', 'years': '1839–1937', 'group': 'Modern Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The devout bookkeeper who built Standard Oil into the greatest monopoly in history and became the richest man in modern times — then reinvented himself as the pioneer of scientific philanthropy.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Making', 'type': 'timeline',
             'intro': 'A devout, frugal boyhood under a pious mother and a con-man father; a bookkeeper who worships the ledger; and a decisive bet on Cleveland oil refining.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · Building Standard Oil', 'type': 'timeline',
             'intro': 'He founds Standard Oil in 1870 and turns ruthless efficiency and secret railroad rebates into weapons — culminating in the Cleveland Massacre.', 'events': PHASE_POWER},
            {'id': 'order', 'label': '3 · The Monopoly', 'type': 'timeline',
             'intro': 'City by city he builds a near-total monopoly through horizontal and vertical integration, invents the Trust, and becomes the richest man in modern history.', 'events': PHASE_ORDER},
            {'id': 'repression', 'label': '4 · The Reckoning', 'type': 'timeline',
             'intro': 'Ida Tarbell’s exposé turns the nation against him, the Sherman Act closes in, and in 1911 the Supreme Court breaks Standard Oil into 34 companies — making him richer still.', 'events': PHASE_REPRESSION},
            {'id': 'end', 'label': '5 · The Second Act', 'type': 'timeline',
             'intro': 'In his long second act he pioneers modern scientific philanthropy — founding great institutions, helping eradicate hookworm, and giving away over half a billion dollars.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Drawn from standard biographies — above all Ron Chernow’s “Titan” — and encyclopaedic and archival sources; dollar figures for his fortune are widely cited estimates.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
