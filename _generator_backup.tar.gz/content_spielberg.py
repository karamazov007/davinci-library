# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Steven Spielberg.
The Arizona boy with an 8mm camera who invented the summer blockbuster and became the most influential filmmaker of his age."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b45309'  # cinematic amber-gold

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE ARIZONA BOY WITH A CAMERA
PHASE_ROOTS = [
    E('origins', '1946', 'Born in Cincinnati, raised in the desert', ['RISE', 'ORIGINS'],
      'Steven Allan Spielberg is born on 18 December 1946 in Cincinnati, Ohio, the eldest child of Arnold Spielberg, an electrical engineer at the dawn of the computer age, and Leah, a concert pianist — a restless Jewish family that follows the father’s work west, settling in the suburbs of Phoenix, Arizona, where the boy grows up an outsider bewitched by movies.',
      svg_row('An engineer’s son who wanted to make movies', [
          {'n': 1, 'label': 'Born Cincinnati, 18 Dec 1946', 'sub': 'father an engineer, mother a pianist', 'color': '#b45309'},
          {'n': 2, 'label': 'The family moves to Arizona', 'sub': 'a Jewish boy in suburban Phoenix', 'color': '#3730a3'},
          {'n': 3, 'label': 'An outsider drawn to the screen', 'sub': 'anxious, bullied, happiest at the movies', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He was a shy, bullied suburban kid who found in the movie camera both a refuge and a way to command the world around him.', accent=AC),
      bg='<b>Steven Allan Spielberg</b> was born on 18 December 1946 in Cincinnati, Ohio, to <b>Arnold Spielberg</b>, a pioneering computer engineer, and <b>Leah Adler</b>, a restaurateur and former concert pianist; the family later moved to Phoenix, Arizona.',
      people='his father <b>Arnold Spielberg</b>, whose engineering work moved the family; his mother <b>Leah</b>, an artistic free spirit; his three younger sisters.',
      what='Spielberg grew up a <b>self-conscious, anxious Jewish boy</b> in largely gentile Arizona suburbs, often bullied, and found escape in movies and in the home-movie camera his father used to film family camping trips.',
      crux='His imagination was <b>a defence against a world that made him feel apart</b> — the camera let him control and reorder reality.',
      conseq='Filmmaking became not a hobby but a compulsion; by adolescence he was already staging elaborate amateur productions.',
      matters='The outsider’s eye became the artist’s gift — Spielberg’s lifelong fascination with wonder, fear and belonging began in that Arizona boyhood.'),

    E('firelight', '1958–1964', 'The 8mm apprenticeship and “Firelight”', ['RISE', 'ORIGINS'],
      'Still a schoolboy, Spielberg makes war films and adventures on 8mm cine film, earning a Boy Scout merit badge with a short movie, and at seventeen he completes "Firelight," a two-and-a-quarter-hour science-fiction feature about alien lights in the sky — shown in a rented Phoenix cinema for one night, it turns a profit and rehearses the themes of his future work.',
      svg_stack('A teenager already making features', [
          {'n': 1, 'label': 'Home movies on 8mm film', 'sub': 'war pictures and adventures as a boy', 'color': '#b45309'},
          {'n': 2, 'label': '“Firelight” completed, 1964', 'sub': 'a 135-minute teenage sci-fi feature', 'color': '#3730a3'},
          {'n': 3, 'label': 'One night in a Phoenix theatre', 'sub': 'it turns a small profit', 'color': '#166534'},
      ], takeaway='Before he could vote he had directed a feature-length film — and its story of alien visitation prefigured Close Encounters and E.T.', accent=AC),
      bg='As a teenager in Arizona, Spielberg made increasingly ambitious amateur films, culminating in <b>“Firelight” (1964)</b>, a roughly 135-minute science-fiction film he shot for a few hundred dollars.',
      people='his family, who acted in and funded the films; the local Phoenix cinema that screened Firelight; his fellow scouts and schoolmates as his cast and crew.',
      what='He filmed war stories and adventures on <b>8mm</b>, won a photography merit badge with a short film, and completed <b>“Firelight,”</b> a feature about mysterious alien lights, screened for a single night in a rented theatre where it earned back its cost.',
      crux='He treated moviemaking as <b>a serious craft to master young</b>, learning storytelling, effects and audience response by doing.',
      conseq='These teenage films built the technical confidence and thematic obsessions — wonder, the sky, the unknown — that would define his career.',
      matters='Genius often rehearses in miniature — the man who reinvented the blockbuster had already been making crowd-pleasing features as a teenager.'),

    E('universal', '1968–1969', 'Rejected by film school, adopted by Universal', ['RISE', 'TURNING POINT'],
      'Turned down by the University of Southern California’s film school, Spielberg talks his way onto the Universal lot, and his polished 26-minute short "Amblin’" (1968) so impresses executives that they sign the 22-year-old to a seven-year television contract — the youngest director ever put under long-term deal by a major Hollywood studio.',
      svg_row('The back door onto the studio lot', [
          {'n': 1, 'label': 'Rejected by USC film school', 'sub': 'grades too low; he studies elsewhere', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The short film “Amblin’,” 1968', 'sub': 'a polished 26-minute calling card', 'color': '#b45309'},
          {'n': 3, 'label': 'A Universal TV contract, 1969', 'sub': 'signed at 22 — the youngest ever', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='Shut out of the front door of film school, he walked through the studio gate — and turned one short film into a professional career.', accent=AC),
      bg='Rejected by <b>USC</b>’s prestigious film school, Spielberg attended California State University, Long Beach, while haunting the <b>Universal Studios</b> lot as an unpaid observer.',
      people='the Universal executive <b>Sidney Sheinberg</b>, who signed him; producer Chuck Silvers, an early champion; the studio veterans he learned from on set.',
      what='His short <b>“Amblin’” (1968)</b>, a wordless romance shot professionally, won festival attention and impressed Universal’s Sidney Sheinberg, who signed Spielberg to a <b>seven-year contract</b>, making him one of the youngest directors ever put under term deal by a major studio.',
      crux='He proved talent could <b>leapfrog credentials</b> — a single accomplished film outweighed the film-school pedigree he lacked.',
      conseq='He began directing episodic television, learning the discipline of the studio system that would make him formidable.',
      matters='The industry’s gatekeepers can be bypassed by sheer craft — the rejected applicant became the studio’s prodigy.'),
]

# ==================================================================  PHASE 2 — THE BLOCKBUSTER IS BORN
PHASE_RISE = [
    E('duel', '1971', '“Duel” — terror on the highway', ['RISE', 'TRIUMPH'],
      'For Universal television Spielberg directs "Duel," a lean thriller in which a lone motorist is stalked by a faceless truck driver across the desert — its relentless suspense and cinematic polish so exceed TV norms that it is released in cinemas abroad, wins acclaim, and marks him out as a major directing talent at just twenty-four.',
      svg_stack('A TV movie that played like cinema', [
          {'n': 1, 'label': '“Duel” for Universal TV, 1971', 'sub': 'a man hunted by a menacing truck', 'color': '#b45309'},
          {'n': 2, 'label': 'Pure suspense, faceless menace', 'sub': 'craft far beyond television norms', 'color': '#3730a3'},
          {'n': 3, 'label': 'Released in cinemas overseas', 'sub': 'critics hail a new directing talent', 'color': '#166534'},
      ], takeaway='He turned a modest TV assignment into a masterclass in tension — and announced himself as a director of the first rank.', accent=AC),
      bg='After directing television episodes, Spielberg was given the TV movie <b>“Duel” (1971)</b>, adapted from a Richard Matheson story, about a salesman terrorised by an unseen truck driver.',
      people='the screenwriter <b>Richard Matheson</b>; star <b>Dennis Weaver</b> as the hunted motorist; the Universal executives who backed him.',
      what='Spielberg directed <b>“Duel”</b> with such visual command and sustained suspense that it transcended its TV origins; it was expanded and released <b>theatrically in Europe</b>, winning strong reviews and awards.',
      crux='He showed that <b>suspense is built by the camera and the cut</b>, not by dialogue or spectacle — a lesson he would soon scale up enormously.',
      conseq='The acclaim for Duel won him the chance to direct theatrical features, leading toward Jaws.',
      matters='Style announces itself early — the technique that would terrify audiences with a shark was already fully formed on a desert highway.'),

    E('jaws', '1975', '“Jaws” and the birth of the summer blockbuster', ['TRIUMPH', 'TURNING POINT'],
      'Handed a troubled production of a shark thriller off the New England coast, the twenty-eight-year-old Spielberg — plagued by a malfunctioning mechanical shark he is forced to hide — turns the film’s limitations into unbearable suspense; released in the summer of 1975, "Jaws" becomes the first film to gross over $100 million in North America, invents the wide-release summer blockbuster, and remakes Hollywood forever.',
      svg_row('The film that changed how Hollywood works', [
          {'n': 1, 'label': 'A chaotic shoot at sea, 1974', 'sub': 'the mechanical shark keeps failing', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The unseen shark becomes terror', 'sub': 'suspense from what you cannot see', 'color': '#b45309'},
          {'n': 3, 'label': 'Summer 1975: over $100M', 'sub': 'the first true summer blockbuster', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='A broken prop forced a masterstroke — hiding the shark created dread, and the wide summer release invented the modern blockbuster.', accent=AC),
      bg='Adapted from Peter Benchley’s novel, <b>“Jaws”</b> was a famously troubled shoot on the water off Martha’s Vineyard, plagued by a malfunctioning mechanical shark nicknamed “Bruce” and a ballooning budget.',
      people='producers <b>Richard Zanuck</b> and <b>David Brown</b>; composer <b>John Williams</b>, whose two-note theme became iconic; stars <b>Roy Scheider</b>, <b>Robert Shaw</b> and <b>Richard Dreyfuss</b>.',
      what='Forced to keep the faulty shark mostly hidden, Spielberg built terror from suggestion and John Williams’ score; released widely in <b>summer 1975</b>, <b>“Jaws”</b> became the <b>first film to earn more than $100 million</b> at the North American box office and grossed roughly <b>$470 million worldwide</b>.',
      crux='Its saturation summer release and vast marketing <b>created the blockbuster template</b> — the event movie that opens everywhere at once.',
      conseq='Jaws made Spielberg a superstar director at 28 and reshaped Hollywood’s business model around the summer tentpole.',
      matters='One film reset an industry — the way studios finance, market and release movies still bears the imprint of Jaws.'),

    E('closeencounters', '1977', '“Close Encounters” — wonder in the sky', ['TRIUMPH', 'IDEAS'],
      'With the clout won by Jaws, Spielberg writes and directs "Close Encounters of the Third Kind," his personal vision of benevolent alien contact — replacing the era’s fear of the unknown with awe and childlike wonder — a critical and commercial triumph that confirms him not merely as a showman but as a genuine cinematic author.',
      svg_stack('Aliens who come in peace', [
          {'n': 1, 'label': '“Close Encounters,” 1977', 'sub': 'written and directed by Spielberg', 'color': '#b45309'},
          {'n': 2, 'label': 'Wonder, not fear, of the unknown', 'sub': 'first contact as awe and light', 'color': '#3730a3'},
          {'n': 3, 'label': 'A hit that proved him an author', 'sub': 'his own story, his own vision', 'color': '#166534'},
      ], takeaway='He answered the fear of Jaws with wonder — and showed that a blockbuster could also be a deeply personal work of art.', accent=AC),
      bg='After Jaws, Spielberg realised a long-cherished project, <b>“Close Encounters of the Third Kind” (1977)</b>, which he wrote himself, about ordinary people drawn toward an alien landing.',
      people='star <b>Richard Dreyfuss</b>; French director <b>François Truffaut</b> in a rare acting role; composer <b>John Williams</b>, whose five-note motif is central to the plot.',
      what='He wrote and directed <b>“Close Encounters,”</b> reimagining alien contact as <b>benevolent and transcendent</b> rather than threatening; it was a major box-office success and earned multiple Oscar nominations.',
      crux='It fused <b>spectacle with sincere emotional and spiritual longing</b> — the awe of childhood projected onto the stars.',
      conseq='The film cemented the themes — wonder, suburban families, the yearning for contact — that run through his signature work.',
      matters='It marked him as an <b>auteur, not just an entertainer</b> — a director whose blockbusters carried a personal, recognisable vision.'),
]

# ==================================================================  PHASE 3 — THE GOLDEN RUN
PHASE_GOLD = [
    E('raiders', '1981', '“Raiders of the Lost Ark” with George Lucas', ['TRIUMPH', 'POLITICS'],
      'Joining forces with his friend George Lucas, fresh from Star Wars, Spielberg directs "Raiders of the Lost Ark," a rollicking homage to the adventure serials of their boyhood — introducing Indiana Jones, becoming the year’s top-grossing film, and launching one of cinema’s most beloved franchises.',
      svg_row('Two young titans reinvent the adventure film', [
          {'n': 1, 'label': 'Spielberg teams with Lucas', 'sub': 'a homage to 1930s serials', 'color': '#3730a3'},
          {'n': 2, 'label': '“Raiders of the Lost Ark,” 1981', 'sub': 'Indiana Jones is born', 'color': '#b45309'},
          {'n': 3, 'label': 'Top-grossing film of the year', 'sub': 'a blockbuster franchise begins', 'color': '#166534'},
      ], edge_labels=['make', 'and'], takeaway='Two boyhood movie lovers turned their love of pulp serials into Indiana Jones — the template for the modern action-adventure hero.', accent=AC),
      bg='Spielberg partnered with <b>George Lucas</b>, creator of Star Wars, on <b>“Raiders of the Lost Ark” (1981)</b>, conceived as a tribute to the cliffhanger serials of the 1930s and ’40s.',
      people='producer and story creator <b>George Lucas</b>; screenwriter <b>Lawrence Kasdan</b>; star <b>Harrison Ford</b> as archaeologist-adventurer Indiana Jones.',
      what='Spielberg directed <b>“Raiders,”</b> introducing <b>Indiana Jones</b>; it was the <b>highest-grossing film of 1981</b>, earned Best Picture and Best Director nominations, and spawned a hugely successful franchise.',
      crux='It showcased his mastery of <b>pace, set-piece and pure kinetic delight</b> — filmmaking as breathless, joyful momentum.',
      conseq='Three more Indiana Jones films (and a fourth decades later) followed, and the Lucas–Spielberg partnership defined 1980s popular cinema.',
      matters='He proved he could <b>manufacture joy on demand</b> — the adventure blockbuster as an engine of sheer entertainment.'),

    E('amblin', '1981', 'Founding Amblin Entertainment', ['RISE', 'REFORM'],
      'Naming it for the short film that launched him, Spielberg establishes Amblin Entertainment as his production company — a base from which he not only directs but produces a string of era-defining hits, from Gremlins to Back to the Future, wielding influence across Hollywood far beyond his own films.',
      svg_stack('Building a studio within the studios', [
          {'n': 1, 'label': 'Amblin Entertainment founded', 'sub': 'named for his 1968 short film', 'color': '#b45309'},
          {'n': 2, 'label': 'Director becomes power broker', 'sub': 'he produces as well as directs', 'color': '#3730a3'},
          {'n': 3, 'label': 'Back to the Future, Gremlins…', 'sub': 'hits that carry his imprint', 'color': '#166534'},
      ], takeaway='He turned personal success into institutional power — Amblin let him shape a whole slate of hits, not just the films he directed himself.', accent=AC),
      bg='At the height of his early success Spielberg formed his own company, <b>Amblin Entertainment</b>, headquartered on the Universal lot, to develop and produce films.',
      people='his producing partners <b>Kathleen Kennedy</b> and <b>Frank Marshall</b>; the directors he mentored and backed through Amblin.',
      what='<b>Amblin</b> became a powerhouse, producing hits such as <b>Gremlins (1984)</b>, <b>Back to the Future (1985)</b>, <b>Who Framed Roger Rabbit (1988)</b> and <b>An American Tail</b>, with Spielberg as producer or executive producer.',
      crux='He grasped that lasting influence came from <b>controlling production, not only directing</b> — building a brand and a talent pipeline.',
      conseq='Amblin gave him the independence and clout that would later let him co-found his own studio, DreamWorks.',
      matters='The most powerful creators build platforms — Amblin turned a director into one of Hollywood’s central power brokers.'),

    E('et', '1982', '“E.T. the Extra-Terrestrial” — the highest-grossing film', ['TRIUMPH', 'LEGACY'],
      'Drawing on the loneliness of his own childhood after his parents’ divorce, Spielberg makes "E.T. the Extra-Terrestrial," the tender story of a suburban boy who befriends a stranded alien — a film of overwhelming warmth that becomes, for over a decade, the highest-grossing film ever made and one of the most beloved movies of all time.',
      svg_row('A small story that conquered the world', [
          {'n': 1, 'label': 'Rooted in a lonely boyhood', 'sub': 'divorce, suburbia, an imaginary friend', 'color': '#3730a3'},
          {'n': 2, 'label': '“E.T.,” released summer 1982', 'sub': 'a boy and a stranded alien', 'color': '#b45309'},
          {'n': 3, 'label': 'Highest-grossing film ever', 'sub': '~$790M; the record for a decade', 'color': '#166534'},
      ], edge_labels=['becomes', 'and'], takeaway='His most personal film became his most universal — a story of a lonely child that the whole world took to its heart.', accent=AC),
      bg='Spielberg conceived <b>“E.T. the Extra-Terrestrial” (1982)</b> partly from memories of his parents’ divorce and the imaginary companion he had wished for as a lonely child.',
      people='screenwriter <b>Melissa Mathison</b>; child stars <b>Henry Thomas</b> and <b>Drew Barrymore</b>; composer <b>John Williams</b>, who won an Oscar for the score.',
      what='<b>“E.T.”</b> told of a boy who shelters a marooned alien; it became the <b>highest-grossing film of all time</b>, earning roughly <b>$790 million worldwide</b> and holding the record for about eleven years, with nine Oscar nominations.',
      crux='Its power lay in <b>emotional truth beneath the spectacle</b> — the ache of childhood loneliness given fantastical form.',
      conseq='E.T. sealed Spielberg’s reputation as the supreme popular storyteller of his generation.',
      matters='The universal hides in the personal — by filming his own childhood longing, he made a film that moved audiences everywhere.'),
]

# ==================================================================  PHASE 4 — REACHING FOR SERIOUSNESS
PHASE_SERIOUS = [
    E('colorpurple', '1985', '“The Color Purple” — the turn to drama', ['REFORM', 'IDEAS'],
      'Determined to be taken seriously as a dramatist, Spielberg adapts Alice Walker’s novel "The Color Purple," a searing story of Black women’s endurance in the segregated American South — a commercial success nominated for eleven Academy Awards, yet one that pointedly wins none, and for which he is not even nominated as director.',
      svg_compare('The showman reaches for gravity', {
          'head': 'What he attempted', 'color': '#b45309',
          'items': ['A serious literary adaptation', 'Black women’s lives in the Jim Crow South', 'Emotional drama over spectacle', 'A bid for critical respect'],
      }, {
          'head': 'How Hollywood answered', 'color': '#3730a3',
          'items': ['Eleven Oscar nominations', 'Zero wins on the night', 'No Best Director nomination for him', 'Doubts he could “do” serious film'],
      }, verdict='A commercial hit and an awards heartbreak — proof he had range, but not yet the establishment’s full respect.',
         takeaway='He proved he could direct grown-up drama and draw great performances — but the industry withheld the recognition he craved.', accent=AC),
      bg='Seeking to broaden beyond blockbusters, Spielberg adapted <b>Alice Walker</b>’s Pulitzer-winning novel <b>“The Color Purple” (1985)</b>, about a poor Black woman’s life in the early-20th-century South.',
      people='author <b>Alice Walker</b>; producer <b>Quincy Jones</b>; stars <b>Whoopi Goldberg</b> and <b>Oprah Winfrey</b> in breakthrough film roles.',
      what='<b>“The Color Purple”</b> was a box-office success and earned <b>eleven Academy Award nominations</b>, but <b>won none</b>, and Spielberg was conspicuously <b>not nominated for Best Director</b>.',
      crux='He was testing whether the master of spectacle could be <b>a serious chronicler of human suffering</b> — and the snub stung.',
      conseq='The film launched major careers and pushed him further toward dramatic, socially weighty subjects.',
      matters='Reinvention meets resistance — the awards snub only deepened his resolve to make films the establishment could not ignore.'),

    E('empire', '1987', '“Empire of the Sun” — a boy and a war', ['REFORM', 'IDEAS'],
      'Spielberg films J.G. Ballard’s autobiographical "Empire of the Sun," the story of a British boy separated from his parents and interned by the Japanese in wartime Shanghai — a visually magnificent, unsentimental study of lost innocence that stretches his range even as it underperforms at the box office.',
      svg_stack('War through a child’s eyes', [
          {'n': 1, 'label': '“Empire of the Sun,” 1987', 'sub': 'from J.G. Ballard’s memoir-novel', 'color': '#b45309'},
          {'n': 2, 'label': 'A boy interned in wartime China', 'sub': 'innocence lost amid catastrophe', 'color': '#3730a3'},
          {'n': 3, 'label': 'Acclaimed, but a box-office miss', 'sub': 'proof of ambition over easy success', 'color': '#166534'},
      ], takeaway='He kept pushing toward serious cinema — a sweeping, sober war film that traded box-office certainty for artistic reach.', accent=AC),
      bg='Spielberg adapted <b>J.G. Ballard</b>’s semi-autobiographical novel <b>“Empire of the Sun” (1987)</b>, about a privileged English boy caught in Japanese-occupied Shanghai during the Second World War.',
      people='novelist <b>J.G. Ballard</b>; a young <b>Christian Bale</b> in his breakthrough role; screenwriter <b>Tom Stoppard</b>.',
      what='<b>“Empire of the Sun”</b> was praised for its scale and visual beauty and earned several Oscar nominations, but <b>underperformed commercially</b> — a mature, demanding film about a child hardened by war.',
      crux='It confirmed his fascination with <b>childhood confronting a vast and terrible adult world</b>, now in a historical register.',
      conseq='It deepened his dramatic credentials and prefigured the wartime seriousness of Schindler’s List and Saving Private Ryan.',
      matters='Artists grow by risking failure — he chose difficult, unprofitable material precisely to expand what he could do.'),

    E('jurassic', '1993', '“Jurassic Park” — dinosaurs and a new record', ['TRIUMPH', 'LEGACY'],
      'Spielberg brings Michael Crichton’s cloned dinosaurs to life with groundbreaking computer-generated imagery, and "Jurassic Park" becomes a global phenomenon — the highest-grossing film of all time, surpassing E.T. — even as he shoots, almost simultaneously, the utterly different Schindler’s List.',
      svg_row('Dinosaurs that changed the movies', [
          {'n': 1, 'label': '“Jurassic Park,” 1993', 'sub': 'from Michael Crichton’s novel', 'color': '#b45309'},
          {'n': 2, 'label': 'Breakthrough CGI creatures', 'sub': 'digital effects come of age', 'color': '#3730a3'},
          {'n': 3, 'label': 'Highest-grossing film ever', 'sub': 'over $900M; surpasses E.T.', 'color': '#166534'},
      ], edge_labels=['with', 'and'], takeaway='He shattered his own box-office record and, with photorealistic digital dinosaurs, ushered cinema into the age of CGI.', accent=AC),
      bg='Adapting <b>Michael Crichton</b>’s bestseller <b>“Jurassic Park” (1993)</b>, Spielberg combined animatronics with pioneering <b>computer-generated imagery</b> from Industrial Light &amp; Magic to depict living dinosaurs.',
      people='author and co-screenwriter <b>Michael Crichton</b>; the effects teams at ILM; composer <b>John Williams</b>; stars <b>Sam Neill</b> and <b>Laura Dern</b>.',
      what='<b>“Jurassic Park”</b> became a worldwide sensation and the <b>highest-grossing film of all time</b> — over <b>$900 million</b> — displacing E.T., and won three Academy Awards for its technical achievements.',
      crux='Its seamless digital creatures marked <b>a turning point for visual effects</b>, proving CGI could create wholly convincing living things.',
      conseq='The film transformed the effects industry and gave Spielberg the commercial power he was about to spend on his most serious work.',
      matters='Technology serves wonder — the same year he broke box-office records, he used his clout to make an unflinching Holocaust drama.'),
]

# ==================================================================  PHASE 5 — THE MASTER RECOGNISED
PHASE_MASTER = [
    E('schindler', '1993', '“Schindler’s List” and the first Oscar', ['TRIUMPH', 'TURNING POINT'],
      'Confronting his own Jewish heritage and the memory of the Holocaust, Spielberg films "Schindler’s List" in stark black-and-white — the true story of a German industrialist who saved over a thousand Jews — a work of shattering moral seriousness that wins seven Academy Awards including Best Picture and, at last, his first Oscar for Best Director.',
      svg_stack('The film that won him respect at last', [
          {'n': 1, 'label': '“Schindler’s List,” 1993', 'sub': 'the Holocaust, in stark black-and-white', 'color': '#b45309'},
          {'n': 2, 'label': 'A true story of rescue', 'sub': 'over 1,000 Jews saved by Oskar Schindler', 'color': '#3730a3'},
          {'n': 3, 'label': 'Seven Oscars; first Best Director', 'sub': 'including Best Picture, 1994', 'color': '#166534'},
      ], takeaway='His most personal reckoning became his greatest triumph — the Holocaust drama that finally won him Hollywood’s highest honour.', accent=AC),
      bg='Spielberg adapted Thomas Keneally’s book to make <b>“Schindler’s List” (1993)</b>, about <b>Oskar Schindler</b>, a Nazi Party member whose factory saved more than 1,100 Jews from extermination.',
      people='star <b>Liam Neeson</b> as Schindler; <b>Ralph Fiennes</b> as the SS officer Amon Göth; <b>Ben Kingsley</b>; producer and Holocaust survivors who advised the film.',
      what='Shot largely in black-and-white in Poland, <b>“Schindler’s List”</b> won <b>seven Academy Awards</b>, including <b>Best Picture</b> and Spielberg’s <b>first Oscar for Best Director</b> — the recognition that had eluded him.',
      crux='He set aside spectacle for <b>unflinching moral witness</b>, confronting the Holocaust and his own Jewish identity directly.',
      conseq='The film is regarded as one of the greatest ever made and reoriented his career toward history and conscience.',
      matters='The entertainer became an artist of memory — Schindler’s List proved his gift could serve the gravest of subjects.'),

    E('shoah', '1994', 'The Shoah Foundation', ['REFORM', 'LEGACY'],
      'Moved by the survivors he met making Schindler’s List, Spielberg founds the Survivors of the Shoah Visual History Foundation to record and preserve the video testimonies of Holocaust survivors and witnesses — amassing over fifty thousand accounts in dozens of languages, one of the largest archives of eyewitness history ever assembled.',
      svg_row('Turning a film into a mission', [
          {'n': 1, 'label': 'Survivors met on set', 'sub': 'their testimonies must not be lost', 'color': '#3730a3'},
          {'n': 2, 'label': 'Shoah Foundation founded, 1994', 'sub': 'recording survivor testimony on video', 'color': '#b45309'},
          {'n': 3, 'label': '50,000+ testimonies archived', 'sub': 'in dozens of languages and countries', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='He converted the moral weight of Schindler’s List into permanence — an archive so the survivors’ words outlive them.', accent=AC),
      bg='Using profits and prestige from Schindler’s List, Spielberg established the <b>Survivors of the Shoah Visual History Foundation (1994)</b>, later based at the University of Southern California.',
      people='the Holocaust survivors who gave testimony; the historians and volunteers who conducted and catalogued interviews worldwide.',
      what='The foundation recorded and preserved <b>more than 50,000 video testimonies</b> from Holocaust survivors and other witnesses in over thirty languages, building one of the world’s great archives of oral history.',
      crux='He acted on the conviction that <b>memory is a moral duty</b> — that eyewitness truth must be captured before the generation is gone.',
      conseq='The archive became a vital resource for education and research and expanded to document other genocides.',
      matters='Art can beget stewardship — a filmmaker used his wealth and fame to safeguard the testimony of history’s victims.'),

    E('dreamworks', '1994', 'Co-founding DreamWorks SKG', ['RISE', 'POLITICS'],
      'In a landmark move, Spielberg joins Disney’s former studio chief Jeffrey Katzenberg and the music mogul David Geffen to launch DreamWorks SKG — the first major new Hollywood studio in decades — an audacious bid by three powers to build a fully independent film, animation and music empire.',
      svg_stack('Three moguls build a new studio', [
          {'n': 1, 'label': 'DreamWorks SKG founded, 1994', 'sub': 'the first new major studio in decades', 'color': '#b45309'},
          {'n': 2, 'label': 'Spielberg, Katzenberg, Geffen', 'sub': 'film, animation and music combined', 'color': '#3730a3'},
          {'n': 3, 'label': 'An independent Hollywood power', 'sub': 'creative control on their own terms', 'color': '#166534'},
      ], takeaway='He moved from studio prodigy to studio owner — betting that three creative powers could found a new major from scratch.', accent=AC),
      bg='In 1994 Spielberg co-founded <b>DreamWorks SKG</b> with former Disney studio chief <b>Jeffrey Katzenberg</b> and entertainment mogul <b>David Geffen</b> — the “S,” “K” and “G” of the name.',
      people='partners <b>Jeffrey Katzenberg</b> (animation and studio management) and <b>David Geffen</b> (music and business); the investors who backed the venture.',
      what='<b>DreamWorks</b> was the <b>first new major Hollywood studio in decades</b>, spanning live-action film, animation and music; it later produced Best Picture winners such as American Beauty and Gladiator and the Shrek franchise.',
      crux='It embodied the ambition to <b>own the means of production</b> — creative and financial independence at the highest level.',
      conseq='Though the studio faced financial strain and was eventually restructured, DreamWorks Animation became a lasting force.',
      matters='Even at the summit, he sought more control — the drive to build institutions, not just films, defined his maturity.'),

    E('ryan', '1998', '“Saving Private Ryan” and a second Oscar', ['TRIUMPH', 'TURNING POINT'],
      'Spielberg opens "Saving Private Ryan" with a harrowing, unprecedentedly visceral re-creation of the D-Day landings, then follows a squad sent to bring one soldier home — a film that redefines the war movie for a generation and wins him his second Academy Award for Best Director.',
      svg_row('Redefining the war film', [
          {'n': 1, 'label': '“Saving Private Ryan,” 1998', 'sub': 'the D-Day landings, unflinchingly', 'color': '#b45309'},
          {'n': 2, 'label': 'Visceral realism, human cost', 'sub': 'the chaos and terror of combat', 'color': '#3730a3'},
          {'n': 3, 'label': 'Second Best Director Oscar', 'sub': 'five Academy Awards in all', 'color': '#166534'},
      ], edge_labels=['and', 'so'], takeaway='His unsparing D-Day sequence reset the war film — and earned him a second directing Oscar and the status of elder master.', accent=AC),
      bg='For DreamWorks, Spielberg directed <b>“Saving Private Ryan” (1998)</b>, about a squad in Normandy ordered to retrieve a paratrooper whose brothers have been killed in action.',
      people='star <b>Tom Hanks</b> as Captain Miller; composer <b>John Williams</b>; the veterans and historians who advised the production.',
      what='Its opening <b>Omaha Beach</b> sequence was hailed for unprecedented, harrowing realism; <b>“Saving Private Ryan”</b> won <b>five Academy Awards</b>, including Spielberg’s <b>second Oscar for Best Director</b>.',
      crux='He rendered combat as <b>chaotic, terrifying and morally weighty</b> — honouring sacrifice without glamour.',
      conseq='It influenced war films and games for decades and, with Band of Brothers, deepened his engagement with World War II memory.',
      matters='He kept raising his own bar — two decades after Jaws, he was reinventing another genre and collecting Hollywood’s highest honour again.'),
]

# ==================================================================  PHASE 6 — THE ELDER STATESMAN
PHASE_LEGACY = [
    E('munich', '2005', '“Munich” — moral ambiguity and terror', ['IDEAS', 'REFORM'],
      'After the science-fiction of A.I. and Minority Report, Spielberg makes "Munich," a tense, morally troubled account of Israel’s covert reprisals after the 1972 Olympics massacre — a film that questions the costs of vengeance and shows the popular master willing to grapple with the hardest political questions.',
      svg_stack('The entertainer as moral questioner', [
          {'n': 1, 'label': '“Munich,” 2005', 'sub': 'after the 1972 Olympics massacre', 'color': '#b45309'},
          {'n': 2, 'label': 'The price of vengeance', 'sub': 'covert reprisals and their moral cost', 'color': '#3730a3'},
          {'n': 3, 'label': 'A Best Picture nominee', 'sub': 'praised and fiercely debated', 'color': '#166534'},
      ], takeaway='He used his standing to make deliberately uncomfortable political cinema — refusing easy answers about terror and revenge.', accent=AC),
      bg='In the 2000s Spielberg alternated blockbusters with serious work, including the dystopian <b>A.I. (2001)</b> and <b>Minority Report (2002)</b>, before directing <b>“Munich” (2005)</b>.',
      people='star <b>Eric Bana</b>; screenwriter <b>Tony Kushner</b>; the historical figures behind Israel’s Operation Wrath of God.',
      what='<b>“Munich”</b> dramatised Israel’s <b>covert campaign to hunt the perpetrators of the 1972 Olympic massacre</b>, portraying the moral corrosion of endless retaliation; it earned five Oscar nominations, including Best Picture.',
      crux='He insisted on <b>moral complexity over comfort</b> — depicting counter-terror as a cycle with a terrible human price.',
      conseq='The film drew both praise and controversy and marked a new, politically searching phase of his career.',
      matters='Popularity can buy the freedom to provoke — the most beloved director chose to unsettle his audience about violence and justice.'),

    E('lincoln', '2012', '“Lincoln” — history as moral drama', ['TRIUMPH', 'IDEAS'],
      'Spielberg turns to the final months of Abraham Lincoln’s presidency and the political struggle to pass the Thirteenth Amendment abolishing slavery — an intimate, dialogue-driven historical drama, anchored by Daniel Day-Lewis’s Oscar-winning performance, that becomes both a critical triumph and a surprise commercial hit.',
      svg_row('The abolition of slavery as a political thriller', [
          {'n': 1, 'label': '“Lincoln,” 2012', 'sub': 'the fight to pass the 13th Amendment', 'color': '#b45309'},
          {'n': 2, 'label': 'Day-Lewis wins Best Actor', 'sub': 'a definitive screen Lincoln', 'color': '#3730a3'},
          {'n': 3, 'label': 'Twelve Oscar nominations', 'sub': 'critical and commercial success', 'color': '#166534'},
      ], edge_labels=['with', 'and'], takeaway='He rendered the machinery of democracy as gripping drama — proof his late work could be as vital as his blockbusters.', accent=AC),
      bg='Spielberg directed <b>“Lincoln” (2012)</b>, focusing on the president’s efforts in early 1865 to secure House passage of the <b>Thirteenth Amendment</b> abolishing slavery.',
      people='star <b>Daniel Day-Lewis</b> as Lincoln; screenwriter <b>Tony Kushner</b>; co-stars <b>Sally Field</b> and <b>Tommy Lee Jones</b>.',
      what='<b>“Lincoln”</b> earned <b>twelve Academy Award nominations</b>, winning Best Actor for <b>Daniel Day-Lewis</b>; a talky, detailed political drama, it was also a strong box-office performer.',
      crux='He treated <b>the grind of legislative politics as high moral drama</b> — showing democracy’s greatest advances won by compromise and craft.',
      conseq='The film reaffirmed his standing as a serious chronicler of American history in his late career.',
      matters='Mastery need not fade — in his sixties he made one of his most acclaimed and unexpectedly popular films.'),

    E('bridgeofspies', '2015–', 'Bridge of Spies, The Fabelmans and the honours', ['LEGACY', 'TRIUMPH'],
      'In his later decades Spielberg keeps working prolifically — the Cold War drama "Bridge of Spies," the semi-autobiographical "The Fabelmans" about his own filmmaking boyhood — while accumulating the highest honours: AFI and Kennedy Center recognition, the Presidential Medal of Freedom, and a body of work that makes him the most commercially successful director in history.',
      svg_stack('The most successful director in history', [
          {'n': 1, 'label': 'Bridge of Spies, The Post, West Side Story', 'sub': 'a prolific late career', 'color': '#b45309'},
          {'n': 2, 'label': '“The Fabelmans,” 2022', 'sub': 'his own boyhood love of film', 'color': '#3730a3'},
          {'n': 3, 'label': 'Medal of Freedom; AFI; Kennedy Center', 'sub': 'the most commercially successful director ever', 'color': '#166534'},
      ], takeaway='He became the living definition of the great director — endlessly productive, garlanded with honours, and still making deeply personal films.', accent=AC),
      bg='Spielberg continued directing into his seventies, including <b>“Bridge of Spies” (2015)</b>, <b>The BFG</b>, <b>The Post (2017)</b>, <b>Ready Player One</b>, <b>West Side Story (2021)</b> and the autobiographical <b>“The Fabelmans” (2022)</b>.',
      people='frequent collaborators <b>Tom Hanks</b>, screenwriter <b>Tony Kushner</b>, and lifelong composer <b>John Williams</b>; the family whose story The Fabelmans retells.',
      what='He received the <b>AFI Life Achievement Award (1995)</b>, <b>Kennedy Center Honors (2006)</b> and the <b>Presidential Medal of Freedom (2015)</b>; his films have grossed many billions of dollars, making him the <b>highest-grossing director of all time</b>.',
      crux='His career fused <b>unmatched popular success with genuine artistic ambition</b> — the rare figure equally at home with dinosaurs and the Holocaust.',
      conseq='He reshaped popular cinema, mentored a generation of filmmakers, and left an archive of the human record through the Shoah Foundation.',
      matters='Few artists so define an era — Spielberg made moviegoing itself feel wondrous, and did it for half a century.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Steven Spielberg is the filmmaker who reinvented what a movie could be at the box office — and then proved a blockbuster director could also be a serious artist. An anxious, bullied Jewish boy in suburban Arizona, he made feature films as a teenager, talked his way onto the Universal lot, and with <b>Jaws (1975)</b> invented the modern summer blockbuster. Across five decades he gave the world Indiana Jones and E.T., broke his own box-office records with Jurassic Park, and confronted the Holocaust in Schindler’s List and war in Saving Private Ryan — winning two Best Director Oscars and founding both Amblin and DreamWorks. He is the ultimate study in <b>wonder, craft, and the marriage of popularity with art.</b></p>
<div class="ov-quote">“I dream for a living.”<span>— Steven Spielberg</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A movie-mad Arizona boy makes features on 8mm and lands a Universal contract → “Duel” and then “Jaws” invent the summer blockbuster → Close Encounters, Raiders and E.T. make him the great popular storyteller → he reaches for drama with The Color Purple and Empire of the Sun → Jurassic Park breaks records while Schindler’s List wins him his first Oscar → he founds DreamWorks and wins a second Oscar for Saving Private Ryan → and as an elder master makes Munich, Lincoln and The Fabelmans.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🦈</div><h4>Invented the blockbuster</h4><p>Jaws created the wide-release summer event movie that rules Hollywood.</p></div>
  <div class="ov-card"><div class="i">✨</div><h4>The poet of wonder</h4><p>E.T. and Close Encounters turned childhood awe into universal cinema.</p></div>
  <div class="ov-card"><div class="i">🕯️</div><h4>Artist of memory</h4><p>Schindler’s List and the Shoah Foundation gave witness to the Holocaust.</p></div>
  <div class="ov-card"><div class="i">🏛️</div><h4>A studio builder</h4><p>Amblin and DreamWorks made him a power broker, not just a director.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Arizona Boy</b><small> 1946–1969</small><p>A movie-mad childhood, 8mm features, and the Universal contract.</p></div>
  <div><b>2 · The Blockbuster</b><small> 1971–1977</small><p>Duel, Jaws and Close Encounters remake Hollywood.</p></div>
  <div><b>3 · The Golden Run</b><small> 1981–1982</small><p>Raiders, Amblin and E.T. — the supreme popular storyteller.</p></div>
  <div><b>4 · Reaching for Drama</b><small> 1985–1993</small><p>The Color Purple, Empire of the Sun and Jurassic Park.</p></div>
  <div><b>5 · The Master</b><small> 1993–1998</small><p>Schindler’s List, the Shoah Foundation, DreamWorks, Saving Private Ryan.</p></div>
  <div><b>6 · Elder Statesman</b><small> 2005–</small><p>Munich, Lincoln, The Fabelmans and the honours.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'George Lucas', 'role': 'friend & collaborator', 'color': '#b45309',
     'bio': 'The creator of Star Wars who teamed with Spielberg on Raiders of the Lost Ark (1981) and the Indiana Jones films, a defining partnership of 1980s cinema.',
     'rel': 'His friend and creative partner on the Indiana Jones franchise.'},
    {'name': 'John Williams', 'role': 'composer', 'color': '#3730a3',
     'bio': 'The composer of nearly all Spielberg’s films from The Sugarland Express onward, whose scores for Jaws, E.T., Jurassic Park and Schindler’s List are inseparable from the images.',
     'rel': 'His lifelong musical collaborator across five decades.'},
    {'name': 'Kathleen Kennedy', 'role': 'producing partner', 'color': '#166534',
     'bio': 'Co-founder of Amblin Entertainment and producer of many Spielberg films, who became one of Hollywood’s most powerful executives.',
     'rel': 'His key producing partner and co-founder of Amblin.'},
    {'name': 'Katzenberg & Geffen', 'role': 'DreamWorks partners', 'color': '#a16207',
     'bio': 'Jeffrey Katzenberg, Disney’s former studio chief, and David Geffen, the music and media mogul, who joined Spielberg to found DreamWorks SKG in 1994.',
     'rel': 'His partners in building a new Hollywood studio.'},
    {'name': 'Tom Hanks', 'role': 'leading collaborator', 'color': '#b91c1c',
     'bio': 'The star of Saving Private Ryan, The Terminal, Bridge of Spies and The Post, and co-producer with Spielberg of the WWII series Band of Brothers.',
     'rel': 'His frequent star and creative ally in later decades.'},
]

KEY_EVENTS = [
    ('1946', 'Born in Cincinnati', 'Raised in suburban Phoenix, Arizona.'),
    ('1964', '“Firelight” completed', 'A feature-length teenage sci-fi film.'),
    ('1969', 'Universal TV contract', 'Signed at 22 after the short “Amblin’.”'),
    ('1971', '“Duel”', 'A TV movie that played like cinema.'),
    ('1975', '“Jaws”', 'Invents the summer blockbuster; first $100M film.'),
    ('1977', '“Close Encounters”', 'Alien contact as wonder, not fear.'),
    ('1981', '“Raiders of the Lost Ark”', 'With Lucas; Amblin founded.'),
    ('1982', '“E.T.”', 'Highest-grossing film for over a decade.'),
    ('1985', '“The Color Purple”', '11 Oscar nominations, no wins.'),
    ('1993', '“Jurassic Park” & “Schindler’s List”', 'A record-breaker and his first Oscar.'),
    ('1994', 'DreamWorks & Shoah Foundation', 'A new studio; an archive of survivors.'),
    ('1998', '“Saving Private Ryan”', 'Second Best Director Oscar.'),
    ('2012', '“Lincoln”', 'The 13th Amendment as moral drama.'),
    ('2022', '“The Fabelmans”', 'His own filmmaking boyhood on screen.'),
]

MASTER = [
    {'year': '1946', 'age': 'born', 'phase': 'Arizona Boy', 'title': 'Born in Cincinnati', 'desc': 'A movie-mad childhood in Arizona.'},
    {'year': '1969', 'age': 'age 22', 'phase': 'Arizona Boy', 'title': 'Universal contract', 'desc': 'The short “Amblin’” wins a deal.'},
    {'year': '1975', 'age': 'age 28', 'phase': 'The Blockbuster', 'title': 'Jaws', 'desc': 'The summer blockbuster is born.'},
    {'year': '1982', 'age': 'age 35', 'phase': 'Golden Run', 'title': 'E.T.', 'desc': 'Highest-grossing film for a decade.'},
    {'year': '1993', 'age': 'age 46', 'phase': 'The Master', 'title': 'Jurassic Park & Schindler’s List', 'desc': 'A record, then his first Oscar.'},
    {'year': '1994', 'age': 'age 47', 'phase': 'The Master', 'title': 'DreamWorks & Shoah Foundation', 'desc': 'A new studio; survivor testimony.'},
    {'year': '1998', 'age': 'age 51', 'phase': 'The Master', 'title': 'Saving Private Ryan', 'desc': 'Second Best Director Oscar.'},
    {'year': '2012', 'age': 'age 65', 'phase': 'Elder Statesman', 'title': 'Lincoln', 'desc': 'History as moral drama.'},
    {'year': '2022', 'age': 'age 75', 'phase': 'Elder Statesman', 'title': 'The Fabelmans', 'desc': 'His own story, at last.'},
]

SOURCES = [
    ('Britannica — Steven Spielberg', 'https://www.britannica.com/biography/Steven-Spielberg'),
    ('Wikipedia — Steven Spielberg', 'https://en.wikipedia.org/wiki/Steven_Spielberg'),
    ('Wikipedia — Jaws (film)', 'https://en.wikipedia.org/wiki/Jaws_(film)'),
    ('Wikipedia — Schindler’s List', 'https://en.wikipedia.org/wiki/Schindler%27s_List'),
    ('AFI — Steven Spielberg (Life Achievement Award)', 'https://www.afi.com/award/steven-spielberg/'),
    ('USC Shoah Foundation — About', 'https://sfi.usc.edu/about'),
    ('Academy Awards — Steven Spielberg (Oscars database)', 'https://www.oscars.org/oscars/ceremonies/1994'),
]

def build_meta():
    return {
        'pid': 'gm-spielberg.html', 'kind': 'man', 'emoji': '🎬', 'accent': AC,
        'name': 'Steven Spielberg', 'years': 'b. 1946', 'group': 'Artists & Filmmakers',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Arizona boy with an 8mm camera who invented the summer blockbuster with Jaws, gave the world E.T. and Indiana Jones, confronted the Holocaust in Schindler’s List, and became the most commercially successful and influential director in film history.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'roots', 'label': '1 · Arizona Boy', 'type': 'timeline',
             'intro': 'An anxious, movie-mad Jewish boy in suburban Arizona makes feature films as a teenager, is rejected by film school, and talks his way into a Universal contract.', 'events': PHASE_ROOTS},
            {'id': 'rise', 'label': '2 · The Blockbuster', 'type': 'timeline',
             'intro': 'From the TV thriller “Duel” to the record-shattering “Jaws” and the wonder of “Close Encounters,” he remakes Hollywood around the summer event movie.', 'events': PHASE_RISE},
            {'id': 'gold', 'label': '3 · The Golden Run', 'type': 'timeline',
             'intro': 'Raiders of the Lost Ark with George Lucas, the founding of Amblin, and E.T. make him the supreme popular storyteller of his generation.', 'events': PHASE_GOLD},
            {'id': 'serious', 'label': '4 · Reaching for Drama', 'type': 'timeline',
             'intro': 'Determined to be taken seriously, he turns to grown-up drama with The Color Purple and Empire of the Sun — then breaks every record with Jurassic Park.', 'events': PHASE_SERIOUS},
            {'id': 'master', 'label': '5 · The Master', 'type': 'timeline',
             'intro': 'Schindler’s List wins him his first Oscar; he founds the Shoah Foundation and DreamWorks, and Saving Private Ryan wins a second — the entertainer becomes a master.', 'events': PHASE_MASTER},
            {'id': 'legacy', 'label': '6 · Elder Statesman', 'type': 'timeline',
             'intro': 'In his later decades he makes politically searching and deeply personal films — Munich, Lincoln, The Fabelmans — while collecting Hollywood’s highest honours.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; box-office figures are contemporary worldwide gross estimates and vary by source and inflation adjustment.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
