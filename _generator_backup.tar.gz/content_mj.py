# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Michael Jackson.
The King of Pop — the child star who became the best-selling artist of all time,
whose monumental artistry and painful controversies are presented here with care."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#a21caf'  # pop-icon fuchsia

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE CHILD STAR
PHASE_CHILD = [
    E('gary', '1958–1968', 'Gary, Indiana — a childhood built into a stage act', ['RISE', 'ORIGINS'],
      'Born the seventh of nine children in the steel town of Gary, Indiana, Michael Jackson is drilled into a performer before he is ten — his father Joe Jackson running gruelling rehearsals with a discipline many later called abusive, forging a prodigy and, at the same time, a lost childhood.',
      svg_stack('A prodigy forged under a hard father', [
          {'n': 1, 'label': 'Born in Gary, Indiana, 1958', 'sub': 'seventh of nine children in a working-class family', 'color': '#a21caf'},
          {'n': 2, 'label': 'Joe Jackson’s harsh drilling', 'sub': 'relentless rehearsals; a discipline later called abusive', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A prodigy — and a lost childhood', 'sub': 'a dazzling talent trained at the cost of a normal boyhood', 'color': '#78350f'},
      ], takeaway='The same iron discipline that built an extraordinary performer also robbed Michael of the ordinary childhood he mourned all his life.', accent=AC),
      bg='<b>Michael Joseph Jackson</b> was born on 29 August 1958 in Gary, Indiana, the seventh of nine children of Joe and Katherine Jackson in a cramped working-class home.',
      people='his father <b>Joe Jackson</b>, the driving manager; his mother <b>Katherine</b>; his brothers, with whom he sang.',
      what='From early childhood Michael was drilled as a performer by his father through <b>gruelling rehearsals and a harsh discipline</b> that Michael later described as frightening and, at times, abusive — even as it sharpened a prodigious talent.',
      crux='His genius and his wounds shared one source — a <b>childhood turned into a stage act</b> under a demanding, punishing father.',
      conseq='By the mid-1960s the youngest brothers had become a polished act, ready for a professional breakthrough.',
      matters='Extraordinary talent is often forged under pressure — but Michael’s life shows the human cost when a childhood is sacrificed to a career.'),

    E('motown', '1969–1971', 'The Jackson 5 and Motown — an instant sensation', ['RISE', 'TRIUMPH'],
      'Signed to Berry Gordy’s Motown, the Jackson 5 explode onto the charts in 1969 with "I Want You Back" — an eleven-year-old Michael singing lead — and become an instant phenomenon, sending their first four singles to number one and making Michael a household name before adolescence.',
      svg_row('A breakout child star', [
          {'n': 1, 'label': 'Signed to Motown, 1969', 'sub': 'Berry Gordy takes on the Jackson 5', 'color': '#a21caf'},
          {'n': 2, 'label': '“I Want You Back” hits', 'sub': 'young Michael on lead vocal; an instant classic', 'color': '#166534'},
          {'n': 3, 'label': 'Four straight No. 1s', 'sub': 'a national sensation before Michael turns twelve', 'color': '#a16207'},
      ], edge_labels=['then', 'so'], takeaway='Michael was a chart-topping star before adolescence — the most electrifying child performer of his generation.', accent=AC),
      bg='In 1968–69 the Jackson 5 signed with <b>Motown Records</b> and moved toward Detroit-honed stardom, with Michael as the group’s magnetic young frontman.',
      people='<b>Berry Gordy</b>, Motown’s founder; the brothers <b>Jackie, Tito, Jermaine and Marlon</b>; Michael on lead.',
      what='The Jackson 5 debuted in 1969 with <b>“I Want You Back”</b> and sent their first four singles — including “ABC” and “I’ll Be There” — to <b>number one</b>, an unprecedented start that made Michael a star as a child.',
      crux='His gift was undeniable from the start — a <b>preternatural voice and stage presence</b> in a boy barely eleven years old.',
      conseq='Michael’s fame as a child set impossibly high expectations and previewed the solo giant he would become.',
      matters='Few artists peak as children and again as adults — Michael’s Motown years launched one of history’s most sustained careers in pop.'),

    E('gottobethere', '1971–1975', 'First solo steps — and outgrowing Motown', ['RISE', 'REFORM'],
      'Even as the group thrives, Motown launches Michael as a solo act — "Got to Be There" and the chart-topping "Ben" hint at his individual star — but by the mid-1970s the brothers, chafing at Motown’s tight control, leave for Epic Records, setting Michael on the path to reinvention.',
      svg_stack('The solo star emerges', [
          {'n': 1, 'label': 'Solo singles begin, 1971–72', 'sub': '“Got to Be There”; “Ben” reaches No. 1', 'color': '#a21caf'},
          {'n': 2, 'label': 'Chafing at Motown’s control', 'sub': 'the group wants creative freedom', 'color': '#a16207'},
          {'n': 3, 'label': 'Move to Epic Records, 1976', 'sub': 'a new label opens the door to reinvention', 'color': '#166534'},
      ], takeaway='Michael’s first solo hits revealed a star who would soon eclipse the group — and the move to Epic gave him room to grow.', accent=AC),
      bg='While the Jackson 5 kept recording, Motown built Michael a parallel <b>solo career</b> in the early 1970s, testing the individual appeal that would soon define him.',
      people='<b>Berry Gordy</b> and Motown; Michael’s brothers; the new team at <b>Epic/CBS Records</b>.',
      what='Michael’s solo singles <b>“Got to Be There” (1971)</b> and <b>“Ben” (1972, a No. 1 hit)</b> showed his individual promise; frustrated with Motown’s creative control, the brothers signed with <b>Epic Records in 1976</b>.',
      crux='He was already <b>bigger than the group</b> — and needed creative freedom to become the artist he imagined.',
      conseq='The move to Epic, and a fateful meeting with producer Quincy Jones, set up his adult breakthrough.',
      matters='Great artists outgrow the frameworks that made them — Michael’s search for creative control drove his leap to solo greatness.'),
]

# ==================================================================  PHASE 2 — THE SOLO KING
PHASE_KING = [
    E('offthewall', '1979', '“Off the Wall” — the adult solo breakthrough', ['RISE', 'TURNING POINT'],
      'Teaming with producer Quincy Jones, whom he met filming "The Wiz", Michael releases "Off the Wall" in 1979 — a lush fusion of disco, funk and pop that announces him as a mature solo artist, spins off four top-ten hits, and hints at the revolution to come.',
      svg_row('A grown-up artist arrives', [
          {'n': 1, 'label': 'Meets Quincy Jones', 'sub': 'on the set of “The Wiz” (1978)', 'color': '#a21caf'},
          {'n': 2, 'label': '“Off the Wall” released, 1979', 'sub': 'disco, funk and pop, immaculately produced', 'color': '#166534'},
          {'n': 3, 'label': 'Four top-ten hits', 'sub': 'a mature solo star steps out of the group', 'color': '#a16207'},
      ], edge_labels=['so', 'yields'], takeaway='With Quincy Jones, Michael reinvented himself as a sophisticated solo artist — a dress rehearsal for the phenomenon of Thriller.', accent=AC),
      bg='After playing the Scarecrow in the 1978 film <b>“The Wiz”</b>, Michael met musical director <b>Quincy Jones</b>, who agreed to produce his next solo album.',
      people='producer <b>Quincy Jones</b>; songwriters including <b>Rod Temperton</b>; Michael, now stepping out on his own.',
      what='<b>“Off the Wall” (1979)</b> fused disco, funk, soul and pop into a polished adult sound, spinning off four top-ten singles including “Don’t Stop ’Til You Get Enough” and “Rock with You.”',
      crux='He proved he could be a <b>self-defining solo artist</b>, not just the boy from the Jackson 5.',
      conseq='Its success — and Michael’s hunger for more — set the stage for the record-shattering album that followed.',
      matters='Reinvention is the engine of a long career — Off the Wall turned a former child star into a serious adult artist.'),

    E('thriller', '1982', '“Thriller” — the best-selling album of all time', ['TRIUMPH', 'TURNING POINT'],
      'Reuniting with Quincy Jones, Michael releases "Thriller" in 1982 — a genre-blending masterwork that becomes the best-selling album in history, produces an astonishing seven top-ten singles, and turns Michael Jackson into the biggest star on Earth.',
      svg_stack('The album that broke every record', [
          {'n': 1, 'label': '“Thriller” released, 1982', 'sub': 'Quincy Jones produces; pop, rock, funk, R&B fused', 'color': '#a21caf'},
          {'n': 2, 'label': 'Seven top-ten singles', 'sub': '“Billie Jean,” “Beat It,” “Thriller” and more', 'color': '#166534'},
          {'n': 3, 'label': 'Best-selling album ever', 'sub': 'tens of millions sold worldwide; global fame', 'color': '#a16207'},
      ], takeaway='Thriller is the best-selling album in history — the peak of Michael’s artistry and the moment he became a worldwide phenomenon.', accent=AC),
      bg='In 1982, again produced by <b>Quincy Jones</b>, Michael released <b>“Thriller”</b>, blending pop, rock, funk and R&B into a album of near-universal appeal.',
      people='<b>Quincy Jones</b>; guitarist <b>Eddie Van Halen</b> on “Beat It”; songwriter <b>Rod Temperton</b>; Michael at his creative peak.',
      what='<b>“Thriller” (1982)</b> became the <b>best-selling album of all time</b>, generating seven top-ten singles — among them “Billie Jean,” “Beat It” and the title track — and dominating the charts and airwaves.',
      crux='It was <b>artistry and mass appeal in perfect union</b> — an album that crossed every genre and demographic line.',
      conseq='Thriller’s scale gave Michael the power and platform to transform music video and live performance.',
      matters='Thriller redefined what a pop album could achieve commercially and creatively — a benchmark no record has surpassed.'),

    E('moonwalk', '1983', 'The moonwalk, the videos, and breaking MTV’s barrier', ['TRIUMPH', 'REFORM'],
      'Michael turns music video into an art form — the cinematic "Thriller" short film and the "Billie Jean" clip help break MTV’s de facto racial barrier — and on the "Motown 25" special in 1983 he debuts the moonwalk, a single dance move that seals his legend.',
      svg_row('Reinventing performance itself', [
          {'n': 1, 'label': 'Groundbreaking videos', 'sub': '“Billie Jean” and the cinematic “Thriller” film', 'color': '#a21caf'},
          {'n': 2, 'label': 'Breaks MTV’s barrier', 'sub': 'heavy rotation opens the channel to Black artists', 'color': '#166534'},
          {'n': 3, 'label': 'The moonwalk, Motown 25', 'sub': 'a single dance move seals the legend, 1983', 'color': '#a16207'},
      ], edge_labels=['and', 'then'], takeaway='Michael made the music video an art form and his dancing a global language — the moonwalk became an icon in a single night.', accent=AC),
      bg='With Thriller’s clout, Michael invested in <b>cinematic music videos</b> at a moment when the young MTV rarely played Black artists in heavy rotation.',
      people='director <b>John Landis</b> (“Thriller”); the <b>Motown 25</b> producers; MTV; the millions who watched.',
      what='The <b>“Billie Jean”</b> and <b>“Thriller”</b> videos helped break <b>MTV’s de facto racial barrier</b>; on the <b>“Motown 25” special (aired 1983)</b> Michael debuted the <b>moonwalk</b> during “Billie Jean,” an instantly iconic moment.',
      crux='He turned promotion into <b>art and spectacle</b> — and used his stardom to open doors that had been closed to Black performers.',
      conseq='Video and dance became central to his identity, driving his fame to unprecedented global heights.',
      matters='Michael reshaped the visual language of pop — the modern music video and the dance-driven pop star both bear his imprint.'),
]

# ==================================================================  PHASE 3 — GLOBAL SUPERSTARDOM
PHASE_GLOBAL = [
    E('wearetheworld', '1985', '“We Are the World” — the humanitarian anthem', ['TRIUMPH', 'REFORM'],
      'At the height of his fame Michael co-writes "We Are the World" with Lionel Richie — a charity single recorded by a supergroup of American stars to fight African famine — one of the best-selling singles ever and a landmark of celebrity humanitarianism.',
      svg_row('Star power turned to charity', [
          {'n': 1, 'label': 'Co-writes with Lionel Richie', 'sub': 'a benefit song for African famine relief', 'color': '#a21caf'},
          {'n': 2, 'label': 'USA for Africa records it, 1985', 'sub': 'dozens of stars in one studio session', 'color': '#166534'},
          {'n': 3, 'label': 'A global charity anthem', 'sub': 'among the best-selling singles of all time', 'color': '#a16207'},
      ], edge_labels=['then', 'so'], takeaway='Michael used the biggest platform in music for humanitarian ends — pioneering the celebrity charity single on a global scale.', accent=AC),
      bg='In 1985, moved by the Ethiopian famine, American musicians organised <b>USA for Africa</b> to record a charity single for famine relief.',
      people='co-writer <b>Lionel Richie</b>; producer <b>Quincy Jones</b>; the dozens of stars of USA for Africa.',
      what='Michael <b>co-wrote and performed “We Are the World” (1985)</b> with Lionel Richie; recorded by a supergroup of American artists, it became one of the <b>best-selling singles ever</b> and raised vast sums for famine relief.',
      crux='He channelled his fame into <b>global philanthropy</b>, helping define modern celebrity humanitarianism.',
      conseq='It cemented his image as a benevolent superstar and a leader among his peers.',
      matters='Fame can be turned to public good — “We Are the World” showed how a superstar’s reach could mobilise millions for a cause.'),

    E('bad', '1987', '“Bad” — the tour and the record-breaking run', ['TRIUMPH', 'REFORM'],
      'Michael follows Thriller with "Bad" in 1987 — an album that yields five consecutive number-one singles, a first in chart history — and launches his first solo world tour, a global spectacle of dance, showmanship and pyrotechnics that plays to millions.',
      svg_stack('The superstar as global spectacle', [
          {'n': 1, 'label': '“Bad” released, 1987', 'sub': 'again with Quincy Jones; harder, edgier pop', 'color': '#a21caf'},
          {'n': 2, 'label': 'Five No. 1 singles', 'sub': 'an unprecedented chart feat from one album', 'color': '#166534'},
          {'n': 3, 'label': 'First solo world tour', 'sub': 'a global spectacle seen by millions', 'color': '#a16207'},
      ], takeaway='With Bad, Michael turned recorded success into a live global phenomenon — the template for the modern stadium pop spectacle.', accent=AC),
      bg='After Thriller’s impossible act to follow, Michael released <b>“Bad” (1987)</b>, his third and final album with Quincy Jones, aiming for an edgier, harder-driving sound.',
      people='<b>Quincy Jones</b>; Michael’s expanding creative team; the worldwide audience of the <b>Bad World Tour</b>.',
      what='<b>“Bad” (1987)</b> produced <b>five consecutive number-one singles</b> — a record — and its <b>Bad World Tour</b>, his first solo tour, played to millions across the globe with elaborate choreography and staging.',
      crux='He proved his dominance was <b>no fluke</b>, matching studio success with live showmanship on a planetary scale.',
      conseq='His touring machine and image-making pushed him deeper into the role of a self-directed global icon.',
      matters='Michael raised the ceiling for live pop — the immersive, dance-driven arena show is part of his enduring legacy.'),

    E('dangerous', '1991–1995', '“Dangerous” and “HIStory” — reinvention and reach', ['TRIUMPH', 'POLITICS'],
      'Parting with Quincy Jones, Michael embraces the new-jack-swing sound on "Dangerous" (1991) — its "Black or White" video a worldwide event — and answers a decade of turmoil with "HIStory" (1995), a defiant double album that reaffirms his global reach even as controversy grows.',
      svg_row('Reinvention under pressure', [
          {'n': 1, 'label': '“Dangerous,” 1991', 'sub': 'new jack swing; “Black or White” a global event', 'color': '#a21caf'},
          {'n': 2, 'label': '“HIStory,” 1995', 'sub': 'a defiant double album of hits and new songs', 'color': '#3730a3'},
          {'n': 3, 'label': 'Still a global colossus', 'sub': 'huge sales and tours amid mounting scrutiny', 'color': '#a16207'},
      ], edge_labels=['then', 'yet'], takeaway='Michael kept reinventing his sound and remained a worldwide draw — even as the controversies of his private life began to crowd the headlines.', accent=AC),
      bg='In the 1990s Michael took fuller creative control, moving past Quincy Jones toward the era’s <b>new jack swing</b> and confronting rising media scrutiny.',
      people='producer <b>Teddy Riley</b> (new jack swing); Michael as auteur; a global fan base and an increasingly hostile press.',
      what='<b>“Dangerous” (1991)</b>, with the widely watched <b>“Black or White”</b> video, and the double album <b>“HIStory” (1995)</b> kept Michael a top-selling, arena-filling superstar and showcased his ongoing innovations in music video and dance.',
      crux='He remained a <b>musical force and innovator</b> even as his artistry and his personal controversies became inseparable in the public eye.',
      conseq='His enormous commercial reach persisted, but the surrounding turmoil increasingly defined his public story.',
      matters='Artistic vitality can endure through personal crisis — but Michael’s later career shows how controversy can overshadow even the greatest talent.'),
]

# ==================================================================  PHASE 4 — THE TROUBLED YEARS
PHASE_TROUBLE = [
    E('neverland', '1980s–1990s', 'Changing appearance and Neverland', ['POLITICS', 'TRAGEDY'],
      'As his fame grows, so does public fascination with Michael’s changing appearance — which he attributed to the skin condition vitiligo and cosmetic surgery — and with Neverland Ranch, the fantasy estate he built as a private world, complete with a funfair and zoo, that became a lightning rod for scrutiny.',
      svg_stack('A private world under the spotlight', [
          {'n': 1, 'label': 'A changing appearance', 'sub': 'attributed to vitiligo and cosmetic surgery', 'color': '#a21caf'},
          {'n': 2, 'label': 'Neverland Ranch built, 1988', 'sub': 'a fantasy estate with a funfair and zoo', 'color': '#a16207'},
          {'n': 3, 'label': 'A lightning rod for scrutiny', 'sub': 'endless speculation about his private life', 'color': '#78350f'},
      ], takeaway='Michael sought to build a private refuge and control his own image — but both his appearance and Neverland only intensified the public’s fascination.', accent=AC),
      bg='From the 1980s Michael’s <b>appearance changed markedly</b>, and in 1988 he built <b>Neverland Ranch</b> in California as a personal retreat.',
      people='Michael; his medical advisers; the tabloid press and a fascinated global public.',
      what='Michael said his lightening skin was caused by <b>vitiligo</b>, and he acknowledged <b>cosmetic surgery</b>; <b>Neverland</b>, with its amusement rides and zoo, became both a sanctuary and a focus of relentless speculation.',
      crux='He tried to <b>author his own world and image</b>, but the more private he grew, the more intense the public scrutiny became.',
      conseq='Neverland, where he hosted children, would later become central to the allegations against him.',
      matters='Extreme fame can distort a life beyond recognition — Michael’s retreat into a private fantasy world drew the very scrutiny he sought to escape.'),

    E('allegations1993', '1993–1994', 'The 1993 allegations and the settlement', ['POLITICS', 'TRAGEDY'],
      'In 1993 Michael faces allegations of child sexual abuse from a 13-year-old boy — claims he firmly denies. No criminal charges are brought, and in 1994 the family’s civil suit is resolved through an out-of-court settlement, an outcome that supporters and critics have read in opposite ways ever since.',
      svg_compare('Allegation and outcome, stated neutrally', {
          'head': 'The allegation (1993)', 'color': '#b91c1c', 'items': [
              'A 13-year-old boy accused Michael of child sexual abuse',
              'Michael firmly and consistently denied all wrongdoing',
              'The claims triggered a police investigation and huge publicity',
          ]}, {
          'head': 'The outcome (1994)', 'color': '#3730a3', 'items': [
              'No criminal charges were filed by prosecutors',
              'The civil suit was settled out of court in 1994',
              'A settlement is not a criminal finding either way',
          ]},
      verdict='Allegations remain allegations; no charges were brought — read here without prejudging either side.',
      takeaway='The 1993 case ended without criminal charges and in a civil settlement — facts that his defenders and accusers have interpreted very differently.', accent=AC),
      bg='In 1993 a <b>13-year-old boy</b> and his family accused Michael of <b>child sexual abuse</b>, prompting a police investigation and a media storm.',
      people='the accuser and his family; Michael and his legal team; prosecutors and investigators.',
      what='Michael <b>denied the allegations</b>; <b>no criminal charges were brought</b>, and in <b>1994 the civil lawsuit was settled out of court</b>. Both the allegations and the absence of charges are stated here as facts, without presuming guilt or innocence.',
      crux='The case set a pattern of <b>serious accusation, firm denial and legally inconclusive resolution</b> that would define perceptions of Michael.',
      conseq='The settlement neither proved nor disproved the claims and left the question fiercely contested in public opinion.',
      matters='Allegations are not verdicts — a fair account records the accusation, the denial and the legal outcome without collapsing them into a conclusion.'),

    E('trial2005', '2003–2005', 'The 2005 trial — acquitted on all counts', ['POLITICS', 'TRIUMPH'],
      'In 2003 Michael is arrested on fresh child-molestation charges brought by another family; after a long, heavily publicised 2005 trial he is acquitted on all counts. He maintains his innocence throughout — even as the ordeal, and mounting financial troubles, leave him diminished.',
      svg_compare('Charges and the jury’s verdict', {
          'head': 'The 2005 charges', 'color': '#b91c1c', 'items': [
              'Arrested in 2003 on child-molestation charges',
              'Accused by another family connected to Neverland',
              'A long, intensely publicised criminal trial followed',
          ]}, {
          'head': 'The verdict (June 2005)', 'color': '#166534', 'items': [
              'A jury acquitted Michael on all counts',
              'He consistently maintained his innocence',
              'He was legally cleared of the criminal charges',
          ]},
      verdict='Michael was tried and acquitted on all counts in 2005 — a criminal court found him not guilty.',
      takeaway='Michael stood trial in 2005 and was acquitted on every count — the one criminal case against him ended in a full not-guilty verdict.', accent=AC),
      bg='After a 2003 arrest, Michael was <b>tried in 2005</b> on multiple counts of child molestation involving a boy and his family, in one of the most publicised trials of the era.',
      people='the accusing family; prosecutors; Michael and his defence; the California jury.',
      what='Following a months-long trial, a jury <b>acquitted Michael on all counts in June 2005</b>. He <b>maintained his innocence throughout</b>; the acquittal is recorded here alongside the fact that the charges had been brought.',
      crux='The only criminal case to reach a verdict ended in a <b>full acquittal</b> — a legal fact that stands regardless of continuing public debate.',
      conseq='Cleared but exhausted and financially strained, Michael largely withdrew from public life and left the United States.',
      matters='Due process matters — Michael was accused, tried and found not guilty, and an even-handed account gives the verdict its full weight.'),
]

# ==================================================================  PHASE 5 — THE FINAL ACT
PHASE_END = [
    E('finances', '2005–2008', 'Financial troubles and withdrawal', ['POLITICS', 'DEFEAT'],
      'Despite immense earnings, Michael’s lavish spending, legal costs and heavy borrowing leave him deep in debt; he closes Neverland as a residence, lives abroad for a time, and by the late 2000s needs a dramatic return to restore his finances and his standing.',
      svg_stack('A fortune spent, a comeback needed', [
          {'n': 1, 'label': 'Vast earnings, vaster spending', 'sub': 'lavish costs, legal bills and heavy debt', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Neverland closed; life abroad', 'sub': 'withdraws from the U.S. after the 2005 trial', 'color': '#78350f'},
          {'n': 3, 'label': 'A comeback becomes necessary', 'sub': 'he needs to rebuild finances and reputation', 'color': '#a16207'},
      ], takeaway='For all his earnings, Michael was mired in debt by the late 2000s — making a spectacular return to the stage not just an ambition but a necessity.', accent=AC),
      bg='Michael earned enormous sums, but <b>extravagant spending, legal costs and borrowing</b> left his finances precarious by the mid-2000s.',
      people='Michael; his creditors and financial advisers; the promoters who would back his return.',
      what='After the 2005 trial Michael <b>closed Neverland as a home and lived abroad</b> for a period; deep in <b>debt</b>, he needed a major project to restore both his fortune and his public standing.',
      crux='The world’s best-selling artist was <b>financially cornered</b>, his comeback driven as much by necessity as by artistry.',
      conseq='This pressure shaped the ambitious, gruelling comeback residency he agreed to mount in London.',
      matters='Even peerless success can be undone by mismanagement — Michael’s debts turned his final years into a race to recover.'),

    E('thisisit', '2009', '“This Is It” — preparing the comeback', ['RISE', 'TURNING POINT'],
      'In 2009 Michael announces "This Is It", a run of fifty comeback concerts at London’s O2 Arena, and throws himself into intensive rehearsals for a spectacular return — the show that was meant to reintroduce the King of Pop to the world.',
      svg_row('The return that was almost staged', [
          {'n': 1, 'label': 'Announces “This Is It,” 2009', 'sub': 'a 50-concert residency at London’s O2 Arena', 'color': '#a21caf'},
          {'n': 2, 'label': 'Intensive rehearsals', 'sub': 'preparing an elaborate comeback spectacle', 'color': '#166534'},
          {'n': 3, 'label': 'A reintroduction planned', 'sub': 'meant to restore the King of Pop', 'color': '#a16207'},
      ], edge_labels=['then', 'toward'], takeaway='This Is It was to be Michael’s grand return — a huge London residency he rehearsed intensely but never got to perform.', accent=AC),
      bg='In early 2009 Michael announced <b>“This Is It,”</b> a series of comeback concerts at the <b>O2 Arena in London</b>, and began preparing an elaborate stage show.',
      people='Michael; concert promoter <b>AEG Live</b>; his production and rehearsal team; his physician, Dr <b>Conrad Murray</b>.',
      what='Michael committed to <b>fifty “This Is It” concerts</b> and undertook <b>demanding rehearsals</b> in mid-2009 for a spectacular return intended to reintroduce him to a new generation.',
      crux='It was to be his <b>redemption and revival</b> — the stage on which the King of Pop would reclaim his throne.',
      conseq='The physical strain and the medication used to help him sleep during preparations would prove fatal.',
      matters='A planned triumph can turn to tragedy — the comeback meant to save Michael instead set the stage for his death.'),

    E('death', '2009 & after', 'Death, aftermath and a contested legacy', ['DEATH', 'TRAGEDY'],
      'On 25 June 2009 Michael dies at 50 from acute propofol intoxication while preparing for This Is It; his physician Conrad Murray is later convicted of involuntary manslaughter. The world mourns a monumental artist, even as debate over his private life continues — including the disputed later claims of "Leaving Neverland".',
      svg_stack('A sudden death and an unsettled legacy', [
          {'n': 1, 'label': 'Dies 25 June 2009, age 50', 'sub': 'acute propofol intoxication during rehearsals', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Conrad Murray convicted', 'sub': 'his physician found guilty of involuntary manslaughter', 'color': '#78350f'},
          {'n': 3, 'label': 'A contested legacy', 'sub': 'global mourning; ongoing debate over his private life', 'color': '#3730a3'},
      ], takeaway='Michael died suddenly at the height of his comeback; the world mourned a monumental artist while the debate over his private life continued.', accent=AC),
      bg='On <b>25 June 2009</b>, weeks before the “This Is It” shows, Michael died at his Los Angeles home at the age of <b>50</b>.',
      people='Michael; his physician Dr <b>Conrad Murray</b>; his grieving family and worldwide fans; his estate.',
      what='The cause of death was <b>acute propofol intoxication</b>; in 2011 Dr <b>Conrad Murray was convicted of involuntary manslaughter</b>. His death prompted global mourning. Debate over his private life continues — including the later <b>“Leaving Neverland” (2019)</b> allegations, which his estate <b>disputes</b> and which have not been tested in a criminal court.',
      crux='He died as a <b>towering yet contested figure</b> — an artist of monumental achievement whose personal legacy remains fiercely debated.',
      conseq='His music endures at the summit of pop history, even as arguments over the man behind it go on.',
      matters='A legacy can hold both greatness and unresolved controversy — Michael’s asks us to weigh extraordinary art alongside claims that remain disputed.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Michael Jackson, the “King of Pop,” was the best-selling recording artist of his era and one of the most influential entertainers who ever lived. From a drilled child star in the Jackson 5 to the solo colossus of <b>Off the Wall</b>, <b>Thriller</b> and <b>Bad</b>, he reinvented the music video, the dance-driven pop performance and the global superstar. His later life was shadowed by a changing appearance, child sexual abuse allegations — from which he was legally cleared at his 2005 trial — financial ruin, and a sudden death in 2009. He remains a study in <b>monumental artistry, relentless fame, and a legacy that holds both greatness and unresolved controversy.</b></p>
<div class="ov-quote">“I’m never pleased with anything, I’m a perfectionist, it’s part of who I am.”<span>— Michael Jackson</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A drilled child star breaks out with the Jackson 5 under his father’s harsh hand → he reinvents himself with Quincy Jones on Off the Wall → Thriller becomes the best-selling album ever and he transforms music video and dance → global superstardom with Bad, Dangerous and HIStory, and humanitarian work → his private life draws scrutiny, allegations, a 2005 trial that acquits him, and financial ruin → and he dies suddenly in 2009 while preparing his comeback, leaving a monumental yet contested legacy.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">💿</div><h4>The best-selling album</h4><p>Thriller remains the best-selling album in history.</p></div>
  <div class="ov-card"><div class="i">📺</div><h4>The music video reborn</h4><p>Made the video an art form and helped break MTV’s racial barrier.</p></div>
  <div class="ov-card"><div class="i">🕺</div><h4>Dance and spectacle</h4><p>The moonwalk and the arena show redefined live pop.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>A contested legacy</h4><p>Monumental art alongside allegations and a 2005 acquittal.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Child Star</b><small> 1958–1975</small><p>Gary, Joe Jackson’s drilling, and Motown fame.</p></div>
  <div><b>2 · The Solo King</b><small> 1979–1983</small><p>Off the Wall, Thriller, and the moonwalk.</p></div>
  <div><b>3 · Global Superstardom</b><small> 1985–1995</small><p>We Are the World, Bad, Dangerous, HIStory.</p></div>
  <div><b>4 · The Troubled Years</b><small> 1980s–2005</small><p>Appearance, Neverland, allegations, acquittal.</p></div>
  <div><b>5 · The Final Act</b><small> 2005–2009</small><p>Debt, This Is It, death, and legacy.</p></div>
</div>
<div class="ov-lbl">A note on sensitive material</div>
<p class="ov-lead" style="font-size:15px">This guide treats the allegations against Michael Jackson <b>even-handedly</b>: it states accusations as accusations, records his consistent denials, and notes the legal outcomes — no criminal charges in 1993, a civil settlement in 1994, and a <b>full acquittal on all counts in 2005</b>. Later claims, including “Leaving Neverland,” are noted as disputed and untested in court. Nothing here presumes guilt or innocence beyond what courts determined.</p>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Joe Jackson', 'role': 'father & manager', 'color': '#b91c1c',
     'bio': 'The domineering patriarch who drilled his sons into the Jackson 5 through a harsh discipline Michael later described as abusive.',
     'rel': 'The father whose iron discipline made — and scarred — the prodigy.'},
    {'name': 'Quincy Jones', 'role': 'producer', 'color': '#a16207',
     'bio': 'The legendary producer who shaped Off the Wall, Thriller and Bad, guiding Michael’s reinvention as a solo artist.',
     'rel': 'The collaborator behind his three greatest solo albums.'},
    {'name': 'Berry Gordy', 'role': 'Motown founder', 'color': '#166534',
     'bio': 'The Motown founder who signed the Jackson 5 and launched Michael’s career as a child star in 1969.',
     'rel': 'The label boss who first made the Jacksons stars.'},
    {'name': 'Lionel Richie', 'role': 'co-writer', 'color': '#3730a3',
     'bio': 'The singer-songwriter who co-wrote the charity anthem “We Are the World” with Michael in 1985.',
     'rel': 'His partner on the humanitarian anthem of the decade.'},
    {'name': 'Conrad Murray', 'role': 'physician', 'color': '#78350f',
     'bio': 'Michael’s personal doctor during the This Is It rehearsals, later convicted of involuntary manslaughter over his death.',
     'rel': 'The physician convicted in connection with his death.'},
]

KEY_EVENTS = [
    ('1958', 'Michael Jackson born', 'Gary, Indiana; drilled by his father Joe.'),
    ('1969', '“I Want You Back”', 'Jackson 5 explode onto the charts.'),
    ('1979', '“Off the Wall”', 'Solo breakthrough with Quincy Jones.'),
    ('1982', '“Thriller”', 'Best-selling album of all time.'),
    ('1983', 'Moonwalk on Motown 25', 'Video and dance redefined.'),
    ('1985', '“We Are the World”', 'Charity anthem co-written with Lionel Richie.'),
    ('1987', '“Bad” & world tour', 'Five No. 1 singles; first solo tour.'),
    ('1993–94', 'Allegations & settlement', 'No charges; civil case settled.'),
    ('2005', 'Trial and acquittal', 'Acquitted on all counts.'),
    ('2009', 'Death at 50', 'Propofol; Murray convicted; This Is It cancelled.'),
]

MASTER = [
    {'year': '1958', 'age': 'born', 'phase': 'The Child Star', 'title': 'Born in Gary', 'desc': 'A childhood drilled into a stage act.'},
    {'year': '1969', 'age': 'age 11', 'phase': 'The Child Star', 'title': 'Jackson 5 breakout', 'desc': '“I Want You Back” tops the charts.'},
    {'year': '1982', 'age': 'age 24', 'phase': 'The Solo King', 'title': '“Thriller”', 'desc': 'The best-selling album of all time.'},
    {'year': '1987', 'age': 'age 29', 'phase': 'Global Superstardom', 'title': '“Bad” era', 'desc': 'Five No. 1s and a world tour.'},
    {'year': '2005', 'age': 'age 46', 'phase': 'The Troubled Years', 'title': 'Acquitted at trial', 'desc': 'Cleared on all counts.'},
    {'year': '2009', 'age': 'age 50', 'phase': 'The Final Act', 'title': 'Death', 'desc': 'Dies preparing This Is It.'},
]

SOURCES = [
    ('Britannica — Michael Jackson', 'https://www.britannica.com/biography/Michael-Jackson'),
    ('Britannica — Michael Jackson (summary)', 'https://www.britannica.com/summary/Michael-Jackson'),
    ('HISTORY — Michael Jackson is born', 'https://www.history.com/this-day-in-history/august-29/michael-jackson-is-born'),
    ('Biography — Michael Jackson', 'https://www.biography.com/musicians/michael-jackson'),
    ('Wikipedia — Michael Jackson', 'https://en.wikipedia.org/wiki/Michael_Jackson'),
]

def build_meta():
    return {
        'pid': 'gm-mj.html', 'kind': 'man', 'emoji': '🕺', 'accent': AC,
        'name': 'Michael Jackson', 'years': '1958–2009', 'group': 'Artists & Filmmakers',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The King of Pop — the child star turned best-selling artist of all time, who reinvented music video and dance, and whose monumental artistry is inseparable from the controversies of his later life.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'child', 'label': '1 · The Child Star', 'type': 'timeline',
             'intro': 'Born in Gary, Indiana and drilled by his father Joe, Michael becomes the breakout child star of the Jackson 5 at Motown before stepping out on his own.', 'events': PHASE_CHILD},
            {'id': 'king', 'label': '2 · The Solo King', 'type': 'timeline',
             'intro': 'With Quincy Jones he reinvents himself on Off the Wall and Thriller — the best-selling album ever — and, with the moonwalk and his videos, transforms pop performance.', 'events': PHASE_KING},
            {'id': 'global', 'label': '3 · Global Superstardom', 'type': 'timeline',
             'intro': 'At his peak, Michael co-writes “We Are the World,” conquers the world with Bad, and keeps reinventing his sound across Dangerous and HIStory.', 'events': PHASE_GLOBAL},
            {'id': 'trouble', 'label': '4 · The Troubled Years', 'type': 'timeline',
             'intro': 'His changing appearance and Neverland draw intense scrutiny; child sexual abuse allegations are raised and denied, and a 2005 trial ends in acquittal on all counts.', 'events': PHASE_TROUBLE},
            {'id': 'end', 'label': '5 · The Final Act', 'type': 'timeline',
             'intro': 'Deep in debt, Michael stakes everything on the This Is It comeback — but dies in 2009 of acute propofol intoxication, leaving a monumental yet contested legacy.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources. Allegations are stated as allegations and paired with legal outcomes (no 1993 charges; a 1994 civil settlement; a full 2005 acquittal). Later claims such as “Leaving Neverland” are noted as disputed and untested in court; this guide presumes neither guilt nor innocence beyond what courts determined.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
