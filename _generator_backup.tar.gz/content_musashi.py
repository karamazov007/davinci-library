# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Miyamoto Musashi.
The undefeated swordsman who became a painter, philosopher and author of The Book of Five Rings."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#334e68'  # steel-indigo, the colour of forged iron

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING OF A SWORDSMAN
PHASE_MAKING = [
    E('origins', '1584', 'Born to the sword in a war-torn land', ['RISE'],
      'Miyamoto Musashi is born around 1584 in Harima province, in the last violent years of Japan’s civil wars — the son of Shinmen Munisai, an accomplished martial artist skilled with sword and truncheon, from whom the boy called Bennosuke inherits both a fighting bloodline and a hard, unforgiving upbringing.',
      svg_row('A fighting bloodline in an age of war', [
          {'n': 1, 'label': 'Harima province, c. 1584', 'sub': 'born Shinmen Bennosuke in a land at war', 'color': '#334e68'},
          {'n': 2, 'label': 'Son of Shinmen Munisai', 'sub': 'a noted master of sword and jitte', 'color': '#a16207'},
          {'n': 3, 'label': 'Raised to the blade', 'sub': 'martial skill as birthright and burden', 'color': '#166534'},
      ], edge_labels=['son of', 'so'], takeaway='Born in the last age of the samurai wars to a master of arms, Musashi was bred for the sword from childhood.', accent=AC),
      bg='Musashi was born around 1584 in <b>Harima province</b>, during the final convulsions of Japan’s Sengoku (“Warring States”) era, and given the childhood name <b>Shinmen Bennosuke</b>.',
      people='his father <b>Shinmen Munisai</b>, a renowned expert of the sword and the <i>jitte</i> (truncheon); the martial house of Shinmen he was born into.',
      what='Musashi entered the world as the son of an accomplished warrior in a country still riven by civil war, absorbing the <b>art of arms</b> as his birthright in a hard, often loveless boyhood.',
      crux='He was shaped from the start by <b>combat as a way of life</b> — the sword was not a hobby but his inheritance and identity.',
      conseq='By his early teens he was already large, aggressive and skilled enough to challenge grown fighting men.',
      matters='Genius is often forged early — Musashi’s lifelong obsession with the Way of the sword began in the violent world he was born into.'),

    E('firstduel', '1596', 'First blood at thirteen — killing Arima Kihei', ['BATTLE', 'TURNING POINT'],
      'At about thirteen, Musashi fights his first duel against Arima Kihei, a wandering adult swordsman of the Kashima Shintō-ryū — and the boy hurls the grown warrior to the ground and beats him to death with a staff, opening a lifetime of combat and a ruthless creed that only victory, not method, counts.',
      svg_stack('A boy kills a master swordsman', [
          {'n': 1, 'label': 'A traveller’s challenge, c. 1596', 'sub': 'Arima Kihei of the Kashima Shintō-ryū posts an open duel', 'color': '#a16207'},
          {'n': 2, 'label': 'The 13-year-old accepts', 'sub': 'Musashi answers a grown, trained warrior', 'color': '#334e68'},
          {'n': 3, 'label': 'Beaten to death with a staff', 'sub': 'the boy throws and clubs Kihei down', 'color': '#b91c1c'},
      ], takeaway='At thirteen he killed a trained adult swordsman — and learned that in a duel only the outcome matters, never the style.', accent=AC),
      bg='A wandering swordsman named <b>Arima Kihei</b>, of the <b>Kashima Shintō-ryū</b>, posted an open challenge in Musashi’s district — the kind of duel any comer could accept.',
      people='<b>Arima Kihei</b>, the adult challenger; the boy <b>Musashi</b>, perhaps thirteen; the villagers who witnessed it.',
      what='Musashi accepted the challenge and, ignoring refined technique, <b>threw Kihei to the ground and beat him to death with a staff</b> — his first recorded kill and the start of his dueling life.',
      crux='He grasped early that <b>winning, not elegance, was the whole of combat</b> — a brutally practical creed he never abandoned.',
      conseq='The victory set him on the road as a duelist, and by sixteen he had defeated a powerful adept named Tadashima Akiyama.',
      matters='Musashi’s ruthless pragmatism was there from the first fight — the philosophy of the whole life is visible in its opening act.'),

    E('sekigahara', '1600', 'Onto the battlefield — the great wars and the warrior’s road', ['BATTLE'],
      'As Japan’s destiny is decided at Sekigahara in 1600, the teenage Musashi takes the field in the campaigns that end the civil wars — then, masterless and driven, sets out on the <i>musha shugyō</i>, the wandering warrior’s pilgrimage of self-perfection through duel after duel across the country.',
      svg_row('From the great battle to the wandering road', [
          {'n': 1, 'label': 'Sekigahara era, 1600', 'sub': 'Japan’s fate decided; Musashi in the campaigns', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A masterless swordsman', 'sub': 'no lord, no fixed place in the new peace', 'color': '#475569'},
          {'n': 3, 'label': 'The warrior’s pilgrimage', 'sub': 'musha shugyō — perfect the self by combat', 'color': '#334e68'},
      ], edge_labels=['then', 'begins'], takeaway='The wars that unified Japan left Musashi lordless — so he made his life a pilgrimage of duels to perfect the Way of the sword.', accent=AC),
      bg='In <b>1600</b> the Battle of <b>Sekigahara</b> and the surrounding campaigns decided who would rule Japan; the young Musashi fought in these wars (traditionally on the losing western side, though sources differ).',
      people='the great warlords contesting Japan; <b>Tokugawa Ieyasu</b>, whose victory founded the shogunate; the masterless swordsmen the peace produced.',
      what='Musashi saw real war in the unification campaigns, then — with the fighting over and no lord to serve — embarked on the <b>musha shugyō</b>, a years-long <b>pilgrimage of duels</b> to test and refine himself.',
      crux='He turned the coming of peace into a personal quest — <b>self-mastery through relentless combat</b> rather than settled service.',
      conseq='This wandering road would soon bring him to Kyoto and a collision with Japan’s most famous school of swordsmen.',
      matters='When the age of great wars ended, Musashi channelled the warrior’s discipline inward — combat as a path of self-perfection, not just survival.'),
]

# ==================================================================  PHASE 2 — THE YOSHIOKA DUELS
PHASE_YOSHIOKA = [
    E('seijuro', '1604', 'Humbling the house of Yoshioka — Seijūrō', ['BATTLE', 'TURNING POINT'],
      'In 1604 Musashi arrives in Kyoto and challenges the Yoshioka, the celebrated fencing school of the shōgun’s former instructors — deliberately arriving late to unnerve the head of the house, Yoshioka Seijūrō, then felling him with a single blow of a wooden sword and shattering the school’s pride.',
      svg_stack('The lone swordsman versus the great school', [
          {'n': 1, 'label': 'Challenges the Yoshioka, 1604', 'sub': 'Kyoto’s famed school, once the shōgun’s tutors', 'color': '#a16207'},
          {'n': 2, 'label': 'Arrives deliberately late', 'sub': 'rattles Seijūrō before a blow is struck', 'color': '#334e68'},
          {'n': 3, 'label': 'One strike ends it', 'sub': 'Seijūrō felled by a wooden sword', 'color': '#b91c1c'},
      ], takeaway='He beat Japan’s most prestigious school by attacking its head’s composure first — psychology before steel.', accent=AC),
      bg='The <b>Yoshioka</b> of Kyoto were among Japan’s most prestigious sword schools, having served as fencing instructors to the Ashikaga shōguns; their prestige made them the ultimate test for a wandering duelist.',
      people='<b>Yoshioka Seijūrō</b>, head of the house; the school’s many students; the lone challenger Musashi.',
      what='Musashi challenged Seijūrō, made him <b>wait in mounting anger</b> by arriving late, then struck him down with a single blow of a <b>bokken (wooden sword)</b>, crippling him and humiliating the school.',
      crux='He weaponised <b>timing and psychology</b> — unbalancing a proud opponent before the fight even began.',
      conseq='The disgraced Seijūrō retired; his brother Denshichirō stepped forward to avenge the family honour.',
      matters='Musashi understood that a duel is won in the mind before the body — a lesson at the heart of his later strategy.'),

    E('denshichiro', '1604', 'The brother’s revenge — Denshichirō falls', ['BATTLE'],
      'The Yoshioka honour demands revenge, and Seijūrō’s brother Denshichirō — reputedly the stronger swordsman — challenges Musashi with a real steel blade; but Musashi again seizes the initiative and kills him outright, leaving the once-mighty school leaderless and burning for a final reckoning.',
      svg_row('Revenge answered with a killing blow', [
          {'n': 1, 'label': 'Denshichirō challenges', 'sub': 'Seijūrō’s brother seeks to restore honour', 'color': '#a16207'},
          {'n': 2, 'label': 'A duel of live blades', 'sub': 'the Yoshioka fights in earnest to kill', 'color': '#334e68'},
          {'n': 3, 'label': 'Musashi kills him', 'sub': 'the school is left without a head', 'color': '#b91c1c'},
      ], edge_labels=['met by', 'and'], takeaway='The second Yoshioka came for blood and found his own — Musashi killed the brother and broke the school’s leadership.', accent=AC),
      bg='Bound by honour to avenge Seijūrō, his brother <b>Yoshioka Denshichirō</b> — said to be the more formidable fighter — challenged Musashi to a second duel.',
      people='<b>Yoshioka Denshichirō</b>, the avenging brother; the watching students of the school; Musashi.',
      what='In the second duel Musashi <b>killed Denshichirō outright</b>, leaving the Yoshioka house without an adult leader and its reputation in ruins.',
      crux='He met a determined, deadly challenge by <b>striking first and decisively</b> — refusing to fight on the enemy’s terms.',
      conseq='With both brothers destroyed, the school named the boy heir Matashichirō as figurehead and plotted an ambush.',
      matters='Musashi’s dominance was not luck but method — decisive aggression that took each opponent apart in turn.'),

    E('ichijoji', '1604', 'Ambush at Ichijōji — one against a school', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'For the final reckoning the Yoshioka name their child heir Matashichirō as figurehead and lie in wait with dozens of armed retainers at Ichijōji — but Musashi turns the tables, arriving early instead of late, cutting down the boy first, then hacking his way out through the ambush and ending the house of Yoshioka forever.',
      svg_stack('One man breaks an ambush of dozens', [
          {'n': 1, 'label': 'A trap at Ichijōji', 'sub': 'the boy heir Matashichirō set as bait, dozens hidden', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Musashi arrives early', 'sub': 'reverses his own trick; strikes before they are ready', 'color': '#334e68'},
          {'n': 3, 'label': 'Cuts down the heir and escapes', 'sub': 'kills the boy, fights clear, ends the Yoshioka', 'color': '#78350f'},
      ], takeaway='Facing a whole school in ambush, he did the unexpected — came early, killed the figurehead first, and cut his way free.', accent=AC),
      bg='Unable to beat him fairly, the Yoshioka made the child <b>Matashichirō</b> their nominal champion and prepared an <b>ambush</b> with many armed men outside Kyoto, near <b>Ichijōji</b>.',
      people='the boy <b>Matashichirō</b>, figurehead of the trap; dozens of Yoshioka retainers; Musashi, alone.',
      what='Anticipating the ambush, Musashi <b>arrived early and hidden</b>, <b>killed the boy Matashichirō first</b>, then fought his way out through the astonished retainers — reputedly drawing both his swords at once — and destroyed the school’s last claim to greatness.',
      crux='He <b>inverted his own reputation for lateness</b>, doing exactly what the enemy did not expect — and struck the decisive target before the trap could close.',
      conseq='The once-great Yoshioka school was finished; Musashi’s fame as an unbeatable duelist spread across Japan.',
      matters='Ichijōji became legend — the archetype of one master defeating many through surprise, nerve and the refusal to fight predictably.'),
]

# ==================================================================  PHASE 3 — THE INVINCIBLE
PHASE_INVINCIBLE = [
    E('nitenichiryu', '1605–1612', 'The two-sword way — Niten Ichi-ryū', ['REFORM'],
      'Out of years of dueling Musashi forges his signature innovation: a two-sword style, Niten Ichi-ryū — the “school of two heavens as one” — wielding the long katana and short wakizashi together, reasoning that a warrior should use every weapon he carries rather than let one rust unused at his hip.',
      svg_compare('Why fight with two blades at once',
          {'head': 'The old way — one sword', 'color': '#475569', 'items': [
              'both hands grip a single long sword',
              'the short blade stays sheathed, unused',
              'one line of attack and defence']},
          {'head': 'Niten Ichi-ryū — two blades', 'color': '#334e68', 'items': [
              'katana in one hand, wakizashi in the other',
              'attack and guard at the same instant',
              'two independent threats to manage']},
          verdict='“It is bad to carry a sword you never draw” — use every weapon you bear.',
          takeaway='Musashi’s two-sword method turned the whole arsenal into one weapon — pure practicality raised to an art.', accent=AC),
      bg='Through relentless dueling, Musashi refined a fighting method unlike the single-sword orthodoxy of the great schools.',
      people='the rival single-sword schools he outfought; the students to whom he later taught the style.',
      what='He founded <b>Niten Ichi-ryū</b> (“two heavens as one,” also called Enmei-ryū), fighting with the <b>long katana and short wakizashi together</b> — one hand each — on the logic that a swordsman should <b>use every weapon he carries</b>.',
      crux='His innovation flowed from pure practicality — <b>waste nothing</b>, and force the enemy to defend against two blades at once.',
      conseq='The two-sword style became his signature and the enduring core of his school, which survives to this day.',
      matters='Musashi’s genius was ruthless practicality made systematic — the same mind that won duels codified a whole method of combat.'),

    E('ganryujima', '1612', 'Ganryūjima — the duel with Sasaki Kojirō', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'On 13 April 1612 Musashi meets his greatest rival, Sasaki Kojirō, on the island of Ganryūjima in the strait near Kokura — arriving deliberately late in a boat, having carved a longer-than-normal wooden sword from a spare oar on the crossing, and killing the master of the “swallow cut” with a single blow to the skull.',
      svg_stack('The most famous duel in samurai history', [
          {'n': 1, 'label': 'Kojirō and the “Drying Pole”', 'sub': 'master of the swallow cut, wielding a great long nodachi', 'color': '#a16207'},
          {'n': 2, 'label': 'Musashi arrives late by boat', 'sub': 'carving an oversized bokken from an oar on the way', 'color': '#334e68'},
          {'n': 3, 'label': 'One blow to the skull', 'sub': 'Kojirō struck down; Musashi departs at once', 'color': '#b91c1c'},
      ], takeaway='He beat Japan’s finest swordsman with a whittled oar — out-reaching, out-timing and unnerving him before the strike.', accent=AC),
      bg='<b>Sasaki Kojirō</b> was a celebrated swordsman famed for the <b>Tsubame Gaeshi</b> (“swallow’s counter-cut”) and a very long sword nicknamed the <b>“Drying Pole.”</b> A duel between the two rivals was arranged on <b>Ganryūjima</b>, an island in the Kanmon strait near Kokura.',
      people='<b>Sasaki Kojirō</b>, the greatest rival of Musashi’s life; the Hosokawa officials who sanctioned the duel; the boatman who ferried Musashi.',
      what='On <b>13 April 1612</b> Musashi arrived <b>deliberately late</b>, having <b>carved an over-long wooden sword from a spare oar</b> during the crossing; goading and out-reaching the furious Kojirō, he struck a <b>single fatal blow to the head</b> and left the island immediately.',
      crux='He beat a superb swordsman through <b>reach, timing and psychology</b> — a longer improvised weapon, a rattled opponent, one decisive strike.',
      conseq='The victory sealed Musashi’s legend as Japan’s supreme duelist; it is said to be the last serious duel he ever fought to the death.',
      matters='Ganryūjima is the most retold duel in Japanese history — the purest example of Musashi winning with mind and preparation, not just the blade.'),

    E('undefeated', '1613', 'Sixty duels, never defeated', ['TRIUMPH'],
      'By around his thirtieth year Musashi has fought, by his own account, more than sixty duels against the finest swordsmen in Japan and never once been beaten — a record that turns him from a wandering fighter into a living legend, and prompts him to begin looking beyond mere victory toward the deeper Way.',
      svg_row('A record without equal', [
          {'n': 1, 'label': 'More than 60 duels', 'sub': 'against Japan’s best, from age 13 to about 29', 'color': '#334e68'},
          {'n': 2, 'label': 'Never defeated', 'sub': 'an unbroken record of survival and victory', 'color': '#166534'},
          {'n': 3, 'label': 'Beyond winning', 'sub': 'he begins to seek the principle behind the wins', 'color': '#a16207'},
      ], edge_labels=['all', 'so'], takeaway='Sixty-odd duels, not one loss — and at his peak he turned from the sword’s victories to the wisdom beneath them.', accent=AC),
      bg='By his own testimony in his later writings, Musashi had fought over <b>sixty duels</b> between the age of thirteen and about twenty-nine, against skilled opponents, and had <b>never lost</b>.',
      people='the many swordsmen he defeated; the schools whose champions fell to him; the disciples who began to gather around his name.',
      what='Musashi emerged from his dueling years <b>undefeated in more than sixty encounters</b>, a record unmatched in samurai lore — and at the height of his powers he began to sense that raw victory was not the deepest truth of the sword.',
      crux='Unbroken success led him not to complacency but to <b>reflection</b> — he started to ask what universal principle lay behind his wins.',
      conseq='This turn inward would eventually make him a teacher, artist and philosopher rather than only a killer.',
      matters='Mastery ripens into wisdom — Musashi’s undefeated record freed him to pursue the meaning of the Way rather than the next fight.'),
]

# ==================================================================  PHASE 4 — FROM WARRIOR TO SAGE
PHASE_SERVICE = [
    E('osaka', '1614–1615', 'The siege of Osaka — the last great war', ['BATTLE'],
      'Musashi takes the field one last time in the sieges of Osaka Castle (1614–15), the final war that secures Tokugawa rule over all Japan — but the age of open warfare and the wandering duelist is closing, and he turns from the battlefield toward service, teaching and art.',
      svg_row('The closing of the age of war', [
          {'n': 1, 'label': 'Siege of Osaka, 1614–15', 'sub': 'the last great campaign of the samurai wars', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Tokugawa peace secured', 'sub': 'the shogunate’s rule made total', 'color': '#475569'},
          {'n': 3, 'label': 'The duelist’s world ends', 'sub': 'Musashi turns to service and art', 'color': '#334e68'},
      ], edge_labels=['brings', 'so'], takeaway='The last great war ended the world of the wandering swordsman — and pushed Musashi toward a settled, reflective life.', accent=AC),
      bg='The <b>sieges of Osaka</b> (winter 1614, summer 1615) were the final struggle of the Tokugawa to crush the last opposition and complete their control of Japan.',
      people='<b>Tokugawa Ieyasu</b>, victor and founder of the lasting peace; the doomed defenders of Osaka; Musashi, serving in the campaign.',
      what='Musashi fought in the <b>Osaka campaigns</b> (traditionally on the Tokugawa side), the last major war of his lifetime — after which the long <b>Tokugawa peace</b> left little place for duels or battlefields.',
      crux='The world that had made him — endless war and open challenge — was <b>ending</b>, forcing even the greatest swordsman to find a new path.',
      conseq='Musashi turned to <b>advising lords, teaching, and adopting sons</b>, seeking a role in the new order of peace.',
      matters='Even a supreme warrior must adapt when his age passes — Musashi’s greatness in peace was his ability to become more than a fighter.'),

    E('hosokawa', 'c. 1633–1640', 'Guest of the Hosokawa — the warrior settles', ['POLITICS', 'REFORM'],
      'The masterless swordsman finally finds a home when the powerful Hosokawa lord Tadatoshi welcomes Musashi to Kumamoto as an honoured guest and adviser — a rare dignity for a lifelong rōnin — where he teaches his art, orders his thoughts, and prepares to set down all he has learned.',
      svg_stack('A rōnin finds an honoured place', [
          {'n': 1, 'label': 'A lifelong masterless man', 'sub': 'a rōnin who served no single lord for long', 'color': '#475569'},
          {'n': 2, 'label': 'Welcomed to Kumamoto, c. 1640', 'sub': 'the Hosokawa lord Tadatoshi hosts him as adviser', 'color': '#334e68'},
          {'n': 3, 'label': 'Teacher and honoured guest', 'sub': 'a rare dignity for a wandering swordsman', 'color': '#166534'},
      ], takeaway='Late in life the eternal wanderer was received as an honoured guest — the freedom to finally distil his life’s knowledge.', accent=AC),
      bg='Musashi spent most of his life as a <b>rōnin</b> — a swordsman with no permanent lord — but late in life sought a settled position and patronage.',
      people='<b>Hosokawa Tadatoshi</b>, lord of Kumamoto and his patron; the students who received his teaching; the adopted sons who carried on his name.',
      what='Around <b>1640</b> the daimyō <b>Hosokawa Tadatoshi</b> invited Musashi to <b>Kumamoto</b> as a guest and adviser — an unusual honour for a rōnin — where he taught, painted and began to organise his lifetime of insight.',
      crux='Patronage gave him <b>security and standing</b> at last, and the leisure to turn experience into lasting teaching.',
      conseq='It was under Hosokawa protection that Musashi would soon withdraw to a cave to write his masterwork.',
      matters='Recognition came late but decisively — the settled years let Musashi transform a warrior’s life into enduring wisdom.'),

    E('art', 'c. 1630s–1640s', 'The brush and the blade — Musashi the artist', ['REFORM', 'TRIUMPH'],
      'In his mature years Musashi becomes a master of the brush as well as the sword — producing spare, powerful ink paintings such as the famous “Shrike on a Withered Branch,” along with calligraphy and sculpture, and living out his conviction that the Way of the warrior and the way of the arts are one and the same.',
      svg_row('One Way, expressed in sword and brush', [
          {'n': 1, 'label': 'The swordsman takes up the brush', 'sub': 'ink painting, calligraphy, sculpture', 'color': '#334e68'},
          {'n': 2, 'label': '“Shrike on a Withered Branch”', 'sub': 'spare, forceful sumi-e in the Zen manner', 'color': '#a16207'},
          {'n': 3, 'label': 'The arts as one Way', 'sub': 'the same discipline underlies combat and creation', 'color': '#166534'},
      ], edge_labels=['as in', 'so'], takeaway='The hand that had killed sixty men painted masterpieces — Musashi held that sword and brush follow one Way.', accent=AC),
      bg='Zen and the samurai ideal held that mastery of any art reflected mastery of the self; Musashi embodied this by excelling in the fine arts as well as the sword.',
      people='the Zen and ink-painting traditions he drew on; later collectors and museums that preserved his works; his students.',
      what='Musashi became an accomplished <b>ink painter, calligrapher and sculptor</b>, leaving admired works such as the sumi-e <b>“Shrike on a Withered Branch”</b> — art of striking economy and force, prized to this day.',
      crux='He lived the principle that <b>all Ways are one Way</b> — the discipline that mastered the sword also mastered the brush.',
      conseq='His dual mastery cemented his stature as far more than a killer — a complete master in the Japanese ideal.',
      matters='Musashi endures as the archetype of the warrior-sage — proof that true mastery transcends any single craft.'),
]

# ==================================================================  PHASE 5 — THE BOOK OF FIVE RINGS
PHASE_BOOK = [
    E('reigando', '1643', 'Into the cave — Reigandō', ['DEATH', 'TURNING POINT'],
      'Around 1643, aged about sixty and knowing his end is near, Musashi withdraws to the Reigandō, a cave in the hills near Kumamoto, to live as a hermit — and there, in solitude, he sets out to distil the wisdom of a lifetime of undefeated combat into a single, timeless book on strategy.',
      svg_row('The swordsman becomes a hermit-sage', [
          {'n': 1, 'label': 'Aged about sixty, 1643', 'sub': 'his health failing, his fighting days done', 'color': '#475569'},
          {'n': 2, 'label': 'Retreats to the Reigandō cave', 'sub': 'lives as a hermit in the hills near Kumamoto', 'color': '#334e68'},
          {'n': 3, 'label': 'To write down the Way', 'sub': 'distil a lifetime of combat into one book', 'color': '#a16207'},
      ], edge_labels=['so', 'to'], takeaway='At the end he traded the duel for the cave — turning a life of violence into a testament of strategy.', accent=AC),
      bg='By 1643 Musashi was old and ailing, and — in the tradition of the warrior-sage seeking enlightenment — sought solitude to reflect on and record his teaching.',
      people='the Zen tradition of the mountain hermit; the disciples he would leave his work to; Musashi in his final years.',
      what='Around <b>1643</b>, aged roughly sixty, Musashi withdrew to the <b>Reigandō cave</b> near Kumamoto to live as a hermit and to <b>write down the essence</b> of his lifetime on the Way of the sword.',
      crux='He chose to <b>convert experience into wisdom</b> — leaving not a fortune or a domain but a book of hard-won principle.',
      conseq='In the cave he composed the work that would outlast him by centuries.',
      matters='Musashi’s greatest legacy came not from a duel but from reflection — the decision to teach what he alone had learned.'),

    E('fiverings', '1645', 'The Book of Five Rings — Go Rin no Sho', ['REFORM', 'TRIUMPH'],
      'In the cave Musashi writes the Go Rin no Sho, The Book of Five Rings — a treatise on strategy in five scrolls named for the elements (Earth, Water, Fire, Wind and Void) — which he hands to his disciple Terao Magonojō days before his death, and which endures as one of the world’s classic texts on combat, strategy and the mind.',
      svg_stack('Five scrolls, five elements, one Way', [
          {'n': 1, 'label': 'The Go Rin no Sho', 'sub': 'a treatise on strategy in five books', 'color': '#334e68'},
          {'n': 2, 'label': 'Earth · Water · Fire · Wind · Void', 'sub': 'each element a dimension of strategy and mind', 'color': '#a16207'},
          {'n': 3, 'label': 'Handed to Terao Magonojō, 1645', 'sub': 'given to his disciple days before death', 'color': '#166534'},
      ], takeaway='His five-scroll treatise turned a life of duels into a universal philosophy of strategy still studied worldwide.', accent=AC),
      bg='In the Reigandō, Musashi set down his mature philosophy of combat, timing, and the mind — the culmination of over fifty years with the sword.',
      people='his disciple <b>Terao Magonojō</b>, to whom he entrusted the manuscript; the countless later readers, from samurai to modern strategists.',
      what='Musashi wrote <b>The Book of Five Rings (Go Rin no Sho)</b> in five scrolls — <b>Earth, Water, Fire, Wind and the Void</b> — covering strategy, adaptability, timing, the critique of other schools, and the formless mind; he <b>gave it to Terao Magonojō</b> shortly before he died.',
      crux='He reduced a lifetime of victory to <b>transferable principle</b> — a philosophy of strategy applicable far beyond the sword.',
      conseq='The book became a Japanese classic and, centuries later, a worldwide touchstone for strategy in war, business and life.',
      matters='Musashi’s deepest triumph was intellectual — a slim book of principle that has outlived every duel and every enemy.'),

    E('death', '1645', 'The Way of walking alone — death of a master', ['DEATH'],
      'Days before he dies in 1645, Musashi writes the Dokkōdō, twenty-one austere precepts on “the Way of walking alone” — a code of self-reliance and detachment — and then dies at about sixty-one, reputedly seated upright with sword in hand, and is buried in full armour: the undefeated swordsman who became a sage.',
      svg_row('The last testament of the lone warrior', [
          {'n': 1, 'label': 'The Dokkōdō, 1645', 'sub': '21 precepts on the Way of walking alone', 'color': '#334e68'},
          {'n': 2, 'label': 'Death at about sixty-one', 'sub': 'reputedly upright, sword in hand', 'color': '#111827'},
          {'n': 3, 'label': 'Buried in full armour', 'sub': 'the swordsman-sage passes into legend', 'color': '#78350f'},
      ], edge_labels=['then', 'and'], takeaway='He died as he lived — self-reliant and unbowed — leaving a code of solitude and a legend that never faded.', accent=AC),
      bg='Sensing the end, Musashi composed a final short testament of principles for living, distilling the discipline of a solitary warrior’s life.',
      people='his disciples, who received his final writings; the Hosokawa who buried him with honour; the generations who made him a legend.',
      what='A week before his death Musashi wrote the <b>Dokkōdō (“The Way of Walking Alone”)</b>, <b>twenty-one precepts</b> of self-reliance and detachment; he then died in <b>1645</b> at about sixty-one, and — by tradition — was <b>buried in full armour</b>.',
      crux='His last act was to leave a <b>code of solitary discipline</b> — the inner mastery that underlay all his outer victories.',
      conseq='Musashi passed into legend as the <b>Kensei</b>, the “Sword Saint” of Japan, revered as warrior, artist and philosopher alike.',
      matters='Musashi remains the supreme image of self-made mastery — a man who perfected himself utterly, and left the world both a method and a philosophy for doing the same.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Miyamoto Musashi was the greatest swordsman in Japanese history — a wandering rōnin who fought more than sixty duels without a single defeat, killed his first man at thirteen, destroyed the famed Yoshioka school of Kyoto, and cut down his greatest rival Sasaki Kojirō with a sword whittled from an oar. Yet he became far more than a killer: the founder of the two-sword Niten Ichi-ryū, an admired ink painter and calligrapher, and the author of <i>The Book of Five Rings</i>, a treatise on strategy still studied worldwide. He is the ultimate study in <b>self-made mastery, the psychology of combat, and the unity of the warrior’s Way with the way of the mind.</b></p>
<div class="ov-quote">“Think lightly of yourself and deeply of the world.”<span>— Miyamoto Musashi, The Dokkōdō</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born to a master of arms in a land at war → kills a grown swordsman at thirteen and takes to the warrior’s road → destroys the great Yoshioka school of Kyoto in three duels → forges the two-sword style and slays Sasaki Kojirō at Ganryūjima → emerges undefeated in over sixty duels → settles under the Hosokawa as teacher and painter → and withdraws to a cave to write The Book of Five Rings before his death in 1645.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⚔️</div><h4>The undefeated duelist</h4><p>Over sixty duels against Japan’s best, never once defeated.</p></div>
  <div class="ov-card"><div class="i">🧠</div><h4>Psychology of combat</h4><p>Won with timing, surprise and nerve as much as the blade.</p></div>
  <div class="ov-card"><div class="i">🗡️</div><h4>The two-sword Way</h4><p>Founded Niten Ichi-ryū — use every weapon you carry.</p></div>
  <div class="ov-card"><div class="i">📜</div><h4>The Book of Five Rings</h4><p>Turned a life of duels into a timeless philosophy of strategy.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Making</b><small> 1584–1600</small><p>A fighting bloodline; first blood; the warrior’s road.</p></div>
  <div><b>2 · The Yoshioka Duels</b><small> 1604</small><p>Three duels destroy Kyoto’s greatest school.</p></div>
  <div><b>3 · The Invincible</b><small> 1605–1613</small><p>Two swords, Ganryūjima, sixty duels undefeated.</p></div>
  <div><b>4 · Warrior to Sage</b><small> 1614–1640s</small><p>Osaka, the Hosokawa, and the master’s brush.</p></div>
  <div><b>5 · The Book of Five Rings</b><small> 1643–1645</small><p>The cave, the treatise, and walking alone.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Shinmen Munisai', 'role': 'his father', 'color': '#a16207',
     'bio': 'A noted martial artist skilled with the sword and the jitte (truncheon), from whom the young Musashi inherited both a fighting bloodline and a hard upbringing.',
     'rel': 'The father who bred him to the sword from childhood.'},
    {'name': 'Arima Kihei', 'role': 'first opponent', 'color': '#b91c1c',
     'bio': 'A wandering adult swordsman of the Kashima Shintō-ryū, killed by the thirteen-year-old Musashi in his very first duel.',
     'rel': 'His first kill — the start of a lifetime of combat.'},
    {'name': 'Yoshioka Seijūrō', 'role': 'rival school head', 'color': '#78350f',
     'bio': 'Head of the prestigious Yoshioka fencing school of Kyoto, felled by Musashi with a single blow; his brothers’ deaths and the Ichijōji ambush followed.',
     'rel': 'The great school Musashi destroyed in three duels.'},
    {'name': 'Sasaki Kojirō', 'role': 'greatest rival', 'color': '#334e68',
     'bio': 'A celebrated swordsman famed for the “swallow cut” and his long sword the “Drying Pole,” killed by Musashi in the legendary 1612 duel at Ganryūjima.',
     'rel': 'The supreme rival Musashi beat with an oar-carved sword.'},
    {'name': 'Hosokawa Tadatoshi', 'role': 'patron', 'color': '#166534',
     'bio': 'The daimyō of Kumamoto who, late in Musashi’s life, welcomed the rōnin as an honoured guest and adviser — the patronage under which he wrote his masterwork.',
     'rel': 'The lord who gave the wanderer a home at last.'},
]

KEY_EVENTS = [
    ('c. 1584', 'Musashi born', 'Harima province; son of the swordsman Munisai.'),
    ('c. 1596', 'First duel at 13', 'Kills Arima Kihei with a staff.'),
    ('1600', 'The great wars', 'Fights at Sekigahara; takes to the warrior’s road.'),
    ('1604', 'The Yoshioka duels', 'Destroys Kyoto’s great school; ambush at Ichijōji.'),
    ('1612', 'Ganryūjima', 'Kills Sasaki Kojirō with an oar-carved sword.'),
    ('c. 1613', 'Sixty duels, undefeated', 'Unmatched record in samurai history.'),
    ('1614–15', 'Siege of Osaka', 'The last great war; the duelist’s age ends.'),
    ('c. 1640', 'Guest of the Hosokawa', 'Settles in Kumamoto as adviser and teacher.'),
    ('1643', 'Retreats to Reigandō', 'Begins The Book of Five Rings in a cave.'),
    ('1645', 'Death of the master', 'Finishes his book and the Dokkōdō; dies at ~61.'),
]

MASTER = [
    {'year': 'c. 1584', 'age': 'born', 'phase': 'The Making', 'title': 'Born in Harima', 'desc': 'Son of a master of arms.'},
    {'year': 'c. 1596', 'age': 'age ~13', 'phase': 'The Making', 'title': 'First duel', 'desc': 'Kills Arima Kihei.'},
    {'year': '1604', 'age': 'age ~20', 'phase': 'The Yoshioka Duels', 'title': 'Destroys the Yoshioka', 'desc': 'Three duels; the Ichijōji ambush.'},
    {'year': '1612', 'age': 'age ~28', 'phase': 'The Invincible', 'title': 'Ganryūjima', 'desc': 'Slays Sasaki Kojirō.'},
    {'year': '1643', 'age': 'age ~60', 'phase': 'The Book of Five Rings', 'title': 'The Reigandō cave', 'desc': 'Begins his masterwork.'},
    {'year': '1645', 'age': 'age ~61', 'phase': 'The Book of Five Rings', 'title': 'Death of the Kensei', 'desc': 'The Sword Saint passes into legend.'},
]

SOURCES = [
    ('Britannica — Miyamoto Musashi', 'https://www.britannica.com/biography/Miyamoto-Musashi'),
    ('Wikipedia — Miyamoto Musashi', 'https://en.wikipedia.org/wiki/Miyamoto_Musashi'),
    ('Samurai Museum — Miyamoto Musashi: Life, Duels & The Book of Five Rings', 'https://samuraimuseum.de/en/learn/miyamoto-musashi-life-duels-the-book-of-five-rings/'),
    ('New World Encyclopedia — Miyamoto Musashi', 'https://www.newworldencyclopedia.org/entry/Miyamoto_Musashi'),
    ('History of Fighting — The Duels of Miyamoto Musashi', 'https://www.historyoffighting.com/miyamoto-musashi.php'),
]

def build_meta():
    return {
        'pid': 'gm-musashi.html', 'kind': 'man', 'emoji': '⚔️', 'accent': AC,
        'name': 'Miyamoto Musashi', 'years': '1584–1645', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The undefeated swordsman of feudal Japan — victor of some sixty duels, founder of the two-sword Niten Ichi-ryū, and author of The Book of Five Rings, who ended a life of the blade as a painter, philosopher and sage.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'making', 'label': '1 · The Making', 'type': 'timeline',
             'intro': 'Born to a master of arms in a land at war, Musashi kills a grown swordsman at thirteen, sees the great unification battles, and takes to the wandering warrior’s road.', 'events': PHASE_MAKING},
            {'id': 'yoshioka', 'label': '2 · The Yoshioka Duels', 'type': 'timeline',
             'intro': 'In Kyoto he challenges Japan’s most prestigious sword school and destroys it in three duels — humbling Seijūrō, killing Denshichirō, and breaking an ambush at Ichijōji.', 'events': PHASE_YOSHIOKA},
            {'id': 'invincible', 'label': '3 · The Invincible', 'type': 'timeline',
             'intro': 'He forges the two-sword style Niten Ichi-ryū, kills his greatest rival Sasaki Kojirō at Ganryūjima with a sword carved from an oar, and emerges undefeated in over sixty duels.', 'events': PHASE_INVINCIBLE},
            {'id': 'service', 'label': '4 · Warrior to Sage', 'type': 'timeline',
             'intro': 'The age of duels closes at the siege of Osaka; the lifelong rōnin finds a home under the Hosokawa of Kumamoto and masters the brush as well as the blade.', 'events': PHASE_SERVICE},
            {'id': 'book', 'label': '5 · The Book of Five Rings', 'type': 'timeline',
             'intro': 'Old and ailing, Musashi withdraws to the Reigandō cave to write The Book of Five Rings and the Dokkōdō — distilling a life of combat into a philosophy of strategy — and dies in 1645.', 'events': PHASE_BOOK,
             'sources': SOURCES, 'srcnote': 'Drawn from Musashi’s own Book of Five Rings and standard biographies; many duel details survive through tradition and legend, and dates in his early life vary between sources.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
