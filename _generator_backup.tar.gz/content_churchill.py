# -*- coding: utf-8 -*-
"""Full birth-to-death guide content for Winston Churchill."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#1e3a8a'  # British navy

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_wilderness():
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">THE 1930s · one man against the consensus of his age</text>'
    # consensus block (big) vs Churchill (small)
    b += '<rect x="40" y="60" width="380" height="120" rx="12" fill="#f1f5f9" stroke="#94a3b8" stroke-width="1.6"/>'
    b += '<text x="56" y="84" font-size="12" font-weight="800" fill="#475569">THE CONSENSUS: appeasement</text>'
    for i,t in enumerate(['“Never again” — the trauma of WWI','Germany has grievances; negotiate','Britain is unready; buy time at Munich (1938)']):
        ln,_=_tspans(56,108+i*22,'• '+t,10.5,'#5b6472',500,12,58); b+=ln
    b += '<rect x="470" y="60" width="210" height="120" rx="12" fill="#dbeafe" stroke="#1e3a8a" stroke-width="1.9"/>'
    b += '<text x="486" y="84" font-size="12" font-weight="800" fill="#1e3a8a">CHURCHILL: alone</text>'
    for i,t in enumerate(['Hitler means war','rearm NOW','appeasement feeds the aggressor']):
        ln,_=_tspans(486,108+i*22,'• '+t,10.5,'#1e40af',600,12,30); b+=ln
    b += '<line x1="470" y1="120" x2="422" y2="120" stroke="#dc2626" stroke-width="2" marker-end="url(#ah)"/>'
    b += '<text x="360" y="206" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He was mocked as a warmonger — until 1939 proved him right and made him the only man to lead.</text>'
    return _wrap(W, H, 'The Wilderness Years — being right too early', _tk(b, W, H, 'Being right before everyone else looks like being wrong — until events arrive to vindicate you.'), '', AC)

def svg_battleofbritain():
    W, H = 720, 262
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">SUMMER 1940 · how a smaller air force beat a larger one over Britain</text>'
    boxes=[(40,'#1e3a8a','Radar + control rooms','see raids coming; send fighters to the right place'),
           (270,'#0891b2','Home advantage','downed RAF pilots fly again; German ones are captured'),
           (500,'#16a34a','Hitler switches to the Blitz','stops hitting airfields → RAF recovers & wins')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="78" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="82" font-size="11" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,100,s,9.6,'#5b6472',500,11,30); b+=ss
    b += '<line x1="220" y1="99" x2="268" y2="99" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="99" x2="498" y2="99" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="11" fill="#1e3a8a" font-weight="800" text-anchor="middle">“Never was so much owed by so many to so few.”</text>'
    b += '<text x="360" y="196" font-size="10" fill="#334155" font-weight="600" text-anchor="middle">Britain survives → Hitler cannot invade → the war stays alive for the US and USSR to join.</text>'
    return _wrap(W, H, 'The Battle of Britain — a system, not just heroism', _tk(b, W, H, 'A well-run system (radar + repair + home ground) beat raw numbers — and simply not losing was the victory.'), '', AC)

def svg_ironcurtain():
    W, H = 720, 230
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1946 · Fulton, Missouri · naming the new divide before others saw it</text>'
    b += '<rect x="40" y="60" width="300" height="96" rx="12" fill="#dbeafe" stroke="#1e3a8a" stroke-width="1.7"/>'
    b += '<text x="56" y="84" font-size="11.5" font-weight="800" fill="#1e3a8a">THE WEST (free)</text>'
    ln,_=_tspans(56,104,'democracies, allied with the US',10,'#1e40af',500,12,44); b+=ln
    b += '<rect x="380" y="60" width="300" height="96" rx="12" fill="#fee2e2" stroke="#b91c1c" stroke-width="1.7"/>'
    b += '<text x="396" y="84" font-size="11.5" font-weight="800" fill="#b91c1c">THE EAST (Soviet)</text>'
    ln2,_=_tspans(396,104,'states behind Soviet control',10,'#991b1b',500,12,44); b+=ln2
    # the curtain
    b += '<rect x="356" y="52" width="8" height="112" fill="#334155"/>'
    b += '<text x="360" y="180" font-size="11" fill="#334155" font-weight="800" text-anchor="middle">“an iron curtain has descended across the Continent”</text>'
    return _wrap(W, H, 'The Iron Curtain — naming the Cold War', _tk(b, W, H, 'Again the lone early voice: he named the next great danger while the world still hoped it away.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1
PHASE_YOUNG = [
    E('birth', '1874–1895', 'An aristocrat with something to prove', ['RISE'],
      'Born in a palace to a famous, distant father and a glamorous American mother, he is a poor student written off as a failure — and grows up desperate to prove his worth and win fame.',
      svg_stack('The engine of his ambition', [
          {'n': 1, 'label': 'Born at Blenheim Palace (1874)', 'sub': 'grandson of a duke; father Lord Randolph, a rising Tory star', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'A neglected, mediocre schoolboy', 'sub': 'distant parents; poor grades; a stammer', 'color': '#64748b'},
          {'n': 3, 'label': 'Sandhurst & a hunger for glory', 'sub': 'the army as the stage to prove himself', 'color': '#16a34a'},
      ], takeaway='A craving for a distant father’s approval and a fear of being a failure fuelled a lifetime of relentless ambition.', accent=AC),
      bg='Winston Churchill was born in <b>1874</b> into the aristocratic Spencer-Churchill family, but his branch was not rich, and his parents were remote.',
      people='<b>Lord Randolph Churchill</b>, his brilliant, erratic father who died young having barely praised him; <b>Jennie Jerome</b>, his beautiful American mother; the nanny <b>Mrs Everest</b>, his real source of warmth.',
      what='A poor student with a lisp, he was steered into the army, graduating from <b>Sandhurst</b>. He burned to make a name for himself and escape the shadow of a father who thought little of him.',
      crux='Emotional deprivation became rocket fuel. The need to prove himself — to a father who never rated him and to the world — drove a superhuman work rate and appetite for the spotlight.',
      conseq='He entered adulthood hungry for fame and action, willing to take extraordinary risks to get noticed — a pattern that shaped his whole career.',
      matters='The drive to prove yourself, born of early doubt or rejection, is one of history’s most common engines of achievement — and Churchill ran on it his whole life.'),

    E('adventurer', '1895–1900', 'Soldier, writer, escape artist — building a legend', ['RISE', 'BATTLE'],
      'He turns himself into a celebrity by seeking out wars on three continents, writing bestselling books about them, and pulling off a daring prison-break in the Boer War that makes him a national hero.',
      svg_row('Manufacturing his own fame', [
          {'n': 1, 'label': 'Seek out wars', 'sub': 'India, Sudan (the Omdurman charge)', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Write bestsellers', 'sub': 'soldier + war correspondent; famous by his 20s', 'color': '#0891b2'},
          {'n': 3, 'label': 'Boer War escape (1899)', 'sub': 'captured, escapes 300 miles → national hero', 'color': '#16a34a'},
      ], edge_labels=['then', 'then'], takeaway='He didn’t wait for fame — he engineered it, turning danger into stories and stories into a platform for power.', accent=AC),
      bg='In the 1890s, a young officer could win fame in Britain’s many small colonial wars — and Churchill deliberately used journalism and books to broadcast his exploits.',
      people='General <b>Kitchener</b> (whose Sudan campaign Churchill joined and later criticised); the <b>Boer</b> captors he escaped; the British public, whom he learned to court through the press.',
      what='He fought on the North-West Frontier of <b>India</b>, rode in the cavalry charge at <b>Omdurman (1898)</b>, and as a war correspondent in the <b>Boer War (1899)</b> was captured and made a <b>dramatic 300-mile escape</b> — turning himself into a household name.',
      crux='He understood, before it was common, that <b>publicity is power</b>. Combining physical courage with a gift for words, he built a personal brand that could carry him into politics.',
      conseq='Riding his fame, he was <b>elected to Parliament in 1900</b> at 25, launching a political career that would last more than half a century.',
      matters='Courage plus communication is a potent combination. Doing brave things is not enough — Churchill won power by also being the one who told the story.'),
]

# ==================================================================  PHASE 2
PHASE_RISE = [
    E('omdurman', '1898', 'The charge at Omdurman — riding into legend', ['RISE', 'BATTLE'],
      'In the Sudan the young cavalry subaltern takes part in one of the last great British cavalry charges — a few desperate minutes at Omdurman that he turns, like everything, into a vivid book and another rung of fame.',
      svg_stack('Turning danger into celebrity', [
          {'n': 1, 'label': 'Attaches himself to the Sudan war', 'sub': 'pulls strings to join Kitchener’s 1898 campaign', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Charges with the 21st Lancers', 'sub': 'one of the last British cavalry charges, at Omdurman', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Writes “The River War”', 'sub': 'the experience becomes another bestselling book', 'color': '#a16207'},
      ], takeaway='He courted danger deliberately — then converted it into the words and reputation that carried him upward.', accent=AC),
      bg='Ambitious for glory and short of money, the young Churchill used family connections to attach himself to Britain’s colonial wars as both soldier and paid correspondent.',
      people='<b>Lord Kitchener</b>, who disliked the pushy young officer; the Dervish army of the Mahdist state; the readers who devoured his dispatches.',
      what='At the <b>Battle of Omdurman (1898)</b> Churchill rode in the charge of the <b>21st Lancers</b>, then wrote the acclaimed <b>The River War</b> — repeating his formula of war, writing and self-promotion.',
      crux='He understood early that <b>experience plus a pen equals fame</b> — deliberately seeking the front so he could sell the story.',
      conseq='By 1900, still in his twenties, he was a national name and war hero, poised to enter Parliament.',
      matters='Reputations can be manufactured: those who seek out the dramatic and then tell the tale write their own legend.'),

    E('reformer', '1900–1914', 'Crossing the floor — power and reform', ['POLITICS', 'REFORM'],
      'He abandons his own party over principle, joins the Liberals, and helps build the foundations of the British welfare state — rising fast to run the Navy as the world drifts toward war.',
      svg_row('An early willingness to switch sides for ends he believed in', [
          {'n': 1, 'label': 'Crosses to the Liberals (1904)', 'sub': 'breaks with Tory protectionism', 'color': '#64748b'},
          {'n': 2, 'label': 'Social reform', 'sub': 'labour exchanges, early welfare, with Lloyd George', 'color': '#0891b2'},
          {'n': 3, 'label': 'First Lord of the Admiralty (1911)', 'sub': 'modernises the Royal Navy for the coming war', 'color': '#1e3a8a'},
      ], edge_labels=['then', 'then'], takeaway='He put conviction (and ambition) above party loyalty — a habit that won him office and a reputation as unreliable.', accent=AC),
      bg='Edwardian Britain was debating free trade, poverty and the naval race with Germany. Churchill, restless and ambitious, moved to where he could act.',
      people='<b>David Lloyd George</b>, his radical Liberal ally in social reform; the Conservatives he abandoned (and would later rejoin); Kaiser Wilhelm’s Germany, building a rival fleet.',
      what='He <b>crossed the floor to the Liberals</b> in 1904, helped pioneer <b>labour exchanges and early social insurance</b>, and as <b>First Lord of the Admiralty from 1911</b> pushed to modernise the fleet (oil-fired ships, naval aviation).',
      crux='He was driven by results over tribal loyalty — willing to change parties twice in his life. It made him effective and powerful, but also distrusted as an opportunist.',
      conseq='He entered the First World War as the political head of the world’s most powerful navy — and soon staked his reputation on a bold, disastrous gamble.',
      matters='Independence of mind is an asset and a liability: it lets you do the right thing against your tribe, but it costs you the trust that loyalty buys.'),

    E('homesecretary', '1910–1911', 'Home Secretary — Tonypandy and Sidney Street', ['POLITICS', 'BATTLE'],
      'As the minister for law and order, Churchill’s restless energy takes him from sending troops toward striking Welsh miners to standing personally in the street directing a gun-battle with anarchists — feeding both a reputation for boldness and a lasting distrust of his judgement.',
      svg_row('A minister who could not stay at his desk', [
          {'n': 1, 'label': 'Tonypandy, 1910', 'sub': 'troops readied against striking Welsh miners — never forgotten in Wales', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Siege of Sidney Street, 1911', 'sub': 'he turns up in person to direct the police and soldiers', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'Bold — or reckless?', 'sub': 'admirers see decisiveness; critics see a man who overreaches', 'color': '#a16207'},
      ], edge_labels=['then', 'so'], takeaway='His hands-on daring thrilled the public and alarmed colleagues — a pattern that would define his whole career.', accent=AC),
      bg='Appointed <b>Home Secretary</b> in 1910, Churchill oversaw policing and prisons during a period of industrial unrest and anarchist scares.',
      people='The striking miners of the Rhondda; the <b>Latvian anarchists</b> besieged in London’s East End; the newsreel cameras that caught him at the scene.',
      what='He was blamed (fairly or not) for deploying force at <b>Tonypandy</b>, and famously appeared in person at the <b>Siege of Sidney Street</b> (1911) to oversee the shootout — an image of a minister who could not resist the action.',
      crux='His instinct to <b>rush toward drama</b> made him vivid and effective but also fed doubts about his steadiness — doubts that shadowed him for decades.',
      conseq='Tonypandy poisoned his standing with organised labour for life; Sidney Street became an early emblem of his flair and his recklessness alike.',
      matters='The same boldness that makes a leader compelling can make colleagues wonder whether he can be trusted with restraint.'),

    E('admiralty', '1911–1915', 'Arming for war — the Navy and the tank', ['REFORM', 'BATTLE'],
      'As head of the Royal Navy before and during the First World War, he modernises the fleet, converts it from coal to oil, and — restlessly inventive — becomes the political champion of a strange new armoured machine, the "landship" that the world would come to call the tank.',
      svg_row('The restless moderniser of war', [
          {'n': 1, 'label': 'Modernises the Navy', 'sub': 'First Lord; the switch from coal to oil', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Backs the tank', 'sub': 'champions the “landships” committee', 'color': '#b45309'},
          {'n': 3, 'label': 'A taste for new weapons', 'sub': 'lifelong enthusiasm for technology in war', 'color': '#16a34a'},
      ], edge_labels=['then', 'plus'], takeaway='He was an early, energetic backer of military innovation — from oil-fired battleships to the tank.', accent=AC),
      bg='As <b>First Lord of the Admiralty</b> from 1911, Churchill led the world’s most powerful navy into the First World War and pushed hard for modernisation.',
      people='The Royal Navy; the engineers and officers behind the early <b>tank</b>; the fleet Churchill re-equipped.',
      what='Churchill <b>modernised the Royal Navy</b> — including the strategic shift from <b>coal to oil</b> — and, fascinated by new technology, became a political <b>champion of the tank</b> (“landships”), helping drive its early development.',
      crux='He had a lifelong <b>enthusiasm for technological innovation in war</b>, repeatedly backing new weapons and methods ahead of more cautious minds.',
      conseq='His naval reforms strengthened Britain for the war; the tank he backed would help break the trench deadlock.',
      matters='Churchill’s eye for military innovation was a real strength — the same restless boldness that, at Gallipoli, would also produce catastrophe.'),

    E('gallipoli', '1915', 'Gallipoli — the great catastrophe', ['BATTLE', 'DEFEAT', 'TRAGEDY'],
      'He champions a bold plan to knock the Ottomans out of the war by forcing a sea passage to Constantinople. It fails bloodily, tens of thousands die, and Churchill is blamed and cast out of power.',
      svg_stack('How a brilliant idea became a bloody failure', [
          {'n': 1, 'label': 'The idea: a knockout blow', 'sub': 'force the Dardanelles → take Constantinople → open a new front', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Botched execution', 'sub': 'naval attack fails; landings delayed & mismanaged', 'color': '#b45309'},
          {'n': 3, 'label': 'Stalemate & slaughter', 'sub': 'trapped on beaches; ~250k Allied casualties', 'color': '#dc2626'},
          {'n': 4, 'label': 'Churchill blamed & demoted', 'sub': 'resigns; goes to command in the trenches', 'color': '#475569'},
      ], takeaway='A sound strategic idea, wrecked by poor execution, still lands on the person who championed it. Ideas are judged by outcomes.', accent=AC),
      bg='By 1915 the Western Front was a deadlocked meat-grinder. Churchill backed a plan to break the stalemate by attacking Germany’s weaker ally, the <b>Ottoman Empire</b>, via the Dardanelles straits.',
      people='The Anzac (Australian & New Zealand), British and French troops who suffered on the beaches; the Turkish defenders (and the future <b>Atatürk</b>, who made his name there); Admiral <b>Fisher</b>, who resigned over it.',
      what='The <b>naval attempt to force the Dardanelles</b> failed, and the follow-up <b>Gallipoli landings (1915)</b> bogged down into another bloody stalemate, costing hundreds of thousands of casualties before evacuation. Churchill, the plan’s champion, was <b>blamed, demoted, and left the government</b>.',
      crux='The concept — a decisive flanking blow — was defensible; the <b>execution</b> was catastrophic. But strategy is judged by results, and the failure attached permanently to his name.',
      conseq='His reputation was shattered; he spent a period commanding troops in the trenches. For years, “Gallipoli” was a byword for his supposed recklessness — a shadow over his career until 1940.',
      matters='You own the outcomes of the bold ideas you push, not just the logic behind them. And a great failure need not be final — but it will define you until a greater success replaces it.'),

    E('antibolshevik', '1918–1920', 'Strangle it in the cradle — the crusade against Bolshevism', ['POLITICS', 'BATTLE', 'DEFEAT'],
      'Almost alone in the cabinet, Churchill throws himself into arming the White armies against the new Soviet state, urging that Bolshevism be “strangled in its cradle” — a passionate, futile crusade that fails and marks him as an anti-communist obsessive.',
      svg_stack('The lost war on the Revolution', [
          {'n': 1, 'label': 'Bolsheviks seize Russia, 1917', 'sub': 'Churchill sees a mortal threat to civilisation', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Arms the White armies', 'sub': 'pushes British intervention and supplies against Lenin', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'The Whites collapse, 1920', 'sub': 'the intervention fails; he is mocked as obsessed', 'color': '#78716c'},
      ], takeaway='His hatred of Bolshevism ran decades ahead of his colleagues — right in the long run, but futile and isolating then.', accent=AC),
      bg='After 1917 the Allied powers half-heartedly intervened in the Russian Civil War. Churchill, as War Secretary, became the loudest voice for crushing the Bolsheviks outright.',
      people='<b>Lenin</b>’s Bolsheviks; the <b>White</b> generals Churchill supplied; cabinet colleagues, weary of war, who resented his zeal.',
      what='Churchill urged all-out support for the <b>White armies</b> and famously wanted to “strangle Bolshevism in its cradle.” The intervention <b>failed</b> and was wound down by 1920, deepening his reputation for reckless obsession.',
      crux='He saw the ideological menace of communism <b>earlier and more fiercely</b> than almost anyone — but misjudged both the cost and the futility of the fight.',
      conseq='The episode isolated him and gave the left a lasting grievance; yet his instinct about Soviet danger would look prophetic by 1946.',
      matters='Being right too early can be as politically costly as being wrong — vindication may arrive decades after the ridicule.'),

    E('irishtreaty', '1921–1922', 'Making peace in Ireland', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'The same minister who unleashed the hated Black and Tans helps negotiate the treaty that creates the Irish Free State — sitting across from the guerrilla leaders he had been fighting, and showing a pragmatism that surprises everyone.',
      svg_row('From coercion to compromise', [
          {'n': 1, 'label': 'The Black and Tans, 1920', 'sub': 'brutal irregulars deployed against the IRA', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Treaty negotiations, 1921', 'sub': 'Churchill helps hammer out the Anglo-Irish settlement', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'The Irish Free State', 'sub': 'a self-governing dominion — and a bitter civil war', 'color': '#16a34a'},
      ], edge_labels=['then', 'creates'], takeaway='He could switch from ruthless coercion to hard-headed deal-making when force reached its limits.', accent=AC),
      bg='The Irish War of Independence (1919–21) pitted the IRA against British forces including the notorious <b>Black and Tans</b>, whose deployment Churchill backed as a minister.',
      people='<b>Michael Collins</b>, the guerrilla leader turned negotiator; <b>Lloyd George</b>, the PM; the Irish and British delegations at the 1921 talks.',
      what='Churchill took part in negotiating the <b>Anglo-Irish Treaty</b> (Dec 1921), creating the <b>Irish Free State</b>, and later worked pragmatically with Collins’s new government even as Ireland slid into civil war.',
      crux='He combined <b>willingness to use hard force</b> with <b>readiness to compromise</b> once force could not win — an unsentimental realism.',
      conseq='The Treaty settled the core of the Irish question but triggered a civil war and left partition; Churchill’s role showed his adaptability.',
      matters='Effective statecraft often means being both the fist and the handshake — knowing when each has done its work.'),

    E('interwar', '1917–1929', 'Comeback, high office — and costly blunders', ['POLITICS', 'REFORM'],
      'He claws his way back into government, running munitions and then the War and Air ministries — but as Chancellor of the Exchequer he makes a fateful mistake, forcing Britain back onto the gold standard at too high a rate, worsening the slump and helping trigger the General Strike.',
      svg_row('Back in power — and out of his depth at the Treasury', [
          {'n': 1, 'label': 'Munitions, War, Air', 'sub': 'rehabilitated into senior office after Gallipoli', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Chancellor, 1924', 'sub': 'returns Britain to gold at too high a rate', 'color': '#b45309'},
          {'n': 3, 'label': 'The General Strike, 1926', 'sub': 'deflation and hardship; a hardline stance', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He proved he could recover from disgrace — and that outside war and strategy, his judgement could be badly wrong.', accent=AC),
      bg='After Gallipoli, Churchill rebuilt his career through the later war and the 1920s, holding several senior posts under changing governments.',
      people='Chancellor-era advisers (and critics like <b>Keynes</b>, who savaged the gold decision); the striking workers of 1926.',
      what='Churchill served as Minister of <b>Munitions</b>, then <b>War and Air</b>, and — remarkably for a former Liberal — became Conservative <b>Chancellor of the Exchequer (1924–29)</b>. His decision to return sterling to the <b>gold standard</b> at the pre-war parity deepened deflation and unemployment and contributed to the <b>1926 General Strike</b>, which he confronted combatively.',
      crux='His restless brilliance in war contrasted with <b>poor economic judgement</b>: on the gold standard he deferred to orthodoxy and got it badly wrong, a reminder that genius in one field is no guarantee in another.',
      conseq='When the Conservatives fell in 1929, Churchill went out of office — into the political “wilderness” that would last a decade.',
      matters='Brilliance is domain-specific. The man who would read Hitler perfectly misjudged the economy — a caution against assuming a great mind is great at everything.'),
]

# ==================================================================  PHASE 3
PHASE_WILDERNESS = [
    E('wilderness', '1929–1939', 'The Wilderness Years — the lone warning', ['POLITICS', 'TURNING POINT'],
      'Out of office and dismissed as a has-been, he spends the 1930s as a lonely, mocked voice warning that Hitler means war and that appeasement is feeding a monster. Almost no one listens — until he is proved right.',
      svg_wilderness(),
      bg='After holding high office (including a rocky turn as Chancellor), Churchill fell out of favour and spent the <b>1930s out of government</b>. Britain, traumatised by WWI, wanted peace at almost any price.',
      people='Prime Minister <b>Neville Chamberlain</b>, architect of appeasement (the <b>Munich Agreement, 1938</b>); <b>Adolf Hitler</b>, rearming Germany; a political class and public desperate to avoid another war.',
      what='Churchill repeatedly <b>warned about German rearmament</b> and opposed <b>appeasement</b>, especially the 1938 Munich deal (“you were given the choice between war and dishonour; you chose dishonour and you will have war”). He was widely dismissed as a warmonger.',
      crux='He was <b>right too early</b>. Seeing a danger before it is obvious makes you sound alarmist; only when events catch up does foresight look like wisdom rather than obsession.',
      conseq='When war came in 1939 exactly as he’d warned, his credibility was total — he was the one man untainted by appeasement, and the obvious choice to lead when disaster struck.',
      matters='The price of being right before your time is ridicule; the reward, if you survive it, is unmatched authority the moment reality proves you correct.'),

    E('abdication', '1935–1937', 'Why no one listened — India and the abdication', ['POLITICS', 'DEFEAT'],
      'His isolation is partly self-inflicted: he spends the early 1930s in a die-hard, losing crusade against Indian self-government, then stakes his credibility defending King Edward VIII in the abdication crisis — squandering the very authority he needed to be heard on the far graver danger of Hitler.',
      svg_row('Squandering his own credibility', [
          {'n': 1, 'label': 'Die-hard on India', 'sub': 'a bitter, losing fight against Indian home rule', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Backs Edward VIII', 'sub': 'defends the king in the 1936 abdication crisis', 'color': '#b45309'},
          {'n': 3, 'label': 'Credibility spent', 'sub': 'seen as a reckless reactionary — so Hitler warnings ignored', 'color': '#1e3a8a'},
      ], edge_labels=['then', 'so'], takeaway='He kept spending his authority on losing causes — which is part of why his crucial warnings on Hitler went unheard.', accent=AC),
      bg='In the 1930s Churchill was not only warning about Germany but embroiled in other, damaging fights that eroded his standing.',
      people='The Indian independence movement (and <b>Gandhi</b>, whom Churchill scorned); <b>King Edward VIII</b> and the abdication crisis of 1936.',
      what='Churchill led a <b>die-hard campaign against Indian self-government</b> — out of step with his own party and history — and then <b>championed Edward VIII</b> during the <b>1936 abdication crisis</b>. Both were losing causes that made him look reckless and reactionary, deepening his isolation.',
      crux='He <b>burned credibility on the wrong battles</b>: by the time his Hitler warnings mattered most, many dismissed him as a serial contrarian rather than a prophet.',
      conseq='His authority was at a low ebb just when Europe most needed his foresight heeded — a self-inflicted part of the tragedy of the 1930s.',
      matters='Authority is a finite currency. Churchill’s wilderness years warn that spending your credibility on doomed causes can silence you on the one that counts.'),

    E('munich', '1938', 'Munich — “a total and unmitigated defeat”', ['POLITICS', 'TURNING POINT'],
      'When Chamberlain returns from Munich waving “peace for our time,” a nation cheers — and Churchill rises in a jeering Commons to call it what he believes it is: a total and unmitigated defeat that has only postponed and worsened the coming war.',
      svg_stack('The lonely dissent against appeasement', [
          {'n': 1, 'label': 'Munich Agreement, Sep 1938', 'sub': 'Czechoslovakia’s borderlands handed to Hitler for “peace”', 'color': '#78716c'},
          {'n': 2, 'label': 'A cheering, relieved Britain', 'sub': 'Chamberlain hailed; Churchill almost alone against it', 'color': '#a16207'},
          {'n': 3, 'label': '“A total and unmitigated defeat”', 'sub': 'he warns the reckoning has only been deferred', 'color': '#b91c1c'},
      ], takeaway='Against a euphoric consensus, he named the disaster plainly — and was proved right within a year.', accent=AC),
      bg='By 1938 Hitler demanded the Sudetenland. Chamberlain’s <b>Munich Agreement</b> ceded it to avoid war and was greeted in Britain with enormous relief.',
      people='<b>Neville Chamberlain</b>, the architect of appeasement; the Czechs, abandoned; the small band of MPs who shared Churchill’s alarm.',
      what='In the Commons debate Churchill declared Munich “<b>a total and unmitigated defeat</b>,” warning that feeding a dictator only whetted his appetite — to boos and hostility from many on his own side.',
      crux='He judged that appeasement <b>bought a worse war, not peace</b> — trading a strong position for a weaker one and dishonour besides.',
      conseq='Hitler seized the rest of Czechoslovakia in March 1939 and invaded Poland that September, vindicating Churchill and paving his road to power.',
      matters='The courage to reject a comforting consensus, and to be jeered for it, is often the mark of the clearest sight in the room.'),

    E('empire', '1900s–1945', 'The imperialist — and the shadow of Bengal', ['POLITICS', 'TRAGEDY'],
      'The same man who defied Hitler held Victorian views of the British Empire and race that sit uneasily with modern eyes — a fierce opponent of Indian independence, and a wartime leader whose policies are widely linked to the catastrophic Bengal famine of 1943, in which millions died. An honest account holds his greatness and these failings together.',
      svg_compare('Two truths that must be held together',
          {'head': 'The heroic Churchill', 'color': '#1e3a8a',
           'items': ['stood alone against Nazi tyranny', 'defended democracy and liberty', 'a defining champion of freedom']},
          {'head': 'The imperial Churchill', 'color': '#7f1d1d',
           'items': ['opposed Indian self-rule; held Victorian racial views', 'policies linked to the 1943 Bengal famine', 'millions died as grain was diverted']},
          verdict='A defender of liberty in Europe and an unrepentant imperialist abroad — both are genuinely him.',
          takeaway='Honest history refuses to choose: Churchill was both the hero of 1940 and an imperialist tied to real catastrophe.', accent=AC),
      bg='Churchill was a product of the Victorian empire and held its assumptions about British rule and racial hierarchy throughout his life.',
      people='The people of <b>India</b>, whose independence he resisted; the millions who died in the <b>Bengal famine of 1943</b>; his critics then and since.',
      what='Churchill was a lifelong <b>imperialist</b> who fiercely opposed Indian independence and expressed <b>Victorian racial views</b>. As wartime PM, his government’s decisions (diverting grain and shipping) are widely linked by historians to the <b>Bengal famine of 1943</b>, in which some <b>three million</b> died — a bitterly contested stain on his record.',
      crux='He embodies a hard historical truth: the <b>same person can be a champion of liberty and a party to catastrophe</b>, and both must be acknowledged.',
      conseq='His imperial attitudes and the Bengal famine remain central to a fuller, more critical modern reckoning with his legacy.',
      matters='Great figures are not simple. This guide presents Churchill’s heroism and his serious failings side by side, and lets you weigh them.'),
]

# ==================================================================  PHASE 4
PHASE_FINEST = [
    E('norway', 'Apr–May 1940', 'The Norway debate — how he finally reached power', ['POLITICS', 'TURNING POINT'],
      'His moment comes through an irony: it is the failure of a Norway campaign he himself helped direct that destroys confidence in Chamberlain — and in a dramatic Commons debate, Parliament turns on the appeaser and, when Labour refuses to serve under him, the crown passes to Churchill on the very day Hitler strikes west.',
      svg_row('The collapse that carried him to No. 10', [
          {'n': 1, 'label': 'The Norway fiasco', 'sub': 'a failed 1940 campaign discredits the government', 'color': '#b45309'},
          {'n': 2, 'label': 'The Norway Debate', 'sub': 'Parliament turns on Chamberlain', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'Churchill becomes PM', 'sub': 'Labour won’t serve under Chamberlain — so he goes', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='The very campaign whose failure toppled Chamberlain carried Churchill, ironically, into power.', accent=AC),
      bg='By May 1940, the failure of the <b>Norway campaign</b> (which Churchill had helped direct as First Lord) triggered a crisis of confidence in <b>Chamberlain’s</b> government.',
      people='Prime Minister <b>Neville Chamberlain</b>; the MPs who turned against him in the <b>Norway Debate</b>; the Labour leaders who refused to serve under him.',
      what='After the <b>Norway Debate</b> shattered confidence in Chamberlain, and with <b>Labour refusing to join a government he led</b>, Chamberlain resigned. On <b>10 May 1940</b>, as Germany invaded the West, <b>Churchill became Prime Minister</b>.',
      crux='He reached power at the <b>exact moment of maximum crisis</b>, partly through the failure of a campaign he had shared in — a supreme irony of timing.',
      conseq='Churchill took office as the war entered its most desperate phase, uniquely placed as the man untainted by appeasement.',
      matters='History’s turning points often hinge on timing and irony. Churchill rose on the wreckage of a policy he had helped pursue, at the hour Britain most needed him.'),
    E('pm', 'May 1940', 'Prime Minister — “blood, toil, tears and sweat”', ['POLITICS', 'TURNING POINT', 'TRIUMPH'],
      'As Germany overruns western Europe, Churchill becomes Prime Minister at the darkest possible moment — and, when many want to negotiate with Hitler, refuses, choosing to fight on alone.',
      svg_row('The decision that mattered most', [
          {'n': 1, 'label': 'Becomes PM (10 May 1940)', 'sub': 'as Germany invades France & the Low Countries', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'The cabinet crisis', 'sub': 'some want to seek terms with Hitler', 'color': '#b45309'},
          {'n': 3, 'label': 'He chooses to fight on', 'sub': 'no negotiation; rally the nation to resist', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='His single most important act was a refusal — to make peace with Hitler when surrender looked rational.', accent=AC),
      bg='In <b>May 1940</b>, German forces smashed through the West. France was collapsing; Britain faced the prospect of standing alone against a triumphant Nazi Germany.',
      people='<b>Neville Chamberlain</b> (resigned); <b>Lord Halifax</b>, who favoured exploring terms; King <b>George VI</b>; and the British people, whom Churchill addressed directly through radio and Parliament.',
      what='Churchill became <b>Prime Minister on 10 May 1940</b>, offering only “<b>blood, toil, tears and sweat</b>.” In a pivotal cabinet debate he <b>rejected any negotiated peace</b> with Hitler and committed Britain to fight on.',
      crux='The core of leadership here was <b>will and words</b>: the refusal to give in when it looked hopeless, and the ability to make an entire nation believe that resistance was possible and right.',
      conseq='Britain fought on, becoming the base from which the war against Nazi Germany could eventually be won. Had it sought terms in 1940, the 20th century might have gone very differently.',
      matters='At the decisive moment, leadership can come down to a single act of will — refusing the “sensible” surrender — and the ability to make others share your resolve.'),

    E('maytalks', 'May 1940', 'The War Cabinet crisis — the choice to fight on', ['POLITICS', 'TURNING POINT', 'TRIUMPH'],
      'In his first desperate days as PM, with France collapsing and the army trapped at Dunkirk, Churchill fights a three-day battle inside his own War Cabinet against Lord Halifax’s push to explore peace terms with Hitler — and wins the argument that decides the war.',
      svg_stack('The hidden debate that saved the war', [
          {'n': 1, 'label': 'France falling, army trapped', 'sub': 'late May 1940 — catastrophe on every front', 'color': '#78716c'},
          {'n': 2, 'label': 'Halifax urges exploring terms', 'sub': 'sound out Hitler via Mussolini — a negotiated peace', 'color': '#a16207'},
          {'n': 3, 'label': 'Churchill refuses', 'sub': 'no talks; rally the nation to fight on alone', 'color': '#b91c1c'},
      ], takeaway='The war’s outcome may have hinged less on any battle than on his winning this quiet argument.', accent=AC),
      bg='Only days into office, Churchill led a divided War Cabinet as France crumbled. Foreign Secretary <b>Lord Halifax</b> argued Britain should at least explore what terms Hitler might offer.',
      people='<b>Lord Halifax</b>, the respected advocate of talks; <b>Chamberlain</b>, whose support Churchill needed; the trapped British army at Dunkirk.',
      what='Over three days (25–28 May 1940) Churchill <b>rejected any approach for terms</b>, arguing negotiation from weakness meant slavery. He rallied the wider cabinet with the vow that Britain would fight on, and Halifax was overruled.',
      crux='He saw that <b>opening talks would itself be fatal</b> — it would sap the will to resist and hand Hitler the initiative without a shot.',
      conseq='Britain fought on alone through 1940–41, keeping the war open until the USSR and USA entered — the indispensable precondition of victory.',
      matters='Some of history’s greatest decisions are arguments won in a private room — resolve at the right moment can outweigh armies.'),

    E('britain', '1940', 'Dunkirk and the Battle of Britain', ['BATTLE', 'TRIUMPH'],
      'The trapped British army escapes at Dunkirk, and then the RAF — helped by radar and home advantage — beats back the German air force, denying Hitler the invasion he needs. Britain survives.',
      svg_battleofbritain(),
      bg='After France fell, Germany needed to defeat Britain — first by destroying the <b>RAF</b> to allow an invasion. The <b>Battle of Britain</b> (summer 1940) was fought in the skies.',
      people='The <b>RAF fighter pilots</b> (“the Few”); <b>Air Chief Marshal Dowding</b>, who built the radar-and-control defence system; the German <b>Luftwaffe</b> under Göring.',
      what='First the <b>Dunkirk evacuation</b> rescued ~338,000 trapped troops. Then, in the <b>Battle of Britain</b>, the outnumbered RAF — using <b>radar</b>, an integrated control system, and home advantage — inflicted unsustainable losses on the Luftwaffe. Hitler shifted to bombing cities (the <b>Blitz</b>) and shelved invasion.',
      crux='It was won by a <b>system</b> as much as by courage: radar gave early warning, downed RAF pilots could fly again, and simply <b>not being defeated</b> was itself the victory Britain needed.',
      conseq='Britain remained unconquered and in the war — the essential precondition for the later entry of the USSR and USA and the eventual defeat of Nazi Germany.',
      matters='Sometimes winning means simply not losing. And durable strength often comes from a good system (organisation, information, resilience), not just individual heroics.'),

    E('mersalkebir', 'Jul 1940', 'Mers-el-Kébir — firing on a former ally', ['BATTLE', 'TRAGEDY', 'TURNING POINT'],
      'To stop France’s powerful fleet falling into Hitler’s hands, Churchill orders the Royal Navy to attack it in a North African port — killing nearly 1,300 French sailors, a ruthless act that appals many but proves to a watching America that Britain will do anything to survive.',
      svg_row('A brutal proof of resolve', [
          {'n': 1, 'label': 'France surrenders, Jun 1940', 'sub': 'its fleet could double German naval power', 'color': '#78716c'},
          {'n': 2, 'label': 'Ultimatum refused at Mers-el-Kébir', 'sub': 'the French squadron will neither join Britain nor disarm', 'color': '#a16207'},
          {'n': 3, 'label': 'The Navy opens fire', 'sub': '~1,300 French sailors killed; the fleet neutralised', 'color': '#b91c1c'},
      ], edge_labels=['so', 'and'], takeaway='He chose a terrible act over a mortal risk — and signalled to the world that Britain would not flinch.', accent=AC),
      bg='After France’s fall in June 1940, its modern navy was a decisive prize. Churchill could not risk it being used against Britain, whatever the armistice promised.',
      people='The French Admiral <b>Gensoul</b>, given an ultimatum; the French sailors killed; <b>Roosevelt</b> and the US, watching to judge Britain’s will.',
      what='When the French squadron at <b>Mers-el-Kébir</b> rejected Britain’s ultimatum, Churchill ordered it destroyed. Nearly <b>1,300 French sailors died</b>. It shocked opinion but demonstrated iron resolve.',
      crux='He accepted a <b>morally agonising, relationship-shattering act</b> because the strategic risk of inaction was existential.',
      conseq='It embittered Anglo-French relations but helped convince Roosevelt that Britain was worth backing — a step toward American support.',
      matters='Leadership in crisis sometimes means choosing the lesser of two terrible options — and owning the blood it costs.'),

    E('blitz', '1940–1941', 'The Blitz — holding a bombed nation together', ['BATTLE', 'TRIUMPH'],
      'Unable to win the air battle, Hitler tries to break Britain’s will by bombing its cities night after night — and Churchill answers with defiant visits to the rubble and radio speeches that turn sheer endurance into a moral victory, keeping a battered people in the fight.',
      svg_row('Turning endurance into a weapon', [
          {'n': 1, 'label': 'Cities bombed nightly', 'sub': 'London and others pounded for months', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Churchill in the ruins', 'sub': 'visits bomb sites; broadcasts defiance', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'Morale holds', 'sub': 'the will to resist survives the Blitz', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He made national endurance itself a form of victory — “London can take it” became a weapon of war.', accent=AC),
      bg='After failing to win air superiority, Germany switched to the <b>Blitz</b> — sustained night bombing of British cities intended to shatter civilian morale.',
      people='The bombed civilians of London, Coventry and other cities; the RAF and civil-defence workers; a watching, still-neutral America.',
      what='Through the winter of <b>1940–41</b>, German bombing killed tens of thousands and devastated British cities. Churchill <b>toured the rubble</b>, projected calm defiance, and used his <b>broadcasts</b> to frame endurance as heroism — helping morale hold.',
      crux='He understood the Blitz was a <b>battle of will</b>, not just of bombs: if the people’s spirit held, the bombing failed strategically no matter the damage.',
      conseq='British morale did not break; the failure of the Blitz, like the Battle of Britain, showed the world that Hitler could be resisted.',
      matters='Leadership in catastrophe is largely about meaning: Churchill gave a terrified, bombed nation a story of defiance it could live up to.'),

    E('atlantic', '1940–1943', 'The Battle of the Atlantic — “the only thing that frightened me”', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'The one campaign Churchill later said truly frightened him was invisible: the U-boat war on the convoys that fed and armed Britain. Lose the Atlantic and the island starves — and for two grim years it hung in the balance.',
      svg_stack('The lifeline that nearly snapped', [
          {'n': 1, 'label': 'Britain depends on the convoys', 'sub': 'food, oil and arms all cross the Atlantic', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'U-boat “wolf packs” maul them', 'sub': 'shipping losses soar toward the unsustainable', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Tech and code-breaking turn it', 'sub': 'escorts, radar, air cover and Ultra beat the packs by 1943', 'color': '#16a34a'},
      ], takeaway='The war’s quietest front was its most dangerous — starvation, not invasion, was the true threat.', accent=AC),
      bg='An island nation, Britain imported most of its food and fuel by sea. German <b>U-boats</b> aimed to sever those convoys and starve the country into surrender.',
      people='The merchant seamen and convoy escorts; the code-breakers of <b>Bletchley Park</b> reading U-boat signals; Admiral <b>Dönitz</b>’s submarine fleet.',
      what='For nearly three years the <b>Battle of the Atlantic</b> raged, with shipping losses at times outstripping replacement. Escort carriers, long-range aircraft, radar and <b>Ultra</b> intelligence finally broke the wolf packs in mid-1943.',
      crux='Everything else depended on this: without the convoys there was <b>no fuel, no food and no build-up</b> for any offensive.',
      conseq='Victory in the Atlantic made possible the bomber offensive, the North African and Italian campaigns, and ultimately D-Day.',
      matters='The decisive struggle is not always the visible one — logistics and supply can matter more than any single battle.'),

    E('alamein', '1942–1943', 'The worst year — and the turning of the tide', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'His darkest stretch as war leader: the fall of Singapore is the worst defeat in British history and he survives a confidence vote — but then victory at El Alamein finally turns the tide in the desert, giving him, at last, a triumph to ring the church bells for.',
      svg_row('From humiliation to the first great victory', [
          {'n': 1, 'label': 'Fall of Singapore, 1942', 'sub': 'Britain’s worst-ever military defeat; he is doubted', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Survives a no-confidence vote', 'sub': 'his leadership is challenged and holds', 'color': '#b45309'},
          {'n': 3, 'label': 'El Alamein, late 1942', 'sub': 'victory in the desert — “the end of the beginning”', 'color': '#16a34a'},
      ], edge_labels=['then', 'then'], takeaway='He weathered the war’s worst defeats and a challenge to his own leadership — then El Alamein gave Britain its first clear win.', accent=AC),
      bg='1942 brought a run of catastrophes — above all the <b>fall of Singapore</b> to Japan — that shook confidence in Churchill even as PM.',
      people='General <b>Montgomery</b>, victor of El Alamein; the critics who challenged Churchill in Parliament; the Commonwealth troops lost at Singapore.',
      what='The <b>fall of Singapore (Feb 1942)</b> — the surrender of a huge garrison — was the <b>worst defeat in British military history</b>, and Churchill <b>survived a no-confidence vote</b>. Then <b>El Alamein (Oct–Nov 1942)</b> under Montgomery brought a decisive victory; Churchill called it “the end of the beginning.”',
      crux='He <b>held his nerve and his office through the war’s lowest point</b>, and understood El Alamein’s value as much psychological as military — proof at last that Britain could win.',
      conseq='The tide turned across 1942–43; with the USSR and USA now in the war, the initiative passed to the Allies.',
      matters='The hardest test of a leader is the middle of a long struggle, after the first defiance and before victory. Churchill’s survival of 1942 was its own kind of triumph.'),

    E('lendlease', '1940–1941', 'Courting America — “give us the tools”', ['POLITICS', 'TURNING POINT', 'TRIUMPH'],
      'Knowing Britain cannot win alone, Churchill spends 1940–41 wooing a neutral, wary United States — trading Atlantic bases for old destroyers, building a bond with Roosevelt, and winning Lend-Lease, the aid that keeps Britain fighting until America joins.',
      svg_row('Drawing in the indispensable ally', [
          {'n': 1, 'label': 'Destroyers-for-bases, Sep 1940', 'sub': '50 old US destroyers for leases on British bases', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Lend-Lease, Mar 1941', 'sub': 'America becomes the “arsenal of democracy” for Britain', 'color': '#16a34a'},
          {'n': 3, 'label': 'The Roosevelt relationship', 'sub': 'personal diplomacy binds the two nations’ war effort', 'color': '#a16207'},
      ], edge_labels=['then', 'built on'], takeaway='He grasped that survival meant pulling in the USA — and made courting Roosevelt his central strategy.', accent=AC),
      bg='Through 1940–41 the United States was neutral and cautious, but its industrial might was the only force that could ultimately defeat Germany. Churchill set out to draw it in.',
      people='President <b>Franklin Roosevelt</b>, sympathetic but constrained by isolationism; US public opinion, wary of another war; British envoys in Washington.',
      what='Churchill negotiated the <b>destroyers-for-bases</b> deal (1940), cultivated a close correspondence with Roosevelt, and secured <b>Lend-Lease</b> (1941) — vast American aid short of war. “Give us the tools,” he said, “and we will finish the job.”',
      crux='He saw that Britain’s role was to <b>survive and hold on</b> until American power could be engaged — and bent his diplomacy entirely to that end.',
      conseq='Lend-Lease and the Roosevelt bond underpinned the Grand Alliance that formed fully once the USSR and USA entered the war.',
      matters='Recognising that you cannot win alone — and patiently building the alliance that can — is a strategy in itself.'),

    E('victory', '1941–1945', 'The Grand Alliance and victory', ['POLITICS', 'TRIUMPH'],
      'He courts America and, after Hitler invades, allies with Stalin — forging the coalition that crushes Nazi Germany, and helping plan the great cross-Channel invasion that liberates Western Europe.',
      svg_stack('Turning survival into victory', [
          {'n': 1, 'label': 'Woo the United States', 'sub': 'Roosevelt, Lend-Lease, the Atlantic Charter', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Ally with Stalin (from 1941)', 'sub': '“If Hitler invaded Hell, I’d say a good word for the Devil”', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The Big Three at Tehran and Yalta', 'sub': 'coordinating grand strategy with two giants', 'color': '#b45309'},
          {'n': 4, 'label': 'D-Day → victory in Europe (1945)', 'sub': 'the Normandy invasion; Germany defeated', 'color': '#16a34a'},
      ], takeaway='He built and managed the alliance of far greater powers that ultimately destroyed Nazi Germany.', accent=AC),
      bg='Britain could not beat Germany alone. Churchill’s central strategic task from 1940 was to <b>bring in powerful allies</b>.',
      people='US President <b>Franklin D. Roosevelt</b>, whom Churchill assiduously courted; Soviet leader <b>Joseph Stalin</b>, an ally of necessity after Germany invaded the USSR in 1941; Labour’s <b>Clement Attlee</b>, who beat him in 1945.',
      what='Churchill drew the <b>United States</b> toward Britain (Lend-Lease, the Atlantic Charter) and allied with the <b>Soviet Union</b> after 1941. As one of the <b>“Big Three,”</b> he helped plan the strategy — culminating in <b>D-Day (1944)</b> — that led to <b>victory in Europe in May 1945</b>.',
      crux='He grasped that the war was a <b>coalition problem</b>: manage the personalities and interests of two far larger powers to point their strength at Germany. His warmth, persistence and rhetoric were strategic tools.',
      conseq='Nazi Germany was destroyed — but a war-weary Britain, wanting social reform rather than a war hero, was about to deliver Churchill a shocking personal defeat.',
      matters='Winning a war is a coalition art. Churchill mastered the alliance-building that pointed two greater powers at Germany and destroyed it.'),
]

# ==================================================================  PHASE 5
PHASE_ELDER = [
    E('election1945', 'Jul 1945', 'Rejected at the summit of triumph', ['POLITICS', 'DEFEAT', 'TRAGEDY'],
      'In the most stunning reversal of his life, the man who has just won the war is thrown out by the voters within weeks of victory in Europe — Britain, grateful but exhausted, wants a builder of the welfare state, not a war hero, and hands a landslide to Labour.',
      svg_row('The war hero the public retired', [
          {'n': 1, 'label': 'Victory in Europe, May 1945', 'sub': 'Churchill at the peak of his fame', 'color': '#16a34a'},
          {'n': 2, 'label': 'General election, July 1945', 'sub': 'voters choose Attlee’s Labour by a landslide', 'color': '#b45309'},
          {'n': 3, 'label': 'Out of Downing Street', 'sub': 'the war-winner is dismissed within weeks', 'color': '#475569'},
      ], edge_labels=['then', 'so'], takeaway='They trusted him to win the war and then, gratefully, retired him — a leader honoured for one era and rejected for the next.', accent=AC),
      bg='As the war in Europe ended, Britain held its first general election in a decade. The public, having endured depression and war, wanted <b>social reform and a new start</b>.',
      people='Labour leader <b>Clement Attlee</b>, who won a landslide and built the welfare state and NHS; a grateful but forward-looking electorate.',
      what='Weeks after <b>VE Day</b>, the July <b>1945 general election</b> handed a <b>landslide to Clement Attlee’s Labour Party</b>. Churchill — the personification of victory — was <b>voted out of office</b>, a result that shocked the world.',
      crux='He embodied <b>war</b>, not the <b>peace</b> people now wanted: the public separated their gratitude for his leadership from their vision for the future, and chose the future.',
      conseq='Attlee’s government reshaped Britain (the NHS, the welfare state); Churchill led the opposition and would return to power in 1951.',
      matters='Voters reward the leader who fits the moment, and moments change. Even history’s war-winner could be honoured and dismissed in the same breath.'),

    E('writer', '1900s–1953', 'The other Churchill — writer, painter, and the “black dog”', ['REFORM', 'TRAGEDY'],
      'Behind the statesman is one of the most productive writers of the age: he earns much of his living by his pen, produces millions of words of history and memoir that win him the Nobel Prize, paints hundreds of canvases as therapy — and wrestles all his life with the depression he called his “black dog.”',
      svg_stack('The private man behind the public legend', [
          {'n': 1, 'label': 'A prolific author', 'sub': 'histories and memoirs; the Nobel Prize (1953)', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'A serious painter', 'sub': 'hundreds of canvases; painting as therapy', 'color': '#16a34a'},
          {'n': 3, 'label': 'The “black dog”', 'sub': 'lifelong struggles with depression', 'color': '#475569'},
      ], takeaway='He funded his life and soothed his mind with words and paint — a creative, troubled man behind the wartime giant.', accent=AC),
      bg='Churchill was not independently rich and largely <b>supported himself by writing</b>, producing an enormous body of history and journalism.',
      people='His readers and publishers; his wife <b>Clementine</b>, who steadied him; the biographers who chronicled his inner life.',
      what='Churchill wrote <b>millions of words</b> of history and memoir (earning the <b>1953 Nobel Prize in Literature</b>), painted <b>hundreds of canvases</b> as a refuge, and struggled throughout his life with periods of <b>depression he called his “black dog.”</b>',
      crux='His towering public resilience coexisted with private <b>creative drive and real vulnerability</b> — the whole man was more complex than the wartime icon.',
      conseq='His writings shaped how the world remembered the wars he fought, and his example of creativity amid depression resonates still.',
      matters='Even the strongest public figures carry private burdens. Churchill’s writing and painting were both livelihood and lifeline against his “black dog.”'),

    E('ironcurtain', '1946', 'The Iron Curtain — naming the Cold War', ['POLITICS', 'TURNING POINT'],
      'Out of power again, he gives a speech in America warning that an “iron curtain” has fallen across Europe — once more the first to name a danger the world would rather ignore.',
      svg_ironcurtain(),
      bg='With the war won, the wartime alliance with the Soviet Union quickly soured as Stalin tightened control over Eastern Europe. Many in the West still hoped for cooperation.',
      people='<b>Joseph Stalin</b>, consolidating a Soviet bloc; US President <b>Truman</b>, who hosted the speech; a Western public reluctant to face a new confrontation so soon.',
      what='In <b>1946 at Fulton, Missouri</b>, Churchill declared that “an <b>iron curtain</b> has descended across the Continent,” framing the emerging division of Europe and helping define the <b>Cold War</b>.',
      crux='Again the <b>early, unwelcome truth-teller</b>: he named the shape of the next forty years of geopolitics while others still hoped the wartime friendship would last.',
      conseq='The phrase entered the language and helped crystallise Western resolve. He returned as Prime Minister (1951–55), was knighted, and won the <b>Nobel Prize in Literature (1953)</b> for his historical writing and oratory.',
      matters='The rarest and most valuable leadership skill is seeing the next danger clearly and naming it early — even when no one wants to hear it.'),

    E('nobel', '1953', 'The Nobel Prize — and a stroke kept secret', ['REFORM', 'TRIUMPH', 'TRAGEDY'],
      'In a single remarkable year the old lion is knighted by the young Queen and wins the Nobel Prize — for Literature, not Peace — while secretly suffering a serious stroke that his circle hides from the public so he can cling to power a little longer.',
      svg_stack('Honours and hidden frailty', [
          {'n': 1, 'label': 'Knight of the Garter, 1953', 'sub': 'Sir Winston Churchill, honoured by the new Queen', 'color': '#a16207'},
          {'n': 2, 'label': 'Nobel Prize in Literature', 'sub': 'for his histories and oratory — a writer to the last', 'color': '#1e3a8a'},
          {'n': 3, 'label': 'A stroke, concealed', 'sub': 'a serious stroke hidden from press and public in 1953', 'color': '#b91c1c'},
      ], takeaway='At the height of his honours his body was failing — and the failing was hidden to preserve his grip on office.', accent=AC),
      bg='Back as PM in his late seventies, Churchill was showered with honours even as his health declined. His literary output — histories, memoirs, biography — was itself monumental.',
      people='the new <b>Queen Elizabeth II</b>, who knighted him; the <b>Nobel</b> committee; his doctor <b>Lord Moran</b> and inner circle, who concealed the stroke.',
      what='In 1953 Churchill was made a <b>Knight of the Garter</b> and awarded the <b>Nobel Prize in Literature</b>. That summer he suffered a <b>serious stroke</b>, which his staff hid so effectively that the public barely knew.',
      crux='His reputation rested as much on the <b>written and spoken word</b> as on politics — and his will to hold office outran his health.',
      conseq='He recovered enough to carry on briefly, finally resigning in 1955, ending one of history’s longest public careers.',
      matters='Legacies are built in words as well as deeds — and the powerful often cling on well past the body’s consent.'),

    E('summit', '1951–1955', 'The last mission — peace through a summit', ['POLITICS', 'REFORM'],
      'Back in power in his late seventies, and having named the Cold War, he spends his final premiership chasing one last great goal: a summit of the great powers to ease the nuclear standoff — the old warrior, who understood war better than anyone, straining at the end to prevent the ultimate one.',
      svg_row('The warrior’s last fight — for peace', [
          {'n': 1, 'label': 'PM again, aged ~77', 'sub': 'returns to power in 1951', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'The nuclear danger', 'sub': 'the H-bomb raises the stakes to annihilation', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Presses for a summit', 'sub': 'seeks great-power talks to ease the Cold War', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='The man who named the Cold War spent his last office trying to thaw it — peace as his final campaign.', accent=AC),
      bg='Returning as PM in <b>1951</b>, an ageing Churchill confronted the terrifying new reality of the <b>hydrogen bomb</b> and a frozen Cold War.',
      people='US and Soviet leaders he hoped to bring together; his own colleagues, often skeptical of his summit hopes.',
      what='In his second premiership (1951–55), Churchill pressed — largely unsuccessfully — for a <b>great-power summit</b> to reduce Cold War tensions, deeply alarmed by the destructive power of the new <b>hydrogen bomb</b>.',
      crux='The old war-leader, understanding war’s horror better than anyone, devoted his last energies to <b>preventing a nuclear one</b> — a fitting final cause.',
      conseq='His summit hopes went largely unrealised in his time, but foreshadowed the later détente diplomacy of the Cold War.',
      matters='He who best understood war worked hardest, at the end, for peace. Churchill’s last mission was to keep the Cold War from turning hot.'),

    E('death', '1955–1965', 'Elder statesman and a nation’s farewell', ['DEATH'],
      'He serves a final term as Prime Minister, wins the Nobel Prize for his writing, and on his death is given a state funeral — an almost unheard-of honour for a commoner — as the nation mourns the man who saved it.',
      svg_row('The long afterglow', [
          {'n': 1, 'label': 'Second premiership (1951–55)', 'sub': 'ageing, but back in Downing Street', 'color': '#1e3a8a'},
          {'n': 2, 'label': 'Nobel Prize in Literature (1953)', 'sub': 'honoured as a historian and orator', 'color': '#a16207'},
          {'n': 3, 'label': 'State funeral (1965)', 'sub': 'a nation mourns; a rare honour for a commoner', 'color': '#475569'},
      ], edge_labels=['then', 'then'], takeaway='He ended not as the failure of Gallipoli but as the voice that saved Britain — the ultimate late vindication.', accent=AC),
      bg='After 1945 Churchill remained a towering figure, returning to power once more before age finally slowed the man who had been in public life since the 1890s.',
      people='His wife <b>Clementine</b>, his lifelong partner and counsel; a generation of Britons for whom his wartime voice was the sound of survival.',
      what='He served a <b>second term as PM (1951–1955)</b>, received the <b>Nobel Prize in Literature (1953)</b> and a knighthood, and retired. On his death on <b>24 January 1965</b>, he was given a <b>state funeral</b> — an extraordinary honour — watched by millions.',
      crux='His life was a story of <b>redemption through persistence</b>: repeatedly written off (Gallipoli, the wilderness years), he outlasted every failure and was finally defined by his one supreme hour.',
      conseq='He is remembered above all as the leader whose words and will held Britain through 1940 — a reputation that eclipsed every earlier setback.',
      matters='A single defining triumph can redeem a lifetime of failures — if you endure long enough, and are ready, to seize the moment when it finally comes.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Winston Churchill’s life was a rollercoaster of triumph and disgrace across sixty years of public life: a fame-hungry aristocrat, a reforming minister, the man blamed for the Gallipoli catastrophe, a mocked outcast in the 1930s — and then, in 1940, the one leader with the will and the words to hold Britain alone against Nazi Germany. His story is the definitive study in <b>resilience, foresight, and the redemptive power of a single finest hour.</b></p>

<div class="ov-quote">“Success is not final, failure is not fatal: it is the courage to continue that counts.”<span>— a sentiment that reads like the summary of his own up-and-down life</span></div>

<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Neglected boy who chases fame in colonial wars → fast-rising reforming minister → disgraced by Gallipoli → cast into the political “wilderness,” warning about Hitler while no one listens → becomes PM at the darkest hour and refuses to surrender → builds the alliance that wins WWII → is voted out, names the Cold War, and dies a national hero.</p>

<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🗣️</div><h4>Words as weapons</h4><p>His speeches show how language and will can hold a nation together when material odds look hopeless.</p></div>
  <div class="ov-card"><div class="i">🔭</div><h4>Foresight</h4><p>Right about Hitler, and then about the Soviet threat — the value, and the loneliness, of seeing danger early.</p></div>
  <div class="ov-card"><div class="i">🔁</div><h4>Resilience</h4><p>Written off again and again, he endured every failure until his one supreme moment arrived.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>A complicated legacy</h4><p>Saviour of 1940 and a gifted writer — also a defender of empire whose views on India and race are now sharply criticised.</p></div>
</div>

<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Young Churchill</b><small> 1874–1900</small><p>A neglected boy builds fame through war and words.</p></div>
  <div><b>2 · Rise & Fall</b><small> 1900–1915</small><p>Reform, high office — then the Gallipoli catastrophe.</p></div>
  <div><b>3 · Wilderness</b><small> 1929–1939</small><p>The lonely, mocked warning about Hitler.</p></div>
  <div><b>4 · Finest Hour</b><small> 1940–1945</small><p>PM at the darkest moment; the alliance; victory.</p></div>
  <div><b>5 · Elder Statesman</b><small> 1946–1965</small><p>The Iron Curtain, a Nobel Prize, a state funeral.</p></div>
</div>

<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b> for dates, <b>Who’s Who</b> for the cast, and <b>Master Timeline</b> for the whole life in one scroll.</p>
"""

# ==================================================================  WHO'S WHO
WHO = [
    {'name': 'Clementine Churchill', 'role': 'wife & counsel', 'color': '#db2777',
     'bio': 'His wife of 56 years, closest confidante and shrewdest adviser, who steadied him and sometimes tempered his worst instincts. Their partnership was central to his endurance.',
     'rel': 'His anchor and private counsellor through every rise and fall.'},
    {'name': 'Lord Randolph Churchill', 'role': 'father', 'color': '#475569',
     'bio': 'A brilliant, meteoric and ultimately failed Tory politician who was cold and dismissive toward his son — and died young. Winston spent his life half-seeking his approval.',
     'rel': 'The distant father whose disregard fuelled Winston’s ambition.'},
    {'name': 'David Lloyd George', 'role': 'ally & rival', 'color': '#0891b2',
     'bio': 'The dynamic Liberal (later PM) with whom Churchill built early social reforms. A mentor, ally and sometime rival across decades of Liberal politics.',
     'rel': 'His partner in the reforming years before WWI.'},
    {'name': 'Neville Chamberlain', 'role': 'the appeaser', 'color': '#64748b',
     'bio': 'Prime Minister who pursued appeasement and signed the 1938 Munich Agreement. His policy — and its failure — set the stage for Churchill’s vindication and rise in 1940.',
     'rel': 'His opposite on appeasement; the PM Churchill replaced.'},
    {'name': 'Adolf Hitler', 'role': 'the enemy', 'color': '#7f1d1d',
     'bio': 'The Nazi dictator whose threat Churchill alone kept warning about in the 1930s, and against whom he rallied Britain in 1940. Churchill’s defiance made him Hitler’s most implacable foe.',
     'rel': 'The danger he foresaw, and the enemy he refused to appease.'},
    {'name': 'Franklin D. Roosevelt', 'role': 'ally (USA)', 'color': '#1e3a8a',
     'bio': 'US President whom Churchill courted relentlessly to bring America into the war (Lend-Lease, the Atlantic Charter). Their partnership was the backbone of the Western war effort.',
     'rel': 'The ally he wooed to turn survival into victory.'},
    {'name': 'Joseph Stalin', 'role': 'ally of necessity', 'color': '#b91c1c',
     'bio': 'The Soviet dictator who became Britain’s ally after Hitler invaded the USSR in 1941. Churchill loathed communism but worked with Stalin to beat Germany — then warned about him.',
     'rel': 'The enemy-turned-ally-turned-Cold-War-adversary.'},
    {'name': 'Clement Attlee', 'role': 'wartime deputy & victor', 'color': '#16a34a',
     'bio': 'Labour leader and Churchill’s loyal deputy in the wartime coalition — who then defeated him in the 1945 election and built the welfare state and NHS.',
     'rel': 'The quiet colleague who beat him at the ballot box in 1945.'},
    {'name': 'Bernard Montgomery', 'role': 'top general', 'color': '#0e7490',
     'bio': 'Britain’s most famous WWII field commander (El Alamein, Normandy). A prickly but effective general Churchill relied on for battlefield victories.',
     'rel': 'The general who delivered the land victories Churchill needed.'},
]

# ==================================================================  KEY EVENTS
KEY_EVENTS = [
    ('1874', 'Born at Blenheim Palace', 'Aristocratic birth; distant, famous father.'),
    ('1898', 'Cavalry charge at Omdurman', 'Builds fame as a soldier-writer.'),
    ('1899', 'Boer War capture and escape', 'A daring escape makes him a national hero.'),
    ('1900', 'Elected to Parliament', 'Begins a 60-year political career.'),
    ('1904', 'Crosses to the Liberals', 'Switches party over free trade and principle.'),
    ('1911', 'First Lord of the Admiralty', 'Runs the Royal Navy into WWI.'),
    ('1915', 'Gallipoli fails', 'Blamed for the catastrophe; demoted; leaves government.'),
    ('1924–29', 'Chancellor of the Exchequer', 'Returns to the Tories; the gold-standard blunder.'),
    ('1930s', 'The Wilderness Years', 'Out of office; the lone warning about Hitler.'),
    ('1938', 'Opposes the Munich Agreement', '“War and dishonour” — against appeasement.'),
    ('10 May 1940', 'Becomes Prime Minister', 'Takes power at the darkest hour; refuses to surrender.'),
    ('1940', 'Dunkirk & Battle of Britain', 'The army escapes; the RAF denies Hitler the skies.'),
    ('1941–45', 'The Grand Alliance', 'Courts the US and allies with the USSR; wins the war.'),
    ('Jul 1945', 'Loses the election', 'Voted out weeks after victory in Europe.'),
    ('1946', 'The Iron Curtain speech', 'Names the Cold War division of Europe.'),
    ('1951–55', 'Second premiership', 'Returns to Downing Street; later knighted.'),
    ('1953', 'Nobel Prize in Literature', 'Honoured for his oratory and histories.'),
    ('1965', 'Death and state funeral', 'A nation mourns the man who saved it.'),
]

# ==================================================================  MASTER
MASTER = [
    {'year': '1874', 'age': 'born', 'phase': 'Young', 'title': 'Born at Blenheim', 'desc': 'Aristocratic birth; a distant father.'},
    {'year': '1899', 'age': 'age 25', 'phase': 'Young', 'title': 'Boer War escape', 'desc': 'Becomes a national celebrity.'},
    {'year': '1900', 'age': 'age 25', 'phase': 'Young', 'title': 'Enters Parliament', 'desc': 'The start of a 60-year career.'},
    {'year': '1911', 'age': 'age 36', 'phase': 'Rise & Fall', 'title': 'Runs the Navy', 'desc': 'First Lord of the Admiralty into WWI.'},
    {'year': '1915', 'age': 'age 40', 'phase': 'Rise & Fall', 'title': 'Gallipoli', 'desc': 'Catastrophe; blamed and cast out.'},
    {'year': '1924', 'age': 'age 49', 'phase': 'Rise & Fall', 'title': 'Chancellor', 'desc': 'Back with the Tories; the gold-standard error.'},
    {'year': '1930s', 'age': '50s', 'phase': 'Wilderness', 'title': 'The lone warning', 'desc': 'Out of office; warns about Hitler.'},
    {'year': '1940', 'age': 'age 65', 'phase': 'Finest Hour', 'title': 'Prime Minister', 'desc': 'Refuses to surrender; Britain fights on.'},
    {'year': '1940', 'age': 'age 65', 'phase': 'Finest Hour', 'title': 'Battle of Britain', 'desc': 'The RAF denies Hitler the invasion.'},
    {'year': '1945', 'age': 'age 70', 'phase': 'Finest Hour', 'title': 'Victory, then defeat', 'desc': 'Wins the war; loses the election.'},
    {'year': '1946', 'age': 'age 71', 'phase': 'Elder', 'title': 'Iron Curtain speech', 'desc': 'Names the Cold War.'},
    {'year': '1953', 'age': 'age 78', 'phase': 'Elder', 'title': 'Nobel Prize', 'desc': 'Honoured for his writing and oratory.'},
    {'year': '1965', 'age': 'age 90', 'phase': 'Elder', 'title': 'Death & state funeral', 'desc': 'A nation mourns.'},
]

SOURCES = [
    ('Britannica — Winston Churchill', 'https://www.britannica.com/biography/Winston-Churchill'),
    ('International Churchill Society', 'https://winstonchurchill.org/'),
    ('Imperial War Museums — Churchill', 'https://www.iwm.org.uk/history/who-was-winston-churchill'),
    ('Britannica — Battle of Britain', 'https://www.britannica.com/event/Battle-of-Britain-European-history'),
    ('Wikipedia — Winston Churchill', 'https://en.wikipedia.org/wiki/Winston_Churchill'),
]

def build_meta():
    return {
        'pid': 'gm-churchill.html', 'kind': 'man', 'emoji': '🇬🇧', 'accent': AC,
        'name': 'Winston Churchill', 'years': '1874–1965', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'Fame-hunter, disgraced by Gallipoli, mocked in the wilderness — then the voice and will that held Britain alone through its darkest hour. A study in resilience and foresight.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'young', 'label': '1 · Young Churchill', 'type': 'timeline',
             'intro': 'A neglected aristocratic boy, hungry to prove himself, manufactures fame through colonial wars and bestselling books — and rides it into Parliament.', 'events': PHASE_YOUNG},
            {'id': 'rise', 'label': '2 · Rise & Fall', 'type': 'timeline',
             'intro': 'He crosses party lines, helps build early social reform and runs the Navy — then stakes everything on Gallipoli, and falls hard.', 'events': PHASE_RISE},
            {'id': 'wilderness', 'label': '3 · Wilderness', 'type': 'timeline',
             'intro': 'Written off in the 1930s, he becomes a lonely, ridiculed voice warning that Hitler means war — and is proved devastatingly right.', 'events': PHASE_WILDERNESS},
            {'id': 'finest', 'label': '4 · Finest Hour', 'type': 'timeline',
             'intro': 'He becomes Prime Minister at the darkest moment, refuses to surrender, holds Britain through 1940, and builds the alliance that wins the war.', 'events': PHASE_FINEST},
            {'id': 'elder', 'label': '5 · Elder Statesman', 'type': 'timeline',
             'intro': 'Voted out at his moment of triumph, he names the Cold War, returns to power once more, wins a Nobel Prize, and dies a national hero.', 'events': PHASE_ELDER,
             'sources': SOURCES, 'srcnote': 'Churchill remains a debated figure: celebrated for 1940, but criticised for his imperialism and views on India and race. This guide notes his greatness and his controversies.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
