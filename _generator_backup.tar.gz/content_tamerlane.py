# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Tamerlane (Timur)."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#0f766e'  # Timurid turquoise

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_amir():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the legitimacy problem: he is not descended from Genghis Khan</text>'
    b += '<rect x="40" y="60" width="300" height="80" rx="12" fill="#fdecec" stroke="#b45309" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#b45309">The problem</text>'
    s1,_=_tspans(54,100,'only a Genghisid may be “khan” — Timur is a Barlas noble, not of the line',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="80" rx="12" fill="#ccfbf1" stroke="#0f766e" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#0f766e">The workaround</text>'
    s2,_=_tspans(394,100,'rule as “amir” behind puppet khans; marry a Genghisid princess → “Gūrkān” (royal son-in-law)',10,'#0f766e',600,12,44); b+=s2
    b += '<line x1="340" y1="100" x2="378" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="168" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He held total power while never claiming the one title he wasn’t entitled to.</text>'
    return _wrap(W, H, 'Amir, not Khan — power without the forbidden title', _tk(b, W, H, 'When you can’t claim the title, take the power and borrow legitimacy from a figurehead.'), '', AC)

def svg_terror():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">terror as policy — the towers of skulls</text>'
    boxes=[(40,'#0f766e','Demand submission','a city is offered the chance to surrender'),
           (270,'#b45309','Resist → annihilation','the population massacred; skulls built into towers'),
           (500,'#dc2626','Fear does the rest','the terror spreads; others yield without a fight')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="80" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="100" x2="268" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="100" x2="498" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Delhi, Isfahan, Baghdad, Aleppo — cities of skulls raised to make resistance unthinkable.</text>'
    return _wrap(W, H, 'The skull-towers — calculated horror', _tk(b, W, H, 'Like Genghis before him, he used mass slaughter as a deliberate tool to shorten every war.'), '', AC)

def svg_ankara():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1402 · Ankara · the day two empires collided</text>'
    boxes=[(40,'#0f766e','Meets the Ottomans','faces Sultan Bayezid I “the Thunderbolt”'),
           (270,'#b45309','Turns Bayezid’s vassals','Anatolian troops defect to Timur mid-battle'),
           (500,'#dc2626','Captures the Sultan','Bayezid taken prisoner — unheard of')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="80" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="100" x2="268" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="100" x2="498" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">A rising empire humbled — and Constantinople won a 50-year reprieve as the Ottomans reeled.</text>'
    return _wrap(W, H, 'Ankara — capturing a sultan', _tk(b, W, H, 'He shattered the rising Ottomans and, by chance, bought Constantinople 50 more years of life.'), '', AC)

def svg_legacy():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1405+ · destroyer of cities, ancestor of a golden age</text>'
    rows=[('#dc2626','The empire fragments','held only by his person; wars of succession follow'),
          ('#0f766e','The Timurid Renaissance','Samarkand’s architecture; his grandson Ulugh Beg, the astronomer-king'),
          ('#0e7490','The Mughal Empire','his descendant Babur founds the Mughal dynasty in India (1526)')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="40" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+20}" r="9" fill="{c}"/><text x="62" y="{y+24}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+17}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+32,s,9.4,'#5b6472',500,11,76); b+=ss
        y+=48
    return _wrap(W, H, 'The paradox of the Timurid legacy', _tk(b, W, H, 'He razed civilisations — and seeded one of history’s great cultural flowerings, and the Mughal Empire.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE LAME RISE
PHASE_RISE = [
    E('birth', '1336–1360s', 'A lamed minor noble on the make', ['RISE'],
      'Born a minor Turco-Mongol noble near Samarkand, wounded so badly in his youth that he is called "Timur the Lame," he claws his way up through the chaos of Transoxiana by raiding, cunning, and shifting alliances.',
      svg_stack('The making of a self-made conqueror', [
          {'n': 1, 'label': 'Born a minor Barlas noble', 'sub': 'near Samarkand; Turco-Mongol, not a Genghisid', 'color': '#0f766e'},
          {'n': 2, 'label': 'Wounded → “Timur the Lame”', 'sub': 'arrows cripple an arm and leg (→ “Tamerlane”)', 'color': '#b45309'},
          {'n': 3, 'label': 'Rises by raid & alliance', 'sub': 'sheep-rustler to warband leader in a fractured land', 'color': '#16a34a'},
      ], takeaway='He started with a name, a limp and little else — and built an empire on sheer will and cunning.', accent=AC),
      bg='The Mongol <b>Chagatai Khanate</b> in Central Asia (<b>Transoxiana</b>) had fragmented into feuding lords. Timur was born around 1336 into the minor <b>Barlas</b> clan.',
      people='His clan and rival warlords of Transoxiana; his brother-in-law and early partner <b>Amir Husayn</b>, whom he would later eliminate.',
      what='Injured in his 20s (leaving him lame in the right arm and leg — hence <b>Timur-e Lang</b>, “Tamerlane”), he rose through the region’s anarchy as a warband leader, switching sides shrewdly and building a following.',
      crux='He was a <b>self-made man in a vacuum of power</b>, rising by a mix of raw courage, ruthless betrayal and a gift for reading and exploiting a fractured political landscape.',
      conseq='By 1370 he had eliminated his rivals (including Amir Husayn) and made himself master of Transoxiana, with Samarkand as his capital.',
      matters='Chaos is opportunity for the ruthless and able. Tamerlane, like Genghis, rose from the margins by exploiting a world with no settled order.'),

    E('sistan', 'c.1363', 'The wounds that made “Timur the Lame”', ['RISE', 'BATTLE', 'TRAGEDY'],
      'In a raid in Sistan the young Timur takes arrows in his right leg and arm, leaving him permanently lamed — the injury that gives him the mocking name Timur-i-Lang, “Tamerlane,” and a body he will drive across a continent regardless.',
      svg_stack('The injury that named a conqueror', [
          {'n': 1, 'label': 'A raid in Sistan', 'sub': 'fighting as a mercenary captain in the borderlands', 'color': '#0f766e'},
          {'n': 2, 'label': 'Arrows cripple his right side', 'sub': 'a lasting limp and a stiff arm for life', 'color': '#b91c1c'},
          {'n': 3, 'label': '“Timur-i-Lang” → Tamerlane', 'sub': 'an insult he turns into a name that terrifies half the world', 'color': '#a16207'},
      ], takeaway='The disability that should have ended his fighting career became the brand of the age’s most feared conqueror.', accent=AC),
      bg='In the anarchic 1360s Timur rose as a warrior-adventurer among the feuding clans of Transoxiana, fighting for shifting patrons and his own herds and followers.',
      people='The rival lords and khans he served and betrayed; the followers he attracted by boldness and plunder; the chroniclers who later mythologised the wounds.',
      what='During a raid in <b>Sistan</b> (c.1363) he was <b>wounded in the right leg and hand</b>, leaving him lamed for life. Enemies called him <b>Timur-i-Lang</b> (“Timur the Lame”), Europeanised as <b>Tamerlane</b>.',
      crux='He refused to let a crippling injury define his limits — <b>sheer will overrode the body</b>, campaigning on horseback and litter to the end.',
      conseq='The lameness was confirmed when Soviet scientists exhumed his body in 1941, matching the chronicles. The name outlived every rival.',
      matters='Great ambition often works around an early wound rather than being stopped by it — the limitation becomes part of the legend.'),

    E('amir', '1370', 'Master of Samarkand — power without the crown', ['POLITICS', 'TURNING POINT'],
      'He takes control of Transoxiana but hits a wall: only a descendant of Genghis Khan may be "khan," and he is not one. His solution is a brilliant fiction — rule everything as "amir" behind a puppet khan.',
      svg_amir(),
      bg='In the Mongol world, sovereignty belonged only to the <b>line of Genghis Khan</b>. Timur, a Barlas noble, had the power but not the bloodline to be a legitimate khan.',
      people='The <b>puppet Chagatai khans</b> Timur kept as figureheads; a <b>Genghisid princess</b> he married to earn the honorific <b>Gūrkān</b> (“royal son-in-law”).',
      what='Timur ruled as <b>amir</b> (commander) in the name of a <b>figurehead khan</b>, and married into the Genghisid line to style himself <b>Gūrkān</b> — wielding absolute power while never usurping the forbidden title of khan.',
      crux='He <b>separated power from title</b>: rather than fight the legitimacy rules, he satisfied them formally while taking all real authority — a shrewd workaround that avoided endless challenges.',
      conseq='Secure in Samarkand and legitimacy, he launched 35 years of near-continuous conquest, casting himself as the restorer of the Mongol Empire.',
      matters='When a rule blocks you, you can often satisfy its form while taking its substance. Timur held the reality of power and left the empty title to a puppet.'),

    E('guregen', '1370', 'Ruling behind a puppet — the son-in-law of the Khan', ['POLITICS', 'REFORM'],
      'Barred by blood from the throne — only a descendant of Genghis Khan may be Great Khan — Timur invents a workaround: he installs a powerless Genghisid as figurehead, marries a princess of the line, and rules all his life as “amir” and royal son-in-law.',
      svg_row('Legitimacy without the forbidden title', [
          {'n': 1, 'label': 'The rule of blood', 'sub': 'only Chinggis’s male line may claim the title of Khan', 'color': '#a16207'},
          {'n': 2, 'label': 'Install a puppet khan', 'sub': 'a figurehead Genghisid reigns; Timur governs', 'color': '#0f766e'},
          {'n': 3, 'label': 'Marry into the line → Güregen', 'sub': 'weds a Chinggisid princess; styles himself “son-in-law”', 'color': '#7c3aed'},
      ], edge_labels=['blocks', 'solved by'], takeaway='He took the substance of supreme power while leaving the forbidden title on a harmless puppet.', accent=AC),
      bg='Across the Mongol world, legitimate sovereignty belonged only to the <b>house of Genghis Khan</b>. Timur, a Turkicised noble of the Barlas clan, had no such claim.',
      people='The puppet khans (like <b>Suyurghatmish</b> and his son) who “reigned”; the Chinggisid princess Timur married; the Turco-Mongol elite who needed the fiction to obey him.',
      what='From 1370 Timur ruled as <b>amir</b> in the name of a <b>puppet Genghisid khan</b>, and took the title <b>Güregen</b> (“royal son-in-law”) by marriage into the line — never calling himself Khan, yet wielding absolute power.',
      crux='He separated the <b>title from the power</b> — obeying the letter of Mongol law while emptying it of meaning.',
      conseq='The device let him command Chinggisid loyalists for 35 years; his descendants, the Mughals, likewise prized their Timurid-Mongol blood.',
      matters='When you cannot hold the crown, hold the crown-maker — real power often hides behind a borrowed legitimacy.'),

    E('invincible', '1370–1405', 'The war machine that never lost', ['RISE', 'BATTLE'],
      'Over thirty-five years of near-constant campaigning he never loses a major battle — welding Mongol cavalry mobility, siege engineering, and a fearsome reputation into a war machine that ranges from India to the Mediterranean, always returning to enrich his beloved Samarkand.',
      svg_stack('Anatomy of an unbeaten conqueror', [
          {'n': 1, 'label': 'Steppe cavalry + siege skill', 'sub': 'Mongol mobility fused with engineers and firepower', 'color': '#0f766e'},
          {'n': 2, 'label': 'Terror as a force-multiplier', 'sub': 'his reputation makes cities surrender on sight', 'color': '#b45309'},
          {'n': 3, 'label': 'All roads lead to Samarkand', 'sub': 'plunder and artisans flow back to his capital', 'color': '#0e7490'},
      ], takeaway='He combined mobility, siegecraft and terror into an army that, across 35 years, never lost a major battle.', accent=AC),
      bg='From his base in Transoxiana, Timur launched a relentless series of campaigns in every direction, treating war almost as a permanent condition.',
      people='His disciplined <b>Turco-Mongol army</b>; the engineers and craftsmen he pressed into siege work; the many cities that submitted rather than fight.',
      what='Timur’s army married <b>steppe cavalry mobility</b> with <b>sophisticated siegecraft</b> and a calculated reputation for terror. In 35 years of campaigning he is generally reckoned to have <b>never lost a major battle</b>, ranging across an enormous theatre while always sending wealth and talent back to <b>Samarkand</b>.',
      crux='His genius was <b>combined-arms flexibility plus psychology</b>: he could out-manoeuvre in the field and out-engineer at a siege, while fear did much of his work for him.',
      conseq='This unbroken record of victory built an empire from Delhi to Anatolia — and a legend of invincibility that long outlived him.',
      matters='Sustained dominance comes from combining strengths others keep separate — here, nomad mobility, settled siegecraft, and sheer terror.'),

    E('swordofislam', '1370s–1405', 'The Sword of Islam — piety and plunder', ['POLITICS', 'REFORM'],
      'He wraps his conquests in the mantle of faith, styling himself a holy warrior and Sword of Islam — yet most of his victims are fellow Muslims, and his massacres fall on Muslim cities as readily as Christian ones, a striking case of religion serving as the justification, not the limit, of ambition.',
      svg_row('Faith as the banner of conquest', [
          {'n': 1, 'label': 'Poses as a holy warrior', 'sub': 'a ghazi and “Sword of Islam”', 'color': '#0f766e'},
          {'n': 2, 'label': 'But sacks Muslim cities', 'sub': 'Isfahan, Baghdad, Delhi, Damascus — all Muslim', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Religion as pretext', 'sub': 'piety justifies, but never limits, his ambition', 'color': '#b45309'},
      ], edge_labels=['yet', 'so'], takeaway='He fought under the banner of Islam while slaughtering Muslims — faith as the justification, not the restraint, of conquest.', accent=AC),
      bg='Timur consistently presented himself as a devout Muslim and holy warrior, patronising scholars and shrines even as he waged total war.',
      people='The Muslim clerics and Sufi shaykhs he patronised; the Muslim populations of the cities he destroyed.',
      what='Timur styled himself a <b>ghazi and Sword of Islam</b>, cloaking his campaigns in piety — yet the great majority of his victims were <b>fellow Muslims</b>, and cities like Isfahan, Baghdad and Delhi were Muslim centres he devastated.',
      crux='His religiosity functioned as <b>legitimation rather than limitation</b>: faith justified conquest and terror without ever restraining them.',
      conseq='He gained religious prestige and Sufi endorsement while pursuing wholly worldly, unlimited ambition.',
      matters='Timur is a stark case of religion as the banner, not the brake, of power — devout in image, boundless in ambition.'),
]

# ==================================================================  PHASE 2 — THE CONQUEROR
PHASE_CONQUER = [
    E('khorasan', '1381–1385', 'Khorasan and Herat — the first great conquests', ['BATTLE', 'TRIUMPH'],
      'With Transoxiana secured, Timur turns outward, swallowing the rich cultural heartland of Khorasan — Herat, the Sarbadar cities, and eastern Persia — the first strides of a career of conquest that will never really stop.',
      svg_row('Turning a secure base into an empire', [
          {'n': 1, 'label': 'Base secured at Samarkand', 'sub': 'a decade consolidating Central Asia', 'color': '#0f766e'},
          {'n': 2, 'label': 'Khorasan & Herat taken', 'sub': 'the wealthy Persianate east absorbed, 1381–83', 'color': '#a16207'},
          {'n': 3, 'label': 'The campaigns begin', 'sub': 'the “Three-, Five-, Seven-Year” expeditions westward', 'color': '#7c3aed'},
      ], edge_labels=['enables', 'launches'], takeaway='A secure homeland was only the springboard — conquest, once begun, became a way of life.', accent=AC),
      bg='By the late 1370s Timur had mastered Transoxiana. To its southwest lay <b>Khorasan</b> — Herat, Nishapur and the Sarbadar states — rich, cultured and divided.',
      people='The <b>Kartid</b> rulers of Herat; the <b>Sarbadars</b> of Sabzevar (who rebelled and were savagely punished); the artisans and scholars he began deporting to Samarkand.',
      what='In 1381–85 Timur conquered <b>Herat and Khorasan</b> and pushed into eastern Persia, launching the series of long expeditions that would carry him from Delhi to Ankara.',
      crux='He needed <b>perpetual war</b> to hold together an army and elite bound by plunder and glory — expansion was structural, not optional.',
      conseq='Khorasan’s wealth and craftsmen fuelled the beautification of Samarkand; the conquest opened the road deep into Persia and the west.',
      matters='Some empires are built to conquer and cannot stop — the machine that wins must keep winning to survive.'),

    E('husayn', '1360s–1370', 'Eliminating his partner — the road to sole power', ['POLITICS', 'RISE', 'TRAGEDY'],
      'His rise runs through betrayal: for years he shares the struggle for Transoxiana with his brother-in-law and ally Amir Husayn — until the partnership sours, and Timur maneuvers to have Husayn killed, emerging in 1370 as the sole, unchallenged master of the region.',
      svg_row('Partner today, rival tomorrow', [
          {'n': 1, 'label': 'Allied with Amir Husayn', 'sub': 'brothers-in-law fighting for Transoxiana', 'color': '#0f766e'},
          {'n': 2, 'label': 'The alliance breaks', 'sub': 'the two partners become rivals for supremacy', 'color': '#b45309'},
          {'n': 3, 'label': 'Husayn eliminated, 1370', 'sub': 'Timur becomes sole master of the region', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He climbed to sole power over the body of the ally who had helped him rise — ruthlessness as a ladder.', accent=AC),
      bg='In the chaos of Transoxiana, Timur’s closest partner was his brother-in-law <b>Amir Husayn</b>, with whom he fought and schemed for control.',
      people='<b>Amir Husayn</b>, the partner turned rival; the shifting warlords of Transoxiana.',
      what='After years of alliance and rivalry, Timur <b>engineered the downfall and death of Amir Husayn</b>, and in <b>1370</b> made himself the <b>sole ruler of Transoxiana</b>, ending the era of shared and contested power.',
      crux='He showed early the <b>ruthless readiness to destroy even close allies</b> when they stood between him and total power.',
      conseq='As undisputed master of Transoxiana, Timur could now turn his energies outward to decades of conquest.',
      matters='His rise, like Genghis’s, was paved with the elimination of former partners — a chilling constant of steppe-empire building.'),

    E('persia', '1380s', 'The conquest of Persia — and terror as policy', ['BATTLE', 'TRIUMPH', 'TRAGEDY'],
      'He pours west into Persia, and where cities resist he answers with annihilation — massacres and towers built from the skulls of the dead, a calculated horror that makes the next city surrender on sight.',
      svg_terror(),
      bg='From Samarkand, Timur launched relentless campaigns into <b>Persia</b> and beyond, exploiting the disunity left by the Mongols’ decline.',
      people='The rulers of fractured Persian and Central Asian states; the populations of cities like <b>Isfahan</b>, massacred for resisting.',
      what='Timur overran Persia through the 1380s. Cities that resisted were subjected to <b>mass slaughter</b> — at Isfahan, tens of thousands were killed and their <b>skulls piled into towers</b>, a signature of his campaigns.',
      crux='Like Genghis, he used <b>terror as a rational instrument</b>: annihilating resisters made surrender the only sane choice, letting him conquer vast areas quickly with limited forces.',
      conseq='Persia fell under his control; his reputation for merciless destruction ran ahead of his armies, easing later conquests.',
      matters='Calculated terror can be brutally effective — and is one of history’s darkest recurring tools of conquest. Tamerlane raised it almost to a system.'),

    E('tokhtamysh1', '1385–1388', 'The protégé turns — Tokhtamysh strikes back', ['BATTLE', 'POLITICS', 'TURNING POINT'],
      'Timur had raised the exiled prince Tokhtamysh and set him on the throne of the Golden Horde — only to watch his creation invade Transoxiana itself, forcing a reckoning between maker and made.',
      svg_stack('When a client becomes a rival', [
          {'n': 1, 'label': 'Timur backs Tokhtamysh', 'sub': 'shelters him, arms him, wins him the Golden Horde', 'color': '#0f766e'},
          {'n': 2, 'label': 'Tokhtamysh reunites the Horde', 'sub': 'grows powerful, sacks Moscow, eyes his patron’s lands', 'color': '#a16207'},
          {'n': 3, 'label': 'He raids Transoxiana, 1388', 'sub': 'strikes at Timur’s heartland while he is in Persia', 'color': '#b91c1c'},
      ], takeaway='He learned the hard way that a strong protégé is a future enemy — and resolved to destroy him utterly.', accent=AC),
      bg='The <b>Golden Horde</b>, the Mongol power over Russia, had fragmented. Timur backed the fugitive prince <b>Tokhtamysh</b> as a friendly neighbour on his northern flank.',
      people='<b>Tokhtamysh</b>, the ungrateful protégé; the merchants of Transoxiana whose cities he raided; the Rus principalities the Horde still dominated.',
      what='Restored by Timur’s help, Tokhtamysh <b>reunified the Golden Horde</b>, sacked Moscow in 1382, then turned on his benefactor, <b>raiding Transoxiana</b> in 1387–88 — the betrayal that set up the annihilating wars of 1391–95.',
      crux='Timur had created a <b>rival on his own border</b>; the lesson was that half-measures against a strong enemy invite disaster.',
      conseq='It provoked the two massive northern campaigns in which Timur wrecked the Golden Horde permanently — reshaping the future of Russia.',
      matters='Building up a powerful neighbour can be as dangerous as facing an enemy — gratitude rarely survives ambition.'),

    E('tokhtamysh', '1391–1395', 'Crushing the Golden Horde — betrayal repaid', ['BATTLE', 'TRIUMPH'],
      'His own protégé, Tokhtamysh, whom he raised to rule the Golden Horde, turns on him. Timur hunts him across thousands of miles of steppe, destroys his army, and sacks the Horde’s cities — crippling it forever.',
      svg_row('The pupil who betrayed the master', [
          {'n': 1, 'label': 'Raises Tokhtamysh', 'sub': 'helps him seize the Golden Horde', 'color': '#0f766e'},
          {'n': 2, 'label': 'Tokhtamysh invades', 'sub': 'the protégé turns and attacks Transoxiana', 'color': '#dc2626'},
          {'n': 3, 'label': 'Timur destroys the Horde', 'sub': 'beats him twice; sacks Sarai & the Horde’s cities', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He answered betrayal with total war — and inadvertently reshaped the future of Russia.', accent=AC),
      bg='Timur had helped his protégé <b>Tokhtamysh</b> unite and rule the <b>Golden Horde</b> (the Mongol khanate over Russia and the western steppe). Tokhtamysh then turned against his patron.',
      people='<b>Tokhtamysh</b>, the ungrateful protégé; the trading cities of the Golden Horde (Sarai, Astrakhan) that Timur devastated.',
      what='Timur pursued Tokhtamysh across the steppes, defeating him decisively (notably at the <b>Terek River, 1395</b>) and <b>sacking the Golden Horde’s cities</b>, wrecking its trade and power.',
      crux='He treated betrayal as an existential offence demanding total destruction — and by shattering the Golden Horde, he unintentionally <b>weakened Mongol dominance over Russia</b>, helping Moscow eventually rise.',
      conseq='The Golden Horde never recovered; its decline opened the long road to Russian independence from Mongol rule.',
      matters='Actions ripple far beyond their intent: Tamerlane’s revenge on a protégé helped set Russia on the path out from under the Mongol yoke.'),

    E('georgia', '1386–1403', 'The hammering of Georgia and the Caucasus', ['BATTLE', 'TRAGEDY'],
      'The small Christian kingdom of Georgia has the misfortune to lie on his path, and he invades it again and again — perhaps eight times across two decades — devastating it repeatedly in campaigns waged partly as holy war, a grinding example of his relentlessness against any who will not simply submit.',
      svg_row('Relentlessness against the defiant', [
          {'n': 1, 'label': 'Invades Georgia', 'sub': 'a small Christian kingdom astride his routes', 'color': '#0f766e'},
          {'n': 2, 'label': 'Again and again', 'sub': 'repeated invasions across nearly two decades', 'color': '#b45309'},
          {'n': 3, 'label': 'Devastation', 'sub': 'towns razed; the kingdom broken but unconquered', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He returned to crush Georgia over and over — proof that defiance bought only more destruction.', accent=AC),
      bg='<b>Georgia</b>, a Christian kingdom in the Caucasus, refused lasting submission and lay near Timur’s northern and western routes.',
      people='The Georgian kings who resisted; the Christian population, targeted in campaigns cast partly as jihad.',
      what='Timur invaded <b>Georgia repeatedly</b> (by some counts around eight times between the 1380s and 1400s), devastating its towns and countryside and forcing tribute, though never fully absorbing it — the campaigns increasingly framed as religious war.',
      crux='It shows his <b>refusal to leave any defiance unpunished</b>: rather than bypass a stubborn small kingdom, he returned again and again until it was shattered.',
      conseq='Georgia was gravely weakened for generations, a lasting scar of Timur’s relentlessness.',
      matters='Relentlessness is itself a weapon. Timur’s willingness to return endlessly to the same enemy made resistance almost suicidal.'),

    E('isfahan', '1387', 'Isfahan — the first great tower of skulls', ['BATTLE', 'TRAGEDY'],
      'The jewel of Persia surrenders peacefully — then rebels and kills his tax collectors, and Timur’s revenge becomes the template for all his terror: a general massacre in which tens of thousands are killed and their heads built into towers, a horror deliberately publicised to make every other city surrender.',
      svg_row('The atrocity that set the pattern', [
          {'n': 1, 'label': 'Isfahan submits, then revolts', 'sub': 'the city rises and kills his tax men', 'color': '#0f766e'},
          {'n': 2, 'label': 'A general massacre', 'sub': 'tens of thousands slaughtered in reprisal', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Towers of skulls', 'sub': 'heads piled into pyramids as a warning', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='Isfahan’s revolt taught every other city the price of defiance — the skull-tower became his signature.', accent=AC),
      bg='<b>Isfahan</b>, a great Persian city, surrendered to Timur but then <b>rebelled</b>, killing the officials he had left to collect tribute.',
      people='The people of Isfahan; the soldiers ordered to bring back a quota of severed heads.',
      what='In reprisal for the <b>1387</b> revolt, Timur ordered a <b>general massacre of Isfahan</b>, in which tens of thousands were killed and their <b>skulls piled into towers</b> — an early, defining example of the calculated terror that marked his whole career.',
      crux='He made <b>exemplary atrocity a deliberate instrument</b>: a rebellious city destroyed so spectacularly that others would never dare resist.',
      conseq='The horror of Isfahan ran ahead of his armies, easing later conquests across Persia.',
      matters='Isfahan is where Timur’s terror-as-policy takes its signature form — the skull-tower that would follow him from Persia to India.'),

    E('shiraz', '1387–1393', 'Conquering the poets’ Persia — Shiraz and Fars', ['BATTLE', 'TRIUMPH'],
      'He completes the conquest of Persia by taking the cultured south — Shiraz, city of the great poets Hafez and Saadi — and legend has it that he confronts a verse of Hafez that gave away his cities of Samarkand and Bukhara for a beautiful girl’s mole, a story that captures the strange meeting of the destroyer and the world of Persian poetry.',
      svg_row('Taking the heartland of Persian culture', [
          {'n': 1, 'label': 'Conquers Fars and Shiraz', 'sub': 'the cultured south of Persia falls', 'color': '#0f766e'},
          {'n': 2, 'label': 'The Muzaffarids ended', 'sub': 'the local dynasty destroyed', 'color': '#b45309'},
          {'n': 3, 'label': 'The Hafez legend', 'sub': 'a famous (apocryphal) exchange over a poem', 'color': '#0e7490'},
      ], edge_labels=['then', 'then'], takeaway='He conquered the very heartland of Persian poetry — the destroyer amid the world of Hafez and Saadi.', accent=AC),
      bg='Southern Persia (<b>Fars</b>), centred on <b>Shiraz</b> — home of the poets <b>Hafez</b> and <b>Saadi</b> — was ruled by the <b>Muzaffarid</b> dynasty.',
      people='The <b>Muzaffarid</b> rulers Timur destroyed; the memory of the poet <b>Hafez</b>, subject of a famous legend about a meeting with Timur.',
      what='Timur conquered <b>Fars and Shiraz</b> and ended the <b>Muzaffarid</b> dynasty, completing his mastery of Persia. Legend tells of a (probably apocryphal) exchange in which he confronted <b>Hafez</b> over a verse offering Samarkand and Bukhara for a lover’s beauty spot.',
      crux='He absorbed the <b>cultural heartland of Persia</b>, and the Hafez legend captures the paradox of a brutal conqueror steeped in, and fascinated by, high Persian culture.',
      conseq='All Persia was now his; its Persianate culture would deeply shape the Timurid renaissance to come.',
      matters='Timur destroyed and absorbed the world of Persian poetry at once — a paradox embodied in the tale of the conqueror and the poet.'),

    E('moscow', '1395', 'To the edge of Russia — the road not taken', ['BATTLE', 'TURNING POINT'],
      'After shattering the Golden Horde at the Terek, he drives north into Russian lands, sacking the town of Yelets and sending panic through Moscow — then, mysteriously, turns back, sparing the Russian capital and leaving Muscovites to credit their deliverance to a holy icon.',
      svg_row('The invasion that suddenly stopped', [
          {'n': 1, 'label': 'Beats Tokhtamysh at the Terek', 'sub': 'the Golden Horde crushed, 1395', 'color': '#0f766e'},
          {'n': 2, 'label': 'Drives into Russia', 'sub': 'sacks Yelets; Moscow braces in terror', 'color': '#b45309'},
          {'n': 3, 'label': 'Turns back', 'sub': 'inexplicably withdraws; Moscow is spared', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He came within reach of Moscow — then turned away, one of history’s great near-misses for Russia.', accent=AC),
      bg='After his decisive victory over Tokhtamysh at the <b>Terek River (1395)</b>, Timur advanced north into the lands of the Rus’.',
      people='The terrified people of <b>Moscow</b>; the town of <b>Yelets</b>, which he sacked; the Russian chroniclers who recorded the scare.',
      what='Timur pushed into Russian territory, <b>sacked Yelets</b>, and threatened <b>Moscow</b> — before unexpectedly <b>turning back</b> without attacking the city. Russians attributed their deliverance to the icon of the Virgin of Vladimir.',
      crux='His northern thrust showed the <b>vast, almost casual reach of his power</b> — and his withdrawal remains one of history’s intriguing "what ifs" for Russia.',
      conseq='Moscow was spared, but the campaign completed the ruin of the Golden Horde that would help Russia eventually rise.',
      matters='History turns on roads not taken. Timur at the edge of Moscow is a haunting near-miss — and a measure of how far his terror reached.'),
]

# ==================================================================  PHASE 3 — INDIA
PHASE_INDIA = [
    E('prisoners', 'Dec 1398', 'The massacre before the battle', ['BATTLE', 'TRAGEDY'],
      'Marching on Delhi, Timur’s army has taken so many captives that he fears they will rise during the coming battle — so on the eve of the fight he orders every prisoner, perhaps 100,000, put to the sword in a single day.',
      svg_stack('Cold arithmetic of terror', [
          {'n': 1, 'label': 'A vast column of captives', 'sub': 'tens of thousands seized crossing the Punjab', 'color': '#a16207'},
          {'n': 2, 'label': 'A battle looming at Delhi', 'sub': 'fear the prisoners will revolt behind the lines', 'color': '#0f766e'},
          {'n': 3, 'label': '~100,000 killed in a day', 'sub': 'every man ordered to execute his own prisoners', 'color': '#b91c1c'},
      ], takeaway='He treated mass murder as a logistical decision — removing a risk before a battle, at a scale that still stuns.', accent=AC),
      bg='Invading India in 1398, Timur’s army swept the Punjab and accumulated an enormous number of Hindu <b>prisoners</b> as it neared the Sultanate’s capital.',
      people='The anonymous captives; Timur’s own chroniclers, who record the order without apology; Sultan <b>Mahmud</b>’s army waiting at Delhi.',
      what='Before engaging the Sultan’s war-elephants, Timur — fearing the prisoners might turn on his rear — ordered the <b>execution of the entire captive host</b>, reportedly around <b>100,000 in one day</b>, each soldier responsible for his own.',
      crux='Terror was <b>calculated, not frenzied</b> — a pre-emptive elimination of risk, and a message to every future foe.',
      conseq='The unencumbered army then destroyed Delhi; the massacre became one of the most infamous atrocities of the age.',
      matters='The most chilling cruelty is often not rage but arithmetic — evil administered as a solution to a problem.'),

    E('delhi', '1398', 'The sack of Delhi', ['BATTLE', 'TRAGEDY', 'TRIUMPH'],
      'He invades India on the pretext that its Muslim rulers are too tolerant of Hindus, defeats the Delhi Sultanate’s war-elephants with clever tactics, and leaves the great city a corpse-choked ruin.',
      svg_row('Beating elephants, then destroying a capital', [
          {'n': 1, 'label': 'Invade the Delhi Sultanate', 'sub': 'crosses the Indus with a pretext of piety', 'color': '#0f766e'},
          {'n': 2, 'label': 'Defeat the war-elephants', 'sub': 'fire, caltrops and burning camels panic them', 'color': '#b45309'},
          {'n': 3, 'label': 'Delhi sacked & massacred', 'sub': 'the city devastated; tens of thousands killed', 'color': '#dc2626'},
      ], edge_labels=['then', 'then'], takeaway='He solved the elephant problem with cunning — then destroyed one of the world’s great cities.', accent=AC),
      bg='In <b>1398</b> Timur invaded northern India, nominally to punish the <b>Delhi Sultanate</b> for being too lenient toward its Hindu subjects — but really for plunder and glory.',
      people='The Sultan of Delhi and his war-elephant army; the people of <b>Delhi</b>, massacred in the sack.',
      what='Timur beat the feared <b>war-elephants</b> (reputedly by loading camels with wood, setting them alight, and driving them at the elephants to stampede them), stormed <b>Delhi</b>, and left it a devastated, depopulated ruin — one of the worst catastrophes in the city’s history.',
      crux='He combined <b>tactical ingenuity</b> against the elephants with his usual <b>strategy of overwhelming terror</b>, extracting immense plunder and skilled captives (who would beautify Samarkand).',
      conseq='The Delhi Sultanate was crippled for decades; Timur withdrew laden with treasure and artisans, leaving chaos behind.',
      matters='Even the most fearsome weapon has a counter. And plunder-by-terror enriched Samarkand at the cost of a shattered India.'),
]

# ==================================================================  PHASE 4 — THE WEST
PHASE_WEST = [
    E('sivas', '1400', 'Sivas — burying the garrison alive', ['BATTLE', 'TRAGEDY'],
      'To punish an Ottoman frontier city and provoke Sultan Bayezid, Timur takes Sivas by siege, then keeps a grim promise not to “shed blood” by burying its surrendered defenders alive — a calculated horror aimed at the man he means to destroy next.',
      svg_row('A siege designed to send a message', [
          {'n': 1, 'label': 'Sivas besieged, 1400', 'sub': 'an Ottoman-held city on Timur’s western march', 'color': '#0f766e'},
          {'n': 2, 'label': '“No blood shed”', 'sub': 'the garrison surrenders on a technical promise of mercy', 'color': '#a16207'},
          {'n': 3, 'label': 'Buried alive', 'sub': 'the defenders entombed — the letter of the promise kept', 'color': '#b91c1c'},
      ], edge_labels=['then', 'then'], takeaway='He weaponised even his promises — honouring their wording while betraying their meaning.', accent=AC),
      bg='As Timur turned west toward Anatolia, the rising <b>Ottoman</b> sultan Bayezid I was expanding into the same borderlands. Sivas was a flashpoint between the two conquerors.',
      people='The Armenian and Turkish defenders of Sivas; <b>Bayezid</b>, whose son had governed there; the envoys trading insults between the two rulers.',
      what='Timur stormed <b>Sivas</b> in 1400 and, having promised not to shed the garrison’s blood, reportedly had many of them <b>buried alive</b> instead — provocation aimed squarely at Bayezid.',
      crux='Terror here was <b>diplomacy by other means</b> — a deliberate outrage to goad his real target into battle on Timur’s terms.',
      conseq='The atrocity and the exchange of insults led directly to the showdown at Ankara in 1402.',
      matters='A promise kept in words but broken in spirit can be crueller than an open threat — and just as strategic.'),

    E('baghdad', '1401', 'The sack of Baghdad — a tower of ninety thousand', ['BATTLE', 'TRAGEDY'],
      'When the great city of Baghdad revolts, he storms it and orders each soldier to bring back severed heads, from which he builds towers said to hold ninety thousand skulls — one of the most notorious atrocities of an age full of them.',
      svg_row('Exemplary horror at Baghdad', [
          {'n': 1, 'label': 'Baghdad revolts', 'sub': 'the ancient Abbasid capital defies him', 'color': '#0f766e'},
          {'n': 2, 'label': 'The city stormed', 'sub': 'taken after a short, brutal siege in 1401', 'color': '#b45309'},
          {'n': 3, 'label': 'Towers of skulls', 'sub': 'a mass slaughter; ~90,000 heads, by report', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He turned one of Islam’s greatest cities into a monument of severed heads — terror as deliberate policy.', accent=AC),
      bg='<b>Baghdad</b>, once the glittering capital of the Abbasid Caliphate, had submitted and then rebelled against Timur.',
      people='The Jalayirid ruler who had defied him; the people of Baghdad, massacred in the sack.',
      what='In <b>1401</b> Timur stormed <b>Baghdad</b> and carried out a horrific massacre, reportedly ordering each soldier to produce severed heads and raising <b>towers of some 90,000 skulls</b> — a signature act of exemplary terror.',
      crux='He used <b>spectacular atrocity as calculated policy</b>: the destruction of a famous city broadcast a warning to every other that might consider resistance.',
      conseq='Baghdad, a centre of Islamic civilisation, was devastated; the horror rippled ahead of his army into Syria and Anatolia.',
      matters='Timur’s sack of Baghdad is a grim reminder that his empire was built as much on deliberate, systematic terror as on generalship.'),

    E('aleppo', '1400', 'Aleppo — shattering the Mamluks', ['BATTLE', 'TRIUMPH', 'TRAGEDY'],
      'Before Damascus, Timur crushes a Mamluk army outside Aleppo by panicking its war-elephants and cavalry, storms the great citadel, and raises yet another tower of skulls — announcing to the Islamic world that even Egypt’s sultanate cannot stop him.',
      svg_row('Breaking the Mamluk shield of Syria', [
          {'n': 1, 'label': 'Mamluk army at Aleppo', 'sub': 'Egypt’s soldiers defend northern Syria, 1400', 'color': '#a16207'},
          {'n': 2, 'label': 'Elephants and feigned flight', 'sub': 'Timur’s tactics rout the Mamluk horse', 'color': '#0f766e'},
          {'n': 3, 'label': 'Citadel stormed, tower of skulls', 'sub': 'the city sacked; terror advertised again', 'color': '#b91c1c'},
      ], edge_labels=['beaten by', 'then'], takeaway='He proved the mighty Mamluks could be broken — isolating Damascus and the whole Levant.', accent=AC),
      bg='Northern Syria belonged to the <b>Mamluk Sultanate</b> of Egypt, one of the era’s great military powers and the destroyer of earlier Mongol invasions.',
      people='The Mamluk field army and governors; the citizens of <b>Aleppo</b>; the qadis and scholars Timur summoned to debate whose dead were “martyrs.”',
      what='In 1400 Timur <b>defeated the Mamluk army before Aleppo</b>, took the formidable citadel, and sacked the city with the customary massacre — clearing the road to Damascus.',
      crux='Defeating the Mamluks in open battle <b>shattered their aura of invincibility</b> and left Syria exposed.',
      conseq='The victory opened the way to Damascus and his famous meeting with Ibn Khaldun, and humbled the greatest Muslim power of the west.',
      matters='Breaking a feared power in one battle can unlock a whole region — reputation, once cracked, collapses fast.'),

    E('ibnkhaldun', '1401', 'Damascus — and a conversation with Ibn Khaldun', ['BATTLE', 'POLITICS'],
      'He takes Damascus and burns its great mosque — but the campaign is immortalised by something stranger: weeks of conversation between the world-conqueror and the great historian Ibn Khaldun, lowered over the city wall to meet him, each studying the other across the ruins.',
      svg_compare('Conqueror meets philosopher',
          {'head': 'Timur the conqueror', 'color': '#0f766e',
           'items': ['takes and sacks Damascus, 1401', 'burns the Umayyad Mosque', 'curious about history and his own place in it']},
          {'head': 'Ibn Khaldun the historian', 'color': '#0e7490',
           'items': ['the age’s greatest theorist of history', 'meets Timur over several weeks', 'leaves a rare first-hand portrait of him']},
          verdict='The 14th century’s greatest destroyer and its greatest historian, face to face amid the ruins.',
          takeaway='History’s most famous conqueror-meets-thinker encounter — Ibn Khaldun’s account is our closest look at the real Timur.', accent=AC),
      bg='After Baghdad, Timur moved against the <b>Mamluks</b> in Syria, besieging and taking <b>Damascus</b>. The great Arab historian <b>Ibn Khaldun</b> was trapped in the city.',
      people='<b>Ibn Khaldun</b>, author of the <i>Muqaddimah</i> and pioneer of the philosophy of history; the Mamluk defenders of Damascus.',
      what='Timur took <b>Damascus in 1401</b>, sacking it and burning the <b>Umayyad Mosque</b>. During the siege, <b>Ibn Khaldun</b> was lowered over the wall to negotiate and spent <b>several weeks in conversation</b> with Timur, later writing a vivid first-hand account of the conqueror’s intelligence and curiosity.',
      crux='The episode captures the <b>paradox of Timur</b>: a destroyer of cities who was also genuinely learned and fascinated by history, ideas and his own legend.',
      conseq='Syria fell; Timur turned north to face the greatest rival left in his path — the Ottomans.',
      matters='One of history’s most remarkable meetings — it gives us, through Ibn Khaldun, a rare and human portrait of a man usually seen only through his atrocities.'),

    E('ankara', '1400–1402', 'Ankara and the capture of a sultan', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'Having shattered Syria, he collides with the rising Ottoman Empire at Ankara, turns its sultan’s own vassals against him mid-battle, and takes Sultan Bayezid prisoner — accidentally saving Constantinople for another fifty years.',
      svg_ankara(),
      bg='In his last great western campaign Timur crushed the <b>Mamluks</b> in Syria (Aleppo and Damascus) and then turned on the <b>Ottomans</b> under the aggressive Sultan Bayezid I.',
      people='<b>Sultan Bayezid I</b> “the Thunderbolt,” the aggressive Ottoman ruler then besieging Constantinople; the Anatolian vassal lords who <b>defected</b> to Timur at the battle.',
      what='At the <b>Battle of Ankara (1402)</b>, Timur defeated the Ottomans — partly because Bayezid’s Anatolian vassals switched sides — and <b>captured Sultan Bayezid himself</b>, who died in captivity. The Ottoman state fell into a decade of civil war.',
      crux='He shattered the strongest rising power in the region at its peak. A side effect: with the Ottomans in chaos, their siege of <b>Constantinople was lifted</b> — buying the Byzantine capital ~50 more years before its 1453 fall.',
      conseq='Timur stood unmatched from the Aegean to India — then turned his eyes east, toward the greatest prize of all: China.',
      matters='Power balances can turn on a single battle. Tamerlane’s victory reshaped the Middle East and inadvertently prolonged the life of the Roman Empire’s last capital.'),
]

# ==================================================================  PHASE 5 — DEATH & LEGACY
PHASE_END = [
    E('samarkand', '1370–1405', 'Building the centre of the world — Samarkand', ['REFORM', 'TRIUMPH'],
      'For all his destruction, he pours the plunder and captive artisans of a continent into one place: his capital Samarkand, which he adorns with dazzling mosques, gardens and monuments meant to make it the most beautiful city on earth — the constructive obsession behind all the carnage.',
      svg_stack('The city he built from the world’s plunder', [
          {'n': 1, 'label': 'Deport the world’s artisans', 'sub': 'craftsmen spared and sent to Samarkand', 'color': '#0f766e'},
          {'n': 2, 'label': 'Dazzling monuments', 'sub': 'the Bibi-Khanym mosque, gardens, the Gur-e-Amir', 'color': '#0e7490'},
          {'n': 3, 'label': 'A capital to awe the world', 'sub': 'meant to be the most beautiful city on earth', 'color': '#166534'},
      ], takeaway='Everything he destroyed elsewhere flowed into one place — Samarkand, built to be the wonder of the world.', accent=AC),
      bg='Timur made his capital <b>Samarkand</b> the showpiece of his empire, deliberately sparing skilled artisans from his massacres to build and beautify it.',
      people='The deported <b>craftsmen, architects and artists</b> from conquered lands; the builders of the <b>Bibi-Khanym mosque</b> and other wonders.',
      what='Timur funnelled plunder and <b>captive artisans</b> from across Asia into <b>Samarkand</b>, raising magnificent mosques, madrasas, gardens and tombs (the <b>Bibi-Khanym mosque</b>, the <b>Gur-e-Amir</b>) to make it a city of unmatched splendour.',
      crux='The <b>destroyer was also a builder</b>: he wrecked civilisations elsewhere to concentrate their wealth and talent in one glittering capital.',
      conseq='Samarkand became one of the great cities of the world and the seedbed of the Timurid renaissance.',
      matters='Timur’s paradox in one city: Samarkand’s beauty was built directly from the plunder and captives of the lands he destroyed.'),

    E('faith', '1370–1405', 'Sword of God — piety wielded as a weapon', ['POLITICS', 'REFORM'],
      'Timur ruled as a pious Muslim and patron of Sufi saints, yet slaughtered fellow Muslims by the hundred thousand — cloaking naked conquest in the language of holy war and divine mission, and silencing scholars who dared object.',
      svg_stack('Religion as legitimacy and cover', [
          {'n': 1, 'label': 'Patron of Islam and Sufis', 'sub': 'builds mosques and shrines; courts holy men like Yasawi’s order', 'color': '#0f766e'},
          {'n': 2, 'label': 'Every war a “holy war”', 'sub': 'campaigns framed as jihad — even against Muslim states', 'color': '#a16207'},
          {'n': 3, 'label': 'Piety over principle', 'sub': 'massacres of Muslims justified by mission and necessity', 'color': '#b91c1c'},
      ], takeaway='He fused genuine devotion with ruthless conquest — faith became both his belief and his alibi.', accent=AC),
      bg='Timur presented himself as a devout Muslim and <b>Ghazi</b> (holy warrior), building the grand shrine of the Sufi saint <b>Ahmad Yasawi</b> and surrounding himself with religious scholars.',
      people='The Sufi shaykhs he patronised; the <b>ulama</b> who blessed or feared him; Ibn Khaldun and others who studied the paradox of the pious destroyer.',
      what='He endowed mosques and shrines and claimed divine sanction, yet sacked Muslim Baghdad, Damascus and Delhi and defeated the Muslim Ottomans and Mamluks — framing all of it as righteous.',
      crux='He grasped that <b>religious legitimacy multiplied power</b> — sanctifying conquest and daring critics to challenge God’s instrument.',
      conseq='The image of the “Sword of Islam” both awed contemporaries and troubled them; his shrines and mosques remain among Central Asia’s glories.',
      matters='Power often drapes itself in the sacred — devotion can be sincere and self-serving at once.'),

    E('china', '1404–1405', 'The last ambition — the march on Ming China', ['BATTLE', 'TURNING POINT'],
      'At nearly seventy, Timur launches his most audacious campaign yet: a winter invasion of Ming China, to punish the dynasty that ended Mongol rule and to spread Islam to the east — a 200,000-strong expedition that death alone would halt.',
      svg_row('The conquest he did not live to attempt', [
          {'n': 1, 'label': 'The grievance', 'sub': 'the Ming had overthrown the Mongol Yuan in 1368', 'color': '#a16207'},
          {'n': 2, 'label': 'A vast winter army', 'sub': '~200,000 men, supply depots, even farmers to sow en route', 'color': '#0f766e'},
          {'n': 3, 'label': 'Marches east, Dec 1404', 'sub': 'the greatest of all his expeditions sets out', 'color': '#7c3aed'},
      ], edge_labels=['drives', 'becomes'], takeaway='His ambition had no ceiling — having taken the west, he turned to conquer the east as well.', accent=AC),
      bg='Timur had long resented the <b>Ming</b> dynasty, which had toppled the Mongol <b>Yuan</b> and treated him as a tributary vassal. He resolved on a full invasion of China.',
      people='The <b>Yongle Emperor</b>’s newly powerful Ming state; Timur’s grandsons and marshals mustering the host; the envoys he had earlier detained.',
      what='In late 1404 he assembled perhaps <b>200,000 troops</b>, with supply arrangements for a winter campaign across the steppe, and set out to <b>conquer China</b> and, he said, convert it to Islam.',
      crux='Even at the summit of an empire from Delhi to the Aegean, he could not stop — <b>conquest was compulsion</b>, not calculation.',
      conseq='The expedition had barely begun when he fell ill and died at Otrar in February 1405; the invasion of China evaporated with him.',
      matters='Boundless ambition often outruns the body and the lifespan — some dreams end only with the dreamer.'),

    E('death', '1405', 'Death on the road to China', ['DEATH', 'TRAGEDY'],
      'At nearly 70, undefeated, he sets out in winter to conquer Ming China and restore the Mongol empire in the east — and dies of illness on the march, his last great campaign never begun.',
      svg_row('The one conquest he never made', [
          {'n': 1, 'label': 'Aims at Ming China', 'sub': 'to “restore” Mongol rule over the east', 'color': '#0f766e'},
          {'n': 2, 'label': 'Marches in winter', 'sub': 'sets out with a huge army, aged ~68', 'color': '#b45309'},
          {'n': 3, 'label': 'Dies en route (1405)', 'sub': 'illness ends the campaign before it starts', 'color': '#111827'},
      ], edge_labels=['then', 'then'], takeaway='Even the undefeated conqueror ran out of the one thing he couldn’t conquer — time.', accent=AC),
      bg='Having subdued western Asia, Timur resolved on a final, vast campaign to conquer <b>Ming China</b> and reunite the old Mongol dominions.',
      people='His many sons and grandsons, who would fight over the succession; the Ming dynasty he never reached.',
      what='In the winter of <b>1404–05</b> he set out for China with a great army, but <b>fell ill and died at Otrar in February 1405</b>, aged around 68 — the invasion abandoned.',
      crux='His empire, like Genghis’s and Alexander’s, was held together by <b>his person and his terror</b>; his death instantly loosened it into rival successor states.',
      conseq='The vast Timurid empire fragmented among his heirs in wars of succession — but the dynasty and its culture endured in Central Asia and Persia.',
      matters='Empires built on one man’s will and fear rarely survive him intact. The conqueror’s hardest limit is mortality itself.'),

    E('succession', '1405–1420', 'The empire torn apart by his heirs', ['POLITICS', 'TRAGEDY', 'DEATH'],
      'Timur named a grandson as heir, but the moment he died his sons and grandsons fell on each other — and the vast empire welded by one man’s will unravelled within a generation into warring Timurid fragments.',
      svg_stack('An empire that could not survive its maker', [
          {'n': 1, 'label': 'Heir ignored', 'sub': 'the designated grandson Pir Muhammad is brushed aside', 'color': '#a16207'},
          {'n': 2, 'label': 'Sons and grandsons at war', 'sub': 'Khalil Sultan seizes Samarkand; rivals carve up the rest', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Shah Rukh salvages a core', 'sub': 'a son restores a smaller, brilliant realm from Herat', 'color': '#0f766e'},
      ], takeaway='Held together by one man’s terror and genius, the empire had no institutions to outlive him.', accent=AC),
      bg='Timur’s domain stretched from India to Anatolia but rested on <b>his personal authority</b> and a Turco-Mongol elite bound by loyalty and plunder, not durable institutions.',
      people='<b>Pir Muhammad</b>, the ignored heir; <b>Khalil Sultan</b>, who grabbed Samarkand; <b>Shah Rukh</b>, the son who eventually re-established a reduced empire from Herat.',
      what='Within months of his death the succession collapsed into <b>civil war among his descendants</b>. Much of the periphery broke away; by 1420 <b>Shah Rukh</b> had restored a smaller Timurid state centred on Khorasan.',
      crux='A conquest empire built on <b>one man’s person</b> — like Alexander’s — shattered the instant that person was gone.',
      conseq='The reduced Timurid realm nonetheless nurtured a golden age of art and science, and a descendant, Babur, would found the Mughal Empire in India.',
      matters='Conquest without institutions dies with the conqueror; what endures is the culture the conquest happens to seed.'),

    E('legacy', '1405–1526', 'The Timurid Renaissance — and the Mughals', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'The destroyer of cities is also, paradoxically, the founder of a golden age: Samarkand becomes a wonder of the world, his grandson maps the stars, and a descendant, Babur, founds the Mughal Empire in India.',
      svg_legacy(),
      bg='Timur brought captured artists, scholars and craftsmen to beautify <b>Samarkand</b>, and his dynasty patronised a brilliant flowering of art, architecture and science.',
      people='<b>Ulugh Beg</b>, his grandson — a great astronomer whose Samarkand observatory produced star charts used for centuries; <b>Babur</b>, his descendant, founder of the <b>Mughal Empire</b>.',
      what='Though his empire fragmented, the <b>Timurid Renaissance</b> made Samarkand and Herat centres of learning and stunning architecture; <b>Ulugh Beg</b> advanced astronomy; and in 1526 Timur’s descendant <b>Babur</b> founded the <b>Mughal Empire</b>, which ruled India for three centuries.',
      crux='His legacy is a stark <b>paradox</b>: one of history’s most destructive conquerors also seeded one of its great cultural golden ages and a durable imperial dynasty.',
      conseq='Timurid art, Persianate culture and the Mughal Empire shaped Central and South Asia for centuries — a creative afterlife utterly unlike the carnage of his campaigns.',
      matters='History’s destroyers and builders are sometimes the same people. Tamerlane razed civilisations and fathered a renaissance — both are his true legacy.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Tamerlane — Timur the Lame — rose from a lamed minor noble to the last of the great steppe world-conquerors, building an empire from Delhi to the Aegean through campaigns of dazzling generalship and appalling slaughter. He is a study in <b>self-made power, legitimacy engineered around the rules, terror as strategy, and the paradox of a destroyer who founded a cultural golden age.</b></p>
<div class="ov-quote">“The whole expanse of the inhabited part of the world is not large enough to have two kings.”<span>— words attributed to Timur</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A lamed Barlas noble rises through the anarchy of Central Asia → rules as “amir” behind a puppet khan to sidestep the Genghisid rule → conquers Persia with towers of skulls → shatters the Golden Horde that betrayed him → sacks Delhi → smashes the Ottomans at Ankara and captures their sultan → dies marching on China → leaves a fragmented empire but a brilliant Timurid renaissance and the future Mughal dynasty.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🧩</div><h4>Power vs title</h4><p>He held total power while never claiming the forbidden title of khan — legitimacy engineered around the rules.</p></div>
  <div class="ov-card"><div class="i">💀</div><h4>Terror as strategy</h4><p>The skull-towers were policy, not madness — a deliberate tool to make resistance unthinkable.</p></div>
  <div class="ov-card"><div class="i">🌐</div><h4>He reshaped Eurasia</h4><p>Crippling the Golden Horde helped free Russia; beating the Ottomans prolonged Constantinople.</p></div>
  <div class="ov-card"><div class="i">🕌</div><h4>Destroyer & renaissance</h4><p>The razer of cities seeded the Timurid golden age and, through Babur, the Mughal Empire.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Lame Rise</b><small> 1336–70</small><p>From minor noble to master of Samarkand.</p></div>
  <div><b>2 · The Conqueror</b><small> 1370s–95</small><p>Persia, terror, and crushing the Golden Horde.</p></div>
  <div><b>3 · India</b><small> 1398</small><p>Beating the elephants; the sack of Delhi.</p></div>
  <div><b>4 · The West</b><small> 1400–02</small><p>Baghdad, Damascus, and the capture of a sultan.</p></div>
  <div><b>5 · Death & Legacy</b><small> 1405+</small><p>Death on the road to China; the Timurid golden age.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Amir Husayn', 'role': 'partner → rival', 'color': '#b45309',
     'bio': 'Timur’s brother-in-law and early ally in the struggle for Transoxiana, whom Timur outmanoeuvred and had eliminated on his road to sole power.',
     'rel': 'The partner he betrayed to become master of Samarkand.'},
    {'name': 'Tokhtamysh', 'role': 'protégé → enemy', 'color': '#dc2626',
     'bio': 'A khan Timur raised to rule the Golden Horde, who then turned on his patron. Timur hunted and crushed him, wrecking the Horde in the process.',
     'rel': 'The ungrateful protégé whose betrayal reshaped Russia’s future.'},
    {'name': 'Bayezid I', 'role': 'Ottoman sultan', 'color': '#7c2d12',
     'bio': 'The aggressive Ottoman sultan “the Thunderbolt,” besieger of Constantinople, defeated and captured by Timur at Ankara (1402); he died in captivity.',
     'rel': 'The rival emperor he humbled and imprisoned.'},
    {'name': 'Ulugh Beg', 'role': 'grandson / astronomer', 'color': '#0e7490',
     'bio': 'Timur’s grandson, a scholar-ruler whose Samarkand observatory produced remarkably accurate star catalogues — the human face of the Timurid Renaissance.',
     'rel': 'The grandson who turned the dynasty toward science and beauty.'},
    {'name': 'Babur', 'role': 'descendant / Mughal founder', 'color': '#0f766e',
     'bio': 'A Timurid prince (descended from Timur, and from Genghis on his mother’s side) who, driven from Central Asia, conquered northern India in 1526 and founded the Mughal Empire.',
     'rel': 'The descendant who turned Timur’s blood into a 300-year Indian empire.'},
    {'name': 'The artisans of Samarkand', 'role': 'the spared', 'color': '#166534',
     'bio': 'The skilled craftsmen, architects and scholars Timur spared from massacre and deported to Samarkand to build and adorn his capital into a wonder of the age.',
     'rel': 'The captives whose talent made his capital immortal.'},
]

KEY_EVENTS = [
    ('c. 1336', 'Born a Barlas noble near Samarkand', 'Minor nobility, not of the line of Genghis.'),
    ('1360s', 'Wounded and lamed', '“Timur the Lame” rises through Transoxiana’s wars.'),
    ('1370', 'Master of Transoxiana', 'Rules as amir behind a puppet Genghisid khan.'),
    ('1380s', 'Conquest of Persia', 'Terror and skull-towers (Isfahan) subdue the region.'),
    ('1391–95', 'Destroys the Golden Horde', 'Crushes his protégé Tokhtamysh; sacks its cities.'),
    ('1398', 'Sack of Delhi', 'Beats the war-elephants; devastates the city.'),
    ('1400–01', 'Sacks Aleppo, Damascus, Baghdad', 'The Mamluks and Iraq crushed with massacres.'),
    ('1402', 'Battle of Ankara', 'Defeats and captures the Ottoman sultan Bayezid I.'),
    ('1405', 'Death on the road to China', 'Dies aged ~68; the last campaign abandoned.'),
    ('1405+', 'The empire fragments', 'Wars of succession among his heirs.'),
    ('1420s', 'Ulugh Beg’s Samarkand', 'The Timurid Renaissance in art and science.'),
    ('1526', 'Babur founds the Mughal Empire', 'Timur’s line rules India for three centuries.'),
]

MASTER = [
    {'year': 'c.1336', 'age': 'born', 'phase': 'The Rise', 'title': 'Born a Barlas noble', 'desc': 'Minor nobility near Samarkand.'},
    {'year': '1370', 'age': 'age ~34', 'phase': 'The Rise', 'title': 'Master of Transoxiana', 'desc': 'Rules as amir behind a puppet khan.'},
    {'year': '1380s', 'age': '40s', 'phase': 'Conqueror', 'title': 'Conquers Persia', 'desc': 'Terror and skull-towers.'},
    {'year': '1395', 'age': 'age ~59', 'phase': 'Conqueror', 'title': 'Crushes the Golden Horde', 'desc': 'Destroys the traitor Tokhtamysh.'},
    {'year': '1398', 'age': 'age ~62', 'phase': 'India', 'title': 'Sack of Delhi', 'desc': 'Beats the elephants; devastates the city.'},
    {'year': '1402', 'age': 'age ~66', 'phase': 'The West', 'title': 'Ankara', 'desc': 'Captures the Ottoman sultan Bayezid.'},
    {'year': '1405', 'age': 'age ~68', 'phase': 'Death', 'title': 'Death en route to China', 'desc': 'The undefeated conqueror dies.'},
    {'year': '1420s', 'age': 'legacy', 'phase': 'Death', 'title': 'Timurid Renaissance', 'desc': 'Samarkand’s golden age under Ulugh Beg.'},
    {'year': '1526', 'age': 'legacy', 'phase': 'Death', 'title': 'The Mughal Empire', 'desc': 'Babur carries the line into India.'},
]

SOURCES = [
    ('Britannica — Timur', 'https://www.britannica.com/biography/Timur'),
    ('World History Encyclopedia — Timur', 'https://www.worldhistory.org/Timur/'),
    ('Britannica — Battle of Ankara', 'https://www.britannica.com/event/Battle-of-Ankara'),
    ('Wikipedia — Timur', 'https://en.wikipedia.org/wiki/Timur'),
]

def build_meta():
    return {
        'pid': 'gm-tamerlane.html', 'kind': 'man', 'emoji': '🗡️', 'accent': AC,
        'name': 'Tamerlane (Timur)', 'years': '1336–1405', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'A lamed minor noble who conquered from Delhi to the Aegean through genius and slaughter — a destroyer of cities who fathered a renaissance and the Mughal Empire.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Lame Rise', 'type': 'timeline',
             'intro': 'A lamed minor noble claws his way up through the anarchy of Central Asia — and solves the problem that he is not of Genghis’s line by ruling as “amir” behind a puppet khan.', 'events': PHASE_RISE},
            {'id': 'conquer', 'label': '2 · The Conqueror', 'type': 'timeline',
             'intro': 'He pours across Persia with terror as his tool, and destroys the Golden Horde — the protégé who betrayed him — reshaping the future of Russia in the process.', 'events': PHASE_CONQUER},
            {'id': 'india', 'label': '3 · India', 'type': 'timeline',
             'intro': 'He invades India, outwits its war-elephants, and leaves Delhi a ruin — carrying home the treasure and artisans who will make Samarkand a wonder.', 'events': PHASE_INDIA},
            {'id': 'west', 'label': '4 · The West', 'type': 'timeline',
             'intro': 'Turning west, he sacks Baghdad and Damascus and smashes the rising Ottomans at Ankara, capturing their sultan — and accidentally saving Constantinople for fifty years.', 'events': PHASE_WEST},
            {'id': 'end', 'label': '5 · Death & Legacy', 'type': 'timeline',
             'intro': 'He dies marching on China, undefeated; his empire fragments — but leaves the dazzling Timurid renaissance and the seed of the Mughal Empire.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Casualty figures for Timur’s massacres are enormous and debated; sources hostile and admiring both exaggerate. This guide reflects the mainstream that his campaigns killed on a vast scale.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
