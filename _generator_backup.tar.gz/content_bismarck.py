# -*- coding: utf-8 -*-
"""Full, DEEP birth-to-death guide content for Otto von Bismarck.
The master of realpolitik who unified Germany by 'blood and iron' — then kept the peace."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#44403c'  # Prussian iron

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE JUNKER
PHASE_RISE = [
    E('junker', '1815–1847', 'The wild Junker — “mad Bismarck”', ['RISE'],
      'Bismarck is born into the Prussian landed aristocracy — the Junkers — and spends his youth as a notorious hell-raiser, running up debts, fighting duels, and drinking, earning the nickname “mad Bismarck,” before settling as a country squire, a late and unlikely start for a future statesman.',
      svg_row('An unpromising start for a titan', [
          {'n': 1, 'label': 'Born a Prussian Junker, 1815', 'sub': 'the conservative landed aristocracy east of the Elbe', 'color': '#44403c'},
          {'n': 2, 'label': '“Mad Bismarck”', 'sub': 'debts, duels and drink at university and after', 'color': '#a16207'},
          {'n': 3, 'label': 'A restless country squire', 'sub': 'manages the family estates, bored and ambitious', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='Nothing in his wild youth suggested the master statesman to come — greatness came late and unexpectedly.', accent=AC),
      bg='<b>Otto von Bismarck</b> was born in 1815 into the <b>Junker</b> class — the conservative Prussian landowning aristocracy — and educated in law, though he was a poor, rebellious student.',
      people='his aristocratic family; the university friends and creditors of his wild years; the Prussian society he would come to dominate.',
      what='Bismarck spent his twenties as a hard-drinking, duelling, debt-ridden <b>“mad Bismarck,”</b> then managed the family estates — a restless, ambitious squire with no obvious path to power.',
      crux='His formidable will and intelligence were, for years, <b>without an outlet</b> — the raw material of greatness looking for a stage.',
      conseq='The revolutions of 1848 gave the bored, reactionary squire his entry into politics.',
      matters='Great ability can lie dormant and misspent until the right crisis calls it out — Bismarck’s stage found him late.'),

    E('reactionary', '1847–1851', 'The revolutions of 1848 — a monarchist finds his voice', ['POLITICS', 'TURNING POINT'],
      'When revolution sweeps Europe in 1848, Bismarck emerges as a fierce, articulate defender of the Prussian monarchy against the liberals — so uncompromisingly reactionary that he first alarms even the king, but marks himself as a man of iron conviction and nerve.',
      svg_stack('The making of a political fighter', [
          {'n': 1, 'label': '1848 revolutions erupt', 'sub': 'liberals across Europe challenge the old order', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Bismarck defends the crown', 'sub': 'a fierce, uncompromising monarchist voice', 'color': '#44403c'},
          {'n': 3, 'label': 'Noticed by the powerful', 'sub': 'his nerve and conviction mark him out', 'color': '#166534'},
      ], takeaway='The crisis that toppled others made Bismarck — his ferocious defence of the monarchy launched his career.', accent=AC),
      bg='The <b>Revolutions of 1848</b> threatened monarchies across Europe with liberal and nationalist demands. In Prussia, conservatives rallied to defend the crown.',
      people='<b>King Frederick William IV</b>; the Prussian liberals Bismarck opposed; the conservative circle that sponsored his rise.',
      what='Bismarck burst onto the scene as an <b>uncompromising defender of royal authority</b> against the 1848 liberals — so hardline he initially unsettled the king, but establishing himself as a conservative of rare force and eloquence.',
      crux='He grasped, against the tide, that <b>resolute defence of power</b> — not compromise — was the winning stance in a revolution.',
      conseq='His conservative credentials won him diplomatic appointments that schooled him in the realities of power.',
      matters='Crises make careers — the person who acts with conviction when others waver is the one who is remembered and promoted.'),

    E('diplomat', '1851–1862', 'The apprenticeship in power — Frankfurt, Russia, France', ['POLITICS', 'REFORM'],
      'For a decade Bismarck learns statecraft first-hand as Prussia’s envoy — at the German Diet in Frankfurt, then as ambassador to Russia and France — coldly sizing up rivals, mastering the balance of power, and forming the ruthless, pragmatic philosophy that will become known as realpolitik.',
      svg_row('Learning the game of nations', [
          {'n': 1, 'label': 'Envoy at Frankfurt', 'sub': 'confronts Austria’s dominance of the German states', 'color': '#44403c'},
          {'n': 2, 'label': 'Ambassador to Russia & France', 'sub': 'studies the great powers up close', 'color': '#a16207'},
          {'n': 3, 'label': 'Forges his realpolitik', 'sub': 'power and interest over ideology and sentiment', 'color': '#166534'},
      ], edge_labels=['then', 'yields'], takeaway='A decade among the great powers taught him to see politics as it is, not as it ought to be — pure realpolitik.', accent=AC),
      bg='Prussia sent Bismarck as its representative to the <b>German Confederation Diet at Frankfurt</b>, then as ambassador to <b>Russia</b> and <b>France</b> — a front-row education in power politics.',
      people='the Austrian diplomats who patronised Prussia; the Russian court; Napoleon III’s France; the European statesmen he studied.',
      what='Across the 1850s Bismarck served as envoy at <b>Frankfurt</b> (where he chafed at Austrian dominance) and as ambassador to <b>St Petersburg and Paris</b> — developing his hard-headed <b>realpolitik</b>: judging every question by power and interest, not ideology.',
      crux='He learned to read the <b>true balance of power</b> and to act on interest, not sentiment — the foundation of all his later triumphs.',
      conseq='By 1862 he was the obvious man to call when the Prussian monarchy faced a crisis it could not otherwise solve.',
      matters='Mastery of statecraft is learned by close observation of power — Bismarck’s decade abroad made him the realist he became.'),
]

# ==================================================================  PHASE 2 — BLOOD AND IRON
PHASE_POWER = [
    E('ministerpresident', '1862', 'Called in a crisis — Minister-President of Prussia', ['POLITICS', 'TURNING POINT'],
      'When the Prussian king deadlocks with a liberal parliament that refuses to fund his army reforms — and even considers abdicating — Bismarck is summoned as a last resort, appointed Minister-President with a mandate to break the impasse by any means.',
      svg_stack('The last resort becomes the leader', [
          {'n': 1, 'label': 'The army-budget crisis', 'sub': 'parliament blocks funding for military reform', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The king near abdication', 'sub': 'Wilhelm I deadlocked with the liberals', 'color': '#a16207'},
          {'n': 3, 'label': 'Bismarck appointed, 1862', 'sub': 'called as a last resort to break the impasse', 'color': '#44403c'},
      ], takeaway='He rose to power not by winning an election but by being the one man ruthless enough to solve the king’s crisis.', accent=AC),
      bg='In 1862 <b>King Wilhelm I</b> was locked in a constitutional struggle with the liberal-dominated parliament, which refused to fund his cherished <b>army reforms</b>. The king even contemplated abdication.',
      people='<b>Wilhelm I</b>, the embattled king; the liberal Prussian parliament; War Minister <b>Roon</b>, who recommended Bismarck.',
      what='As a desperate last resort, Wilhelm I appointed Bismarck <b>Minister-President of Prussia</b> in 1862, trusting him to <b>break the deadlock</b> with the liberals and secure the army reforms.',
      crux='He gained power as the crown’s <b>indispensable strongman</b> — bound to the king, not to any parliament, and free to act ruthlessly.',
      conseq='Bismarck immediately defied the parliament, governing and taxing without an approved budget.',
      matters='Crises hand power to the ruthless — the leader called when all else fails owes his position to nerve, not consensus.'),

    E('bloodiron', '1862–1866', '“Blood and iron” — governing against parliament', ['POLITICS', 'TURNING POINT'],
      'Bismarck tells the Prussian parliament that the great questions of the age will be settled not by speeches and majority votes but by “blood and iron” — then proves it by simply governing and collecting taxes without a legal budget for four years, defying the liberals and daring them to stop him.',
      svg_row('Ruling by will, not by vote', [
          {'n': 1, 'label': '“Blood and iron” speech', 'sub': 'great questions settled by power, not majorities', 'color': '#44403c'},
          {'n': 2, 'label': 'Governs without a budget', 'sub': 'the “gap theory” — collects taxes despite the deadlock', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Dares the liberals to act', 'sub': 'defies parliament for four years and wins', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='He governed by sheer will and the army’s loyalty, exposing the liberals’ powerlessness against a determined executive.', accent=AC),
      bg='Facing a hostile liberal parliament, Bismarck needed to fund the army reforms without its approval — and to establish that real power lay with the crown.',
      people='the liberal deputies he defied; <b>Wilhelm I</b>, whose army he built; the Prussian bureaucracy and army that obeyed him.',
      what='In 1862 Bismarck declared that the day’s great questions would be decided by <b>“blood and iron,”</b> then <b>governed without a legal budget</b> (the “gap theory”) for four years, collecting taxes and building the army in defiance of parliament.',
      crux='He demonstrated that a <b>determined executive backed by the army</b> could simply override a parliament that had no means to enforce its will.',
      conseq='The reformed Prussian army he funded would soon win the wars that united Germany — and success silenced his critics.',
      matters='Formal rules mean little without the power to enforce them — Bismarck exposed the gap between liberal principle and real power.'),
]

# ==================================================================  PHASE 3 — THE WARS OF UNIFICATION
PHASE_WARS = [
    E('denmark', '1864', 'The Danish War — the first move, and a trap for Austria', ['BATTLE', 'POLITICS', 'TURNING POINT'],
      'Bismarck opens his campaign to unify Germany by joining with Austria to seize the disputed duchies of Schleswig and Holstein from Denmark — a quick victory that is also a subtle trap, leaving the two German rivals to jointly administer the spoils and setting up their inevitable quarrel.',
      svg_stack('A victory that plants a future war', [
          {'n': 1, 'label': 'War on Denmark, 1864', 'sub': 'Prussia and Austria seize Schleswig-Holstein', 'color': '#44403c'},
          {'n': 2, 'label': 'Joint administration', 'sub': 'the two rivals must share the conquered duchies', 'color': '#a16207'},
          {'n': 3, 'label': 'A quarrel engineered', 'sub': 'shared spoils guarantee a Prusso-Austrian dispute', 'color': '#b91c1c'},
      ], takeaway='He won territory and, more cleverly, manufactured the future pretext to fight Austria for mastery of Germany.', accent=AC),
      bg='The German duchies of <b>Schleswig and Holstein</b>, under the Danish crown, were a nationalist flashpoint. Bismarck used the issue to begin reshaping Germany.',
      people='<b>Denmark</b>, the defeated party; <b>Austria</b>, Prussia’s partner-then-rival; the German nationalist opinion Bismarck exploited.',
      what='In 1864 Prussia and Austria jointly <b>defeated Denmark</b> and took Schleswig-Holstein, then agreed to <b>administer the duchies together</b> — an arrangement Bismarck knew would breed conflict with Austria.',
      crux='He fought a war that also <b>set a diplomatic trap</b> — the shared spoils were designed to produce the quarrel he needed with Austria.',
      conseq='Disputes over the duchies gave Bismarck his pretext for the decisive war against Austria two years later.',
      matters='The subtlest strategists plant the seeds of the next move within the current one — victory arranged to create opportunity.'),

    E('austria', '1866', 'The Seven Weeks’ War — excluding Austria from Germany', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'Bismarck provokes and wins a lightning war against Austria, crushing it at Königgrätz — then, at the peak of victory, imposes a strikingly lenient peace, taking no Austrian territory, because he needs Austria as a future friend, not a vengeful enemy: a masterstroke of restraint that reshapes Germany under Prussian leadership.',
      svg_stack('Total victory, deliberate restraint', [
          {'n': 1, 'label': 'War with Austria, 1866', 'sub': 'the contest for mastery of Germany', 'color': '#44403c'},
          {'n': 2, 'label': 'Königgrätz — decisive win', 'sub': 'the reformed Prussian army crushes Austria', 'color': '#166534'},
          {'n': 3, 'label': 'A lenient peace', 'sub': 'no Austrian land taken — a future ally preserved', 'color': '#a16207'},
      ], takeaway='His genius was knowing when to stop — winning totally, then sparing the enemy to keep a friend for tomorrow.', accent=AC),
      bg='With Austria and Prussia at odds over the duchies and German leadership, Bismarck engineered the <b>Austro-Prussian War</b> of 1866 to settle who would dominate Germany.',
      people='<b>Austria</b> and its German allies; the Prussian general staff under <b>Moltke</b>; <b>Wilhelm I</b>, whom Bismarck restrained from harsh terms.',
      what='Prussia won decisively at <b>Königgrätz (Sadowa)</b> in the “Seven Weeks’ War.” Against the king’s and generals’ wishes, Bismarck insisted on a <b>lenient peace taking no Austrian territory</b>, and formed the Prussian-led <b>North German Confederation</b>, excluding Austria.',
      crux='He understood that <b>the aim was to reorganise Germany, not to humiliate Austria</b> — restraint in victory secured a stable future order.',
      conseq='Prussia now led a united northern Germany; only France stood between Bismarck and full unification.',
      matters='Knowing when to stop is as vital as knowing how to win — a magnanimous peace can be worth more than more conquered land.'),

    E('france', '1870', 'The Ems Dispatch and the Franco-Prussian War', ['BATTLE', 'POLITICS', 'TRIUMPH'],
      'To complete German unity, Bismarck needs a war with France that makes France the aggressor — so he edits a diplomatic telegram, the Ems Dispatch, to sound insulting to both sides, goading France into declaring war; the southern German states rally to Prussia, and at Sedan the French army and Emperor Napoleon III are captured.',
      svg_stack('A telegram engineered into a war', [
          {'n': 1, 'label': 'The Ems Dispatch, 1870', 'sub': 'Bismarck edits a telegram to inflame both nations', 'color': '#44403c'},
          {'n': 2, 'label': 'France declares war', 'sub': 'goaded into being the aggressor, uniting Germany', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Sedan — total victory', 'sub': 'the French army and Napoleon III captured', 'color': '#166534'},
      ], takeaway='He manufactured the war he needed and made his enemy start it — then won it completely.', accent=AC),
      bg='The southern German states remained outside Prussia’s orbit. Bismarck judged that a <b>war with France</b>, if France appeared the aggressor, would rally all Germans to Prussia.',
      people='<b>Napoleon III</b>, captured at Sedan; the southern German states that joined Prussia; the French public inflamed by the dispatch.',
      what='Bismarck <b>edited the Ems telegram</b> to make an exchange between the king and a French envoy sound insulting, provoking <b>France to declare war</b> in 1870. The German states united behind Prussia, and at <b>Sedan</b> the French army and <b>Napoleon III were captured</b>.',
      crux='He used <b>a single edited document</b> to trigger a war on his terms — with his enemy cast as the aggressor and all Germany his ally.',
      conseq='Victory over France removed the last barrier to a united German Empire — which was proclaimed on French soil.',
      matters='Wars can be engineered by controlling how a provocation is perceived — the aggressor is often the one made to look like one.'),
]

# ==================================================================  PHASE 4 — THE IRON CHANCELLOR
PHASE_EMPIRE = [
    E('empire', '1871', 'The German Empire proclaimed at Versailles', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'In the Hall of Mirrors at Versailles — in the palace of the defeated French — the German princes proclaim King Wilhelm I of Prussia as German Emperor, uniting Germany into a single empire under Prussian leadership, with Bismarck as its all-powerful Chancellor.',
      svg_row('A nation founded on conquered ground', [
          {'n': 1, 'label': 'Hall of Mirrors, Jan 1871', 'sub': 'the Empire proclaimed in defeated France’s palace', 'color': '#44403c'},
          {'n': 2, 'label': 'Wilhelm I made Kaiser', 'sub': 'Prussia’s king becomes German Emperor', 'color': '#a16207'},
          {'n': 3, 'label': 'Bismarck, Chancellor', 'sub': 'the architect of unity now its master', 'color': '#166534'},
      ], edge_labels=['then', 'with'], takeaway='He achieved in a decade what liberals had failed to do in generations — a united Germany, built by force from above.', accent=AC),
      bg='Three wars in seven years — against Denmark, Austria and France — had brought the German states together under Prussian leadership.',
      people='<b>Wilhelm I</b>, proclaimed Kaiser; the German princes; Bismarck, the architect and now Chancellor of the new empire.',
      what='On <b>18 January 1871</b>, in the <b>Hall of Mirrors at Versailles</b>, Wilhelm I was proclaimed <b>German Emperor</b>, completing the <b>unification of Germany</b> under Prussia, with Bismarck as <b>Imperial Chancellor</b>.',
      crux='He had <b>united Germany from above by force and diplomacy</b> — a conservative achievement of what liberal nationalism had failed to win.',
      conseq='A powerful new German Empire now sat at the center of Europe, transforming the balance of power.',
      matters='The unification of Germany created a great power that reshaped world history — achieved not by revolution but by realpolitik.'),

    E('constitution', '1871–1890', 'The master manipulator — power behind a democratic mask', ['POLITICS', 'REFORM'],
      'Bismarck designs an empire that looks partly democratic — with an elected Reichstag chosen by universal male suffrage — but keeps real power with the Kaiser and himself, then dominates the parliament for two decades by playing its parties off against one another with consummate skill.',
      svg_stack('Democracy’s form, autocracy’s substance', [
          {'n': 1, 'label': 'An elected Reichstag', 'sub': 'universal male suffrage — a democratic facade', 'color': '#44403c'},
          {'n': 2, 'label': 'Real power kept above', 'sub': 'the Kaiser and Chancellor control army and policy', 'color': '#a16207'},
          {'n': 3, 'label': 'Divide and rule', 'sub': 'plays the parties against each other for 20 years', 'color': '#166534'},
      ], takeaway='He granted the forms of democracy while keeping its substance — mastering the parliament rather than obeying it.', accent=AC),
      bg='To bind the new empire together and outflank the liberals, Bismarck crafted a constitution that combined popular elements with strong monarchical control.',
      people='the Reichstag parties (liberals, Catholics, socialists, conservatives); the Kaiser; Bismarck, orchestrating them all.',
      what='He created a <b>Reichstag elected by universal male suffrage</b> but with limited real power, keeping control of the <b>army, foreign policy and the Chancellorship</b> in the crown’s hands — and dominated the parliament by <b>shifting alliances</b> among its parties.',
      crux='He gave just enough <b>democratic form to legitimise the state</b> while retaining the <b>substance of power</b> — and out-maneuvered every faction.',
      conseq='The system worked while Bismarck ran it, but concentrated dangerous power in a Chancellor and Kaiser with few checks.',
      matters='The appearance of democracy can coexist with its absence — the skilled manipulator rules through institutions rather than under them.'),

    E('kulturkampf', '1871–1878', 'The Kulturkampf — a war on the Church that fails', ['POLITICS', 'DEFEAT'],
      'Bismarck launches a “struggle for civilisation” against the Catholic Church, whose loyalty to Rome he distrusts — expelling the Jesuits, arresting bishops, and battling Catholic influence — but the campaign backfires, strengthening the Catholic Centre Party, and the pragmatic Bismarck eventually retreats and makes peace.',
      svg_stack('A rare Bismarck defeat', [
          {'n': 1, 'label': 'War on the Catholic Church', 'sub': 'distrusts Catholics’ loyalty to Rome over the state', 'color': '#44403c'},
          {'n': 2, 'label': 'Repression backfires', 'sub': 'jailing bishops strengthens the Catholic Centre Party', 'color': '#b91c1c'},
          {'n': 3, 'label': 'He retreats', 'sub': 'the pragmatist cuts his losses and makes peace', 'color': '#a16207'},
      ], takeaway='Even Bismarck overreached — but his genius included knowing when to abandon a losing fight.', accent=AC),
      bg='Bismarck distrusted the <b>Catholic Church’s</b> transnational loyalty to the Pope as a rival to the new German state, especially among Catholic minorities.',
      people='the Catholic clergy and <b>Centre Party</b>; the Pope; the German Catholics who rallied against persecution.',
      what='In the <b>Kulturkampf</b> (“culture struggle”) of the 1870s, Bismarck expelled the Jesuits, arrested clergy and attacked Catholic institutions — but the repression <b>strengthened the Catholic Centre Party</b>, and he eventually <b>retreated and reconciled</b> with the Church.',
      crux='He misjudged the resilience of faith and community — but, as a realist, <b>cut his losses</b> rather than persist in a failing policy.',
      conseq='The failure taught him to seek new allies; he soon turned his repressive energies against the socialists instead.',
      matters='Knowing when you are beaten is part of strategy — the wise abandon a losing fight rather than double down on it.'),

    E('welfare', '1878–1889', 'Stick and carrot — banning socialists, inventing the welfare state', ['REFORM', 'POLITICS', 'TURNING POINT'],
      'Facing the rise of socialism, Bismarck attacks it with both hands — outlawing the Social Democratic Party, then stealing its thunder by creating the world’s first modern welfare state, with pioneering health, accident and old-age insurance designed to bind workers to the state rather than the revolution.',
      svg_compare('Repression and reform together',
        {'head': 'The stick', 'color': '#b91c1c', 'items': ['Anti-Socialist Laws, 1878', 'bans the Social Democratic Party', 'suppresses socialist press and meetings']},
        {'head': 'The carrot', 'color': '#166534', 'items': ['health insurance, 1883', 'accident insurance, 1884', 'old-age pensions, 1889']},
        'He crushed the socialists with one hand and adopted their popular demands with the other.',
        'To defeat a movement, he co-opted its best ideas — inventing the welfare state to undercut revolution.', AC),
      bg='Industrialisation had created a large working class and a growing <b>socialist movement</b> that Bismarck saw as a threat to the state.',
      people='the <b>Social Democratic Party</b> he banned; the German workers he sought to win over; the state that gained their loyalty.',
      what='Bismarck passed the <b>Anti-Socialist Laws (1878)</b> banning the socialist party, then introduced the world’s first <b>social insurance system</b> — <b>health (1883), accident (1884) and old-age pensions (1889)</b> — to win workers’ loyalty to the state.',
      crux='He combined <b>repression with co-optation</b> — outlawing socialism while adopting its popular reforms to steal its appeal.',
      conseq='He invented the <b>modern welfare state</b>, a model copied worldwide, though socialism kept growing despite the ban.',
      matters='The shrewdest way to defeat a movement can be to adopt its most popular demands — Bismarck fought socialism by inventing social insurance.'),
]

# ==================================================================  PHASE 5 — THE JUGGLER
PHASE_END = [
    E('alliances', '1871–1890', 'The juggler of five balls — keeping the peace', ['POLITICS', 'TRIUMPH'],
      'Having made Germany by war, Bismarck spends his last two decades preventing one — building an intricate web of alliances to isolate a vengeful France and avoid the two-front war that is his nightmare, holding the peace of Europe together through sheer diplomatic virtuosity.',
      svg_stack('A web of alliances to keep the peace', [
          {'n': 1, 'label': 'Isolate France', 'sub': 'deny vengeful France any great-power ally', 'color': '#44403c'},
          {'n': 2, 'label': 'Bind Austria and Russia', 'sub': 'the Dual Alliance (1879), the League of Three Emperors', 'color': '#a16207'},
          {'n': 3, 'label': 'The Reinsurance Treaty, 1887', 'sub': 'a secret deal keeps Russia from France', 'color': '#166534'},
      ], takeaway='The warmaker became Europe’s peacekeeper — juggling rival alliances to prevent the coalition he feared.', accent=AC),
      bg='After 1871 a united Germany was surrounded by great powers and haunted by a France thirsting for revenge. Bismarck’s goal shifted from making war to <b>preventing</b> it.',
      people='<b>France</b>, to be isolated; <b>Austria-Hungary</b> and <b>Russia</b>, to be bound to Germany; the other powers he balanced.',
      what='Bismarck built an intricate system — the <b>Dual Alliance with Austria (1879)</b>, the <b>League of the Three Emperors</b>, the <b>Triple Alliance (1882)</b>, and the secret <b>Reinsurance Treaty with Russia (1887)</b> — all to <b>isolate France</b> and avoid a two-front war.',
      crux='He grasped that a strong, satisfied Germany must now <b>keep the peace and prevent coalitions</b> — “the nightmare of coalitions” was his obsession.',
      conseq='For two decades his diplomacy kept Europe’s great powers from war — a peace that depended on his personal skill.',
      matters='The greatest statecraft can lie in preventing war, not waging it — but a peace resting on one man’s genius is fragile.'),

    E('dismissal', '1888–1898', '“Dropping the pilot” — dismissal and the road to ruin', ['POLITICS', 'DEFEAT', 'DEATH'],
      'A new young Kaiser, Wilhelm II, ambitious and impatient, clashes with the aging Chancellor and dismisses him in 1890 — and without Bismarck’s restraining hand, Germany lets his careful alliances lapse, France and Russia unite, and the two-front nightmare he spent his life preventing draws steadily toward the catastrophe of 1914.',
      svg_stack('The pilot dropped, the ship toward the rocks', [
          {'n': 1, 'label': 'Wilhelm II clashes with him', 'sub': 'a young, headstrong Kaiser wants his own rule', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Dismissed, 1890', 'sub': '“Dropping the pilot” — Bismarck forced out', 'color': '#44403c'},
          {'n': 3, 'label': 'His system unravels', 'sub': 'Russia lost; France-Russia unite; the road to 1914', 'color': '#78350f'},
      ], takeaway='The system held only while its architect ran it — his fall began Germany’s drift toward the war he had always feared.', accent=AC),
      bg='In 1888 the young, headstrong <b>Wilhelm II</b> became Kaiser, determined to rule personally and impatient with the old Chancellor’s dominance.',
      people='<b>Kaiser Wilhelm II</b>, who dismissed him; the successors who let his treaties lapse; France and Russia, soon allied.',
      what='After clashes over policy and power, Wilhelm II <b>dismissed Bismarck in 1890</b> (immortalised in the cartoon “Dropping the Pilot”). Germany then let the <b>Reinsurance Treaty lapse</b>; <b>France and Russia allied</b>, creating the two-front encirclement Bismarck had dreaded. He died, embittered, in <b>1898</b>.',
      crux='His diplomatic system <b>depended on his own genius</b> — once he was gone, lesser hands dismantled it, unleashing the dangers he had contained.',
      conseq='The unraveling of Bismarck’s alliances set Europe on the path to the First World War, sixteen years after his death.',
      matters='A structure built on one person’s brilliance rarely survives them — Bismarck kept the peace, but could not institutionalise it.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Otto von Bismarck was the supreme practitioner of realpolitik — the art of power stripped of sentiment. A wild Junker turned Iron Chancellor, he unified Germany in a single decade through three engineered wars and “blood and iron,” then spent his remaining twenty years as Europe’s master juggler, building an intricate web of alliances to keep the peace he had won. He also, to outflank socialism, invented the modern welfare state. He is the ultimate study in <b>power over principle, knowing when to stop, and the fragility of a system that rests on one person’s genius.</b></p>
<div class="ov-quote">“The great questions of the day will be decided not by speeches and majority votes… but by blood and iron.”<span>— Bismarck, 1862</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A wild Junker finds his voice defending the crown in 1848 → learns realpolitik as a diplomat → is called in a crisis to be Minister-President → governs by “blood and iron” against parliament → unifies Germany through wars with Denmark, Austria and France → proclaims the Empire at Versailles and rules as Iron Chancellor → masters the Reichstag, fails in the Kulturkampf, and invents the welfare state to fight socialism → keeps the European peace with a web of alliances → and is “dropped” by a young Kaiser, after which his system unravels toward 1914.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🇩🇪</div><h4>He made Germany</h4><p>Unified the German states into a great power in a single decade.</p></div>
  <div class="ov-card"><div class="i">♟️</div><h4>Realpolitik</h4><p>The master of power politics — interest and force over ideology and sentiment.</p></div>
  <div class="ov-card"><div class="i">🤝</div><h4>The welfare state</h4><p>Invented modern social insurance — to defeat socialism by co-opting it.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>Peace by balance</h4><p>Kept Europe at peace for 20 years — a system too dependent on him to survive him.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Junker</b><small> 1815–1862</small><p>Wild youth, 1848, and an apprenticeship in power.</p></div>
  <div><b>2 · Blood and Iron</b><small> 1862–1866</small><p>Called in a crisis; governing against parliament.</p></div>
  <div><b>3 · The Wars</b><small> 1864–1871</small><p>Denmark, Austria and France — unification by force.</p></div>
  <div><b>4 · The Iron Chancellor</b><small> 1871–1889</small><p>Empire, Kulturkampf, and the welfare state.</p></div>
  <div><b>5 · The Juggler</b><small> 1871–1898</small><p>Keeping the peace — and being dropped.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Wilhelm I', 'role': 'king / Kaiser', 'color': '#a16207',
     'bio': 'King of Prussia who appointed Bismarck in the 1862 crisis and became German Emperor in 1871; he trusted Bismarck almost completely for nearly three decades.',
     'rel': 'The monarch whose trust gave Bismarck his power.'},
    {'name': 'Helmuth von Moltke', 'role': 'army chief', 'color': '#166534',
     'bio': 'The brilliant Prussian chief of staff whose reformed, railway-mobilised army won the wars of unification that Bismarck’s diplomacy set up.',
     'rel': 'The general whose victories realised Bismarck’s designs.'},
    {'name': 'Napoleon III', 'role': 'adversary', 'color': '#b91c1c',
     'bio': 'Emperor of France, goaded into the 1870 war by the Ems Dispatch and captured at Sedan — his fall clearing the way for German unification.',
     'rel': 'The rival Bismarck maneuvered into a losing war.'},
    {'name': 'Wilhelm II', 'role': 'the young Kaiser', 'color': '#78350f',
     'bio': 'The ambitious young emperor who clashed with the aging Chancellor and dismissed him in 1890, then let his careful alliance system unravel.',
     'rel': 'The Kaiser who “dropped the pilot” and undid his work.'},
    {'name': 'Albrecht von Roon', 'role': 'war minister / ally', 'color': '#44403c',
     'bio': 'The Prussian war minister and Bismarck’s close ally, who reformed the army and recommended Bismarck to the king in the 1862 crisis.',
     'rel': 'The ally who helped bring him to power.'},
]

KEY_EVENTS = [
    ('1815', 'Bismarck born', 'Into the Prussian Junker aristocracy.'),
    ('1862', 'Minister-President', 'Called in the army-budget crisis.'),
    ('1862', '“Blood and iron” speech', 'Governs against parliament.'),
    ('1864', 'Danish War', 'Seizes Schleswig-Holstein with Austria.'),
    ('1866', 'Austro-Prussian War', 'Königgrätz; a lenient peace.'),
    ('1870', 'Ems Dispatch; war with France', 'Sedan; Napoleon III captured.'),
    ('1871', 'German Empire proclaimed', 'At Versailles; Bismarck Chancellor.'),
    ('1878–89', 'Anti-Socialist Laws & welfare', 'Bans socialism; invents social insurance.'),
    ('1890', 'Dismissed by Wilhelm II', '“Dropping the pilot.”'),
    ('1898', 'Death of Bismarck', 'His alliance system already unraveling.'),
]

MASTER = [
    {'year': '1815', 'age': 'born', 'phase': 'The Junker', 'title': 'Born a Junker', 'desc': 'Prussian aristocracy.'},
    {'year': '1862', 'age': 'age 47', 'phase': 'Blood and Iron', 'title': 'Minister-President', 'desc': 'Power in a crisis.'},
    {'year': '1866', 'age': 'age 51', 'phase': 'The Wars', 'title': 'Beats Austria', 'desc': 'Leads northern Germany.'},
    {'year': '1871', 'age': 'age 56', 'phase': 'Iron Chancellor', 'title': 'German Empire', 'desc': 'Unification complete.'},
    {'year': '1883', 'age': 'age 68', 'phase': 'Iron Chancellor', 'title': 'Welfare state', 'desc': 'First social insurance.'},
    {'year': '1890', 'age': 'age 75', 'phase': 'The Juggler', 'title': 'Dismissed', 'desc': 'The pilot dropped.'},
]

SOURCES = [
    ('Britannica — Otto von Bismarck', 'https://www.britannica.com/biography/Otto-von-Bismarck'),
    ('World History Encyclopedia — Otto von Bismarck', 'https://www.worldhistory.org/Otto_von_Bismarck/'),
    ('Britannica — Unification of Germany', 'https://www.britannica.com/event/unification-of-Germany'),
    ('Britannica — Franco-German War', 'https://www.britannica.com/event/Franco-German-War'),
    ('Wikipedia — Otto von Bismarck', 'https://en.wikipedia.org/wiki/Otto_von_Bismarck'),
]

def build_meta():
    return {
        'pid': 'gm-bismarck.html', 'kind': 'man', 'emoji': '🦅', 'accent': AC,
        'name': 'Otto von Bismarck', 'years': '1815–1898', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Iron Chancellor — master of realpolitik who unified Germany by blood and iron, invented the welfare state, and kept Europe at peace for twenty years through sheer diplomatic genius.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Junker', 'type': 'timeline',
             'intro': 'A wild Junker with no obvious path to power finds his voice defending the monarchy in the 1848 revolutions, then learns hard-headed realpolitik through a decade as a diplomat among the great powers.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · Blood and Iron', 'type': 'timeline',
             'intro': 'Called in as a last resort during a constitutional crisis, he governs against parliament by “blood and iron” — proving that a determined executive backed by the army can override liberal principle.', 'events': PHASE_POWER},
            {'id': 'wars', 'label': '3 · The Wars', 'type': 'timeline',
             'intro': 'In a single decade he unifies Germany through three engineered wars — against Denmark, Austria and France — each a masterclass in provocation, victory, and knowing exactly when to stop.', 'events': PHASE_WARS},
            {'id': 'empire', 'label': '4 · The Iron Chancellor', 'type': 'timeline',
             'intro': 'He proclaims the Empire at Versailles and rules as Chancellor — mastering the Reichstag, failing in the Kulturkampf, and inventing the modern welfare state to outflank the rising socialists.', 'events': PHASE_EMPIRE},
            {'id': 'end', 'label': '5 · The Juggler', 'type': 'timeline',
             'intro': 'The warmaker becomes Europe’s peacekeeper, juggling an intricate web of alliances to isolate France and prevent a two-front war — until a young Kaiser drops the pilot, and his system unravels toward 1914.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; Bismarck’s own memoirs are self-serving and read critically by historians.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
