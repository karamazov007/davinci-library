# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Jawaharlal Nehru.
The privileged barrister who became Gandhi’s heir and the chief architect of a modern, secular, democratic India."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#c2410c'  # India saffron

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING
PHASE_MAKING = [
    E('origins', '1889–1905', 'A gilded Allahabad childhood', ['RISE', 'ORIGINS'],
      'Born into wealth and privilege as the pampered only son of Motilal Nehru, one of India’s richest barristers, young Jawaharlal grows up in the palatial Anand Bhavan with English tutors, an Anglicised household and every advantage — a boyhood so comfortable it leaves him, by his own account, a spoilt and rather lonely child of two worlds.',
      svg_row('Privilege as the starting point', [
          {'n': 1, 'label': 'Born Allahabad, 1889', 'sub': 'son of the wealthy barrister Motilal Nehru', 'color': '#c2410c'},
          {'n': 2, 'label': 'The palatial Anand Bhavan', 'sub': 'English governesses and private tutors', 'color': '#a16207'},
          {'n': 3, 'label': 'A child of two worlds', 'sub': 'Kashmiri Brahmin roots, Anglicised upbringing', 'color': '#166534'},
      ], edge_labels=['in', 'making'], takeaway='He began at the very top — a cosseted, Anglicised childhood that gave him everything except a cause of his own.', accent=AC),
      bg='<b>Jawaharlal Nehru</b> was born in 1889 in Allahabad to <b>Motilal Nehru</b>, a Kashmiri Brahmin who had risen to be one of the wealthiest lawyers in India.',
      people='his father <b>Motilal Nehru</b>; his mother Swarup Rani; the English governesses and tutors of the Nehru household.',
      what='Nehru grew up in luxury at the family mansion <b>Anand Bhavan</b>, the adored only son, tutored privately in English and steeped in a household that mixed <b>Kashmiri Brahmin heritage with Western manners</b>.',
      crux='His outlook was formed by <b>privilege and a dual identity</b> — Indian by blood, English by education — a tension he would spend his life trying to resolve.',
      conseq='This cosmopolitan, comfortable start sent him to England for schooling and set the pattern of a Westernised elite Indian.',
      matters='Formation shapes vision — the pampered cosmopolitan child became a leader who could speak to both a modern world and an ancient nation.'),

    E('england', '1905–1912', 'Harrow, Cambridge and the Inner Temple', ['RISE', 'EDUCATION'],
      'Sent to England at fifteen, Nehru passes through Harrow, reads natural sciences at Trinity College, Cambridge, and qualifies as a barrister at the Inner Temple — absorbing Fabian socialism, science and English liberalism, and returning home a polished, faintly restless product of the very empire he would come to fight.',
      svg_stack('An English education, an Indian conscience', [
          {'n': 1, 'label': 'Harrow School, 1905', 'sub': 'sent to England at fifteen', 'color': '#c2410c'},
          {'n': 2, 'label': 'Trinity College, Cambridge', 'sub': 'reads natural sciences; meets Fabian socialism', 'color': '#a16207'},
          {'n': 3, 'label': 'Barrister, Inner Temple, 1912', 'sub': 'called to the bar; returns to India', 'color': '#166534'},
      ], takeaway='Seven years in England gave him science, socialism and doubt — the intellectual toolkit of the modernist he became.', accent=AC),
      bg='At fifteen Nehru was sent to England, following the path of the Anglicised Indian elite through its most prestigious schools.',
      people='his Harrow and Cambridge circles; the Fabian socialists and liberal thinkers he read; his father, financing it all.',
      what='Nehru studied at <b>Harrow</b>, took a degree in <b>natural sciences at Trinity College, Cambridge</b>, and was called to the bar at the <b>Inner Temple in 1912</b>, absorbing science, Fabian socialism and English liberalism.',
      crux='He emerged a <b>scientific, secular, socialist modernist</b> — his lifelong faith in reason, planning and progress was forged in England.',
      conseq='He returned to India in 1912 a qualified barrister but without real direction, drifting until a cause found him.',
      matters='Ideas absorbed young endure — Nehru’s English education made him the great modernist of Indian politics, for better and worse.'),

    E('awakening', '1912–1919', 'A restless barrister is radicalised', ['RISE', 'TURNING POINT'],
      'Back home, Nehru drifts through a desultory law practice, marries Kamala Kaul and welcomes his daughter Indira — but it is the horror of the 1919 Jallianwala Bagh massacre, where British troops gun down hundreds of unarmed Indians at Amritsar, that finally shatters his faith in Britain and turns the comfortable lawyer toward the freedom struggle.',
      svg_row('From drift to fury', [
          {'n': 1, 'label': 'A listless law practice', 'sub': 'restless, unfulfilled, marries Kamala 1916', 'color': '#a16207'},
          {'n': 2, 'label': 'Jallianwala Bagh, 1919', 'sub': 'troops massacre unarmed Indians at Amritsar', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Faith in Britain shattered', 'sub': 'the lawyer turns to the freedom cause', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='The Amritsar massacre killed his faith in the Raj — and gave the aimless barrister the cause that would define his life.', accent=AC),
      bg='Returning to India, Nehru found law dull and life aimless; he married <b>Kamala Kaul</b> in 1916, and their daughter <b>Indira</b> was born in 1917.',
      people='his wife <b>Kamala</b>; his infant daughter <b>Indira</b>; the victims of Amritsar; General Dyer, who ordered the firing.',
      what='After years of restless drift, Nehru was radicalised by the <b>Jallianwala Bagh massacre of 1919</b>, when British troops killed hundreds of unarmed civilians at Amritsar, destroying his residual faith in British rule.',
      crux='A <b>single atrocity converted a privileged loyalist into a nationalist</b> — the personal met the political and set his course.',
      conseq='Primed for rebellion, he was ready when Gandhi launched mass non-violent resistance the following year.',
      matters='Injustice radicalises — the massacre that shamed the Empire pushed a generation, and Nehru with it, into open revolt.'),
]

# ==================================================================  PHASE 2 — GANDHI’S DISCIPLE
PHASE_DISCIPLE = [
    E('gandhi', '1920–1922', 'Finding Gandhi — discipline and self-denial', ['POLITICS', 'TURNING POINT'],
      'Nehru falls under the spell of Mohandas Gandhi, throwing off his Western luxuries to join the Non-Cooperation movement — abandoning his law practice, donning khadi, courting arrest and going to prison for the first time — binding himself to a spiritual mentor whose methods he adored even as his own mind stayed resolutely modern and secular.',
      svg_stack('The making of a disciple', [
          {'n': 1, 'label': 'Gandhi takes command, 1920', 'sub': 'launches mass Non-Cooperation', 'color': '#c2410c'},
          {'n': 2, 'label': 'Nehru sheds his old life', 'sub': 'abandons law and luxury; dons khadi', 'color': '#a16207'},
          {'n': 3, 'label': 'First imprisonment, 1921', 'sub': 'jail becomes the badge of the cause', 'color': '#166534'},
      ], takeaway='He gave himself to Gandhi body and soul — the privileged barrister remade as a khadi-clad servant of the nation.', accent=AC),
      bg='In 1920 Gandhi launched the <b>Non-Cooperation movement</b>, calling Indians to boycott British institutions through non-violent mass action.',
      people='<b>Mohandas Gandhi</b>, his mentor; his father <b>Motilal</b>, who joined the cause; the Congress volunteers he now led.',
      what='Nehru embraced Gandhi, <b>gave up his law practice and Western comforts</b>, took to homespun khadi, plunged into organising, and was <b>jailed for the first time in 1921</b>.',
      crux='He accepted Gandhi as <b>spiritual and political master</b> while privately keeping his own rationalist, socialist convictions — a lifelong creative tension.',
      conseq='Prison and self-denial became the rhythm of his life, and he rose fast in the Congress hierarchy.',
      matters='Great movements need both saints and organisers — Nehru gave Gandhi’s moral revolution its modern, secular political brain.'),

    E('socialist', '1926–1928', 'Europe, the USSR and the turn to socialism', ['POLITICS', 'IDEAS'],
      'Travelling through Europe and the Soviet Union in the mid-1920s, Nehru is captivated by socialism and Marxist analysis, coming to see mass poverty and economic exploitation — not merely foreign rule — as India’s deepest problems, and setting himself apart from Gandhi’s spiritual, village-centred vision with a modern creed of science, industry and planning.',
      svg_compare('Two visions of a free India', {
          'head': 'Nehru the modernist', 'color': '#c2410c', 'items': [
              'Science, industry and heavy machinery',
              'Socialism and central economic planning',
              'A secular, centralised modern state']},
          {'head': 'Gandhi the moralist', 'color': '#166534', 'items': [
              'Village self-rule and the spinning wheel',
              'Trusteeship and simple living',
              'Moral and spiritual regeneration']},
      verdict='Devoted allies who disagreed on almost everything about the future they were building.',
      takeaway='Nehru revered Gandhi the man while rejecting Gandhi’s economics — modernity versus the village would shape independent India.', accent=AC),
      bg='In 1926–27 Nehru toured Europe and attended the Brussels Congress of oppressed nationalities, then visited the <b>Soviet Union</b> on its tenth anniversary.',
      people='the European socialists and anti-imperialists he met; the Soviet planners he admired; <b>Gandhi</b>, whose economics he rejected.',
      what='Nehru returned a convinced <b>socialist</b>, viewing <b>poverty and economic exploitation</b> as India’s root ills and championing <b>industrialisation and planning</b> against Gandhi’s spiritual, village-based ideal.',
      crux='He recast the freedom struggle as a fight for <b>social and economic justice</b>, not just political independence — a modernist against a moralist.',
      conseq='This socialist, industrial vision would become the blueprint for the economy he built as prime minister.',
      matters='What you free a nation FOR matters as much as freeing it — Nehru’s socialism set India’s development path for decades.'),

    E('purnaswaraj', '1929–1930', 'President at Lahore — the demand for full freedom', ['POLITICS', 'TRIUMPH'],
      'Made Congress President at the historic Lahore session of 1929, the young Nehru moves the epochal Purna Swaraj resolution demanding complete independence — not dominion status — and on 26 January 1930 the tricolour is unfurled on the banks of the Ravi and Independence Day is proclaimed, marking his emergence as the coming leader of the movement.',
      svg_row('The demand crystallises', [
          {'n': 1, 'label': 'Congress President, 1929', 'sub': 'chosen to lead at the Lahore session', 'color': '#c2410c'},
          {'n': 2, 'label': 'Purna Swaraj resolution', 'sub': 'complete independence, not dominion status', 'color': '#a16207'},
          {'n': 3, 'label': 'Independence Day, 26 Jan 1930', 'sub': 'tricolour raised on the banks of the Ravi', 'color': '#166534'},
      ], edge_labels=['moves', 'so'], takeaway='At Lahore he made complete independence the movement’s goal — and marked himself as Gandhi’s chosen heir.', accent=AC),
      bg='By 1929 the Congress debated whether to accept dominion status or demand outright independence. Gandhi backed the youthful Nehru for the presidency.',
      people='<b>Gandhi</b>, his sponsor; his father <b>Motilal</b>, the outgoing generation; the Congress that rallied to the demand.',
      what='As <b>Congress President at Lahore (1929)</b>, Nehru moved the <b>Purna Swaraj (complete independence) resolution</b>; on <b>26 January 1930</b> the flag was raised on the Ravi and the first Independence Day declared.',
      crux='He turned the goal from limited self-government into <b>total freedom</b> — and became the young, radical face of the struggle.',
      conseq='The date of 26 January was later chosen for the Republic; Nehru was now the heir apparent to Gandhi.',
      matters='Setting the maximal goal changed the struggle — Purna Swaraj made anything less than full freedom unacceptable.'),
]

# ==================================================================  PHASE 3 — PRISON AND THE ROAD TO FREEDOM
PHASE_ROAD = [
    E('prisons', '1930–1945', 'The prison years — and the books they produced', ['POLITICS', 'IDEAS', 'TRAGEDY'],
      'Across the freedom struggle Nehru is jailed nine times and spends roughly nine years behind bars — using the solitude to write his luminous Autobiography, Glimpses of World History and, at Ahmednagar Fort, The Discovery of India — even as tragedy strikes with the death of his wife Kamala in 1936, deepening the reflective, historical cast of his mind.',
      svg_stack('Prison as study and crucible', [
          {'n': 1, 'label': 'Nine jailings, ~9 years', 'sub': 'imprisonment becomes a way of life', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The prison books', 'sub': 'Autobiography; The Discovery of India, 1944', 'color': '#c2410c'},
          {'n': 3, 'label': 'Kamala dies, 1936', 'sub': 'personal grief amid the struggle', 'color': '#78350f'},
      ], takeaway='Jail made him a writer and a thinker — the cells that held him produced the books that defined his idea of India.', accent=AC),
      bg='Through the 1930s and early 1940s, civil disobedience meant repeated imprisonment for the Congress leadership.',
      people='his wife <b>Kamala</b>, who died in 1936; his daughter <b>Indira</b>; the fellow prisoners of the movement.',
      what='Nehru was <b>imprisoned nine times for a total of about nine years</b>, writing his <b>Autobiography</b>, <b>Glimpses of World History</b> and <b>The Discovery of India</b> (Ahmednagar Fort, 1944) in his cells; Kamala died in 1936.',
      crux='He turned <b>captivity into contemplation</b> — building the historical, humane, secular idea of India that he would later govern by.',
      conseq='These writings made him the intellectual voice of Indian nationalism and shaped his vision of the nation-to-be.',
      matters='Adversity can be generative — Nehru’s prison books remain foundational meditations on what India is and could become.'),

    E('quitindia', '1942–1945', 'Quit India — the final confrontation', ['POLITICS', 'BATTLE'],
      'When Gandhi launches the Quit India movement in 1942 demanding an immediate end to British rule, the Raj responds by jailing the entire Congress leadership, and Nehru spends nearly three years in prison during the war — the last and longest of his confinements — as a exhausted, war-drained Britain edges toward the exit from India.',
      svg_stack('The last great push', [
          {'n': 1, 'label': 'Quit India, 1942', 'sub': 'Gandhi demands the British leave now', 'color': '#c2410c'},
          {'n': 2, 'label': 'Leadership jailed en masse', 'sub': 'Nehru imprisoned until 1945', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A war-drained Raj retreats', 'sub': 'Britain can no longer hold India', 'color': '#166534'},
      ], takeaway='The war broke Britain’s grip — Quit India was the last confrontation, and the endgame of the Raj had begun.', accent=AC),
      bg='With the Second World War raging and India dragged into it without consent, the Congress launched a final mass movement.',
      people='<b>Gandhi</b>, who called the movement; the imprisoned Congress leaders; the wartime British government of Churchill.',
      what='After the <b>Quit India resolution of August 1942</b>, the British jailed the entire Congress leadership; Nehru remained <b>imprisoned until 1945</b>, his longest single confinement.',
      crux='The movement showed British rule was <b>ungovernable without consent</b>, even as war-exhausted Britain lost the will and means to hold on.',
      conseq='By 1945–46 Britain, weakened by war, opened negotiations that led swiftly toward independence.',
      matters='Empires end when they can no longer be afforded — the war and Quit India together made Indian freedom inevitable.'),

    E('tryst', '1946–1947', 'Tryst with Destiny — first Prime Minister', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'Heading the interim government from 1946, Nehru presides over the agonising birth of a nation — independence won but the subcontinent torn by the bloody Partition into India and Pakistan — and at the stroke of midnight on 15 August 1947 delivers his immortal "Tryst with Destiny" address as free India’s first Prime Minister, a role he will hold until his death.',
      svg_row('Freedom, and its terrible price', [
          {'n': 1, 'label': 'Interim government, 1946', 'sub': 'Nehru leads as freedom nears', 'color': '#c2410c'},
          {'n': 2, 'label': 'Partition’s bloodshed', 'sub': 'the subcontinent split; mass violence', 'color': '#b91c1c'},
          {'n': 3, 'label': '“Tryst with Destiny,” 1947', 'sub': 'first PM at the midnight of freedom', 'color': '#166534'},
      ], edge_labels=['amid', 'to'], takeaway='At the stroke of midnight he spoke for a nation reborn — and inherited a country bleeding from its own partition.', accent=AC),
      bg='In 1946 Nehru headed the interim government; independence was agreed, but at the price of <b>partitioning</b> the subcontinent along religious lines.',
      people='<b>Gandhi</b>, anguished by Partition; <b>Sardar Patel</b>, his deputy; <b>Jinnah</b> of the new Pakistan; Lord Mountbatten.',
      what='Nehru became <b>free India’s first Prime Minister</b>, delivering the celebrated <b>"Tryst with Destiny" speech at midnight on 15 August 1947</b>, even as <b>Partition</b> unleashed massacres and vast refugee flows.',
      crux='He took power in a moment of <b>soaring hope and terrible carnage</b> — the triumph of freedom shadowed by the tragedy of Partition.',
      conseq='Gandhi was assassinated in January 1948, leaving Nehru the paramount leader to build the new republic largely alone.',
      matters='Nations are born in blood as well as joy — Nehru’s founding task was to hold a wounded, plural country together.'),
]

# ==================================================================  PHASE 4 — BUILDING MODERN INDIA
PHASE_BUILD = [
    E('secular', '1947–1950', 'A secular democratic republic', ['POLITICS', 'REFORM', 'TRIUMPH'],
      'Nehru sets out to build India as a secular, democratic republic — anchoring it in a Constitution that takes effect on 26 January 1950 with universal adult suffrage, pushing through the Hindu Code Bills to reform family law and advance women’s rights, and, with Sardar Patel, integrating hundreds of princely states — while the unresolved accession of Kashmir sparks the first war with Pakistan.',
      svg_stack('Founding the republic', [
          {'n': 1, 'label': 'Constitution in force, 1950', 'sub': 'a secular republic; universal suffrage', 'color': '#c2410c'},
          {'n': 2, 'label': 'Reform and integration', 'sub': 'Hindu Code Bills; princely states absorbed', 'color': '#a16207'},
          {'n': 3, 'label': 'The Kashmir problem', 'sub': 'accession sparks the 1947–48 war', 'color': '#b91c1c'},
      ], takeaway='He laid democratic, secular foundations that held — even as Kashmir became the wound that would not heal.', accent=AC),
      bg='Independent India had to be constituted from scratch: a plural, largely poor society of many faiths, languages and hundreds of princely states.',
      people='<b>B. R. Ambedkar</b>, drafting the Constitution; <b>Sardar Patel</b>, integrating the states; the citizens of the new republic.',
      what='Nehru anchored a <b>secular democracy</b> in the <b>Constitution of 26 January 1950</b> with universal suffrage, advanced the <b>Hindu Code Bills</b> and women’s rights, and (with Patel) integrated the princely states, while <b>Kashmir</b>’s accession triggered war with Pakistan.',
      crux='He committed India to <b>secularism, democracy and equal citizenship</b> at a time when many predicted it would fracture or fall to dictatorship.',
      conseq='India held together as a functioning democracy; Kashmir remained a running sore and a source of repeated conflict.',
      matters='Institutions outlast leaders — Nehru’s insistence on secular democracy is his most durable and contested legacy.'),

    E('planned', '1950–1961', 'Temples of modern India — the planned economy', ['POLITICS', 'REFORM'],
      'Nehru drives industrialisation through a planned, mixed economy — creating the Planning Commission in 1950 and launching the Five-Year Plans, with the Second Plan’s push into heavy industry — and celebrates the great dams, steel plants and new institutions like the IITs as the "temples of modern India," even as critics later fault the slow "Hindu rate of growth" and a stifling bureaucratic state.',
      svg_row('Building with steel and concrete', [
          {'n': 1, 'label': 'Planning Commission, 1950', 'sub': 'the state directs development', 'color': '#c2410c'},
          {'n': 2, 'label': 'The Five-Year Plans', 'sub': 'heavy industry and public sector', 'color': '#a16207'},
          {'n': 3, 'label': '“Temples of modern India”', 'sub': 'dams, steel plants, the new IITs', 'color': '#166534'},
      ], edge_labels=['drives', 'builds'], takeaway='He bet India’s future on planning and heavy industry — a modern base built, at the cost of slow growth and red tape.', accent=AC),
      bg='Facing mass poverty and a tiny industrial base, Nehru chose a state-led, planned path between capitalism and communism.',
      people='the economist <b>P. C. Mahalanobis</b>, architect of the Second Plan; the engineers of the dams and steel mills; the planners of the state.',
      what='Nehru set up the <b>Planning Commission (1950)</b> and the <b>Five-Year Plans</b>, prioritising <b>heavy industry and the public sector</b>, and hailed the <b>Bhakra-Nangal dam, steel plants and the new IITs</b> (first at Kharagpur, 1951) as "temples of modern India."',
      crux='He believed <b>state-led planning and heavy industry</b> would lift India from poverty and secure its independence — a modernist faith in the machine.',
      conseq='India gained a industrial and scientific base and elite institutions, but also a slow-growing, over-regulated "licence-permit raj" later criticised sharply.',
      matters='Development models cast long shadows — Nehru’s planned economy built India’s modern spine but constrained its growth for decades.'),

    E('nonalign', '1954–1955', 'Non-alignment and the voice of the Third World', ['POLITICS', 'IDEAS', 'TRIUMPH'],
      'On the world stage Nehru refuses to take sides in the Cold War, championing non-alignment as a moral and independent path — articulating the Panchsheel principles of peaceful coexistence in 1954 and co-leading the landmark Bandung Conference of Afro-Asian nations in 1955 — making himself a towering global spokesman for the decolonising world, admired abroad even as some scorn his moralising.',
      svg_stack('A third path in a bipolar world', [
          {'n': 1, 'label': 'Panchsheel, 1954', 'sub': 'five principles of peaceful coexistence', 'color': '#c2410c'},
          {'n': 2, 'label': 'Bandung Conference, 1955', 'sub': 'co-leads the Afro-Asian nations', 'color': '#a16207'},
          {'n': 3, 'label': 'Voice of the Third World', 'sub': 'non-alignment as moral independence', 'color': '#166534'},
      ], takeaway='He gave newly free nations a third path between the blocs — global stature for India, and for himself a moral pulpit.', accent=AC),
      bg='As the Cold War hardened, new nations faced pressure to join one bloc or the other. Nehru insisted on independence from both.',
      people='<b>Nasser</b> of Egypt and <b>Tito</b> of Yugoslavia, fellow non-aligned leaders; <b>Zhou Enlai</b> of China, his Panchsheel partner.',
      what='Nehru championed <b>non-alignment</b>, framed the <b>Panchsheel</b> principles of peaceful coexistence (1954), and co-led the <b>Bandung Conference of 1955</b>, becoming a leading voice of the decolonising world.',
      crux='He sought <b>strategic autonomy and moral leadership</b> for India and the Third World — refusing to be a client of either superpower.',
      conseq='India punched above its weight diplomatically; the later Non-Aligned Movement grew from these foundations, though critics called it naïve.',
      matters='Small and new powers can shape the world by their stance — non-alignment gave post-colonial nations a collective voice.'),
]

# ==================================================================  PHASE 5 — SHADOWS AND LEGACY
PHASE_SHADOWS = [
    E('cracks', '1956–1961', 'Strains beneath the surface', ['POLITICS', 'TRAGEDY'],
      'Cracks open in the Nehruvian order: his non-alignment is dented when India equivocates over the Soviet crushing of Hungary in 1956; granting asylum to the Dalai Lama in 1959 after the Tibetan uprising inflames relations with China; the border simmers; and the armed liberation of Portuguese Goa in 1961, though popular at home, draws charges of hypocrisy against the apostle of non-violence.',
      svg_stack('The order begins to fray', [
          {'n': 1, 'label': 'Hungary, 1956', 'sub': 'silence on Soviet tanks dents his moral stance', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Dalai Lama asylum, 1959', 'sub': 'Tibet inflames the China border', 'color': '#c2410c'},
          {'n': 3, 'label': 'Goa liberated, 1961', 'sub': 'popular at home, called hypocrisy abroad', 'color': '#78350f'},
      ], takeaway='The moralist’s halo slipped — silence over Hungary, tension over Tibet and force in Goa exposed the gaps in his idealism.', accent=AC),
      bg='By the late 1950s the contradictions of Nehru’s idealistic foreign policy and his easy dominance at home began to show.',
      people='the <b>Dalai Lama</b>, granted refuge in 1959; <b>Zhou Enlai</b>, over the deteriorating border; the Portuguese, expelled from Goa.',
      what='India’s equivocation over the <b>Soviet crushing of Hungary (1956)</b> dented Nehru’s moral standing; asylum for the <b>Dalai Lama (1959)</b> worsened ties with China; and the <b>1961 seizure of Goa</b>, though popular, drew charges of hypocrisy.',
      crux='His high moral posture met <b>hard realities</b> — selective principle and the use of force strained the credibility of non-alignment.',
      conseq='Above all, the festering border dispute with China was drifting toward open conflict.',
      matters='Idealism is judged by consistency — the strains of these years foreshadowed the great humiliation to come.'),

    E('china1962', '1962', 'The Sino-Indian War — the great humiliation', ['POLITICS', 'BATTLE', 'DEFEAT'],
      'Nehru’s trust in Chinese friendship — the "Hindi-Chini bhai bhai" slogan — collapses catastrophically when China launches a swift offensive across the Himalayan border in October 1962 and routs India’s unprepared army; Nehru is forced to appeal for Western military aid, shattering the aura of non-alignment and delivering a national humiliation that would darken his final years.',
      svg_compare('Illusion meets reality', {
          'head': 'What Nehru believed', 'color': '#166534', 'items': [
              '“Hindi-Chini bhai bhai” — brotherhood',
              'Panchsheel would keep the peace',
              'Non-alignment shielded India']},
          {'head': 'What 1962 delivered', 'color': '#b91c1c', 'items': [
              'A sudden Chinese offensive and rout',
              'An unprepared, ill-equipped army',
              'A plea for Western arms']},
      verdict='The defeat shattered his China policy and the aura of non-alignment in a single month.',
      takeaway='The war exposed the gap between Nehru’s idealism and a hard world — a humiliation that broke his spirit and his health.', accent=AC),
      bg='For years Nehru had cultivated friendship with China even as the two disputed their vast Himalayan frontier.',
      people='<b>Mao Zedong</b> and <b>Zhou Enlai</b> of China; the outmatched Indian army; the Western powers Nehru turned to for aid.',
      what='In <b>October–November 1962</b> China launched a swift offensive in <b>NEFA (Arunachal) and Aksai Chin</b>, routing Indian forces; Nehru had to <b>appeal for Western military help</b>, discrediting his China policy and his non-alignment.',
      crux='His <b>trust in Chinese goodwill and neglect of defence</b> were exposed as a grave miscalculation — idealism punished by realpolitik.',
      conseq='The defeat was a national trauma that broke Nehru’s prestige and, many said, his spirit; his health declined sharply thereafter.',
      matters='Hope is not a strategy — 1962 stands as the cautionary shadow over Nehru’s otherwise luminous record.'),

    E('death', '1963–1964', 'Death, and the Nehruvian legacy', ['POLITICS', 'DEATH', 'LEGACY'],
      'Broken in health after the 1962 defeat, Nehru suffers a stroke and dies on 27 May 1964, having governed for nearly seventeen years — leaving behind a functioning democracy, a secular constitution, an industrial and scientific base and a tradition of non-alignment, a towering founding legacy that admirers revere and critics fault for its economic timidity and the wound of Kashmir.',
      svg_stack('The founder’s balance sheet', [
          {'n': 1, 'label': 'Health broken, 1963', 'sub': 'the 1962 defeat takes its toll', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Dies 27 May 1964', 'sub': 'after nearly seventeen years as PM', 'color': '#c2410c'},
          {'n': 3, 'label': 'The Nehruvian legacy', 'sub': 'a secular democracy — revered and criticised', 'color': '#166534'},
      ], takeaway='He left India a democracy, a secular constitution and an industrial base — a founding legacy weighed against slow growth and Kashmir.', accent=AC),
      bg='After 1962 Nehru’s health failed; he had led India since 1947 and become synonymous with the young republic itself.',
      people='his daughter <b>Indira Gandhi</b>, a future prime minister; his colleagues and successors; the nation he had founded.',
      what='Nehru <b>died on 27 May 1964</b> after a stroke, having served as prime minister for nearly seventeen years, leaving a <b>secular democracy, a constitution, an industrial-scientific base and non-alignment</b> as his legacy.',
      crux='He bequeathed <b>durable democratic and secular institutions</b> — his defenders’ pride and his critics’ target, faulted for statist economics and Kashmir.',
      conseq='India remained a democracy through the transitions that followed; the "Nehruvian consensus" shaped its politics for a generation.',
      matters='Founders are judged in the long run — Nehru built the framework of modern India, and the debate over it defines its politics still.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Jawaharlal Nehru was the chief architect of a modern, secular, democratic India. Born to wealth and educated at Harrow and Cambridge, he abandoned a barrister’s comfort to become Gandhi’s foremost disciple — a modernist and socialist who saw poverty, not just foreign rule, as India’s enemy. He led the independence struggle, went to prison nine times, and at the midnight of freedom in 1947 became the nation’s first Prime Minister. Over seventeen years he built a secular republic, a planned economy and a policy of non-alignment — a towering founding record shadowed by the humiliating defeat by China in 1962. He is the great study in <b>nation-building, secular democracy, and the tension between idealism and a hard world.</b></p>
<div class="ov-quote">“At the stroke of the midnight hour, when the world sleeps, India will awake to life and freedom.”<span>— Nehru, “Tryst with Destiny,” 15 August 1947</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A privileged Allahabad childhood and an English education → radicalised by the Amritsar massacre, he becomes Gandhi’s disciple → turns socialist and demands complete independence at Lahore → jails, prison books, and the road through Quit India → “Tryst with Destiny” and the first premiership amid Partition → builds a secular republic, a planned economy and non-alignment → and is shadowed in his last years by the 1962 defeat by China before his death in 1964.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🕊️</div><h4>Secular democracy</h4><p>Anchored a plural nation in democracy and equal citizenship.</p></div>
  <div class="ov-card"><div class="i">🏭</div><h4>Temples of modern India</h4><p>Planned economy, dams, steel and the IITs built a modern base.</p></div>
  <div class="ov-card"><div class="i">🌍</div><h4>Non-alignment</h4><p>Gave the Third World a voice between the Cold War blocs.</p></div>
  <div class="ov-card"><div class="i">⚠️</div><h4>The limits of idealism</h4><p>1962 exposed the cost of hope unbacked by hard power.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Making</b><small> 1889–1919</small><p>Privilege, England, and the radicalising massacre.</p></div>
  <div><b>2 · Gandhi’s Disciple</b><small> 1920–1930</small><p>Self-denial, socialism, and Purna Swaraj.</p></div>
  <div><b>3 · The Road to Freedom</b><small> 1930–1947</small><p>Prisons, prison books, and the tryst with destiny.</p></div>
  <div><b>4 · Building Modern India</b><small> 1947–1955</small><p>A secular republic, planning, and non-alignment.</p></div>
  <div><b>5 · Shadows &amp; Legacy</b><small> 1956–1964</small><p>Strains, the 1962 defeat, and the founder’s legacy.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Mohandas Gandhi', 'role': 'mentor', 'color': '#166534',
     'bio': 'The leader of the freedom struggle who made Nehru his political heir, though the two differed sharply on economics and modernity.',
     'rel': 'His revered master — and his great ideological foil.'},
    {'name': 'Motilal Nehru', 'role': 'father', 'color': '#a16207',
     'bio': 'The wealthy barrister who gave Jawaharlal his privileged start, then joined him in the national movement.',
     'rel': 'The father whose wealth and ambition shaped his path.'},
    {'name': 'Sardar Vallabhbhai Patel', 'role': 'deputy & rival', 'color': '#b91c1c',
     'bio': 'Nehru’s tough deputy prime minister, who integrated the princely states and balanced Nehru’s idealism with hard pragmatism.',
     'rel': 'The iron man who complemented and checked him.'},
    {'name': 'Indira Gandhi', 'role': 'daughter & heir', 'color': '#c2410c',
     'bio': 'Nehru’s only child and closest companion, who would herself become one of India’s most powerful prime ministers.',
     'rel': 'His daughter, confidante and eventual successor.'},
    {'name': 'Zhou Enlai', 'role': 'partner turned adversary', 'color': '#5b21b6',
     'bio': 'The Chinese premier who signed Panchsheel with Nehru before the 1962 war shattered their proclaimed brotherhood.',
     'rel': 'The friend of Panchsheel who became the face of 1962.'},
]

KEY_EVENTS = [
    ('1889', 'Nehru born in Allahabad', 'Son of the wealthy barrister Motilal Nehru.'),
    ('1905–12', 'Harrow, Cambridge, the bar', 'An English education and Fabian socialism.'),
    ('1919', 'Jallianwala Bagh', 'The massacre that radicalised him.'),
    ('1929', 'Congress President at Lahore', 'Moves the Purna Swaraj resolution.'),
    ('1942–45', 'Quit India and prison', 'His longest confinement; the Raj’s endgame.'),
    ('1947', 'First Prime Minister', '“Tryst with Destiny” amid Partition.'),
    ('1950', 'The Republic and planning', 'Constitution in force; Planning Commission.'),
    ('1955', 'Bandung and non-alignment', 'Voice of the decolonising world.'),
    ('1962', 'Sino-Indian War', 'A humiliating defeat by China.'),
    ('1964', 'Death of Nehru', 'The founder of modern India dies.'),
]

MASTER = [
    {'year': '1889', 'age': 'born', 'phase': 'The Making', 'title': 'Born in Allahabad', 'desc': 'Privilege and an Anglicised childhood.'},
    {'year': '1919', 'age': 'age 30', 'phase': 'The Making', 'title': 'Radicalised', 'desc': 'Amritsar shatters his faith in Britain.'},
    {'year': '1929', 'age': 'age 40', 'phase': 'Gandhi’s Disciple', 'title': 'Purna Swaraj', 'desc': 'Demands complete independence at Lahore.'},
    {'year': '1947', 'age': 'age 58', 'phase': 'Road to Freedom', 'title': 'First Prime Minister', 'desc': '“Tryst with Destiny” amid Partition.'},
    {'year': '1950', 'age': 'age 60', 'phase': 'Building Modern India', 'title': 'The Republic', 'desc': 'Secular constitution; planned economy.'},
    {'year': '1955', 'age': 'age 66', 'phase': 'Building Modern India', 'title': 'Bandung', 'desc': 'Non-alignment and global stature.'},
    {'year': '1962', 'age': 'age 73', 'phase': 'Shadows & Legacy', 'title': 'War with China', 'desc': 'The great humiliation.'},
    {'year': '1964', 'age': 'age 74', 'phase': 'Shadows & Legacy', 'title': 'Death', 'desc': 'The Nehruvian legacy endures.'},
]

SOURCES = [
    ('Britannica — Jawaharlal Nehru', 'https://www.britannica.com/biography/Jawaharlal-Nehru'),
    ('Britannica — Nehru: Achievements as prime minister', 'https://www.britannica.com/biography/Jawaharlal-Nehru/Achievements-as-prime-minister'),
    ('Wikipedia — Jawaharlal Nehru', 'https://en.wikipedia.org/wiki/Jawaharlal_Nehru'),
    ('Wikipedia — Tryst with Destiny', 'https://en.wikipedia.org/wiki/Tryst_with_Destiny'),
    ('PM India — Shri Jawaharlal Nehru', 'https://www.pmindia.gov.in/en/former_pm/shri-jawaharlal-nehru/'),
]

def build_meta():
    return {
        'pid': 'gm-nehru.html', 'kind': 'man', 'emoji': '🇮🇳', 'accent': AC,
        'name': 'Jawaharlal Nehru', 'years': '1889–1964', 'group': 'Independence & Nation-Building',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The privileged barrister who became Gandhi’s heir and free India’s first Prime Minister — architect of a secular democracy, a planned economy and non-alignment, shadowed at the last by the 1962 defeat by China.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'making', 'label': '1 · The Making', 'type': 'timeline',
             'intro': 'A gilded Allahabad childhood and an English education at Harrow and Cambridge produce a polished barrister — until the Amritsar massacre of 1919 radicalises him toward the freedom struggle.', 'events': PHASE_MAKING},
            {'id': 'disciple', 'label': '2 · Gandhi’s Disciple', 'type': 'timeline',
             'intro': 'He gives himself to Gandhi and the Non-Cooperation movement, turns socialist after visiting Europe and the USSR, and as Congress President moves the demand for complete independence at Lahore.', 'events': PHASE_DISCIPLE},
            {'id': 'road', 'label': '3 · The Road to Freedom', 'type': 'timeline',
             'intro': 'Nine imprisonments and the great prison books forge his idea of India; Quit India breaks Britain’s grip; and at midnight in 1947 he becomes first Prime Minister amid the agony of Partition.', 'events': PHASE_ROAD},
            {'id': 'build', 'label': '4 · Building Modern India', 'type': 'timeline',
             'intro': 'He founds a secular democratic republic, drives industrialisation through the Five-Year Plans and the “temples of modern India,” and gives the Third World a voice through non-alignment.', 'events': PHASE_BUILD},
            {'id': 'shadows', 'label': '5 · Shadows & Legacy', 'type': 'timeline',
             'intro': 'Strains fray the Nehruvian order, the 1962 defeat by China delivers a national humiliation that breaks his health, and his death in 1964 leaves a founding legacy revered and contested in equal measure.', 'events': PHASE_SHADOWS,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources; famous phrases such as “Tryst with Destiny” and “temples of modern India” are Nehru’s own and are quoted as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
