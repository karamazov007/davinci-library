# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Emperor Wu of Han (Han Wudi).
The emperor who forged the enduring shape of imperial China — Confucian state, expanded empire, and the Silk Road."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#9d1c1c'  # Han crimson

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE YOUNG EMPEROR
PHASE_RISE = [
    E('accession', '141–135 BC', 'A boy emperor under his grandmother’s shadow', ['RISE', 'POLITICS'],
      'Liu Che takes the throne at fifteen as the seventh Han emperor, but real power rests with his Taoist-minded grandmother, the Grand Dowager Empress Dou, who blocks his early Confucian reforms — until her death in 135 BC frees the young ruler to begin remaking the state in his own image.',
      svg_stack('A young ruler waits for his moment', [
          {'n': 1, 'label': 'Liu Che crowned at fifteen, 141 BC', 'sub': 'seventh emperor of the Han dynasty', 'color': '#9d1c1c'},
          {'n': 2, 'label': 'Grand Dowager Empress Dou rules', 'sub': 'her Taoist faction blocks Confucian reform', 'color': '#a16207'},
          {'n': 3, 'label': 'Her death frees him, 135 BC', 'sub': 'the young emperor seizes the initiative', 'color': '#166534'},
      ], takeaway='He inherited a rich, peaceful realm but no free hand — and bided his time until the old guard died away.', accent=AC),
      bg='The Han dynasty, founded in 202 BC, had recovered under decades of light-handed, frugal rule. <b>Liu Che</b> inherited a full treasury and a peaceful realm at just fifteen.',
      people='<b>Liu Che</b>, the young emperor; the <b>Grand Dowager Empress Dou</b>, his formidable Taoist grandmother; the court factions around them.',
      what='Crowned in <b>141 BC</b>, the boy emperor’s first Confucian-leaning reforms were crushed by his grandmother’s Taoist faction; only her <b>death in 135 BC</b> gave him command of policy.',
      crux='Power on paper was not power in fact — the young ruler had to <b>outlast the old regents</b> before he could govern.',
      conseq='Freed of his grandmother’s restraint, Wu launched the reforms and wars that would define a 54-year reign.',
      matters='Patience is the first lesson of power — even an emperor must sometimes wait for his moment to arrive.'),

    E('confucianism', '136–124 BC', 'Making Confucianism the creed of the state', ['REFORM', 'TURNING POINT'],
      'Advised by the scholar Dong Zhongshu, Emperor Wu elevates Confucianism to the official ideology of the empire — establishing academic chairs for the Five Classics, founding an Imperial Academy to train officials, and recruiting men by merit and recommendation, laying the deep foundations of the scholar-official state that would govern China for two millennia.',
      svg_row('Building a state on the Classics', [
          {'n': 1, 'label': 'Dong Zhongshu’s counsel', 'sub': 'honour Confucianism, sideline rival schools', 'color': '#a16207'},
          {'n': 2, 'label': 'Chairs of the Five Classics, 136 BC', 'sub': 'and the Imperial Academy (Taixue), 124 BC', 'color': '#9d1c1c'},
          {'n': 3, 'label': 'Officials chosen by merit', 'sub': 'recommendation and examination take root', 'color': '#166534'},
      ], edge_labels=['leads to', 'so'], takeaway='He fused throne and Confucian learning — creating the scholar-official ideal that outlasted every dynasty after him.', accent=AC),
      bg='Early Han rulers had favoured the laissez-faire <b>Huang-Lao</b> Taoism. Wu sought a doctrine that dignified strong, activist central rule.',
      people='the scholar <b>Dong Zhongshu</b>, who framed the new orthodoxy; the classicists who filled the new chairs; the officials trained by the academy.',
      what='Wu made <b>Confucianism the state ideology</b>, endowed <b>chairs for the Five Classics (136 BC)</b>, founded the <b>Imperial Academy / Taixue (124 BC)</b>, and recruited officials by <b>merit and recommendation</b> — the germ of the examination system.',
      crux='He gave the empire a <b>shared moral and administrative language</b> — a bureaucracy bound by learning rather than birth.',
      conseq='The scholar-official (mandarin) state took root and endured, in evolving form, until the twentieth century.',
      matters='Ideology can be infrastructure — Wu’s choice of Confucianism shaped how China would be governed for over two thousand years.'),

    E('centralise', '127 BC', 'Breaking the great lords with a kind decree', ['POLITICS', 'REFORM'],
      'To tame the semi-independent kingdoms that threatened the throne, Emperor Wu issues the cunning "Decree of Grace" — compelling each nobleman to divide his fief among all his sons rather than pass it whole to one heir — a policy that shatters the great domains into harmless fragments and pulls real power to the imperial centre without a single revolt.',
      svg_stack('Dividing to rule', [
          {'n': 1, 'label': 'Over-mighty vassal kingdoms', 'sub': 'a standing threat to the Han throne', 'color': '#a16207'},
          {'n': 2, 'label': 'The Decree of Grace, 127 BC', 'sub': 'fiefs split among all a lord’s sons', 'color': '#9d1c1c'},
          {'n': 3, 'label': 'Domains crumble; centre gains', 'sub': 'no rebellion — the lords could not refuse', 'color': '#166534'},
      ], takeaway='He dressed a power-grab as generosity — every heir gained land, and every great kingdom dissolved into weakness.', accent=AC),
      bg='Since the <b>Rebellion of the Seven States (154 BC)</b>, the great princely kingdoms remained a danger to central authority.',
      people='<b>Emperor Wu</b> and his adviser <b>Zhufu Yan</b>, author of the scheme; the regional lords it quietly dispossessed.',
      what='The <b>Decree of Grace (tuī’ēn lìng, 127 BC)</b> required nobles to <b>partition their lands among all their sons</b>, fragmenting the kingdoms into small, powerless estates over a generation.',
      crux='It was <b>coercion disguised as a favour</b> — the lords could not object to enriching their own children.',
      conseq='The threat of the great kingdoms withered, and power flowed decisively to the emperor and his officials.',
      matters='The subtlest reforms make resistance impossible — Wu centralised an empire by appearing only to be generous.'),
]

# ==================================================================  PHASE 2 — THE WARS AGAINST THE XIONGNU
PHASE_WAR = [
    E('breakheqin', '133 BC', 'From appeasement to open war with the Xiongnu', ['POLITICS', 'TURNING POINT', 'BATTLE'],
      'For sixty years the Han had bought peace from the nomadic Xiongnu confederation with princesses and tribute under the humiliating "heqin" policy. Emperor Wu breaks with it decisively, springing a great ambush at Mayi in 133 BC — and though the trap fails, it opens a war against the steppe that will consume his reign.',
      svg_compare('A generation of appeasement — abandoned', {
          'head': 'The old heqin policy',
          'color': '#a16207',
          'items': ['Han princesses married to the Xiongnu chief',
                    'Annual tribute of silk, grain and gold',
                    'Peace bought through humiliation',
                    'Raids continued despite the payments'],
      }, {
          'head': 'Wu’s policy of war',
          'color': '#9d1c1c',
          'items': ['The Mayi ambush of 133 BC',
                    'Open, offensive campaigns onto the steppe',
                    'The frontier to be won, not bribed',
                    'Decades of costly, expansive warfare'],
      }, verdict='Wu chose to defeat the Xiongnu rather than pay them — a fateful, ruinous, and transformative reversal.',
        takeaway='He tore up sixty years of tribute diplomacy and staked his reign on beating the steppe by force.', accent=AC),
      bg='Since Emperor Gaozu’s defeat at <b>Baideng (200 BC)</b>, the Han had appeased the powerful <b>Xiongnu</b> confederation through the <b>heqin</b> marriage-and-tribute system.',
      people='<b>Emperor Wu</b>, bent on war; the <b>Xiongnu chanyu</b> (supreme ruler); the frontier hawks who urged the break.',
      what='In <b>133 BC</b> Wu abandoned heqin and laid the <b>Mayi ambush</b> to trap the Xiongnu army; the plan was discovered and failed, but it began <b>open war</b> with the steppe.',
      crux='He judged that tribute bought only contempt — the nomads must be <b>beaten, not bribed</b>.',
      conseq='The failed ambush ignited a war that would last decades, drain the treasury, and reshape Asia.',
      matters='A ruler’s first great choice can define an era — Wu traded a costly peace for a still costlier war of conquest.'),

    E('generals', '127–119 BC', 'Wei Qing and Huo Qubing shatter the steppe', ['BATTLE', 'TRIUMPH'],
      'Emperor Wu finds two brilliant cavalry generals — the veteran Wei Qing and his meteoric young nephew Huo Qubing — who carry the war deep into the Xiongnu heartland, seizing the vital Hexi Corridor and, at the climactic Battle of Mobei in 119 BC, driving the nomads north of the Gobi and breaking their grip on the frontier.',
      svg_stack('Carrying the war onto the steppe', [
          {'n': 1, 'label': 'Wei Qing takes the offensive, 127 BC', 'sub': 'recovers the Ordos loop of the Yellow River', 'color': '#9d1c1c'},
          {'n': 2, 'label': 'Huo Qubing seizes the Hexi Corridor', 'sub': 'the young prodigy opens the road west, 121 BC', 'color': '#a16207'},
          {'n': 3, 'label': 'The Battle of Mobei, 119 BC', 'sub': 'Xiongnu driven north beyond the Gobi', 'color': '#166534'},
      ], takeaway='Two cavalry generals turned defence into conquest — and pushed the Xiongnu off the frontier for a generation.', accent=AC),
      bg='Beating mounted nomads required their own weapon — massed <b>cavalry</b> striking deep — and commanders bold enough to lead it.',
      people='<b>Wei Qing</b>, the steady commander-in-chief; <b>Huo Qubing</b>, his dazzling young nephew; the <b>Xiongnu chanyu</b> they hunted.',
      what='From <b>127 BC</b> Wei Qing recovered the Ordos; <b>Huo Qubing</b> seized the <b>Hexi Corridor (121 BC)</b>; and at <b>Mobei (119 BC)</b> both generals drove the Xiongnu <b>north of the Gobi</b>.',
      crux='Wu matched the nomads’ mobility with his own cavalry and <b>took the war to their homeland</b> instead of defending the wall.',
      conseq='The Xiongnu threat was broken for a generation, and the corridor to Central Asia lay open — but at staggering cost in men and treasure.',
      matters='To beat an enemy you must fight on his terms — Wu defeated the horse-nomads by out-riding them.'),

    E('expansion', '112–108 BC', 'An empire stretched to Korea, the south, and the west', ['BATTLE', 'TRIUMPH'],
      'With the steppe subdued, Emperor Wu turns his armies outward in every direction — annexing the southern kingdom of Nanyue across modern Guangdong and northern Vietnam, conquering Gojoseon in the Korean peninsula, and pushing the frontier into the southwest and Central Asia, roughly doubling the territory of the Han and setting the enduring bounds of the Chinese world.',
      svg_row('The empire expands on every front', [
          {'n': 1, 'label': 'Nanyue conquered, 111 BC', 'sub': 'the south into Guangdong and northern Vietnam', 'color': '#9d1c1c'},
          {'n': 2, 'label': 'Gojoseon annexed, 108 BC', 'sub': 'commanderies planted in the Korean peninsula', 'color': '#a16207'},
          {'n': 3, 'label': 'West and southwest secured', 'sub': 'Hexi commanderies; reach into Central Asia', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='In a single reign the Han roughly doubled — fixing the frontiers of the Chinese world for centuries.', accent=AC),
      bg='The victories over the Xiongnu freed Wu’s armies and ambition for <b>conquest in every direction</b>.',
      people='the general <b>Lu Bode</b> in the south; the commanders in Korea; the frontier settlers who colonised the new commanderies.',
      what='Wu annexed <b>Nanyue (111 BC)</b> across the far south and northern Vietnam, conquered <b>Gojoseon (108 BC)</b> in Korea, subdued the southwestern <b>Dian</b>, and secured the <b>Hexi Corridor</b> toward Central Asia.',
      crux='He turned a defensive dynasty into an <b>expansive empire</b>, planting Han administration far beyond the old heartland.',
      conseq='The Han roughly doubled in size, and the borders Wu set became a lasting template for the Chinese state.',
      matters='Conquest can outlive the conqueror — the map Wu drew still echoes in the shape of East Asia today.'),
]

# ==================================================================  PHASE 3 — OPENING THE WORLD
PHASE_SILK = [
    E('zhangqian', '139–126 BC', 'Zhang Qian’s long road into the unknown west', ['REFORM', 'TURNING POINT'],
      'Seeking allies against the Xiongnu, Emperor Wu sends the envoy Zhang Qian westward into lands no Han official had seen. Captured and held by the nomads for years, Zhang finally escapes, reaches the distant kingdoms of Central Asia, and returns after thirteen years — bringing not an alliance, but priceless knowledge of a whole world beyond the mountains.',
      svg_stack('An envoy opens the map of the west', [
          {'n': 1, 'label': 'Sent to find allies, 139 BC', 'sub': 'to seek the Yuezhi against the Xiongnu', 'color': '#9d1c1c'},
          {'n': 2, 'label': 'Captured, escapes, presses on', 'sub': 'years a prisoner, then Ferghana and Bactria', 'color': '#a16207'},
          {'n': 3, 'label': 'Returns after thirteen years, 126 BC', 'sub': 'no pact, but a map of the western world', 'color': '#166534'},
      ], takeaway='He set out for an alliance and came back with something greater — the first Chinese knowledge of Central Asia.', accent=AC),
      bg='Wu learned that the <b>Yuezhi</b> people, driven west by the Xiongnu, might make natural allies — if he could reach them.',
      people='the intrepid envoy <b>Zhang Qian</b>; the Xiongnu who held him captive; the western kingdoms of <b>Dayuan (Ferghana)</b> and <b>Bactria</b> he described.',
      what='Dispatched in <b>139 BC</b>, <b>Zhang Qian</b> was captured by the Xiongnu, escaped, journeyed through <b>Ferghana and Bactria</b>, and returned in <b>126 BC</b> with detailed reports of the western lands.',
      crux='His mission failed in its aim but succeeded beyond it — <b>opening China’s eyes to the wider world</b>.',
      conseq='His reports spurred trade, further embassies, and the wars and diplomacy that opened the Silk Road.',
      matters='Exploration rewards the persistent — Zhang Qian’s journey mattered not for its errand but for the world it revealed.'),

    E('silkroad', '126–114 BC', 'The Silk Road opens between China and the west', ['REFORM', 'TRIUMPH'],
      'On the strength of Zhang Qian’s reports, Emperor Wu sends caravans and embassies streaming westward, and secures the Hexi Corridor with garrisons and commanderies — opening the great overland trade routes that will carry Chinese silk toward Rome and bring horses, ideas, and goods eastward: the birth of the Silk Road.',
      svg_row('Trade routes span a continent', [
          {'n': 1, 'label': 'The Hexi Corridor secured', 'sub': 'garrison commanderies guard the road west', 'color': '#9d1c1c'},
          {'n': 2, 'label': 'Embassies and caravans dispatched', 'sub': 'Han envoys reach the Central Asian kingdoms', 'color': '#a16207'},
          {'n': 3, 'label': 'Silk flows west, goods flow east', 'sub': 'the trans-Asian trade routes come alive', 'color': '#166534'},
      ], edge_labels=['enables', 'yields'], takeaway='Wu stitched China to Central Asia by road and garrison — founding the trade artery that bore his silk toward the west.', accent=AC),
      bg='The conquest of the <b>Hexi Corridor</b> and Zhang Qian’s intelligence made regular contact with the west possible for the first time.',
      people='<b>Emperor Wu</b>, sponsor of the routes; the merchants and envoys who travelled them; the Central Asian states they linked.',
      what='Wu planted <b>commanderies along the Hexi Corridor</b>, sent repeated <b>embassies and trade caravans</b> westward, and opened the overland <b>Silk Road</b> connecting China to Central Asia and, eventually, the Mediterranean.',
      crux='He turned military reach into <b>commercial and diplomatic reach</b> — protecting the roads that carried trade.',
      conseq='For centuries the Silk Road carried silk, horses, crops, religions and ideas between East and West.',
      matters='Roads outlast reigns — Wu’s Silk Road became one of history’s great channels of exchange between civilisations.'),

    E('heavenlyhorses', '104–101 BC', 'The War of the Heavenly Horses reaches Ferghana', ['BATTLE', 'POLITICS'],
      'Coveting the famed "blood-sweating" heavenly horses of Ferghana for his cavalry, and to enforce Han prestige across the west, Emperor Wu sends the general Li Guangli on a gruelling expedition thousands of miles into Central Asia — a costly, punishing campaign that finally subdues the distant kingdom of Dayuan and cements Han dominance over the trade routes to the far west.',
      svg_stack('Reaching the ends of the known world', [
          {'n': 1, 'label': 'Coveting the heavenly horses', 'sub': 'Ferghana’s prized “blood-sweating” steeds', 'color': '#9d1c1c'},
          {'n': 2, 'label': 'Li Guangli marches west, 104 BC', 'sub': 'a brutal expedition across the deserts', 'color': '#a16207'},
          {'n': 3, 'label': 'Dayuan subdued, 101 BC', 'sub': 'Han prestige imposed on Central Asia', 'color': '#166534'},
      ], takeaway='He waged war at the very edge of the map — for prize horses and the prestige of an empire that reached to Ferghana.', accent=AC),
      bg='The prized <b>heavenly horses</b> of <b>Dayuan (Ferghana)</b> promised better war-mounts, and Wu meant to enforce Han authority over the western states.',
      people='the general <b>Li Guangli</b>, brother of a favourite consort; the defenders of Dayuan; the exhausted Han soldiers of the long march.',
      what='In the <b>War of the Heavenly Horses (104–101 BC)</b>, <b>Li Guangli</b> led an enormous, costly expedition across Central Asia that ultimately <b>subdued Dayuan</b> and secured the coveted horses and Han supremacy.',
      crux='Wu projected power to the <b>farthest reach of the known world</b> — as much for prestige as for the horses.',
      conseq='Han dominance over the western trade routes was confirmed, but at ruinous expense in lives and treasure.',
      matters='Great powers spend lavishly on prestige — Wu marched armies across a continent partly to prove that he could.'),
]

# ==================================================================  PHASE 4 — THE MACHINERY AND OBSESSIONS OF EMPIRE
PHASE_STATE = [
    E('saltiron', '119–110 BC', 'Salt, iron and the state that pays for war', ['REFORM', 'POLITICS'],
      'The endless wars drain the treasury, so Emperor Wu, guided by the financier Sang Hongyang, seizes the means to refill it — establishing state monopolies over salt and iron, minting coinage, and intervening in markets through "equable transport" — an activist command economy that funds the empire’s armies and marks one of history’s earliest experiments in state economic control.',
      svg_row('Financing an empire at war', [
          {'n': 1, 'label': 'The wars drain the treasury', 'sub': 'campaigns cost more than taxes can bear', 'color': '#a16207'},
          {'n': 2, 'label': 'State monopolies on salt and iron', 'sub': 'plus coinage and market intervention, 119+ BC', 'color': '#9d1c1c'},
          {'n': 3, 'label': 'The state funds itself', 'sub': 'an activist command economy is born', 'color': '#166534'},
      ], edge_labels=['forces', 'so'], takeaway='He turned essential goods into state revenue — an early command economy built to pay for conquest.', accent=AC),
      bg='Wu’s wars and expeditions cost more than the light Han land tax could ever raise, threatening bankruptcy.',
      people='the financier <b>Sang Hongyang</b>, architect of the monopolies; the merchants they squeezed; the officials who ran the new state industries.',
      what='From <b>119 BC</b> Wu imposed <b>state monopolies on salt and iron</b> (and later liquor), reformed the <b>coinage</b>, and used <b>“equable transport and standard” schemes</b> to control prices and profit — a command economy to fund the state.',
      crux='He made the state the <b>producer and merchant</b> of life’s necessities, capturing the revenue directly.',
      conseq='The monopolies financed his ambitions and became a permanent, hotly debated feature of Chinese statecraft.',
      matters='War drives fiscal invention — Wu’s salt and iron monopolies pioneered the state’s deep hand in the economy.'),

    E('legalism', '120s–100s BC', 'Confucian in robe, Legalist in fist', ['POLITICS', 'REFORM'],
      'For all his Confucian trappings, Emperor Wu governs with an iron, Legalist hand — employing "harsh officials" to enforce the law without mercy, building a powerful centralised bureaucracy, and wielding a strong "inner court" of trusted men against the formal ministries: the classic Han synthesis of Confucian ideals outside and Legalist discipline within.',
      svg_compare('The two faces of Wu’s rule', {
          'head': 'The Confucian face',
          'color': '#a16207',
          'items': ['Confucianism as the state creed',
                    'Officials schooled in the Classics',
                    'Rule justified by virtue and the Mandate',
                    'A moral language for government'],
      }, {
          'head': 'The Legalist fist',
          'color': '#9d1c1c',
          'items': ['“Harsh officials” enforcing strict law',
                    'A centralised, disciplined bureaucracy',
                    'A trusted inner court over the ministries',
                    'Severe punishments and tight control'],
      }, verdict='“Outwardly Confucian, inwardly Legalist” — the enduring formula of the Chinese imperial state.',
        takeaway='He clothed a hard, centralising machine in the robes of Confucian virtue — and both halves outlasted him.', accent=AC),
      bg='The Qin had ruled by naked <b>Legalism</b> and collapsed; the Han needed the discipline without the brutality’s bad name.',
      people='<b>Emperor Wu</b>; his <b>“harsh officials”</b> such as Zhang Tang; the inner-court favourites who wielded real power.',
      what='Wu paired his Confucian orthodoxy with <b>Legalist administration</b> — strict enforcement by <b>“harsh officials,”</b> a strong central bureaucracy, and a trusted <b>inner court</b> that eclipsed the formal ministries.',
      crux='He took the <b>discipline of Legalism</b> and the <b>legitimacy of Confucianism</b>, and fused them into one system.',
      conseq='This “outwardly Confucian, inwardly Legalist” synthesis became the durable model of Chinese imperial rule.',
      matters='Enduring states borrow from every school — Wu’s blend of virtue and severity governed China for millennia.'),

    E('immortality', '110s–90s BC', 'The emperor’s hunt for immortality', ['POLITICS', 'TRAGEDY'],
      'As he ages, the all-powerful emperor grows obsessed with cheating death — surrounding himself with magicians and alchemists who promise elixirs of immortality, performing the grand Feng and Shan sacrifices atop sacred Mount Tai, and squandering vast sums on expeditions to find the fabled isles of the immortals: the great weakness of a mind that could command everything but time.',
      svg_stack('A ruler at war with mortality', [
          {'n': 1, 'label': 'Obsession with immortality', 'sub': 'the ageing emperor fears death', 'color': '#a16207'},
          {'n': 2, 'label': 'Magicians and elixirs', 'sub': 'fangshi promise potions of eternal life', 'color': '#9d1c1c'},
          {'n': 3, 'label': 'Rites and quests for the immortals', 'sub': 'the Feng and Shan sacrifices on Mount Tai', 'color': '#78350f'},
      ], takeaway='The man who commanded an empire could not command time — and poured his fortune into the search for eternal life.', accent=AC),
      bg='In an age steeped in belief in <b>immortals and spirits</b>, an ageing, all-powerful emperor found the thought of death unbearable.',
      people='the <b>fangshi</b> (magician-alchemists) who cultivated him; the courtiers who exploited his hopes; the sceptics who paid for doubting them.',
      what='Wu embraced <b>magicians and immortality-elixirs</b>, performed the imperial <b>Feng and Shan sacrifices at Mount Tai</b>, and financed lavish <b>expeditions to find the isles of the immortals</b>.',
      crux='Absolute power met its one true limit — <b>mortality</b> — and the emperor spent recklessly trying to escape it.',
      conseq='The credulous atmosphere of magic and suspicion he fostered helped set the stage for the witchcraft terror to come.',
      matters='Even the mightiest confront the one thing they cannot rule — and the fear of death can warp the wisest ruler.'),
]

# ==================================================================  PHASE 5 — THE TWILIGHT
PHASE_END = [
    E('witchcraft', '91 BC', 'The witchcraft terror engulfs the palace', ['TRAGEDY', 'DEATH', 'POLITICS'],
      'Late in his reign, the aged and paranoid emperor is convinced that sorcery — the burying of curse-dolls, or "wugu" — is sapping his health, and unleashes a witch-hunt through the court. The scheming official Jiang Chong turns the terror against the emperor’s own family, and tens of thousands perish in a spiralling purge of accusation, torture and death.',
      svg_stack('A court consumed by suspicion', [
          {'n': 1, 'label': 'The emperor fears black magic', 'sub': 'curse-dolls (wugu) blamed for his illness', 'color': '#a16207'},
          {'n': 2, 'label': 'Jiang Chong unleashes the hunt, 91 BC', 'sub': 'accusations reach the imperial family', 'color': '#9d1c1c'},
          {'n': 3, 'label': 'Tens of thousands die', 'sub': 'a spiral of denunciation and execution', 'color': '#111827'},
      ], takeaway='A sick old emperor’s dread of sorcery became a court-wide terror that devoured his own household.', accent=AC),
      bg='Aged, ill and steeped in the magic-haunted atmosphere of his own court, Wu came to believe that <b>witchcraft (wugu)</b> was killing him.',
      people='the malicious official <b>Jiang Chong</b>, who drove the purge; the countless accused; the imperial family in his sights.',
      what='In <b>91 BC</b> the <b>witchcraft scare (wugu zhi huo)</b> erupted; <b>Jiang Chong</b> exploited it to plant evidence against rivals — and against the crown prince — as <b>tens of thousands were killed</b>.',
      crux='Fear at the top became <b>licence for terror below</b> — every enemy could now be branded a sorcerer.',
      conseq='The hysteria drove the emperor’s own heir to a desperate act that would tear the dynasty’s heart out.',
      matters='A ruler’s private fears can become a nation’s catastrophe — paranoia at the summit rains down as terror.'),

    E('crownprince', '91 BC', 'The heir destroyed — the death of Liu Ju', ['TRAGEDY', 'DEATH', 'BATTLE'],
      'Framed by Jiang Chong and unable to reach his father, the crown prince Liu Ju is driven to raise troops in his own defence — an act instantly branded rebellion. After days of bloody street-fighting in the capital Chang’an, the prince’s forces are crushed; Liu Ju takes his own life, his mother the Empress Wei Zifu follows him in death, and Emperor Wu is left having destroyed his own chosen successor.',
      svg_row('A dynasty turns on itself', [
          {'n': 1, 'label': 'The crown prince is framed', 'sub': 'Jiang Chong plants curse-dolls against Liu Ju', 'color': '#a16207'},
          {'n': 2, 'label': 'Fighting erupts in Chang’an', 'sub': 'the cornered prince raises troops to defend himself', 'color': '#9d1c1c'},
          {'n': 3, 'label': 'The heir and empress die', 'sub': 'Liu Ju and Empress Wei Zifu take their lives', 'color': '#111827'},
      ], edge_labels=['drives', 'ends in'], takeaway='The witch-hunt turned father against son — and cost the old emperor the heir he had raised to rule.', accent=AC),
      bg='The <b>crown prince Liu Ju</b>, Wu’s son by <b>Empress Wei Zifu</b>, became the ultimate target of Jiang Chong’s poisoned accusations.',
      people='<b>Crown Prince Liu Ju</b>; his mother <b>Empress Wei Zifu</b>; <b>Jiang Chong</b>, his destroyer; Emperor Wu, deceived and enraged.',
      what='Framed and unable to prove his innocence, <b>Liu Ju killed Jiang Chong and raised troops</b>; branded a rebel, he was defeated after days of fighting in <b>Chang’an</b> and <b>took his own life</b>, as did the empress.',
      crux='A loyal heir, given no way to be heard, was <b>forced into the appearance of rebellion</b> and destroyed by it.',
      conseq='Wu lost his chosen successor, later realised the prince’s innocence, and grieved the tragedy bitterly.',
      matters='Injustice unchecked destroys the innocent first — the terror consumed the very heir it should have protected.'),

    E('luntai', '89–87 BC', 'Repentance, the Luntai Edict, and death', ['REFORM', 'DEATH', 'TURNING POINT'],
      'In his final years, a chastened Emperor Wu comes to see the ruin his endless wars and cruelties have wrought — and in the remarkable Luntai Edict of 89 BC he publicly repents, renouncing further military adventures and turning the state back toward the people’s welfare. He dies in 87 BC, leaving the throne to a young son under a trusted regent, and an empire transformed for all time.',
      svg_stack('An emperor’s reckoning', [
          {'n': 1, 'label': 'A reign of war and loss weighs on him', 'sub': 'exhausted treasury, dead heir, weary people', 'color': '#a16207'},
          {'n': 2, 'label': 'The Luntai Edict of repentance, 89 BC', 'sub': 'he renounces expansion, turns to the people’s welfare', 'color': '#9d1c1c'},
          {'n': 3, 'label': 'Death and succession, 87 BC', 'sub': 'young Liu Fuling under the regent Huo Guang', 'color': '#166534'},
      ], takeaway='The great conqueror ended by confessing his errors — and steering the exhausted empire back toward peace.', accent=AC),
      bg='Decades of war, heavy taxation, and the witchcraft catastrophe left the empire <b>drained and grieving</b> as Wu grew old.',
      people='the aged, repentant <b>Emperor Wu</b>; his heir <b>Liu Fuling</b> (the future Emperor Zhao); the regent <b>Huo Guang</b>, who would steady the realm.',
      what='In the <b>Luntai Edict (89 BC)</b> Wu <b>publicly repented</b> his wars and extravagance, rejected a plan for further expansion, and refocused on <b>agriculture and the people’s welfare</b>. He died in <b>87 BC</b>, leaving the throne to young <b>Liu Fuling</b> under <b>Huo Guang’s</b> regency.',
      crux='A ruler at the end of his powers chose <b>public repentance and course-correction</b> over pride — a rare act for an emperor.',
      conseq='The turn toward recovery preserved the dynasty, and Wu’s reforms and conquests shaped China for two thousand years.',
      matters='Even a titan can admit he went too far — Wu’s repentance let the empire he had strained survive and recover.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Emperor Wu of Han (Han Wudi) reigned for fifty-four years — one of the longest and most consequential reigns in Chinese history — and forged the enduring shape of imperial China. He made <b>Confucianism the creed of the state</b> and built the scholar-official system that would govern China for two millennia; he broke the semi-independent lords and centralised power in the throne; he shattered the <b>Xiongnu nomads</b> and roughly doubled the empire into Central Asia, Korea and the far south; he opened the <b>Silk Road</b> to the west; and he pioneered a command economy of salt and iron monopolies to pay for it all. Yet his reign ended in the shadow of a <b>witchcraft terror</b> that destroyed his own heir — before, in a rare act of imperial humility, he <b>publicly repented</b>. He is the ultimate study in <b>state-building, expansion, and the ruinous cost of unrelenting ambition.</b></p>
<div class="ov-quote">“Outwardly Confucian, inwardly Legalist.”<span>— the enduring formula of the state Emperor Wu built</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A boy emperor waits out his grandmother, then makes Confucianism the creed of the state and breaks the great lords → he tears up sixty years of appeasement and sends Wei Qing and Huo Qubing to shatter the Xiongnu → he expands the empire to Korea, the south and Central Asia and dispatches Zhang Qian to open the Silk Road → he funds it all with salt-and-iron monopolies and rules by a Confucian-Legalist blend, while hunting for immortality → and his reign closes in a witchcraft terror that kills his heir, followed by his own public repentance in the Luntai Edict.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">📜</div><h4>The Confucian state</h4><p>Made Confucianism state ideology and founded the scholar-official system.</p></div>
  <div class="ov-card"><div class="i">🐎</div><h4>The Xiongnu wars</h4><p>Broke the steppe nomads and doubled the empire’s reach.</p></div>
  <div class="ov-card"><div class="i">🐫</div><h4>The Silk Road</h4><p>Sent Zhang Qian west and opened trade between China and the world.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>The command economy</h4><p>Salt and iron monopolies — an early experiment in state economic control.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Young Emperor</b><small> 141–124 BC</small><p>Confucianism as state creed; breaking the lords.</p></div>
  <div><b>2 · The Xiongnu Wars</b><small> 133–108 BC</small><p>War on the steppe; an empire expands.</p></div>
  <div><b>3 · Opening the World</b><small> 139–101 BC</small><p>Zhang Qian and the birth of the Silk Road.</p></div>
  <div><b>4 · Machinery of Empire</b><small> 120s–90s BC</small><p>Monopolies, Legalist rule, and immortality.</p></div>
  <div><b>5 · The Twilight</b><small> 91–87 BC</small><p>The witchcraft terror, and repentance.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Dong Zhongshu', 'role': 'Confucian adviser', 'color': '#a16207',
     'bio': 'The scholar who framed the doctrine elevating Confucianism to state orthodoxy and justifying strong, centralised imperial rule.',
     'rel': 'The thinker who gave Wu’s state its guiding ideology.'},
    {'name': 'Wei Qing', 'role': 'commander-in-chief', 'color': '#9d1c1c',
     'bio': 'The steady, brilliant general who carried the war onto the steppe, recovering the Ordos and helping break the Xiongnu at Mobei.',
     'rel': 'The commander who turned Wu’s war on the nomads into victory.'},
    {'name': 'Huo Qubing', 'role': 'young cavalry general', 'color': '#b45309',
     'bio': 'Wei Qing’s meteoric nephew, who seized the Hexi Corridor and struck deep into Xiongnu territory before dying tragically young.',
     'rel': 'The dazzling prodigy of Wu’s campaigns against the steppe.'},
    {'name': 'Zhang Qian', 'role': 'explorer-envoy', 'color': '#166534',
     'bio': 'The envoy who journeyed for thirteen years into Central Asia, opening Chinese knowledge of the west and paving the way for the Silk Road.',
     'rel': 'The explorer whose mission opened China to the wider world.'},
    {'name': 'Crown Prince Liu Ju', 'role': 'his doomed heir', 'color': '#111827',
     'bio': 'Wu’s son and chosen successor, framed for witchcraft, driven to raise arms, and forced to his death in the terror of 91 BC.',
     'rel': 'The heir the witchcraft purge tore from him.'},
]

KEY_EVENTS = [
    ('141 BC', 'Liu Che takes the throne', 'A boy emperor begins a 54-year reign.'),
    ('136 BC', 'Confucianism made state creed', 'Chairs of the Five Classics established.'),
    ('133 BC', 'War with the Xiongnu begins', 'The Mayi ambush ends the heqin peace.'),
    ('127 BC', 'The Decree of Grace', 'The great lords broken by division.'),
    ('126 BC', 'Zhang Qian returns', 'Central Asia revealed after thirteen years.'),
    ('119 BC', 'Battle of Mobei', 'Xiongnu driven north of the Gobi.'),
    ('111–108 BC', 'The empire expands', 'Nanyue and Gojoseon conquered.'),
    ('91 BC', 'The witchcraft terror', 'The purge destroys the crown prince Liu Ju.'),
    ('89 BC', 'The Luntai Edict', 'The emperor publicly repents his wars.'),
    ('87 BC', 'Death of Emperor Wu', 'He leaves an empire transformed for good.'),
]

MASTER = [
    {'year': '141 BC', 'age': 'age 15', 'phase': 'The Young Emperor', 'title': 'Takes the throne', 'desc': 'A 54-year reign begins.'},
    {'year': '136 BC', 'age': 'age 20', 'phase': 'The Young Emperor', 'title': 'Confucianism elevated', 'desc': 'The state creed is set.'},
    {'year': '133 BC', 'age': 'age 23', 'phase': 'The Xiongnu Wars', 'title': 'War on the steppe', 'desc': 'The heqin peace is torn up.'},
    {'year': '119 BC', 'age': 'age 37', 'phase': 'The Xiongnu Wars', 'title': 'Battle of Mobei', 'desc': 'The nomads driven back.'},
    {'year': '126 BC', 'age': 'age 30', 'phase': 'Opening the World', 'title': 'Zhang Qian returns', 'desc': 'The Silk Road begins.'},
    {'year': '91 BC', 'age': 'age 65', 'phase': 'The Twilight', 'title': 'The witchcraft terror', 'desc': 'The heir is destroyed.'},
    {'year': '89 BC', 'age': 'age 67', 'phase': 'The Twilight', 'title': 'The Luntai Edict', 'desc': 'The emperor repents.'},
    {'year': '87 BC', 'age': 'age 69', 'phase': 'The Twilight', 'title': 'Death of Wu', 'desc': 'An empire transformed.'},
]

SOURCES = [
    ('Britannica — Wudi (Emperor Wu of Han)', 'https://www.britannica.com/biography/Wudi-emperor-of-Han-dynasty'),
    ('World History Encyclopedia — Emperor Wu / Han Dynasty', 'https://www.worldhistory.org/Han_Dynasty/'),
    ('Wikipedia — Emperor Wu of Han', 'https://en.wikipedia.org/wiki/Emperor_Wu_of_Han'),
    ('Wikipedia — Han–Xiongnu Wars', 'https://en.wikipedia.org/wiki/Han%E2%80%93Xiongnu_Wars'),
    ('New World Encyclopedia — Emperor Wu of Han', 'https://www.newworldencyclopedia.org/entry/Emperor_Wu_of_Han'),
]

def build_meta():
    return {
        'pid': 'gm-wuofhan.html', 'kind': 'man', 'emoji': '🐉', 'accent': AC,
        'name': 'Emperor Wu of Han', 'years': '156–87 BC', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The emperor who ruled Han China for fifty-four years — making Confucianism the creed of the state, shattering the Xiongnu, opening the Silk Road, and forging the enduring shape of imperial China.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Young Emperor', 'type': 'timeline',
             'intro': 'A boy emperor waits out his Taoist grandmother, then makes Confucianism the creed of the state, founds the Imperial Academy, and breaks the great lords with a cunning decree.', 'events': PHASE_RISE},
            {'id': 'war', 'label': '2 · The Xiongnu Wars', 'type': 'timeline',
             'intro': 'He tears up sixty years of appeasement and sends Wei Qing and Huo Qubing to shatter the Xiongnu — then turns his armies outward to double the empire.', 'events': PHASE_WAR},
            {'id': 'silk', 'label': '3 · Opening the World', 'type': 'timeline',
             'intro': 'He dispatches Zhang Qian on a thirteen-year journey into the unknown west, opens the Silk Road, and marches armies to Ferghana at the edge of the known world.', 'events': PHASE_SILK},
            {'id': 'state', 'label': '4 · Machinery of Empire', 'type': 'timeline',
             'intro': 'He funds his wars with salt-and-iron monopolies, rules by a blend of Confucian ideals and Legalist discipline, and grows obsessed with the search for immortality.', 'events': PHASE_STATE},
            {'id': 'end', 'label': '5 · The Twilight', 'type': 'timeline',
             'intro': 'A witchcraft terror engulfs the court and destroys his own heir — before the aged emperor publicly repents in the Luntai Edict and dies, leaving an empire transformed.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources, drawing on Sima Qian’s Records and Ban Gu’s History of the Han; dates follow the conventional chronology.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
