# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Lee Kuan Yew."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#dc2626'  # Singapore red

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_separation():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1965 · a nation nobody wanted to be — with nothing</text>'
    boxes=[(40,'#7f1d1d','Expelled from Malaysia','thrown out; independence forced, not chosen'),
           (270,'#dc2626','No resources at all','no land, no water, no hinterland, deep poverty'),
           (500,'#166534','Survive or perish','the fear of extinction becomes the spur to excel')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He wept on television at the separation — then turned the terror of a tiny, resourceless state into fuel.</text>'
    return _wrap(W, H, 'Independence — thrust upon a tiny island', _tk(b, W, H, 'Having nothing and no margin for error became Singapore’s discipline: excel, or cease to exist.'), '', AC)

def svg_firstworld():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the formula that made a swamp into a first-world city in one generation</text>'
    rows=[('#dc2626','Court global companies','clean, stable, low-corruption — invite the world’s factories'),
          ('#0369a1','Educate and house everyone','English + skills; near-universal home ownership (HDB)'),
          ('#166534','Absolute clean government','pay ministers well, punish corruption ruthlessly')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="42" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+21}" r="9" fill="{c}"/><text x="62" y="{y+25}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+18}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+34,s,9.3,'#5b6472',500,11,78); b+=ss
        y+=50
    return _wrap(W, H, 'From Third World to First — the model', _tk(b, W, H, 'Attract global capital, educate and house the people, and keep government spotlessly clean — repeated for 30 years.'), '', AC)

def svg_tradeoff():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the central, honest debate about his rule</text>'
    left = {'title':'What Singapore gained', 'color':'#166534',
            'lines':['first-world wealth in one generation','clean government; near-zero corruption','safety, housing, world-class education']}
    right = {'title':'What it traded away', 'color':'#7f1d1d',
             'lines':['a controlled press and limited dissent','defamation suits against opponents','detention without trial; strict social rules']}
    b += f'<rect x="40" y="58" width="300" height="96" rx="12" fill="#f0fdf4" stroke="{left["color"]}" stroke-width="1.7"/>'
    b += f'<text x="56" y="80" font-size="11.5" font-weight="800" fill="{left["color"]}">{left["title"]}</text>'
    yy=98
    for ln in left['lines']:
        b += f'<circle cx="60" cy="{yy-3}" r="2.6" fill="{left["color"]}"/>'
        ss,_=_tspans(72,yy,ln,9.4,'#5b6472',500,12,40); b+=ss; yy+=17
    b += f'<rect x="380" y="58" width="300" height="96" rx="12" fill="#fef2f2" stroke="{right["color"]}" stroke-width="1.9"/>'
    b += f'<text x="396" y="80" font-size="11.5" font-weight="800" fill="{right["color"]}">{right["title"]}</text>'
    yy=98
    for ln in right['lines']:
        b += f'<circle cx="400" cy="{yy-3}" r="2.6" fill="{right["color"]}"/>'
        ss,_=_tspans(412,yy,ln,9.4,'#5b6472',500,12,40); b+=ss; yy+=17
    return _wrap(W, H, 'Prosperity and its price — the great debate', _tk(b, W, H, 'His model delivered extraordinary results by curbing liberties others hold sacred — the trade-off is the whole argument about him.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING OF A LEADER
PHASE_RISE = [
    E('young', '1923–1945', 'A Straits Chinese boy and the shock of war', ['RISE', 'TRAGEDY'],
      'Born into an English-educated Straits Chinese family, his comfortable world is shattered by the brutal Japanese occupation of Singapore — an experience that teaches him, at first hand, hard lessons about power, fear, and how quickly order can collapse.',
      svg_stack('Lessons learned under occupation', [
          {'n': 1, 'label': 'Straits Chinese, English-schooled', 'sub': 'a bright, ambitious colonial-era boy', 'color': '#dc2626'},
          {'n': 2, 'label': 'The Japanese occupation', 'sub': 'brutality and chaos, 1942–45', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Learns how power really works', 'sub': 'survival, fear, and the fragility of order', 'color': '#b45309'},
      ], takeaway='The occupation taught him that power is real and order is fragile — lessons that shaped his whole philosophy of rule.', accent=AC),
      bg='<b>Singapore</b> was a British colony and a great trading port. Lee was born in <b>1923</b> into an English-educated <b>Straits Chinese</b> family.',
      people='His family; the Japanese occupiers whose brutality marked his youth.',
      what='Lee’s comfortable upbringing was upended by the <b>Japanese occupation (1942–45)</b>, a period of violence and hardship in which he learned to survive, trade on the black market, and observe how power and fear operated.',
      crux='The occupation gave him a <b>hard-headed, unsentimental view of power and human nature</b> — and a lifelong conviction that order and strength are prerequisites for everything else.',
      conseq='After the war he went to Britain to study, determined to master the tools of the colonial rulers.',
      matters='Formative shocks shape leaders. Lee’s wartime experience underlies his lifelong emphasis on security, order and survival.'),

    E('cambridge', '1946–1954', 'Cambridge, the law, and a political awakening', ['RISE', 'POLITICS'],
      'He studies law at Cambridge, graduating with a rare double-starred first, and returns to Singapore a brilliant lawyer with a burning anti-colonial ambition — to win independence and then run the place better than the British ever did.',
      svg_row('The making of a formidable politician', [
          {'n': 1, 'label': 'Cambridge law', 'sub': 'a rare double-starred first-class degree', 'color': '#dc2626'},
          {'n': 2, 'label': 'Anti-colonial conviction', 'sub': 'determined to end British rule', 'color': '#b45309'},
          {'n': 3, 'label': 'Returns as a labour lawyer', 'sub': 'builds a political base among unions', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He mastered the colonisers’ own tools — law and politics — to end their rule and replace it with his own.', accent=AC),
      bg='After the war, Lee studied in Britain, immersing himself in law and politics and sharpening his anti-colonial views.',
      people='His wife <b>Kwa Geok Choo</b>, herself a brilliant lawyer; the trade unionists who became his early base.',
      what='Lee earned a <b>double-starred first in law at Cambridge</b>, returned to Singapore, and built a political base as a <b>labour lawyer</b> representing unions and championing independence.',
      crux='He combined <b>elite education, formidable intellect and political cunning</b> with a genuine mission to free and then transform Singapore.',
      conseq='In 1954 he co-founded the party that would dominate Singapore for generations: the People’s Action Party.',
      matters='Lee turned a first-class mind to the practical work of nation-building — a rare fusion of intellect and iron will.'),
]

# ==================================================================  PHASE 2 — THE ROAD TO POWER
PHASE_POWER = [
    E('pap', '1954–1959', 'Founding the PAP and winning power', ['POLITICS', 'RISE'],
      'He co-founds the People’s Action Party, forms a risky alliance with the communists to build a mass base, then out-manoeuvres them — and in 1959 becomes the first Prime Minister of self-governing Singapore at just thirty-five.',
      svg_row('Riding the tiger to power', [
          {'n': 1, 'label': 'Founds the PAP, 1954', 'sub': 'an anti-colonial mass party', 'color': '#dc2626'},
          {'n': 2, 'label': 'Allies with the communists', 'sub': 'uses their mass base — a dangerous game', 'color': '#b45309'},
          {'n': 3, 'label': 'Wins power, 1959', 'sub': 'becomes PM of self-governing Singapore', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He harnessed the communists’ organising muscle to win power — then spent years breaking their grip.', accent=AC),
      bg='In the 1950s Singapore was moving toward self-government, with fierce competition between moderates, communists and colonial authorities.',
      people='His PAP co-founders; the communist and pro-communist factions he allied with and then fought; the British authorities.',
      what='Lee co-founded the <b>People’s Action Party (1954)</b>, formed a tactical alliance with the <b>communist-led left</b> to build mass support, and led the PAP to victory in <b>1959</b>, becoming Singapore’s first <b>Prime Minister</b> under self-government.',
      crux='He played a <b>dangerous double game</b> — using the communists’ organisational power while planning to outmanoeuvre them — showing the ruthless pragmatism that defined his career.',
      conseq='Lee then fought a prolonged, bitter struggle against his former communist allies for control of the left and of Singapore.',
      matters='Power often requires uncomfortable alliances. Lee’s willingness to ride the tiger — and then master it — was central to his rise.'),

    E('communists', '1961–1963', 'Breaking the communists — the fight for the left', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'His old allies turn into his deadliest rivals: the pro-communist left splits away and threatens to sweep him aside — until, in a sweeping security operation, scores of his opponents are detained without trial, decisively breaking the communist challenge and securing his grip on power.',
      svg_row('Mastering the tiger he had ridden', [
          {'n': 1, 'label': 'The left splits away', 'sub': 'pro-communists form a powerful rival party', 'color': '#dc2626'},
          {'n': 2, 'label': 'Operation Coldstore, 1963', 'sub': 'scores of opponents detained without trial', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'The challenge broken', 'sub': 'Lee’s control of the left is secured', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He crushed the communist challenge with detention without trial — winning power, and setting a hard precedent for his rule.', accent=AC),
      bg='The alliance that had helped Lee to power fractured, as the <b>pro-communist left</b> broke away and mounted a serious bid to take over.',
      people='The breakaway <b>Barisan Sosialis</b> and its leaders; the security services; the detainees held without trial.',
      what='As the pro-communist left surged, a major internal-security operation (<b>Operation Coldstore, 1963</b>) saw <b>scores of Lee’s political opponents detained without trial</b>, decisively weakening the communist challenge and consolidating his and the PAP’s dominance.',
      crux='He <b>defeated his most dangerous rivals through the coercive power of the state</b> — an effective but deeply controversial use of detention that foreshadowed his later methods.',
      conseq='The communist threat was broken and the PAP’s long dominance secured — but the episode remains fiercely debated as a use of security powers against political opponents.',
      matters='Lee’s rise was not only clever politics but hard state power. The breaking of the left shows both his effectiveness and the authoritarian streak that defined him.'),

    E('merger', '1963–1965', 'Merger with Malaysia — and disaster', ['POLITICS', 'TRAGEDY'],
      'Convinced tiny Singapore cannot survive alone, he leads it into a merger with Malaysia in 1963 — but racial politics and clashes with Kuala Lumpur turn the union toxic, culminating in deadly riots and an impossible position.',
      svg_row('A union that could not hold', [
          {'n': 1, 'label': 'Joins Malaysia, 1963', 'sub': 'seeking a hinterland and survival', 'color': '#dc2626'},
          {'n': 2, 'label': 'Racial and political clashes', 'sub': 'friction with Kuala Lumpur; communal tension', 'color': '#b45309'},
          {'n': 3, 'label': 'Deadly riots', 'sub': 'communal violence makes the union untenable', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='He bet Singapore’s future on merger — and watched it curdle into communal crisis within two years.', accent=AC),
      bg='Believing Singapore was too small to stand alone, Lee sought union with <b>Malaysia</b>, achieved in <b>1963</b>.',
      people='Malaysian leaders, especially PM <b>Tunku Abdul Rahman</b>; the communities caught in rising racial tension.',
      what='Singapore joined the Federation of <b>Malaysia (1963)</b>, but Lee’s vision of a multiracial "Malaysian Malaysia" clashed with Malay-dominant politics; friction and <b>communal riots</b> made the union unworkable.',
      crux='He had staked survival on merger, only to find the union torn apart by the very <b>racial politics</b> he had hoped to transcend.',
      conseq='By 1965 the relationship had broken down completely, leading Malaysia to expel Singapore.',
      matters='Even the best strategic bets can fail. The merger’s collapse set up the crisis that would define Lee and Singapore.'),
]

# ==================================================================  PHASE 3 — SEPARATION AND SURVIVAL
PHASE_SURVIVAL = [
    E('separation', '1965', 'The nation nobody chose to be', ['TURNING POINT', 'TRAGEDY'],
      'On 9 August 1965 Singapore is expelled from Malaysia and forced into an independence it never wanted — a tiny island with no natural resources, no water of its own, and a population many expected to fail. Lee weeps on television.',
      svg_separation(),
      bg='In <b>1965</b>, unable to reconcile with Kuala Lumpur, Singapore was <b>expelled from Malaysia</b> and became, against its will, an independent country.',
      people='Lee and his cabinet; a fearful population; skeptical foreign observers who doubted Singapore could survive.',
      what='On <b>9 August 1965</b> Singapore became independent — a tiny city-state with <b>no natural resources, no hinterland, dependent even on Malaysia for water</b>. Lee, devastated, <b>wept on television</b> announcing the separation.',
      crux='He faced the ultimate challenge: making a <b>resource-less micro-state survive and thrive</b> in a hostile region — with no margin for error.',
      conseq='Lee transformed this existential fear into a national discipline and a relentless drive to make Singapore indispensable to the world.',
      matters='Adversity can forge greatness. Singapore’s hopeless starting position became the spur for one of history’s great development stories.'),
]

# ==================================================================  PHASE 4 — THIRD WORLD TO FIRST
PHASE_FIRST = [
    E('invest', '1965–1980s', 'Courting the world’s factories', ['REFORM', 'TRIUMPH'],
      'Rejecting the fashionable anti-Western economics of the era, he does the opposite of his neighbours: he rolls out the red carpet for multinational corporations, offering them a stable, clean, English-speaking, strike-free base — and jobs pour in.',
      svg_firstworld(),
      bg='In the 1960s many newly independent states embraced protectionism and suspicion of foreign capital. Lee bet the other way.',
      people='The <b>Economic Development Board</b> and Lee’s technocrats; the multinational companies he courted; his deputy <b>Goh Keng Swee</b>, an economic architect.',
      what='Lee actively <b>courted multinational corporations</b>, offering political stability, low corruption, a skilled English-speaking workforce and labour peace — turning Singapore into a manufacturing and, later, financial hub.',
      crux='He grasped that a tiny state’s path to wealth was to make itself <b>indispensable to global business</b> — a first-world oasis of reliability in a turbulent region.',
      conseq='Foreign investment and industry flooded in, driving rapid growth and full employment.',
      matters='Lee proved a small, poor state could leapfrog to prosperity by welcoming global capital — a model studied worldwide.'),

    E('society', '1965–1990', 'Housing, schooling, and clean government', ['REFORM', 'TRIUMPH'],
      'He rebuilds society as deliberately as the economy: near-universal home ownership through public housing, world-class bilingual education, ruthless anti-corruption, and a greened, orderly city — turning a poor, divided port into a model of competence.',
      svg_stack('Engineering a first-world society', [
          {'n': 1, 'label': 'Homes for almost all', 'sub': 'public housing (HDB) and mass home ownership', 'color': '#dc2626'},
          {'n': 2, 'label': 'Education and English', 'sub': 'bilingual, skills-focused, meritocratic schooling', 'color': '#0369a1'},
          {'n': 3, 'label': 'Zero-tolerance corruption', 'sub': 'well-paid, spotlessly clean administration', 'color': '#166534'},
      ], takeaway='He built the society to match the economy — housing, schooling and clean governance, all engineered from the top.', accent=AC),
      bg='Economic growth alone was not enough; Lee set out to remake Singapore’s society, housing and institutions.',
      people='His technocratic ministers; the civil service he built into a byword for competence and integrity.',
      what='Lee drove <b>mass public housing</b> (with high home ownership), <b>bilingual and meritocratic education</b> with English as a working language, <b>ruthless anti-corruption</b>, and a relentless push for cleanliness, order and a "garden city."',
      crux='He treated <b>nation-building as engineering</b>: deliberately designing housing, education and institutions to create a stable, capable, cohesive society.',
      conseq='Within a generation Singapore had first-world living standards, one of the world’s cleanest governments, and a highly skilled population.',
      matters='Prosperity needs institutions, not just growth. Lee’s social engineering turned wealth into a stable, functioning first-world nation.'),

    E('corruption', '1960s–1990s', 'Clean hands — abolishing corruption by design', ['REFORM', 'TRIUMPH'],
      'He makes incorruptibility the foundation of the whole system: a powerful anti-graft bureau that can investigate anyone, ministers paid salaries high enough to remove temptation, and swift, merciless punishment for the corrupt — turning a region famous for graft into one of the cleanest governments on earth.',
      svg_row('Making honesty the only option', [
          {'n': 1, 'label': 'A fearless anti-graft bureau', 'sub': 'the CPIB can investigate anyone, even ministers', 'color': '#dc2626'},
          {'n': 2, 'label': 'Pay leaders like the private sector', 'sub': 'high salaries to remove the temptation to steal', 'color': '#0369a1'},
          {'n': 3, 'label': 'Punish ruthlessly', 'sub': 'the corrupt are disgraced and destroyed', 'color': '#166534'},
      ], edge_labels=['plus', 'plus'], takeaway='He attacked corruption from both ends — pay leaders well, then punish any theft without mercy.', accent=AC),
      bg='Corruption was endemic across the region; Lee saw clean government as essential both morally and to attract global investors.',
      people='The <b>Corrupt Practices Investigation Bureau (CPIB)</b>; ministers held to spotless standards; investors who trusted Singapore’s integrity.',
      what='Lee empowered the <b>CPIB</b> to investigate anyone without fear, <b>paid ministers and officials high salaries</b> to reduce temptation, and punished corruption <b>swiftly and severely</b> — making Singapore one of the least corrupt states in the world.',
      crux='He treated integrity as an <b>engineered outcome</b>: remove temptation through good pay, raise the certainty and severity of punishment, and enforce it at the very top.',
      conseq='Clean government became Singapore’s brand and a key competitive advantage in attracting global business.',
      matters='Corruption is not inevitable; it is a system that can be designed out. Lee’s clean-government model is studied by reformers worldwide.'),

    E('cpf', '1960s–1980s', 'The Central Provident Fund — forced thrift as nation-building', ['REFORM', 'TRIUMPH'],
      'He turns a compulsory savings scheme into the engine of the whole society: workers and employers pay into personal accounts that fund each citizen’s own home, healthcare and retirement — building mass home ownership and a self-reliant welfare model without a Western-style welfare state.',
      svg_stack('One fund, a whole social contract', [
          {'n': 1, 'label': 'Compulsory savings', 'sub': 'workers and employers pay into personal CPF accounts', 'color': '#dc2626'},
          {'n': 2, 'label': 'Buy your own flat', 'sub': 'CPF savings finance mass home ownership', 'color': '#0369a1'},
          {'n': 3, 'label': 'Self-reliant welfare', 'sub': 'healthcare and retirement without heavy state hand-outs', 'color': '#166534'},
      ], takeaway='He funded housing, health and retirement through forced personal saving — welfare through self-reliance, not hand-outs.', accent=AC),
      bg='Lee rejected what he saw as the dependency of Western welfare states, preferring a model of <b>compulsory self-reliance</b>.',
      people='Singapore’s workers and employers; the <b>Housing Development Board</b>, financed in part through CPF savings.',
      what='The <b>Central Provident Fund (CPF)</b> required workers and employers to pay into individual accounts used for <b>housing, healthcare and retirement</b>, powering mass <b>home ownership</b> and a distinctive, low-dependency social model.',
      crux='He built a welfare system around <b>individual responsibility and asset ownership</b> rather than redistribution — binding citizens to the nation through a stake in it.',
      conseq='Singaporeans became a nation of homeowners with funded retirements, and the state avoided large welfare deficits.',
      matters='Lee offered an influential alternative to Western welfare: mandatory saving and ownership, giving every citizen a personal stake in the country’s success.'),

    E('water', '1960s–2000s', 'Water — turning a fatal weakness into strength', ['REFORM', 'TURNING POINT'],
      'Independent Singapore’s deepest vulnerability is that it cannot even supply its own water, depending on Malaysia — so Lee makes water security a national obsession, building reservoirs, recycling, and eventually the technology to reclaim and desalinate, transforming an existential weakness into a point of pride and expertise.',
      svg_row('From dependence to self-sufficiency', [
          {'n': 1, 'label': 'Dependent on Malaysia', 'sub': 'a strategic vulnerability at independence', 'color': '#dc2626'},
          {'n': 2, 'label': 'A national water strategy', 'sub': 'reservoirs, catchment, conservation', 'color': '#0369a1'},
          {'n': 3, 'label': 'Recycling and desalination', 'sub': 'NEWater and desalination toward self-reliance', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='He turned the island’s most dangerous dependency into a showcase of engineering self-reliance.', accent=AC),
      bg='At independence Singapore relied on <b>Malaysia for much of its water</b> — a strategic weakness that could be used against it.',
      people='Lee and his planners; the water engineers of the <b>PUB</b>; later generations who built recycling and desalination.',
      what='Lee made <b>water security a top national priority</b>: building reservoirs and catchments, enforcing conservation, and driving the long-term development of <b>water recycling (NEWater)</b> and <b>desalination</b> to reduce dependence on imports.',
      crux='He converted an <b>existential vulnerability into a strategic capability</b>, refusing to leave the nation’s survival in another country’s hands.',
      conseq='Singapore moved toward water self-sufficiency and became a global centre of water technology.',
      matters='Great leaders obsess over their nation’s deepest vulnerabilities. Lee turned water — a potential noose — into an emblem of Singaporean ingenuity.'),

    E('defence', '1965–1970s', 'An army from nothing — the poison shrimp', ['REFORM', 'BATTLE'],
      'A tiny city-state surrounded by far larger neighbours needs credible defence, so Lee builds armed forces from scratch — quietly aided by Israeli advisers — and institutes national service for every young man, making Singapore a "poison shrimp": too small to threaten, but too painful to swallow.',
      svg_row('Deterrence for a tiny state', [
          {'n': 1, 'label': 'No real army in 1965', 'sub': 'a vulnerable city among bigger neighbours', 'color': '#dc2626'},
          {'n': 2, 'label': 'Build the SAF (with Israeli help)', 'sub': 'quiet foreign advisers train a new force', 'color': '#0369a1'},
          {'n': 3, 'label': 'National Service for all', 'sub': 'every young man serves — a citizen army', 'color': '#166534'},
      ], edge_labels=['so', 'then'], takeaway='He made a tiny nation indigestible — a "poison shrimp" no larger neighbour could swallow cheaply.', accent=AC),
      bg='Independent Singapore had almost no armed forces and faced potential threats from far larger neighbours.',
      people='The <b>Israeli military advisers</b> (discreetly labelled “Mexicans”) who helped build the army; the young men conscripted into <b>National Service</b>.',
      what='Lee built the <b>Singapore Armed Forces</b> from nothing — quietly aided by <b>Israeli advisers</b> — and introduced <b>compulsory National Service</b>, creating credible deterrence and a shared national institution.',
      crux='He pursued <b>deterrence through disproportionate cost</b>: too small to conquer others, Singapore would make itself too costly to attack — the “poison shrimp.”',
      conseq='Singapore developed one of the region’s most capable militaries and used National Service to forge national cohesion.',
      matters='Even the smallest state can secure itself through smart deterrence and shared sacrifice. Lee’s defence-building was nation-building too.'),

    E('language', '1960s–1980s', 'The language gamble — English as the great equaliser', ['REFORM', 'TURNING POINT'],
      'In a society split among Chinese, Malay and Tamil speakers, he makes a bold, contentious choice: English as the common working language, taught alongside each community’s mother tongue — a policy that binds a divided people, plugs Singapore into the global economy, and stirs lasting debate about culture and identity.',
      svg_row('One neutral language to unite and connect', [
          {'n': 1, 'label': 'A divided, multilingual society', 'sub': 'Chinese, Malay, Tamil communities', 'color': '#dc2626'},
          {'n': 2, 'label': 'English as the working language', 'sub': 'plus each community’s mother tongue', 'color': '#0369a1'},
          {'n': 3, 'label': 'Unity and global access', 'sub': 'a neutral link at home; a bridge to the world', 'color': '#166534'},
      ], edge_labels=['so', 'so'], takeaway='He chose a neutral common tongue to bind rival communities and wire the nation into the world economy.', accent=AC),
      bg='Singapore’s ethnic communities spoke different languages; a common tongue was needed both for unity and for global commerce.',
      people='The Chinese-, Malay- and Tamil-speaking communities; educators and, later, critics of the mother-tongue policy.',
      what='Lee made <b>English the common working language</b>, taught alongside each community’s <b>mother tongue</b> in a bilingual system — a controversial choice that provided a <b>neutral link among the races</b> and direct access to global business, science and finance.',
      crux='He picked a <b>neutral, globally useful language</b> over favouring any one community — sacrificing some cultural purity for unity and connection.',
      conseq='English gave Singapore a huge economic advantage and a common civic identity, though debates over language and culture continued.',
      matters='Language policy can make or break a plural society. Lee’s English gamble unified Singapore and linked it to the world — at a cost that is still debated.'),

    E('greening', '1963–1990s', 'The Garden City — cleanliness and order as strategy', ['REFORM', 'TRIUMPH'],
      'He personally champions a relentless campaign to green, clean and order the city — planting trees by the million, banning litter and chewing gum, enforcing strict fines — not as vanity but as a calculated signal to investors that Singapore is a competent, first-world place to do business.',
      svg_row('Order and greenery as an economic signal', [
          {'n': 1, 'label': 'A Garden City campaign', 'sub': 'millions of trees; a clean, green cityscape', 'color': '#166534'},
          {'n': 2, 'label': 'Strict rules and fines', 'sub': 'anti-litter laws; the famous chewing-gum ban', 'color': '#dc2626'},
          {'n': 3, 'label': 'A signal to the world', 'sub': 'proof of competence and order to investors', 'color': '#0369a1'},
      ], edge_labels=['plus', 'so'], takeaway='He greened and disciplined the city as a deliberate advertisement of first-world competence.', accent=AC),
      bg='Lee believed a clean, green, orderly environment was both good for citizens and a powerful signal of competence to the world.',
      people='The public servants who ran the campaigns; citizens subject to strict rules and fines; the investors Lee sought to impress.',
      what='Lee drove a sustained <b>“Garden City”</b> campaign — mass tree-planting, immaculate public spaces — alongside strict rules (anti-litter laws, the celebrated <b>chewing-gum ban</b>) enforced by fines, projecting order and competence.',
      crux='He understood that <b>a nation’s appearance and order are a form of branding</b> — visible proof to investors and citizens alike that the state works.',
      conseq='Singapore became famous for its cleanliness and greenery, reinforcing its image as a safe, efficient, first-world hub.',
      matters='Details signal competence. Lee’s obsession with order and greenery was strategy as much as aesthetics — a city that worked, on display.'),

    E('miracle', '1980s–1990s', 'The economic miracle complete', ['TRIUMPH'],
      'Within a single generation, Lee takes Singapore — in his own famous phrase — "from Third World to First": one of the richest, safest, best-run places on earth, and a global financial and shipping hub admired and studied around the world.',
      svg_row('One generation, a whole leap in development', [
          {'n': 1, 'label': 'A global hub', 'sub': 'finance, shipping, high-tech manufacturing', 'color': '#dc2626'},
          {'n': 2, 'label': 'First-world living', 'sub': 'among the highest incomes and lowest crime on earth', 'color': '#166534'},
          {'n': 3, 'label': 'A model studied worldwide', 'sub': 'leaders everywhere seek the "Singapore formula"', 'color': '#0369a1'},
      ], edge_labels=['so', 'so'], takeaway='He compressed a century of development into a single generation — the phrase "Third World to First" is literally his.', accent=AC),
      bg='By the 1980s and 90s the cumulative effect of Lee’s policies had transformed Singapore beyond recognition.',
      people='The generation of Singaporeans who rose with the country; the many world leaders who sought Lee’s advice.',
      what='Singapore became <b>one of the wealthiest and best-governed nations on earth</b> — a global financial, shipping and high-tech centre — the story Lee titled his memoirs <b>"From Third World to First."</b>',
      crux='He achieved a <b>development leap of extraordinary speed and completeness</b>, making a resource-less island one of the world’s most successful states.',
      conseq='Lee became a globally sought-after statesman, consulted by leaders from China to the West on governance and development.',
      matters='Singapore’s rise is one of the clearest proofs that governance quality, not resources, is the key to national success.'),
]

# ==================================================================  PHASE 5 — THE TRADE-OFF AND LEGACY
PHASE_END = [
    E('population', '1970s–1980s', 'Engineering the population — and overreaching', ['REFORM', 'DEFEAT'],
      'His faith in social engineering meets its limits in the bedroom: a harsh "Stop at Two" campaign cuts the birth rate — too well — and then his controversial belief that educated women should have more children sparks a public backlash, a rare case of Lee pushing his top-down instincts a step too far.',
      svg_row('When social engineering overreached', [
          {'n': 1, 'label': '“Stop at Two”', 'sub': 'a hard campaign to cut the birth rate', 'color': '#dc2626'},
          {'n': 2, 'label': 'It works too well', 'sub': 'fertility falls below replacement', 'color': '#b45309'},
          {'n': 3, 'label': 'The graduate-mother row', 'sub': 'urging educated women to have more children backfires', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='Even his social engineering had limits — the population policy overshot and the graduate-mother idea provoked real backlash.', accent=AC),
      bg='Believing population could be managed like any other national variable, Lee pursued assertive family-planning and, later, eugenics-tinged natalist policies.',
      people='Singaporean families subject to the campaigns; educated women targeted by the “graduate mother” policy; the voters who pushed back.',
      what='Lee’s <b>“Stop at Two”</b> campaign sharply cut fertility — eventually <b>below replacement</b> — and his subsequent, controversial push for <b>educated women to have more children</b> (the “graduate mother” policy) provoked a rare public <b>backlash</b> and was walked back.',
      crux='It exposed the <b>limits of top-down social engineering</b>: human choices about family resisted state direction, and his interventions overshot or offended.',
      conseq='Singapore was left with a persistent low-birth-rate challenge, and Lee learned that some domains resist even his methods.',
      matters='Not everything can be engineered from the top. Lee’s population missteps are a revealing counterpoint to his many successes.'),

    E('foreignpolicy', '1965–2000s', 'Punching above its weight — the global city-state', ['POLITICS', 'TRIUMPH'],
      'A tiny nation with no hinterland survives by being useful to everyone: Lee makes Singapore a trusted, neutral hub, a founder of ASEAN, and a friend to great powers on all sides — turning smallness into influence and making his own voice sought by leaders far larger than himself.',
      svg_row('Turning smallness into global influence', [
          {'n': 1, 'label': 'Be useful to all sides', 'sub': 'a trusted, neutral hub for trade and diplomacy', 'color': '#dc2626'},
          {'n': 2, 'label': 'Help found ASEAN', 'sub': 'regional stability to secure a small state', 'color': '#0369a1'},
          {'n': 3, 'label': 'A courted global voice', 'sub': 'great powers seek Lee’s counsel', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He made a city-state matter far beyond its size by being indispensable and trusted by everyone.', accent=AC),
      bg='A small state in a volatile region needed friends, stability and relevance to survive and prosper.',
      people='Fellow founders of <b>ASEAN</b>; leaders across the US, China and the region who valued Lee’s counsel.',
      what='Lee positioned Singapore as a <b>neutral, reliable hub</b>, helped found <b>ASEAN (1967)</b> for regional stability, and cultivated good relations with powers on <b>all sides</b> — making the tiny state, and his own analysis, influential far beyond its size.',
      crux='He grasped that a small state’s security lies in being <b>useful, trusted and relevant to everyone</b>, never wholly dependent on or hostile to any one power.',
      conseq='Singapore became a global diplomatic and economic hub, and Lee an internationally sought-after statesman.',
      matters='Size is not destiny in diplomacy. Lee’s Singapore shows how a small, well-run state can wield outsized influence through usefulness and trust.'),

    E('china', '1978–2011', 'Mentor to a rising China', ['POLITICS', 'TURNING POINT'],
      'His deepest global influence comes as an adviser to the giant next door: when Deng Xiaoping visits, Singapore becomes a model for China’s reforms, and for decades Lee is a uniquely trusted interlocutor between Beijing and the West — a small-state leader shaping the trajectory of the world’s largest nation.',
      svg_row('The small state that helped shape a superpower', [
          {'n': 1, 'label': 'Deng visits Singapore, 1978', 'sub': 'sees a Chinese-majority society that has succeeded', 'color': '#dc2626'},
          {'n': 2, 'label': 'A model for reform', 'sub': 'Singapore influences China’s opening and development', 'color': '#0369a1'},
          {'n': 3, 'label': 'A trusted bridge', 'sub': 'Lee counsels leaders in both Beijing and the West', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He became a mentor-figure to a rising China and a rare trusted bridge between it and the West.', accent=AC),
      bg='As China began its historic opening under <b>Deng Xiaoping</b>, its leaders looked for models of how a modernising, Chinese-majority society could prosper.',
      people='<b>Deng Xiaoping</b> and successive Chinese leaders; Western leaders who valued Lee’s reading of China.',
      what='After <b>Deng Xiaoping’s 1978 visit</b>, <b>Singapore became a reference point for China’s reforms</b>, and for decades Lee served as a <b>uniquely trusted adviser and interpreter</b> between Beijing and the West, his views on China sought by leaders worldwide.',
      crux='His blend of <b>Chinese heritage, Western training and proven success</b> made him an unmatched interlocutor as China rose — a small-state leader with a superpower’s ear.',
      conseq='Lee’s ideas influenced China’s development path, and his geopolitical analyses shaped how the West understood a rising China.',
      matters='Influence flows from credibility, not size. Lee’s counsel to a rising China may be the widest-reaching legacy of a leader from a tiny island.'),

    E('tradeoff', '1965–1990', 'Prosperity and its price', ['POLITICS', 'REFORM'],
      'His success came with a hard bargain that still defines the debate about him: extraordinary results delivered through a controlled press, defamation suits against critics, detention without trial, and strict social rules — a "soft authoritarian" model of order over unfettered liberty.',
      svg_tradeoff(),
      bg='Lee’s model delivered results by prioritising <b>order, stability and results over Western-style political liberty</b> — a trade-off he defended unapologetically.',
      people='Opposition politicians who faced defamation suits; detained activists; his many defenders and critics abroad.',
      what='Lee’s Singapore featured a <b>tightly controlled press</b>, <b>defamation suits</b> that bankrupted opponents, <b>detention without trial</b> of some critics, and strict social laws — while delivering wealth, safety and clean government. He argued "Asian values" justified prioritising order and the collective.',
      crux='He made a deliberate <b>trade of certain liberties for prosperity, order and competence</b> — the central and genuinely contested question of his legacy.',
      conseq='Singapore’s success made the model influential, but its limits on dissent drew persistent criticism from human-rights advocates.',
      matters='Lee poses one of the sharpest questions in modern governance: how much liberty is worth trading for order and prosperity? Reasonable people still disagree.'),

    E('legacy', '1990–2015', 'Stepping back, and the final years', ['DEATH', 'TURNING POINT'],
      'He gives up the premiership in 1990 but stays on for decades as "Senior Minister" and "Minister Mentor," guiding his successors and remaining Singapore’s guiding intelligence until his death in 2015 — mourned by a nation he had, quite literally, built.',
      svg_row('The architect steps back', [
          {'n': 1, 'label': 'Steps down as PM, 1990', 'sub': 'hands over but stays in the cabinet', 'color': '#dc2626'},
          {'n': 2, 'label': 'Mentor for decades', 'sub': '"Senior Minister," then "Minister Mentor"', 'color': '#b45309'},
          {'n': 3, 'label': 'Dies in 2015', 'sub': 'mourned by the nation he built', 'color': '#111827'},
      ], edge_labels=['then', 'then'], takeaway='He engineered his own succession and remained the nation’s guiding mind almost to the end.', accent=AC),
      bg='Lee stepped down as Prime Minister in <b>1990</b> in favour of Goh Chok Tong, but remained deeply influential in government for many years.',
      people='His successors <b>Goh Chok Tong</b> and his son <b>Lee Hsien Loong</b>; the nation that mourned him.',
      what='Lee handed over the premiership in <b>1990</b> but continued as <b>Senior Minister</b> and then <b>Minister Mentor</b>, shaping policy and mentoring leaders, until his <b>death in 2015</b>, which prompted an outpouring of national grief.',
      crux='He managed something rare — an <b>orderly, planned succession</b> and continued institutional influence — ensuring his system outlasted him.',
      conseq='Singapore remained stable and prosperous after him; Lee is revered as the nation’s founding father and studied as a model administrator.',
      matters='The mark of an institution-builder is what endures. Lee left not just a rich country but a system designed to keep running without him.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Lee Kuan Yew took a tiny, resource-less island — expelled into an independence it never wanted — and, in a single generation, turned it into one of the richest, safest and best-governed nations on earth. He is a study in <b>governance as engineering, pragmatism over ideology, clean and competent administration, and the hard trade-off of prosperity and order against political liberty.</b></p>
<div class="ov-quote">“We knew that if we were just like our neighbours, we would die.”<span>— Lee Kuan Yew</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A Straits Chinese boy is hardened by the Japanese occupation → studies law at Cambridge → founds the PAP and rides an alliance with the communists to power → leads Singapore into a merger with Malaysia that collapses → is forced into independence in 1965 with nothing → courts the world’s factories, houses and educates his people, and enforces clean government → lifts Singapore "from Third World to First" → does it through a soft-authoritarian bargain → and remains the nation’s guiding mind until his death in 2015.</p>
<div class="ov-lbl">Why he matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🏙️</div><h4>Third World to First</h4><p>One of history’s fastest, most complete development leaps.</p></div>
  <div class="ov-card"><div class="i">🧹</div><h4>Clean government</h4><p>He made competence and near-zero corruption a national brand.</p></div>
  <div class="ov-card"><div class="i">🧭</div><h4>Pragmatism over dogma</h4><p>He asked only "does it work?" — and courted global capital when others wouldn’t.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>The great trade-off</h4><p>Prosperity and order bought partly at the cost of political liberty.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Making of a Leader</b><small> 1923–54</small><p>Occupation, Cambridge, and political awakening.</p></div>
  <div><b>2 · The Road to Power</b><small> 1954–65</small><p>The PAP, and the doomed Malaysian merger.</p></div>
  <div><b>3 · Separation</b><small> 1965</small><p>Independence forced on a resource-less island.</p></div>
  <div><b>4 · Third World to First</b><small> 1965–90s</small><p>The economic and social miracle.</p></div>
  <div><b>5 · The Trade-off and Legacy</b><small> 1965–2015</small><p>Prosperity, its price, and the long farewell.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Kwa Geok Choo', 'role': 'wife / partner', 'color': '#dc2626',
     'bio': 'Lee’s wife, a brilliant lawyer in her own right and a trusted confidante throughout his career; their partnership was central to his life.',
     'rel': 'His life partner and closest confidante.'},
    {'name': 'Goh Keng Swee', 'role': 'economic architect', 'color': '#166534',
     'bio': 'A key deputy and economic mastermind who helped design Singapore’s development strategy, the Economic Development Board and its defence.',
     'rel': 'The economic architect behind the miracle.'},
    {'name': 'Tunku Abdul Rahman', 'role': 'Malaysian PM', 'color': '#b45309',
     'bio': 'Malaysia’s first prime minister, with whom Lee’s vision clashed, leading to Singapore’s expulsion from the Federation in 1965.',
     'rel': 'The leader who expelled Singapore into independence.'},
    {'name': 'Goh Chok Tong', 'role': 'successor PM', 'color': '#0369a1',
     'bio': 'Lee’s chosen successor as Prime Minister from 1990, under whom Lee served as Senior Minister.',
     'rel': 'The successor Lee groomed and handed power to.'},
    {'name': 'Lee Hsien Loong', 'role': 'son / later PM', 'color': '#7c3aed',
     'bio': 'Lee’s eldest son, who became Prime Minister of Singapore in 2004, continuing the family’s central role in the nation.',
     'rel': 'The son who later led the nation his father built.'},
]

KEY_EVENTS = [
    ('1923', 'Born in Singapore', 'A Straits Chinese, English-educated family.'),
    ('1942–45', 'Japanese occupation', 'Hard lessons in power and survival.'),
    ('1949', 'Cambridge law degree', 'A double-starred first.'),
    ('1954', 'Founds the PAP', 'An anti-colonial mass party.'),
    ('1959', 'Becomes Prime Minister', 'Of self-governing Singapore, at 35.'),
    ('1963', 'Merger with Malaysia', 'A search for survival that fails.'),
    ('1965', 'Expelled into independence', 'A resource-less island alone; Lee weeps.'),
    ('1965–90s', 'Third World to First', 'Foreign investment, housing, clean government.'),
    ('1990', 'Steps down as PM', 'Stays on as Senior Minister / Minister Mentor.'),
    ('2015', 'Death of Lee Kuan Yew', 'A nation mourns its founding father.'),
]

MASTER = [
    {'year': '1923', 'age': 'born', 'phase': 'The Making', 'title': 'Born in Singapore', 'desc': 'A colonial-era boyhood.'},
    {'year': '1949', 'age': 'age ~26', 'phase': 'The Making', 'title': 'Cambridge law', 'desc': 'A brilliant student returns.'},
    {'year': '1959', 'age': 'age 35', 'phase': 'To Power', 'title': 'Becomes PM', 'desc': 'Self-governing Singapore.'},
    {'year': '1963', 'age': 'age 40', 'phase': 'To Power', 'title': 'Merger with Malaysia', 'desc': 'A union that fails.'},
    {'year': '1965', 'age': 'age 42', 'phase': 'Separation', 'title': 'Independence', 'desc': 'Forced on a tiny island.'},
    {'year': '1970s', 'age': '50s', 'phase': 'The Miracle', 'title': 'The economic leap', 'desc': 'Global investment pours in.'},
    {'year': '1990', 'age': 'age 66', 'phase': 'Legacy', 'title': 'Steps down as PM', 'desc': 'Remains a mentor.'},
    {'year': '2015', 'age': 'age 91', 'phase': 'Legacy', 'title': 'Death', 'desc': 'The founding father mourned.'},
]

SOURCES = [
    ('Britannica — Lee Kuan Yew', 'https://www.britannica.com/biography/Lee-Kuan-Yew'),
    ('Gov.sg — Founding Prime Minister Lee Kuan Yew', 'https://www.gov.sg/'),
    ('Britannica — Singapore (history)', 'https://www.britannica.com/place/Singapore'),
    ('Wikipedia — Lee Kuan Yew', 'https://en.wikipedia.org/wiki/Lee_Kuan_Yew'),
]

def build_meta():
    return {
        'pid': 'gm-lky.html', 'kind': 'man', 'emoji': '🇸🇬', 'accent': AC,
        'name': 'Lee Kuan Yew', 'years': '1923–2015', 'group': 'Statesmen & Politicians',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'He took a tiny, resource-less island expelled into independence and, in one generation, built it "from Third World to First" — the archetype of governance as engineering.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Making of a Leader', 'type': 'timeline',
             'intro': 'A Straits Chinese boy is hardened by the brutal Japanese occupation, then masters the colonisers’ own tools — law and politics — at Cambridge, returning with a burning ambition to free and remake Singapore.', 'events': PHASE_RISE},
            {'id': 'power', 'label': '2 · The Road to Power', 'type': 'timeline',
             'intro': 'He founds the PAP, rides a dangerous alliance with the communists to power, and leads Singapore into a merger with Malaysia that curdles into communal crisis.', 'events': PHASE_POWER},
            {'id': 'survival', 'label': '3 · Separation', 'type': 'timeline',
             'intro': 'Expelled from Malaysia in 1965, Singapore is forced into an independence it never wanted — a tiny island with no resources and no margin for error.', 'events': PHASE_SURVIVAL},
            {'id': 'first', 'label': '4 · Third World to First', 'type': 'timeline',
             'intro': 'Rejecting the anti-Western economics of the age, he courts the world’s factories, houses and educates his people, and enforces spotless government — lifting Singapore to the first world in a generation.', 'events': PHASE_FIRST},
            {'id': 'end', 'label': '5 · The Trade-off and Legacy', 'type': 'timeline',
             'intro': 'His miracle came with a hard bargain — order and prosperity bought partly at the cost of liberty — before he stepped back and remained the nation’s guiding mind until his death in 2015.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Assessments of Lee’s human-rights record and "soft authoritarianism" are genuinely contested; this guide presents both his achievements and the criticisms of his methods.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
