# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Swami Vivekananda.
The monk who carried Vedanta and Yoga to the West and remade Hinduism as a creed of service and strength."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#d97706'  # saffron

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE MAKING OF NARENDRA
PHASE_ROOTS = [
    E('origins', '1863', 'Born Narendranath Datta in Calcutta', ['RISE', 'ORIGINS'],
      'On 12 January 1863 Narendranath Datta is born into a well-to-do Bengali Kayastha family of north Calcutta — his father Vishwanath a liberal, rationalist attorney at the High Court, his mother Bhuvaneshwari Devi devout and steeped in the epics, so that the boy grows up pulled between reason and religion.',
      svg_row('A gifted child of two worlds', [
          {'n': 1, 'label': 'Born in Calcutta, 12 Jan 1863', 'sub': 'a prosperous Bengali Kayastha family', 'color': '#d97706'},
          {'n': 2, 'label': 'Father Vishwanath, a rationalist lawyer', 'sub': 'mother Bhuvaneshwari, devout and learned', 'color': '#3730a3'},
          {'n': 3, 'label': 'Reason and faith in one house', 'sub': 'a mercurial, brilliant, questioning boy', 'color': '#166534'},
      ], edge_labels=['to', 'so'], takeaway='Narendra was raised in a home where a lawyer’s reason and a mother’s devotion met — the tension that would drive his whole search.', accent=AC),
      bg='<b>Narendranath Datta</b> — the future Swami Vivekananda — was born on <b>12 January 1863</b> in Calcutta, then capital of British India, into an affluent Bengali Kayastha family.',
      people='his father <b>Vishwanath Datta</b>, an attorney of the Calcutta High Court; his pious mother <b>Bhuvaneshwari Devi</b>; the wider Datta family of Simulia, north Calcutta.',
      what='Narendra grew up a <b>precocious, high-spirited child</b> — musical, athletic and headstrong — in a household that blended his father’s Western-leaning rationalism with his mother’s Hindu devotion and love of the <b>Ramayana</b> and <b>Mahabharata</b>.',
      crux='He inherited a <b>double temper</b> — a hunger for logical proof alongside a natural pull toward the spiritual.',
      conseq='That inner tension would send him searching for a faith that could satisfy the intellect as well as the heart.',
      matters='The great synthesiser of East and West was shaped from birth by a home that held both — reason and reverence under one roof.'),

    E('education', '1879–1884', 'Western learning and a restless intellect', ['RISE', 'IDEAS'],
      'At Presidency College and the Scottish Church College Narendra devours Western philosophy and science — Kant, Hegel, Spencer, Comte, John Stuart Mill and Darwin — earning a name as a brilliant, argumentative student, until the empiricism he absorbs begins to corrode the easy faith of his childhood.',
      svg_stack('A mind sharpened on Western thought', [
          {'n': 1, 'label': 'Presidency & Scottish Church College', 'sub': 'graduates in Western philosophy, 1884', 'color': '#3730a3'},
          {'n': 2, 'label': 'Reads Spencer, Mill, Hume, Kant', 'sub': 'logic, science and European philosophy', 'color': '#d97706'},
          {'n': 3, 'label': 'Faith meets the acid of reason', 'sub': 'inherited belief no longer satisfies him', 'color': '#a16207'},
      ], takeaway='He was no naïve believer — he came to religion only after Western philosophy had taught him to demand proof.', accent=AC),
      bg='Narendra studied at the <b>Metropolitan Institution</b> and then <b>Presidency College</b> and the <b>General Assembly’s Institution (Scottish Church College)</b>, graduating in 1884.',
      people='the Scottish principal <b>William Hastie</b>, who first spoke to him of Ramakrishna; the European philosophers he read — Spencer, Mill, Hume, Kant, Hegel, Comte, Darwin.',
      what='He became a <b>voracious, sceptical student</b>, mastering Western logic, science and philosophy and even corresponding with Herbert Spencer, while the rational temper he acquired left him <b>doubting the God of his upbringing</b>.',
      crux='He demanded that religion <b>withstand reason</b> — he would accept nothing he could not test against experience.',
      conseq='His doubts drove him to seek a teacher who could show him God, not merely argue about God.',
      matters='His later power came from this training — he could speak to the modern, questioning mind because he had been one himself.'),

    E('brahmo', '1880–1884', 'The Brahmo Samaj and a crisis of doubt', ['IDEAS', 'TURNING POINT'],
      'Drawn to the reformist Brahmo Samaj and its rational, image-less monotheism, the young Narendra still finds no certainty — tormented by the question of whether God can truly be known, he begins asking the religious leaders he meets one blunt, burning question: "Have you seen God?" — and none can answer yes.',
      svg_row('A seeker who wanted proof, not doctrine', [
          {'n': 1, 'label': 'Joins the Brahmo Samaj', 'sub': 'reformist, rational, image-less worship', 'color': '#3730a3'},
          {'n': 2, 'label': '“Have you seen God?”', 'sub': 'the question no teacher can answer', 'color': '#d97706'},
          {'n': 3, 'label': 'Doubt hardens into a quest', 'sub': 'he needs experience, not argument', 'color': '#b91c1c'},
      ], edge_labels=['yet', 'so'], takeaway='He would not settle for belief about God — he demanded a teacher who had actually seen Him.', accent=AC),
      bg='In his youth Narendra was drawn to the <b>Brahmo Samaj</b>, the reformist movement of Rammohan Roy and Keshab Chandra Sen that rejected idol-worship and preached a rational, monotheistic faith.',
      people='the Brahmo leader <b>Keshab Chandra Sen</b> and reformer <b>Debendranath Tagore</b>; the many holy men and preachers he questioned.',
      what='The Brahmo Samaj’s reason appealed to him, but gave no <b>direct experience of the divine</b>; famously he asked teacher after teacher, <b>“Sir, have you seen God?”</b> — and received no convincing answer until he met Ramakrishna.',
      crux='His crisis was not lack of belief but <b>lack of certainty</b> — he wanted to know God as fact, not accept Him on authority.',
      conseq='This unanswered question led him, in 1881, to the temple-priest of Dakshineswar who would say yes.',
      matters='The seeker’s honesty set the whole story in motion — his refusal of second-hand faith made him ready for a true master.'),
]

# ==================================================================  PHASE 2 — THE MASTER
PHASE_MASTER = [
    E('meeting', '1881', 'Meeting Ramakrishna at Dakshineswar', ['RISE', 'TURNING POINT'],
      'In November 1881 the doubting student finally meets Sri Ramakrishna Paramahamsa, the ecstatic priest of the Kali temple at Dakshineswar — and when he puts his old question, "Have you seen God?", the master answers without hesitation: "Yes, I see Him as clearly as I see you" — an answer that shakes and slowly captures him.',
      svg_stack('The question answered at last', [
          {'n': 1, 'label': 'Dakshineswar, November 1881', 'sub': 'the student meets the temple-priest', 'color': '#3730a3'},
          {'n': 2, 'label': '“Have you seen God?” — “Yes”', 'sub': 'Ramakrishna answers without a doubt', 'color': '#d97706'},
          {'n': 3, 'label': 'A sceptic begins to yield', 'sub': 'reason meets living realisation', 'color': '#166534'},
      ], takeaway='The one man who could answer his burning question became the master who reshaped his life.', accent=AC),
      bg='In <b>November 1881</b>, Narendra first visited <b>Sri Ramakrishna Paramahamsa</b> (Gadadhar Chattopadhyay), the mystic priest of the <b>Dakshineswar Kali Temple</b> outside Calcutta.',
      people='<b>Sri Ramakrishna</b>, his guru; <b>Rani Rasmani</b>’s temple where the master served; the fellow young disciples who would become monks with him.',
      what='When Narendra asked whether he had seen God, Ramakrishna replied that he saw Him <b>“as clearly as I see you, only far more intensely”</b> — a claim of direct realisation that no one had ever made to him before.',
      crux='Here the <b>doubter met a man of demonstrated experience</b> — realisation offered as fact, not as creed.',
      conseq='Though he resisted at first, Narendra was drawn back again and again, and became Ramakrishna’s foremost disciple.',
      matters='The meeting of the modern sceptic and the God-intoxicated saint is the hinge of the whole story — and of modern Hinduism.'),

    E('discipleship', '1881–1886', 'The making of a disciple', ['RISE', 'IDEAS'],
      'Over five years Ramakrishna patiently wins the argumentative young rationalist — teaching him that all religions are true paths to one Reality, tempering his pride, and steering him from the reformist Brahmo God toward the non-dual Vedanta — all while Narendra bears the sudden death of his father and the family’s plunge into poverty.',
      svg_row('Five years that transformed him', [
          {'n': 1, 'label': 'A patient master and a proud pupil', 'sub': 'Ramakrishna wins the sceptic over', 'color': '#3730a3'},
          {'n': 2, 'label': 'Father dies, 1884; family ruined', 'sub': 'Narendra tastes poverty and grief', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Turned toward Advaita Vedanta', 'sub': 'all faiths as paths to one Reality', 'color': '#d97706'},
      ], edge_labels=['while', 'toward'], takeaway='Ramakrishna did not crush his reason but ripened it — turning a Brahmo sceptic into a Vedantin.', accent=AC),
      bg='From 1881 to 1886 Narendra was Ramakrishna’s closest disciple, testing the master with hard questions even as he was slowly transformed.',
      people='<b>Ramakrishna</b>, teaching by love and example; the young disciples — the future Swamis Brahmananda, Premananda, Saradananda and others; his widowed mother, whom the family’s ruin left in want.',
      what='Ramakrishna taught him that <b>all religions lead to the same God</b> and drew him toward <b>Advaita Vedanta</b>; meanwhile the <b>sudden death of his father Vishwanath in 1884</b> plunged the family into poverty and deepened Narendra’s spiritual struggle.',
      crux='The master worked by <b>ripening, not breaking</b> — he let Narendra keep his reason while opening him to realisation.',
      conseq='By the time Ramakrishna fell ill, Narendra had become the natural leader of his band of young disciples.',
      matters='Discipleship here meant transformation, not submission — the pupil’s independent mind was preserved and turned to a larger end.'),

    E('passing', '1886', 'The master’s death and the vow of sannyasa', ['DEATH', 'TURNING POINT'],
      'Dying of throat cancer, Ramakrishna entrusts his young disciples to Narendra’s care and passes away at Cossipore on 16 August 1886 — and the grieving band, led by Narendra, gathers in a rented, half-ruined house at Baranagar to take formal monastic vows and live as a brotherhood of renunciants.',
      svg_stack('A brotherhood born from grief', [
          {'n': 1, 'label': 'Ramakrishna dies, 16 Aug 1886', 'sub': 'throat cancer, at Cossipore garden house', 'color': '#b91c1c'},
          {'n': 2, 'label': 'The disciples entrusted to Narendra', 'sub': 'he becomes their acknowledged leader', 'color': '#3730a3'},
          {'n': 3, 'label': 'The Baranagar Math, 1886', 'sub': 'young monks take sannyasa vows', 'color': '#d97706'},
      ], takeaway='The master’s death did not scatter his boys — Narendra bound them into the monastic order that would carry the mission.', accent=AC),
      bg='Ramakrishna developed <b>throat cancer</b> in 1885 and, after months of decline nursed by his disciples, died at the <b>Cossipore garden house</b> on <b>16 August 1886</b>.',
      people='the dying <b>Ramakrishna</b>; his widow <b>Sarada Devi</b>, the Holy Mother; the young disciples who now looked to Narendra as their head.',
      what='After the master’s death Narendra gathered the destitute young disciples in a dilapidated house at <b>Baranagar</b>, where in <b>1886</b> they took <b>formal vows of sannyasa</b> and founded the first monastery of the order — Narendra taking the name Vividishananda before later becoming Vivekananda.',
      crux='Out of loss came <b>organisation</b> — Narendra forged the scattered grievers into a committed monastic brotherhood.',
      conseq='The Baranagar Math became the seed of what would grow into the Ramakrishna Order and Mission.',
      matters='A movement survives its founder only if someone institutionalises it — Narendra was that someone.'),
]

# ==================================================================  PHASE 3 — THE WANDERING MONK
PHASE_WANDERING = [
    E('parivrajaka', '1888–1893', 'Years as a wandering monk', ['RISE', 'ODYSSEY'],
      'From 1888 the young monk sets out alone across India as a parivrajaka — a wandering mendicant with staff and begging-bowl — travelling the length of the subcontinent on foot and by rail, sheltering with paupers and princes alike, and seeing at first hand the crushing poverty of the Indian masses.',
      svg_row('India seen on foot', [
          {'n': 1, 'label': 'Sets out as a parivrajaka, 1888', 'sub': 'a wandering monk with staff and bowl', 'color': '#d97706'},
          {'n': 2, 'label': 'Traverses the whole subcontinent', 'sub': 'Himalayas to Cape Comorin, five years', 'color': '#3730a3'},
          {'n': 3, 'label': 'Confronts India’s mass poverty', 'sub': 'the suffering of the common people', 'color': '#b91c1c'},
      ], edge_labels=['across', 'and'], takeaway='The wandering years turned an inward-looking monk outward — he saw India’s poverty and vowed to serve it.', accent=AC),
      bg='In <b>1888</b> Narendra left the monastery to travel India as a <b>parivrajaka</b>, an itinerant monk owning nothing but a staff (<i>kamandalu</i>) and begging-bowl, for some five years.',
      people='the countless hosts he stayed with — scholars, peasants, dewans and rajas; the poor of India whose plight moved him deeply.',
      what='He wandered <b>the length and breadth of India</b>, from the Himalayas to the southern tip, living on alms, studying the country’s religions and conditions, and growing <b>convinced that India’s degradation was rooted in poverty and neglect of the masses</b>.',
      crux='The journey converted his spirituality into a <b>social conscience</b> — realisation must serve the suffering many.',
      conseq='It gave him the conviction, and the firsthand knowledge, that he would carry to the West and back.',
      matters='Direct exposure changed his mission — he came to see the service of the poor as the truest worship.'),

    E('kanyakumari', '1892', 'The rock at Kanyakumari', ['IDEAS', 'TURNING POINT'],
      'At the very southern tip of India, at Kanyakumari (Cape Comorin), in December 1892 the monk swims out to a rock and meditates for three days — and there resolves his mission: to lift India from her poverty and to carry her spiritual wisdom to the world, a plan that crystallises into the idea of going to America.',
      svg_stack('A vision at land’s end', [
          {'n': 1, 'label': 'Kanyakumari, December 1892', 'sub': 'the southernmost tip of India', 'color': '#3730a3'},
          {'n': 2, 'label': 'Three days of meditation on a rock', 'sub': 'he swims out and takes stock of India', 'color': '#d97706'},
          {'n': 3, 'label': 'A mission crystallises', 'sub': 'raise the poor; carry Vedanta abroad', 'color': '#166534'},
      ], takeaway='On the last rock of India he found his purpose — to serve his people and to speak for them to the world.', accent=AC),
      bg='At the end of his wanderings, in late <b>1892</b>, Vivekananda reached <b>Kanyakumari (Cape Comorin)</b>, the southernmost point of the Indian mainland.',
      people='the fishermen and villagers of the cape; the memory of Ramakrishna and the poor of India on his mind.',
      what='He <b>swam out to a rock in the sea and meditated for three days</b> (24–26 December 1892), taking stock of India’s past and future and resolving to work for the <b>uplift of the masses</b> and to seek help and a hearing in the West — the rock is today the Vivekananda Rock Memorial.',
      crux='Here his mission came into focus — <b>spiritual India and material help must meet</b>, and he would go abroad to make it happen.',
      conseq='The decision to attend the coming Parliament of Religions in Chicago was born on that rock.',
      matters='Every great enterprise needs its moment of resolve — Kanyakumari was Vivekananda’s.'),

    E('khetri', '1893', 'The Maharaja of Khetri and a new name', ['RISE', 'DRAMA'],
      'His passage to America is made possible by Raja Ajit Singh of Khetri, a devoted disciple who funds the voyage — and it is the Maharaja who suggests the monastic name by which the world will know him, "Vivekananda," and who provides the ochre robe and turban in which he will conquer Chicago.',
      svg_row('A patron, a name, a robe', [
          {'n': 1, 'label': 'Raja Ajit Singh of Khetri', 'sub': 'a devoted disciple and patron', 'color': '#3730a3'},
          {'n': 2, 'label': 'Funds the voyage to America', 'sub': 'and gives the ochre robe and turban', 'color': '#d97706'},
          {'n': 3, 'label': 'Takes the name “Vivekananda”', 'sub': 'suggested by the Maharaja himself', 'color': '#166534'},
      ], edge_labels=['who', 'and'], takeaway='A princely disciple gave him the means, the name and the very robe in which he would face the West.', accent=AC),
      bg='Among the many admirers of his wandering years was <b>Raja Ajit Singh of Khetri</b> in Rajputana, who became a close disciple and supporter.',
      people='<b>Raja Ajit Singh of Khetri</b>, his royal patron; the Madras disciples who also raised funds for the journey.',
      what='The Maharaja and other admirers <b>financed his passage to the United States</b>; it was <b>Ajit Singh who suggested the name “Vivekananda”</b> (from <i>viveka</i>, discrimination) and provided the distinctive <b>saffron robe and turban</b> he wore in America. Vivekananda set sail from Bombay on <b>31 May 1893</b>.',
      crux='Patronage turned resolve into reality — without Khetri’s support the voyage could not have happened.',
      conseq='On 30 July 1893 he reached Chicago to seek entry to the World’s Parliament of Religions.',
      matters='Great missions ride on quiet backers — a Rajput prince helped send Vedanta to the world.'),
]

# ==================================================================  PHASE 4 — CONQUEST OF THE WEST
PHASE_WEST = [
    E('chicago', '1893', 'Arrival in Chicago and a locked door', ['RISE', 'DRAMA'],
      'Reaching Chicago in July 1893, the unknown monk finds he has come too early, has no credentials to enter the Parliament, and is running out of money in an expensive city — until, near despair, he is helped by strangers and, crucially, by the Harvard professor J.H. Wright, who secures his place among the delegates.',
      svg_stack('An unknown monk almost turned away', [
          {'n': 1, 'label': 'Reaches Chicago, 30 July 1893', 'sub': 'too early, no credentials, funds low', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Prof. J.H. Wright intervenes', 'sub': 'the Harvard scholar vouches for him', 'color': '#3730a3'},
          {'n': 3, 'label': 'Admitted to the Parliament', 'sub': 'a delegate at the last moment', 'color': '#d97706'},
      ], takeaway='He nearly missed his moment — a chance meeting with a Harvard professor put the monk on the world stage.', accent=AC),
      bg='Vivekananda arrived in the United States in <b>July 1893</b> to attend the <b>World’s Parliament of Religions</b>, part of the Chicago World’s Columbian Exposition.',
      people='<b>Professor John Henry Wright</b> of Harvard, who championed him; the Boston and Chicago hosts who sheltered the penniless monk.',
      what='He found the Parliament would not open for weeks, that he lacked the required <b>credentials</b>, and that his money was dwindling; <b>Professor J.H. Wright</b> was so impressed that he wrote a letter of introduction — reportedly saying to ask Vivekananda for his credentials was <b>“like asking the sun to state its right to shine”</b> — and secured his admission.',
      crux='His breakthrough hung on <b>a single sympathetic scholar</b> who saw his stature at once.',
      conseq='On 11 September 1893 he took his place among the delegates and prepared to speak.',
      matters='History often turns on a chance encounter — Wright’s letter opened the door through which Vedanta walked into the West.'),

    E('speech', '1893', '“Sisters and Brothers of America”', ['TRIUMPH', 'TURNING POINT'],
      'On 11 September 1893 the young monk rises before the World’s Parliament of Religions and opens not with a formal address but with five words — "Sisters and Brothers of America" — that bring the seven-thousand-strong audience to its feet in a two-minute ovation, and in a few sentences he preaches tolerance and the acceptance of all religions.',
      svg_row('Five words that conquered a hall', [
          {'n': 1, 'label': 'Parliament of Religions, 11 Sep 1893', 'sub': 'the Art Institute of Chicago', 'color': '#3730a3'},
          {'n': 2, 'label': '“Sisters and Brothers of America”', 'sub': 'a two-minute standing ovation', 'color': '#d97706'},
          {'n': 3, 'label': 'Preaches tolerance and acceptance', 'sub': 'Hinduism as mother of all religions', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He won America not with argument but with warmth — a single fraternal greeting made him a sensation.', accent=AC),
      bg='The <b>World’s Parliament of Religions</b> opened on <b>11 September 1893</b> at the Art Institute of Chicago, the first global inter-faith gathering, before an audience of some seven thousand.',
      people='the vast Chicago audience; the assembled delegates of the world’s faiths; the American press that made him famous overnight.',
      what='Vivekananda opened his address with <b>“Sisters and Brothers of America,”</b> which drew a <b>two-minute standing ovation</b>; he then spoke of <b>religious tolerance and the universal acceptance of all faiths</b>, quoting that all rivers flow to the same sea, and became the sensation of the Parliament.',
      crux='He offered the West a <b>Hinduism of tolerance and universality</b>, not a rival dogma — and it electrified his hearers.',
      conseq='Overnight he became a celebrity, sought after for lectures across the United States.',
      matters='It was the moment Hindu thought entered the modern Western mind — one of the most famous speeches in the history of religion.'),

    E('lecturetours', '1893–1896', 'Lecture tours and the Vedanta Societies', ['RISE', 'IDEAS'],
      'Riding his Chicago fame, Vivekananda spends nearly three years lecturing across the United States and England — founding the Vedanta Society of New York in 1894, teaching Raja Yoga and Jnana Yoga, and gathering the Western disciples, among them the stenographer J.J. Goodwin, who take down and preserve his words.',
      svg_stack('Carrying Vedanta across the West', [
          {'n': 1, 'label': 'Lectures across the US, 1893–95', 'sub': 'New York, Boston, Detroit and beyond', 'color': '#3730a3'},
          {'n': 2, 'label': 'Vedanta Society of New York, 1894', 'sub': 'and teaching in England from 1895', 'color': '#d97706'},
          {'n': 3, 'label': 'Goodwin records the lectures', 'sub': '“Raja Yoga” and other books result', 'color': '#166534'},
      ], takeaway='He turned a single speech into a movement — societies, disciples and books that outlived his Western tours.', accent=AC),
      bg='After the Parliament, Vivekananda spent about <b>three years (1893–1896) lecturing in the United States and England</b>, spreading Vedanta and Yoga.',
      people='the English stenographer <b>J.J. Goodwin</b>, who recorded his lectures verbatim; American disciples such as the <b>Hale</b> family and <b>Josephine MacLeod</b>; the philosopher <b>William James</b>, whom he met.',
      what='He <b>founded the Vedanta Society of New York in 1894</b>, lectured widely on <b>Raja Yoga, Jnana Yoga, Bhakti and Karma Yoga</b>, and worked in London from 1895; his loyal amanuensis <b>J.J. Goodwin</b> transcribed the talks that became books such as <b>Raja Yoga (1896)</b>.',
      crux='He built <b>durable institutions and texts</b>, not just a reputation — Vedanta now had a home in the West.',
      conseq='He drew Western disciples who would follow him to India, and left societies that endure to this day.',
      matters='A speaker becomes a founder — Vivekananda planted Vedanta permanently in Western soil.'),

    E('nivedita', '1895–1898', 'Margaret Noble becomes Sister Nivedita', ['RISE', 'IDEAS'],
      'In London in November 1895 an Irish schoolteacher, Margaret Elizabeth Noble, hears Vivekananda lecture and is captivated — she follows him to India in 1898, takes the name Sister Nivedita ("the dedicated one"), and devotes her life to the education of Indian women and to the national cause.',
      svg_row('A Western disciple for India', [
          {'n': 1, 'label': 'Margaret Noble hears him, London 1895', 'sub': 'an Irish teacher, deeply moved', 'color': '#3730a3'},
          {'n': 2, 'label': 'Follows him to India, 1898', 'sub': 'initiated as Sister Nivedita', 'color': '#d97706'},
          {'n': 3, 'label': 'Devotes herself to Indian women', 'sub': 'a school in Calcutta; the national cause', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='He inspired Westerners not just to admire India but to serve her — Nivedita gave her life to it.', accent=AC),
      bg='Among those who heard Vivekananda lecture in <b>London in 1895</b> was <b>Margaret Elizabeth Noble</b>, an Irish-born teacher active in education reform.',
      people='<b>Margaret Noble / Sister Nivedita</b>, his devoted Western disciple; fellow Western followers <b>Sara Bull</b> and <b>Josephine MacLeod</b>, who supported his work.',
      what='Noble came to India in <b>1898</b>, was initiated by Vivekananda into <i>brahmacharya</i> and given the name <b>Sister Nivedita</b> (“the dedicated one”); she founded a <b>girls’ school in Calcutta</b> and became a champion of Indian women’s education and the freedom movement.',
      crux='He drew the West not only to Vedanta but to <b>the service of India herself</b> — disciples who gave everything.',
      conseq='Nivedita became one of the most beloved figures of the Indian renaissance and nationalist movement.',
      matters='His magnetism crossed cultures — an Irish teacher became an Indian saint in his service.'),
]

# ==================================================================  PHASE 5 — THE MISSION
PHASE_MISSION = [
    E('return', '1897', 'A hero’s return to India', ['TRIUMPH', 'POLITICS'],
      'Landing at Colombo in January 1897, the once-unknown monk is received across India as a conquering hero — feted from the south to Almora — and in a series of ringing lectures, later collected as "From Colombo to Almora," he calls on his countrymen to shake off weakness and reclaim pride in their own spiritual heritage.',
      svg_stack('The monk comes home in triumph', [
          {'n': 1, 'label': 'Lands at Colombo, January 1897', 'sub': 'welcomed as a national hero', 'color': '#d97706'},
          {'n': 2, 'label': '“From Colombo to Almora”', 'sub': 'ringing lectures the length of India', 'color': '#3730a3'},
          {'n': 3, 'label': 'A call to national self-respect', 'sub': 'reclaim pride in India’s heritage', 'color': '#166534'},
      ], takeaway='He returned not as a supplicant but as a herald — telling Indians to be proud and strong.', accent=AC),
      bg='Vivekananda returned to India in <b>January 1897</b>, landing at <b>Colombo</b> in Ceylon before a triumphal progress up the subcontinent.',
      people='the crowds and princes who feted him; the young men of Madras and Calcutta who took him as their leader; his brother-monks awaiting him.',
      what='He was received with <b>extraordinary acclaim</b>, delivering a famous series of lectures — later published as <b>“Lectures from Colombo to Almora”</b> — that urged Indians toward <b>self-confidence, national pride and the revival of their spiritual civilisation</b>.',
      crux='He preached <b>strength and self-respect</b> — that a spiritually great India need not feel inferior to the material West.',
      conseq='His message helped kindle the cultural nationalism that fed India’s independence movement.',
      matters='He gave a colonised people a source of pride — a spiritual nationalism that outlasted him.'),

    E('mission', '1897', 'Founding the Ramakrishna Mission', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'On 1 May 1897 in Calcutta, Vivekananda founds the Ramakrishna Mission — an organisation uniting monastic discipline with active social service, education, medical relief and famine work — giving institutional form to his conviction that serving the poor is itself the worship of God.',
      svg_row('Renunciation harnessed to service', [
          {'n': 1, 'label': 'Ramakrishna Mission, 1 May 1897', 'sub': 'founded in Calcutta by Vivekananda', 'color': '#d97706'},
          {'n': 2, 'label': 'Monks who serve, not only pray', 'sub': 'schools, hospitals, famine relief', 'color': '#3730a3'},
          {'n': 3, 'label': '“Service to man is service to God”', 'sub': 'the poor seen as living Narayana', 'color': '#166534'},
      ], edge_labels=['as', 'for'], takeaway='He fused the monastery and the hospital — making service to the poor the heart of monastic life.', accent=AC),
      bg='On <b>1 May 1897</b>, at Balaram Bose’s house in Calcutta, Vivekananda founded the <b>Ramakrishna Mission</b> to carry his master’s teaching into active social work.',
      people='his brother-monks — Swamis <b>Brahmananda</b> (first president), <b>Saradananda</b>, <b>Premananda</b> and others; the lay disciples who joined the work.',
      what='The Mission combined <b>renunciation with organised social service</b> — running schools, hospitals, orphanages and relief during famine and plague — on the principle of <b>“Atmano mokshartham jagad hitaya cha”</b> (for one’s own salvation and the good of the world).',
      crux='He turned Vedanta into <b>practical action</b> — the realisation of the divine in every human being expressed as service.',
      conseq='The Ramakrishna Mission grew into one of India’s great humanitarian and educational institutions, active worldwide today.',
      matters='He institutionalised compassion — a monastic order defined as much by its relief work as by its prayer.'),

    E('belurmath', '1899', 'Belur Math — the seat of the order', ['LEGACY', 'REFORM'],
      'In 1899 Vivekananda establishes the permanent headquarters of the Ramakrishna Order at Belur Math on the west bank of the Ganga near Calcutta — designing its central temple to blend Hindu, Christian and Islamic motifs as a symbol of the unity of all religions that his master had taught.',
      svg_stack('A temple to the unity of faiths', [
          {'n': 1, 'label': 'Belur Math established, 1899', 'sub': 'on the Ganga near Calcutta', 'color': '#d97706'},
          {'n': 2, 'label': 'The permanent seat of the order', 'sub': 'headquarters of Math and Mission', 'color': '#3730a3'},
          {'n': 3, 'label': 'Architecture blending all religions', 'sub': 'Hindu, Christian and Islamic motifs', 'color': '#166534'},
      ], takeaway='He built the order a lasting home — its very temple designed to embody the harmony of all faiths.', accent=AC),
      bg='In <b>1899</b> the Ramakrishna Order acquired a permanent home at <b>Belur</b>, on the western bank of the Hooghly (Ganga) opposite Calcutta.',
      people='the brother-monks who settled there; the disciples and donors who funded it; Sarada Devi, the Holy Mother, revered by the order.',
      what='Vivekananda founded <b>Belur Math</b> as the <b>headquarters of the Ramakrishna Math and Mission</b>; its main temple, conceived by him, deliberately combined <b>Hindu, Christian and Islamic architectural elements</b> to express the unity of religions.',
      crux='The Math gave the movement <b>permanence and identity</b> — a spiritual centre embodying its universal creed.',
      conseq='Belur Math remains the global headquarters of the Ramakrishna Order to this day.',
      matters='Institutions in stone outlast their founders — Belur Math is Vivekananda’s enduring seat.'),
]

# ==================================================================  PHASE 6 — TEACHINGS AND THE END
PHASE_LEGACY = [
    E('teachings', '1897–1902', 'Practical Vedanta — “Arise, awake”', ['IDEAS', 'LEGACY'],
      'At the core of his message is a "Practical Vedanta" — that every soul is potentially divine, that religion must be lived through strength and service rather than dogma or ritual — summed up in his tireless call, borrowed from the Katha Upanishad: "Arise, awake, and stop not till the goal is reached."',
      svg_row('A religion of strength and service', [
          {'n': 1, 'label': 'Each soul is potentially divine', 'sub': 'the goal: to manifest that divinity', 'color': '#3730a3'},
          {'n': 2, 'label': 'Service as worship of God', 'sub': 'the poor and sick as living Narayana', 'color': '#d97706'},
          {'n': 3, 'label': '“Arise, awake, stop not…”', 'sub': 'strength, fearlessness, self-reliance', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='He preached a muscular, practical Vedanta — divinity realised not in ritual but in strength and service.', accent=AC),
      bg='Vivekananda distilled Vedanta into a <b>practical, this-worldly creed</b> for the modern age, addressed as much to the weak and poor as to the learned.',
      people='the young Indians he exhorted to strength; the monks he trained to serve; the Western students of his Yoga books.',
      what='He taught that <b>“each soul is potentially divine”</b> and religion’s goal is to <b>manifest that divinity</b> through work, worship and knowledge; he preached <b>service to humanity as worship of God</b>, <b>fearlessness and strength</b> — “weakness is sin” — and rallied India with the Upanishadic cry <b>“Arise, awake, and stop not till the goal is reached.”</b>',
      crux='His genius was to make Vedanta <b>practical and empowering</b> — a philosophy of self-reliance and service, not withdrawal.',
      conseq='His teachings shaped modern Hinduism and inspired reformers, nationalists and seekers around the world.',
      matters='He redefined religion as strength and service — a message that still stirs India and beyond.'),

    E('secondtour', '1899–1900', 'The second voyage to the West', ['RISE', 'ODYSSEY'],
      'Though his health is failing, Vivekananda sails west a second time in June 1899 — founding the Vedanta Society of San Francisco and the Shanti Ashrama in California, lecturing in America and Europe, and meeting figures of the age before returning to India, exhausted, at the end of 1900.',
      svg_stack('One last mission abroad', [
          {'n': 1, 'label': 'Sails west again, June 1899', 'sub': 'with Sister Nivedita and Turiyananda', 'color': '#3730a3'},
          {'n': 2, 'label': 'Vedanta work in California', 'sub': 'San Francisco society; Shanti Ashrama', 'color': '#d97706'},
          {'n': 3, 'label': 'Returns to India, December 1900', 'sub': 'his health already broken', 'color': '#b91c1c'},
      ], takeaway='He spent his last strength abroad — planting Vedanta on the American West Coast before coming home to die.', accent=AC),
      bg='Despite declining health, Vivekananda undertook a <b>second journey to the West in June 1899</b>, travelling with Sister Nivedita and Swami Turiyananda.',
      people='<b>Sister Nivedita</b> and <b>Swami Turiyananda</b>, his companions; the Western disciples on the American West Coast; the Paris Congress of the History of Religions he attended in 1900.',
      what='He established the <b>Vedanta Society of San Francisco</b> and the <b>Shanti Ashrama</b> in northern California, lectured in the United States, England and France, then <b>returned to India in December 1900</b> in worsening health.',
      crux='He drove himself onward <b>against his failing body</b> — determined to spread the work while he still could.',
      conseq='The second tour extended Vedanta’s reach in America but left him gravely weakened.',
      matters='He burned himself out for the mission — the West Coast societies are a legacy of that final effort.'),

    E('death', '1902', 'Mahasamadhi at Belur Math, aged 39', ['DEATH', 'LEGACY'],
      'On the evening of 4 July 1902, at Belur Math, Vivekananda meditates, teaches his students, and passes away at around nine o’clock — at just thirty-nine — his disciples calling it mahasamadhi; he had foretold he would not live to forty, and left behind a reborn Hinduism and a worldwide order.',
      svg_row('A brief life, an immense legacy', [
          {'n': 1, 'label': 'Belur Math, 4 July 1902', 'sub': 'passes away in meditation, aged 39', 'color': '#b91c1c'},
          {'n': 2, 'label': 'He had foretold an early death', 'sub': '“I shall not live to be forty”', 'color': '#78350f'},
          {'n': 3, 'label': 'A reborn Hinduism endures', 'sub': 'the Mission, the message, the memory', 'color': '#d97706'},
      ], edge_labels=['as', 'and'], takeaway='He died at thirty-nine, spent in his own service — but his mission and message far outlived the man.', accent=AC),
      bg='By 1902 Vivekananda’s health — worn by diabetes, asthma and relentless work — had broken; he had told his followers he would not see forty.',
      people='the brother-monks and disciples at Belur Math; Sister Nivedita and the Western followers who mourned; the Holy Mother, Sarada Devi.',
      what='On <b>4 July 1902</b>, after a normal day of teaching and meditation, Vivekananda <b>died at Belur Math around 9 p.m. at the age of 39</b>; his disciples regard his passing as <b>mahasamadhi</b>, a conscious release. His birthday is now marked in India as <b>National Youth Day</b>.',
      crux='He gave everything in a <b>short, blazing life</b> — realisation, organisation and a message poured out in barely a decade of public work.',
      conseq='The Ramakrishna Mission he founded, and the confident Hinduism he preached, spread across India and the world.',
      matters='Few have done so much so fast — in nine public years Vivekananda remade Hinduism and carried it to the globe.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Swami Vivekananda was the monk who carried Vedanta and Yoga to the West and, in doing so, gave modern India a new confidence in itself. Born Narendranath Datta into a Calcutta family torn between reason and faith, he was a sceptical, brilliant student who demanded proof of God — until he met the mystic Ramakrishna, who claimed to have seen Him. As a wandering monk he confronted India’s poverty; at the 1893 Parliament of Religions in Chicago he stunned the West with five words — “Sisters and Brothers of America”; and he returned to found the Ramakrishna Mission, preaching a <b>Practical Vedanta of strength, service and self-respect.</b> He is the study in <b>reason married to realisation, and spirituality turned into service.</b></p>
<div class="ov-quote">“Arise, awake, and stop not till the goal is reached.”<span>— Swami Vivekananda, after the Katha Upanishad</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born a doubting Calcutta student who demanded proof of God → finds his master in Ramakrishna, who says he has seen Him → after the master’s death forges a monastic brotherhood and wanders India as a beggar-monk → resolves his mission on the rock at Kanyakumari → conquers the West at the 1893 Chicago Parliament of Religions → returns a hero and founds the Ramakrishna Mission and Belur Math → and dies at just thirty-nine, having remade Hinduism as a creed of service and strength.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🕉</div><h4>East meets West</h4><p>Made Vedanta and Yoga part of the modern Western mind.</p></div>
  <div class="ov-card"><div class="i">🤝</div><h4>Service as worship</h4><p>Turned renunciation into schools, hospitals and relief work.</p></div>
  <div class="ov-card"><div class="i">🔥</div><h4>Strength and self-respect</h4><p>Gave a colonised people pride in their own heritage.</p></div>
  <div class="ov-card"><div class="i">⚡</div><h4>A brief, blazing life</h4><p>Remade Hinduism in barely a decade — dead at 39.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Narendra</b><small> 1863–1884</small><p>A doubting student who demands proof of God.</p></div>
  <div><b>2 · The Master</b><small> 1881–1886</small><p>Ramakrishna, discipleship, and the vow of sannyasa.</p></div>
  <div><b>3 · The Wanderer</b><small> 1888–1893</small><p>Beggar-monk across India; the rock at Kanyakumari.</p></div>
  <div><b>4 · The West</b><small> 1893–1898</small><p>Chicago, the lecture tours, and Sister Nivedita.</p></div>
  <div><b>5 · The Mission</b><small> 1897–1899</small><p>Return in triumph; the Mission and Belur Math.</p></div>
  <div><b>6 · Teachings & End</b><small> 1897–1902</small><p>Practical Vedanta, a last tour, and mahasamadhi.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Sri Ramakrishna', 'role': 'his guru', 'color': '#d97706',
     'bio': 'The ecstatic priest of the Dakshineswar Kali temple (1836–1886) who claimed direct vision of God and became Vivekananda’s master, teaching the harmony of all religions.',
     'rel': 'The guru whose realisation answered his doubts and shaped his whole life.'},
    {'name': 'Sarada Devi', 'role': 'the Holy Mother', 'color': '#a16207',
     'bio': 'The wife and spiritual consort of Ramakrishna, revered by the order as the Holy Mother, who blessed Vivekananda’s mission to the West.',
     'rel': 'The Holy Mother whose blessing sanctioned his journey and work.'},
    {'name': 'Sister Nivedita', 'role': 'Western disciple', 'color': '#3730a3',
     'bio': 'Margaret Elizabeth Noble (1867–1911), the Irish teacher who followed him to India in 1898, took the name Nivedita, and devoted her life to Indian women’s education and nationalism.',
     'rel': 'His devoted Western disciple who gave her life to serving India.'},
    {'name': 'Raja Ajit Singh of Khetri', 'role': 'royal patron', 'color': '#166534',
     'bio': 'The Rajput ruler and disciple who financed Vivekananda’s voyage to America, suggested the name “Vivekananda,” and provided his saffron robe.',
     'rel': 'The prince who funded his journey and gave him his monastic name.'},
    {'name': 'J.J. Goodwin', 'role': 'stenographer disciple', 'color': '#b91c1c',
     'bio': 'The English stenographer who from 1895 recorded Vivekananda’s lectures verbatim, preserving the talks that became books such as Raja Yoga.',
     'rel': 'The disciple whose shorthand saved his teachings for posterity.'},
    {'name': 'Prof. J.H. Wright', 'role': 'Harvard champion', 'color': '#78350f',
     'bio': 'The Harvard professor of Greek who vouched for the credential-less monk, securing his admission to the 1893 Parliament of Religions.',
     'rel': 'The scholar whose letter opened the door to Chicago.'},
]

KEY_EVENTS = [
    ('1863', 'Narendranath Datta born', 'A Calcutta family of reason and faith.'),
    ('1881', 'Meets Ramakrishna', 'The master who says he has seen God.'),
    ('1886', 'Ramakrishna dies', 'Baranagar Math and the vow of sannyasa.'),
    ('1888', 'Wandering monk years begin', 'A parivrajaka across all India.'),
    ('1892', 'Kanyakumari meditation', 'His mission crystallises on the rock.'),
    ('1893', 'Sails for America', 'Funded by the Maharaja of Khetri.'),
    ('1893', 'Chicago speech, 11 Sep', '“Sisters and Brothers of America.”'),
    ('1894', 'Vedanta Society of New York', 'Vedanta plants roots in the West.'),
    ('1897', 'Ramakrishna Mission founded', 'Service to man as worship of God.'),
    ('1899', 'Belur Math established', 'Permanent seat of the order.'),
    ('1902', 'Mahasamadhi at 39', 'Dies at Belur Math, 4 July.'),
]

MASTER = [
    {'year': '1863', 'age': 'born', 'phase': 'Narendra', 'title': 'Born in Calcutta', 'desc': 'Narendranath Datta.'},
    {'year': '1881', 'age': 'age 18', 'phase': 'The Master', 'title': 'Meets Ramakrishna', 'desc': 'The doubter finds his guru.'},
    {'year': '1886', 'age': 'age 23', 'phase': 'The Master', 'title': 'Ramakrishna dies', 'desc': 'Baranagar Math; sannyasa.'},
    {'year': '1892', 'age': 'age 29', 'phase': 'The Wanderer', 'title': 'Kanyakumari', 'desc': 'His mission crystallises.'},
    {'year': '1893', 'age': 'age 30', 'phase': 'The West', 'title': 'Chicago speech', 'desc': '“Sisters and Brothers…”'},
    {'year': '1897', 'age': 'age 34', 'phase': 'The Mission', 'title': 'Ramakrishna Mission', 'desc': 'Renunciation plus service.'},
    {'year': '1899', 'age': 'age 36', 'phase': 'The Mission', 'title': 'Belur Math', 'desc': 'Seat of the order.'},
    {'year': '1902', 'age': 'age 39', 'phase': 'The End', 'title': 'Mahasamadhi', 'desc': 'Dies at Belur Math.'},
]

SOURCES = [
    ('Britannica — Vivekananda', 'https://www.britannica.com/biography/Vivekananda'),
    ('Wikipedia — Swami Vivekananda', 'https://en.wikipedia.org/wiki/Swami_Vivekananda'),
    ('Belur Math — Swami Vivekananda', 'https://belurmath.org/swami-vivekananda/'),
    ('Wikipedia — Vivekananda at the Parliament of the World’s Religions', "https://en.wikipedia.org/wiki/Swami_Vivekananda_at_the_Parliament_of_the_World's_Religions"),
    ('Art Institute of Chicago — Sisters and Brothers of America', 'https://www.artic.edu/articles/710/sisters-and-brothers-of-america-swami-vivekananda-in-chicago'),
    ('Parliament of the World’s Religions — 1893 Chicago', 'https://parliamentofreligions.org/parliament/1893-chicago/'),
    ('Sri Ramakrishna Math, Chennai — Swami Vivekananda', 'https://chennaimath.org/swami-vivekananda'),
]

def build_meta():
    return {
        'pid': 'gm-vivekananda.html', 'kind': 'man', 'emoji': '🕉', 'accent': AC,
        'name': 'Swami Vivekananda', 'years': '1863–1902', 'group': 'Sages, Poets & Philosophers',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Indian monk who carried Vedanta and Yoga to the West — electrifying the 1893 Chicago Parliament of Religions with “Sisters and Brothers of America” — and founded the Ramakrishna Mission, preaching a practical Vedanta of strength and service.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'roots', 'label': '1 · Narendra', 'type': 'timeline',
             'intro': 'Born Narendranath Datta into a Calcutta home of reason and faith, he grows into a brilliant, sceptical student who demands proof of God and finds none.', 'events': PHASE_ROOTS},
            {'id': 'master', 'label': '2 · The Master', 'type': 'timeline',
             'intro': 'He meets Ramakrishna, who answers his burning question, and over five years is transformed from doubter to disciple — until the master’s death makes him a monk and a leader.', 'events': PHASE_MASTER},
            {'id': 'wandering', 'label': '3 · The Wanderer', 'type': 'timeline',
             'intro': 'As a beggar-monk he crosses the whole of India, confronts its poverty, and resolves his mission on a rock at Kanyakumari — his passage to America funded by the Maharaja of Khetri.', 'events': PHASE_WANDERING},
            {'id': 'west', 'label': '4 · The West', 'type': 'timeline',
             'intro': 'An unknown monk almost turned away conquers the 1893 Chicago Parliament with five words, spends three years lecturing across the US and England, and draws Western disciples like Sister Nivedita.', 'events': PHASE_WEST},
            {'id': 'mission', 'label': '5 · The Mission', 'type': 'timeline',
             'intro': 'Returning to India a hero, he preaches national self-respect and founds the Ramakrishna Mission and Belur Math — giving his creed of service its lasting institutions.', 'events': PHASE_MISSION},
            {'id': 'legacy', 'label': '6 · Teachings & End', 'type': 'timeline',
             'intro': 'He distils a Practical Vedanta of strength and service, drives himself through a second Western tour, and dies at Belur Math at just thirty-nine — his mission remaking modern Hinduism.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies and the Ramakrishna Order’s own records; some episodes (such as the three-day meditation at Kanyakumari) are preserved through the order’s tradition and read as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
