# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Giacomo Casanova.
The Venetian adventurer, Enlightenment polymath and memoirist of an entire century."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#9d174d'  # Venetian rose-crimson

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — VENETIAN ORIGINS
PHASE_ORIGINS = [
    E('origins', '1725–1742', 'Born to the Venetian stage', ['RISE', 'ORIGINS'],
      'Giacomo Casanova is born in Venice to a pair of actors and raised largely by his grandmother while his mother tours the theatres of Europe — a sickly, precocious child who overcomes his frailty, is sent to Padua, and takes a law degree at seventeen, revealing an appetite for learning as boundless as his later appetite for life.',
      svg_row('A player’s son with a scholar’s mind', [
          {'n': 1, 'label': 'Venice, 2 April 1725', 'sub': 'son of the actors Gaetano and Zanetta', 'color': '#9d174d'},
          {'n': 2, 'label': 'Raised by his grandmother', 'sub': 'sickly boy; his mother tours Europe’s stages', 'color': '#a16207'},
          {'n': 3, 'label': 'Law degree at Padua, 1742', 'sub': 'a prodigy graduates at seventeen', 'color': '#166534'},
      ], edge_labels=['then', 'to'], takeaway='From a theatrical, unstable childhood emerged a restless intellect that would treat all of Europe as its stage.', accent=AC),
      bg='<b>Giacomo Casanova</b> was born on 2 April 1725 in Venice to Gaetano Casanova and Zanetta Farussi, both actors of the San Samuele theatre.',
      people='his actor parents <b>Gaetano</b> and <b>Zanetta</b>; the grandmother who raised him; the professors of Padua who schooled a prodigy.',
      what='A frail, nosebleed-prone child, Casanova was largely raised by his <b>grandmother</b> while his mother performed across Europe. Sent to <b>Padua</b>, he thrived, taking a <b>law degree at seventeen (1742)</b> while devouring languages, mathematics and philosophy.',
      crux='He was a <b>theatrical outsider with a first-class mind</b> — neither noble nor poor, equipped to charm and to reason his way through any society.',
      conseq='His learning and social fluency became the tools of a life lived by wit rather than birth.',
      matters='Genius unmoored from fixed station — Casanova’s in-between origins gave him both the hunger and the versatility to reinvent himself endlessly.'),

    E('seminary', '1742–1743', 'False starts in every calling', ['RISE', 'ORIGINS'],
      'Groomed for the Church, Casanova takes minor orders and enters a seminary — only to be expelled in scandal, the first of a lifetime of collapsed careers. Church, army and orchestra pit each claim him in turn, but none can hold a man who has decided that no single profession will ever contain him.',
      svg_stack('A man of no fixed profession', [
          {'n': 1, 'label': 'Minor orders in the Church', 'sub': 'groomed as an abbé for a clerical career', 'color': '#3730a3'},
          {'n': 2, 'label': 'Expelled from the seminary, 1743', 'sub': 'dismissed for scandalous conduct', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Soldier, then violinist', 'sub': 'a Corfu commission, then the San Samuele pit', 'color': '#a16207'},
      ], takeaway='Every respectable path he tried spat him out — pushing him toward the improvised, self-made life he would come to master.', accent=AC),
      bg='Casanova’s patrons intended a clerical career and he received minor orders, entering a Venetian seminary as a promising young <b>abbé</b>.',
      people='the churchmen who groomed him; the seminary that expelled him; the Venetian regiment and theatre that briefly employed him.',
      what='Casanova was <b>expelled from the seminary in 1743</b> for scandalous conduct, ending his clerical hopes. He then took an army commission bound for <b>Corfu</b>, abandoned it, and fell back on playing the <b>violin</b> in the San Samuele theatre orchestra.',
      crux='He could enter any profession but keep none — a pattern of <b>brilliant beginnings and abrupt ruptures</b> that defined his whole life.',
      conseq='Stripped of a settled career, he learned to live by charm, luck and improvisation.',
      matters='The self-invented life has no ladder — Casanova’s serial failures forced him to build a career out of pure adaptability.'),

    E('bragadin', '1746–1750', 'The making of a polymath', ['RISE', 'POLITICS'],
      'A chance kindness to an ailing Venetian nobleman wins Casanova a wealthy patron who half-believes him a wizard — and Casanova, ever the quick study, embraces the role, mastering the cabala, alchemy and the gaming table, and joining the Freemasons at Lyon to enter the secret networks that criss-crossed Enlightenment Europe.',
      svg_row('Occultist, gambler, freemason', [
          {'n': 1, 'label': 'Cures the patrician Bragadin', 'sub': 'wins a rich lifelong patron, c. 1746', 'color': '#9d174d'},
          {'n': 2, 'label': 'Cabala, alchemy and cards', 'sub': 'plays the magus; lives by the gaming table', 'color': '#5b21b6'},
          {'n': 3, 'label': 'Freemason at Lyon, 1750', 'sub': 'enters Europe’s secret fraternities', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='He turned a lucky bedside cure into a persona — the learned magus and man of the world who could walk into any court.', accent=AC),
      bg='Around 1746 Casanova nursed the ailing senator <b>Matteo Bragadin</b> back to health; the credulous patrician, believing him possessed of occult powers, adopted him as a son.',
      people='the senator <b>Matteo Bragadin</b>, his patron; the gamblers and mystics of Venice; the Masonic brothers of Lyon.',
      what='With Bragadin’s money and protection, Casanova cultivated a reputation as an <b>occultist versed in the cabala and alchemy</b>, supported himself as a <b>gambler</b>, and was <b>initiated as a Freemason at Lyon in 1750</b>, gaining entry to networks that spanned the continent.',
      crux='He learned to sell an <b>aura of mystery and learning</b> — half genuine erudition, half theatrical fraud — as his passport into elite society.',
      conseq='These arts and connections would sustain, and repeatedly imperil, him across decades of wandering.',
      matters='Reputation is a currency — Casanova minted his own, blending real knowledge with performance to open doors that birth had closed.'),
]

# ==================================================================  PHASE 2 — THE PIOMBI
PHASE_PRISON = [
    E('arrest', '1755', 'Venice turns on its native son', ['POLITICS', 'TRAGEDY', 'TURNING POINT'],
      'Casanova’s libertinism, occult dabbling and freethinking make him a marked man in the watchful Venetian Republic — and in the summer of 1755 the State Inquisitors strike, arresting him for affront to religion and decency and, without trial or stated term, condemning him to the dreaded prison beneath the Doge’s Palace.',
      svg_stack('Arrested by the Inquisitors of State', [
          {'n': 1, 'label': 'Denounced as a freethinker', 'sub': 'libertine, gambler, dabbler in magic', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Arrested, 26 July 1755', 'sub': '“affront to religion and common decency”', 'color': '#9d174d'},
          {'n': 3, 'label': 'Five years, no trial', 'sub': 'condemned by secret order to the Leads', 'color': '#78350f'},
      ], takeaway='The Republic that bred him now feared him — his freedom of mind and morals made him an enemy of the watchful Venetian state.', accent=AC),
      bg='The <b>Venetian Republic</b> policed heresy and immorality through its feared <b>Inquisitors of State</b>; Casanova’s reputation as a libertine and occultist made him a target.',
      people='the <b>State Inquisitors</b> of Venice; the informers who denounced him; the patrician establishment he had scandalised.',
      what='On <b>26 July 1755</b> Casanova was arrested for <b>“affront to religion and common decency,”</b> denounced as a magician and freethinker, and <b>sentenced without trial to five years</b> in the Piombi beneath the Doge’s Palace.',
      crux='He was punished less for a crime than for <b>who he was</b> — an unclassifiable free spirit the Republic could not tolerate.',
      conseq='He vanished into the harshest of Venice’s prisons, from which no one was thought to escape.',
      matters='Freedom of thought is dangerous to closed orders — Casanova’s very unclassifiability was treated as a threat to the state.'),

    E('piombi', '1755–1756', 'Prisoner under the leaden roof', ['TRAGEDY', 'POLITICS'],
      'The Piombi — named for the lead plates of the palace roof under which its cells were built — is a place of broiling summers, vermin and total isolation, with no fixed term and no appeal. Rather than break, Casanova studies his prison, hoards a smuggled iron bar, and begins, in secret and by inches, to plot the impossible.',
      svg_row('Life in the Leads of the Doge’s Palace', [
          {'n': 1, 'label': 'Cells beneath the lead roof', 'sub': 'the Piombi — “the Leads” of the palace', 'color': '#78350f'},
          {'n': 2, 'label': 'Heat, vermin, isolation', 'sub': 'no term, no appeal, no visitors', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A plan takes shape', 'sub': 'he hides a sharpened iron bar', 'color': '#166534'},
      ], edge_labels=['and', 'so'], takeaway='Where others despaired he calculated — turning idle observation and a single hidden tool into the seed of escape.', accent=AC),
      bg='The <b>Piombi</b> occupied the attic of the Doge’s Palace, directly under its <b>lead (piombo) roof</b> — stifling in summer, freezing in winter, and reserved for the Republic’s more prominent prisoners.',
      people='Casanova, the prisoner; his gaolers; the fellow inmate, the renegade monk <b>Father Balbi</b>, he would recruit.',
      what='Held in the <b>Leads</b> under a life of <b>heat, vermin and isolation</b> with no release in sight, Casanova refused to submit. He studied the building, secretly obtained and sharpened an <b>iron bar</b>, and began preparing a breakout.',
      crux='He answered hopeless confinement with <b>patient, meticulous planning</b> — treating escape as an engineering problem to be solved.',
      conseq='His preparations set up the most celebrated jailbreak of the eighteenth century.',
      matters='Method beats despair — Casanova endured the unendurable by turning his mind to the one problem that mattered: getting out.'),

    E('escape', '1756', 'The most famous escape of the age', ['TRIUMPH', 'BATTLE', 'TURNING POINT'],
      'On the night of 31 October 1756, Casanova and a fellow prisoner break through the ceiling, clamber out onto the leaden roof of the Doge’s Palace above sleeping Venice, force their way down into its grand state rooms, and walk out the front gate at dawn — an escape so audacious that he would dine out on the story for the rest of his life and later turn it into a bestselling book.',
      svg_stack('Over the roof of the Doge’s Palace', [
          {'n': 1, 'label': 'Up through the ceiling', 'sub': 'breaks out with the monk Father Balbi', 'color': '#9d174d'},
          {'n': 2, 'label': 'Across the leads by night', 'sub': 'over the palace roof, down into the state rooms', 'color': '#a16207'},
          {'n': 3, 'label': 'Free at dawn, 31 Oct 1756', 'sub': 'walks out; a gondola to the mainland', 'color': '#166534'},
      ], takeaway='He did what no one was supposed to do — and the flight from the Leads made him a legend across Europe overnight.', accent=AC),
      bg='No one was believed capable of escaping the <b>Piombi</b>. Casanova, with the monk <b>Father Balbi</b>, resolved to try the impossible.',
      people='<b>Casanova</b>; his accomplice <b>Father Marino Balbi</b>; the gaolers they outwitted; the Venice he fled forever.',
      what='On the night of <b>31 October 1756</b>, the pair broke through the cell ceiling onto the <b>lead roof</b>, descended into the palace’s state apartments, and bluffed their way out the gate at dawn, escaping by <b>gondola to the mainland</b> and abroad.',
      crux='He converted careful planning and sheer nerve into a <b>flawless, theatrical escape</b> — and understood at once its value as a story.',
      conseq='The exploit made his name across Europe; he retold it endlessly and published <b>Histoire de ma fuite</b> (Story of My Flight, 1788).',
      matters='A single unforgettable deed can define a life — the escape from the Leads gave Casanova a legend that opened every door in Europe.'),
]

# ==================================================================  PHASE 3 — THE GRAND TOUR
PHASE_TOUR = [
    E('paris', '1757', 'A fugitive conquers Paris', ['RISE', 'TRIUMPH'],
      'Arriving in Paris in the depths of winter, penniless but armed with his escape story, his learning and his dazzling manner, Casanova reinvents himself yet again — charming his way into the salons and the court, befriending ministers and financiers, and setting himself up as a gentleman of the world who would in time invent the noble title “Chevalier de Seingalt.”',
      svg_row('The escape artist charms a capital', [
          {'n': 1, 'label': 'Reaches Paris, Jan 1757', 'sub': 'penniless fugitive with a famous story', 'color': '#9d174d'},
          {'n': 2, 'label': 'Conquers the salons', 'sub': 'wit, learning and audacity open every door', 'color': '#a16207'},
          {'n': 3, 'label': 'Becomes a “gentleman”', 'sub': 'later styles himself Chevalier de Seingalt', 'color': '#166534'},
      ], edge_labels=['then', 'to'], takeaway='He arrived with nothing but a story and a manner — and made both into a passport to the heart of Parisian society.', accent=AC),
      bg='Casanova reached <b>Paris on 5 January 1757</b>, a penniless fugitive whose escape from the Leads had already made him famous.',
      people='the ministers, financiers and salon hostesses of Paris; the aristocracy he cultivated; the persona of <b>Chevalier de Seingalt</b> he would invent.',
      what='Trading on his <b>notoriety, charm and learning</b>, Casanova won entry to the salons and the court, befriending powerful figures. He recast himself as a man of quality, later adopting the self-conferred title <b>“Chevalier de Seingalt.”</b>',
      crux='He understood that in the fluid society of the Enlightenment, <b>reputation and manner could substitute for birth</b> — and he manufactured both.',
      conseq='His new standing set the stage for his single greatest coup: a role in the finances of the French crown.',
      matters='Self-fashioning is a real power — Casanova turned a story and a style into social capital in a Europe hungry for novelty.'),

    E('lottery', '1757', 'Financier of the French state lottery', ['POLITICS', 'REFORM', 'TRIUMPH'],
      'In a startling turn for a gambler, Casanova helps design and launch France’s first national lottery — winning over sceptical ministers with the mathematics of the odds, proving that the state could not lose over the long run, and being rewarded with a directorship and offices that make him, briefly, genuinely rich.',
      svg_stack('The gambler who banked the house', [
          {'n': 1, 'label': 'Proposes a state lottery, 1757', 'sub': 'to fund the École Militaire', 'color': '#3730a3'},
          {'n': 2, 'label': 'Wins the ministers with maths', 'sub': 'proves the odds favour the crown', 'color': '#9d174d'},
          {'n': 3, 'label': 'Made a lottery director', 'sub': 'grows rich on the receipts', 'color': '#166534'},
      ], takeaway='The professional gambler flipped the table — using probability to make the state, not the player, the sure winner.', accent=AC),
      bg='The French crown sought new revenue; the idea of a great public <b>lottery</b> to fund the École Militaire was in the air.',
      people='the French ministers and financiers who backed it; the mathematicians of the age; Casanova, its persuasive salesman.',
      what='Casanova helped promote and administer <b>France’s first national lottery (1757)</b>, the Loterie de l’École Militaire, arguing from <b>probability</b> that the state must profit over time. Rewarded with a <b>directorship and ticket offices</b>, he made a genuine fortune.',
      crux='He grasped the <b>mathematics of chance</b> better than the ministers — and turned that knowledge into money and standing.',
      conseq='For a time he lived as a wealthy man of affairs, though extravagance and restlessness would soon undo it.',
      matters='Casanova was no mere rake — his lottery coup shows a real command of finance and probability, the intellect behind the legend.'),

    E('durfe', '1757–1763', 'The alchemist and the great con', ['POLITICS', 'TRAGEDY'],
      'Casanova’s occult reputation now bears rotten fruit: he cultivates the fabulously rich and credulous Marquise d’Urfé, spinning an elaborate alchemical fantasy in which she will be reborn into a new body — and fleeces her over years in the boldest and most cynical swindle of his career, a reminder that the polymath was also, when it suited him, a charlatan.',
      svg_row('Genius and fraud, hand in hand', [
          {'n': 1, 'label': 'The Marquise d’Urfé', 'sub': 'immensely rich, obsessed with the occult', 'color': '#5b21b6'},
          {'n': 2, 'label': 'A rebirth scheme', 'sub': 'promises to reincarnate her soul by magic', 'color': '#9d174d'},
          {'n': 3, 'label': 'Fleeced over years', 'sub': 'the boldest, most cynical of his cons', 'color': '#b91c1c'},
      ], edge_labels=['met', 'then'], takeaway='The same theatrical brilliance that charmed courts could also deceive the desperate — Casanova was magus and swindler at once.', accent=AC),
      bg='The <b>Marquise d’Urfé</b> was a wealthy Parisian noblewoman consumed by a belief in alchemy and the occult — exactly the mark Casanova’s reputation attracted.',
      people='the deluded <b>Marquise d’Urfé</b>; the occult believers of Paris; Casanova, the confidence man in the magus’s robes.',
      what='Over several years Casanova exploited d’Urfé’s obsessions, promising through an elaborate <b>alchemical rite to have her soul reborn</b> in a new body, and extracting <b>vast sums</b> from her in what became the most notorious swindle of his life.',
      crux='He showed the <b>dark underside of his gifts</b> — the persuasion and learning that opened courts could also ruthlessly exploit the credulous.',
      conseq='The affair enriched him briefly but deepened his reputation as an adventurer to be watched and, eventually, expelled.',
      matters='Talent is morally neutral — Casanova’s story refuses easy heroism, pairing genuine brilliance with cold, elaborate fraud.'),
]

# ==================================================================  PHASE 4 — THE ENLIGHTENMENT
PHASE_MIND = [
    E('voltaire', '1760', 'Not merely a seducer — a man of the Enlightenment', ['POLITICS', 'TRIUMPH'],
      'Behind the libertine legend stands a genuine man of letters: a linguist, mathematician and writer who visits Voltaire at Ferney and spars with him over literature and religion, knows Rousseau, translates the Iliad, and moves as an equal among the philosophes — the side of Casanova that his reputation as a seducer has almost entirely eclipsed.',
      svg_compare('The legend against the fuller truth', {
          'head': 'The popular legend', 'color': '#b91c1c',
          'items': ['The greatest seducer of his age', 'A gambler, rake and libertine', 'Remembered only for his conquests'],
      }, {
          'head': 'The fuller truth', 'color': '#166534',
          'items': ['Linguist, mathematician and writer', 'Debated Voltaire at Ferney, 1760', 'Knew Rousseau and the philosophes', 'Translated the Iliad into Italian', 'A first-hand witness of his century'],
      }, verdict='Both are true — but the seducer has all but eclipsed the polymath.',
      takeaway='Casanova belonged to the Enlightenment as fully as to the boudoir — the mind is the half of him the legend forgot.', accent=AC),
      bg='By 1760 Casanova moved in the intellectual world of the <b>Enlightenment</b>, corresponding and conversing with its leading minds as he criss-crossed Europe.',
      people='<b>Voltaire</b>, whom he visited at Ferney; <b>Rousseau</b>; the philosophes, scientists and writers of the age.',
      what='Casanova <b>visited Voltaire at Ferney in 1760</b>, debating literature and religion with the great man, and moved among the era’s thinkers. He was a <b>linguist and mathematician</b> who wrote plays, essays and a translation of the <b>Iliad</b>, and later a science-fiction novel, <b>Icosameron.</b>',
      crux='He was a <b>full participant in the intellectual life</b> of his century, not merely its most famous libertine.',
      conseq='This engaged, observant mind is what made his eventual memoir a document of lasting historical value.',
      matters='The caricature obscures the man — Casanova’s true significance lies as much in his intellect as in his amours.'),

    E('monarchs', '1764–1765', 'Courting the crowned heads of Europe', ['POLITICS', 'RISE'],
      'In his decades of wandering, Casanova is received by the most powerful sovereigns of the age — welcomed by Frederick the Great in Berlin, who offers him a post, and granted audiences by Catherine the Great in St Petersburg, to whom he proposes a reform of the Russian calendar — the ultimate proof that this actor’s son had made himself a figure fit for the company of emperors.',
      svg_row('An adventurer among emperors', [
          {'n': 1, 'label': 'Frederick the Great, 1764', 'sub': 'received in Berlin; offered a tutor’s post', 'color': '#3730a3'},
          {'n': 2, 'label': 'Catherine the Great, 1765', 'sub': 'audiences in St Petersburg; a calendar plan', 'color': '#a16207'},
          {'n': 3, 'label': 'Received, never settled', 'sub': 'always moving on to the next court', 'color': '#166534'},
      ], edge_labels=['then', 'yet'], takeaway='Born to actors, he made himself the guest of kings — but could never anchor his brilliance to a single throne.', accent=AC),
      bg='Between the 1760s and 1780s Casanova wandered the <b>courts of Europe</b> — Berlin, St Petersburg, Warsaw, Madrid, Vienna and beyond — living by his wits.',
      people='<b>Frederick the Great</b> of Prussia; <b>Catherine the Great</b> of Russia; the courtiers, ministers and monarchs who received him.',
      what='In <b>1764</b> Casanova was received by <b>Frederick the Great in Berlin</b>, who offered him a position; in <b>1765</b> he gained audiences with <b>Catherine the Great in St Petersburg</b>, proposing a reform of the Russian <b>calendar</b>. He met kings and courtiers across the continent.',
      crux='His charm and reputation carried him to the <b>very summit of European society</b>, though he never secured a lasting place.',
      conseq='The endless wandering gave him an unmatched panorama of eighteenth-century Europe to record.',
      matters='Access without permanence — Casanova saw every court but belonged to none, the perfect observer of his age.'),

    E('franklin', '1783–1787', 'At the table of genius', ['POLITICS', 'REFORM'],
      'Casanova’s orbit touches the widest range of the age’s greatness: in Paris he debates the future of flight with Benjamin Franklin at the height of the balloon craze, and in Prague he moves in the circle of the librettist Lorenzo Da Ponte — placing him at the very edges of Mozart’s Don Giovanni, the operatic myth of the great seducer he himself had come to embody.',
      svg_stack('From Franklin’s balloons to Mozart’s stage', [
          {'n': 1, 'label': 'Benjamin Franklin, Paris 1783', 'sub': 'debates the steering of balloons', 'color': '#166534'},
          {'n': 2, 'label': 'Prague, 1787', 'sub': 'in the circle of the librettist Da Ponte', 'color': '#9d174d'},
          {'n': 3, 'label': 'The orbit of Don Giovanni', 'sub': 'Mozart’s opera of the great seducer', 'color': '#3730a3'},
      ], takeaway='He brushed against the age’s every kind of genius — science, letters and music — and even the myth that would outlive him.', accent=AC),
      bg='In his later wandering Casanova moved among the <b>scientific and artistic</b> luminaries of the age, from Enlightenment Paris to musical Prague.',
      people='<b>Benjamin Franklin</b>, met in Paris; the librettist <b>Lorenzo Da Ponte</b>; <b>Mozart</b>, whose Don Giovanni was staged in Prague.',
      what='In <b>Paris, 1783</b>, Casanova reportedly discussed the <b>steering of balloons</b> with <b>Benjamin Franklin</b> amid the ballooning craze; in <b>Prague, 1787</b>, he moved in the circle of <b>Da Ponte</b> as Mozart’s <b>Don Giovanni</b> — the opera of the archetypal seducer — was being staged.',
      crux='His life <b>intersected with genius of every kind</b>, science, letters and music, and even with the myth of the seducer itself.',
      conseq='These encounters cement his place as a connective thread running through the whole culture of his century.',
      matters='One life can touch an entire age — Casanova stands at the crossroads of the Enlightenment’s science, art and legend.'),
]

# ==================================================================  PHASE 5 — DUX AND THE MEMOIR
PHASE_END = [
    E('spy', '1774–1783', 'A spy, and exile once more', ['POLITICS', 'TRAGEDY'],
      'After eighteen years abroad, Casanova is at last allowed home to Venice — and, poacher turned gamekeeper, serves as a paid informer for the very Inquisitors who had jailed him. But the free spirit cannot be tamed: a stinging satire of a powerful patrician forces him out of his beloved city for the last time, a wanderer again with nowhere left to go.',
      svg_stack('Home, then banished again', [
          {'n': 1, 'label': 'Allowed home to Venice, 1774', 'sub': 'after eighteen years of exile', 'color': '#166534'},
          {'n': 2, 'label': 'Spies for the Inquisitors', 'sub': 'the poacher turned gamekeeper, 1776–82', 'color': '#78350f'},
          {'n': 3, 'label': 'A satire exiles him, 1783', 'sub': 'leaves Venice for the last time', 'color': '#b91c1c'},
      ], takeaway='He could return but never belong — the same untamable spirit that first got him jailed drove him from home for good.', accent=AC),
      bg='In <b>1774</b>, after nearly two decades of wandering, Casanova was permitted to return to <b>Venice</b>, the city that had imprisoned and exiled him.',
      people='the <b>Venetian Inquisitors</b> he now served; the patrician he satirised; the Venice he lost forever.',
      what='Back in Venice, Casanova worked as a <b>paid informer for the State Inquisitors (1776–82)</b> — the very body that had jailed him. A biting <b>satire</b> of an influential nobleman then forced him to leave the city permanently in <b>1783.</b>',
      crux='Even reconciled with the Republic, his <b>irrepressible pen and pride</b> made him unable to keep a settled place.',
      conseq='Homeless and ageing, he drifted toward the obscure Bohemian refuge where he would end his days.',
      matters='The rebel cannot be domesticated — Casanova’s final exile flowed from the same defiant nature that shaped his whole life.'),

    E('dux', '1785', 'Librarian at the edge of the world', ['TRAGEDY', 'POLITICS'],
      'Old, poor and out of options, Casanova accepts the post of librarian to Count Waldstein at the remote Castle of Dux in Bohemia — a quiet, bookish exile far from the salons and courts he once dazzled, where he is mocked by the servants and consumed by boredom, until he turns to the one refuge left to him: writing down his life.',
      svg_row('The wanderer comes to rest', [
          {'n': 1, 'label': 'Count Waldstein takes him in, 1785', 'sub': 'as librarian at Dux Castle, Bohemia', 'color': '#3730a3'},
          {'n': 2, 'label': 'Far from the salons', 'sub': 'lonely, ageing, mocked by the servants', 'color': '#78350f'},
          {'n': 3, 'label': 'He turns to the page', 'sub': 'begins his memoirs to relive his life', 'color': '#9d174d'},
      ], edge_labels=['to', 'so'], takeaway='Stranded in provincial obscurity, he found in memory and the pen the freedom the world had finally denied him.', accent=AC),
      bg='In <b>1785</b> the wealthy Bohemian nobleman <b>Count Joseph Karl von Waldstein</b> engaged the ageing Casanova as <b>librarian</b> at his <b>Castle of Dux</b> (Duchcov).',
      people='his last patron <b>Count Waldstein</b>; the castle servants who tormented him; the memory of the Europe he had roamed.',
      what='Casanova spent his final years at <b>Dux from 1785</b>, cataloguing the count’s library in a remote corner of Bohemia. <b>Lonely, bored and humiliated</b> by petty quarrels with the household, he sought escape in writing his <b>memoirs.</b>',
      crux='In his bleakest and most obscure years he found his <b>true and lasting vocation</b> — not adventure, but its recollection.',
      conseq='The tedium of Dux gave the world its greatest first-hand portrait of the eighteenth century.',
      matters='Great work can come from the lowest ebb — Casanova’s dreary exile produced the masterpiece that immortalised him.'),

    E('memoir', '1789–1798', 'The matchless portrait of an age', ['TRIUMPH', 'DEATH'],
      'At Dux, Casanova pours his whole extraordinary life into Histoire de ma vie — a vast, candid, twelve-volume memoir written in French that brings a whole century vividly back to life: its courts and cities, its great minds and small swindlers, its loves and losses. He dies in 1798, and only long after does the world discover that the famous seducer had left it a work of genius.',
      svg_stack('Story of My Life', [
          {'n': 1, 'label': 'Writes Histoire de ma vie', 'sub': 'twelve volumes, in French, from c. 1789', 'color': '#9d174d'},
          {'n': 2, 'label': 'A whole century revived', 'sub': 'courts, cities, loves and great minds', 'color': '#166534'},
          {'n': 3, 'label': 'Dies at Dux, 4 June 1798', 'sub': 'the memoir published long after his death', 'color': '#78350f'},
      ], takeaway='He set out to relive his life and instead preserved his age — the seducer’s truest conquest was the page.', accent=AC),
      bg='From around <b>1789</b> Casanova devoted himself at Dux to composing his life story in French, the language of the cultivated Europe he had known.',
      people='the countless figures of his memoir — lovers, monarchs, philosophers and rogues; the readers who would discover him a century on.',
      what='Casanova wrote <b>Histoire de ma vie (Story of My Life)</b>, a candid <b>twelve-volume memoir</b> covering his life to 1774. It is prized as a <b>matchless portrait of eighteenth-century Europe.</b> He died at Dux on <b>4 June 1798</b>; the work was published, in expurgated form, only from the 1820s onward.',
      crux='He transformed a scandalous life into an <b>enduring work of literature and history</b> — the record outlasting the reputation.',
      conseq='Long after his death, the manuscript established Casanova as a writer of the first rank and an indispensable witness to his century.',
      matters='He is remembered wrongly as only a seducer — his greatest achievement was to leave the Enlightenment its fullest self-portrait.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Giacomo Casanova is remembered as history’s great seducer — but he was far more: an Enlightenment adventurer and writer whose restless life touched nearly every corner of eighteenth-century Europe. Actor’s son, expelled seminarian, soldier, violinist, gambler, alchemist, spy and financier who helped launch the French state lottery, he escaped the Republic’s dreaded prison in the most famous jailbreak of the age, sparred with Voltaire, was received by Catherine and Frederick the Great, and moved in the orbit of Franklin and Mozart. In his final, obscure years as a castle librarian he wrote <b>Histoire de ma vie</b> — a matchless portrait of his century and the truest measure of his genius.</p>
<div class="ov-quote">“I have lived as a philosopher, and I die as a Christian.”<span>— Casanova, attributed last words</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born in Venice to actors and expelled from the seminary → drifts through the Church, army and orchestra before a rich patron and the occult arts make him a man of the world → is jailed in the Piombi and stages a legendary escape → conquers Paris and helps launch the French lottery → wanders the courts of Europe, meeting Voltaire, Catherine, Frederick, Franklin and Da Ponte → and ends as librarian at Dux Castle, where he writes the great memoir of his age.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🗝️</div><h4>The great escape</h4><p>Broke out of Venice’s Piombi in 1756 — the most famous jailbreak of the century.</p></div>
  <div class="ov-card"><div class="i">🎲</div><h4>Polymath adventurer</h4><p>Gambler, alchemist, spy and financier of the French state lottery.</p></div>
  <div class="ov-card"><div class="i">🧠</div><h4>Man of the Enlightenment</h4><p>Debated Voltaire; met Catherine, Frederick, Franklin and Da Ponte.</p></div>
  <div class="ov-card"><div class="i">📖</div><h4>Memoirist of an age</h4><p>Histoire de ma vie is a matchless portrait of 18th-century Europe.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Venetian Origins</b><small> 1725–1750</small><p>An actor’s son, expelled and self-invented.</p></div>
  <div><b>2 · The Piombi</b><small> 1755–1756</small><p>Arrest, the Leads, and a legendary escape.</p></div>
  <div><b>3 · The Grand Tour</b><small> 1757–1763</small><p>Paris, the lottery, and a great occult con.</p></div>
  <div><b>4 · The Enlightenment</b><small> 1760–1787</small><p>Voltaire, monarchs, Franklin and Mozart.</p></div>
  <div><b>5 · Dux & the Memoir</b><small> 1774–1798</small><p>Exile, the castle library, and Story of My Life.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Senator Bragadin', 'role': 'his first patron', 'color': '#a16207',
     'bio': 'The Venetian patrician Casanova nursed back to health around 1746; believing him gifted with occult powers, he adopted the young man and funded his early adventures.',
     'rel': 'The wealthy protector who launched him into the world.'},
    {'name': 'Voltaire', 'role': 'intellectual sparring partner', 'color': '#166534',
     'bio': 'The towering philosophe whom Casanova visited at Ferney in 1760, debating literature and religion — a meeting that reveals Casanova as a genuine man of the Enlightenment.',
     'rel': 'The great mind he engaged as an equal.'},
    {'name': 'Catherine the Great', 'role': 'monarch who received him', 'color': '#3730a3',
     'bio': 'The Empress of Russia who granted Casanova audiences in St Petersburg in 1765, to whom he proposed a reform of the Russian calendar.',
     'rel': 'One of the crowned heads who welcomed the adventurer.'},
    {'name': 'Lorenzo Da Ponte', 'role': 'friend and librettist', 'color': '#9d174d',
     'bio': 'The Venetian-born librettist of Mozart’s Don Giovanni, in whose Prague circle Casanova moved in 1787 — linking him to the operatic myth of the great seducer.',
     'rel': 'The friend who tied him to Mozart’s stage.'},
    {'name': 'Count Waldstein', 'role': 'his final patron', 'color': '#78350f',
     'bio': 'The Bohemian nobleman who, in 1785, engaged the ageing Casanova as librarian at his Castle of Dux, where the memoirist spent his last years and wrote Histoire de ma vie.',
     'rel': 'The patron of his final, most productive exile.'},
]

KEY_EVENTS = [
    ('1725', 'Born in Venice', 'Son of actors; a precocious, sickly child.'),
    ('1743', 'Expelled from the seminary', 'The first of many collapsed careers.'),
    ('1755', 'Arrested by the Inquisitors', 'Jailed in the Piombi for affront to religion.'),
    ('1756', 'Escape from the Leads', 'The most famous jailbreak of the age.'),
    ('1757', 'The French lottery', 'Helps launch and direct the state lottery.'),
    ('1760', 'Visits Voltaire at Ferney', 'The man of the Enlightenment.'),
    ('1764–65', 'Frederick and Catherine', 'Received by Europe’s greatest monarchs.'),
    ('1785', 'Librarian at Dux', 'Waldstein takes him in at his Bohemian castle.'),
    ('1798', 'Death at Dux', 'Leaves behind Histoire de ma vie.'),
]

MASTER = [
    {'year': '1725', 'age': 'born', 'phase': 'Venetian Origins', 'title': 'Born in Venice', 'desc': 'An actor’s son.'},
    {'year': '1755', 'age': 'age 30', 'phase': 'The Piombi', 'title': 'Jailed in the Leads', 'desc': 'Affront to religion.'},
    {'year': '1756', 'age': 'age 31', 'phase': 'The Piombi', 'title': 'The great escape', 'desc': 'Flees over the roof.'},
    {'year': '1757', 'age': 'age 32', 'phase': 'The Grand Tour', 'title': 'The French lottery', 'desc': 'Financier of the crown.'},
    {'year': '1785', 'age': 'age 60', 'phase': 'Dux & the Memoir', 'title': 'Librarian at Dux', 'desc': 'Refuge in Bohemia.'},
    {'year': '1798', 'age': 'age 73', 'phase': 'Dux & the Memoir', 'title': 'Death at Dux', 'desc': 'The memoir survives him.'},
]

SOURCES = [
    ('Britannica — Giacomo Casanova', 'https://www.britannica.com/biography/Giacomo-Casanova'),
    ('Wikipedia — Giacomo Casanova', 'https://en.wikipedia.org/wiki/Giacomo_Casanova'),
    ('Wikipedia — Histoire de ma vie', 'https://en.wikipedia.org/wiki/Histoire_de_ma_vie'),
    ('National Geographic — Inside the decadence of Casanova’s Venice', 'https://www.nationalgeographic.com/history/history-magazine/article/casanova-venice-italy-18th-century-decadence-pleasure-scandal'),
    ('FAMSF — Casanova: The Seduction of Europe', 'https://digitalstories.famsf.org/casanova/'),
]

def build_meta():
    return {
        'pid': 'gm-casanova.html', 'kind': 'man', 'emoji': '🗝️', 'accent': AC,
        'name': 'Giacomo Casanova', 'years': '1725–1798', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Venetian adventurer, Enlightenment polymath and memoirist — abbé, soldier, gambler, alchemist, spy and financier, who escaped the Leads, sparred with Voltaire and kings, and wrote the matchless portrait of his century.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'origins', 'label': '1 · Venetian Origins', 'type': 'timeline',
             'intro': 'Born in Venice to actors and expelled from the seminary, the young Casanova drifts through Church, army and orchestra before a rich patron and the occult arts make him a self-invented man of the world.', 'events': PHASE_ORIGINS},
            {'id': 'prison', 'label': '2 · The Piombi', 'type': 'timeline',
             'intro': 'The watchful Venetian Republic jails him for affront to religion in the dreaded Leads beneath the Doge’s Palace — from which he stages the most famous escape of the age.', 'events': PHASE_PRISON},
            {'id': 'tour', 'label': '3 · The Grand Tour', 'type': 'timeline',
             'intro': 'A penniless fugitive conquers Paris on charm and a story, helps launch the French state lottery, and reveals a darker gift in the great occult swindle of the Marquise d’Urfé.', 'events': PHASE_TOUR},
            {'id': 'mind', 'label': '4 · The Enlightenment', 'type': 'timeline',
             'intro': 'Behind the seducer stands a man of the Enlightenment: he spars with Voltaire, is received by Frederick and Catherine the Great, and moves in the orbit of Franklin and Mozart.', 'events': PHASE_MIND},
            {'id': 'end', 'label': '5 · Dux & the Memoir', 'type': 'timeline',
             'intro': 'Exiled from Venice for the last time, the ageing adventurer becomes librarian at a remote Bohemian castle — where boredom and memory yield Histoire de ma vie, the great portrait of his century.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources, drawing on Casanova’s own Histoire de ma vie; famous quips and last words attributed to him capture his outlook and are read as such.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
