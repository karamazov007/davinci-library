# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Steve Jobs."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#1f2937'  # Apple space-gray

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_woz():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the partnership that started it all in a garage</text>'
    b += '<rect x="40" y="60" width="300" height="82" rx="12" fill="#f0f9ff" stroke="#0369a1" stroke-width="1.7"/>'
    b += '<text x="54" y="82" font-size="11.5" font-weight="800" fill="#0369a1">Wozniak — the engineer</text>'
    s1,_=_tspans(54,100,'a genius who designs the Apple I and II circuit-boards himself',10,'#5b6472',500,12,44); b+=s1
    b += '<rect x="380" y="60" width="300" height="82" rx="12" fill="#f3f4f6" stroke="#1f2937" stroke-width="1.9"/>'
    b += '<text x="394" y="82" font-size="11.5" font-weight="800" fill="#1f2937">Jobs — the visionary</text>'
    s2,_=_tspans(394,100,'sees it as a product; sells, packages and dreams the company',10,'#1f2937',600,12,44); b+=s2
    b += '<line x1="352" y1="90" x2="368" y2="90" stroke="#94a3b8" stroke-width="1.6"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Woz could build the machine; Jobs saw it was a product the whole world would want.</text>'
    return _wrap(W, H, 'The two Steves — engineer and visionary', _tk(b, W, H, 'Jobs’ genius wasn’t engineering — it was seeing a finished product where others saw a hobbyist’s board.'), '', AC)

def svg_ousted():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1985 · fired from the company he founded</text>'
    boxes=[(40,'#1f2937','Recruits a CEO','hires Pepsi’s Sculley: “sell sugar water or change the world?”'),
           (270,'#b45309','Power struggle','the Mac undersells; the board sides with Sculley'),
           (500,'#7f1d1d','Forced out','Jobs is stripped of power and leaves Apple')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="82" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="101" x2="268" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="101" x2="498" y2="101" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">He later called getting fired the best thing that could have happened — it freed him to start again.</text>'
    return _wrap(W, H, 'The fall — fired from Apple', _tk(b, W, H, 'The humiliation of being fired from his own company became the making of him.'), '', AC)

def svg_return():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1997 · how he saved a company months from bankruptcy</text>'
    rows=[('#1f2937','Apple buys NeXT','Jobs returns; his NeXT software becomes Mac OS X'),
          ('#b45309','Ruthless focus','kills most products; keeps a tiny, clear lineup'),
          ('#166534','“Think Different”','rebuilds the brand around design and simplicity')]
    y=58
    for i,(c,t,s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="42" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="62" cy="{y+21}" r="9" fill="{c}"/><text x="62" y="{y+25}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="82" y="{y+18}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        ss,_=_tspans(82,y+34,s,9.3,'#5b6472',500,11,78); b+=ss
        y+=50
    return _wrap(W, H, 'The return — focus as strategy', _tk(b, W, H, 'He saved Apple not by adding but by subtracting — cutting the product line to a handful of great things.'), '', AC)

def svg_iphone():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">2007 · “three revolutionary products… it’s one device”</text>'
    boxes=[(40,'#1f2937','A widescreen iPod','music and video in your pocket'),
           (270,'#0369a1','A phone','calls, texts, contacts — reinvented'),
           (500,'#166534','The internet','a real web browser in your hand')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="70" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="82" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,100,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<rect x="250" y="140" width="220" height="30" rx="9" fill="#1f2937"/>'
    b += '<text x="360" y="160" font-size="11" font-weight="800" fill="#fff" text-anchor="middle">= one device: iPhone</text>'
    b += '<line x1="130" y1="130" x2="330" y2="140" stroke="#94a3b8" stroke-width="1.4" marker-end="url(#ah)"/>'
    b += '<line x1="360" y1="130" x2="360" y2="138" stroke="#94a3b8" stroke-width="1.4" marker-end="url(#ah)"/>'
    b += '<line x1="590" y1="130" x2="390" y2="140" stroke="#94a3b8" stroke-width="1.4" marker-end="url(#ah)"/>'
    return _wrap(W, H, 'The iPhone — three things in one', _tk(b, W, H, 'He fused three devices into one and, with the App Store, put a computer in everyone’s pocket.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE ADOPTED TINKERER
PHASE_RISE = [
    E('adopted', '1955–1972', 'An adopted boy in the Valley', ['RISE'],
      'Given up for adoption at birth and raised by a working-class couple in what would become Silicon Valley, he grows up tinkering with electronics with his father and absorbing the hobbyist culture that will soon birth the personal computer.',
      svg_stack('Formed by the Valley’s garage culture', [
          {'n': 1, 'label': 'Adopted at birth, 1955', 'sub': 'raised by Paul and Clara Jobs', 'color': '#1f2937'},
          {'n': 2, 'label': 'Tinkers with electronics', 'sub': 'learns craftsmanship from his adoptive father', 'color': '#b45309'},
          {'n': 3, 'label': 'Silicon Valley boyhood', 'sub': 'steeped in the hobbyist-computer culture', 'color': '#0369a1'},
      ], takeaway='He grew up in exactly the right place and time — the Valley as the personal computer was about to be born.', accent=AC),
      bg='Jobs was born in <b>1955</b> and adopted by <b>Paul and Clara Jobs</b>, growing up in the region that would become <b>Silicon Valley</b> as its electronics culture flourished.',
      people='His adoptive parents; his future partner <b>Steve Wozniak</b>, whom he met as a teenager.',
      what='Raised in the Valley, Jobs absorbed its <b>electronics and hobbyist culture</b>, learned craftsmanship from his father, and — as a teenager — met the engineering prodigy <b>Steve Wozniak</b>.',
      crux='He was shaped by a rare intersection of <b>place, time and personality</b>: an intense, aesthetically obsessive mind in the cradle of the coming computer revolution.',
      conseq='After a restless period, that combination would soon produce the personal-computer company Apple.',
      matters='Context makes the person. Jobs’ Valley boyhood put him at the exact spot where the digital age would ignite.'),

    E('reed', '1972–1976', 'Dropout, calligraphy, and India', ['RISE'],
      'He drops out of college after one semester but keeps auditing classes — including a calligraphy course that later shapes the Mac’s typography — travels to India seeking enlightenment, and returns a barefoot, intense seeker who fuses counterculture with technology.',
      svg_row('The unconventional education of a founder', [
          {'n': 1, 'label': 'Drops out of Reed', 'sub': 'but keeps auditing the classes he loves', 'color': '#1f2937'},
          {'n': 2, 'label': 'Studies calligraphy', 'sub': 'later inspires the Mac’s beautiful typefaces', 'color': '#b45309'},
          {'n': 3, 'label': 'Seeks meaning in India', 'sub': 'returns steeped in Zen and counterculture', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He wandered on purpose — and the "useless" calligraphy class became the soul of the Macintosh.', accent=AC),
      bg='In the early 1970s Jobs briefly attended <b>Reed College</b>, immersed himself in counterculture, Zen Buddhism and the search for meaning, and worked at <b>Atari</b>.',
      people='His college friends; the spiritual teachers he sought in <b>India</b>; his Atari colleagues.',
      what='Jobs <b>dropped out</b> of Reed after a semester but audited classes — famously <b>calligraphy</b>, which later inspired the Macintosh’s typography — traveled to <b>India</b> seeking enlightenment, and returned a barefoot, intense young seeker.',
      crux='He fused <b>counterculture aesthetics and spirituality with technology</b> — a blend of art and engineering that would define his products.',
      conseq='Back in the Valley, he reconnected with Wozniak and the local Homebrew Computer Club scene, on the cusp of founding Apple.',
      matters='Seemingly useless detours can become defining. Jobs’ calligraphy class is the classic example of curiosity paying off years later.'),

    E('bluebox', '1971–1975', 'The blue box — the first product, and a first deception', ['RISE', 'TURNING POINT'],
      'His partnership with Wozniak begins not with a computer but with mischief: together they build and sell "blue boxes" that let you make free long-distance calls by hacking the phone system — a first taste of turning Woz’s engineering into a product Jobs could sell, and, in the Atari "Breakout" episode, a first sign of Jobs’ willingness to cut a sharp deal even with his friend.',
      svg_row('The template — and its first shadow — appear early', [
          {'n': 1, 'label': 'Woz builds the blue box', 'sub': 'a device to hack free phone calls', 'color': '#1f2937'},
          {'n': 2, 'label': 'Jobs sells it', 'sub': 'the first Woz-builds / Jobs-sells product', 'color': '#0369a1'},
          {'n': 3, 'label': 'The Breakout episode', 'sub': 'reportedly shorts Woz on an Atari bonus', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'later'], takeaway='The pattern that built Apple — Woz engineers, Jobs sells — began with a phone-hacking gadget, sharp edges and all.', accent=AC),
      bg='Before Apple, Jobs and Wozniak collaborated on early projects that revealed their complementary talents — and Jobs’ sometimes ruthless streak.',
      people='<b>Steve Wozniak</b>, the engineer; the counterculture "phone phreaks" whose blue boxes they copied; Atari, where Jobs briefly worked.',
      what='Jobs and Wozniak built and sold <b>“blue boxes”</b> (devices to hack the phone network for free calls) — their first product together — and in the Atari <b>“Breakout”</b> job Jobs reportedly <b>underpaid Woz</b> on a bonus, an early sign of his hard edge.',
      crux='The <b>Woz-builds/Jobs-sells template</b> that would create Apple appeared here — as did the first hint of Jobs’ willingness to cut a sharp deal, even with a friend.',
      conseq='The partnership and pattern were set; a few years later they applied them to the personal computer.',
      matters='Founding partnerships often rehearse their dynamics early. The blue box shows both the genius and the ruthlessness that would define Jobs.'),
]

# ==================================================================  PHASE 2 — FOUNDING APPLE
PHASE_APPLE = [
    E('garage', '1976–1977', 'Two Steves and a garage', ['RISE', 'TRIUMPH'],
      'With Wozniak building the machines and Jobs seeing them as products the world would want, they found Apple, sell the hand-built Apple I, and then launch the Apple II — one of the first massively successful personal computers.',
      svg_woz(),
      bg='In 1976 the personal computer was a hobbyist’s toy. <b>Steve Wozniak</b> had designed an elegant machine; Jobs saw a business.',
      people='Co-founder <b>Steve Wozniak</b>, the engineering genius; early investor <b>Mike Markkula</b>, who provided funding and business sense.',
      what='Jobs and Wozniak founded <b>Apple</b> in 1976, sold the hand-built <b>Apple I</b>, and in 1977 launched the <b>Apple II</b> — a friendly, mass-market personal computer that became a huge success.',
      crux='Jobs’ contribution was not engineering but <b>product vision and taste</b>: seeing Woz’s circuit board as a finished, desirable product for ordinary people.',
      conseq='The Apple II made the company a leader of the emerging PC industry and set up a blockbuster public offering.',
      matters='Great products need both a builder and a visionary. Apple was born from the marriage of Woz’s engineering and Jobs’ taste.'),

    E('mac', '1979–1984', 'The Macintosh and the graphical revolution', ['TRIUMPH', 'REFORM', 'TURNING POINT'],
      'Inspired by ideas he sees at Xerox PARC, he drives the creation of the Macintosh — the computer that brings the mouse and graphical desktop to ordinary people — and launches it with the legendary "1984" Super Bowl ad.',
      svg_stack('Bringing the GUI to the masses', [
          {'n': 1, 'label': 'Sees the future at Xerox PARC', 'sub': 'the mouse and graphical interface', 'color': '#1f2937'},
          {'n': 2, 'label': 'Drives the Macintosh', 'sub': 'a computer "for the rest of us"', 'color': '#b45309'},
          {'n': 3, 'label': 'The "1984" ad', 'sub': 'a legendary Super Bowl launch', 'color': '#166534'},
      ], takeaway='He took the graphical interface out of a research lab and put it on desks around the world.', accent=AC),
      bg='At <b>Xerox PARC</b>, Jobs saw the <b>graphical user interface</b> and mouse — brilliant research that Xerox had failed to commercialise.',
      people='The Macintosh team he drove hard; the ad agency behind the "1984" commercial; Apple CEO <b>John Sculley</b>, whom Jobs recruited from Pepsi.',
      what='Jobs championed the <b>Macintosh (1984)</b>, popularising the <b>mouse and graphical desktop</b> for ordinary users, and launched it with the iconic <b>"1984" Super Bowl commercial</b>.',
      crux='He excelled at <b>recognising and productising others’ innovations</b> — turning PARC’s research into a machine "for the rest of us," wrapped in unforgettable marketing.',
      conseq='The Mac defined the future of personal computing — but its early sales disappointed, fuelling a clash with Sculley.',
      matters='Vision plus taste plus marketing changes industries. The Mac set the template for how we all use computers today.'),

    E('ipo', '1980', 'The IPO — a millionaire at twenty-five', ['TRIUMPH', 'RISE'],
      'Apple’s explosive growth culminates in one of the most spectacular stock-market debuts in history: its 1980 public offering makes Jobs, at just twenty-five, worth over two hundred million dollars, and mints hundreds of Apple millionaires overnight — proof that the personal computer had become a world-changing business.',
      svg_row('The garage startup becomes a public giant', [
          {'n': 1, 'label': 'Explosive growth', 'sub': 'the Apple II drives soaring sales', 'color': '#1f2937'},
          {'n': 2, 'label': 'The 1980 IPO', 'sub': 'one of the biggest debuts since Ford', 'color': '#0369a1'},
          {'n': 3, 'label': 'Rich at 25', 'sub': 'Jobs worth $200M+; hundreds of new millionaires', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='In four years he went from a garage to one of the great IPOs in history — rich, famous, and only twenty-five.', accent=AC),
      bg='By 1980 the Apple II had made Apple a fast-growing company, and it went public in a hugely anticipated offering.',
      people='The early Apple employees made wealthy by the IPO; the investors who piled in.',
      what='Apple’s <b>1980 IPO</b> was one of the largest since Ford’s, instantly making <b>Jobs (at 25) worth over $200 million</b> and creating hundreds of Apple millionaires — a landmark moment for Silicon Valley.',
      crux='It confirmed that the <b>personal computer was a world-changing industry</b>, and made Jobs both rich and famous while still very young.',
      conseq='Wealth and fame at 25 amplified both Jobs’ ambition and the pressures that would soon lead to his clash with Sculley.',
      matters='The 1980 IPO announced the arrival of the personal-computer era as big business — and made Jobs an icon before he was thirty.'),

    E('rdf', '1976–2011', 'The reality distortion field — genius and cruelty', ['POLITICS', 'REFORM'],
      'His colleagues coin a phrase for his uncanny ability to bend people to his will and convince them the impossible is possible: the "reality distortion field." It drives his teams to extraordinary heights — and it comes bound up with a perfectionism and a capacity for cruelty, public tantrums, and belittling others, that make him as difficult as he is inspiring.',
      svg_compare('The double edge of his intensity',
          {'head': 'The genius', 'color': '#166534',
           'items': ['makes people believe the impossible', 'demands and gets extraordinary work', 'an unerring eye for the great and the awful']},
          {'head': 'The cruelty', 'color': '#7f1d1d',
           'items': ['perfectionism to the point of tyranny', 'public tantrums; belittles colleagues', 'divides the world into “geniuses” and “bozos”']},
          verdict='The same intensity that inspired greatness also wounded the people around him.',
          takeaway='His “reality distortion field” drove miracles — and came wound together with real cruelty toward the people who made them.', accent=AC),
      bg='Jobs’ management style was legendary — inspiring, demanding, and often harsh, as recorded by many who worked with him.',
      people='The engineers and designers who did their best work for him — and were sometimes crushed by him.',
      what='Colleagues described Jobs’ <b>“reality distortion field”</b> — his power to convince people the impossible was achievable — which produced extraordinary work, but came with <b>perfectionism, public tantrums, and a capacity for cruelty and belittlement</b>.',
      crux='His <b>inspiration and his cruelty were inseparable</b>: the same absolute intensity that drove greatness also wounded those around him.',
      conseq='He extracted historic achievements from his teams, at a real human cost that colours his legacy.',
      matters='Jobs raises a hard question about genius and character: whether the results justified the way he treated people. This guide presents both.'),

    E('sculley', '1983–1985', 'The CEO he hired turns on him', ['POLITICS', 'TRAGEDY'],
      'He famously lures Pepsi’s John Sculley to run Apple — "do you want to sell sugar water, or change the world?" — but when the Mac underperforms, the two clash, and the board sides with Sculley.',
      svg_row('The seeds of his own downfall', [
          {'n': 1, 'label': 'Recruits Sculley', 'sub': '“sell sugar water or change the world?”', 'color': '#1f2937'},
          {'n': 2, 'label': 'The Mac underdelivers', 'sub': 'early sales fall short; tensions rise', 'color': '#b45309'},
          {'n': 3, 'label': 'The board turns', 'sub': 'Sculley wins the power struggle', 'color': '#7f1d1d'},
      ], edge_labels=['then', 'then'], takeaway='The very CEO he hand-picked to help him would soon be the one to push him out.', accent=AC),
      bg='To provide business leadership, Jobs recruited <b>John Sculley</b>, a marketing star, as Apple’s CEO — a decision that would backfire.',
      people='CEO <b>John Sculley</b>; the Apple board of directors.',
      what='Jobs persuaded Sculley to join Apple with his famous challenge about "sugar water." But as the <b>Macintosh underperformed</b> and Jobs proved a difficult manager, the two <b>clashed</b>, and the board backed Sculley.',
      crux='His <b>brilliance as a visionary was matched by an abrasive, uncompromising management style</b> — which, combined with the Mac’s slow start, made him vulnerable.',
      conseq='In 1985 Jobs was stripped of operational power and left Apple — a stunning fall for the company’s co-founder.',
      matters='Even founders can be undone by their own choices. Jobs’ fall shows how vision without managerial temperance can turn allies into rivals.'),
]

# ==================================================================  PHASE 3 — THE FALL AND THE WILDERNESS
PHASE_WILD = [
    E('ousted', '1985', 'Fired from his own company', ['DEFEAT', 'TURNING POINT', 'TRAGEDY'],
      'At thirty, the co-founder of Apple is pushed out of the company he built — a public humiliation he would later call, astonishingly, the best thing that ever happened to him, because it set him free to start over.',
      svg_ousted(),
      bg='After losing the power struggle with Sculley, Jobs found himself sidelined and, in <b>1985</b>, effectively forced out of Apple.',
      people='Sculley and the board; the loyal engineers who left Apple to join Jobs’ new venture.',
      what='In <b>1985</b> Jobs <b>resigned from Apple</b> after being stripped of authority — a very public fall. He later said being fired freed him from the weight of success and let him enter "one of the most creative periods" of his life.',
      crux='He turned catastrophe into <b>liberation</b>: released from Apple, he could take the risks and start the ventures that would ultimately make his return possible.',
      conseq='Jobs founded <b>NeXT</b> and bought the computer-graphics group that became <b>Pixar</b> — the seeds of his comeback.',
      matters='Failure can be a hinge, not an ending. Jobs’ years in the wilderness produced Pixar and the technology that later revived Apple.'),

    E('pixar', '1986–1996', 'NeXT and the Pixar miracle', ['RISE', 'TRIUMPH'],
      'In the wilderness he builds NeXT (whose software will later power Apple’s comeback) and buys a struggling graphics outfit called Pixar — which, with Toy Story, becomes the most successful animation studio in the world and makes him a billionaire.',
      svg_row('Two bets that funded the comeback', [
          {'n': 1, 'label': 'Founds NeXT', 'sub': 'advanced computers; its software becomes Mac OS X', 'color': '#1f2937'},
          {'n': 2, 'label': 'Buys Pixar (1986)', 'sub': 'a small computer-graphics group', 'color': '#b45309'},
          {'n': 3, 'label': 'Toy Story (1995)', 'sub': 'the first all-CGI feature; Pixar soars', 'color': '#166534'},
      ], edge_labels=['and', 'then'], takeaway='His "failure years" produced both the software that saved Apple and the studio that redefined animation.', accent=AC),
      bg='Out of Apple, Jobs poured his energy and fortune into two ventures: the computer company <b>NeXT</b> and the graphics group he bought from Lucasfilm, <b>Pixar</b>.',
      people='The <b>Pixar</b> team, including director <b>John Lasseter</b>; the NeXT engineers.',
      what='Jobs founded <b>NeXT</b> (whose operating system would later become the basis of <b>Mac OS X</b>) and bought <b>Pixar</b> in 1986. Pixar’s <b>Toy Story (1995)</b> — the first fully computer-animated feature — was a smash, and Pixar’s IPO made Jobs a <b>billionaire</b>.',
      crux='He kept building through failure, and his NeXT technology and Pixar success gave him both the <b>tools and the credibility</b> for a triumphant return.',
      conseq='When Apple, near bankruptcy, bought NeXT in 1996–97, Jobs came back — with a proven second act behind him.',
      matters='The wilderness can be the most productive of all. Jobs’ exile years arguably created more than his first Apple stint did.'),

    E('pixardeal', '1986–2006', 'The Pixar gamble — from near-ruin to a Disney fortune', ['RISE', 'TRIUMPH'],
      'The Pixar story is a saga of nerve: he pays millions for a money-losing graphics group, pours in his own fortune for years as it burns cash, nearly gives up more than once — then Toy Story makes it a phenomenon, its IPO makes him a billionaire, and he ultimately sells it to Disney to become the entertainment giant’s largest shareholder.',
      svg_row('A decade of patience, then a jackpot', [
          {'n': 1, 'label': 'Buys a money-loser', 'sub': 'pays for the graphics group; funds years of losses', 'color': '#1f2937'},
          {'n': 2, 'label': 'Toy Story (1995) + IPO', 'sub': 'a smash; the IPO makes him a billionaire', 'color': '#166534'},
          {'n': 3, 'label': 'Sold to Disney (2006)', 'sub': 'becomes Disney’s largest shareholder', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='He bankrolled a failing studio for a decade — and it paid off in a Toy Story phenomenon and a Disney fortune.', accent=AC),
      bg='Jobs bought the computer-graphics division that became <b>Pixar</b> from Lucasfilm and personally funded it through years of losses.',
      people='Pixar’s creative leader <b>John Lasseter</b>; the animators; <b>Disney</b>, its distributor and eventual buyer.',
      what='Jobs poured his own money into the loss-making <b>Pixar</b> for years, nearly giving up, until <b>Toy Story (1995)</b> made it a phenomenon; Pixar’s <b>IPO made him a billionaire</b>, and in <b>2006</b> he sold it to <b>Disney</b>, becoming Disney’s <b>largest individual shareholder</b>.',
      crux='He showed extraordinary <b>patience and nerve</b> with a long-failing venture — and reaped one of the great business payoffs when it finally succeeded.',
      conseq='Pixar made Jobs a billionaire and a media-industry force, and revolutionised animation.',
      matters='Great returns often require years of loss-bearing conviction. Jobs’ Pixar saga is a study in patient, high-stakes belief.'),
]

# ==================================================================  PHASE 4 — THE RETURN
PHASE_RETURN = [
    E('ive', '1997–2011', 'Design as religion — Jony Ive and the Apple aesthetic', ['REFORM', 'TRIUMPH'],
      'The heart of Apple’s comeback is a creative marriage: Jobs finds in the designer Jony Ive a kindred obsessive, and together they make design the organising principle of everything Apple builds — obsessing over materials, curves, and even the parts no one sees, guided by a Zen-tinged conviction that simplicity is the ultimate sophistication.',
      svg_row('Making design the soul of the company', [
          {'n': 1, 'label': 'Jobs meets Jony Ive', 'sub': 'a kindred design obsessive at Apple', 'color': '#1f2937'},
          {'n': 2, 'label': 'Design leads everything', 'sub': 'form, materials, even unseen internals obsessed over', 'color': '#0369a1'},
          {'n': 3, 'label': 'Simplicity as sophistication', 'sub': 'ruthless reduction to the essential', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He made design the soul of Apple — with Ive, turning simplicity into the company’s deepest competitive weapon.', accent=AC),
      bg='On his return, Jobs elevated <b>design</b> to the center of Apple, partnering with the designer <b>Jony Ive</b>.',
      people='<b>Jony Ive</b>, Apple’s chief designer; the engineers who executed their exacting standards.',
      what='Jobs and <b>Jony Ive</b> made <b>design the organising principle</b> of Apple’s products — obsessing over form, materials, and even <b>internal parts no user would see</b> — guided by a belief, rooted in Jobs’ Zen aesthetics, that <b>simplicity is the ultimate sophistication</b>.',
      crux='He treated <b>design not as decoration but as the essence</b> of a product — the deepest source of Apple’s difference and value.',
      conseq='The Ive-Jobs partnership produced the iMac, iPod, iPhone and iPad, defining a global design language.',
      matters='Jobs proved design could be a company’s core strategy. His partnership with Ive is one of the great creative collaborations in business.'),

    E('retail', '2001–2011', 'The Apple Stores — selling the experience', ['REFORM', 'TRIUMPH'],
      'Against near-universal skepticism, he decides Apple must control how its products are sold, and builds a chain of beautiful retail stores — with their open layouts, wooden tables, and "Genius Bars" — that critics predict will fail and that instead become among the most profitable square footage in all of retail.',
      svg_row('Controlling the whole experience', [
          {'n': 1, 'label': 'Skeptics say it will fail', 'sub': 'why would a computer maker open stores?', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Beautiful, experiential stores', 'sub': 'open layouts, wood tables, the Genius Bar', 'color': '#1f2937'},
          {'n': 3, 'label': 'Retail gold', 'sub': 'among the most profitable stores per square foot', 'color': '#166534'},
      ], edge_labels=['yet', 'then'], takeaway='He controlled the buying experience as tightly as the product — and made Apple’s stores a retail phenomenon.', accent=AC),
      bg='Jobs believed Apple’s products were being poorly sold in big-box stores, and resolved to <b>control the retail experience</b> himself.',
      people='The retail team Jobs recruited; the skeptics who predicted the stores would fail.',
      what='Jobs launched the <b>Apple Store</b> chain (from 2001) — with distinctive <b>open, minimalist layouts, wooden tables and the "Genius Bar"</b> — which, despite widespread skepticism, became <b>among the most profitable retail space in the world</b>.',
      crux='He extended his obsession with the <b>whole experience</b> to how products were sold, treating retail as an extension of the product itself.',
      conseq='The stores hugely boosted Apple’s brand, sales and customer relationships, and were widely imitated.',
      matters='Jobs understood that the buying experience is part of the product. The Apple Store is a landmark of experiential retail.'),
    E('return', '1997–2001', 'The return and the great turnaround', ['TURNING POINT', 'TRIUMPH'],
      'Apple, months from bankruptcy, buys NeXT and brings Jobs back. He ruthlessly cuts the bloated product line to a handful of great products, relaunches the brand with "Think Different," and with the candy-coloured iMac makes Apple cool — and profitable — again.',
      svg_return(),
      bg='By 1997 Apple was <b>near bankruptcy</b>, its product line bloated and its brand faded. It bought NeXT, bringing Jobs back as leader.',
      people='Designer <b>Jony Ive</b>, who became Jobs’ creative partner; the Apple employees who rallied to the turnaround.',
      what='Jobs returned in 1997, <b>slashed most of Apple’s products</b> to focus on a few great ones, launched the <b>"Think Different"</b> campaign, and released the striking <b>iMac (1998)</b> — restoring Apple’s finances and its cool.',
      crux='His turnaround weapon was <b>focus</b>: subtracting rather than adding, betting the company on a handful of beautifully designed products.',
      conseq='Apple returned to profit and design leadership, setting the stage for a decade of world-changing products.',
      matters='Focus is a superpower. Jobs saved Apple by having the discipline to say no to almost everything.'),

    E('ipod', '2001–2006', 'The iPod and iTunes reinvent music', ['TRIUMPH', 'REFORM'],
      'With "a thousand songs in your pocket," the iPod and the iTunes Store transform how the world buys and listens to music — and turn Apple from a computer company into a consumer-electronics juggernaut.',
      svg_row('Reinventing an entire industry', [
          {'n': 1, 'label': 'The iPod (2001)', 'sub': '“a thousand songs in your pocket”', 'color': '#1f2937'},
          {'n': 2, 'label': 'The iTunes Store', 'sub': 'legal, easy song downloads at 99¢', 'color': '#b45309'},
          {'n': 3, 'label': 'Music transformed', 'sub': 'Apple becomes a consumer-electronics giant', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He didn’t just make a music player — he rebuilt the entire business of music around it.', accent=AC),
      bg='In the early 2000s digital music was chaotic and piracy rampant. Jobs saw an opening to make it elegant and legal.',
      people='The iPod and iTunes teams; the record labels Jobs persuaded to sell songs digitally.',
      what='Apple launched the <b>iPod (2001)</b> and the <b>iTunes Store (2003)</b>, combining a beautiful device with an easy, legal way to buy music — transforming the industry and making Apple a consumer-electronics powerhouse.',
      crux='He mastered the <b>ecosystem</b>: pairing a desirable device with seamless software and content, so the whole experience — not just the gadget — was superior.',
      conseq='Apple’s success with the iPod set the pattern — device plus ecosystem — for the far bigger revolution to come.',
      matters='The best products are systems, not gadgets. The iPod taught Jobs the ecosystem playbook he would use for the iPhone.'),
]

# ==================================================================  PHASE 5 — THE REINVENTION AND DEATH
PHASE_END = [
    E('appstore', '2008–2011', 'The App Store — an economy in your pocket', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'His deepest platform stroke comes a year after the iPhone: the App Store, which lets anyone in the world write software for the device and sell it to hundreds of millions of users — creating an entirely new economy, turning the iPhone into an ever-expanding universe of uses, and cementing Apple’s ecosystem for a generation.',
      svg_row('Opening the phone to the world’s developers', [
          {'n': 1, 'label': 'The App Store (2008)', 'sub': 'anyone can build and sell iPhone apps', 'color': '#1f2937'},
          {'n': 2, 'label': 'A whole new economy', 'sub': 'millions of apps; a vast developer marketplace', 'color': '#166534'},
          {'n': 3, 'label': 'The ecosystem locks in', 'sub': 'the iPhone becomes endlessly extensible', 'color': '#0369a1'},
      ], edge_labels=['then', 'so'], takeaway='He turned the iPhone into a platform the whole world could build on — creating an economy and an unbreakable ecosystem.', accent=AC),
      bg='Jobs was initially reluctant to let outsiders write iPhone software, but was persuaded to open the platform.',
      people='The millions of <b>developers</b> who built apps; the users whose phones became infinitely more useful.',
      what='The <b>App Store (2008)</b> let independent developers build and sell software for the iPhone, creating an <b>entirely new app economy</b>, making the device endlessly extensible, and deepening Apple’s ecosystem lock-in.',
      crux='He turned the iPhone from a product into a <b>platform</b> — harnessing the creativity of the whole world’s developers and binding users to the ecosystem.',
      conseq='The app economy became a multi-hundred-billion-dollar industry and a foundation of modern digital life.',
      matters='Platforms beat products. The App Store may be Jobs’ most consequential single stroke — an economy and a lock-in in one.'),

    E('zen', '1970s–2011', 'Zen and the art of simplicity', ['REFORM', 'POLITICS'],
      'The aesthetic that drives everything he makes has a spiritual root: his youthful immersion in Zen Buddhism gives him a lifelong devotion to minimalism, focus, and the removal of everything inessential — a philosophy visible in his products, his famously spare home, and even his black-turtleneck uniform.',
      svg_row('A philosophy made visible in objects', [
          {'n': 1, 'label': 'Zen Buddhism', 'sub': 'youthful immersion shapes his whole aesthetic', 'color': '#1f2937'},
          {'n': 2, 'label': 'Minimalism and focus', 'sub': 'remove everything inessential', 'color': '#166534'},
          {'n': 3, 'label': 'Visible everywhere', 'sub': 'products, his spare home, the turtleneck uniform', 'color': '#0369a1'},
      ], edge_labels=['then', 'so'], takeaway='His minimalism was not a style but a philosophy — Zen focus and reduction, made physical in his products.', accent=AC),
      bg='Jobs’ immersion in <b>Zen Buddhism</b> as a young man profoundly shaped his lifelong values and aesthetic.',
      people='The Zen teachers who influenced him; the designers who translated his minimalism into products.',
      what='Jobs’ <b>Zen</b> practice underlay a lifelong devotion to <b>minimalism, focus and the elimination of the inessential</b> — expressed in his products, his famously sparse home, and even his uniform of black turtleneck and jeans.',
      crux='His design philosophy was <b>spiritual as much as commercial</b>: reduction to the essential as a way of both making things and living.',
      conseq='This aesthetic became Apple’s hallmark and reshaped global expectations of how technology should look and feel.',
      matters='Jobs’ minimalism came from within. His Zen-rooted philosophy of simplicity is inseparable from what made Apple’s products feel different.'),

    E('personal', '1955–2011', 'The complicated private man', ['POLITICS', 'TRAGEDY'],
      'His personal life is as tangled as his public one is polished: adopted as a baby, he later sought out his biological family and discovered a sister, the novelist Mona Simpson; for years he denied paternity of his first daughter, Lisa, before reconciling; and he found lasting stability only later, with his wife Laurene — a reminder that the man of perfect products was an imperfect, searching human being.',
      svg_row('The private contradictions', [
          {'n': 1, 'label': 'Adopted, then searching', 'sub': 'finds his birth family; a sister, Mona Simpson', 'color': '#1f2937'},
          {'n': 2, 'label': 'Denied, then embraced Lisa', 'sub': 'estranged from his first daughter, later reconciled', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'Stability with Laurene', 'sub': 'lasting family life found later', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='The maker of perfect objects was a searching, flawed, deeply human man in his private life.', accent=AC),
      bg='Jobs’ personal life was marked by his adoption, his search for identity, and difficult early relationships.',
      people='His birth sister, the novelist <b>Mona Simpson</b>; his first daughter <b>Lisa</b>; his wife <b>Laurene Powell Jobs</b>.',
      what='Given up for adoption, Jobs later <b>found his biological family</b> (including his sister <b>Mona Simpson</b>), for years <b>denied paternity of his daughter Lisa</b> before reconciling, and found lasting family stability with his wife <b>Laurene</b>.',
      crux='The perfectionist of products was a <b>flawed, searching human being</b> in private — his personal contradictions as real as his professional genius.',
      conseq='His relationships, strained and mended, are part of the fuller, more human picture of Jobs.',
      matters='Genius does not equal a tidy life. Jobs’ private struggles round out the portrait of a brilliant, difficult, deeply human person.'),

    E('cancer', '2003–2011', 'The fatal delay — illness and its secrets', ['DEATH', 'TRAGEDY'],
      'His response to his own cancer becomes a poignant, cautionary chapter: diagnosed in 2003 with a rare, potentially treatable pancreatic tumor, he delays surgery for months to try alternative and dietary treatments — a decision he reportedly came to regret — before undergoing surgery, a later liver transplant, and years of decline shrouded, like everything at Apple, in secrecy.',
      svg_row('When even he could not control the outcome', [
          {'n': 1, 'label': 'Diagnosed in 2003', 'sub': 'a rare, treatable pancreatic tumor', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Delays surgery', 'sub': 'tries alternative and dietary treatments first', 'color': '#b45309'},
          {'n': 3, 'label': 'Surgery, transplant, decline', 'sub': 'later operations amid intense secrecy', 'color': '#475569'},
      ], edge_labels=['then', 'then'], takeaway='The man who controlled everything could not control this — and his early delay may have cost him dearly.', accent=AC),
      bg='In 2003 Jobs was diagnosed with a rare, comparatively treatable form of <b>pancreatic cancer</b> (a neuroendocrine tumor).',
      people='His doctors and family, who urged surgery; the Apple board and public kept in the dark by Apple’s secrecy.',
      what='Jobs <b>delayed surgery for about nine months</b> to pursue <b>alternative and dietary treatments</b> — a choice he reportedly later regretted — before undergoing surgery, a <b>2009 liver transplant</b>, and years of decline, all managed under Apple’s trademark <b>secrecy</b>.',
      crux='His illness revealed the <b>limits of his will</b>: the same self-belief that moved mountains led him, at first, to defy medical advice, perhaps at great cost.',
      conseq='He continued to lead Apple through the iPhone and iPad years while gravely ill, until resigning in 2011.',
      matters='Even Jobs could not bend reality here. His delay is a sober human coda — a reminder that will has limits medicine does not forgive.'),

    E('iphone', '2007–2010', 'The iPhone and iPad change the world', ['TRIUMPH', 'REFORM', 'TURNING POINT'],
      'He unveils the iPhone as "three revolutionary products in one," then adds the App Store and the iPad — putting a powerful computer in billions of pockets, creating whole new industries, and making Apple the most valuable company on earth.',
      svg_iphone(),
      bg='By 2007 the mobile phone was ripe for reinvention. Jobs combined Apple’s hardware, software and ecosystem mastery to remake it.',
      people='The iPhone engineering and design teams; the millions of developers who built apps.',
      what='Jobs launched the <b>iPhone (2007)</b> — pitched as an iPod, phone and internet device in one — followed by the <b>App Store (2008)</b> and the <b>iPad (2010)</b>, creating the modern smartphone era and vast new app economies.',
      crux='He achieved the ultimate <b>convergence</b>: fusing multiple devices into one, backed by an ecosystem that let others build on it — reshaping communication, media and computing.',
      conseq='The iPhone became one of the best-selling products in history and drove Apple to become the <b>most valuable company in the world</b>.',
      matters='A single product can remake civilisation’s daily life. The iPhone put the internet in everyone’s pocket and defined the modern age.'),

    E('death', '2003–2011', 'Illness, resignation, and death', ['DEATH', 'TRAGEDY'],
      'Diagnosed with a rare pancreatic cancer in 2003, he keeps building through years of illness and a liver transplant, delivers a famous meditation on death in his Stanford speech, resigns as CEO in August 2011, and dies that October at fifty-six — at the height of Apple’s power.',
      svg_row('Building to the very end', [
          {'n': 1, 'label': 'Cancer diagnosed, 2003', 'sub': 'a rare pancreatic tumour; he keeps working', 'color': '#b45309'},
          {'n': 2, 'label': '“Stay hungry, stay foolish”', 'sub': 'his 2005 Stanford speech on death and purpose', 'color': '#1f2937'},
          {'n': 3, 'label': 'Resigns and dies, 2011', 'sub': 'steps down in August; dies in October at 56', 'color': '#111827'},
      ], edge_labels=['then', 'then'], takeaway='Facing death for years, he kept creating — and left behind the most valuable company on earth.', accent=AC),
      bg='In <b>2003</b> Jobs was diagnosed with a rare form of <b>pancreatic cancer</b>. He continued to lead Apple through treatment and a 2009 liver transplant.',
      people='His family; his successor <b>Tim Cook</b>; the millions who mourned him.',
      what='Jobs battled cancer for years while launching the iPhone and iPad, delivered his celebrated <b>2005 Stanford commencement address</b> ("Stay hungry, stay foolish"), <b>resigned as CEO in August 2011</b>, and <b>died on 5 October 2011</b>, aged 56.',
      crux='He embodied <b>relentless creativity in the face of mortality</b>, using his awareness of death as, in his words, a tool to focus on what truly mattered.',
      conseq='He left Apple at the peak of its power and influence, and became an enduring icon of design, innovation and singular vision.',
      matters='Jobs turned the shadow of death into a spur to create. His life is a meditation on doing meaningful work in the time you have.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Steve Jobs co-founded Apple in a garage, was fired from it, and came back to build the most valuable company on earth — reinventing personal computing, music, phones and tablets along the way. He is a study in <b>product vision and taste over pure engineering, the power of focus, redemption after failure, and the marriage of art and technology.</b></p>
<div class="ov-quote">“Stay hungry. Stay foolish.”<span>— Steve Jobs, Stanford commencement, 2005</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">An adopted Valley tinkerer drops out, wanders to India, and co-founds Apple with Wozniak → drives the Macintosh and the graphical revolution → is fired from his own company → builds NeXT and Pixar in the wilderness → returns to a dying Apple and saves it by focus → reinvents music with the iPod → puts a computer in every pocket with the iPhone → and dies at 56, at the height of Apple’s power.</p>
<div class="ov-lbl">Why he matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🎨</div><h4>Taste as strategy</h4><p>He proved design and product taste could be a company’s core advantage.</p></div>
  <div class="ov-card"><div class="i">🎯</div><h4>The power of focus</h4><p>He saved Apple by saying no to almost everything.</p></div>
  <div class="ov-card"><div class="i">🔁</div><h4>Redemption</h4><p>Fired from his own company, he came back to build its greatest era.</p></div>
  <div class="ov-card"><div class="i">📱</div><h4>He shaped daily life</h4><p>The iPhone reinvented how billions of people live and communicate.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Adopted Tinkerer</b><small> 1955–76</small><p>Valley boyhood, dropout, India.</p></div>
  <div><b>2 · Founding Apple</b><small> 1976–85</small><p>The garage, the Mac, and the first fall.</p></div>
  <div><b>3 · The Wilderness</b><small> 1985–96</small><p>Fired; NeXT and the Pixar miracle.</p></div>
  <div><b>4 · The Return</b><small> 1997–2006</small><p>The turnaround and the iPod.</p></div>
  <div><b>5 · Reinvention and Death</b><small> 2007–11</small><p>The iPhone, the iPad, and the end.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Steve Wozniak', 'role': 'co-founder / engineer', 'color': '#0369a1',
     'bio': 'The engineering genius who designed the Apple I and II and co-founded Apple with Jobs; the builder to Jobs’ visionary.',
     'rel': 'The engineer whose machines Jobs turned into a company.'},
    {'name': 'John Sculley', 'role': 'CEO / rival', 'color': '#7f1d1d',
     'bio': 'The Pepsi executive Jobs recruited to run Apple, who then won the 1985 power struggle that pushed Jobs out of the company.',
     'rel': 'The CEO Jobs hired who engineered his ousting.'},
    {'name': 'Jony Ive', 'role': 'design partner', 'color': '#1f2937',
     'bio': 'Apple’s legendary designer and Jobs’ close creative partner after his return, responsible for the look of the iMac, iPod, iPhone and iPad.',
     'rel': 'The designer who gave Jobs’ vision its physical form.'},
    {'name': 'Tim Cook', 'role': 'successor', 'color': '#166534',
     'bio': 'Apple’s operations chief who became CEO when Jobs resigned in 2011, and who has led the company since.',
     'rel': 'The successor who inherited Apple at its peak.'},
    {'name': 'John Lasseter', 'role': 'Pixar director', 'color': '#b45309',
     'bio': 'The creative leader of Pixar whose Toy Story and later films, under Jobs’ ownership, made Pixar the world’s premier animation studio.',
     'rel': 'The talent behind the Pixar success that funded Jobs’ comeback.'},
]

KEY_EVENTS = [
    ('1955', 'Born and adopted', 'Raised in the future Silicon Valley.'),
    ('1976', 'Apple founded', 'With Wozniak; the Apple I.'),
    ('1977', 'Apple II', 'A hit personal computer.'),
    ('1984', 'The Macintosh', 'The graphical interface for the masses.'),
    ('1985', 'Fired from Apple', 'Loses the power struggle with Sculley.'),
    ('1986', 'Buys Pixar; builds NeXT', 'The wilderness years begin.'),
    ('1995', 'Toy Story', 'Pixar’s triumph; Jobs a billionaire.'),
    ('1997', 'Returns to Apple', 'Saves a company near bankruptcy.'),
    ('2001', 'The iPod', 'Reinvents music; “1,000 songs in your pocket.”'),
    ('2007', 'The iPhone', 'Three devices in one; the modern smartphone.'),
    ('2010', 'The iPad', 'Defines the tablet.'),
    ('2011', 'Resigns and dies', 'Dies at 56, at the height of Apple’s power.'),
]

MASTER = [
    {'year': '1955', 'age': 'born', 'phase': 'Tinkerer', 'title': 'Born and adopted', 'desc': 'A Valley boyhood.'},
    {'year': '1976', 'age': 'age 21', 'phase': 'Founding', 'title': 'Apple founded', 'desc': 'The garage era.'},
    {'year': '1984', 'age': 'age 29', 'phase': 'Founding', 'title': 'The Macintosh', 'desc': 'The GUI for everyone.'},
    {'year': '1985', 'age': 'age 30', 'phase': 'Wilderness', 'title': 'Fired from Apple', 'desc': 'The great fall.'},
    {'year': '1995', 'age': 'age 40', 'phase': 'Wilderness', 'title': 'Toy Story', 'desc': 'The Pixar miracle.'},
    {'year': '1997', 'age': 'age 42', 'phase': 'Return', 'title': 'Returns to Apple', 'desc': 'The great turnaround.'},
    {'year': '2007', 'age': 'age 52', 'phase': 'Reinvention', 'title': 'The iPhone', 'desc': 'The world changes.'},
    {'year': '2011', 'age': 'age 56', 'phase': 'The End', 'title': 'Resigns and dies', 'desc': 'At the height of Apple.'},
]

SOURCES = [
    ('Britannica — Steve Jobs', 'https://www.britannica.com/biography/Steve-Jobs'),
    ('Stanford — Steve Jobs 2005 Commencement Address', 'https://news.stanford.edu/2005/06/12/youve-got-find-love-jobs-says/'),
    ('Britannica — Apple Inc.', 'https://www.britannica.com/topic/Apple-Inc'),
    ('Wikipedia — Steve Jobs', 'https://en.wikipedia.org/wiki/Steve_Jobs'),
]

def build_meta():
    return {
        'pid': 'gm-jobs.html', 'kind': 'man', 'emoji': '📱', 'accent': AC,
        'name': 'Steve Jobs', 'years': '1955–2011', 'group': 'Business & Industry',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'He co-founded Apple in a garage, was fired from it, and returned to build the most valuable company on earth — reinventing computing, music and the phone along the way.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · The Adopted Tinkerer', 'type': 'timeline',
             'intro': 'An adopted boy grows up in Silicon Valley’s garage culture, drops out of college, wanders to India, and returns a barefoot seeker fusing counterculture with technology.', 'events': PHASE_RISE},
            {'id': 'apple', 'label': '2 · Founding Apple', 'type': 'timeline',
             'intro': 'With Wozniak he founds Apple, drives the graphical revolution with the Macintosh — and then, undone by his own management style, loses the power struggle he set in motion.', 'events': PHASE_APPLE},
            {'id': 'wild', 'label': '3 · The Wilderness', 'type': 'timeline',
             'intro': 'Fired from his own company at thirty, he builds NeXT and buys Pixar — and his "failure years" quietly create the software that will save Apple and the studio that redefines animation.', 'events': PHASE_WILD},
            {'id': 'return', 'label': '4 · The Return', 'type': 'timeline',
             'intro': 'He comes back to a dying Apple and saves it by ruthless focus, then reinvents an entire industry with the iPod and iTunes.', 'events': PHASE_RETURN},
            {'id': 'end', 'label': '5 · Reinvention and Death', 'type': 'timeline',
             'intro': 'He puts a computer in every pocket with the iPhone and iPad — and, battling cancer for years, keeps creating until he dies at fifty-six, at the height of Apple’s power.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Jobs’ life is very well documented, including in Walter Isaacson’s authorised biography; this guide follows the mainstream account.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
