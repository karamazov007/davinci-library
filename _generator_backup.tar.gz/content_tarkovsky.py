# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Andrei Tarkovsky.
The Soviet poet of cinema who sculpted time itself — and paid for his vision with exile."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#0f766e'  # weathered teal — water, rust and the Zone

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — ROOTS OF A POET
PHASE_ROOTS = [
    E('origins', '1932', 'Born the son of a poet', ['RISE', 'ORIGINS'],
      'Andrei Tarkovsky is born in April 1932 in the village of Zavrazhye on the Volga, son of the celebrated poet and translator Arseny Tarkovsky — a father who abandons the family in 1937 but whose verse, later spoken aloud in the film Mirror, threads a poetic sensibility through the whole of his son’s cinema.',
      svg_row('A childhood soaked in poetry and loss', [
          {'n': 1, 'label': 'Born on the Volga, 1932', 'sub': 'Zavrazhye, Ivanovo region, 4 April', 'color': '#0f766e'},
          {'n': 2, 'label': 'Son of poet Arseny Tarkovsky', 'sub': 'father leaves the family in 1937', 'color': '#7c2d12'},
          {'n': 3, 'label': 'Poetry as inheritance', 'sub': 'the father’s verse haunts the son’s films', 'color': '#3730a3'},
      ], edge_labels=['then', 'so'], takeaway='He was born into words before images — the poet’s son who would make cinema a form of poetry.', accent=AC),
      bg='<b>Andrei Tarkovsky</b> was born on 4 April 1932 in Zavrazhye, a Volga village in the Ivanovo region of Soviet Russia, to the poet <b>Arseny Tarkovsky</b> and Maria Vishnyakova.',
      people='his father, the poet <b>Arseny Tarkovsky</b>; his mother <b>Maria Vishnyakova</b>, who raised the children alone; his sister Marina.',
      what='His father <b>left the family in 1937</b>, and Andrei was raised largely by his mother through war and evacuation — a childhood of absence, rural landscape and poetry that he would later reconstruct almost directly in <b>Mirror (1975)</b>.',
      crux='He grew up inside a <b>poetic rather than a political</b> world — shaped by his father’s verse and his mother’s endurance, not by ideology.',
      conseq='That sensibility — memory, longing, the sacred in the ordinary — became the permanent material of his art.',
      matters='Artists mine their childhoods — Tarkovsky’s films return again and again to the rain, houses and absent father of these early years.'),

    E('vgik', '1954–1960', 'VGIK and the school of Mikhail Romm', ['RISE', 'CRAFT'],
      'After a restless youth — Arabic studies abandoned, a year prospecting for gold in the Siberian taiga — Tarkovsky enters the state film school VGIK in 1954 and studies under the veteran director Mikhail Romm, who prizes independence of vision and shelters a generation of gifted, unruly students learning to break with Socialist Realism.',
      svg_stack('From gold-prospector to film student', [
          {'n': 1, 'label': 'A wandering youth', 'sub': 'Arabic dropped; a year in the Siberian taiga', 'color': '#7c2d12'},
          {'n': 2, 'label': 'Enters VGIK film school, 1954', 'sub': 'Moscow’s state institute of cinematography', 'color': '#0f766e'},
          {'n': 3, 'label': 'Studies under Mikhail Romm', 'sub': 'a mentor who guards independent vision', 'color': '#3730a3'},
      ], takeaway='He found his vocation late and formally — but under a teacher who taught him to trust his own eye.', accent=AC),
      bg='Before film, Tarkovsky studied Arabic at Moscow’s Oriental Institute, dropped out, and joined a year-long <b>geological expedition</b> in the Siberian taiga near the Kureyka River before deciding to study cinema.',
      people='the director <b>Mikhail Romm</b>, his teacher at VGIK; fellow students including <b>Andrei Konchalovsky</b>; his first wife, actress Irma Raush.',
      what='In 1954 he entered the <b>State Institute of Cinematography (VGIK)</b> and joined the workshop of <b>Mikhail Romm</b>, who encouraged a cohort of young directors to develop personal styles rather than obey Socialist Realist formula.',
      crux='Under Romm he learned that <b>cinema could be authorship</b> — a director’s vision, not a state commission — a conviction that would soon put him at odds with the system.',
      conseq='He emerged a fully formed auteur, ready to make films unlike anything in official Soviet cinema.',
      matters='A great teacher protects the strange — Romm gave Tarkovsky the licence to be uncompromising from the very start.'),

    E('steamroller', '1960–1961', 'The Steamroller and the Violin', ['CRAFT', 'RISE'],
      'For his graduation film Tarkovsky makes The Steamroller and the Violin (1960), a lyrical short about the friendship between a small boy learning the violin and a burly road-worker — co-written with Andrei Konchalovsky — whose tenderness, water imagery and painterly light already announce the poet-director to come, and it wins first prize at the New York Student Film Festival.',
      svg_row('A student film that is already Tarkovsky', [
          {'n': 1, 'label': 'Graduation film, 1960', 'sub': 'The Steamroller and the Violin', 'color': '#0f766e'},
          {'n': 2, 'label': 'A boy, a violin, a road-worker', 'sub': 'co-written with Andrei Konchalovsky', 'color': '#3730a3'},
          {'n': 3, 'label': 'Wins in New York, 1961', 'sub': 'first prize, NY Student Film Festival', 'color': '#166534'},
      ], edge_labels=['about', 'and'], takeaway='His diploma film already carried the signature — water, light and childhood tenderness — of everything to come.', accent=AC),
      bg='Soviet film students completed a graduation film to qualify; Tarkovsky’s, made in 1960, was a short feature shot in colour on the streets of Moscow.',
      people='co-writer <b>Andrei Konchalovsky</b>; the child actor at the film’s centre; his mentor Romm, who supervised the work.',
      what='<b>The Steamroller and the Violin (1960)</b>, a 46-minute film about a sensitive boy and a kindly steamroller driver, revealed Tarkovsky’s trademark imagery — rain, reflections, glowing light — and won <b>first prize at the New York Student Film Festival</b> in 1961.',
      crux='Even as a student he treated film as <b>visual poetry</b>, privileging atmosphere and feeling over plot.',
      conseq='The film’s promise won him his first professional feature assignment almost immediately.',
      matters='Some artists arrive whole — Tarkovsky’s style was recognisably his own before he had directed a single feature.'),
]

# ==================================================================  PHASE 2 — TRIUMPH AND THE CENSORS
PHASE_BREAK = [
    E('ivan', '1962', 'Ivan’s Childhood and the Golden Lion', ['TRIUMPH', 'TURNING POINT'],
      'Handed a troubled war project to rescue, Tarkovsky reinvents it as Ivan’s Childhood (1962) — the story of an orphaned boy scout on the Eastern Front, told through dreams and shattered memory rather than heroics — and at just thirty wins the Golden Lion at the Venice Film Festival, announcing a major new voice to the world.',
      svg_stack('A war film like no other wins Venice', [
          {'n': 1, 'label': 'Rescues a failed war project', 'sub': 'reworks it into Ivan’s Childhood, 1962', 'color': '#0f766e'},
          {'n': 2, 'label': 'War through a child’s dreams', 'sub': 'memory and nightmare, not heroics', 'color': '#3730a3'},
          {'n': 3, 'label': 'Golden Lion at Venice, 1962', 'sub': 'world fame for a director of thirty', 'color': '#166534'},
      ], takeaway='His first feature won cinema’s oldest top prize — and made the West aware of a new Soviet master overnight.', accent=AC),
      bg='Tarkovsky was assigned to salvage a stalled adaptation of Vladimir Bogomolov’s war story <b>“Ivan”</b>, and rebuilt it almost from scratch as his debut feature.',
      people='his cinematographer <b>Vadim Yusov</b>; the young lead <b>Nikolai Burlyaev</b> as Ivan; the Venice jury that crowned it.',
      what='<b>Ivan’s Childhood (1962)</b> portrayed a boy scout on the Eastern Front through <b>dream sequences and fractured memory</b>, and won the <b>Golden Lion (Grand Prix) at the 1962 Venice Film Festival</b>, sharing the top award.',
      crux='He proved a war film could be <b>an interior, poetic vision</b> rather than propaganda — feeling over ideology.',
      conseq='International acclaim gave him standing at home and the confidence to attempt his most ambitious film.',
      matters='A single festival prize can make a career — Venice turned a first-time director into a name spoken alongside the great auteurs.'),

    E('rublev', '1966', 'Andrei Rublev — a monumental vision', ['MASTERWORK', 'IDEAS'],
      'Tarkovsky completes Andrei Rublev in 1966, an epic in eight episodes on the fifteenth-century icon painter — a three-hour meditation on faith, violence, artistic doubt and the burden of creation under tyranny, filmed in stark medieval Russia and climaxing in a boy’s desperate casting of a great bell — the film he considered his true statement of purpose.',
      svg_row('An epic on faith, art and cruelty', [
          {'n': 1, 'label': 'Andrei Rublev completed, 1966', 'sub': 'the 15th-century icon painter', 'color': '#0f766e'},
          {'n': 2, 'label': 'Eight episodes, three-plus hours', 'sub': 'faith, violence, the artist’s doubt', 'color': '#3730a3'},
          {'n': 3, 'label': 'The casting of the bell', 'sub': 'creation wrung from fear and faith', 'color': '#7c2d12'},
      ], edge_labels=['a life in', 'ending with'], takeaway='He made an immense film about whether the artist can create at all in a world of cruelty — his deepest theme.', accent=AC),
      bg='After Venice, Tarkovsky spent years developing a vast historical film on <b>Andrei Rublev</b>, the revered medieval Russian icon painter, co-written with Konchalovsky.',
      people='the actor <b>Anatoly Solonitsyn</b> as Rublev; cinematographer <b>Vadim Yusov</b>; co-writer Konchalovsky; the Soviet cultural authorities watching warily.',
      what='<b>Andrei Rublev</b>, finished in 1966, unfolded in <b>eight loosely linked episodes</b> across war, famine and pagan revelry, exploring the artist’s crisis of faith and ending with the fraught <b>casting of a cathedral bell</b> as an allegory of creation itself.',
      crux='The film asked his central question — <b>can beauty be made amid brutality?</b> — and answered it with the very fact of its own existence.',
      conseq='Its scale, violence and religious themes alarmed the censors, and its release was blocked for years.',
      matters='It is routinely ranked among the greatest films ever made — but its greatness came at the cost of a long battle to be seen.'),

    E('censorship', '1966–1971', 'The censors and the buried film', ['POLITICS', 'CONFLICT'],
      'Soviet authorities recoil from Andrei Rublev’s violence, nudity and unofficial vision of Russian history — the film is shelved after a single Moscow screening, forced through cuts and re-edits, and only shown abroad at Cannes in 1969 (where it wins the critics’ prize) before finally reaching Soviet screens in a shortened version in 1971, five years after completion.',
      svg_stack('A masterpiece locked in a vault', [
          {'n': 1, 'label': 'Shelved after one screening, 1966', 'sub': 'deemed too violent, too religious', 'color': '#7c2d12'},
          {'n': 2, 'label': 'Forced cuts and re-edits', 'sub': 'the authorities demand a tamer film', 'color': '#a16207'},
          {'n': 3, 'label': 'Cannes 1969, Soviet release 1971', 'sub': 'FIPRESCI prize abroad; buried at home', 'color': '#0f766e'},
      ], takeaway='The state tried to bury his greatest film — and its five-year suppression set the pattern of his life under Soviet power.', accent=AC),
      bg='Soviet cinema was governed by <b>Goskino</b>, the state film committee, which vetted every film for ideological safety; Andrei Rublev troubled it on every count.',
      people='the officials of <b>Goskino</b>; the critics abroad who championed the film at Cannes; Tarkovsky, forced to defend and trim his work.',
      what='<b>Andrei Rublev</b> was <b>withheld from release</b> after 1966, subjected to demanded cuts, shown at <b>Cannes in 1969</b> (winning the FIPRESCI critics’ prize), and only given limited Soviet distribution in a <b>shortened version in 1971</b>.',
      crux='The episode exposed the fundamental clash of his career — a <b>singular artist inside a system that feared singular art</b>.',
      conseq='Every subsequent film would be a struggle for funding, approval and release against official suspicion.',
      matters='Censorship rarely destroys great work — but it steals years from its makers; Tarkovsky would make only seven features in a lifetime.'),
]

# ==================================================================  PHASE 3 — THE INNER COSMOS
PHASE_COSMOS = [
    E('solaris', '1972', 'Solaris — the anti-science-fiction', ['MASTERWORK', 'IDEAS'],
      'Turning to Stanisław Lem’s novel, Tarkovsky makes Solaris (1972) — a science-fiction film that turns its back on spectacle, using a sentient ocean-planet that resurrects the dead from memory to stage a meditation on grief, guilt and love — and it wins the Grand Prix Spécial du Jury at Cannes, though he privately faults it as too tied to genre.',
      svg_row('Space travel as a journey inward', [
          {'n': 1, 'label': 'Solaris released, 1972', 'sub': 'from Stanisław Lem’s novel', 'color': '#0f766e'},
          {'n': 2, 'label': 'A planet that revives the dead', 'sub': 'grief, guilt and memory made flesh', 'color': '#3730a3'},
          {'n': 3, 'label': 'Grand Prix at Cannes, 1972', 'sub': 'the Jury’s special grand prize', 'color': '#166534'},
      ], edge_labels=['where', 'wins'], takeaway='He answered Western sci-fi spectacle with an inward, mournful film about conscience — space as a mirror of the soul.', accent=AC),
      bg='Tarkovsky adapted <b>Stanisław Lem’s</b> 1961 novel <b>Solaris</b>, partly as a Soviet reply to Kubrick’s 2001, but recoiled from technological spectacle.',
      people='co-writer Friedrich Gorenstein; lead actors including <b>Donatas Banionis</b> and Natalya Bondarchuk; the novelist Lem, who disliked the adaptation.',
      what='<b>Solaris (1972)</b> set its drama on a space station orbiting a <b>sentient ocean-planet that materialises the crew’s buried memories</b>, focusing on a psychologist confronted by his dead wife, and won the <b>Grand Prix Spécial du Jury at Cannes</b>.',
      crux='He insisted that <b>the human interior, not the cosmos, was the true frontier</b> — technology bored him; conscience did not.',
      conseq='The film widened his international reputation while deepening his quarrel with genre and with the studios.',
      matters='He redefined a genre by refusing it — Solaris remains the touchstone for cinema that treats science fiction as philosophy.'),

    E('mirror', '1975', 'Mirror — memory as film', ['MASTERWORK', 'IDEAS'],
      'Tarkovsky makes his most personal and radical film, Mirror (1975) — a non-linear collage of a dying man’s memories, dreams and newsreel history, fusing his own childhood, his mother, his absent father’s poems (read aloud by Arseny himself) into a stream of images with almost no story — a film the authorities classify “third category” to bury it, yet which becomes a landmark of subjective cinema.',
      svg_stack('A film woven from memory and dream', [
          {'n': 1, 'label': 'Mirror released, 1975', 'sub': 'autobiography as non-linear collage', 'color': '#0f766e'},
          {'n': 2, 'label': 'Childhood, mother, father’s verse', 'sub': 'Arseny Tarkovsky reads his own poems', 'color': '#7c2d12'},
          {'n': 3, 'label': 'Buried as “third category”', 'sub': 'limited prints, minimal distribution', 'color': '#a16207'},
      ], takeaway='He dissolved plot entirely into memory — and the state punished the film’s difficulty by all but hiding it.', accent=AC),
      bg='Long planned as a portrait of his mother, <b>Mirror</b> grew into an autobiographical film blending private memory with the collective history of the Soviet twentieth century.',
      people='his mother, played in old age by <b>Maria Vishnyakova</b> herself; <b>Margarita Terekhova</b> in dual roles; his father <b>Arseny</b>, reading his poems on the soundtrack.',
      what='<b>Mirror (1975)</b> abandoned linear narrative for a <b>free flow of dreams, childhood scenes, newsreel footage and poetry</b>, and Soviet officials classified it in the restrictive <b>“third category,”</b> starving it of prints and screenings.',
      crux='He treated the camera as an instrument of <b>consciousness itself</b> — filming how memory actually feels, unmoored from chronology.',
      conseq='Baffling to censors and many contemporaries, it is now regarded as one of the supreme achievements of personal cinema.',
      matters='Some films teach audiences a new way to watch — Mirror expanded what film could hold: the shapeless truth of remembering.'),
]

# ==================================================================  PHASE 4 — THE ZONE
PHASE_ZONE = [
    E('stalker', '1976–1979', 'Stalker — the film that had to be made twice', ['MASTERWORK', 'ORDEAL'],
      'Tarkovsky’s last Soviet film, Stalker (1979) — a slow, hypnotic parable in which a guide leads a writer and a scientist through a forbidden “Zone” toward a room said to grant one’s deepest wish — becomes an ordeal: much of the first year’s footage is ruined in the lab, forcing him to reshoot the entire film, break with his cinematographer, and suffer a heart attack mid-production.',
      svg_row('A cursed shoot, reshot from zero', [
          {'n': 1, 'label': 'Filming begins, 1977', 'sub': 'a guide, a writer, a scientist, the Zone', 'color': '#0f766e'},
          {'n': 2, 'label': 'Footage ruined in the lab', 'sub': 'most of a year’s work destroyed', 'color': '#7c2d12'},
          {'n': 3, 'label': 'Reshot; a heart attack, 1978', 'sub': 'new cameraman, near-total remake', 'color': '#b91c1c'},
      ], edge_labels=['then', 'so'], takeaway='He rebuilt an entire masterpiece from ruin — the making of Stalker was as gruelling as the pilgrimage it depicts.', accent=AC),
      bg='Based on the Strugatsky brothers’ novel <b>Roadside Picnic</b>, Stalker imagined a mysterious, quarantined <b>Zone</b> left by some unexplained event.',
      people='the Strugatsky brothers, who rewrote the script many times; actors <b>Alexander Kaidanovsky</b>, Anatoly Solonitsyn, Nikolai Grinko; cinematographer Georgy Rerberg, later replaced.',
      what='During <b>Stalker (1976–79)</b> most of the initial footage was <b>destroyed by faulty film processing</b>, forcing Tarkovsky to <b>reshoot the film almost entirely</b>; he broke with cinematographer Rerberg and suffered a <b>heart attack in 1978</b> before completing it in 1979.',
      crux='He refused to abandon the film despite catastrophe, remaking it around a <b>slower, more meditative</b> vision than the first attempt.',
      conseq='The completed film won the Ecumenical Jury prize at Cannes and is revered as a pinnacle of philosophical cinema.',
      matters='Persistence can be a form of genius — Stalker exists only because its maker would not let a wrecked film die.'),

    E('hazards', '1977–1986', 'Poisoned ground', ['TRAGEDY', 'ORDEAL'],
      'The Stalker shoot is later suspected of being lethal: filmed near a chemical plant and a hydroelectric station in Estonia, amid water polluted by industrial runoff, the production exposes cast and crew to toxins — and Tarkovsky, his wife Larisa and the lead actor Anatoly Solonitsyn all later die of cancer, deaths many link to the poisoned locations of the Zone.',
      svg_stack('The Zone that may have killed its makers', [
          {'n': 1, 'label': 'Shot beside a chemical plant', 'sub': 'Estonia, near polluted river water', 'color': '#7c2d12'},
          {'n': 2, 'label': 'Cast and crew exposed to toxins', 'sub': 'wading through industrial runoff', 'color': '#a16207'},
          {'n': 3, 'label': 'Later cancer deaths', 'sub': 'Tarkovsky, Larisa, Solonitsyn', 'color': '#b91c1c'},
      ], takeaway='The imaginary poisoned Zone may have been literally poisonous — a grim shadow over Stalker’s legend.', accent=AC),
      bg='Stalker was filmed largely in <b>Estonia</b>, downstream of a chemical plant, in landscapes chosen for their derelict, contaminated look.',
      people='his wife <b>Larisa Tarkovskaya</b>, who worked on the film; lead actor <b>Anatoly Solonitsyn</b>; sound and crew members exposed on location.',
      what='The location placed the crew amid <b>industrial pollution and possibly toxic water</b>, and in the years after, Tarkovsky, his wife Larisa and actor <b>Anatoly Solonitsyn all died of cancer</b> — deaths biographers and colleagues have linked to the shoot.',
      crux='The suspicion is unprovable but haunting — that the <b>real environment stood in for the fictional Zone</b> at a terrible price.',
      conseq='It lent Stalker a mythic, sacrificial aura and darkened Tarkovsky’s final decade with illness.',
      matters='Art can demand the body as well as the soul — the Zone became a legend partly because its makers may have died for it.'),

    E('sculpting', '1979–1986', 'Sculpting in Time — the time-image', ['IDEAS', 'LEGACY'],
      'Across lectures, diaries and finally his 1986 book Sculpting in Time, Tarkovsky sets out his aesthetic: cinema’s unique power is to capture time itself, the director working like a sculptor who cuts away everything superfluous to leave “time-pressure” running through the long take — a theory of the slow, unbroken shot that reshapes how film is understood.',
      svg_row('Cinema as the art of time', [
          {'n': 1, 'label': 'A theory of film as time', 'sub': 'the director “sculpts in time”', 'color': '#0f766e'},
          {'n': 2, 'label': 'The long take and “time-pressure”', 'sub': 'rhythm carried by the unbroken shot', 'color': '#3730a3'},
          {'n': 3, 'label': 'Sculpting in Time, 1986', 'sub': 'his aesthetic set down in a book', 'color': '#166534'},
      ], edge_labels=['through', 'stated in'], takeaway='He gave slowness a philosophy — the long take as a way to make time itself visible on screen.', accent=AC),
      bg='Alongside his films Tarkovsky developed a rigorous theory of the medium, expressed in his diaries (the <b>Martyrolog</b>), lectures, and the book <b>Sculpting in Time</b>.',
      people='the film theorists and philosophers who took up his ideas; later, Gilles Deleuze and others writing on the cinematic <b>time-image</b>.',
      what='He argued that film’s essence is <b>“sculpting in time”</b> — that a director captures and shapes real duration, using <b>long, unbroken takes</b> whose inner rhythm he called <b>“time-pressure,”</b> a theory laid out fully in his 1986 book of that name.',
      crux='For him the cut was subordinate to duration — the <b>long take let time breathe</b>, making cinema unlike any other art.',
      conseq='His ideas became foundational for “slow cinema” and for generations of directors who followed him.',
      matters='Great artists often theorise their own practice — Tarkovsky gave the world a vocabulary for the poetry of the long take.'),
]

# ==================================================================  PHASE 5 — EXILE
PHASE_EXILE = [
    E('goskino', '1970s–1984', 'The long war with Goskino', ['POLITICS', 'CONFLICT'],
      'Every Tarkovsky film is a fight with the state: Goskino starves his projects of funds, delays and re-cuts his films, blocks their release and travel, and denies him work for long stretches — a slow attrition of a singular artist by a bureaucracy that neither trusts nor understands him, driving him at last to seek work abroad.',
      svg_compare('Two irreconcilable ideas of cinema', {
          'head': 'Tarkovsky’s cinema', 'color': '#0f766e',
          'items': ['Film as personal, spiritual art', 'Slowness, ambiguity, faith', 'The director as sole author', 'Truth over ideology'],
      }, {
          'head': 'What the state wanted', 'color': '#7c2d12',
          'items': ['Film as ideological instrument', 'Clarity, optimism, the collective', 'The committee as final authority', 'Ideology over vision'],
      }, verdict='An uncompromising auteur inside a system built to grind auteurs down — the conflict was structural, not personal.',
         takeaway='He and the Soviet film system wanted opposite things — and the system held the money, the labs and the borders.', accent=AC),
      bg='Soviet filmmaking ran through <b>Goskino</b>, the State Committee for Cinematography, which controlled budgets, approvals, distribution and foreign travel.',
      people='the officials of <b>Goskino</b> and the Union of Cinematographers; sympathetic colleagues; the actor Solonitsyn and others who stayed loyal to him.',
      what='Across his career Goskino <b>underfunded, delayed, re-edited and suppressed</b> his films, restricted his travel, and left him <b>idle for years at a time</b>, unable to realise projects — a steady bureaucratic strangulation of his work.',
      crux='The state treated his refusal to compromise as <b>disloyalty</b>, and answered it by denying him the means to make films.',
      conseq='By the early 1980s he concluded he could only work freely outside the USSR, and looked to Italy and the West.',
      matters='Systems can defeat individuals by exhaustion — Tarkovsky was not banned so much as slowly denied the oxygen to create.'),

    E('nostalghia', '1980–1983', 'Nostalghia — exile as subject', ['MASTERWORK', 'TURNING POINT'],
      'Working in Italy with the screenwriter Tonino Guerra, Tarkovsky makes Nostalghia (1983) — the story of a Russian poet abroad, consumed by homesickness and spiritual longing, who carries a lit candle across an empty pool in a single unbroken take — a film that is itself an act of exile, its funding pulled by Mosfilm and taken up by Italian television; at Cannes it wins three prizes.',
      svg_stack('A homesick film made in a foreign land', [
          {'n': 1, 'label': 'Made in Italy, 1980–83', 'sub': 'written with Tonino Guerra', 'color': '#0f766e'},
          {'n': 2, 'label': 'A Russian abroad, sick for home', 'sub': 'the candle carried across the pool', 'color': '#3730a3'},
          {'n': 3, 'label': 'Three prizes at Cannes, 1983', 'sub': 'Mosfilm pulls out; Italian RAI funds it', 'color': '#166534'},
      ], takeaway='He made a film about exile while becoming an exile — Nostalghia’s longing was already his own condition.', accent=AC),
      bg='Invited to work in Italy, Tarkovsky co-wrote <b>Nostalghia</b> with the celebrated screenwriter <b>Tonino Guerra</b>, filming it there as a Soviet-Italian production.',
      people='screenwriter <b>Tonino Guerra</b>; actors Oleg Yankovsky and Erland Josephson; the Italian broadcaster <b>RAI</b>, which financed it after Mosfilm withdrew.',
      what='<b>Nostalghia (1983)</b> followed a Russian poet in Italy paralysed by <b>homesickness and spiritual crisis</b>, culminating in the famous long take of a man carrying a candle across a drained pool; it won <b>three prizes at Cannes</b>, including a shared Grand Prix.',
      crux='The film fused his life and art — <b>the pain of separation from Russia</b> became both its theme and his reality.',
      conseq='Soviet authorities lobbied against its top Cannes award, deepening his sense that he could not go home.',
      matters='The most personal art is often the most universal — Nostalghia turned one man’s exile into a meditation on all belonging.'),

    E('defection', '1984', 'The Milan press conference', ['POLITICS', 'TURNING POINT'],
      'On 10 July 1984, at a press conference in Milan, Tarkovsky announces that he will not return to the Soviet Union — a public break with the state that had smothered his work, made under the strain of separation from his young son, held in the USSR as leverage — declaring himself an artist without a country rather than a political dissident.',
      svg_row('An artist declares his exile', [
          {'n': 1, 'label': 'Milan press conference, 1984', 'sub': '10 July: “I will not return”', 'color': '#0f766e'},
          {'n': 2, 'label': 'A break, not a defection of politics', 'sub': '“I am not a Soviet dissident”', 'color': '#3730a3'},
          {'n': 3, 'label': 'His son held as hostage', 'sub': 'the state keeps Andriosha in the USSR', 'color': '#b91c1c'},
      ], edge_labels=['saying', 'while'], takeaway='He chose freedom to make films over his homeland — but the state kept his young son, turning exile into agony.', accent=AC),
      bg='By 1984, after Nostalghia, Tarkovsky faced the choice of returning to certain unemployment in the USSR or staying in the West to work.',
      people='his wife <b>Larisa</b>, with him in the West; his son <b>Andrei Jr. (Andriosha)</b>, kept in the Soviet Union; the assembled Italian press.',
      what='At a <b>Milan press conference on 10 July 1984</b>, Tarkovsky publicly announced he would <b>not return to the Soviet Union</b>, framing it as an artistic necessity rather than dissidence — while the authorities <b>withheld his young son</b> as leverage against him.',
      crux='He accepted permanent exile as the price of <b>continuing to make films on his own terms</b> — a wrenching, deliberate rupture.',
      conseq='He was thereafter treated as a defector; his son was only allowed to join him in 1986 as he lay dying.',
      matters='Freedom can carry an unbearable cost — Tarkovsky bought his art’s liberty with separation from his own child.'),
]

# ==================================================================  PHASE 6 — LAST TESTAMENT
PHASE_LAST = [
    E('sacrifice', '1985–1986', 'The Sacrifice — a final testament', ['MASTERWORK', 'LEGACY'],
      'For his last film, The Sacrifice (1986), Tarkovsky works in Sweden with Ingmar Bergman’s great cinematographer Sven Nykvist — a parable of a man who, to avert nuclear apocalypse, vows to give up everything he loves — climaxing in a house set ablaze in one unbroken shot; made as cancer took hold, it plays as the spiritual last will of a dying artist.',
      svg_stack('A dying man’s film about giving everything up', [
          {'n': 1, 'label': 'The Sacrifice, shot in Sweden 1985', 'sub': 'with Bergman’s cameraman Sven Nykvist', 'color': '#0f766e'},
          {'n': 2, 'label': 'A vow to avert apocalypse', 'sub': 'a man renounces all he loves', 'color': '#3730a3'},
          {'n': 3, 'label': 'The burning house, one take', 'sub': 'a final unbroken long shot', 'color': '#7c2d12'},
      ], takeaway='His last film was a testament — faith, sacrifice and the end of the world, made as he was dying.', accent=AC),
      bg='Settled in the West, Tarkovsky made his final film in <b>Sweden</b>, working with collaborators of <b>Ingmar Bergman</b>, whom he revered.',
      people='cinematographer <b>Sven Nykvist</b>, Bergman’s longtime collaborator; actor <b>Erland Josephson</b> in the lead; Tarkovsky, already gravely ill.',
      what='<b>The Sacrifice (1986)</b> told of a man who <b>vows to renounce everything he loves</b> to save the world from nuclear catastrophe, ending in the celebrated <b>single-take burning of a house</b>; it won the Grand Prix Spécial du Jury at Cannes.',
      crux='It distilled his lifelong themes — <b>faith, sacrifice and redemption</b> — into a final, valedictory statement.',
      conseq='Filmed as cancer advanced, it became his farewell to cinema, dedicated to his son “with hope and confidence.”',
      matters='A final work can crown a life — The Sacrifice reads as the spiritual summation of everything Tarkovsky believed film could be.'),

    E('death', '1986', 'Death in Paris', ['DEATH', 'TRAGEDY'],
      'Diagnosed with lung cancer at the end of 1985, Tarkovsky is treated in Paris — his son finally allowed out of the USSR to be at his side — and dies on 29 December 1986, aged fifty-four, having published Sculpting in Time that same year and been buried among fellow Russian exiles beneath a stone inscribed “to the man who saw the Angel.”',
      svg_row('An exile’s death, an artist’s testament', [
          {'n': 1, 'label': 'Lung cancer, treated in Paris', 'sub': 'diagnosed late 1985', 'color': '#7c2d12'},
          {'n': 2, 'label': 'Dies 29 December 1986', 'sub': 'aged 54, his son at last beside him', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Sculpting in Time published', 'sub': 'buried “to the man who saw the Angel”', 'color': '#0f766e'},
      ], edge_labels=['and', 'while'], takeaway='He died in exile at fifty-four — but left a book and seven films that secured his immortality.', accent=AC),
      bg='At the close of 1985 Tarkovsky was diagnosed with <b>lung cancer</b> and sought treatment in <b>Paris</b>, where he spent his final year.',
      people='his wife <b>Larisa</b>; his son <b>Andrei Jr.</b>, finally permitted to leave the USSR to join him; the émigré community that mourned him.',
      what='Tarkovsky <b>died on 29 December 1986 in Paris, aged 54</b>; his book <b>Sculpting in Time</b> appeared that year, and he was buried at the <b>Sainte-Geneviève-des-Bois</b> Russian cemetery under a stone reading “to the man who saw the Angel.”',
      crux='He died an <b>exile from the country whose soul his films had captured</b> — never permitted to return.',
      conseq='His early death at the height of his powers sealed his legend and left his small body of work luminous and complete.',
      matters='A life cut short can still be whole — seven features and one book made Tarkovsky one of cinema’s undisputed masters.'),

    E('legacy', '1986–', 'The poet of cinema', ['LEGACY', 'TRIUMPH'],
      'Tarkovsky leaves only seven feature films, yet stands among the most revered and influential directors in the history of the medium — Ingmar Bergman calling him the greatest, the inventor of “a new language” — his spiritual seriousness, painterly long takes and “sculpting in time” shaping slow cinema and auteurs across the world for generations.',
      svg_stack('Seven films, an immortal reputation', [
          {'n': 1, 'label': 'Only seven features', 'sub': 'each ranked among cinema’s greatest', 'color': '#0f766e'},
          {'n': 2, 'label': 'Bergman’s highest praise', 'sub': '“invented a new language” of film', 'color': '#3730a3'},
          {'n': 3, 'label': 'Father of “slow cinema”', 'sub': 'shaping auteurs across the world', 'color': '#166534'},
      ], takeaway='He proved a handful of uncompromising films could outweigh a hundred — the measure of an artist is depth, not output.', accent=AC),
      bg='Tarkovsky completed just <b>seven feature films</b> — Ivan’s Childhood, Andrei Rublev, Solaris, Mirror, Stalker, Nostalghia and The Sacrifice — yet none is regarded as minor.',
      people='<b>Ingmar Bergman</b>, who hailed him as the greatest; the countless directors — from Sokurov to Malick and beyond — who acknowledge his influence.',
      what='He is <b>consistently ranked among the greatest directors ever</b>; <b>Bergman said he had “invented a new language”</b> of cinema, and his aesthetic of the long take and spiritual gravity founded much of what is now called <b>“slow cinema.”</b>',
      crux='His legacy rests on <b>uncompromising vision</b> — the belief that film is a spiritual and poetic art, not entertainment.',
      conseq='He remains a touchstone for serious filmmakers and the patron saint of cinema as an art of contemplation.',
      matters='Influence is not measured in volume — Tarkovsky’s seven films reshaped the ambitions of cinema itself.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Andrei Tarkovsky was the poet of cinema — a Soviet director who insisted film was a spiritual art, capable of “sculpting in time,” and who made only seven features yet stands among the greatest and most influential directors in history. Son of a poet, trained under Mikhail Romm, he broke through at thirty with the Venice-winning Ivan’s Childhood, then spent his life at war with Soviet censors over Andrei Rublev, Solaris, Mirror and Stalker — before exile in the West gave him Nostalghia and The Sacrifice, and cancer took him in Paris at fifty-four. He is the ultimate study in <b>uncompromising artistic vision under a hostile state.</b></p>
<div class="ov-quote">“I try to make films that are like a mirror, in which everyone can see themselves.”<span>— Andrei Tarkovsky, on his cinema</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born the son of a poet and trained under Romm → wins Venice at thirty with Ivan’s Childhood → makes the monumental Andrei Rublev, buried by censors for five years → turns science fiction inward in Solaris and dissolves narrative into memory in Mirror → survives the ruinous, possibly poisonous shoot of Stalker → theorises film as “sculpting in time” → and, driven into exile, makes Nostalghia and The Sacrifice before dying in Paris in 1986.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🎞️</div><h4>Cinema as poetry</h4><p>He treated film as a spiritual, painterly art — not entertainment.</p></div>
  <div class="ov-card"><div class="i">⏳</div><h4>Sculpting in time</h4><p>The long take and “time-pressure” founded modern slow cinema.</p></div>
  <div class="ov-card"><div class="i">🕯️</div><h4>Vision under tyranny</h4><p>He made uncompromising films inside a system built to crush them.</p></div>
  <div class="ov-card"><div class="i">🌍</div><h4>Exile and influence</h4><p>Seven films that reshaped the ambitions of directors worldwide.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Roots</b><small> 1932–1961</small><p>A poet’s son, VGIK under Romm, the first student films.</p></div>
  <div><b>2 · Triumph &amp; Censors</b><small> 1962–1971</small><p>Ivan’s Childhood, Andrei Rublev, and the buried masterpiece.</p></div>
  <div><b>3 · Inner Cosmos</b><small> 1972–1975</small><p>Solaris and Mirror — sci-fi and memory made poetry.</p></div>
  <div><b>4 · The Zone</b><small> 1976–1986</small><p>Stalker, its poisoned shoot, and the theory of time.</p></div>
  <div><b>5 · Exile</b><small> 1980–1984</small><p>Nostalghia, the war with Goskino, the Milan break.</p></div>
  <div><b>6 · Last Testament</b><small> 1985–</small><p>The Sacrifice, death in Paris, and the legend.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Arseny Tarkovsky', 'role': 'father, poet', 'color': '#7c2d12',
     'bio': 'The celebrated Russian poet who left the family in 1937; his verse, read aloud in Mirror, threads through his son’s films.',
     'rel': 'The absent father whose poetry shaped Andrei’s whole sensibility.'},
    {'name': 'Mikhail Romm', 'role': 'teacher at VGIK', 'color': '#0f766e',
     'bio': 'The veteran director who taught Tarkovsky at the state film school and encouraged a generation of young auteurs to find personal styles.',
     'rel': 'The mentor who gave him licence to be uncompromising.'},
    {'name': 'Larisa Tarkovskaya', 'role': 'wife, collaborator', 'color': '#a16207',
     'bio': 'His second wife, met on Andrei Rublev, who worked on his films and shared his exile; she too later died of cancer.',
     'rel': 'His partner in life, work and exile in the West.'},
    {'name': 'Anatoly Solonitsyn', 'role': 'lead actor', 'color': '#b91c1c',
     'bio': 'Tarkovsky’s favourite actor, the star of Andrei Rublev, Solaris, Mirror and Stalker, who died of cancer in 1982.',
     'rel': 'His signature leading man across four films.'},
    {'name': 'Sven Nykvist', 'role': 'cinematographer', 'color': '#3730a3',
     'bio': 'Ingmar Bergman’s legendary cinematographer, who shot Tarkovsky’s final film The Sacrifice in Sweden in 1985.',
     'rel': 'The master cameraman of his last testament.'},
    {'name': 'Goskino', 'role': 'the Soviet censors', 'color': '#78350f',
     'bio': 'The State Committee for Cinematography that controlled Soviet film — funding, cutting, delaying and suppressing Tarkovsky’s work for two decades.',
     'rel': 'The bureaucracy whose obstruction drove him into exile.'},
]

KEY_EVENTS = [
    ('1932', 'Tarkovsky born', 'Son of poet Arseny Tarkovsky, on the Volga.'),
    ('1960', 'The Steamroller and the Violin', 'Graduation film wins in New York.'),
    ('1962', 'Ivan’s Childhood', 'Golden Lion at the Venice Film Festival.'),
    ('1966', 'Andrei Rublev completed', 'Epic on the icon painter; shelved by censors.'),
    ('1971', 'Rublev finally released', 'Five years after completion, in a cut version.'),
    ('1972', 'Solaris', 'Grand Prix Spécial du Jury at Cannes.'),
    ('1975', 'Mirror', 'Autobiographical collage; buried “third category.”'),
    ('1979', 'Stalker', 'Reshot after ruined footage; a poisoned Zone.'),
    ('1983', 'Nostalghia', 'Made in Italy; three prizes at Cannes.'),
    ('1984', 'Milan press conference', 'Announces he will not return to the USSR.'),
    ('1986', 'The Sacrifice', 'Final film, in Sweden with Sven Nykvist.'),
    ('1986', 'Death in Paris', 'Dies of cancer, aged 54; Sculpting in Time published.'),
]

MASTER = [
    {'year': '1932', 'age': 'born', 'phase': 'Roots', 'title': 'Born on the Volga', 'desc': 'Son of poet Arseny Tarkovsky.'},
    {'year': '1954', 'age': 'age 22', 'phase': 'Roots', 'title': 'Enters VGIK', 'desc': 'Studies under Mikhail Romm.'},
    {'year': '1962', 'age': 'age 30', 'phase': 'Triumph & Censors', 'title': 'Ivan’s Childhood', 'desc': 'Golden Lion at Venice.'},
    {'year': '1966', 'age': 'age 34', 'phase': 'Triumph & Censors', 'title': 'Andrei Rublev', 'desc': 'Completed, then shelved for years.'},
    {'year': '1972', 'age': 'age 40', 'phase': 'Inner Cosmos', 'title': 'Solaris', 'desc': 'Grand Prix at Cannes.'},
    {'year': '1975', 'age': 'age 43', 'phase': 'Inner Cosmos', 'title': 'Mirror', 'desc': 'Memory dissolved into film.'},
    {'year': '1979', 'age': 'age 47', 'phase': 'The Zone', 'title': 'Stalker', 'desc': 'Reshot from ruin; his last Soviet film.'},
    {'year': '1983', 'age': 'age 51', 'phase': 'Exile', 'title': 'Nostalghia', 'desc': 'Made in Italy; three Cannes prizes.'},
    {'year': '1984', 'age': 'age 52', 'phase': 'Exile', 'title': 'The Milan break', 'desc': 'Will not return to the USSR.'},
    {'year': '1986', 'age': 'age 54', 'phase': 'Last Testament', 'title': 'The Sacrifice & death', 'desc': 'Final film; dies in Paris.'},
]

SOURCES = [
    ('Wikipedia — Andrei Tarkovsky', 'https://en.wikipedia.org/wiki/Andrei_Tarkovsky'),
    ('Britannica — Andrey Tarkovsky', 'https://www.britannica.com/biography/Andrey-Tarkovsky'),
    ('Senses of Cinema — Great Directors: Tarkovsky', 'https://www.sensesofcinema.com/2002/great-directors/tarkovsky/'),
    ('Wikipedia — Sculpting in Time', 'https://en.wikipedia.org/wiki/Sculpting_in_Time'),
    ('Wikipedia — Stalker (1979 film)', 'https://en.wikipedia.org/wiki/Stalker_(1979_film)'),
    ('Offscreen — Tarkovsky’s Theory of Time-Pressure', 'https://offscreen.com/view/tarkovsky1'),
]

def build_meta():
    return {
        'pid': 'gm-tarkovsky.html', 'kind': 'man', 'emoji': '🎬', 'accent': AC,
        'name': 'Andrei Tarkovsky', 'years': '1932–1986', 'group': 'Artists & Filmmakers',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Soviet poet of cinema who made only seven films — from Andrei Rublev to Stalker to The Sacrifice — yet, defying the censors and dying in exile, became one of the most revered and influential directors in the history of the medium.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'roots', 'label': '1 · Roots', 'type': 'timeline',
             'intro': 'Born the son of the poet Arseny Tarkovsky and trained under Mikhail Romm at VGIK, he arrives as a fully formed poet-director with his very first films.', 'events': PHASE_ROOTS},
            {'id': 'break', 'label': '2 · Triumph & Censors', 'type': 'timeline',
             'intro': 'Ivan’s Childhood wins Venice at thirty — but the monumental Andrei Rublev falls foul of the censors and is buried for five years.', 'events': PHASE_BREAK},
            {'id': 'cosmos', 'label': '3 · Inner Cosmos', 'type': 'timeline',
             'intro': 'He turns science fiction inward in Solaris and dissolves narrative into pure memory in Mirror — the most personal of all his films.', 'events': PHASE_COSMOS},
            {'id': 'zone', 'label': '4 · The Zone', 'type': 'timeline',
             'intro': 'Stalker is reshot from ruin on a possibly poisonous location — and around it he sets down his theory of cinema as “sculpting in time.”', 'events': PHASE_ZONE},
            {'id': 'exile', 'label': '5 · Exile', 'type': 'timeline',
             'intro': 'Worn down by his long war with Goskino, he makes Nostalghia in Italy and, at a Milan press conference in 1984, refuses to return to the USSR.', 'events': PHASE_EXILE},
            {'id': 'last', 'label': '6 · Last Testament', 'type': 'timeline',
             'intro': 'In Sweden he makes The Sacrifice with Sven Nykvist — then dies of cancer in Paris in 1986, an exile at the height of his powers.', 'events': PHASE_LAST,
             'sources': SOURCES, 'srcnote': 'Standard biographies and encyclopaedic sources, together with festival records and Tarkovsky’s own Sculpting in Time; the link between the Stalker location and later cancers is widely reported but remains a strong suspicion rather than proven fact.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
