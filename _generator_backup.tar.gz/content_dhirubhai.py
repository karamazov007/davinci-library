# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Dhirubhai Ambani.
The schoolteacher’s son who built Reliance into India’s largest private enterprise and founded India’s equity culture."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#0369a1'  # confident business blue

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — HUMBLE ORIGINS
PHASE_ORIGINS = [
    E('birth', '1932', 'A schoolteacher’s son in Chorwad', ['RISE', 'ORIGINS'],
      'Dhirajlal Hirachand Ambani is born on 28 December 1932 in Chorwad, a coastal village in the Junagadh princely state of Gujarat, the son of Hirachand Gordhanbhai Ambani, a modestly paid village schoolteacher — a childhood of scarcity in which the boy hawks snacks to pilgrims and sells fried goods to make a few extra rupees.',
      svg_row('From village scarcity to ambition', [
          {'n': 1, 'label': 'Born in Chorwad, Gujarat, 1932', 'sub': 'a village in the Junagadh princely state', 'color': '#0369a1'},
          {'n': 2, 'label': 'Son of a village schoolteacher', 'sub': 'Hirachand Ambani, on a modest salary', 'color': '#b45309'},
          {'n': 3, 'label': 'A boy who hustles for rupees', 'sub': 'sells snacks and fritters to pilgrims', 'color': '#166534'},
      ], edge_labels=['as', 'so'], takeaway='He began with almost nothing — the ambition that built Reliance was forged by early want.', accent=AC),
      bg='<b>Dhirajlal “Dhirubhai” Hirachand Ambani</b> was born on <b>28 December 1932</b> in Chorwad, Gujarat, into a Modh Bania family of limited means.',
      people='his father <b>Hirachand Gordhanbhai Ambani</b>, a village schoolteacher; his mother Jamnaben; the pilgrims and villagers he sold snacks to as a boy.',
      what='Dhirubhai grew up <b>poor in a small coastal village</b>, one of several children of a low-paid teacher; as a teenager he sold fried snacks (<b>bhajias</b>) to pilgrims near Junagadh to help the family.',
      crux='Scarcity taught him early that <b>opportunity had to be seized, not waited for</b> — a lesson that shaped his whole career.',
      conseq='Restless and with little formal education, he left for the Arab port of Aden as a young man in search of work.',
      matters='India’s greatest private fortune began in a schoolteacher’s home — proof that origin need not fix destiny.'),

    E('aden', '1949–1958', 'The clerk in Aden', ['RISE', 'FORMATION'],
      'Around the age of sixteen Dhirubhai sails to Aden — then a booming British free-trade port in Yemen — and takes work as a clerk and petrol-pump attendant for A. Besse & Co, the region’s largest trading house and a Shell distributor; there he learns commodities, currencies and oil, and legend holds he once melted down Yemeni silver rials because the metal was worth more than the coins’ face value.',
      svg_stack('An apprenticeship in trade and oil', [
          {'n': 1, 'label': 'Sails to Aden as a teenager', 'sub': 'a British free port booming on trade', 'color': '#0369a1'},
          {'n': 2, 'label': 'Clerk for A. Besse & Co', 'sub': 'the largest trading firm east of Suez, a Shell agent', 'color': '#b45309'},
          {'n': 3, 'label': 'Learns commodities, currency, oil', 'sub': 'the silver-rial legend; a merchant’s instincts', 'color': '#166534'},
      ], takeaway='Aden was his university — he learned global trade and the oil business years before he owned a single share.', accent=AC),
      bg='In the late 1940s Dhirubhai left India for <b>Aden</b>, a thriving British colonial port and one of the world’s busiest bunkering and trading hubs.',
      people='his employer <b>A. Besse & Co</b>, agents for <b>Shell</b>; the Arab, Indian and European traders of the Aden bazaar; his brother Ramniklal, already working there.',
      what='He worked as a <b>clerk and later filling-station attendant</b> for A. Besse & Co, absorbing the mechanics of commodity trading, foreign exchange and the petroleum trade; a famous anecdote holds he <b>melted Yemeni silver rials</b> whose bullion value exceeded their face value.',
      crux='Aden gave him a <b>practical education in world trade</b> that no Indian classroom of his youth could — and a lifelong feel for oil.',
      conseq='When the Suez crisis and Yemeni turmoil dimmed Aden’s fortunes, he returned to India in 1958 to start on his own.',
      matters='The instincts that would remake Indian industry were sharpened not in Bombay but in a foreign port’s trading rooms.'),
]

# ==================================================================  PHASE 2 — THE TRADER
PHASE_TRADER = [
    E('return', '1958', 'Reliance Commercial Corporation', ['RISE', 'FOUNDING'],
      'Returning to India in 1958 with a few thousand rupees, Dhirubhai founds Reliance Commercial Corporation in Bombay — a tiny trading firm run from a 350-square-foot office with a telephone, one table and three chairs — importing polyester yarn and exporting spices to Yemen, betting on the gap between what India made badly and what the world wanted.',
      svg_row('A trading house from a 350 sq ft room', [
          {'n': 1, 'label': 'Returns to Bombay, 1958', 'sub': 'with modest savings and large ambition', 'color': '#0369a1'},
          {'n': 2, 'label': 'Founds Reliance Commercial Corp', 'sub': 'a 350 sq ft office: a phone, a table, three chairs', 'color': '#b45309'},
          {'n': 3, 'label': 'Yarn in, spices out', 'sub': 'imports polyester yarn, exports spices to Yemen', 'color': '#166534'},
      ], edge_labels=['and', 'so'], takeaway='Reliance began as a two-way trading bet — buying cheap, selling dear across two markets he understood.', accent=AC),
      bg='In <b>1958</b> Dhirubhai settled in Bombay and set up <b>Reliance Commercial Corporation</b>, initially in partnership with his cousin Champaklal Damani.',
      people='his cousin and partner <b>Champaklal Damani</b>; the Yemeni spice buyers he knew from Aden; Bombay’s yarn merchants of the Masjid Bunder district.',
      what='He ran a lean commodity-trading business from a <b>350 sq ft office at Narsi Natha Street</b>, <b>importing polyester (nylon) yarn</b> into a starved Indian market and <b>exporting spices</b>, ginger and other goods to Yemen.',
      crux='He spotted that <b>synthetic yarn commanded huge margins</b> in a protected, shortage-ridden India — and moved to supply it.',
      conseq='The yarn trade generated the capital and market knowledge he would soon plough into making the fibre himself.',
      matters='Great enterprises often start as arbitrage — Reliance’s empire grew from a trader’s eye for a price gap.'),

    E('damani-split', '1965', 'Going it alone', ['POLITICS', 'TURNING POINT'],
      'By 1965 Dhirubhai and his cautious cousin Champaklal Damani part ways — Damani wary of the risks Dhirubhai wanted to take, from speculative yarn positions to building factories — and Dhirubhai keeps the Reliance name, free now to pursue an aggressive, risk-hungry vision of growth on his own terms.',
      svg_compare('Two temperaments in one firm', {
          'head': 'Dhirubhai’s instinct', 'color': '#0369a1',
          'items': ['Take big, calculated risks', 'Build factories, not just trade', 'Move fast on scarce licences', 'Grow aggressively on debt and equity'],
      }, {
          'head': 'Damani’s caution', 'color': '#b45309',
          'items': ['Keep the business small and safe', 'Stay a trader, avoid capital sinks', 'Limit speculative exposure', 'Preserve what had been earned'],
      }, verdict='The partners split in 1965; Dhirubhai kept Reliance and its appetite for risk.',
         takeaway='The break freed Dhirubhai to be as bold as he wished — the firm now mirrored one man’s ambition.', accent=AC),
      bg='The Reliance partnership had grown, but the two founders differed sharply over how much risk the business should take.',
      people='<b>Champaklal Damani</b>, the risk-averse cousin; Dhirubhai, hungry to expand; the family that watched the two diverge.',
      what='Around <b>1965</b> the partnership dissolved; <b>Damani exited</b> while Dhirubhai <b>retained the Reliance name and business</b>, now sole master of its direction.',
      crux='Freed of a cautious partner, Dhirubhai could <b>pursue manufacturing and scale</b> without compromise.',
      conseq='Within a year he committed Reliance to building its own textile mill — the first great leap.',
      matters='Ventures are shaped by who stays and who goes — the split let the bolder vision win.'),

    E('naroda', '1966', 'Into textiles — the Naroda mill', ['RISE', 'INDUSTRY'],
      'In 1966 Dhirubhai stops merely trading yarn and starts weaving it — building a textile mill at Naroda near Ahmedabad to make synthetic blended fabrics, integrating forward from importer to manufacturer, and setting the pattern that would define Reliance: never stay a middleman when you can own the whole chain.',
      svg_stack('From trader to manufacturer', [
          {'n': 1, 'label': 'Builds the Naroda mill, 1966', 'sub': 'a textile plant near Ahmedabad, Gujarat', 'color': '#0369a1'},
          {'n': 2, 'label': 'Makes synthetic blended fabric', 'sub': 'polyester blends the market craved', 'color': '#b45309'},
          {'n': 3, 'label': 'Owns the chain, not just the trade', 'sub': 'the first step of relentless integration', 'color': '#166534'},
      ], takeaway='Naroda turned a trader into an industrialist — and set the integrate-everything logic Reliance never abandoned.', accent=AC),
      bg='Having profited from importing yarn, Dhirubhai moved to <b>manufacture the finished fabric himself</b>, capturing more of the value chain.',
      people='the Gujarati textile engineers and workers of Naroda; Bombay’s cloth wholesalers; the growing middle-class buyers of synthetic cloth.',
      what='In <b>1966</b> Reliance built a <b>textile mill at Naroda</b>, near Ahmedabad, producing polyester-blended fabrics — Dhirubhai’s first move from trading into large-scale manufacturing.',
      crux='He grasped that <b>the real margins lay in making, not just moving</b>, and in controlling quality and supply end to end.',
      conseq='The mill’s output needed a brand and a market — which Dhirubhai would build with Vimal.',
      matters='The Naroda decision founded the integration strategy that would carry Reliance from cloth all the way to crude oil.'),
]

# ==================================================================  PHASE 3 — VIMAL & THE EQUITY CULT
PHASE_EQUITY = [
    E('vimal', '1966–1980', 'The Vimal brand and the retail revolution', ['RISE', 'TRIUMPH'],
      'Dhirubhai builds a consumer brand where India had only anonymous cloth — "Only Vimal," named after his brother’s son, marketed with lavish advertising and sold through a nationwide web of exclusive franchised showrooms — turning Reliance fabric into an aspirational household name and pioneering modern branded retail in Indian textiles.',
      svg_row('Building a brand where none existed', [
          {'n': 1, 'label': 'Launches the “Vimal” brand', 'sub': 'named for his nephew; “Only Vimal”', 'color': '#0369a1'},
          {'n': 2, 'label': 'Lavish advertising and glamour', 'sub': 'fabric sold as aspiration, not commodity', 'color': '#b45309'},
          {'n': 3, 'label': 'Exclusive franchised showrooms', 'sub': 'a nationwide retail network for Reliance cloth', 'color': '#166534'},
      ], edge_labels=['with', 'through'], takeaway='He made cloth a brand and built the shops to sell it — controlling the customer, not just the factory.', accent=AC),
      bg='Indian textiles were largely sold as unbranded cloth through traditional traders; Dhirubhai saw room for a <b>branded, marketed product</b>.',
      people='the ad agencies that glamourised Vimal; the thousands of franchisees who ran <b>“Only Vimal”</b> stores; India’s rising middle-class consumers.',
      what='Reliance launched the <b>Vimal</b> brand (named after nephew Vimal), backed it with <b>heavy advertising</b>, and sold it through a chain of <b>exclusive franchised showrooms</b> across India — a break from the traditional wholesale trade.',
      crux='By <b>owning the brand and the shelf</b>, Reliance captured demand and pricing power the old cloth trade never had.',
      conseq='Vimal’s success funded — and demanded — ever-larger fibre plants, driving Reliance deeper upstream.',
      matters='He pioneered branded retail in Indian textiles, showing that even a commodity could be sold as a name.'),

    E('ipo', '1977', 'The 1977 IPO — banks say no, the public says yes', ['POLITICS', 'TURNING POINT', 'TRIUMPH'],
      'When India’s nationalised banks and financial institutions refuse to fund his expansion, Dhirubhai goes straight to the public: Reliance Textile Industries lists on the Bombay Stock Exchange in 1977, raising capital directly from ordinary savers — a gambit that not only funds Reliance but plants the seed of India’s first true mass equity culture.',
      svg_stack('Bypassing the banks, courting the public', [
          {'n': 1, 'label': 'Banks refuse to finance growth', 'sub': 'nationalised lenders wary of the newcomer', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Reliance goes public, 1977', 'sub': 'lists on the Bombay Stock Exchange', 'color': '#0369a1'},
          {'n': 3, 'label': 'Capital raised from ordinary savers', 'sub': 'the small investor funds the empire', 'color': '#166534'},
      ], takeaway='Shut out by the banks, he turned the ordinary saver into his banker — and changed how India financed industry.', accent=AC),
      bg='India’s post-1969 <b>nationalised banking system</b> was cautious toward ambitious private promoters; Reliance struggled to raise institutional finance for expansion.',
      people='the reluctant nationalised banks and DFIs; the retail investors who bought the shares; India’s small stock-broking community.',
      what='In <b>1977</b> Reliance Textile Industries made its <b>initial public offering on the Bombay Stock Exchange</b>, raising money directly from the public rather than from banks that had turned it down.',
      crux='He realised the <b>public equity market could fund what the banks would not</b> — and that millions of small savers, courted well, were a limitless bank.',
      conseq='Legions of first-time investors bought Reliance, seeding a shareholder base that would swell into the millions.',
      matters='The 1977 IPO is a turning point in Indian capitalism — the moment industry learned to raise money from the crowd.'),

    E('equity-cult', '1977–1985', 'The equity cult — a nation of shareholders', ['POLITICS', 'LEGACY'],
      'Dhirubhai keeps his word to small investors — rewarding them with bonus shares, generous dividends and rising prices — and they repay him with loyalty, turning Reliance into the company with the largest shareholder base in India; its annual general meetings grow so vast they are held in football stadiums, filled with tens of thousands of ordinary owners.',
      svg_row('Turning savers into loyal owners', [
          {'n': 1, 'label': 'Rewards the small investor', 'sub': 'bonus shares, dividends, rising prices', 'color': '#0369a1'},
          {'n': 2, 'label': 'Largest shareholder base in India', 'sub': 'millions of ordinary Indians own Reliance', 'color': '#b45309'},
          {'n': 3, 'label': 'AGMs fill football stadiums', 'sub': 'tens of thousands of owners attend', 'color': '#166534'},
      ], edge_labels=['so', 'until'], takeaway='He built a mass constituency of shareholders — a base of loyalty and capital no rival could match.', accent=AC),
      bg='After 1977 Reliance made the <b>retail shareholder central to its financing</b>, repeatedly returning to the public for capital via shares and debentures.',
      people='the millions of small Reliance shareholders; the middle-class families who bought in; the brokers and agents who spread the shares nationwide.',
      what='Reliance <b>rewarded investors handsomely</b> — bonus issues, high dividends and soaring share prices — and grew the <b>largest shareholder base of any Indian company</b>, its <b>AGMs held in stadiums</b> to accommodate the crowds.',
      crux='He treated shareholders as <b>partners to be enriched</b>, converting them into a loyal, self-renewing source of capital.',
      conseq='This deep equity base financed Reliance’s enormous capital projects for decades.',
      matters='Dhirubhai is credited with creating India’s “equity cult” — making stock ownership a middle-class habit.'),
]

# ==================================================================  PHASE 4 — BACKWARD INTEGRATION
PHASE_INTEGRATION = [
    E('integration', '1980–1991', 'Backward integration — cloth to crude', ['INDUSTRY', 'STRATEGY'],
      'Dhirubhai drives Reliance relentlessly up the value chain: from finished fabric back to polyester fibre, then to the petrochemical intermediates that make the fibre, then toward refining crude oil itself — each step capturing a supplier’s margin, so that by the 1990s Reliance is remaking itself from a textile firm into a petrochemicals-and-refining colossus.',
      svg_row('Climbing the chain, one link at a time', [
          {'n': 1, 'label': 'Fabric and yarn', 'sub': 'the textile business it began with', 'color': '#166534'},
          {'n': 2, 'label': 'Polyester fibre and filament', 'sub': 'make the raw material, not buy it', 'color': '#0369a1'},
          {'n': 3, 'label': 'Petrochemicals, then refining', 'sub': 'intermediates and crude oil itself', 'color': '#6d28d9'},
      ], edge_labels=['back to', 'back to'], takeaway='Every input became a business — Reliance kept moving upstream until it owned the chain from crude oil to cloth.', accent=AC),
      bg='Rather than buy fibre and chemicals from others, Dhirubhai chose to <b>make each input Reliance needed</b>, capturing every margin in the chain.',
      people='the engineers who built each new plant; global technology and licence suppliers; the financiers and shareholders who funded the capital.',
      what='Reliance integrated <b>backward step by step</b> — from fabric to <b>polyester fibre</b>, then to <b>petrochemical intermediates (PTA, MEG, PX)</b>, then toward <b>oil refining</b> — transforming from a textile firm into a petrochemicals giant.',
      crux='Vertical integration gave Reliance <b>cost control, scale and independence from suppliers</b> that competitors could not match.',
      conseq='The logic culminated in the vast Patalganga and later Jamnagar complexes, and India’s largest private company.',
      matters='His integration doctrine — own everything from crude to consumer — became the template for Reliance’s scale.'),

    E('patalganga', '1982–1986', 'Patalganga and the scale gambit', ['INDUSTRY', 'RISE'],
      'Dhirubhai builds a huge petrochemical complex at Patalganga, near Bombay, making polyester filament yarn and, crucially, purified terephthalic acid (PTA) — the modern feedstock for polyester — betting that world-scale plants and the newest technology would let Reliance produce far cheaper than smaller rivals, and set the industry’s terms.',
      svg_stack('Betting on world-scale plants', [
          {'n': 1, 'label': 'Builds Patalganga complex', 'sub': 'a large petrochemical site near Bombay', 'color': '#0369a1'},
          {'n': 2, 'label': 'Makes PTA and polyester filament', 'sub': 'PTA — the modern feedstock for polyester', 'color': '#b45309'},
          {'n': 3, 'label': 'Scale drives costs down', 'sub': 'newest tech, biggest plants, lowest price', 'color': '#166534'},
      ], takeaway='He built bigger and newer than anyone dared — winning on cost by sheer scale.', accent=AC),
      bg='To feed its fibre business, Reliance moved into <b>petrochemical manufacturing</b> at a scale then unprecedented for an Indian private firm.',
      people='the plant’s technology partners; the workers of Patalganga; rival fibre makers who used the older DMT route.',
      what='At <b>Patalganga</b> Reliance built capacity for <b>polyester filament yarn</b> and <b>purified terephthalic acid (PTA)</b>, the cheaper, more modern polyester feedstock, betting on <b>large-scale, latest-technology plants</b> to undercut competitors.',
      crux='He wagered that <b>scale and modern technology</b> would crush higher-cost rivals — a bet that repeatedly paid off.',
      conseq='The PTA choice put Reliance on a collision course with DMT-based rivals like Bombay Dyeing.',
      matters='Patalganga proved his core theory of the business: build biggest, newest and cheapest, and the market follows.'),

    E('license-raj', '1980s', 'Mastering the License Raj', ['POLITICS', 'CONTROVERSY'],
      'Reliance thrives inside India’s tangle of industrial licences, import quotas and tariffs — the "License Raj" — and Dhirubhai becomes famed, and to critics infamous, for his mastery of Delhi: cultivating officials and ministers, securing timely licences and favourable policy, and turning the regulatory maze that hobbled rivals into a competitive weapon.',
      svg_compare('A talent seen two ways', {
          'head': 'Admirers’ view', 'color': '#0369a1',
          'items': ['Navigated a broken system brilliantly', 'Won licences rivals could not', 'Built world-class plants under quotas', 'Delivered growth, jobs and exports'],
      }, {
          'head': 'Critics’ view', 'color': '#b91c1c',
          'items': ['Bent policy through political access', 'Gained unfair regulatory advantage', 'Blurred lines of business and the state', 'Prospered on connections, not just merit'],
      }, verdict='Both sides agree he mastered the License Raj; they disagree on whether that was genius or cronyism.',
         takeaway='In a licence-bound economy, political skill was a business skill — and few practised it like Dhirubhai.', accent=AC),
      bg='Pre-1991 India ran a <b>command economy of licences, quotas and tariffs</b> in which government permission gated almost every industrial decision.',
      people='the ministers and bureaucrats of Delhi; Reliance’s liaison network; rival industrialists who resented his access.',
      what='Dhirubhai became <b>renowned for managing the government</b> — obtaining licences, import permissions and favourable duty structures — which admirers call skillful and critics call the fruit of undue political influence.',
      crux='In the License Raj, <b>access and timing could matter as much as capital or technology</b>, and he excelled at both.',
      conseq='His policy influence became a central charge in the press and political wars that erupted in the mid-1980s.',
      matters='His career poses a lasting question about India’s old economy: how far success rested on enterprise, how far on the state.'),
]

# ==================================================================  PHASE 5 — THE WARS
PHASE_WARS = [
    E('bear-cartel', '1982', 'The bear-cartel share battle', ['BATTLE', 'DRAMA', 'TRIUMPH'],
      'In 1982 a cartel of bear operators — reputedly Calcutta brokers — short-sells Reliance shares heavily to drive down the price; Dhirubhai’s allies, the "Friends of Reliance," secretly buy every share offered, trapping the bears, who cannot deliver stock they never had — forcing the Bombay Stock Exchange to shut for days and cementing his legend as a market tactician.',
      svg_row('Trapping the short-sellers', [
          {'n': 1, 'label': 'Bear cartel shorts Reliance', 'sub': 'brokers sell to crash the share price', 'color': '#b91c1c'},
          {'n': 2, 'label': '“Friends of Reliance” buy it all', 'sub': 'allies soak up every offered share', 'color': '#0369a1'},
          {'n': 3, 'label': 'Bears can’t deliver; BSE shuts', 'sub': 'a settlement crisis; the exchange closes', 'color': '#b45309'},
      ], edge_labels=['but', 'so'], takeaway='He turned a bear raid into a rout — beating the market’s insiders at their own game.', accent=AC),
      bg='Reliance’s soaring, retail-heavy stock made it a target for <b>bear operators</b> who bet on a fall by short-selling shares they did not own.',
      people='the anonymous <b>bear cartel</b> (widely said to be Calcutta brokers); the pro-Reliance “<b>Friends of Reliance</b>” buyers; the BSE authorities.',
      what='When the cartel short-sold Reliance to force the price down, <b>pro-Ambani brokers bought up all the shares</b>; at settlement the bears <b>could not deliver</b>, the <b>badla/unbadla</b> financing mechanism seized, and the <b>exchange closed for days</b> before a settlement was forced.',
      crux='He understood <b>market mechanics and settlement rules</b> well enough to turn a bear attack into a trap.',
      conseq='The episode became Indian market folklore, burnishing Dhirubhai’s image as an untouchable operator.',
      matters='It showed a self-made outsider outfighting the old broking establishment — and how tightly Reliance and the market were bound.'),

    E('wadia', '1985–1986', 'The Polyester War with Nusli Wadia', ['BATTLE', 'RIVALRY', 'CONTROVERSY'],
      'Dhirubhai’s PTA route to polyester collides with Nusli Wadia’s Bombay Dyeing, which uses the older DMT process — and when government policy tilts toward PTA, Wadia’s business suffers, igniting one of independent India’s fiercest corporate wars, fought through licences, policy lobbying, the press, and even, in one unproven allegation, a conspiracy charge against a Reliance manager.',
      svg_compare('PTA versus DMT — two paths to polyester', {
          'head': 'Reliance (Dhirubhai)', 'color': '#0369a1',
          'items': ['Backed the modern PTA feedstock', 'Built world-scale, low-cost plants', 'Policy shifts favoured PTA', 'Emerged the industry’s winner'],
      }, {
          'head': 'Bombay Dyeing (Nusli Wadia)', 'color': '#b45309',
          'items': ['Committed to the older DMT route', 'Squeezed as policy turned', 'Became a leading Reliance critic', 'Allied with the hostile press'],
      }, verdict='Reliance’s PTA bet and policy tilt hurt Bombay Dyeing; the rivalry turned personal and bitter.',
         takeaway='A technical choice between chemicals became a war for survival between two of India’s biggest houses.', accent=AC),
      bg='Both houses made polyester, but from <b>different feedstocks</b> — Reliance from <b>PTA</b>, Bombay Dyeing from <b>DMT</b> — so government raw-material policy could make or break each.',
      people='<b>Nusli Wadia</b> of Bombay Dyeing; Dhirubhai and Reliance; finance minister <b>V.P. Singh</b>, whose 1985 moves reshaped PTA imports.',
      what='As policy favoured <b>PTA</b>, Bombay Dyeing’s <b>DMT-based business was squeezed</b>; the rivalry escalated into <b>licence and policy battles, press attacks, and a 1985 Mumbai police charge accusing a Reliance manager of conspiring to murder Wadia — a charge never established in court</b>.',
      crux='The war showed how, under the License Raj, <b>a policy decision on feedstock could decide a corporate contest</b>.',
      conseq='Wadia became a key backer of the Indian Express campaign that would dog Reliance for years.',
      matters='It remains a landmark of Indian business history — rivalry fought not only in markets but in ministries and newspapers.'),

    E('press-war', '1986–1987', 'The Indian Express press war', ['CONTROVERSY', 'POLITICS'],
      'Ramnath Goenka’s Indian Express, with journalists Arun Shourie and S. Gurumurthy, wages a sustained investigative campaign against Reliance — alleging it imported excess plant capacity disguised as spare parts, bought its own shares through offshore shell companies, and won undue favours — while Reliance denies wrongdoing; the government even commissions the Fairfax detectives, and the affair convulses Indian politics.',
      svg_stack('Allegations, denials, and a detective agency', [
          {'n': 1, 'label': 'Indian Express opens fire, 1986–87', 'sub': 'Goenka, Arun Shourie, S. Gurumurthy', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Charges: imports, offshore shares', 'sub': '“spares” capacity; Isle of Man share-buying', 'color': '#b45309'},
          {'n': 3, 'label': 'Reliance denies; Fairfax probes', 'sub': 'a political storm; nothing fully proven in court', 'color': '#0369a1'},
      ], takeaway='Present even-handedly: grave allegations were aired and denied; the affair scarred politics but produced no clear legal verdict against Dhirubhai.', accent=AC),
      bg='After Dhirubhai’s February 1986 stroke, the <b>Indian Express</b> under proprietor <b>Ramnath Goenka</b> ran a lengthy investigative campaign against Reliance.',
      people='<b>Ramnath Goenka</b>, the crusading publisher; journalists <b>Arun Shourie</b> and <b>S. Gurumurthy</b>; the <b>Fairfax</b> investigators; Nusli Wadia, an ally of the critics.',
      what='The Express alleged Reliance had <b>imported extra polyester-plant capacity as “spare parts,”</b> <b>bought its own shares through offshore firms (routed via the Isle of Man)</b>, and enjoyed undue policy favours; <b>Reliance denied the charges</b>, and the disputes drew in Parliament and the Fairfax detective agency without a conclusive court verdict against Dhirubhai.',
      crux='The war pitted <b>a free press and rivals against a business colossus</b> — and left the truth of many claims legally unresolved.',
      conseq='The controversy strained governments and became a defining saga of business-versus-press conflict in India.',
      matters='It is a case study in the tangle of big business, politics and journalism — best read with both the charges and the denials in view.'),
]

# ==================================================================  PHASE 6 — DECLINE, DEATH & LEGACY
PHASE_LEGACY = [
    E('stroke', '1986', 'The first stroke — the sons step up', ['TRAGEDY', 'TURNING POINT'],
      'In February 1986 Dhirubhai suffers a stroke that paralyses his right hand and forces him to step back from daily control — handing operational command to his sons Mukesh and Anil, who begin steering Reliance while their father remains the guiding strategic mind and figurehead of the empire he built.',
      svg_row('A founder steps back', [
          {'n': 1, 'label': 'Stroke in February 1986', 'sub': 'paralyses his right hand', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Sons take daily command', 'sub': 'Mukesh and Anil Ambani step up', 'color': '#0369a1'},
          {'n': 3, 'label': 'Dhirubhai the guiding mind', 'sub': 'strategist and figurehead to the end', 'color': '#166534'},
      ], edge_labels=['so', 'while'], takeaway='Illness forced a succession in fact if not in title — the next generation began running Reliance in 1986.', accent=AC),
      bg='At the height of the corporate and press wars, Dhirubhai’s health failed: a <b>stroke in February 1986</b> left his right side impaired.',
      people='his sons <b>Mukesh</b> and <b>Anil Ambani</b>, now taking charge; his wife Kokilaben; the Reliance management team.',
      what='The <b>1986 stroke</b> forced Dhirubhai to <b>delegate operational control to Mukesh and Anil</b>, who ran day-to-day affairs while he remained the group’s strategic and symbolic head.',
      crux='The crisis <b>accelerated the sons’ rise</b> and began the transition of the empire to the next generation.',
      conseq='Over the next fifteen years the brothers drove huge expansion — even as sibling tension quietly grew.',
      matters='Founders’ health can reshape corporate destiny — 1986 set Reliance’s succession, and its later split, in motion.'),

    E('empire', '1991–2002', 'Refining, Jamnagar and the colossus', ['INDUSTRY', 'TRIUMPH'],
      'As India liberalises after 1991, Reliance completes its climb from cloth to crude — building at Jamnagar in Gujarat what becomes one of the world’s largest oil-refining complexes, executed under Mukesh — so that by Dhirubhai’s final years Reliance stands as India’s largest private-sector enterprise, spanning textiles, petrochemicals and refining.',
      svg_stack('From cloth to crude — the full chain', [
          {'n': 1, 'label': 'Liberalisation opens India, 1991', 'sub': 'the License Raj begins to fall', 'color': '#166534'},
          {'n': 2, 'label': 'Jamnagar refinery rises', 'sub': 'among the world’s largest; built under Mukesh', 'color': '#0369a1'},
          {'n': 3, 'label': 'India’s largest private firm', 'sub': 'textiles to petrochemicals to refining', 'color': '#6d28d9'},
      ], takeaway='The integration dream was realised — Reliance now owned the chain from crude oil all the way to fabric.', accent=AC),
      bg='India’s <b>1991 economic liberalisation</b> dismantled much of the License Raj, opening scope for private giants to expand freely.',
      people='<b>Mukesh Ambani</b>, who drove the Jamnagar project; the global contractors who built it; Reliance’s vast workforce and shareholders.',
      what='Reliance built the <b>Jamnagar refinery complex</b> in Gujarat — one of the world’s largest — completing its integration into <b>oil refining</b> and making Reliance <b>India’s largest private-sector company</b> by Dhirubhai’s last years.',
      crux='The realised vision was <b>full vertical integration</b>, from crude oil to petrochemicals to fibre to fabric, at world scale.',
      conseq='Reliance became a national industrial champion — and the prize over which the brothers would soon divide.',
      matters='He lived to see the trader’s arbitrage of 1958 become one of the world’s great integrated industrial empires.'),

    E('death', '2002', 'Death of the founder', ['DEATH', 'TURNING POINT'],
      'On 6 July 2002 Dhirubhai Ambani dies in Mumbai at the age of 69, after a second major stroke in late June — mourned across India as the self-made visionary who built its largest private enterprise and made shareholders of millions; in 2016 he is posthumously awarded the Padma Vibhushan, India’s second-highest civilian honour.',
      svg_row('The passing of a self-made giant', [
          {'n': 1, 'label': 'Second stroke, late June 2002', 'sub': 'admitted to hospital in Mumbai', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Dies 6 July 2002, aged 69', 'sub': 'mourned across India', 'color': '#0369a1'},
          {'n': 3, 'label': 'Padma Vibhushan, 2016', 'sub': 'India’s second-highest civilian honour', 'color': '#b45309'},
      ], edge_labels=['then', 'later'], takeaway='He died as he had lived — a national figure, the self-made man who reshaped Indian capitalism.', accent=AC),
      bg='After years of frail health following his 1986 stroke, Dhirubhai suffered a <b>second major stroke</b> in June 2002.',
      people='his wife <b>Kokilaben</b>; sons <b>Mukesh</b> and <b>Anil</b>; the millions of shareholders and admirers who mourned him.',
      what='Dhirubhai was admitted to hospital on <b>24 June 2002</b> and <b>died on 6 July 2002 in Mumbai, aged 69</b>; he was later honoured with the <b>Padma Vibhushan (2016)</b>.',
      crux='He died leaving <b>India’s largest private company</b> — and no clear settlement of how his sons would share it.',
      conseq='His death triggered a bitter succession struggle between Mukesh and Anil over control of the group.',
      matters='He is remembered as the archetype of the self-made Indian entrepreneur and the father of India’s equity culture.'),

    E('split', '2002–2006', 'The Mukesh–Anil split and the legacy', ['LEGACY', 'CONTROVERSY'],
      'Dhirubhai left no will, and after his death his sons Mukesh and Anil feud openly over the empire — a rift their mother Kokilaben brokers into a formal division around 2005–06: Mukesh takes oil, refining and petrochemicals; Anil takes telecom, power and financial services — splitting Reliance in two even as their father’s legacy as India’s equity pioneer endures.',
      svg_compare('Dividing an empire between two sons', {
          'head': 'Mukesh Ambani', 'color': '#0369a1',
          'items': ['Oil, gas and refining (Jamnagar)', 'Petrochemicals — the core business', 'Later Jio telecom and retail', 'Reliance Industries Limited'],
      }, {
          'head': 'Anil Ambani', 'color': '#b45309',
          'items': ['Telecom, power and infrastructure', 'Financial services and entertainment', 'The Reliance ADA Group', 'A separate corporate empire'],
      }, verdict='With no will, Kokilaben brokered a 2005–06 split of the group between the feuding brothers.',
         takeaway='The empire Dhirubhai forged as one was divided in two — yet his equity-culture legacy outlasted the split.', accent=AC),
      bg='Dhirubhai <b>died without a will</b>, leaving control of Reliance ambiguous between his two sons.',
      people='<b>Mukesh</b> and <b>Anil Ambani</b>, the feuding brothers; their mother <b>Kokilaben</b>, who brokered peace; the shareholders caught in the uncertainty.',
      what='A bitter, public <b>succession feud</b> erupted; around <b>2005–06</b> Kokilaben mediated a <b>formal demerger</b> — Mukesh keeping <b>oil, refining and petrochemicals</b>, Anil taking <b>telecom, power and financial services</b> — dividing the group in two.',
      crux='The absence of a clear succession plan turned a united empire into <b>two rival houses</b>.',
      conseq='Reliance Industries under Mukesh went on to become one of the world’s most valuable companies; Anil’s group later declined.',
      matters='Even the greatest fortunes can fracture without succession planning — yet Dhirubhai’s deeper legacy, the equity cult, endured.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Dhirubhai Ambani was the schoolteacher’s son who rose from selling snacks in a Gujarat village to building Reliance Industries into India’s largest private enterprise — and, along the way, founded the country’s modern equity culture. He learned trade as a clerk in Aden, returned in 1958 to start a tiny yarn-and-spices firm, and then drove it relentlessly up the value chain: from cloth to the Vimal brand, to polyester fibre, to petrochemicals, to one of the world’s biggest oil refineries. Shut out by the banks, he raised money from millions of small investors and made shareholders of ordinary Indians. He is the ultimate study in <b>ambition, integration, and the power — and controversy — of building at scale.</b></p>
<div class="ov-quote">“Think big, think fast, think ahead. Ideas are no one’s monopoly.”<span>— Dhirubhai Ambani</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born poor in Chorwad and schooled in trade at Aden → returns in 1958 to found Reliance, trading yarn and spices → builds textile mills and the Vimal brand → bypasses the banks with the 1977 IPO and creates an equity cult of millions → integrates backward from cloth to polyester to petrochemicals to refining → fights the bear cartel, the Wadia polyester war and the Indian Express press campaign → and dies in 2002 leaving India’s largest private company, soon split between his sons.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🧵</div><h4>Cloth to crude</h4><p>Integrated backward from fabric to petrochemicals and refining.</p></div>
  <div class="ov-card"><div class="i">📈</div><h4>The equity cult</h4><p>Made shareholders of millions; funded industry from the crowd.</p></div>
  <div class="ov-card"><div class="i">🏭</div><h4>Building at scale</h4><p>Bet on world-scale, latest-technology plants to win on cost.</p></div>
  <div class="ov-card"><div class="i">⚖️</div><h4>Enterprise and controversy</h4><p>A master of the License Raj — celebrated and contested alike.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Origins</b><small> 1932–1958</small><p>A poor Gujarat boyhood and an apprenticeship in Aden.</p></div>
  <div><b>2 · The Trader</b><small> 1958–1966</small><p>Reliance founded; from yarn trading to the first mill.</p></div>
  <div><b>3 · Equity Cult</b><small> 1966–1985</small><p>The Vimal brand, the 1977 IPO, a nation of shareholders.</p></div>
  <div><b>4 · Integration</b><small> 1980–1991</small><p>Backward integration, Patalganga, the License Raj.</p></div>
  <div><b>5 · The Wars</b><small> 1982–1987</small><p>The bear cartel, Nusli Wadia, and the press campaign.</p></div>
  <div><b>6 · Legacy</b><small> 1986–2006</small><p>Strokes, Jamnagar, death, and the sons’ split.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Controversies are presented with <b>both sides</b>. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Kokilaben Ambani', 'role': 'wife & mediator', 'color': '#0369a1',
     'bio': 'Dhirubhai’s wife and the matriarch of the family, who after his death brokered the 2005–06 division of the Reliance empire between their feuding sons.',
     'rel': 'His wife and the peacemaker of the post-death succession.'},
    {'name': 'Mukesh Ambani', 'role': 'elder son', 'color': '#b45309',
     'bio': 'The elder son who drove the giant Jamnagar refinery project and, after the split, took control of Reliance Industries, building it into one of the world’s most valuable companies.',
     'rel': 'His heir in oil, refining and petrochemicals.'},
    {'name': 'Anil Ambani', 'role': 'younger son', 'color': '#166534',
     'bio': 'The younger son who, after the 2005–06 split, took the telecom, power and financial-services businesses as the Reliance ADA Group.',
     'rel': 'His heir in telecom, power and financial services.'},
    {'name': 'Nusli Wadia', 'role': 'chief rival', 'color': '#b91c1c',
     'bio': 'The chairman of Bombay Dyeing, whose DMT-based polyester business clashed with Reliance’s PTA route in one of India’s fiercest corporate wars.',
     'rel': 'His great business rival in the polyester wars.'},
    {'name': 'Ramnath Goenka', 'role': 'press adversary', 'color': '#6d28d9',
     'bio': 'The crusading proprietor of the Indian Express, whose journalists Arun Shourie and S. Gurumurthy led a sustained investigative campaign against Reliance in 1986–87.',
     'rel': 'The publisher who waged the press war against him.'},
]

KEY_EVENTS = [
    ('1932', 'Born in Chorwad', 'A village schoolteacher’s son in Gujarat.'),
    ('1949', 'Works in Aden', 'Clerk for A. Besse & Co, a Shell agent.'),
    ('1958', 'Reliance founded', 'Trading yarn and spices in Bombay.'),
    ('1966', 'Naroda textile mill', 'From trader to manufacturer.'),
    ('1975', 'The Vimal brand', 'Branded retail across India.'),
    ('1977', 'Reliance IPO', 'Bypasses banks; the equity cult begins.'),
    ('1982', 'Bear-cartel battle', 'Short-sellers trapped; BSE shuts.'),
    ('1985', 'Polyester war', 'PTA vs Wadia’s DMT; policy tilts.'),
    ('1986', 'First stroke; press war', 'Sons step up; Indian Express campaign.'),
    ('2002', 'Death', 'Dies aged 69; India’s largest private firm.'),
    ('2006', 'Mukesh–Anil split', 'The empire divided between the sons.'),
]

MASTER = [
    {'year': '1932', 'age': 'born', 'phase': 'Origins', 'title': 'Born in Chorwad', 'desc': 'A schoolteacher’s son.'},
    {'year': '1949', 'age': 'age 16', 'phase': 'Origins', 'title': 'Aden', 'desc': 'Clerk for A. Besse & Co.'},
    {'year': '1958', 'age': 'age 25', 'phase': 'The Trader', 'title': 'Reliance founded', 'desc': 'Yarn and spices.'},
    {'year': '1966', 'age': 'age 33', 'phase': 'The Trader', 'title': 'Naroda mill', 'desc': 'Into textiles.'},
    {'year': '1977', 'age': 'age 44', 'phase': 'Equity Cult', 'title': 'Reliance IPO', 'desc': 'The equity cult begins.'},
    {'year': '1982', 'age': 'age 49', 'phase': 'The Wars', 'title': 'Bear-cartel battle', 'desc': 'Short-sellers trapped.'},
    {'year': '1985', 'age': 'age 52', 'phase': 'The Wars', 'title': 'Polyester war', 'desc': 'PTA vs Wadia’s DMT.'},
    {'year': '1986', 'age': 'age 53', 'phase': 'Legacy', 'title': 'Stroke; press war', 'desc': 'Sons take command.'},
    {'year': '2002', 'age': 'age 69', 'phase': 'Legacy', 'title': 'Death', 'desc': 'India’s largest private firm.'},
    {'year': '2006', 'age': 'posthumous', 'phase': 'Legacy', 'title': 'Mukesh–Anil split', 'desc': 'The empire divided.'},
]

SOURCES = [
    ('Britannica — Dhirubhai Ambani', 'https://www.britannica.com/money/Dhirubhai-Ambani'),
    ('Wikipedia — Dhirubhai Ambani', 'https://en.wikipedia.org/wiki/Dhirubhai_Ambani'),
    ('Britannica — Reliance Industries Limited', 'https://www.britannica.com/topic/Reliance-Industries-Limited'),
    ('Reliance Industries — Our History', 'https://www.ril.com/about/our-history'),
    ('India Seminar — Paranjoy Guha Thakurta, “The two faces of Dhirubhai Ambani”', 'https://www.india-seminar.com/2003/521/521%20paranjoy%20guha%20thakurta.htm'),
    ('Jio Institute Exhibits — Reliance Goes Public in 1977', 'https://exhibits.jioinstitute.edu.in/spotlight/reliance-industries-limited-timeline/feature/reliance-industries-goes-public-in-1977'),
]

def build_meta():
    return {
        'pid': 'gm-dhirubhai.html', 'kind': 'man', 'emoji': '🧵', 'accent': AC,
        'name': 'Dhirubhai Ambani', 'years': '1932–2002', 'group': 'Business & Industry',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Gujarat schoolteacher’s son who built Reliance into India’s largest private enterprise — pioneering backward integration from cloth to crude and founding the country’s mass equity culture.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'origins', 'label': '1 · Origins', 'type': 'timeline',
             'intro': 'Born poor in the Gujarat village of Chorwad, a schoolteacher’s son learns the world of trade, currency and oil as a young clerk in the British port of Aden.', 'events': PHASE_ORIGINS},
            {'id': 'trader', 'label': '2 · The Trader', 'type': 'timeline',
             'intro': 'Returning to India in 1958, he founds Reliance as a tiny yarn-and-spices trader, parts from his cautious partner, and takes the leap from trading into manufacturing.', 'events': PHASE_TRADER},
            {'id': 'equity', 'label': '3 · Equity Cult', 'type': 'timeline',
             'intro': 'He builds the Vimal brand and a retail network, then bypasses the banks with the 1977 IPO — creating the largest shareholder base in India and a mass equity culture.', 'events': PHASE_EQUITY},
            {'id': 'integration', 'label': '4 · Integration', 'type': 'timeline',
             'intro': 'Reliance climbs the value chain from fabric to fibre to petrochemicals, building at world scale — and Dhirubhai masters, to admirers and critics alike, the License Raj.', 'events': PHASE_INTEGRATION},
            {'id': 'wars', 'label': '5 · The Wars', 'type': 'timeline',
             'intro': 'His rise is fought out in the open: a bear-cartel share battle, the polyester war with Nusli Wadia, and the Indian Express campaign of allegations and denials.', 'events': PHASE_WARS},
            {'id': 'legacy', 'label': '6 · Legacy', 'type': 'timeline',
             'intro': 'Struck down by illness, he hands control to his sons, sees Reliance become India’s largest private firm, and dies in 2002 — leaving an empire soon divided between Mukesh and Anil.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Encyclopaedic and company sources for the business record; some controversies (the press war, offshore-share and import allegations) are presented with both the charges and Reliance’s denials, as many were never conclusively resolved in court.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
