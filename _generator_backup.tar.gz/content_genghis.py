# -*- coding: utf-8 -*-
"""Birth-to-death guide content for Genghis Khan."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#0369a1'  # Eternal Blue Sky

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def _twocol(top, left, right):
    """Direct two-column compare body (avoids nesting one svg helper in another)."""
    def col(x, head, c, items):
        h = 40 + len(items)*22 + 10
        s = f'<rect x="{x}" y="{top}" width="300" height="{h}" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        s += f'<rect x="{x}" y="{top}" width="300" height="28" rx="12" fill="{c}"/><rect x="{x}" y="{top+14}" width="300" height="14" fill="{c}"/>'
        s += f'<text x="{x+14}" y="{top+19}" font-size="12" font-weight="800" fill="#fff">{esc(head)}</text>'
        yy = top+46
        for it in items:
            s += f'<circle cx="{x+16}" cy="{yy-4}" r="3" fill="{c}"/>'
            ln, _ = _tspans(x+26, yy, it, 10.4, '#334155', 500, 12, 46); s += ln; yy += 22
        return s
    s = col(40, left[0], left[1], left[2]) + col(380, right[0], right[1], right[2])
    s += f'<text x="360" y="{top+12}" font-size="14" font-weight="800" fill="#94a3b8" text-anchor="middle">vs</text>'
    return s

def svg_meritocracy():
    W, H = 720, 210
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">his real invention: loyalty and skill over blood and tribe</text>'
    b += _twocol(56,
        ('The old steppe way', '#64748b', ['rank by birth and clan', 'loyalty to your tribe', 'plunder kept by chiefs']),
        ('Genghis’ system', '#0369a1', ['promote by merit and loyalty', 'loyalty to the Khan alone', 'plunder shared by law (the Yassa)']))
    return _wrap(W, H, 'Why the tribes followed him', _tk(b, W, H, 'He bound men by merit and fair reward, not birth — turning enemies into one loyal nation.'), '', AC)

def svg_decimal():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">the army as a machine: organised in tens, loyal to the Khan not the clan</text>'
    units = [(40,'#0369a1','Arban','10 men'),(220,'#0e7490','Zuun','100 (10 arban)'),(400,'#155e75','Mingghan','1,000'),(560,'#0c4a6e','Tumen','10,000')]
    for x,c,t,s in units:
        w = 130 if x<560 else 130
        b += f'<rect x="{x}" y="70" width="130" height="56" rx="10" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+65}" y="92" font-size="12" font-weight="800" fill="{c}" text-anchor="middle">{t}</text>'
        b += f'<text x="{x+65}" y="110" font-size="9.5" fill="#5b6472" text-anchor="middle">{s}</text>'
        if x<560:
            b += f'<line x1="{x+130}" y1="98" x2="{x+180}" y2="98" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="160" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Men from different tribes were mixed into each unit — so loyalty flowed to the army, not the clan.</text>'
    b += '<text x="360" y="180" font-size="10" fill="#0369a1" font-weight="700" text-anchor="middle">Fast, disciplined, endlessly divisible — commanded by signal flags and couriers.</text>'
    return _wrap(W, H, 'The decimal army — a nation reorganised for war', _tk(b, W, H, 'Reorganise people by function, not tribe, and you dissolve old loyalties into one command.'), '', AC)

def svg_terror():
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1219–21 · terror used as a deliberate instrument of war</text>'
    boxes=[(40,'#0369a1','Offer: submit and live','cities that open their gates are spared and taxed'),
           (270,'#b45309','Resist → total destruction','a defiant city is massacred as an example'),
           (500,'#dc2626','The news travels ahead','the next city surrenders without a fight')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="80" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="100" x2="268" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="100" x2="498" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Massacre was not mindless rage — it was a calculated policy to make resistance seem suicidal.</text>'
    return _wrap(W, H, 'Terror as strategy — surrender or be erased', _tk(b, W, H, 'Make the price of resistance so total that most enemies choose surrender — cruelty as a shortcut to conquest.'), '', AC)

def svg_legacy():
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">1227+ · what the outcast boy left behind</text>'
    rows = [('#0369a1', 'The largest contiguous empire in history', 'grew after his death from the Pacific to Eastern Europe'),
            ('#0e7490', 'The Pax Mongolica', 'safe Silk Road trade; ideas, goods and plague flow across Eurasia'),
            ('#155e75', 'Meritocracy, tolerance, law, writing', 'religious tolerance, the Yassa, a postal relay, a written script'),
            ('#dc2626', '...built on staggering slaughter', 'millions dead; whole cities and peoples erased')]
    y = 58
    for i, (c, t, s) in enumerate(rows):
        b += f'<rect x="40" y="{y}" width="640" height="34" rx="9" fill="#fff" stroke="{c}" stroke-width="1.7"/>'
        b += f'<circle cx="60" cy="{y+17}" r="9" fill="{c}"/><text x="60" y="{y+21}" font-size="10" font-weight="800" fill="#fff" text-anchor="middle">{i+1}</text>'
        b += f'<text x="80" y="{y+15}" font-size="11" font-weight="800" fill="{c}">{esc(t)}</text>'
        b += f'<text x="80" y="{y+29}" font-size="9.5" fill="#5b6472">{esc(s)}</text>'
        y += 42
    return _wrap(W, H, 'The paradox of the legacy', _tk(b, W, H, 'One of history’s great builders AND destroyers — connector of a continent, and its bloodiest conqueror.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE OUTCAST
PHASE_OUTCAST = [
    E('birth', 'c. 1162', 'Born Temüjin — a chief’s son on the steppe', ['RISE'],
      'Born to a minor clan chief and named after a captured enemy, the boy Temüjin enters a violent world of feuding nomad tribes where survival depends on alliances, revenge, and raw endurance.',
      svg_stack('The harsh world that made him', [
          {'n': 1, 'label': 'Born to a minor Mongol chief', 'sub': 'father Yesügei; named for a captured Tatar', 'color': '#0369a1'},
          {'n': 2, 'label': 'A world of feuding tribes', 'sub': 'Mongols, Tatars, Keraites, Naimans, Merkits — endless raids', 'color': '#64748b'},
          {'n': 3, 'label': 'Survival = alliance + revenge', 'sub': 'kinship, blood-feud and betrayal rule the steppe', 'color': '#b45309'},
      ], takeaway='He was forged in a merciless world where trust was scarce and betrayal normal — lessons he never forgot.', accent=AC),
      bg='The 12th-century Mongolian steppe was a patchwork of rival nomadic confederations locked in constant raiding, blood-feud and shifting alliance — no unity, no state.',
      people='<b>Yesügei</b>, his father, a chief of a minor Mongol clan; <b>Hoelun</b>, his strong-willed mother; the surrounding tribes who would be enemies and, later, subjects.',
      what='Born around 1162 (traditionally), the boy <b>Temüjin</b> was reportedly named after a Tatar chief his father had captured — a birth marked by the steppe’s cycle of raid and revenge.',
      crux='He was shaped by a world where <b>power came only from loyalty you could enforce and enemies you could out-survive</b>. Nothing was inherited safely.',
      conseq='This brutal environment taught him the value of loyalty, the danger of betrayal, and the need to remake the rules — lessons that would drive his entire life.',
      matters='Environments forge people. The ruthlessness and obsession with loyalty that defined Genghis were born from a childhood where neither could be taken for granted.'),

    E('abandoned', 'c. 1171', 'Poisoned father, abandoned family', ['TRAGEDY', 'RISE'],
      'When Tatars poison his father, his clan abandons the widow and her children to die on the steppe. The family survives on roots and fish — and the boy learns that status means nothing without power.',
      svg_row('From chief’s son to nothing', [
          {'n': 1, 'label': 'Yesügei poisoned', 'sub': 'Tatars kill his father', 'color': '#dc2626'},
          {'n': 2, 'label': 'The clan abandons them', 'sub': 'the widow Hoelun and children left to starve', 'color': '#64748b'},
          {'n': 3, 'label': 'Survive on nothing', 'sub': 'roots, fish, rodents — utter poverty', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='He fell from privilege to destitution — and learned that rank without power is worthless.', accent=AC),
      bg='Steppe alliances were personal; when a chief died, his followers often deserted his family rather than support a widow and young sons.',
      people='<b>Hoelun</b>, his mother, who kept the children alive through sheer will; his siblings and half-siblings; the clan that deserted them.',
      what='Tatars <b>poisoned Yesügei</b>; his followers abandoned the family. Hoelun raised her children in <b>desperate poverty</b>, foraging to survive on the open steppe.',
      crux='The abandonment burned in a lifelong lesson: <b>inherited status is nothing; only loyalty you command and power you hold are real</b>.',
      conseq='Temüjin grew up hardened, resourceful and fiercely protective of his family — and determined never to be powerless again.',
      matters='Adversity early can either break a person or forge them. It forged in Genghis an absolute focus on building loyalty he could actually rely on.'),

    E('begter', 'c. 1170s', 'Killing Begter — dominance in a starving family', ['TRAGEDY', 'RISE', 'TURNING POINT'],
      'In the desperate poverty of exile, the boy Temüjin kills his own older half-brother Begter in a quarrel over food and rank — a shocking, formative act that establishes him, brutally young, as the undisputed head of his family.',
      svg_row('A ruthless assertion of primacy', [
          {'n': 1, 'label': 'A family on the edge', 'sub': 'exiled, starving; half-brothers vie for control', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Conflict with Begter', 'sub': 'the older half-brother asserts dominance over food', 'color': '#b45309'},
          {'n': 3, 'label': 'Temüjin kills him', 'sub': 'with his brother Khasar — becomes family head', 'color': '#0369a1'},
      ], edge_labels=['then', 'then'], takeaway='Even as a boy he answered a challenge to his primacy with lethal decisiveness — a chilling early sign of the ruler to come.', accent=AC),
      bg='After the family’s abandonment, the children survived in bitter poverty, where rank and food were matters of life and death.',
      people='His older half-brother <b>Begter</b>; his full brother <b>Khasar</b>, who helped him; his mother <b>Hö’elün</b>, who was appalled.',
      what='In a dispute over food and hierarchy, the young <b>Temüjin, with his brother Khasar, killed his half-brother Begter</b> — a killing recorded in the Mongols’ own <i>Secret History</i>, establishing Temüjin as head of the family despite his mother’s fury.',
      crux='It revealed, terribly early, his <b>willingness to act with lethal decisiveness to secure primacy</b> — and to override even family and sentiment when power was at stake.',
      conseq='He became the unquestioned leader of his siblings, a role he would expand, step by step, to the leadership of all the steppe.',
      matters='The traits that build empires can be chilling in a child. Temüjin’s earliest act of “leadership” was the ruthless elimination of a rival.'),

    E('enslaved', 'c. 1170s', 'Captured and enslaved — the escape that forged him', ['TRAGEDY', 'RISE', 'TURNING POINT'],
      'Hunted by a rival clan, the young Temüjin is captured, clamped in a wooden collar and enslaved — until a sympathetic family hides him in a cart of wool and lets him flee, a brush with a slave’s death that hardened his will and taught him who could be trusted.',
      svg_stack('From captive to fugitive', [
          {'n': 1, 'label': 'Seized by the Tayichiud', 'sub': 'a rival clan captures him, locks him in a wooden cangue', 'color': '#b91c1c'},
          {'n': 2, 'label': 'A night-time escape', 'sub': 'he slips his guards and hides in the Onon river', 'color': '#0369a1'},
          {'n': 3, 'label': 'Sheltered by Sorkan-Shira', 'sub': 'a low-ranking family hides him in wool and sets him free', 'color': '#16a34a'},
      ], takeaway='He survived slavery by nerve and the kindness of humble people — and never forgot either lesson.', accent=AC),
      bg='After his father’s murder, the outcast boy was a target. The <b>Tayichiud</b> clan captured him to remove a potential future rival.',
      people='the <b>Tayichiud</b> captors; <b>Sorkan-Shira</b> and his sons <b>Chila’un</b> and <b>Chimbai</b>, who risked their lives to hide him; the guard he overpowered.',
      what='Temüjin was <b>enslaved and collared</b> in a wooden cangue, then escaped during a feast, hid submerged in a river, and was concealed and freed by the family of <b>Sorkan-Shira</b> — whom he later raised to high honour.',
      crux='He learned that <b>survival depended on loyalty freely given</b> by ordinary people — and that he could inspire it even as a captive.',
      conseq='Those who helped him were rewarded for life; the episode deepened his conviction that merit and loyalty, not birth, should be rewarded.',
      matters='The lowest moments reveal who your true allies are — and the gratitude they earn can become the core of future power.'),

    E('borte', 'c. 1180s', 'Börte kidnapped — the first war of his own', ['RISE', 'BATTLE', 'LOVE'],
      'His wife Börte is kidnapped by a rival tribe; to get her back, the young Temüjin calls in every alliance he has and wins his first campaign — his first taste of leading men to victory.',
      svg_row('Turning a personal wrong into a coalition', [
          {'n': 1, 'label': 'Merkits kidnap Börte', 'sub': 'his wife seized in revenge for an old wrong', 'color': '#dc2626'},
          {'n': 2, 'label': 'Call in allies', 'sub': 'Toghrul (his father’s ally) & Jamukha (blood-brother)', 'color': '#0369a1'},
          {'n': 3, 'label': 'Rescue & first victory', 'sub': 'crushes the Merkits; recovers Börte', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He learned to convert a personal cause into a coalition — and discovered his gift for leading men.', accent=AC),
      bg='As a young man, Temüjin married <b>Börte</b>. In the feud-driven steppe, the Merkits kidnapped her to avenge an old abduction (Yesügei had once stolen Hoelun from them).',
      people='<b>Börte</b>, his wife and lifelong partner; <b>Toghrul (Ong Khan)</b> of the Keraites, his father’s old ally; <b>Jamukha</b>, his charismatic blood-brother (anda).',
      what='To recover Börte, Temüjin appealed to <b>Toghrul</b> and <b>Jamukha</b>, who lent their forces. Together they <b>crushed the Merkits</b> and rescued her — Temüjin’s first real military success.',
      crux='He showed an early genius for <b>alliance-building</b> and for inspiring loyalty — turning a private grievance into a coalition that won.',
      conseq='His reputation grew; followers began to gather around him. But his friendship with Jamukha would curdle into deadly rivalry for mastery of the Mongols.',
      matters='Great leaders turn personal causes into shared ones. Temüjin’s power began with his ability to make other men fight for his cause as if it were their own.'),
]

# ==================================================================  PHASE 2 — UNITER OF THE STEPPE
PHASE_UNITE = [
    E('meritocracy', '1180s–1200s', 'A new deal — merit, loyalty, and shared spoils', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'He breaks every steppe rule: promoting talented commoners over princes, punishing betrayal of any lord, and sharing plunder by fixed law — so followers flock to him from every tribe.',
      svg_meritocracy(),
      bg='Steppe society ran on birth and clan. Chiefs rewarded aristocratic kin and kept plunder for themselves — so loyalty was narrow and fickle.',
      people='The lowborn but talented men Temüjin raised to command; the aristocrats he sidelined; defeated enemies he pardoned and promoted for their courage.',
      what='Temüjin <b>promoted by merit and loyalty</b>, not birth; he <b>rewarded loyalty even to defeated enemies</b> and punished treachery to any lord; and he <b>shared plunder by rule</b> rather than letting chiefs hoard it.',
      crux='He redesigned the <b>incentives</b> of steppe politics: talent was rewarded, loyalty was protected, and spoils were fair — so it paid to join and stay with him rather than any old clan.',
      conseq='Followers deserted rival chiefs to join him; his movement grew from a band into a nation-in-arms drawn from many tribes.',
      matters='Change the incentives and you change who follows you. Genghis out-competed rivals less by battle than by offering a fairer, more meritocratic deal.'),

    E('thirteenhordes', 'c. 1187', 'Dalan Balzhut — losing a battle, winning the men', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'In an early clash his former blood-brother Jamukha defeats him — but then boils captured enemies alive in cauldrons, and the horror of it drives Jamukha’s own disgusted followers to defect to Temüjin, so that the loser of the battle wins the war for hearts.',
      svg_row('The defeat that recruited an army', [
          {'n': 1, 'label': 'Temüjin loses at Dalan Balzhut', 'sub': 'Jamukha’s coalition beats him in the field', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Jamukha boils his captives', 'sub': 'a cruelty that appals even his own men', 'color': '#78350f'},
          {'n': 3, 'label': 'His followers defect to Temüjin', 'sub': 'they choose the leader who treats men better', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He turned a battlefield defeat into a moral victory — men followed the leader who valued them.', accent=AC),
      bg='As Temüjin and his boyhood <b>anda</b> (blood-brother) <b>Jamukha</b> became rivals for leadership of the Mongols, they came to blows at <b>Dalan Balzhut</b>.',
      people='<b>Jamukha</b>, the charismatic but cruel rival; the captured warriors he executed; the disillusioned nobles who came over to Temüjin.',
      what='Temüjin was <b>defeated</b> in the battle, but Jamukha’s reported <b>boiling of captives alive</b> so revolted his allies that many <b>defected to Temüjin</b> — who gained more from losing than winning.',
      crux='He grasped that <b>how you treat people</b> — allies and captives — is itself a weapon that outlasts any single battle.',
      conseq='His growing reputation for generosity and fair reward steadily drew the steppe’s warriors to his banner over the harsher Jamukha.',
      matters='You can lose the fight and still win the following — reputation for how you treat people compounds over time.'),

    E('jamukha', '1180s–1205', 'The break with Jamukha — friend into rival', ['BATTLE', 'POLITICS', 'TRAGEDY'],
      'His blood-brother Jamukha represents the old aristocratic order; the two friends become rivals for mastery of the Mongols. Temüjin’s meritocratic model wins, and Jamukha is finally executed.',
      svg_row('Two visions of the steppe collide', [
          {'n': 1, 'label': 'Blood-brothers (anda)', 'sub': 'close friends and allies in youth', 'color': '#0369a1'},
          {'n': 2, 'label': 'Rival models', 'sub': 'Jamukha = aristocracy; Temüjin = merit', 'color': '#b45309'},
          {'n': 3, 'label': 'Temüjin prevails', 'sub': 'Jamukha’s own men defect; he is captured & executed', 'color': '#dc2626'},
      ], edge_labels=['then', 'so'], takeaway='His system beat his friend’s: men chose the leader who rewarded them fairly over the one who ruled by rank.', accent=AC),
      bg='<b>Jamukha</b>, Temüjin’s charismatic blood-brother, championed the traditional aristocratic order. As both men rose, they became competitors to unite the Mongols.',
      people='<b>Jamukha</b>, the rival anda; the followers who repeatedly <b>abandoned Jamukha for Temüjin</b>, drawn by the fairer deal; <b>Toghrul</b>, once an ally, later an enemy too.',
      what='After years of shifting alliance and war, Temüjin defeated Jamukha — whose own followers deserted him. Captured, <b>Jamukha was executed</b> (reportedly an honourable, bloodless death at Temüjin’s order).',
      crux='It was a contest of <b>systems</b>: Jamukha rewarded aristocrats; Temüjin rewarded merit and loyalty. Ordinary warriors kept choosing the meritocrat.',
      conseq='With Jamukha gone and the Keraites and Naimans beaten, Temüjin stood as master of the Mongol tribes.',
      matters='When two leaders compete, the one whose system treats followers better usually wins the long game — people vote with their feet.'),

    E('tatars', '1202', 'Avenging his father — the destruction of the Tatars', ['BATTLE', 'TRAGEDY'],
      'He settles the oldest score of his life against the Tatars who poisoned his father — and does it with chilling method: after crushing them he orders every male taller than a cart axle killed, so that no adult Tatar warrior survives to seek revenge, absorbing the rest into his own people.',
      svg_row('A methodical, total revenge', [
          {'n': 1, 'label': 'Defeats the Tatars', 'sub': 'the tribe that poisoned his father', 'color': '#0369a1'},
          {'n': 2, 'label': 'The cart-axle massacre', 'sub': 'all men taller than a wheel-axle killed', 'color': '#7f1d1d'},
          {'n': 3, 'label': 'The rest absorbed', 'sub': 'women and children taken into his people', 'color': '#b45309'},
      ], edge_labels=['then', 'then'], takeaway='He answered an old blood-debt with total, calculated annihilation — then folded the survivors into his nation.', accent=AC),
      bg='The <b>Tatars</b> had poisoned Temüjin’s father Yesügei, and were among the strongest tribes contesting the eastern steppe.',
      people='The Tatar tribe; the children (like the future general spared as boys) absorbed into Temüjin’s following.',
      what='In <b>1202</b> Temüjin defeated the <b>Tatars</b> and, to end the cycle of blood-feud, reportedly ordered all Tatar males <b>taller than a cart axle killed</b>, while absorbing the women and children — eliminating the tribe as a rival for good.',
      crux='He combined <b>personal vengeance with cold strategic logic</b>: annihilating a rival’s fighting men while absorbing the rest prevented future revenge and grew his own numbers.',
      conseq='The Tatar threat was ended permanently; ironically, the name “Tatar” later stuck to the Mongols in Western usage.',
      matters='Genghis’s rise was built on calculated, total solutions to old threats — a chilling pattern of eliminating any tribe that could one day strike back.'),

    E('kereit', '1203', 'Breaking with Toghrul — the Kereit war', ['BATTLE', 'POLITICS', 'TURNING POINT'],
      'His most important patron, the powerful Ong Khan of the Kereit, turns against him at Jamukha’s urging and nearly destroys him in a surprise attack — but Temüjin regroups from the brink, defeats the Kereit in a night assault, and removes the last great rival between him and mastery of the steppe.',
      svg_row('From near-ruin to breaking his patron', [
          {'n': 1, 'label': 'Ong Khan turns on him', 'sub': 'his patron, swayed by Jamukha, attacks by surprise', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Temüjin nearly destroyed', 'sub': 'reduced to a tiny band at Baljuna', 'color': '#b45309'},
          {'n': 3, 'label': 'Crushes the Kereit', 'sub': 'a surprise night attack shatters them', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='Betrayed and nearly finished by his own patron, he clawed back and destroyed the most powerful tribe on the steppe.', accent=AC),
      bg='<b>Toghrul (Ong Khan)</b>, ruler of the powerful <b>Kereit</b>, had been Temüjin’s protector and ally — until jealousy and Jamukha’s intrigues turned him into an enemy.',
      people='<b>Toghrul/Ong Khan</b>, the patron turned foe; the small band of followers who swore loyalty to Temüjin at the <b>Baljuna</b> covenant.',
      what='In <b>1203</b> Ong Khan launched a surprise attack that nearly destroyed Temüjin, reducing him to a tiny, loyal remnant. Temüjin regrouped, then <b>defeated the Kereit in a surprise assault</b>, ending their power and Toghrul’s life.',
      crux='He showed his signature <b>resilience and capacity to recover from disaster</b>, and his willingness to destroy even a former patron who became a threat.',
      conseq='With the Kereit broken, only the Naimans stood between Temüjin and mastery of all the tribes.',
      matters='The steppe rewarded resilience above all. Temüjin’s recovery from the brink against Ong Khan is one of the great comebacks of his rise.'),

    E('naiman', '1204', 'The Naimans and a written language', ['BATTLE', 'REFORM', 'TRIUMPH'],
      'He defeats the last great rival confederation, the Naimans — and in the spoils gains something more lasting than territory: a captured scribe and the Uyghur script, which he adopts to give the Mongol language writing for the first time, the seed of an administered empire.',
      svg_row('The last rival — and the gift of writing', [
          {'n': 1, 'label': 'Defeats the Naimans', 'sub': 'the last great tribal confederation falls, 1204', 'color': '#0369a1'},
          {'n': 2, 'label': 'Captures a scribe', 'sub': 'the Uyghur official Tatatonga is taken', 'color': '#b45309'},
          {'n': 3, 'label': 'Adopts the Uyghur script', 'sub': 'the Mongol language is given writing', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='His last tribal war handed him not just victory but literacy — the tool to administer an empire.', accent=AC),
      bg='The <b>Naimans</b>, a powerful western confederation, were the last major tribe resisting Temüjin’s unification of the steppe.',
      people='The Naiman leadership; the captured Uyghur scribe <b>Tatatonga</b>, who introduced writing and seals to the Mongols.',
      what='In <b>1204</b> Temüjin <b>defeated the Naimans</b>, completing the conquest of the steppe tribes. Among the captives was the Uyghur official <b>Tatatonga</b>, whose <b>Uyghur script</b> Temüjin adopted to give the previously oral <b>Mongol language a written form</b> and administrative seals.',
      crux='He grasped the value of <b>literacy and administration</b>: writing let him record laws, keep accounts and issue orders — turning a tribal following into a governable state.',
      conseq='With the Naimans beaten and writing adopted, the way was clear for the 1206 kurultai that would proclaim him Genghis Khan.',
      matters='Empires need records, not just armies. Genghis’s adoption of writing after beating the Naimans was a quiet turning point toward a true state.'),

    E('kurultai', '1206', 'Proclaimed Genghis Khan — a nation is born', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'At a great assembly in 1206 the united tribes proclaim him Genghis Khan — "universal ruler." He fuses the warring clans into a single Mongol nation with a new army, a written law, and a script.',
      svg_decimal(),
      bg='By 1206 Temüjin had defeated or absorbed every major steppe confederation. A grand <b>kurultai</b> (assembly) gathered to recognise his supremacy.',
      people='The assembled Mongol and allied chiefs; the scribes who adopted the <b>Uyghur script</b> to write the Mongol language and law.',
      what='Proclaimed <b>Genghis Khan</b> (“universal ruler”) in 1206, he reorganised the tribes into a <b>decimal army</b> (units of 10/100/1,000/10,000) that mixed clansmen together, issued the <b>Yassa</b> law code, created a <b>postal relay (yam)</b>, and adopted a <b>written script</b>.',
      crux='He turned a fractious collection of tribes into a <b>single disciplined nation-state on horseback</b>, with loyalty to the Khan and the army rather than the clan — the institutional basis of everything that followed.',
      conseq='For the first time the steppe was united under one ruler and one system — a war machine now poised to turn outward against the great settled empires.',
      matters='Institutions turn a leader’s charisma into a lasting state. Genghis’s army structure, law and communications outlived him and powered a world empire.'),
]
# ==================================================================  PHASE 3 — CHINA
PHASE_CHINA = [
    E('yasa', '1206', 'The Great Yasa — a nation under one law', ['REFORM', 'POLITICS', 'TURNING POINT'],
      'To bind quarrelsome tribes into a single people, Genghis promulgates a body of law — the Great Yasa — that overrides clan custom, punishes theft and betrayal with death, protects the weak and the postal riders, and makes his word the supreme rule of the steppe.',
      svg_stack('Law as the glue of a new nation', [
          {'n': 1, 'label': 'Above tribe and custom', 'sub': 'one code binding all Mongols, superseding clan feuds', 'color': '#0369a1'},
          {'n': 2, 'label': 'Harsh, clear rules', 'sub': 'death for theft, betrayal, adultery; loyalty enforced', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Order and protection', 'sub': 'safe roads, protected envoys, disciplined army', 'color': '#16a34a'},
      ], takeaway='He replaced a chaos of blood-feuds with a single enforced law — turning tribes into a state.', accent=AC),
      bg='The steppe had been a churn of clan vendettas. To make a durable nation, Genghis needed a common law that stood above every tribe’s custom.',
      people='his adopted brother and judge <b>Shigi Qutuqu</b>, who recorded judgements; the Mongol nobles bound by the code; later Khans who invoked the Yasa.',
      what='Genghis issued the <b>Great Yasa</b> — a code (largely unwritten to outsiders but authoritative) prescribing severe punishments, protecting envoys and the postal system, enforcing military discipline and religious tolerance, and elevating loyalty above all.',
      crux='He understood that a nation needs <b>shared, enforced rules</b>, not just a strong leader — law converted a coalition into a lasting order.',
      conseq='The Yasa underpinned Mongol governance across the empire and long outlived him as a source of legitimacy.',
      matters='Uniting people requires more than charisma — it takes a common law that binds even the powerful.'),

    E('tebtengri', '1206–1207', 'Killing the kingmaker shaman', ['POLITICS', 'TRAGEDY', 'TURNING POINT'],
      'When the powerful shaman Teb Tengri, who had helped proclaim him Khan, grows too influential and sows discord among Genghis’s own brothers, Genghis has him quietly killed — a chilling signal that no religious authority, however sacred, may rival the throne.',
      svg_row('No rival authority, not even a holy one', [
          {'n': 1, 'label': 'Teb Tengri, the kingmaker', 'sub': 'the shaman who blessed Genghis’s rise gains huge sway', 'color': '#7c3aed'},
          {'n': 2, 'label': 'He sows discord', 'sub': 'humiliates and turns on Genghis’s own brothers', 'color': '#b91c1c'},
          {'n': 3, 'label': 'His back is broken', 'sub': 'killed discreetly — sacred status is no shield', 'color': '#0369a1'},
      ], edge_labels=['then', 'so'], takeaway='He tolerated all religions but let none become a power that could challenge his own.', accent=AC),
      bg='<b>Teb Tengri</b> (Kököchü) was the most influential shaman among the Mongols and had publicly endorsed Genghis’s title. His spiritual prestige began to rival the Khan’s.',
      people='<b>Teb Tengri</b>, the overreaching shaman; Genghis’s brother <b>Temüge</b>, whom the shaman humiliated; the wrestlers who carried out the killing.',
      what='After Teb Tengri set the Khan’s brothers against one another, Genghis had him <b>killed — his back broken</b> without spilling blood, as befitted his rank — removing a spiritual rival while keeping the appearance of respect.',
      crux='He drew a hard line: <b>religious tolerance, yes; a religious power centre, never</b>. Ultimate authority stayed with him alone.',
      conseq='It secured the unity of his family and the supremacy of the Khan over shamanic and, later, all clerical influence.',
      matters='Rulers who tolerate all faiths still cannot allow any of them to become a rival throne.'),

    E('xixia', '1209–1210', 'Western Xia — the first foreign conquest', ['BATTLE', 'TRIUMPH'],
      'His first great war beyond the steppe is against the Tangut kingdom of Western Xia — a rich, walled, settled state that teaches him hard lessons about attacking cities, and whose forced submission gives the young Mongol nation its first taste of imperial conquest and plunder.',
      svg_row('The steppe empire’s first foreign target', [
          {'n': 1, 'label': 'Invades Western Xia', 'sub': 'the Tangut kingdom on China’s northwest edge', 'color': '#0369a1'},
          {'n': 2, 'label': 'Struggles with walls', 'sub': 'even tries (and botches) flooding a city', 'color': '#b45309'},
          {'n': 3, 'label': 'Forces submission', 'sub': 'Western Xia becomes a tributary vassal', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='His first conquest was also his first schooling in the siege warfare his nomads would soon master.', accent=AC),
      bg='Before striking the great <b>Jin</b> empire, Genghis tested his new nation against the smaller but wealthy <b>Western Xia (Tangut)</b> kingdom.',
      people='The <b>Tangut</b> rulers of Western Xia; the Chinese-style walled cities the Mongols could not yet easily take.',
      what='In <b>1209–10</b> Genghis invaded <b>Western Xia</b>, struggling against its fortified cities (a botched attempt to flood the capital nearly backfired) but ultimately <b>forcing the Tanguts into vassalage</b> and tribute.',
      crux='It was his <b>first encounter with the settled world’s walls and wealth</b> — exposing the Mongols’ key weakness (siegecraft) and their appetite for conquest.',
      conseq='Emboldened and enriched, and now aware he must master siege warfare, Genghis turned to the far greater prize: Jin China.',
      matters='First conquests teach as much as they win. Western Xia showed Genghis both what he lacked and what awaited him in the settled world.'),

    E('yam', '1200s–1227', 'The Yam — an empire wired together by horses', ['REFORM', 'POLITICS', 'TRIUMPH'],
      'Genghis builds a relay network of post-stations across the steppe — the Yam — where riders can gallop between fresh horses to carry messages hundreds of miles a day, giving his scattered empire a nervous system no enemy could match.',
      svg_stack('The information network of a world empire', [
          {'n': 1, 'label': 'Relay stations a day apart', 'sub': 'each stocked with fresh horses, food and shelter', 'color': '#0369a1'},
          {'n': 2, 'label': 'Riders and the paiza pass', 'sub': 'couriers bearing a tablet of authority speed through', 'color': '#155e75'},
          {'n': 3, 'label': 'News moves at a gallop', 'sub': 'messages cross vast distances in days, not weeks', 'color': '#16a34a'},
      ], takeaway='He solved the tyranny of distance — command and intelligence flowed faster than any rival’s.', accent=AC),
      bg='An empire spanning thousands of miles could not be ruled if orders took months to arrive. Genghis needed speed of communication above all.',
      people='the <b>couriers</b> who rode the relays; the station-keepers who maintained horses and supplies; the officials who carried the <b>paiza</b> passports of authority.',
      what='He established the <b>Yam</b>, a system of relay stations roughly a day’s ride apart. Couriers with a <b>paiza</b> tablet could change to fresh mounts and cover extraordinary distances, binding the empire in a web of fast communication.',
      crux='He recognised that <b>speed of information is a form of power</b> — faster command meant faster reaction than any opponent.',
      conseq='The Yam let the Mongols coordinate armies across continents and later awed travellers like Marco Polo; it was a model of imperial logistics.',
      matters='Great powers rest on their networks — whoever moves information fastest can out-think and out-manoeuvre the rest.'),

    E('china', '1211–1215', 'Turning on China — and learning to take cities', ['BATTLE', 'TRIUMPH', 'REFORM'],
      'A nomad army that cannot storm walls turns south against the rich Chinese states — and Genghis, unable to take fortified cities at first, absorbs Chinese and Muslim engineers until his Mongols master siege warfare.',
      svg_row('Nomads learn the one thing they lacked', [
          {'n': 1, 'label': 'Invade Xi Xia & Jin China', 'sub': 'the rich, walled settled world', 'color': '#0369a1'},
          {'n': 2, 'label': 'Walls stop the horsemen', 'sub': 'cavalry can’t storm fortifications', 'color': '#b45309'},
          {'n': 3, 'label': 'Absorb engineers', 'sub': 'Chinese & Muslim siege experts join → catapults, sappers', 'color': '#16a34a'},
      ], edge_labels=['but', 'so'], takeaway='He turned a fatal weakness (no siegecraft) into a strength by recruiting the enemy’s specialists.', accent=AC),
      bg='Having united the steppe, Genghis turned on the wealthy settled states to the south — the <b>Western Xia (Tangut)</b> and the vast <b>Jin dynasty</b> of northern China.',
      people='Captured and defecting <b>Chinese and Muslim engineers</b>, who gave the Mongols catapults, siege towers and gunpowder weapons; the Jin emperor’s vast but brittle empire.',
      what='At first the horse-armies <b>could not take walled cities</b>. Genghis systematically <b>recruited enemy engineers and specialists</b>, learning siege warfare; by <b>1215 the Jin capital Zhongdu (Beijing) fell</b>.',
      crux='He treated his army’s <b>weakness as a problem to be solved by absorbing talent</b>. The Mongols became not just horsemen but masters of siegecraft, logistics and captured technology.',
      conseq='Northern China’s wealth, craftsmen and technology flowed into the Mongol war machine — making it capable of conquering settled empires anywhere.',
      matters='The best conquerors are relentless learners. Genghis co-opted the very skills his enemies used against him, converting weakness into a decisive edge.'),
]

# ==================================================================  PHASE 4 — THE KHWAREZM CATACLYSM
PHASE_KHWAREZM = [
    E('siegetech', '1211–1220', 'Borrowing the enemy’s engines — mastering the siege', ['REFORM', 'BATTLE', 'TRIUMPH'],
      'Steppe horsemen could not storm walls — so Genghis absorbed the skill from those he conquered, recruiting Chinese and Muslim engineers with their catapults, siege towers and gunpowder, and turning a cavalry army into one that could crack any fortress on earth.',
      svg_row('Turning a weakness into a strength', [
          {'n': 1, 'label': 'Nomads can’t take walls', 'sub': 'the early Mongols had no way to reduce fortified cities', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Recruit enemy engineers', 'sub': 'Chinese and Persian siege experts enter his service', 'color': '#0369a1'},
          {'n': 3, 'label': 'Catapults, towers, gunpowder', 'sub': 'a mobile siege train travels with the army', 'color': '#16a34a'},
      ], edge_labels=['so', 'gains'], takeaway='He conquered his own greatest limitation by absorbing the talents of the people he beat.', accent=AC),
      bg='Fortified cities were the Achilles heel of nomadic armies. In the China campaigns Genghis confronted walls his horsemen could not breach.',
      people='the captured <b>Chinese and Muslim engineers</b> who joined him; the artisans spared from massacre for their skills; the commanders who deployed the new machines.',
      what='Genghis systematically <b>recruited siege engineers</b> and their technology — trebuchets, siege towers, incendiaries and early gunpowder — building a mobile siege capability that let the Mongols take even the greatest walled cities.',
      crux='He treated conquered skill as <b>plunder to be used</b>, not despised — sparing and employing the talent of the vanquished.',
      conseq='With siege power added to their mobility, the Mongols became able to destroy the mightiest cities of China and the Islamic world.',
      matters='The fastest way to overcome a weakness is to absorb the strength of those who have it — even your enemies.'),

    E('spies', '1215–1219', 'Merchants and spies — knowing the enemy first', ['POLITICS', 'REFORM'],
      'Before he strikes, Genghis learns: he cultivates merchants as sources, maps roads, rulers and rivalries, and gathers intelligence so thorough that his armies often understand an enemy’s country better than its own defenders do.',
      svg_stack('Winning with knowledge before force', [
          {'n': 1, 'label': 'Merchants as informants', 'sub': 'traders bring news of routes, cities and rulers', 'color': '#0369a1'},
          {'n': 2, 'label': 'Systematic reconnaissance', 'sub': 'scouts map terrain, water, rivalries and weaknesses', 'color': '#155e75'},
          {'n': 3, 'label': 'Strike where it is weakest', 'sub': 'campaigns planned on superior information', 'color': '#16a34a'},
      ], takeaway='He fought informed while enemies fought blind — intelligence multiplied every other advantage.', accent=AC),
      bg='Genghis valued trade and travellers not only for wealth but for knowledge. He built an appetite for detailed information about lands he might fight.',
      people='the <b>Muslim and Uighur merchants</b> he protected and questioned; his scouts and envoys; the defectors who supplied local intelligence.',
      what='He <b>cultivated merchants and spies</b>, debriefing them on roads, fortifications, politics and feuds, so that Mongol commanders entered enemy lands with remarkable knowledge of the terrain and the divisions to exploit.',
      crux='He made <b>intelligence a precondition of war</b> — force was applied only after understanding where and how to apply it.',
      conseq='This is partly why the caravan sent to Khwarezm mattered so much: trade and intelligence were intertwined, and its massacre at Otrar meant war.',
      matters='Superior information is a force multiplier — those who understand the enemy’s world before fighting hold a decisive edge.'),

    E('otrar', '1218–1219', 'The insult that doomed an empire', ['POLITICS', 'TURNING POINT', 'TRAGEDY'],
      'Genghis wants trade, not war, with the great Khwarezmian Empire — until its governor massacres a Mongol caravan and the Shah executes his envoys. The response will erase one of the richest civilisations on earth.',
      svg_row('How a trade dispute became annihilation', [
          {'n': 1, 'label': 'Genghis offers trade', 'sub': 'sends a huge merchant caravan & envoys', 'color': '#0369a1'},
          {'n': 2, 'label': 'Otrar massacre', 'sub': 'a governor kills the merchants as “spies”', 'color': '#b45309'},
          {'n': 3, 'label': 'Envoys executed', 'sub': 'the Shah kills/shames Genghis’ ambassadors', 'color': '#dc2626'},
      ], edge_labels=['then', 'then'], takeaway='He punished the killing of envoys with total war — making an example that echoed across Asia.', accent=AC),
      bg='West of the Mongol realm lay the wealthy, powerful <b>Khwarezmian Empire</b> (Persia and Central Asia) under <b>Shah Muhammad II</b>. Genghis initially sought <b>peaceful trade</b>.',
      people='<b>Shah Muhammad II</b> of Khwarezm; <b>Inalchuq</b>, the governor of Otrar who massacred the Mongol caravan; the executed Mongol envoys.',
      what='After the governor of <b>Otrar</b> massacred a Mongol trade caravan as spies, Genghis sent envoys demanding justice; the Shah <b>executed or humiliated them</b>. Genghis took this as an unforgivable outrage and launched a full-scale invasion (1219).',
      crux='To Genghis, <b>the murder of envoys and merchants was an absolute violation</b>. His response was deliberately disproportionate — total war — to teach the world that such treachery meant annihilation.',
      conseq='The invasion of Khwarezm (1219–21) became one of the most destructive campaigns in history, erasing cities and killing on a massive scale.',
      matters='Reputation is enforced by response. Genghis made betrayal so catastrophically costly that few would ever dare it again.'),

    E('bukhara', '1220', 'Bukhara and Samarkand — cities erased', ['BATTLE', 'TRAGEDY'],
      'Moving with terrifying speed and coordination, the Mongols storm the jewels of Central Asia; those that resist are massacred and levelled, a calculated terror that makes other cities surrender on sight.',
      svg_terror(),
      bg='The Khwarezmian Empire’s great cities — <b>Bukhara, Samarkand, Urgench, Merv, Nishapur</b> — were centres of Islamic civilisation, learning and trade.',
      people='Shah Muhammad, who scattered his larger army in garrisons instead of massing it; the populations of the great cities, massacred or enslaved; the artisans spared to serve the Mongols.',
      what='The Mongols took <b>Bukhara and Samarkand</b> in 1220 and, over the campaign, <b>massacred defiant cities</b> — sometimes killing or enslaving entire populations, sparing only useful craftsmen. Genghis reportedly called himself “the punishment of God.”',
      crux='The slaughter was <b>strategic terror</b>: by annihilating those who resisted, he made surrender the only rational choice, letting a smaller army conquer a vast empire quickly.',
      conseq='Khwarezm collapsed within about two years. The destruction of irrigation and cities scarred the region for generations, but the Silk Road came under one power.',
      matters='Terror can be brutally effective and morally monstrous at once. It shortened the war — at a human cost counted in the hundreds of thousands or more.'),

    E('khorasan', '1220–1221', 'The annihilation of Khorasan', ['BATTLE', 'TRAGEDY'],
      'To crush all resistance, he lets his armies systematically destroy the great cities of Khorasan — Merv, Nishapur, Herat — in massacres so complete that some are said to have taken days to count the dead, turning one of the world’s richest regions into a depopulated wasteland.',
      svg_row('Cities turned to killing grounds', [
          {'n': 1, 'label': 'Cities resist or revolt', 'sub': 'Merv, Nishapur and Herat defy the Mongols', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Systematic massacre', 'sub': 'populations slaughtered; skulls piled in pyramids', 'color': '#b45309'},
          {'n': 3, 'label': 'A region erased', 'sub': 'irrigation wrecked; Khorasan depopulated for generations', 'color': '#0369a1'},
      ], edge_labels=['then', 'then'], takeaway='He answered resistance with total annihilation — destroying not just armies but whole civilisations of cities.', accent=AC),
      bg='As the Khwarezmian empire collapsed, its heartland of <b>Khorasan</b> — a jewel of Persian-Islamic civilisation — resisted or rebelled against Mongol control.',
      people='The people of <b>Merv, Nishapur and Herat</b>; Genghis’s son <b>Tolui</b>, who led much of the destruction; the chroniclers who recorded staggering death tolls.',
      what='In <b>1220–21</b>, Mongol armies (largely under <b>Tolui</b>) <b>systematically destroyed the great cities of Khorasan</b> — Merv, Nishapur, Herat and others — in massacres of extraordinary scale, and wrecked the irrigation that sustained the region.',
      crux='He used <b>total destruction as a strategic message</b>: annihilating cities that resisted made the cost of defiance so horrific that others would surrender at once.',
      conseq='Khorasan’s population and prosperity were shattered for generations; the atrocities became the archetype of Mongol terror.',
      matters='Genghis’s empire was built on calculated, catastrophic terror as much as on generalship — Khorasan is its most harrowing monument.'),

    E('merv', '1221', 'Merv — erasing one of the world’s greatest cities', ['BATTLE', 'TRAGEDY'],
      'At Merv, a jewel of the Islamic world and one of the largest cities on earth, the Mongols accept its surrender and then methodically slaughter its entire population — a massacre so total it became the age’s byword for annihilation, and a deliberate lesson to every city still standing.',
      svg_stack('Total destruction as policy', [
          {'n': 1, 'label': 'A great city surrenders', 'sub': 'Merv, rich and populous, opens its gates', 'color': '#155e75'},
          {'n': 2, 'label': 'The population divided and killed', 'sub': 'systematically massacred, each soldier assigned a share', 'color': '#b91c1c'},
          {'n': 3, 'label': 'A warning to all others', 'sub': 'terror engineered to make cities surrender without a fight', 'color': '#0369a1'},
      ], takeaway='He made annihilation a calculated instrument — the fate of one city bought the surrender of the next.', accent=AC),
      bg='<b>Merv</b> in Khorasan was among the largest and most cultured cities of the medieval world, a centre of learning on the Silk Road, when the Mongols reached it in 1221.',
      people='the citizens of Merv; Genghis’s son <b>Tolui</b>, who directed the massacre; the chroniclers whose (likely inflated) death tolls horrified the Islamic world.',
      what='After Merv surrendered, the Mongols <b>systematically massacred its inhabitants</b> over days. Medieval chroniclers claimed astronomically high death tolls; whatever the true figure, the city was effectively destroyed.',
      crux='The horror was <b>deliberate psychological warfare</b> — proving resistance or even surrender could mean extinction, to terrify others into submission.',
      conseq='The obliteration of great Khorasani cities like Merv and Nishapur shattered the region’s civilisation for generations and cemented the Mongols’ terrifying reputation.',
      matters='Calculated terror can be a weapon of conquest — but its moral cost, and the devastation it leaves, are staggering.'),

    E('jalaladdin', '1221', 'The last stand at the Indus — Jalal al-Din', ['BATTLE', 'TRIUMPH'],
      'The one Khwarezmian who fights him well is the Shah’s brave son Jalal al-Din, who wins a rare victory over a Mongol force before Genghis corners him against the Indus River — and, watching the prince escape by leaping his horse into the torrent, the old conqueror reportedly admires his courage even as he hunts him.',
      svg_row('A worthy foe cornered at the river', [
          {'n': 1, 'label': 'Jalal al-Din fights on', 'sub': 'the Shah’s son wins a rare victory over the Mongols', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Cornered at the Indus', 'sub': 'Genghis traps his army against the river, 1221', 'color': '#0369a1'},
          {'n': 3, 'label': 'The leap into the river', 'sub': 'the prince escapes across the Indus on horseback', 'color': '#166534'},
      ], edge_labels=['then', 'then'], takeaway='He met one foe worthy of his respect — and pushed the empire’s reach to the edge of India in the chase.', accent=AC),
      bg='As the Khwarezmian empire fell, the Shah’s son <b>Jalal al-Din</b> rallied resistance and even defeated a Mongol detachment — the one Khwarezmian to fight the Mongols with real success.',
      people='<b>Jalal al-Din Mingburnu</b>, the courageous prince; the Mongol armies pursuing him toward India.',
      what='After Jalal al-Din won a rare victory, Genghis pursued and <b>cornered his army against the Indus River (1221)</b>, destroying it — but the prince famously <b>escaped by spurring his horse across the river</b>, an act of daring Genghis is said to have openly admired.',
      crux='He recognised and respected <b>genuine courage and skill</b> even in an enemy — and the pursuit pushed the Mongol reach to the very borders of India.',
      conseq='Khwarezmian resistance was effectively ended; the Mongols had now touched the edge of the Indian subcontinent.',
      matters='Even a conqueror of his ruthlessness could admire a brave foe. Jalal al-Din’s leap became one of the legendary images of the age.'),

    E('yelu', '1215–1227', 'Yelü Chucai — the advisor who taught him to tax, not just kill', ['REFORM', 'POLITICS', 'TURNING POINT'],
      'A captured Khitan scholar changes the future of the empire with a single argument: that living, taxed subjects are worth far more than empty land — persuading Genghis and his heirs to govern and tax the conquered rather than simply exterminate them, the beginning of Mongol statecraft.',
      svg_row('From plunder to government', [
          {'n': 1, 'label': 'A captured scholar', 'sub': 'the Khitan Yelü Chucai enters Mongol service', 'color': '#0369a1'},
          {'n': 2, 'label': '“Tax them, don’t kill them”', 'sub': 'live subjects yield more than empty pasture', 'color': '#166534'},
          {'n': 3, 'label': 'The seed of a state', 'sub': 'administration and taxation begin to replace pure plunder', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='One advisor’s argument turned a machine of destruction toward the arts of government and taxation.', accent=AC),
      bg='The Mongols excelled at conquest but at first had little concept of governing settled populations, some advisers even proposing to turn farmland into pasture.',
      people='<b>Yelü Chucai</b>, the learned Khitan statesman who became a trusted advisor; the Chinese subjects whose lives and taxes he argued for.',
      what='<b>Yelü Chucai</b> persuaded Genghis (and especially his successor Ögedei) that <b>taxing living, productive subjects</b> was far more valuable than exterminating them and emptying the land — laying the intellectual foundation of Mongol <b>administration and taxation</b>.',
      crux='He recognised the limit of pure destruction: an empire must eventually <b>govern and tax</b>, not just plunder, to endure and enrich its rulers.',
      conseq='Mongol rule began to develop real administration; the argument saved countless lives and made the empire far richer.',
      matters='Conquest and governance are different arts. Yelü Chucai’s counsel marks the moment the Mongols began to become a state, not just an army.'),

    E('tolerance', '1206–1227', 'Every faith welcome — religious tolerance as statecraft', ['REFORM', 'POLITICS', 'TURNING POINT'],
      'Genghis makes tolerance a policy of empire: he exempts the priests of every religion from taxes and service, consults Buddhist, Muslim, Christian and Daoist holy men alike, and lets conquered peoples keep their faiths — buying loyalty and legitimacy without a single conversion.',
      svg_row('Ruling many faiths by favouring none', [
          {'n': 1, 'label': 'Clergy of all religions exempt', 'sub': 'Buddhist, Muslim, Christian, Daoist priests freed from tax', 'color': '#0369a1'},
          {'n': 2, 'label': 'No forced conversion', 'sub': 'conquered peoples keep their own beliefs', 'color': '#155e75'},
          {'n': 3, 'label': 'Loyalty and legitimacy', 'sub': 'holy men of every creed pray for the Khan', 'color': '#16a34a'},
      ], edge_labels=['plus', 'yields'], takeaway='He made every religion a stakeholder in his rule — tolerance as a tool of empire, not mere kindness.', accent=AC),
      bg='Genghis ruled peoples of many faiths — shamanist, Buddhist, Muslim, Christian, Daoist. Forcing one religion would have meant endless revolt.',
      people='the <b>Daoist sage Changchun</b>, the Muslim and Christian clerics at his court, the Buddhist lamas — all patronised; the diverse conquered subjects.',
      what='He <b>exempted the clergy of all religions</b> from taxation and duties, consulted holy men of every faith, and permitted freedom of worship — while personally following the sky-god <b>Tengri</b>.',
      crux='He saw that <b>tolerance secured loyalty and information</b> from every community, at no cost to his own authority.',
      conseq='Religious freedom became a hallmark of Mongol rule and helped hold together the most diverse empire the world had seen.',
      matters='Tolerance can be shrewd policy as well as principle — a ruler who threatens no one’s god earns everyone’s prayers.'),

    E('changchun', '1219–1223', 'Summoning the sage — the search for wisdom', ['POLITICS', 'REFORM'],
      'Even amid total war, the conqueror sends for a famous Daoist master, Changchun, and has him brought across thousands of miles to Afghanistan — not for an elixir of immortality, which the sage honestly says he cannot give, but for counsel on how to live and rule, revealing a striking curiosity and a policy of religious tolerance.',
      svg_row('A warlord in search of counsel', [
          {'n': 1, 'label': 'Summons the sage Changchun', 'sub': 'the Daoist master brought across Asia to his camp', 'color': '#0369a1'},
          {'n': 2, 'label': 'Seeks wisdom, not just elixirs', 'sub': 'the sage tells him honestly there is no immortality', 'color': '#166534'},
          {'n': 3, 'label': 'Tolerates all faiths', 'sub': 'exempts clergy from tax; protects religions', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='The great destroyer was also genuinely curious about wisdom — and made tolerance of all religions state policy.', accent=AC),
      bg='Genghis was intensely curious about religion and philosophy, and — like many rulers — interested in longevity and how to rule well.',
      people='The Daoist master <b>Changchun (Qiu Chuji)</b>, who travelled to meet him; the many faiths (Buddhist, Muslim, Christian, Daoist) under Mongol rule.',
      what='Genghis had the sage <b>Changchun</b> brought across Asia to his camp near the Hindu Kush. The master honestly said he had <b>no elixir of immortality</b> but offered moral counsel. Genghis practised broad <b>religious tolerance</b>, exempting clergy of many faiths from taxation.',
      crux='He combined ruthless conquest with a genuine <b>curiosity about wisdom and a policy of religious tolerance</b> — pragmatic and open, not merely destructive.',
      conseq='Mongol religious tolerance became a hallmark of the empire, easing the rule of a vastly diverse population.',
      matters='The man who razed cities also protected every religion in his realm — a reminder that Genghis was more complex than his reputation for terror.'),

    E('subutai', '1220–1223', 'The great raid — Jebe and Subutai ride round the world', ['BATTLE', 'TRIUMPH'],
      'While chasing the fleeing Shah, two of his generals lead a cavalry column on an epic reconnaissance-in-force around the Caspian Sea, smashing every army sent against them — scouting the West for a future invasion.',
      svg_row('A 3-year, 8,000-km armed reconnaissance', [
          {'n': 1, 'label': 'Chase the Shah', 'sub': 'Muhammad II hunted to a lonely death on an island', 'color': '#0369a1'},
          {'n': 2, 'label': 'Ride around the Caspian', 'sub': 'Jebe & Subutai loop through Persia, the Caucasus, the steppe', 'color': '#0e7490'},
          {'n': 3, 'label': 'Beat Rus’ & Cumans (Kalka, 1223)', 'sub': 'crush a Russian-Cuman army, then ride home', 'color': '#16a34a'},
      ], edge_labels=['then', 'then'], takeaway='The Mongols didn’t just conquer — they scouted, learning the roads and armies of enemies they’d return to destroy.', accent=AC),
      bg='As the Shah fled, Genghis detached two of his finest generals, <b>Jebe</b> and <b>Subutai</b>, to hunt him and probe the lands beyond.',
      people='<b>Subutai</b>, perhaps history’s greatest cavalry general; <b>Jebe</b>; the Georgian, Cuman and Rus’ armies they defeated at the <b>Kalka River (1223)</b>.',
      what='The two generals pursued the Shah (who died a fugitive), then led an extraordinary <b>8,000-km loop around the Caspian</b> through Persia, the Caucasus and the south Russian steppe, defeating every force they met — including a Rus’–Cuman army at the <b>Kalka</b> — before rejoining Genghis.',
      crux='It was a <b>strategic reconnaissance</b> as much as a raid: the Mongols mapped the armies, roads and politics of the West, laying the groundwork for the later invasion of Europe.',
      conseq='The raid demonstrated unmatched operational reach and gathered the intelligence Subutai would use to invade Russia and Europe a decade later.',
      matters='Great powers scout before they strike. The Mongols’ genius was not only battle but reconnaissance, learning and planning across whole continents.'),
]

# ==================================================================  PHASE 5 — DEATH & LEGACY
PHASE_END = [
    E('women', '1180s–1227', 'The women who held the empire together', ['POLITICS', 'LOVE', 'REFORM'],
      'Behind the conqueror stood formidable women: the mother who kept his outcast family alive, the wife whose counsel he trusted above all, and the daughters he married to allied kings — then had those kings sent to war, leaving his own daughters to rule the conquered lands in his name.',
      svg_stack('An empire run in part by his family’s women', [
          {'n': 1, 'label': 'Hö’elün, the mother', 'sub': 'kept the abandoned family alive on roots and fish', 'color': '#0369a1'},
          {'n': 2, 'label': 'Börte, the trusted wife', 'sub': 'his chief queen and adviser, whose word carried weight', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Daughters as ruling queens', 'sub': 'married to allied kings — then left to govern their realms', 'color': '#16a34a'},
      ], takeaway='He built loyalty and administration through the women of his house as deliberately as through his generals.', accent=AC),
      bg='Mongol women held real authority — managing camps, herds and even realms. Genghis relied on the women of his family as pillars of his rule.',
      people='<b>Hö’elün</b>, his indomitable mother; <b>Börte</b>, his first wife and chief queen; his <b>daughters</b>, married into the ruling houses of allied peoples.',
      what='His mother’s toughness saved his childhood; <b>Börte’s</b> counsel shaped key decisions (including the fall of the shaman); and he married <b>daughters to allied kings</b>, sending those kings to the front so his daughters governed the lands — an “empire of in-laws.”',
      crux='He treated the <b>women of his family as trusted rulers and advisers</b>, extending his control through marriage and administration.',
      conseq='Mongol royal women continued to wield great power after his death, several acting as regents over the vast empire.',
      matters='Great enterprises are rarely one person’s work — the partners and kin who administer and advise are part of the achievement.'),

    E('succession', '1219–1227', 'Dividing the world among his sons', ['POLITICS', 'TURNING POINT'],
      'Knowing an empire this vast cannot be ruled by one man, he plans the succession with care — settling a bitter quarrel over his eldest son’s disputed birth, and naming the steady Ögedei as heir while allotting each son his own realm, an arrangement that holds the empire together for a generation after his death.',
      svg_row('Planning the succession of a world empire', [
          {'n': 1, 'label': 'The Jochi question', 'sub': 'a bitter dispute over his eldest son’s paternity', 'color': '#7f1d1d'},
          {'n': 2, 'label': 'Ögedei named heir', 'sub': 'the steady third son chosen as Great Khan', 'color': '#166534'},
          {'n': 3, 'label': 'A realm for each son', 'sub': 'the empire divided into sons’ appanages (ulus)', 'color': '#0369a1'},
      ], edge_labels=['then', 'then'], takeaway='He deliberately arranged the succession — the one thing conquerors so often fatally neglect.', accent=AC),
      bg='Genghis’s four sons by Börte — <b>Jochi, Chagatai, Ögedei and Tolui</b> — were potential rivals, and the empire was too vast for any one to rule alone.',
      people='His sons <b>Jochi</b> (whose birth was disputed), <b>Chagatai</b> (who quarrelled with him), <b>Ögedei</b> (the chosen heir) and <b>Tolui</b>.',
      what='Genghis defused the dangerous <b>quarrel over Jochi’s paternity</b>, chose the diplomatic <b>Ögedei as Great Khan</b>, and <b>allotted each son his own realm (ulus)</b> — a considered succession plan meant to keep the empire united.',
      crux='He addressed the flaw that destroys most conquerors’ empires — <b>succession</b> — by planning it deliberately rather than leaving it to a bloody free-for-all.',
      conseq='The arrangement held the empire together and even expanded it for a generation under Ögedei, before later fragmentation.',
      matters='Empires die at the succession. Genghis’s foresight in planning his gave his creation decades of unity that Alexander’s and Attila’s never had.'),

    E('death', '1227', 'Death on campaign — and a secret grave', ['DEATH', 'TRAGEDY'],
      'Returning east, he crushes the Western Xia for their disloyalty and dies during the campaign in 1227. His death is kept secret, his burial place hidden so completely that it has never been found.',
      svg_row('The end of the conqueror', [
          {'n': 1, 'label': 'Final Western Xia war', 'sub': 'punishes them for refusing troops; near-extermination', 'color': '#b45309'},
          {'n': 2, 'label': 'Dies on campaign (1227)', 'sub': 'cause uncertain — a fall, illness, or wounds', 'color': '#111827'},
          {'n': 3, 'label': 'A hidden tomb', 'sub': 'death kept secret; grave concealed, never found', 'color': '#0369a1'},
      ], edge_labels=['then', 'then'], takeaway='He died as he lived — on campaign, undefeated, and shrouded in deliberate mystery.', accent=AC),
      bg='Genghis returned east to punish the <b>Western Xia</b>, who had refused to send troops for the Khwarezm war. During this final campaign, he died in <b>1227</b>.',
      people='His sons — <b>Jochi</b> (died just before him), <b>Chagatai</b>, <b>Ögedei</b> (his chosen heir) and <b>Tolui</b>; the soldiers who kept his death secret.',
      what='Genghis crushed the Western Xia (reportedly ordering their near-extermination) and <b>died in 1227</b> — the cause disputed (a fall from a horse, illness, or wounds). His death was <b>kept secret</b> to finish the campaign, and his <b>burial place hidden</b> so thoroughly it has never been located.',
      crux='Even in death he imposed <b>discipline and secrecy</b>: the succession was arranged, the campaign completed, and his grave concealed to keep it sacred and safe.',
      conseq='He left a united empire and a designated heir — the crucial difference from conquerors like Alexander whose realms shattered instantly.',
      matters='Preparing succession is what separates a lasting empire from a fleeting one. Genghis named an heir and built institutions — so his empire grew after his death rather than dying with him.'),

    E('legacy', '1227–1300s', 'The paradox — destroyer and world-builder', ['POLITICS', 'TURNING POINT'],
      'His heirs push the empire to the largest land empire in history, and under the "Mongol Peace" ideas, goods and technology flow across Eurasia — a connected world built on one of the greatest slaughters ever recorded.',
      svg_legacy(),
      bg='Under his son <b>Ögedei</b> and later heirs, the Mongol Empire expanded to stretch from Korea to Hungary — the largest contiguous land empire in history.',
      people='<b>Ögedei</b>, his heir; grandsons <b>Kublai Khan</b> (who conquered China and founded the Yuan dynasty) and <b>Batu</b> and <b>Hulagu</b> (who conquered Russia and Persia).',
      what='The empire he built and passed on created the <b>Pax Mongolica</b> — secure trade and travel across Eurasia that moved goods, technologies (paper, gunpowder, printing) and ideas between East and West (and, later, the Black Death). It also rested on <b>massacres that killed millions</b>.',
      crux='His legacy is a genuine <b>paradox</b>: a monstrous destroyer of cities and peoples who was also, through meritocracy, religious tolerance, law and secured trade, one of history’s great <b>connectors and state-builders</b>.',
      conseq='He reshaped the map, the gene pool (a striking share of men in the region descend from his line), and the flow of ideas across the medieval world.',
      matters='History’s giants are rarely simply good or evil. Genghis is the starkest case of world-changing achievement and world-shattering destruction in the same life.'),
]

# ==================================================================  OVERVIEW / REFERENCE
OVERVIEW_HTML = """
<p class="ov-lead">Genghis Khan rose from an abandoned, starving outcast on the Mongolian steppe to the founder of the <b>largest contiguous land empire in history</b> — uniting the warring nomad tribes into one nation and turning them on the great settled civilisations of China and Central Asia. His life is the definitive study in <b>building loyalty from nothing, out-competing rivals with a better system, and the paradox of a conqueror who was both a monstrous destroyer and a great connector of the world.</b></p>
<div class="ov-quote">“I am the punishment of God... If you had not committed great sins, God would not have sent a punishment like me upon you.”<span>— words attributed to Genghis Khan before the people of Bukhara</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Outcast boy → survives betrayal and poverty → wins loyalty by merit and fair reward → out-competes his blood-brother to unite the steppe → is proclaimed Genghis Khan and builds a nation-army → conquers northern China (learning siegecraft) → annihilates Khwarezm in revenge for murdered envoys → dies undefeated in 1227, leaving an heir and an empire that becomes the largest in history.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🤝</div><h4>Merit over birth</h4><p>He bound a nation by rewarding loyalty and talent, not bloodline — out-competing rivals who ruled by rank.</p></div>
  <div class="ov-card"><div class="i">🐎</div><h4>The war machine</h4><p>The decimal army, discipline, reconnaissance and absorbed technology — a model of organisation studied ever since.</p></div>
  <div class="ov-card"><div class="i">🌏</div><h4>The Pax Mongolica</h4><p>He connected Eurasia — trade, ideas and technology flowing East–West along a secured Silk Road.</p></div>
  <div class="ov-card"><div class="i">⚠️</div><h4>The cost</h4><p>All of it built on terror and massacre that killed millions — the starkest paradox of achievement and destruction.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Outcast</b><small> 1162–1190s</small><p>Abandonment, poverty, and the first war for his wife.</p></div>
  <div><b>2 · Uniter</b><small> 1190s–1206</small><p>Merit, the break with Jamukha, proclaimed Genghis Khan.</p></div>
  <div><b>3 · China</b><small> 1209–15</small><p>Turning south and learning to take cities.</p></div>
  <div><b>4 · Khwarezm</b><small> 1219–23</small><p>The insult, the annihilation, the great raid west.</p></div>
  <div><b>5 · Death & Legacy</b><small> 1227+</small><p>A hidden grave, an heir, and a connected world.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches. Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Börte', 'role': 'chief wife', 'color': '#db2777',
     'bio': 'His first and most important wife, kidnapped early by the Merkits (prompting his first war). Her sons were his recognised heirs; she remained a powerful, trusted figure throughout his life.',
     'rel': 'His lifelong partner; recovering her was his first campaign.'},
    {'name': 'Hoelun', 'role': 'mother', 'color': '#7c3aed',
     'bio': 'His formidable mother, who kept her abandoned children alive through sheer will after Yesügei’s murder — the source of his toughness.',
     'rel': 'Kept him alive in childhood; forged his resilience.'},
    {'name': 'Jamukha', 'role': 'blood-brother → rival', 'color': '#b45309',
     'bio': 'Temüjin’s charismatic anda (blood-brother) and champion of the old aristocratic order. Their rivalry to unite the Mongols ended with Jamukha’s defeat and execution.',
     'rel': 'The friend-turned-rival whose defeat cleared his path to power.'},
    {'name': 'Toghrul (Ong Khan)', 'role': 'patron → enemy', 'color': '#64748b',
     'bio': 'Powerful khan of the Keraites and Temüjin’s father’s old ally, who backed his early rise — then turned against him and was defeated.',
     'rel': 'The early patron he outgrew and finally overthrew.'},
    {'name': 'Subutai', 'role': 'greatest general', 'color': '#0e7490',
     'bio': 'A commoner raised on merit to become perhaps history’s greatest cavalry general — architect of the great Caspian raid and, later, the invasions of Russia and Europe.',
     'rel': 'The supreme proof of his meritocracy — a nobody made a war-winning marshal.'},
    {'name': 'Jebe', 'role': 'general', 'color': '#155e75',
     'bio': 'A former enemy who, after impressing Genghis (reputedly by shooting his horse), was pardoned and became a brilliant general — co-leader of the great raid around the Caspian.',
     'rel': 'A pardoned foe turned trusted commander — meritocracy in action.'},
    {'name': 'Shah Muhammad II', 'role': 'Khwarezm nemesis', 'color': '#dc2626',
     'bio': 'Ruler of the mighty Khwarezmian Empire whose governor massacred a Mongol caravan and who executed Genghis’ envoys — triggering the annihilation of his empire. Died a hunted fugitive.',
     'rel': 'His fatal insult brought total war on his own civilisation.'},
    {'name': 'Ögedei', 'role': 'heir', 'color': '#16a34a',
     'bio': 'Genghis’ third son and chosen successor, under whom the empire kept expanding (into Russia, Persia and toward Europe). The orderly succession is why the empire grew rather than shattered.',
     'rel': 'The heir who let the empire outlive its founder.'},
    {'name': 'Kublai Khan', 'role': 'grandson', 'color': '#0369a1',
     'bio': 'Grandson who completed the conquest of China and founded the Yuan dynasty, ruling as emperor of China — the empire’s later apogee in the East.',
     'rel': 'Carried the conquest to its height a generation on.'},
]

KEY_EVENTS = [
    ('c. 1162', 'Born Temüjin', 'A minor chief’s son on the feuding steppe.'),
    ('c. 1171', 'Father poisoned; family abandoned', 'From privilege to starving poverty.'),
    ('c. 1180s', 'Börte kidnapped and rescued', 'His first campaign and first alliances.'),
    ('1180s–1200s', 'Builds a meritocratic following', 'Wins loyalty by talent and fair reward.'),
    ('1201–1205', 'Defeats Jamukha and rivals', 'Meritocracy beats the aristocratic order.'),
    ('1206', 'Proclaimed Genghis Khan', 'Unites the tribes; the Yassa, decimal army, script.'),
    ('1209–10', 'Subdues the Western Xia', 'First blow against the settled world.'),
    ('1211–15', 'War on Jin China; Zhongdu falls', 'Learns siege warfare; takes Beijing (1215).'),
    ('1218–19', 'Otrar massacre; envoys killed', 'Khwarezm’s fatal insult triggers invasion.'),
    ('1220', 'Bukhara & Samarkand fall', 'Terror-massacres shatter the empire.'),
    ('1220–23', 'Jebe & Subutai’s great raid', '8,000 km around the Caspian; Kalka River (1223).'),
    ('1226–27', 'Final Western Xia campaign', 'Crushes the Tangut for disloyalty.'),
    ('1227', 'Death; secret burial', 'Dies on campaign; grave hidden, never found.'),
    ('1227+', 'The empire grows under Ögedei', 'Becomes the largest contiguous empire in history.'),
]

MASTER = [
    {'year': 'c.1162', 'age': 'born', 'phase': 'Outcast', 'title': 'Born Temüjin', 'desc': 'A minor chief’s son on the steppe.'},
    {'year': 'c.1171', 'age': 'child', 'phase': 'Outcast', 'title': 'Abandoned', 'desc': 'Father poisoned; family left to starve.'},
    {'year': 'c.1184', 'age': 'young', 'phase': 'Outcast', 'title': 'Rescues Börte', 'desc': 'First campaign and alliances.'},
    {'year': '1206', 'age': 'age ~44', 'phase': 'Uniter', 'title': 'Genghis Khan', 'desc': 'Unites the steppe; builds a nation-army.'},
    {'year': '1215', 'age': 'age ~53', 'phase': 'China', 'title': 'Zhongdu falls', 'desc': 'Masters siege warfare; takes Beijing.'},
    {'year': '1219', 'age': 'age ~57', 'phase': 'Khwarezm', 'title': 'Invades Khwarezm', 'desc': 'Revenge for murdered envoys.'},
    {'year': '1220', 'age': 'age ~58', 'phase': 'Khwarezm', 'title': 'Bukhara & Samarkand', 'desc': 'Terror-massacres shatter an empire.'},
    {'year': '1223', 'age': 'age ~61', 'phase': 'Khwarezm', 'title': 'The great raid; Kalka', 'desc': 'Subutai & Jebe loop the Caspian.'},
    {'year': '1227', 'age': 'age ~65', 'phase': 'Death', 'title': 'Death & hidden grave', 'desc': 'Dies on campaign; an heir in place.'},
    {'year': '1227+', 'age': 'legacy', 'phase': 'Death', 'title': 'The largest empire', 'desc': 'Grows under his heirs; the Pax Mongolica.'},
]

SOURCES = [
    ('Britannica — Genghis Khan', 'https://www.britannica.com/biography/Genghis-Khan'),
    ('World History Encyclopedia — Genghis Khan', 'https://www.worldhistory.org/Genghis_Khan/'),
    ('Britannica — Mongol Empire', 'https://www.britannica.com/place/Mongol-empire'),
    ('Wikipedia — Genghis Khan', 'https://en.wikipedia.org/wiki/Genghis_Khan'),
]

def build_meta():
    return {
        'pid': 'gm-genghis.html', 'kind': 'man', 'emoji': '🐎', 'accent': AC,
        'name': 'Genghis Khan', 'years': 'c. 1162–1227', 'group': 'Asian Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'An abandoned, starving outcast who united the steppe and forged the largest contiguous empire in history — history’s starkest paradox of world-builder and world-destroyer.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'outcast', 'label': '1 · The Outcast', 'type': 'timeline',
             'intro': 'Betrayal, abandonment and starvation on the steppe forge a boy who learns that only loyalty you command and power you hold are ever real.', 'events': PHASE_OUTCAST},
            {'id': 'unite', 'label': '2 · Uniter', 'type': 'timeline',
             'intro': 'He out-competes every rival not mainly by battle but by a better system — merit, loyalty and fair spoils — and fuses the warring tribes into one nation.', 'events': PHASE_UNITE},
            {'id': 'china', 'label': '3 · China', 'type': 'timeline',
             'intro': 'He turns his horse-nation on the rich, walled settled world — and, unable to storm cities, absorbs the enemy’s engineers until the Mongols master siege warfare.', 'events': PHASE_CHINA},
            {'id': 'khwarezm', 'label': '4 · Khwarezm', 'type': 'timeline',
             'intro': 'A massacred caravan and murdered envoys unleash one of history’s most destructive campaigns — and a legendary cavalry raid that scouts the whole western world.', 'events': PHASE_KHWAREZM},
            {'id': 'end', 'label': '5 · Death & Legacy', 'type': 'timeline',
             'intro': 'He dies undefeated on campaign, buried in secret — leaving an heir and an empire that becomes the largest in history, and a legacy of both connection and slaughter.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Much of his early life comes from the semi-legendary “Secret History of the Mongols”; birth date, death cause and casualty figures are all debated. This guide flags what is legend versus record.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
