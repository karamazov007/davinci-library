# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Jesus Christ (Jesus of Nazareth).
The central figure of Christianity, whose life is recounted in the Gospels.
Presented with respect: the Gospel account and the historical context are given
reverently and neutrally, noting where tradition and scholarship differ without
adjudicating between them. Diagrams are abstract concept maps only."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#6d28d9'  # liturgical violet

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — THE COMING
PHASE_COMING = [
    E('nativity', 'c. 4 BC', 'The Nativity — born in Bethlehem', ['RISE', 'TURNING POINT'],
      'The Gospels of Matthew and Luke recount the birth of Jesus in Bethlehem in Judea during the reign of Herod the Great — to Mary and Joseph, in humble circumstances, heralded to shepherds by angels and honoured by Magi from the East. Historians place the birth around 6–4 BC.',
      svg_stack('The birth recounted in the Gospels', [
          {'n': 1, 'label': 'Journey to Bethlehem', 'sub': 'Mary and Joseph travel for a Roman census', 'color': '#3730a3'},
          {'n': 2, 'label': 'Born and laid in a manger', 'sub': 'no room at the inn; born in the city of David', 'color': '#a16207'},
          {'n': 3, 'label': 'Shepherds and Magi', 'sub': 'angels announce him; wise men bring gifts', 'color': '#166534'},
      ], takeaway='In the Gospel account, the awaited Messiah enters the world in poverty, in the city of David.', accent=AC),
      bg='According to the Gospels of <b>Matthew and Luke</b>, Jesus was born in <b>Bethlehem</b> in Judea in the reign of <b>Herod the Great</b>; historians estimate the birth at around <b>6–4 BC</b>.',
      people='<b>Mary</b>, his mother; <b>Joseph</b>, a carpenter of the line of David; the <b>shepherds</b> and the <b>Magi</b>; King <b>Herod</b>.',
      what='Luke describes Mary and Joseph travelling to Bethlehem for a census, where Jesus was born and laid in a <b>manger</b>, with angels announcing the news to shepherds; Matthew tells of <b>Magi</b> guided by a star and of Herod’s slaughter of the infants.',
      crux='The Gospels present the birth as the <b>fulfilment of prophecy</b> — the Messiah born in the city of David, yet in the humblest of settings.',
      conseq='Warned in a dream, the family fled to <b>Egypt</b> to escape Herod, later returning to settle in Nazareth in Galilee.',
      matters='The Nativity is a foundation of Christian faith and is celebrated at <b>Christmas</b> — remembered as God entering the world in humility.'),

    E('nazareth', 'childhood', 'Growing up in Nazareth', ['RISE'],
      'The Gospels record little of the years between infancy and adulthood. Jesus was raised in Nazareth, a small town in Galilee, in a devout Jewish household, learning Joseph’s trade as a carpenter. Luke alone preserves one scene: the boy Jesus, aged twelve, astonishing the teachers in the Temple.',
      svg_row('The hidden years in Galilee', [
          {'n': 1, 'label': 'Raised in Nazareth', 'sub': 'a small town in rural Galilee', 'color': '#3730a3'},
          {'n': 2, 'label': 'A devout Jewish home', 'sub': 'the carpenter’s trade; the Law and prophets', 'color': '#a16207'},
          {'n': 3, 'label': 'The boy in the Temple', 'sub': 'at twelve, he amazes the teachers', 'color': '#166534'},
      ], edge_labels=['in', 'then'], takeaway='Little is recorded of these years; Jesus grew up observant and obscure in rural Galilee.', accent=AC),
      bg='After the return from Egypt, the family settled in <b>Nazareth</b>, an obscure town in Galilee, and Jesus grew up in a <b>Jewish household</b> shaped by the Law and the prophets.',
      people='<b>Mary</b> and <b>Joseph</b>; the teachers of the Law in the Temple; the village community of Nazareth.',
      what='The Gospels pass over most of these years in silence; Jesus is remembered as learning <b>Joseph’s trade</b> as a carpenter. Luke records the single episode of the <b>twelve-year-old Jesus</b> questioning the teachers in the Jerusalem Temple.',
      crux='The Gospels present a <b>hidden, ordinary upbringing</b> — the Messiah formed within a faithful Jewish family and community.',
      conseq='He emerged from Nazareth around the age of thirty to begin his public ministry.',
      matters='These “hidden years” root Jesus firmly in the <b>Jewish life of first-century Galilee</b> — a detail on which Gospel tradition and historians agree.'),

    E('baptism', 'c. AD 26–29', 'The baptism by John the Baptist', ['TURNING POINT', 'REFORM'],
      'At the river Jordan, Jesus was baptised by John the Baptist, a prophet calling Israel to repentance. The Gospels describe the heavens opening, the Spirit descending like a dove, and a voice from heaven — the moment that inaugurates his public ministry.',
      svg_stack('The ministry begins at the Jordan', [
          {'n': 1, 'label': 'John preaches repentance', 'sub': 'baptising in the river Jordan', 'color': '#78350f'},
          {'n': 2, 'label': 'Jesus is baptised', 'sub': 'he comes to John to be baptised', 'color': '#3730a3'},
          {'n': 3, 'label': 'The Spirit descends', 'sub': 'a dove; a voice from heaven', 'color': '#a16207'},
      ], takeaway='The Gospels mark the baptism as the opening of Jesus’ public ministry.', accent=AC),
      bg='<b>John the Baptist</b>, a prophetic figure, was calling people to <b>repentance</b> and baptising them in the <b>river Jordan</b> as Jesus reached adulthood.',
      people='<b>John the Baptist</b>, the forerunner; Jesus, who comes to be baptised; the crowds at the Jordan.',
      what='The Gospels recount that Jesus was <b>baptised by John</b>, and that as he came up from the water the heavens opened, the <b>Spirit descended like a dove</b>, and a <b>voice from heaven</b> declared him the beloved Son.',
      crux='The baptism marks the <b>threshold of the public ministry</b> — the private man of Nazareth stepping forward as a public teacher.',
      conseq='Immediately afterward, according to the Gospels, the Spirit led Jesus into the wilderness to be tested.',
      matters='The baptism is one of the events most widely accepted by <b>historians</b> as well as central to the <b>Gospel narrative</b> — the recognised start of his mission.'),
]

# ==================================================================  PHASE 2 — THE MINISTRY BEGINS
PHASE_MINISTRY = [
    E('temptation', 'c. AD 27', 'The temptation in the wilderness', ['BATTLE'],
      'The Gospels describe Jesus fasting forty days in the wilderness, where he is tempted three times by Satan — to turn stones to bread, to leap from the Temple, and to seize the kingdoms of the world. Each time he answers with Scripture and refuses.',
      svg_stack('Tested in the desert', [
          {'n': 1, 'label': 'Forty days of fasting', 'sub': 'led into the wilderness by the Spirit', 'color': '#78350f'},
          {'n': 2, 'label': 'Three temptations', 'sub': 'bread, the Temple pinnacle, the kingdoms', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Answered by Scripture', 'sub': 'he refuses each; the tempter departs', 'color': '#166534'},
      ], takeaway='The Gospels present the wilderness as a testing of purpose before the ministry unfolds.', accent=AC),
      bg='Following his baptism, according to the Gospels, Jesus withdrew into the <b>wilderness of Judea</b> and fasted for <b>forty days</b>.',
      people='Jesus, alone in the desert; <b>Satan</b>, the tempter; the wilderness itself.',
      what='The Gospels recount <b>three temptations</b> — to turn stones into bread, to throw himself from the Temple, and to receive all the kingdoms of the world — each of which Jesus <b>rejects, quoting Scripture</b>.',
      crux='The episode dramatises the <b>testing and defining of his mission</b> — refusing power, spectacle and self-service.',
      conseq='Having withstood the trial, Jesus returned to Galilee and began to preach and gather followers.',
      matters='The temptation frames the <b>character of the ministry to come</b> — a path of service and self-denial rather than worldly power.'),

    E('apostles', 'c. AD 27–28', 'The calling of the twelve apostles', ['RISE', 'REFORM'],
      'By the Sea of Galilee, Jesus called ordinary men — fishermen among them — to follow him, saying he would make them fishers of men. From his followers he chose twelve as apostles, to be with him and to be sent out to proclaim the Kingdom.',
      svg_row('Choosing the twelve', [
          {'n': 1, 'label': 'Calls fishermen', 'sub': '“follow me”; by the Sea of Galilee', 'color': '#3730a3'},
          {'n': 2, 'label': 'Twelve apostles chosen', 'sub': 'Peter, Andrew, James, John and the rest', 'color': '#a16207'},
          {'n': 3, 'label': 'Sent to proclaim', 'sub': 'to be with him and to preach', 'color': '#166534'},
      ], edge_labels=['then', 'to'], takeaway='He gathered an inner circle of twelve to share and carry his mission.', accent=AC),
      bg='Beginning his ministry in <b>Galilee</b>, Jesus drew followers and chose an inner circle to accompany and assist him.',
      people='<b>Simon Peter</b> and his brother <b>Andrew</b>; <b>James</b> and <b>John</b>, sons of Zebedee; and the other apostles, including <b>Judas Iscariot</b>.',
      what='The Gospels describe Jesus calling <b>fishermen from their nets</b> — “I will make you fishers of men” — and appointing <b>twelve apostles</b> to be with him and to be sent out to preach and heal.',
      crux='He built the ministry around a <b>chosen twelve</b>, a number echoing the twelve tribes of Israel, to carry the message onward.',
      conseq='These twelve became the core of the early movement and, after the Resurrection, the leaders of the emerging Church.',
      matters='The calling of the apostles established the <b>community that would transmit</b> Jesus’ teaching and become the foundation of Christianity.'),

    E('kingdom', 'c. AD 28', 'The ministry in Galilee — proclaiming the Kingdom', ['REFORM', 'RISE'],
      'Across the towns and shores of Galilee, Jesus preached that the Kingdom of God was at hand, calling people to repentance and announcing good news to the poor. Crowds gathered as he taught in synagogues, on hillsides and by the lake.',
      svg_stack('The message across Galilee', [
          {'n': 1, 'label': '“The Kingdom is at hand”', 'sub': 'a call to repentance and to God', 'color': '#3730a3'},
          {'n': 2, 'label': 'Crowds gather', 'sub': 'teaching in synagogues and on the shore', 'color': '#a16207'},
          {'n': 3, 'label': 'Good news to the poor', 'sub': 'mercy for the humble and the outcast', 'color': '#166534'},
      ], takeaway='The Gospels centre the Galilean ministry on the coming Kingdom of God.', accent=AC),
      bg='The heart of Jesus’ public work, the Gospels record, unfolded in the villages and along the lake of <b>Galilee</b>.',
      people='the <b>crowds</b> of Galilee; the <b>apostles</b>; tax collectors, the sick and the poor drawn to him.',
      what='Jesus proclaimed that the <b>Kingdom of God</b> was near, calling for <b>repentance</b> and announcing good news especially to the poor and the marginalised, teaching in synagogues, on hillsides and from boats.',
      crux='The <b>Kingdom of God</b> stood at the centre of his preaching — a reign of God breaking into the world, calling for a change of heart.',
      conseq='His growing fame and his message drew large followings, and increasingly the suspicion of religious authorities.',
      matters='The proclamation of the <b>Kingdom of God</b> is the recurring theme of his ministry and the frame for his teachings and parables.'),
]

# ==================================================================  PHASE 3 — TEACHINGS & MIRACLES
PHASE_TEACHINGS = [
    E('sermon', 'c. AD 28', 'The Sermon on the Mount and the Beatitudes', ['REFORM', 'TRIUMPH'],
      'In Matthew’s Gospel, Jesus teaches a great sermon on a mountainside. It opens with the Beatitudes — “blessed are the poor in spirit… the meek… the peacemakers” — and gathers his ethical teaching: love of enemies, mercy, and the words of the Lord’s Prayer.',
      svg_row('The heart of his teaching', [
          {'n': 1, 'label': 'Teaches on the mountain', 'sub': 'the crowds gather to listen', 'color': '#3730a3'},
          {'n': 2, 'label': 'The Beatitudes', 'sub': '“blessed are the poor in spirit…”', 'color': '#a16207'},
          {'n': 3, 'label': 'Mercy, love, prayer', 'sub': 'love of enemies; the Lord’s Prayer', 'color': '#166534'},
      ], edge_labels=['begins', 'then'], takeaway='The Sermon on the Mount gathers Jesus’ ethical teaching into one discourse.', accent=AC),
      bg='<b>Matthew’s Gospel</b> presents the <b>Sermon on the Mount</b> as a great compendium of Jesus’ teaching, delivered on a hillside to the gathered crowds.',
      people='Jesus, the teacher; the <b>crowds</b> and disciples who listen; the poor and the meek he blesses.',
      what='The sermon opens with the <b>Beatitudes</b> — blessings on the poor in spirit, the mourning, the meek, the merciful, the peacemakers — and continues with teaching on <b>love of enemies, forgiveness, mercy</b> and the <b>Lord’s Prayer</b>.',
      crux='It reorients righteousness toward the <b>inner heart</b> — humility, mercy and love — rather than outward observance alone.',
      conseq='The sermon became one of the most influential texts in Western moral and religious thought.',
      matters='The <b>Beatitudes and the Sermon on the Mount</b> are among the best-known expressions of Christian ethics and of Jesus’ vision of the Kingdom.'),

    E('parables', 'c. AD 28–29', 'Teaching in parables', ['REFORM'],
      'Jesus often taught in parables — short stories drawn from everyday life that carried the truths of the Kingdom. The Sower, the Prodigal Son, the Good Samaritan, the Mustard Seed and many more used familiar images to convey deeper meaning.',
      svg_stack('Kingdom truths in everyday stories', [
          {'n': 1, 'label': 'He teaches in parables', 'sub': 'short stories from daily life', 'color': '#3730a3'},
          {'n': 2, 'label': 'Sower, Prodigal Son, Samaritan', 'sub': 'the mustard seed; the lost sheep', 'color': '#a16207'},
          {'n': 3, 'label': 'A deeper meaning', 'sub': 'the Kingdom revealed in familiar images', 'color': '#166534'},
      ], takeaway='The parables convey the Kingdom of God through ordinary, memorable images.', accent=AC),
      bg='A characteristic feature of Jesus’ teaching, the Gospels record, was his use of <b>parables</b> — vivid stories drawn from farming, family and village life.',
      people='the <b>listening crowds</b>; the disciples, to whom he explained the parables; the ordinary folk whose lives supplied the images.',
      what='Among the best known are the <b>Sower</b>, the <b>Prodigal Son</b>, the <b>Good Samaritan</b>, the <b>Mustard Seed</b> and the <b>Lost Sheep</b> — everyday scenes turned into teaching about God, mercy and the Kingdom.',
      crux='The parable <b>reveals and conceals at once</b> — a simple story that opens its meaning to those who reflect on it.',
      conseq='The parables became among the most memorable and widely retold of all Jesus’ teachings.',
      matters='The <b>parables</b> are a hallmark of Jesus’ method — profound teaching carried in plain, unforgettable images.'),

    E('miracles', 'c. AD 28–29', 'The miracles reported in the Gospels', ['TRIUMPH', 'REFORM'],
      'The Gospels report many miracles: healing the sick, blind and lame; calming a storm; feeding a multitude with a few loaves and fish; walking on water; and raising the dead, as with Lazarus. For believers these are signs of divine power; the Gospels present them as such.',
      svg_row('The signs recounted in the Gospels', [
          {'n': 1, 'label': 'Healings', 'sub': 'the sick, blind, lame and lepers', 'color': '#3730a3'},
          {'n': 2, 'label': 'Power over nature', 'sub': 'calming the storm; feeding the five thousand', 'color': '#a16207'},
          {'n': 3, 'label': 'Raising the dead', 'sub': 'the raising of Lazarus', 'color': '#166534'},
      ], edge_labels=['and', 'and'], takeaway='The Gospels present the miracles as signs of the in-breaking Kingdom.', accent=AC),
      bg='Alongside his teaching, the Gospels report that Jesus performed many <b>miracles</b>, drawing crowds and stirring wonder across Galilee and Judea.',
      people='the <b>sick and suffering</b> he is said to heal; the <b>disciples</b> who witness; <b>Lazarus</b>, raised from the tomb.',
      what='The reported miracles include <b>healings</b> of the sick, blind and lame; <b>power over nature</b> such as calming a storm, walking on water and <b>feeding the five thousand</b>; and the <b>raising of the dead</b>, notably Lazarus.',
      crux='The Gospels present the miracles as <b>signs of divine authority</b> and of the Kingdom breaking into the world — matters of faith rather than of neutral record.',
      conseq='The miracles heightened both Jesus’ following and the alarm of authorities who saw his influence growing.',
      matters='For Christians the miracles are <b>signs of who Jesus is</b>; historians treat them as faith claims within the Gospel testimony rather than as verifiable events.'),
]

# ==================================================================  PHASE 4 — THE PASSION
PHASE_PASSION = [
    E('palmsunday', 'c. AD 30/33', 'The entry into Jerusalem (Palm Sunday)', ['TURNING POINT', 'TRIUMPH'],
      'The Gospels recount Jesus entering Jerusalem for Passover riding on a donkey, greeted by crowds spreading cloaks and palm branches and crying “Hosanna.” Christians mark this as Palm Sunday, the opening of Holy Week. Soon after, he drives the money-changers from the Temple.',
      svg_stack('Arrival in the holy city', [
          {'n': 1, 'label': 'Enters on a donkey', 'sub': 'coming to Jerusalem for Passover', 'color': '#3730a3'},
          {'n': 2, 'label': 'Crowds cry “Hosanna”', 'sub': 'palms and cloaks strewn on the road', 'color': '#a16207'},
          {'n': 3, 'label': 'Cleansing the Temple', 'sub': 'he drives out the money-changers', 'color': '#b91c1c'},
      ], takeaway='The Gospels mark the entry as the opening of the final week — Holy Week.', accent=AC),
      bg='As <b>Passover</b> approached, Jesus came to <b>Jerusalem</b>, the religious centre of Judaism, where crowds of pilgrims had gathered.',
      people='the <b>crowds</b> welcoming him; the <b>apostles</b>; the <b>Temple authorities</b> and merchants he confronted.',
      what='The Gospels describe Jesus <b>riding into Jerusalem on a donkey</b>, hailed by crowds waving <b>palm branches</b> and shouting “Hosanna,” and soon afterward <b>cleansing the Temple</b> by driving out the money-changers.',
      crux='The entry is presented as a <b>deliberate, prophetic act</b> — a humble king coming to the city — that heightened tensions with the authorities.',
      conseq='The Temple confrontation sharpened the resolve of religious leaders to move against him.',
      matters='Christians commemorate this as <b>Palm Sunday</b>, the beginning of Holy Week that leads to the Crucifixion and Resurrection.'),

    E('lastsupper', 'c. AD 30/33', 'The Last Supper', ['TURNING POINT', 'LOVE'],
      'On the night before his death, Jesus shared a final Passover meal with his apostles. He blessed bread and wine, saying “this is my body” and “this is my blood,” instituting what Christians observe as the Eucharist, and foretold his betrayal and Peter’s denial.',
      svg_row('The final meal', [
          {'n': 1, 'label': 'Passover with the Twelve', 'sub': 'the last meal before his death', 'color': '#3730a3'},
          {'n': 2, 'label': 'Bread and wine', 'sub': '“this is my body… my blood”', 'color': '#a16207'},
          {'n': 3, 'label': 'Betrayal foretold', 'sub': 'and Peter’s coming denial', 'color': '#b91c1c'},
      ], edge_labels=['then', 'and'], takeaway='The Gospels present the supper as instituting the Eucharist on the eve of the Passion.', accent=AC),
      bg='On the eve of his death, the Gospels record, Jesus gathered his apostles for a <b>Passover meal</b> in Jerusalem.',
      people='Jesus and the <b>twelve apostles</b>; <b>Judas</b>, about to betray; <b>Peter</b>, who would deny.',
      what='Jesus <b>blessed and shared bread and wine</b>, saying “this is my body” and “this is my blood,” and foretold that one of the Twelve would <b>betray</b> him and that Peter would <b>deny</b> him three times.',
      crux='The words over the bread and wine <b>institute the Eucharist</b> — the central rite of Christian worship — on the threshold of his death.',
      conseq='After the meal Jesus went to the garden of Gethsemane to pray, where he would be arrested.',
      matters='The Last Supper is remembered in the Christian <b>Eucharist (Holy Communion)</b> and marks the opening of the Passion.'),

    E('trial', 'c. AD 30/33', 'Betrayal, arrest, and the trials', ['DEFEAT', 'TRAGEDY'],
      'Judas betrayed Jesus with a kiss in Gethsemane, and he was arrested by night. He was tried before the Jewish Sanhedrin on a charge of blasphemy, then handed to the Roman governor Pontius Pilate, before whom the charge became sedition — claiming to be “King of the Jews.”',
      svg_compare('From a religious charge to a Roman sentence',
        {'head': 'Before the Sanhedrin', 'color': '#3730a3', 'items': [
            'Judas betrays him with a kiss in Gethsemane',
            'Arrested at night; the apostles scatter',
            'Questioned by the high priest Caiaphas',
            'Charged with blasphemy']},
        {'head': 'Before Pontius Pilate', 'color': '#b91c1c', 'items': [
            'Handed to the Roman governor',
            'Charged as “King of the Jews” — sedition',
            'Pilate hesitates but yields to the crowd',
            'Condemned to crucifixion']},
        verdict='A religious charge of blasphemy became a Roman charge of sedition — and a sentence of death.',
        takeaway='The Gospels trace the path from betrayal through two trials to the sentence of crucifixion.', accent=AC),
      bg='After the Last Supper, in the garden of <b>Gethsemane</b>, the Gospels record that Jesus was betrayed and arrested as Passover unfolded in Jerusalem.',
      people='<b>Judas Iscariot</b>, the betrayer; the high priest <b>Caiaphas</b> and the <b>Sanhedrin</b>; the Roman governor <b>Pontius Pilate</b>.',
      what='<b>Judas betrayed Jesus with a kiss</b>; he was arrested, tried before the <b>Sanhedrin</b> on a charge of <b>blasphemy</b>, then brought before <b>Pilate</b>, where the accusation was recast as claiming to be “<b>King of the Jews</b>.” Pilate, the Gospels say, yielded to the crowd.',
      crux='A <b>religious accusation</b> before the Sanhedrin was translated into a <b>political charge of sedition</b> that a Roman governor could punish with death.',
      conseq='Pilate sentenced Jesus to <b>crucifixion</b>, the Roman penalty for rebels and slaves.',
      matters='The arrest and trials — and the roles of Judas, the Sanhedrin and Pilate — are pivotal to the Passion narrative and much studied by historians of the period.'),
]

# ==================================================================  PHASE 5 — DEATH AND RESURRECTION
PHASE_RESURRECTION = [
    E('crucifixion', 'c. AD 30/33', 'The Crucifixion at Golgotha', ['DEATH', 'TRAGEDY'],
      'Jesus was scourged and led to Golgotha, the “place of the skull,” outside Jerusalem, where he was crucified between two others. The Gospels record his final words, a darkness over the land, and the tearing of the Temple veil. He died and was laid in a tomb.',
      svg_stack('Death outside the city walls', [
          {'n': 1, 'label': 'Scourged and led out', 'sub': 'to Golgotha, the place of the skull', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Crucified between two others', 'sub': 'the Roman penalty for rebels', 'color': '#78350f'},
          {'n': 3, 'label': '“It is finished”', 'sub': 'darkness; the Temple veil is torn; he dies', 'color': '#3730a3'},
      ], takeaway='The Gospels recount the death on the cross and burial in a tomb.', accent=AC),
      bg='Condemned by Pilate, Jesus was subjected to the Roman punishment of <b>crucifixion</b> at <b>Golgotha</b>, outside the walls of Jerusalem.',
      people='the <b>Roman soldiers</b>; the two crucified beside him; <b>Mary</b> and the women; <b>Joseph of Arimathea</b>, who buried him.',
      what='After being <b>scourged</b>, Jesus was <b>crucified between two others</b>. The Gospels record his final sayings, a <b>darkness over the land</b>, and the <b>tearing of the Temple veil</b>; he died and was laid in a rock-cut <b>tomb</b>.',
      crux='The <b>cross</b>, an instrument of shameful death, became for Christians the very centre of faith — sacrifice and redemption.',
      conseq='His body was placed in a tomb before the Sabbath; his followers were scattered and grieving.',
      matters='The Crucifixion, commemorated on <b>Good Friday</b>, is among the events historians most widely accept, and stands at the heart of Christian belief in redemption.'),

    E('resurrection', 'c. AD 30/33', 'The Resurrection', ['TRIUMPH', 'RISE'],
      'The Gospels proclaim that on the third day the tomb was found empty and Jesus rose from the dead, appearing to Mary Magdalene, then to the apostles and others. For Christians the Resurrection is the foundation of the faith, celebrated at Easter.',
      svg_stack('The proclamation of Easter', [
          {'n': 1, 'label': 'Laid in the tomb', 'sub': 'sealed and guarded', 'color': '#3730a3'},
          {'n': 2, 'label': 'The empty tomb', 'sub': 'on the third day, the stone is rolled away', 'color': '#a16207'},
          {'n': 3, 'label': 'He appears to his own', 'sub': 'to Mary Magdalene, then the apostles', 'color': '#166534'},
      ], takeaway='Christians hold the Resurrection to be the foundation of their faith.', accent=AC),
      bg='After the burial, the Gospels record, the followers of Jesus kept the Sabbath in grief and fear.',
      people='<b>Mary Magdalene</b> and the women at the tomb; the <b>apostles</b>; the risen Christ himself.',
      what='The Gospels proclaim that on the <b>third day the tomb was empty</b> and that Jesus <b>rose from the dead</b>, appearing first to Mary Magdalene and then to the <b>apostles</b> and many others.',
      crux='The <b>Resurrection</b> transforms the Crucifixion from defeat into victory — the core claim on which Christian faith rests.',
      conseq='The apostles, once scattered, were emboldened to proclaim the risen Christ throughout the world.',
      matters='The Resurrection is the <b>central belief of Christianity</b>, celebrated at <b>Easter</b>; it is proclaimed as a matter of faith rather than established by historical method.'),

    E('commission', 'from c. AD 30/33', 'The Great Commission and the historical question', ['RISE', 'REFORM'],
      'The Gospels close with the risen Christ commissioning the apostles to make disciples of all nations, and with his Ascension; the Church is born at Pentecost. Historians, working from evidence, describe the same figure through a different lens — noting where testimony of faith and reconstruction of the past diverge.',
      svg_compare('Two ways of describing the same figure',
        {'head': 'The Gospel proclamation', 'color': '#3730a3', 'items': [
            'The risen Christ commissions the apostles',
            '“Go and make disciples of all nations”',
            'The Ascension into heaven',
            'The Church is born at Pentecost']},
        {'head': 'Historical-Jesus scholarship', 'color': '#a16207', 'items': [
            'A Galilean Jewish teacher, c.4 BC–c.30/33 AD',
            'Baptism and crucifixion widely held historical',
            'Miracles and Resurrection are faith claims',
            'The Gospels read as theological testimony']},
        verdict='Believers and historians describe the same figure through different lenses — the testimony of faith and the reconstruction of evidence.',
        takeaway='Gospel proclamation and historical scholarship view the same life through different lenses.', accent=AC),
      bg='The Gospels end not with the Crucifixion but with the <b>Resurrection appearances</b> and the sending out of the apostles; historians, meanwhile, study the same life through the tools of their discipline.',
      people='the <b>apostles</b>, commissioned to preach; the early <b>Church</b>; the <b>historians</b> who reconstruct the figure of Jesus.',
      what='The Gospels record the <b>Great Commission</b> — “make disciples of all nations” — and the <b>Ascension</b>, with the Church born at <b>Pentecost</b>. Historical-Jesus scholarship generally accepts his <b>baptism and crucifixion</b> as historical, while treating <b>miracles and Resurrection</b> as claims of faith and the Gospels as theological testimony.',
      crux='The <b>Gospel account and historical scholarship</b> address the same person with different aims — one proclaiming faith, the other weighing evidence — and this guide notes their differences without adjudicating between them.',
      conseq='From this small movement in Judea grew <b>Christianity</b>, which became one of the world’s major religions.',
      matters='Understanding Jesus means holding together the <b>Gospel proclamation</b> and the <b>historical inquiry</b> — distinct but both part of how his life is known and remembered.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Jesus of Nazareth is the central figure of Christianity — a first-century Jewish teacher and preacher from Galilee whose life, teachings, death and resurrection are recounted in the four Gospels. Christians revere him as the Son of God and risen Lord; historians study him as a Galilean Jew who was baptised by John, gathered followers, taught the coming Kingdom of God, and was crucified under Pontius Pilate. This guide follows the <b>Gospel narrative reverently and the historical context neutrally</b>, noting where tradition and scholarship differ without adjudicating between them. His life is a study in <b>humility, the Kingdom of God, and a message that reshaped the world.</b></p>
<div class="ov-quote">“Love your neighbour as yourself.”<span>— attributed to Jesus in the Gospels</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born in Bethlehem and raised in Nazareth → baptised by John at the Jordan and tested in the wilderness → calls twelve apostles and proclaims the Kingdom across Galilee → teaches the Sermon on the Mount, the parables, and works the miracles the Gospels report → enters Jerusalem on Palm Sunday and shares the Last Supper → is betrayed, tried before the Sanhedrin and Pilate, and crucified at Golgotha → and, the Gospels proclaim, rises on the third day — the foundation of Christian faith.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🕊️</div><h4>The Kingdom of God</h4><p>Preached a reign of God breaking into the world, calling for a change of heart.</p></div>
  <div class="ov-card"><div class="i">📜</div><h4>The Sermon and parables</h4><p>The Beatitudes and parables became foundations of Christian ethics.</p></div>
  <div class="ov-card"><div class="i">✝️</div><h4>Cross and Resurrection</h4><p>His death and the proclaimed Resurrection stand at the heart of the faith.</p></div>
  <div class="ov-card"><div class="i">🌍</div><h4>A world religion</h4><p>From a small movement in Judea grew Christianity, followed across the globe.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · The Coming</b><small> c. 4 BC – AD 27</small><p>Nativity, Nazareth, and the baptism by John.</p></div>
  <div><b>2 · The Ministry Begins</b><small> c. AD 27–28</small><p>Temptation, the twelve apostles, the Kingdom preached.</p></div>
  <div><b>3 · Teachings & Miracles</b><small> c. AD 28–29</small><p>The Sermon on the Mount, the parables, the miracles.</p></div>
  <div><b>4 · The Passion</b><small> c. AD 30/33</small><p>Palm Sunday, the Last Supper, betrayal and trial.</p></div>
  <div><b>5 · Death & Resurrection</b><small> c. AD 30/33</small><p>The Crucifixion, the Resurrection, and after.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: an abstract diagram of the sequence, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references. Where the Gospel account and historical scholarship differ, this guide notes both evenly.</p>
"""

WHO = [
    {'name': 'John the Baptist', 'role': 'the forerunner', 'color': '#78350f',
     'bio': 'The prophet who called Israel to repentance and baptised Jesus in the river Jordan, preparing the way for his ministry.',
     'rel': 'The forerunner who baptised him and heralded his coming.'},
    {'name': 'Mary', 'role': 'his mother', 'color': '#3730a3',
     'bio': 'The mother of Jesus, present from the Nativity through the ministry to the foot of the cross; deeply venerated in Christian tradition.',
     'rel': 'His mother, present from the birth to the Crucifixion.'},
    {'name': 'Simon Peter', 'role': 'chief apostle', 'color': '#166534',
     'bio': 'A Galilean fisherman called to follow Jesus, foremost of the twelve apostles, who denied Jesus at his trial yet became a leader of the early Church.',
     'rel': 'The foremost apostle and later a pillar of the Church.'},
    {'name': 'Judas Iscariot', 'role': 'the betrayer', 'color': '#b91c1c',
     'bio': 'One of the twelve apostles who, the Gospels record, betrayed Jesus to the authorities with a kiss in the garden of Gethsemane.',
     'rel': 'The apostle who betrayed him to arrest.'},
    {'name': 'Pontius Pilate', 'role': 'Roman governor', 'color': '#475569',
     'bio': 'The Roman prefect of Judea before whom Jesus was tried; the Gospels record that he hesitated but ultimately sentenced Jesus to crucifixion.',
     'rel': 'The governor who condemned him to the cross.'},
]

KEY_EVENTS = [
    ('c. 4 BC', 'Birth in Bethlehem', 'Born to Mary and Joseph; raised in Nazareth.'),
    ('c. AD 27', 'Baptism by John', 'Baptised in the Jordan; the ministry begins.'),
    ('c. AD 27', 'The twelve apostles', 'Calls fishermen and others to follow him.'),
    ('c. AD 28', 'Sermon on the Mount', 'The Beatitudes and his ethical teaching.'),
    ('c. AD 28–29', 'Parables and miracles', 'Teaching in stories; the signs the Gospels report.'),
    ('c. AD 30/33', 'Entry into Jerusalem', 'Palm Sunday opens Holy Week.'),
    ('c. AD 30/33', 'The Last Supper', 'Bread and wine; betrayal foretold.'),
    ('c. AD 30/33', 'Crucifixion at Golgotha', 'Tried before Pilate; died on the cross.'),
    ('c. AD 30/33', 'The Resurrection', 'The empty tomb; foundation of the faith.'),
]

MASTER = [
    {'year': 'c. 4 BC', 'age': 'infancy', 'phase': 'The Coming', 'title': 'Born in Bethlehem', 'desc': 'Raised in Nazareth in Galilee.'},
    {'year': 'c. AD 27', 'age': '~age 30', 'phase': 'The Ministry Begins', 'title': 'Baptism by John', 'desc': 'The public ministry opens.'},
    {'year': 'c. AD 28', 'age': 'the ministry', 'phase': 'Teachings & Miracles', 'title': 'Sermon on the Mount', 'desc': 'The Beatitudes and parables.'},
    {'year': 'c. AD 30/33', 'age': 'Palm Sunday', 'phase': 'The Passion', 'title': 'Entry into Jerusalem', 'desc': 'Holy Week begins.'},
    {'year': 'c. AD 30/33', 'age': 'Good Friday', 'phase': 'Death & Resurrection', 'title': 'Crucifixion', 'desc': 'Condemned by Pilate; died at Golgotha.'},
    {'year': 'c. AD 30/33', 'age': 'the third day', 'phase': 'Death & Resurrection', 'title': 'The Resurrection', 'desc': 'The empty tomb; Easter.'},
]

SOURCES = [
    ('Britannica — Jesus', 'https://www.britannica.com/biography/Jesus'),
    ('World History Encyclopedia — The Life of Jesus of Nazareth in the Gospels', 'https://www.worldhistory.org/article/633/the-life-of-jesus-of-nazareth-in-the-gospels/'),
    ('Britannica — Sermon on the Mount', 'https://www.britannica.com/topic/Sermon-on-the-Mount'),
    ('Wikipedia — Jesus', 'https://en.wikipedia.org/wiki/Jesus'),
    ('Wikipedia — Historical Jesus', 'https://en.wikipedia.org/wiki/Historical_Jesus'),
]

def build_meta():
    return {
        'pid': 'gm-jesus.html', 'kind': 'man', 'emoji': '✝️', 'accent': AC,
        'name': 'Jesus Christ', 'years': 'c. 4 BC – c. 30 AD', 'group': 'Religious Founders',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The central figure of Christianity — a first-century Jewish teacher from Galilee whom Christians revere as the Son of God and risen Lord, whose life, teachings, death and resurrection are recounted in the Gospels.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'coming', 'label': '1 · The Coming', 'type': 'timeline',
             'intro': 'The Gospels recount the Nativity in Bethlehem and the upbringing in Nazareth, and the baptism by John the Baptist that opens the public ministry.', 'events': PHASE_COMING},
            {'id': 'ministry', 'label': '2 · The Ministry Begins', 'type': 'timeline',
             'intro': 'Tested in the wilderness, Jesus calls the twelve apostles and proclaims across Galilee that the Kingdom of God is at hand.', 'events': PHASE_MINISTRY},
            {'id': 'teachings', 'label': '3 · Teachings & Miracles', 'type': 'timeline',
             'intro': 'The Sermon on the Mount and the Beatitudes, teaching in parables, and the miracles the Gospels report as signs of the Kingdom.', 'events': PHASE_TEACHINGS},
            {'id': 'passion', 'label': '4 · The Passion', 'type': 'timeline',
             'intro': 'The entry into Jerusalem on Palm Sunday, the Last Supper, and the betrayal, arrest and trials before the Sanhedrin and Pontius Pilate.', 'events': PHASE_PASSION},
            {'id': 'resurrection', 'label': '5 · Death & Resurrection', 'type': 'timeline',
             'intro': 'The Crucifixion at Golgotha and the Resurrection the Gospels proclaim — with a neutral note on how historical scholarship views the same life.', 'events': PHASE_RESURRECTION,
             'sources': SOURCES, 'srcnote': 'Drawn from the Gospel accounts and standard encyclopaedic and scholarly sources. Where the Gospel narrative and historical-Jesus scholarship differ, both are noted evenly; this guide does not adjudicate truth claims of faith.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
