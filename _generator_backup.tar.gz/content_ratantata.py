# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Ratan Tata.
The soft-spoken industrialist who globalised the Tata Group and married bold capitalism to conscience."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#1e40af'  # Tata corporate blue

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — FORMATION
PHASE_FORMATION = [
    E('origins', '1937', 'Born into the House of Tata', ['RISE', 'ORIGINS'],
      'Ratan Naval Tata is born on 28 December 1937 in Bombay into the Tata family, the Parsi industrial dynasty founded by Jamsetji Tata — but his parents separate when he is about ten, and he is raised largely by his grandmother Navajbai, growing up privileged yet notably private and reserved.',
      svg_row('A dynasty’s child, an unshowy boy', [
          {'n': 1, 'label': 'Born in Bombay, 28 Dec 1937', 'sub': 'into the Parsi house of Tata', 'color': '#1e40af'},
          {'n': 2, 'label': 'Parents separate; raised by grandmother', 'sub': 'Navajbai Tata brings him up', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Heir to a founding vision', 'sub': 'Jamsetji Tata’s legacy of nation-building', 'color': '#166534'},
      ], edge_labels=['then', 'yet'], takeaway='Born to great name and wealth, he grew up reserved and self-contained — an unlikely showman for a business empire.', accent=AC),
      bg='<b>Ratan Naval Tata</b> was born on 28 December 1937 in Bombay (Mumbai) into the <b>Tata family</b>, the Parsi dynasty whose group was founded by Jamsetji Tata in the 19th century.',
      people='his father <b>Naval Tata</b>; his grandmother <b>Navajbai Tata</b>, who raised him after his parents separated; the towering forebear <b>Jamsetji Tata</b>.',
      what='Ratan was born into <b>immense industrial pedigree</b>, but his parents’ separation when he was around ten left him raised largely by his grandmother, and he grew up <b>shy, private and reserved</b> rather than to the manner of a tycoon.',
      crux='His inheritance was <b>a name and a duty</b> more than a guaranteed throne — the Tata group was controlled by charitable trusts, not owned as personal wealth.',
      conseq='He entered adulthood with a strong sense of stewardship and a temperament far removed from the flamboyant business barons of his age.',
      matters='Character is often forged in early loss — the reticent boy became a leader who led by quiet conviction rather than swagger.'),

    E('cornell', '1955–1962', 'Cornell, and a degree in architecture', ['RISE', 'IDEAS'],
      'Sent to the United States, Ratan Tata studies at Cornell University and takes a degree in architecture in 1962 — not business — a training in structure, proportion and design that he would later credit for shaping how he thought about problems, and he even considers staying on in America.',
      svg_stack('An architect, not an MBA', [
          {'n': 1, 'label': 'Schooling in the US, then Cornell', 'sub': 'leaves India for an American education', 'color': '#7c3aed'},
          {'n': 2, 'label': 'B.S. in architecture, 1962', 'sub': 'design and structure, not commerce', 'color': '#1e40af'},
          {'n': 3, 'label': 'A designer’s eye for business', 'sub': 'he credits it for how he saw problems', 'color': '#166534'},
      ], takeaway='He came to industry through architecture — a designer’s instinct for structure that later shaped a car, a company and a group.', accent=AC),
      bg='Ratan Tata finished high school in the US and enrolled at <b>Cornell University</b>, choosing to study architecture rather than the business or engineering expected of an industrial heir.',
      people='the Cornell faculty who trained him; his family in India expecting his return; the American employers he briefly worked for.',
      what='He earned a <b>Bachelor of Science in architecture from Cornell in 1962</b>, worked briefly in the US, and seriously considered building a life there before family duty called him home.',
      crux='His formation was <b>aesthetic and structural</b>, not managerial — a way of thinking about form, function and design he applied to enterprise.',
      conseq='He returned to India in 1962 to join the family group, closing off the American life he had imagined.',
      matters='Unconventional training breeds unconventional leaders — an architect’s eye would one day imagine a car for the masses and a global group.'),

    E('shopfloor', '1962', 'On the shop floor at Jamshedpur', ['RISE', 'REFORM'],
      'Rather than start in a boardroom, Ratan Tata joins the group in 1962 on the shop floor of Tata Steel at Jamshedpur — shovelling limestone and working the blast furnaces alongside ordinary workmen — a hands-on apprenticeship that grounds the heir in the realities of heavy industry and labour.',
      svg_row('The heir who started at the furnace', [
          {'n': 1, 'label': 'Joins Tata Group, 1962', 'sub': 'no boardroom shortcut for the heir', 'color': '#1e40af'},
          {'n': 2, 'label': 'Shop floor at Tata Steel, Jamshedpur', 'sub': 'blast furnaces and limestone', 'color': '#b45309'},
          {'n': 3, 'label': 'Learns industry from the ground up', 'sub': 'alongside ordinary workmen', 'color': '#166534'},
      ], edge_labels=['to', 'so'], takeaway='He earned his place from the factory floor up — the founder’s heir learning steel with a shovel in his hands.', accent=AC),
      bg='On returning to India in 1962, Ratan Tata began his career not as an executive but on the <b>shop floor of Tata Steel (then TISCO) at Jamshedpur</b>.',
      people='the Jamshedpur steelworkers he laboured beside; the plant managers who trained him; his uncle <b>J.R.D. Tata</b>, then chairman.',
      what='He worked <b>hands-on in the steel plant</b> — famously shovelling limestone and handling the blast furnaces — learning heavy industry and factory labour from the bottom.',
      crux='The group insisted its heir <b>earn credibility through graft</b>, not inherit authority — grounding him in the plant, not the boardroom.',
      conseq='This grounding gave him a lifelong feel for manufacturing and for workers that shaped his later leadership.',
      matters='Legitimacy is built, not bestowed — starting at the furnace taught him the business he would one day command.'),

    E('nelco', '1971–1970s', 'The Nelco struggle — a hard schooling', ['DEFEAT', 'REFORM'],
      'In 1971 Ratan Tata is handed the ailing National Radio & Electronics Company (Nelco) — an electronics maker bleeding money — and he engineers a genuine turnaround, only to watch it undone by a wider economic slump and union unrest, a bruising early lesson in the limits of a manager amid India’s stifling licence-permit Raj.',
      svg_stack('A turnaround the economy undid', [
          {'n': 1, 'label': 'Given ailing Nelco, 1971', 'sub': 'a loss-making consumer-electronics firm', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Engineers a real turnaround', 'sub': 'market share and results improve', 'color': '#166534'},
          {'n': 3, 'label': 'Undone by slump and unrest', 'sub': 'recession and union troubles sink it', 'color': '#b91c1c'},
      ], takeaway='His first big command ended in defeat he could not control — a hard, formative lesson in a hobbled economy.', accent=AC),
      bg='In 1971 Ratan Tata was made director-in-charge of <b>National Radio & Electronics Company (Nelco)</b>, a struggling Tata electronics business.',
      people='the Nelco workforce and unions; the group leadership watching his performance; consumers in a closed, licence-bound economy.',
      what='He <b>turned Nelco around for a time</b>, improving its position, but a broad <b>economic downturn and labour unrest</b> reversed the gains and the venture ultimately foundered.',
      crux='The failure was largely <b>structural, not personal</b> — India’s licence-permit Raj and recession left even a capable manager little room.',
      conseq='Nelco marked him within the group as a serious operator despite the setback, and taught him hard lessons about scale and reform.',
      matters='Early failure can school a leader better than easy success — Nelco showed him how a closed economy strangled ambition.'),
]

# ==================================================================  PHASE 2 — TAKING COMMAND
PHASE_COMMAND = [
    E('industries', '1981', 'Chairman of Tata Industries', ['RISE', 'POLITICS'],
      'In 1981 J.R.D. Tata appoints Ratan as chairman of Tata Industries, the group’s incubator arm, and asks him to turn it into a vehicle for new high-technology ventures — a signal that the reserved nephew, not one of the group’s famous chieftains, is being groomed to lead the whole empire one day.',
      svg_row('Anointed as heir apparent', [
          {'n': 1, 'label': 'Chairman, Tata Industries, 1981', 'sub': 'the group’s strategy and incubator arm', 'color': '#1e40af'},
          {'n': 2, 'label': 'Tasked with high-tech ventures', 'sub': 'a mandate to modernise the group', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Marked as JRD’s successor', 'sub': 'grooming for the top job', 'color': '#166534'},
      ], edge_labels=['to', 'so'], takeaway='JRD placed him where the group’s future would be built — a quiet signal that Ratan would inherit the chair.', accent=AC),
      bg='By 1981 Ratan Tata had proven himself across several group companies, and chairman <b>J.R.D. Tata</b> chose him to lead Tata Industries.',
      people='<b>J.R.D. Tata</b>, the long-serving chairman and mentor; the group’s powerful company heads eyeing the succession.',
      what='He became <b>chairman of Tata Industries in 1981</b>, charged with steering the group into <b>new high-technology businesses</b> and shaping its strategy.',
      crux='The appointment was a <b>succession signal</b> — JRD backing his reserved nephew over more flamboyant contenders.',
      conseq='It set up his elevation a decade later to the chairmanship of the whole group, amid resistance from entrenched chiefs.',
      matters='Successions are decided long before they are announced — 1981 was the moment Ratan’s path to the top was set.'),

    E('chairman91', '1991', 'Succeeding J.R.D. as chairman', ['TRIUMPH', 'TURNING POINT'],
      'In 1991 — the very year India begins dismantling the licence Raj and opening its economy — Ratan Tata succeeds his uncle J.R.D. Tata as chairman of Tata Sons, the holding company at the group’s apex, inheriting a sprawling, loosely federated empire just as liberalisation transforms the rules of Indian business.',
      svg_stack('The right man for a new India', [
          {'n': 1, 'label': 'Succeeds J.R.D. Tata, 1991', 'sub': 'chairman of Tata Sons, the group’s apex', 'color': '#1e40af'},
          {'n': 2, 'label': 'India opens its economy', 'sub': 'liberalisation ends the licence Raj', 'color': '#b45309'},
          {'n': 3, 'label': 'A loose empire to remake', 'sub': 'dozens of firms, semi-independent chiefs', 'color': '#7c3aed'},
      ], takeaway='He took the chair at the hinge of history — as India opened up, he had to turn a sprawling federation into a modern group.', accent=AC),
      bg='In 1991 <b>J.R.D. Tata</b> stepped down after decades at the helm, naming Ratan Tata chairman of <b>Tata Sons</b> — the same year India launched sweeping economic liberalisation.',
      people='<b>J.R.D. Tata</b>, handing over the group; the reforming finance minister <b>Manmohan Singh</b>, whose 1991 reforms reshaped the landscape; sceptical group veterans.',
      what='Ratan became <b>chairman of Tata Sons in 1991</b>, taking control of a group of dozens of companies just as India <b>opened to competition and foreign capital</b>.',
      crux='He arrived at a <b>pivotal moment</b> — the old protected economy was ending, and the group had to become globally competitive or fall behind.',
      conseq='His first task was to assert control over a fragmented empire run by powerful, semi-autonomous company bosses.',
      matters='Timing shapes legacies — Ratan’s chairmanship coincided exactly with the liberalisation that made his global ambitions possible.'),

    E('satraps', '1991–1993', 'Reining in the satraps', ['POLITICS', 'REFORM', 'TURNING POINT'],
      'To govern the group at all, Ratan Tata must break the power of the "satraps" — the long-entrenched chieftains who ran flagship companies as personal fiefs — and he wields a new retirement-age rule to ease out titans like Russi Mody at Tata Steel, Darbari Seth at Tata Chemicals, and Ajit Kerkar at the Taj hotels, centralising authority in the group office.',
      svg_compare('Two ideas of what "Tata" meant', {
          'head': 'The satraps’ order', 'color': '#b91c1c',
          'items': ['Companies run as personal fiefdoms', 'Chiefs answerable to no one', 'Loose federation, weak centre', 'Loyalty to the man, not the group'],
      }, {
          'head': 'Ratan’s centralised group', 'color': '#1e40af',
          'items': ['A retirement age eases out the titans', 'Companies report to the group office', 'One coherent Tata strategy and brand', 'Loyalty to the group and its trusts'],
      }, verdict='He replaced a federation of barons with a unified group under a single strategy and brand.',
         takeaway='Before he could globalise Tata, he had to make it one company — and that meant ending the age of the satraps.', accent=AC),
      bg='On taking charge, Ratan inherited flagship companies run by <b>powerful, long-serving chieftains</b> — the "satraps" — who operated with great independence.',
      people='<b>Russi Mody</b> of Tata Steel, <b>Darbari Seth</b> of Tata Chemicals and Tata Tea, and <b>Ajit Kerkar</b> of the Taj hotels (Indian Hotels) — the chiefs he eased out.',
      what='Using a newly enforced <b>retirement age</b> and a rule that companies report to the group office, he <b>removed or sidelined the satraps</b> in the early 1990s and centralised control.',
      crux='He grasped that a global Tata was impossible while flagships were <b>personal fiefdoms</b> — unity of command had to come first.',
      conseq='By the mid-1990s he had consolidated authority, unified the group under a common strategy, and could pursue group-wide ambitions.',
      matters='Reform often begins as a power struggle — Ratan’s quiet ruthlessness with the satraps was the precondition for everything that followed.'),
]

# ==================================================================  PHASE 3 — GOING GLOBAL
PHASE_GLOBAL = [
    E('tetley', '2000', 'Tetley Tea — the first global bite', ['TRIUMPH', 'REFORM'],
      'In 2000 Tata Tea buys Britain’s Tetley for about $431 million — a landmark deal in which an Indian company swallows a far larger, iconic British brand, the group’s first big overseas acquisition and the opening statement of Ratan Tata’s ambition to make Tata a genuinely global enterprise.',
      svg_row('The minnow swallows the whale', [
          {'n': 1, 'label': 'Tata Tea buys Tetley, 2000', 'sub': 'Britain’s famous tea brand, ~$431m', 'color': '#1e40af'},
          {'n': 2, 'label': 'An Indian firm buys a bigger foreign one', 'sub': 'a first for corporate India', 'color': '#b45309'},
          {'n': 3, 'label': 'The global strategy is launched', 'sub': 'a template for bigger deals to come', 'color': '#166534'},
      ], edge_labels=['so', 'and'], takeaway='A former colony’s company bought a British icon — the deal announced that Tata would grow by going global.', accent=AC),
      bg='By 2000, with the group consolidated and India open, Ratan Tata looked abroad for growth, and <b>Tata Tea</b> targeted the British tea giant <b>Tetley</b>.',
      people='the Tata Tea leadership executing the deal; Tetley’s British owners and brand; Ratan Tata driving the global vision.',
      what='In <b>2000 Tata Tea acquired Tetley for around $431 million</b> — then a striking case of an Indian company buying a larger, iconic Western brand.',
      crux='It proved that an <b>Indian group could buy and run a global brand</b>, shattering old assumptions about who acquired whom.',
      conseq='Tetley became the springboard for a decade of ever-bigger overseas acquisitions under Ratan Tata.',
      matters='Symbolism can matter as much as economics — a former colony’s firm buying a British institution reset expectations for Indian business.'),

    E('tcs', '2004', 'The Tata Consultancy Services IPO', ['TRIUMPH', 'POLITICS'],
      'In 2004 Tata takes its crown jewel public: the Tata Consultancy Services (TCS) IPO, then India’s largest, floats the software giant that would become the group’s profit engine and one of the world’s biggest IT-services firms — a masterstroke that funds Ratan Tata’s global ambitions and anchors the group’s finances.',
      svg_stack('Floating the crown jewel', [
          {'n': 1, 'label': 'TCS goes public, 2004', 'sub': 'then India’s largest IPO', 'color': '#1e40af'},
          {'n': 2, 'label': 'A global IT-services giant', 'sub': 'the group’s biggest profit engine', 'color': '#166534'},
          {'n': 3, 'label': 'War chest for global growth', 'sub': 'value that underwrites bold deals', 'color': '#b45309'},
      ], takeaway='Listing TCS turned a software arm into the group’s financial backbone — the engine that funded everything else.', accent=AC),
      bg='<b>Tata Consultancy Services</b>, founded in 1968, had grown into a vast software and services business, and in 2004 the group listed it on the market.',
      people='the TCS leadership; investors in India’s then-largest IPO; Ratan Tata, whose global plans the listing helped underwrite.',
      what='The <b>2004 TCS IPO</b> was <b>India’s largest at the time</b>, unlocking huge value and making TCS the group’s dominant earner and a global IT powerhouse.',
      crux='TCS became the <b>cash engine of the group</b> — its profits underpinning the finances behind Ratan Tata’s acquisitions.',
      conseq='TCS grew into one of the world’s largest IT-services companies and the most valuable Tata business.',
      matters='Great strategies need a paymaster — TCS gave Ratan Tata the financial firepower for his global ambitions.'),

    E('corus', '2007', 'Corus — the $12 billion steel gamble', ['TRIUMPH', 'BATTLE'],
      'In 2007 Tata Steel wins a fierce bidding war to buy the Anglo-Dutch steelmaker Corus for around $12 billion — the largest overseas acquisition by an Indian company to that point — vaulting Tata Steel into the world’s top rank of steelmakers, though the vast debt taken on would weigh heavily as global steel prices later slumped.',
      svg_row('A record deal, a heavy bet', [
          {'n': 1, 'label': 'Tata Steel buys Corus, 2007', 'sub': 'Anglo-Dutch steelmaker, ~$12bn', 'color': '#1e40af'},
          {'n': 2, 'label': 'Wins a fierce bidding war', 'sub': 'beats Brazil’s CSN for control', 'color': '#b45309'},
          {'n': 3, 'label': 'A top-tier global steelmaker', 'sub': 'but a mountain of debt', 'color': '#b91c1c'},
      ], edge_labels=['after', 'yet'], takeaway='The biggest Indian overseas deal of its day made Tata Steel a global giant — and saddled it with costly debt.', accent=AC),
      bg='Seeking global scale in steel, Tata Steel pursued <b>Corus</b>, the Anglo-Dutch giant formed from British Steel and Hoogovens.',
      people='Ratan Tata and the Tata Steel leadership; the rival bidder <b>CSN</b> of Brazil; Corus’s European workforce and management.',
      what='In <b>2007 Tata Steel acquired Corus for around $12 billion</b> after a bidding war, the <b>largest foreign takeover by an Indian firm</b> at the time.',
      crux='It made Tata Steel a <b>top-five global steelmaker overnight</b> — but the <b>heavy debt</b> became a burden when steel markets weakened.',
      conseq='The deal globalised Tata Steel yet strained its balance sheet, and the European operations later proved a persistent challenge.',
      matters='Ambition carries risk — Corus showed both the reach and the peril of Ratan Tata’s debt-funded global expansion.'),

    E('jlr', '2008', 'Jaguar Land Rover — reviving British icons', ['TRIUMPH', 'TURNING POINT'],
      'In 2008 Tata Motors buys the storied British marques Jaguar and Land Rover from Ford for about $2.3 billion — a deal derided by sceptics amid a looming global crisis, yet which Ratan Tata turns into a triumph, as JLR is revived into a profit powerhouse that comes to underpin Tata Motors’ fortunes.',
      svg_stack('A doubted deal that became a triumph', [
          {'n': 1, 'label': 'Tata Motors buys JLR, 2008', 'sub': 'Jaguar and Land Rover from Ford, ~$2.3bn', 'color': '#1e40af'},
          {'n': 2, 'label': 'Bought on the eve of a crisis', 'sub': 'sceptics call it reckless', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Revived into a profit engine', 'sub': 'JLR turns around and thrives', 'color': '#166534'},
      ], takeaway='He bought two ailing British icons just before the crash — and turned them into the jewel of Tata Motors.', accent=AC),
      bg='In 2008 <b>Ford</b>, retrenching in a weakening economy, put its loss-making luxury marques <b>Jaguar and Land Rover</b> up for sale.',
      people='Ratan Tata and Tata Motors; <b>Ford</b>, the seller; JLR’s British engineers and workforce; doubting analysts.',
      what='<b>Tata Motors acquired Jaguar Land Rover for about $2.3 billion in 2008</b>; despite the timing on the brink of the financial crisis, JLR was <b>turned around into a hugely profitable business</b>.',
      crux='Ratan Tata backed <b>brand heritage and long-term investment</b> where others saw only losses — and was vindicated.',
      conseq='JLR became a cornerstone of Tata Motors’ profits and a symbol of Indian industry reviving Western icons.',
      matters='Conviction against the crowd defines great dealmakers — JLR is the clearest case of Ratan Tata’s judgement paying off.'),
]

# ==================================================================  PHASE 4 — VISION AND CRISIS
PHASE_CRISIS = [
    E('nano', '2008–2009', 'The Tata Nano — the people’s car', ['REFORM', 'DEFEAT'],
      'Ratan Tata’s most personal project is the Tata Nano — a car meant to cost about one lakh rupees (~$2,000) so ordinary Indian families could trade a scooter for a safe, enclosed vehicle — unveiled in 2008 and launched in 2009; a bold feat of frugal engineering that wins the world’s admiration yet stumbles commercially, undone by safety scares and its "cheapest car" image.',
      svg_row('A noble idea the market resisted', [
          {'n': 1, 'label': 'Unveiled 2008, launched 2009', 'sub': 'the ~one-lakh-rupee “people’s car”', 'color': '#1e40af'},
          {'n': 2, 'label': 'A triumph of frugal engineering', 'sub': 'a safe car to replace the family scooter', 'color': '#166534'},
          {'n': 3, 'label': 'Stumbles in the market', 'sub': 'safety fears and a “cheapest” stigma', 'color': '#b91c1c'},
      ], edge_labels=['as', 'but'], takeaway='His dearest project was a moral idea more than a market hit — the Nano won hearts but not enough buyers.', accent=AC),
      bg='Ratan Tata was moved by the sight of whole families riding on scooters, and set out to build an affordable, safe small car for them.',
      people='Ratan Tata, the project’s driving force; Tata Motors’ engineers; the aspiring middle-class families it was meant for.',
      what='The <b>Tata Nano</b>, aimed at roughly <b>one lakh rupees (~$2,000)</b>, was unveiled in 2008 and launched in 2009 as the <b>“people’s car”</b>, but <b>sold poorly</b>, hurt by early safety incidents and a low-status image.',
      crux='The very framing that made it famous — the <b>“cheapest car”</b> — deterred aspirational buyers who did not want to be seen in it.',
      conseq='Production wound down over the following years, and the Nano became a study in how a brilliant idea can fail in the market.',
      matters='Innovation is not only engineering but perception — the Nano showed that solving a problem is not the same as selling the solution.'),

    E('taj', '2008', 'The 26/11 attack on the Taj', ['TRAGEDY', 'TURNING POINT'],
      'On 26 November 2008, terrorists attack Mumbai, and the Tata-owned Taj Mahal Palace hotel becomes the searing symbol of the siege — and Ratan Tata’s response, standing with staff, caring for victims’ families, and vowing to restore the hotel, comes to define the group’s ethos of putting people and duty before profit.',
      svg_stack('Leadership defined by a tragedy', [
          {'n': 1, 'label': '26/11 attacks Mumbai, 2008', 'sub': 'the Taj hotel besieged for days', 'color': '#b91c1c'},
          {'n': 2, 'label': 'Staff shield and save guests', 'sub': 'Taj employees show extraordinary courage', 'color': '#b45309'},
          {'n': 3, 'label': 'Tata stands by his people', 'sub': 'supports families; vows to rebuild', 'color': '#1e40af'},
      ], takeaway='In the group’s darkest hour he chose people over ledgers — a response that came to embody the Tata ethos.', accent=AC),
      bg='On <b>26 November 2008</b>, coordinated terrorist attacks struck Mumbai; the historic <b>Taj Mahal Palace hotel</b>, owned by the Tata group, was a principal target.',
      people='Ratan Tata; the Taj’s staff, many of whom died protecting guests; the victims’ families the group vowed to support.',
      what='During and after the siege, Ratan Tata <b>stood with his employees</b>, ensured the group <b>supported the families of those killed</b>, and pledged to <b>restore the damaged heritage hotel</b>.',
      crux='His response embodied the group’s creed that a <b>company’s duty is to its people</b>, not just its shareholders.',
      conseq='The Taj was restored and reopened, and the episode burnished Ratan Tata’s reputation for compassionate leadership.',
      matters='Character shows in crisis — 26/11 became, for many, the defining portrait of the kind of leader Ratan Tata was.'),
]

# ==================================================================  PHASE 5 — SUCCESSION AND RETURN
PHASE_SUCCESSION = [
    E('retire12', '2012', 'Stepping down after 21 years', ['TRIUMPH', 'LEGACY'],
      'In December 2012, on his 75th birthday, Ratan Tata retires as chairman of Tata Sons after 21 years in which group revenues had multiplied more than 40 times and profits over 50 — handing over to Cyrus Mistry, of the Shapoorji Pallonji family, the largest single shareholder in Tata Sons, chosen after a long, careful succession search.',
      svg_row('A transformed group handed on', [
          {'n': 1, 'label': 'Retires December 2012', 'sub': 'after 21 years as chairman', 'color': '#1e40af'},
          {'n': 2, 'label': 'Revenue up 40×, profit up 50×', 'sub': 'a global group he remade', 'color': '#166534'},
          {'n': 3, 'label': 'Hands over to Cyrus Mistry', 'sub': 'chosen by a long succession search', 'color': '#7c3aed'},
      ], edge_labels=['having', 'to'], takeaway='He left on a high after two transformative decades — passing a globalised group to a carefully chosen heir.', accent=AC),
      bg='Reaching the group’s retirement age of 75, Ratan Tata prepared to step down at the end of 2012 after decades of expansion.',
      people='<b>Cyrus Mistry</b>, his chosen successor; the Shapoorji Pallonji family, Tata Sons’ largest shareholder; the selection committee.',
      what='He <b>retired in December 2012</b>, during which tenure <b>group revenue rose over 40-fold and profit over 50-fold</b>, and was succeeded by <b>Cyrus Mistry</b> after a careful search.',
      crux='He handed over a <b>globalised, consolidated group</b> — and vested trust in a successor from the family that held the biggest stake.',
      conseq='He took the title of chairman emeritus, expecting a clean generational handover — which would prove anything but.',
      matters='Succession is a leader’s final test — and the handover Ratan Tata designed would soon unravel into open conflict.'),

    E('mistry', '2016', 'The Mistry rupture', ['POLITICS', 'BATTLE', 'TURNING POINT'],
      'In October 2016 the Tata Sons board abruptly removes Cyrus Mistry as chairman — an unprecedented and bitter boardroom rupture. The board cited a loss of confidence in his direction; Mistry countered that he was ousted for confronting hard truths about the group’s debts and underperformers, and alleged interference. The dispute spilled into years of public litigation.',
      svg_compare('Two accounts of a bitter split', {
          'head': 'The Tata Sons board’s case', 'color': '#1e40af',
          'items': ['Lost confidence in his leadership', 'Concern over group direction', 'Board’s prerogative to change chair', 'Protecting the group’s ethos'],
      }, {
          'head': 'Cyrus Mistry’s case', 'color': '#b45309',
          'items': ['Ousted for confronting hard problems', 'Legacy debts and weak businesses', 'Alleged interference in his running', 'Removal was improper, he argued'],
      }, verdict='The board asserted its right to change the chairman; Mistry alleged an unfair, interfering removal — courts later weighed both.',
         takeaway='The succession Ratan Tata designed ended in open rupture — a clash of two accounts fought out in public and in court.', accent=AC),
      bg='By 2016 relations between <b>Cyrus Mistry</b> and the Tata Sons board — and its emeritus chairman Ratan Tata — had deteriorated over strategy, debt and control.',
      people='<b>Cyrus Mistry</b>, the ousted chairman; <b>Ratan Tata</b> and the Tata Sons board; the Shapoorji Pallonji and Tata camps.',
      what='On <b>24 October 2016 the board removed Mistry as chairman</b>; the board cited <b>lost confidence</b>, while Mistry alleged he was ousted for <b>tackling hard problems</b> and faced interference — beginning years of litigation.',
      crux='At its heart lay a <b>governance clash</b>: the board’s authority to replace a chairman versus Mistry’s claim of unfair, interfering removal.',
      conseq='The feud ran through India’s tribunals and the Supreme Court, which in 2021 ultimately upheld Mistry’s removal.',
      matters='Even the best-planned successions can fracture — the Tata–Mistry dispute became a landmark in Indian corporate governance.'),

    E('interim', '2016–2017', 'The interim return and a new chair', ['POLITICS', 'REFORM'],
      'With Mistry gone, the 78-year-old Ratan Tata steps back in as interim chairman in October 2016 to steady the group through the crisis, before a search committee names Natarajan Chandrasekaran — the head of TCS — as chairman in January 2017, the first professional from outside the founding families to lead the group in that role.',
      svg_stack('Steadying the ship, then handing over', [
          {'n': 1, 'label': 'Ratan Tata returns, Oct 2016', 'sub': 'interim chairman amid the crisis', 'color': '#1e40af'},
          {'n': 2, 'label': 'A search for a lasting successor', 'sub': 'stabilise, then choose carefully', 'color': '#7c3aed'},
          {'n': 3, 'label': 'N. Chandrasekaran named, Jan 2017', 'sub': 'the TCS chief takes the chair', 'color': '#166534'},
      ], takeaway='He returned to hold the group steady, then handed it to a professional insider — an orderly close to a turbulent chapter.', accent=AC),
      bg='After Mistry’s removal, the group needed steady hands, and Ratan Tata agreed to serve as interim chairman while a successor was found.',
      people='<b>Ratan Tata</b>, back as interim chairman; <b>N. Chandrasekaran</b>, the TCS chief who succeeded him; the selection committee.',
      what='Ratan Tata returned as <b>interim chairman in October 2016</b>, and in <b>January 2017 Natarajan Chandrasekaran</b>, then head of TCS, was named chairman of Tata Sons.',
      crux='The choice signalled a shift to <b>professional leadership</b> — a respected insider rather than a family scion or outside financier.',
      conseq='Chandrasekaran took charge in 2017, and Ratan Tata stepped back to his role as chairman emeritus and philanthropist.',
      matters='Institutions outlast individuals — Ratan Tata’s final act as leader was to secure a stable, professional succession at last.'),
]

# ==================================================================  PHASE 6 — PHILANTHROPY AND LEGACY
PHASE_LEGACY = [
    E('trusts', '2017–2024', 'Tata Trusts and a life of giving', ['REFORM', 'LEGACY'],
      'In his later years Ratan Tata devotes himself to the Tata Trusts — the philanthropic bodies that own around 66% of Tata Sons, so that the group’s profits flow back to charity — funding health, education, rural development and research, and becoming, in retirement, as admired for his giving and his mentoring of start-ups as for his dealmaking.',
      svg_row('A group owned by its conscience', [
          {'n': 1, 'label': 'Chairs the Tata Trusts', 'sub': 'philanthropy at the group’s core', 'color': '#1e40af'},
          {'n': 2, 'label': 'Trusts own ~66% of Tata Sons', 'sub': 'profits flow back to charity', 'color': '#166534'},
          {'n': 3, 'label': 'Health, education, research', 'sub': 'and a mentor to young start-ups', 'color': '#7c3aed'},
      ], edge_labels=['where', 'funding'], takeaway='The group’s ownership itself is charitable — Ratan Tata’s later life turned that structure into a mission of giving.', accent=AC),
      bg='Uniquely among big business houses, the Tata group is controlled by <b>charitable trusts</b>, and in later life Ratan Tata led that philanthropic mission.',
      people='the beneficiaries of Tata Trusts programmes; the start-up founders he mentored and backed; the group he still guided as emeritus.',
      what='The <b>Tata Trusts own roughly 66% of Tata Sons</b>, channelling group profits into <b>health, education, rural development and research</b>; Ratan Tata also became a noted <b>mentor and investor in Indian start-ups</b>.',
      crux='The structure means <b>the group works, in large part, for charity</b> — a model of capitalism yoked to social purpose.',
      conseq='His philanthropy and support for young entrepreneurs cemented his standing as India’s most trusted and admired businessman.',
      matters='Wealth can be held in trust for a nation — the Tata model, and Ratan Tata’s stewardship of it, made giving the point of the enterprise.'),

    E('death', '2024', 'Death and a nation’s mourning', ['DEATH', 'LEGACY'],
      'Ratan Tata dies on 9 October 2024 in Mumbai at the age of 86 — mourned across India as few businessmen ever are, honoured with a state funeral and remembered not merely as the man who globalised the Tata Group but as a rare industrialist trusted for his integrity, humility and conscience.',
      svg_stack('A nation mourns an industrialist', [
          {'n': 1, 'label': 'Dies 9 October 2024, Mumbai', 'sub': 'aged 86, after age-related illness', 'color': '#111827'},
          {'n': 2, 'label': 'Mourned across India', 'sub': 'honoured with a state funeral', 'color': '#b45309'},
          {'n': 3, 'label': 'Remembered for conscience', 'sub': 'integrity and humility, not just deals', 'color': '#1e40af'},
      ], takeaway='He was mourned as a moral figure as much as a magnate — proof that how one builds is remembered, not only what.', accent=AC),
      bg='After years as chairman emeritus and philanthropist, Ratan Tata’s health declined, and he died in a Mumbai hospital in October 2024.',
      people='the millions of Indians who mourned him; the Tata group he had transformed; the leaders and public who paid tribute.',
      what='He <b>died on 9 October 2024, aged 86</b>, and was <b>honoured with a state funeral</b>, mourned nationwide as a beloved figure far beyond the business world.',
      crux='The scale of the grief reflected that he was trusted for his <b>integrity and humility</b> as much as admired for his success.',
      conseq='He left a globalised group and a template of ethical, purpose-driven capitalism as his legacy.',
      matters='Reputation is the final ledger — Ratan Tata was mourned less as a tycoon than as a conscience for Indian business.'),

    E('legacy', '2024–', 'The Tata way — capitalism with a conscience', ['LEGACY', 'TRIUMPH'],
      'Ratan Tata’s enduring legacy is a model as much as an empire: a globalised group spanning steel, cars, software, salt and hospitality, married to a conviction that business must serve the nation and the poor — leaving him revered as the industrialist who proved that ambition and integrity need not be at odds.',
      svg_row('Ambition married to integrity', [
          {'n': 1, 'label': 'A truly global Tata Group', 'sub': 'from Tetley to Corus to JLR', 'color': '#1e40af'},
          {'n': 2, 'label': 'Business as national service', 'sub': 'profit yoked to social purpose', 'color': '#166534'},
          {'n': 3, 'label': 'A model, not just an empire', 'sub': 'the trusted face of Indian industry', 'color': '#7c3aed'},
      ], edge_labels=['plus', 'equals'], takeaway='He leaves both a global conglomerate and a creed — that capitalism can be built on conscience.', accent=AC),
      bg='Ratan Tata’s career spanned India’s transformation from a closed economy to a global player, and the Tata group both drove and embodied that change.',
      people='the generations of Indians who take him as a model; the group and trusts that carry on his work; the entrepreneurs he inspired.',
      what='He is remembered for <b>globalising the Tata Group</b> across steel, autos, IT and hospitality while insisting that <b>enterprise serve society</b> — a fusion of scale and ethics.',
      crux='His legacy is the belief that <b>ambition and integrity can coexist</b> — that a business can be both world-class and principled.',
      conseq='He remains the most trusted and revered figure in Indian business, a benchmark for ethical leadership.',
      matters='Legacies are measured in values as well as valuations — Ratan Tata is remembered as the conscience of Indian capitalism.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Ratan Tata was the soft-spoken industrialist who globalised the Tata Group and, in doing so, redefined what an Indian company could be. Born into the Parsi dynasty founded by Jamsetji Tata but raised largely by his grandmother, he trained as an architect at Cornell, started on the shop floor at Tata Steel, and took the group’s chair in 1991 just as India opened its economy. He reined in the group’s powerful chieftains, then bought Tetley, Corus and Jaguar Land Rover to make Tata a global name — all while insisting that business serve the nation. He is the ultimate study in <b>ambition married to conscience.</b></p>
<div class="ov-quote">“I don’t believe in taking right decisions. I take decisions and then make them right.”<span>— Ratan Tata</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born into the House of Tata and trained as an architect → starts on the shop floor and is bruised by the Nelco struggle → succeeds J.R.D. as chairman in 1991 and breaks the power of the satraps → goes global with Tetley, TCS, Corus and Jaguar Land Rover → dreams up the Nano and shows his soul in the 26/11 crisis → retires in 2012 into the bitter Mistry succession and an interim return → and devotes his last years to the Tata Trusts before his death in 2024.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🌍</div><h4>A global Indian group</h4><p>Tetley, Corus and JLR turned Tata into a world enterprise.</p></div>
  <div class="ov-card"><div class="i">🤝</div><h4>Capitalism with conscience</h4><p>Charitable trusts own ~66% of Tata Sons; profit serves society.</p></div>
  <div class="ov-card"><div class="i">🚗</div><h4>The people’s car</h4><p>The Nano dared to imagine a safe car for every family.</p></div>
  <div class="ov-card"><div class="i">🕊️</div><h4>Integrity under fire</h4><p>His 26/11 response defined leadership by care, not profit.</p></div>
</div>
<div class="ov-lbl">The six chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Formation</b><small> 1937–1970s</small><p>Birth, Cornell, the shop floor, and the Nelco struggle.</p></div>
  <div><b>2 · Taking Command</b><small> 1981–1993</small><p>Heir apparent, chairman in 1991, and breaking the satraps.</p></div>
  <div><b>3 · Going Global</b><small> 2000–2008</small><p>Tetley, the TCS IPO, Corus and Jaguar Land Rover.</p></div>
  <div><b>4 · Vision &amp; Crisis</b><small> 2008</small><p>The Nano dream and the 26/11 attack on the Taj.</p></div>
  <div><b>5 · Succession</b><small> 2012–2017</small><p>Retirement, the Mistry rupture, and the interim return.</p></div>
  <div><b>6 · Legacy</b><small> 2017–</small><p>The Tata Trusts, his death, and the Tata way.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'J.R.D. Tata', 'role': 'predecessor & mentor', 'color': '#1e40af',
     'bio': 'The legendary chairman of Tata Sons for over half a century who groomed Ratan and handed him the group in 1991.',
     'rel': 'His uncle, mentor and predecessor as chairman.'},
    {'name': 'Cyrus Mistry', 'role': 'chosen successor', 'color': '#b45309',
     'bio': 'Of the Shapoorji Pallonji family, Tata Sons’ largest shareholder; chosen to succeed Ratan in 2012 and removed in a bitter dispute in 2016.',
     'rel': 'His successor as chairman, and later his adversary in a public feud.'},
    {'name': 'N. Chandrasekaran', 'role': 'later chairman', 'color': '#166534',
     'bio': 'The head of TCS who became the first professional from outside the founding families to chair Tata Sons, taking over in January 2017.',
     'rel': 'The professional leader who succeeded him after the interim return.'},
    {'name': 'The satraps', 'role': 'entrenched chiefs', 'color': '#b91c1c',
     'bio': 'Powerful company heads — Russi Mody, Darbari Seth, Ajit Kerkar — who ran Tata flagships as fiefs until Ratan centralised control.',
     'rel': 'The barons he eased out to unify the group in the early 1990s.'},
    {'name': 'Jamsetji Tata', 'role': 'founder', 'color': '#7c3aed',
     'bio': 'The 19th-century founder of the Tata group whose vision of industry as nation-building set the ethos Ratan carried forward.',
     'rel': 'The founding forebear whose legacy Ratan inherited and honoured.'},
]

KEY_EVENTS = [
    ('1937', 'Ratan Tata born', 'Into the Parsi house of Tata in Bombay.'),
    ('1962', 'Cornell architecture degree', 'Returns to start on the shop floor.'),
    ('1971', 'Given ailing Nelco', 'A bruising early lesson in a closed economy.'),
    ('1991', 'Chairman of Tata Sons', 'Succeeds J.R.D. as India liberalises.'),
    ('1991–93', 'Breaks the satraps', 'Centralises a fragmented empire.'),
    ('2000', 'Tetley acquisition', 'First big global bite, ~$431m.'),
    ('2004', 'TCS IPO', 'India’s largest; the group’s profit engine.'),
    ('2007', 'Corus, ~$12bn', 'Largest Indian overseas deal of its day.'),
    ('2008', 'Jaguar Land Rover', 'A doubted deal turned triumph.'),
    ('2008–09', 'Tata Nano', 'The people’s car; a market disappointment.'),
    ('2008', '26/11 Taj attack', 'His response defines the Tata ethos.'),
    ('2012', 'Retires as chairman', 'Hands over to Cyrus Mistry.'),
    ('2016', 'Mistry removed', 'A bitter, unprecedented boardroom rupture.'),
    ('2017', 'Chandrasekaran named', 'Interim return ends; a new chairman.'),
    ('2024', 'Death at 86', 'A nation mourns; a state funeral.'),
]

MASTER = [
    {'year': '1937', 'age': 'born', 'phase': 'Formation', 'title': 'Born in Bombay', 'desc': 'Into the House of Tata.'},
    {'year': '1962', 'age': 'age 24', 'phase': 'Formation', 'title': 'Cornell & shop floor', 'desc': 'Architecture degree; joins Tata Steel.'},
    {'year': '1991', 'age': 'age 53', 'phase': 'Taking Command', 'title': 'Chairman of Tata Sons', 'desc': 'Succeeds J.R.D. amid liberalisation.'},
    {'year': '2000', 'age': 'age 62', 'phase': 'Going Global', 'title': 'Tetley bought', 'desc': 'The global strategy begins.'},
    {'year': '2007', 'age': 'age 69', 'phase': 'Going Global', 'title': 'Corus, ~$12bn', 'desc': 'Tata Steel goes world-scale.'},
    {'year': '2008', 'age': 'age 70', 'phase': 'Vision & Crisis', 'title': 'JLR, Nano & 26/11', 'desc': 'Triumph, dream and tragedy.'},
    {'year': '2012', 'age': 'age 75', 'phase': 'Succession', 'title': 'Retires as chairman', 'desc': 'Hands over to Cyrus Mistry.'},
    {'year': '2016', 'age': 'age 78', 'phase': 'Succession', 'title': 'Mistry rupture', 'desc': 'Removal and interim return.'},
    {'year': '2024', 'age': 'age 86', 'phase': 'Legacy', 'title': 'Death in Mumbai', 'desc': 'A nation mourns an industrialist.'},
]

SOURCES = [
    ('Britannica — Ratan Tata', 'https://www.britannica.com/money/Ratan-Tata'),
    ('Wikipedia — Ratan Tata', 'https://en.wikipedia.org/wiki/Ratan_Tata'),
    ('Tata group — Ratan Naval Tata', 'https://www.tata.com/about-us/tata-group-our-heritage/tata-titans/ratan-naval-tata'),
    ('Reuters — Ratan Tata, who put India’s Tata group on the global map, dies at 86', 'https://www.reuters.com/world/india/ratan-tata-chairman-emeritus-tata-sons-dies-86-2024-10-09/'),
    ('Forbes India — How Ratan Tata took the group international', 'https://www.forbesindia.com/article/news/land-rover-to-tetley-to-corushow-ratan-tata-took-the-group-international/94357/1'),
    ('The Week — Why was Cyrus Mistry ousted as Tata Sons chairman in 2016?', 'https://www.theweek.in/news/biz-tech/2019/12/18/replug-why-was-cyrus-mistry-ousted-as-tata-sons-chairman-2016.html'),
]

def build_meta():
    return {
        'pid': 'gm-ratantata.html', 'kind': 'man', 'emoji': '🚗', 'accent': AC,
        'name': 'Ratan Tata', 'years': '1937–2024', 'group': 'Business & Industry',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The soft-spoken industrialist who globalised the Tata Group — buying Tetley, Corus and Jaguar Land Rover — while insisting that business serve the nation, becoming the trusted conscience of Indian capitalism.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'formation', 'label': '1 · Formation', 'type': 'timeline',
             'intro': 'Born into the Parsi house of Tata but raised largely by his grandmother, he trains as an architect at Cornell, starts on the shop floor at Jamshedpur, and is bruised by the Nelco struggle.', 'events': PHASE_FORMATION},
            {'id': 'command', 'label': '2 · Taking Command', 'type': 'timeline',
             'intro': 'Marked as heir in 1981, he succeeds J.R.D. as chairman in 1991 just as India liberalises — then breaks the power of the satraps to unify a fragmented empire.', 'events': PHASE_COMMAND},
            {'id': 'global', 'label': '3 · Going Global', 'type': 'timeline',
             'intro': 'With the group consolidated, he goes global — Tetley, the record TCS IPO, the $12 billion Corus deal, and the doubted-then-triumphant Jaguar Land Rover.', 'events': PHASE_GLOBAL},
            {'id': 'crisis', 'label': '4 · Vision & Crisis', 'type': 'timeline',
             'intro': 'The same year brings his dearest dream and his darkest hour — the Nano “people’s car” and the 26/11 attack on the Taj that revealed the leader he was.', 'events': PHASE_CRISIS},
            {'id': 'succession', 'label': '5 · Succession', 'type': 'timeline',
             'intro': 'He retires in 2012 into a succession that unravels — the bitter removal of Cyrus Mistry, his own interim return, and a new professional chairman.', 'events': PHASE_SUCCESSION},
            {'id': 'legacy', 'label': '6 · Legacy', 'type': 'timeline',
             'intro': 'His last years belong to the Tata Trusts and his philanthropy — until his death in 2024, mourned as the conscience of Indian business.', 'events': PHASE_LEGACY,
             'sources': SOURCES, 'srcnote': 'Standard biographies, encyclopaedic and news sources. The Tata–Mistry dispute is presented even-handedly; India’s Supreme Court ultimately upheld Mistry’s removal in 2021.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
