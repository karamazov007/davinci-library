# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Marco Polo.
The Venetian whose 24-year journey to Kublai Khan's China gave Europe its picture of the East."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#b45309'  # Venetian amber

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — VENICE
PHASE_RISE = [
    E('venice', '1254–1269', 'A merchant’s son in the queen of the seas', ['RISE'],
      'Marco Polo is born into Venice, the richest trading republic of medieval Europe — a city whose wealth flows from the East — while his own father and uncle are already far away on the Silk Road, so that the boy grows up in the world’s greatest marketplace with the East in his blood.',
      svg_row('Born into the crossroads of trade', [
          {'n': 1, 'label': 'Venice, c. 1254', 'sub': 'medieval Europe’s richest trading republic', 'color': '#b45309'},
          {'n': 2, 'label': 'A family of merchants', 'sub': 'father Niccolò and uncle Maffeo trade to the East', 'color': '#a16207'},
          {'n': 3, 'label': 'The East in his blood', 'sub': 'raised where Europe met Asia’s goods and stories', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='He was born at the meeting point of Europe and Asia — a merchant world that made his journey almost destiny.', accent=AC),
      bg='<b>Marco Polo</b> was born around 1254 in <b>Venice</b>, the dominant maritime trading power of medieval Europe, whose fortune came from commerce with the East.',
      people='his father <b>Niccolò Polo</b> and uncle <b>Maffeo Polo</b>, merchants already traveling east; the Venetian trading world.',
      what='Marco grew up in <b>Venice</b> — a city of merchants and the gateway of Eastern goods into Europe — while his father and uncle were away on a long trading journey that would reach the court of the Mongol emperor.',
      crux='He was shaped by a <b>commercial civilisation oriented toward the East</b>, primed from birth for the journey of his life.',
      conseq='When his father returned with tales of the Great Khan, the young Marco was ready to follow.',
      matters='Environment shapes destiny — a boy raised in the world’s great marketplace was born to travel its farthest roads.'),

    E('fatherjourney', '1260–1269', 'The Great Khan’s invitation', ['POLITICS', 'TURNING POINT'],
      'Marco’s father and uncle, trading ever eastward, reach the court of Kublai Khan himself — the Mongol emperor of China — who, curious about Europe, sends them home as his envoys with a request to the Pope for a hundred learned men and holy oil from Jerusalem, an invitation that will draw the whole family back to the East.',
      svg_stack('An emperor’s curiosity opens the road', [
          {'n': 1, 'label': 'The Polos reach Kublai Khan', 'sub': 'trading east, they arrive at the Mongol court', 'color': '#b45309'},
          {'n': 2, 'label': 'Kublai’s request', 'sub': 'asks for 100 scholars and holy oil from Jerusalem', 'color': '#a16207'},
          {'n': 3, 'label': 'A return journey beckons', 'sub': 'they go home as the Khan’s envoys — and will go back', 'color': '#166534'},
      ], takeaway='An emperor’s curiosity about the West created the opening that Marco would follow across the world.', accent=AC),
      bg='By the 1260s the Mongol Empire spanned Asia, and <b>Kublai Khan</b> ruled China. Niccolò and Maffeo Polo’s trading took them all the way to his court.',
      people='<b>Kublai Khan</b>, emperor of the Mongols and of China; <b>Niccolò and Maffeo</b>, his new European envoys; the Pope they were to petition.',
      what='Kublai Khan, curious about Christendom, sent the Polos home as <b>envoys</b> with a request to the Pope for <b>a hundred learned men and holy oil from Jerusalem</b>. Returning to Venice, they found the young Marco — and prepared to go back east.',
      crux='The journey was made possible by <b>Mongol openness and the Pax Mongolica</b> that made the Silk Road safe to travel end to end.',
      conseq='In 1271 the Polos set out again — this time with the teenage Marco.',
      matters='Great journeys often begin with an invitation across cultures — curiosity opening a road that trade and courage then travel.'),
]

# ==================================================================  PHASE 2 — THE JOURNEY
PHASE_JOURNEY = [
    E('departure', '1271', 'Setting out at seventeen', ['RISE', 'TURNING POINT'],
      'In 1271 the seventeen-year-old Marco leaves Venice with his father and uncle, carrying letters from the new Pope and holy oil from Jerusalem, to begin one of the longest and most famous journeys in history — an overland trek of thousands of miles toward the court of the Great Khan.',
      svg_row('The start of an epic journey', [
          {'n': 1, 'label': 'Leaves Venice, 1271', 'sub': 'Marco, 17, with father and uncle', 'color': '#b45309'},
          {'n': 2, 'label': 'The Pope’s letters, holy oil', 'sub': 'gifts and messages for Kublai Khan', 'color': '#a16207'},
          {'n': 3, 'label': 'Toward the Great Khan', 'sub': 'a trek of thousands of miles begins', 'color': '#166534'},
      ], edge_labels=['with', 'toward'], takeaway='A teenager set out on a journey to the ends of the known world — and would not see home again for 24 years.', accent=AC),
      bg='In 1271, having secured letters from the newly elected Pope, the three Polos departed Venice for the court of Kublai Khan.',
      people='the teenage <b>Marco</b>; his father and uncle; the new Pope, whose letters they carried.',
      what='At <b>17, Marco set out in 1271</b> with Niccolò and Maffeo, carrying the Pope’s letters and holy oil, on the vast overland journey to China.',
      crux='He committed, as a boy, to a journey of <b>staggering length and danger</b> — years across deserts and mountains to an unknown empire.',
      conseq='The journey east would take some three and a half years.',
      matters='The greatest adventures demand a leap into the unknown — Marco took his as a teenager, and it defined his life.'),

    E('silkroad', '1271–1275', 'The Silk Road — deserts, mountains and years', ['BATTLE', 'RISE'],
      'For three and a half years the Polos travel the Silk Road — crossing Persia, the towering Pamir mountains, and the deadly Gobi desert — an epic of endurance through lands few Europeans had ever seen, which Marco stores up in a memory that will later astonish Europe.',
      svg_stack('Crossing a continent on foot and horse', [
          {'n': 1, 'label': 'Through Persia and beyond', 'sub': 'the ancient overland trade route east', 'color': '#b45309'},
          {'n': 2, 'label': 'The Pamir mountains', 'sub': 'the “roof of the world,” high and desolate', 'color': '#a16207'},
          {'n': 3, 'label': 'The Gobi desert', 'sub': 'a deadly crossing of sand and emptiness', 'color': '#78350f'},
      ], takeaway='He endured years of the harshest travel on earth — and observed everything, storing a continent in his memory.', accent=AC),
      bg='The <b>Silk Road</b> stretched thousands of miles across Asia. Under the Mongol peace, it was traversable end to end, though brutally hard.',
      people='the caravans and peoples of the route; Marco, absorbing the lands, cities and customs he passed through.',
      what='Over about <b>three and a half years</b> the Polos crossed <b>Persia, the Pamir mountains and the Gobi desert</b>, passing through lands almost unknown to Europeans — all of which Marco later described in vivid detail.',
      crux='He combined <b>endurance with acute observation</b> — surviving the journey while recording a world Europe had never seen.',
      conseq='At last, around 1275, they reached the court of Kublai Khan.',
      matters='The great chronicler is first a great observer — Marco’s gift was to see, remember, and later tell.'),

    E('arrival', '1275', 'Arrival at the court of Kublai Khan', ['POLITICS', 'TRIUMPH', 'TURNING POINT'],
      'The Polos finally reach the magnificent court of Kublai Khan at his summer capital, Shangdu — the fabled Xanadu — and the emperor takes a particular liking to the young, observant, quick-witted Marco, drawing him into his service as a trusted foreign official.',
      svg_row('Welcomed by the Great Khan', [
          {'n': 1, 'label': 'Reach Shangdu (Xanadu), c. 1275', 'sub': 'Kublai’s magnificent summer capital', 'color': '#b45309'},
          {'n': 2, 'label': 'Kublai favours young Marco', 'sub': 'charmed by his wit and powers of observation', 'color': '#a16207'},
          {'n': 3, 'label': 'Drawn into imperial service', 'sub': 'the Venetian becomes the Khan’s trusted man', 'color': '#166534'},
      ], edge_labels=['then', 'so'], takeaway='The observant young foreigner won the emperor’s favour — opening the whole Mongol world to him.', accent=AC),
      bg='Around 1275 the Polos arrived at <b>Kublai Khan’s</b> court. The emperor, ruler of the largest realm on earth, welcomed the returning envoys.',
      people='<b>Kublai Khan</b>, emperor of the Mongols and China; the young <b>Marco</b>, who caught his eye.',
      what='The Polos reached <b>Shangdu (Xanadu)</b>, Kublai’s summer capital. The Khan was <b>drawn to the young Marco</b> — his curiosity, memory and gift for observation — and took him into <b>imperial service</b>.',
      crux='Marco’s personal qualities won him a place at the <b>heart of the greatest empire on earth</b>, an extraordinary position for a foreigner.',
      conseq='For the next seventeen years Marco would serve Kublai and travel his vast empire.',
      matters='Access to power often turns on personal qualities — Marco’s curiosity and memory made a Venetian teenager the Khan’s trusted man.'),
]

# ==================================================================  PHASE 3 — IN THE SERVICE OF THE KHAN
PHASE_SERVICE = [
    E('service', '1275–1291', 'Seventeen years serving the Great Khan', ['POLITICS', 'REFORM'],
      'For nearly two decades Marco serves Kublai Khan as a trusted official and envoy — sent on missions across the vast empire, from the Chinese heartland to Burma and beyond — a unique vantage point from which a European saw the workings of the mightiest state on earth.',
      svg_stack('A European inside the Mongol machine', [
          {'n': 1, 'label': 'Trusted foreign official', 'sub': 'serves the Khan for ~17 years', 'color': '#b45309'},
          {'n': 2, 'label': 'Missions across the empire', 'sub': 'sent far and wide as the Khan’s envoy', 'color': '#a16207'},
          {'n': 3, 'label': 'Sees the state from within', 'sub': 'observes the administration of a continent', 'color': '#166534'},
      ], takeaway='He didn’t just visit China — he served inside its government, seeing the empire as few outsiders ever could.', accent=AC),
      bg='Kublai employed capable foreigners in his administration. Marco, fluent in several languages and endlessly observant, became a useful servant of the Khan.',
      people='<b>Kublai Khan</b>; the officials and peoples of the Mongol-ruled empire; Marco, traveling on the Khan’s business.',
      what='For about <b>seventeen years</b> Marco served Kublai as an <b>official and envoy</b>, sent on <b>missions across the empire</b> (by his account even administering a city), observing its government, wealth and customs from the inside.',
      crux='He gained a <b>unique inside view</b> of the greatest empire on earth — not a passing traveler but a servant of its ruler.',
      conseq='The knowledge he gathered would become the substance of the most influential travel book in history.',
      matters='The deepest understanding comes from within — Marco saw the East not as a tourist but as a participant in its rule.'),

    E('wonders', '1275–1291', 'Wonders that Europe would not believe', ['REFORM', 'TRIUMPH'],
      'Marco witnesses marvels unknown to Europe — paper money accepted as if it were gold, black stones (coal) that burn for heat, a vast imperial postal relay that speeds messages across the empire, and cities of a size no European had imagined — reporting them so faithfully that many at home simply refused to believe him.',
      svg_row('The marvels of the East', [
          {'n': 1, 'label': 'Paper money', 'sub': 'the Khan’s paper currency, accepted as gold', 'color': '#b45309'},
          {'n': 2, 'label': 'Coal — “stones that burn”', 'sub': 'black rocks used for fuel, unknown in Europe', 'color': '#a16207'},
          {'n': 3, 'label': 'The imperial postal relay', 'sub': 'the yam — messages speeding across a continent', 'color': '#166534'},
      ], edge_labels=['plus', 'plus'], takeaway='He reported a civilisation so advanced that Europe thought he was lying — much of it later proved true.', accent=AC),
      bg='Kublai’s China was in many ways far more advanced than medieval Europe — in commerce, technology and administration.',
      people='the Chinese and Mongol subjects of Kublai; the European readers who would doubt Marco’s reports.',
      what='Marco described <b>paper money</b>, <b>coal</b> (“black stones that burn”), the vast <b>imperial postal relay (yam)</b>, the Grand Canal, and cities of astonishing size and wealth — marvels so far beyond European experience that many <b>refused to believe</b> him.',
      crux='He faithfully reported a <b>more advanced civilisation</b> than his readers could imagine — and paid the price in disbelief.',
      conseq='Much of what seemed fantastical was later confirmed, vindicating his account.',
      matters='The honest reporter of an unfamiliar world is often disbelieved — reality can outrun the imagination of those who have not seen it.'),

    E('hangzhou', '1275–1291', 'Hangzhou — “the finest city in the world”', ['REFORM', 'TRIUMPH'],
      'Of all the wonders Marco sees, none impresses him more than the great southern city of Hangzhou — which he calls Kinsai and declares the finest and noblest city in the world, a metropolis of canals, bridges, markets and perhaps a million people, dwarfing anything in Europe.',
      svg_stack('A city beyond European imagining', [
          {'n': 1, 'label': 'Hangzhou (Kinsai)', 'sub': 'the great city of southern China', 'color': '#b45309'},
          {'n': 2, 'label': 'Canals, bridges, vast markets', 'sub': 'a metropolis of perhaps a million people', 'color': '#a16207'},
          {'n': 3, 'label': '“The finest city in the world”', 'sub': 'dwarfing anything Marco knew in Europe', 'color': '#166534'},
      ], takeaway='He found a city so vast and refined that it redefined, for Europe, what a city could be.', accent=AC),
      bg='<b>Hangzhou</b>, capital of the former Song dynasty, was one of the largest and most sophisticated cities on earth in the 13th century.',
      people='the million inhabitants of Hangzhou; the merchants and officials Marco observed there.',
      what='Marco described <b>Hangzhou (Kinsai)</b> as <b>“the finest and noblest city in the world”</b> — a metropolis of countless <b>canals, bridges and markets</b> and perhaps a million people, incomparably larger and richer than any European city.',
      crux='He conveyed the <b>scale and refinement of Chinese urban civilisation</b>, expanding Europe’s sense of what was possible.',
      conseq='His descriptions of such cities fired the European imagination about the wealth of the East.',
      matters='Encountering a greater civilisation can enlarge a whole culture’s horizons — Marco brought the scale of China home to Europe.'),
]

# ==================================================================  PHASE 4 — THE RETURN
PHASE_RETURN = [
    E('return', '1291–1295', 'The long way home — escorting a princess', ['BATTLE', 'TURNING POINT'],
      'After seventeen years, the Polos win the Khan’s leave to return home — given the task of escorting a Mongol princess by sea to Persia, a perilous two-year voyage of shipwreck and death — and finally reach Venice in 1295 after twenty-four years away, so changed that their own relatives barely recognize them.',
      svg_stack('A perilous voyage back to Venice', [
          {'n': 1, 'label': 'Escort a princess to Persia', 'sub': 'the price of the Khan’s leave to depart', 'color': '#b45309'},
          {'n': 2, 'label': 'A deadly sea voyage', 'sub': 'shipwreck and disease claim most of the party', 'color': '#78350f'},
          {'n': 3, 'label': 'Venice, 1295 — 24 years away', 'sub': 'they return so changed few recognise them', 'color': '#166534'},
      ], takeaway='Even the journey home was an epic — and they returned to Venice as near-strangers after a quarter-century.', accent=AC),
      bg='After nearly two decades, the aging Kublai reluctantly granted the Polos leave — on condition they escort a <b>Mongol princess</b> by sea to marry a Persian ruler.',
      people='the Mongol princess; the ships’ crews, most of whom died en route; the Venetian relatives who barely knew the returning Polos.',
      what='The Polos escorted the princess on a <b>perilous two-year sea voyage</b> to Persia (most of the large party died), then made their way to <b>Venice, arriving in 1295</b> after 24 years — reportedly so altered that relatives scarcely recognised them.',
      crux='Their return completed one of the <b>longest journeys ever recorded</b> — a quarter-century that transformed them into strangers at home.',
      conseq='Back in Venice, Marco resumed a merchant’s life — until war gave his story to the world.',
      matters='The greatest journeys change the traveler as much as the map — Marco came home a different man from a different world.'),

    E('curzola', '1298', 'Captured in war — a prison that made a book', ['BATTLE', 'TURNING POINT', 'TRAGEDY'],
      'Soon after his return, Marco is caught up in Venice’s war with rival Genoa, captured at the naval Battle of Curzola, and thrown into a Genoese prison — where fate places him beside a writer of romances, Rustichello of Pisa, who will turn Marco’s memories into a book.',
      svg_row('War, capture, and a fateful cellmate', [
          {'n': 1, 'label': 'Venice vs Genoa', 'sub': 'the rival republics at war', 'color': '#b45309'},
          {'n': 2, 'label': 'Captured at Curzola, 1298', 'sub': 'Marco taken in a naval battle', 'color': '#78350f'},
          {'n': 3, 'label': 'A writer for a cellmate', 'sub': 'imprisoned beside Rustichello of Pisa', 'color': '#166534'},
      ], edge_labels=['then', 'and'], takeaway='Capture and prison — a disaster — gave Marco the one thing he needed: time, and a writer to record his tale.', accent=AC),
      bg='Venice and <b>Genoa</b> were fierce commercial rivals. Marco, back home, took part in the war and was captured at the <b>Battle of Curzola (1298)</b>.',
      people='the Genoese captors; <b>Rustichello of Pisa</b>, a writer of chivalric romances, imprisoned with Marco.',
      what='Marco was <b>captured and imprisoned in Genoa</b>, where he shared a cell with <b>Rustichello of Pisa</b> — to whom, to pass the time, he dictated the story of his travels.',
      crux='A <b>misfortune became the making of his fame</b> — prison gave him the leisure, and a collaborator, to set down his tale.',
      conseq='The result was one of the most influential books ever written.',
      matters='Fortune turns on chance encounters — a war, a prison and a cellmate gave the world Marco’s book.'),
]

# ==================================================================  PHASE 5 — THE BOOK
PHASE_BOOK = [
    E('book', '1298–1300', 'The Travels — the book that opened the East', ['REFORM', 'TRIUMPH', 'TURNING POINT'],
      'From Marco’s dictation, Rustichello writes The Description of the World — soon nicknamed Il Milione — a book that gives medieval Europe its first detailed picture of China and the East, and becomes a sensation, even as many readers dismiss its wonders as tall tales.',
      svg_stack('A book that redrew Europe’s map of the world', [
          {'n': 1, 'label': 'Dictated to Rustichello', 'sub': 'Marco’s memories, written up in prison', 'color': '#b45309'},
          {'n': 2, 'label': '“The Description of the World”', 'sub': 'Europe’s first detailed account of China', 'color': '#a16207'},
          {'n': 3, 'label': 'Nicknamed “Il Milione”', 'sub': 'a sensation — and doubted for its “million” marvels', 'color': '#166534'},
      ], takeaway='One book gave a whole civilisation its picture of the East — believed or not, it changed the European imagination.', accent=AC),
      bg='Books were copied by hand and rare, yet Marco’s account spread widely across Europe in many languages.',
      people='<b>Rustichello of Pisa</b>, who wrote it up; the many readers who copied, translated, doubted and devoured it.',
      what='The book — <b>“The Description of the World,”</b> popularly <b>“Il Milione” (The Travels of Marco Polo)</b> — gave Europe its <b>first detailed account of China</b> and the East. It was a sensation, though its marvels led many to dismiss it as exaggeration.',
      crux='He gave Europe a <b>vast new picture of the world</b> — the wealth, scale and sophistication of a civilisation it had barely imagined.',
      conseq='The book shaped European ideas of Asia for centuries and inspired the age of exploration.',
      matters='A single account can reshape a civilisation’s view of the world — Marco’s East became Europe’s dream and destination.'),

    E('legacy', '1300–1324', 'Death — and the map of the world’s imagination', ['DEATH', 'TURNING POINT'],
      'Marco is freed, returns to Venice, marries and lives out his days as a merchant, dying in 1324 — but his book lives on, inspiring the explorers who will one day seek the riches he described, including Columbus, who carries a heavily annotated copy on his voyage west, chasing Marco’s Cathay and finding a new world.',
      svg_row('The traveler who moved history', [
          {'n': 1, 'label': 'Dies in Venice, 1324', 'sub': 'a merchant to the end; “I did not tell half of what I saw”', 'color': '#b45309'},
          {'n': 2, 'label': 'The book endures', 'sub': 'copied and read across Europe for centuries', 'color': '#a16207'},
          {'n': 3, 'label': 'Inspires the explorers', 'sub': 'Columbus carried an annotated copy west', 'color': '#166534'},
      ], edge_labels=['yet', 'and'], takeaway='He died a merchant, but his book launched the search for the East that discovered a new world.', accent=AC),
      bg='Released from prison, Marco returned to Venice, married and traded, dying in 1324. His book, meanwhile, spread across Europe.',
      people='<b>Christopher Columbus</b>, who owned an annotated copy; generations of explorers and readers; the historians who still debate his accuracy.',
      what='Marco <b>died in 1324</b>, reportedly saying he had <b>“not told half of what I saw.”</b> His book inspired the Age of Exploration — <b>Columbus carried a heavily annotated copy</b> as he sailed west seeking Marco’s Cathay, and found the Americas.',
      crux='His account <b>fired the European imagination</b> toward the wealth of the East — a hunger that launched the voyages that remade the world.',
      conseq='Debate continues over how much he saw first-hand, but his book’s influence on history is beyond dispute.',
      matters='Ideas travel further than their authors — Marco never sailed west, yet his book helped launch the discovery of a new world.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Marco Polo was the Venetian merchant whose 24-year journey to the court of Kublai Khan gave medieval Europe its first detailed picture of China and the East. He crossed the Silk Road as a teenager, served the Great Khan for seventeen years, and saw wonders — paper money, coal, vast cities — that his countrymen refused to believe. Captured in war on his return, he dictated his travels into a book that became a sensation and, generations later, helped launch the Age of Exploration. He is the ultimate study in <b>the traveler as bridge between worlds, the power of observation, and how a single account can reshape a civilisation’s imagination.</b></p>
<div class="ov-quote">“I did not tell half of what I saw.”<span>— attributed to Marco Polo on his deathbed</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">A merchant’s son of Venice → his father and uncle reach Kublai Khan and return as his envoys → Marco sets out at 17 in 1271 → crosses Persia, the Pamirs and the Gobi over 3.5 years → reaches Kublai’s court and wins his favour → serves the Khan for 17 years, seeing paper money, coal, and the vast cities of China → returns to Venice in 1295 after 24 years → is captured by Genoa and, in prison, dictates his Travels → and the book opens the East to Europe, inspiring the explorers who would seek it.</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🧭</div><h4>Bridge between worlds</h4><p>Gave Europe its first detailed knowledge of China and the East.</p></div>
  <div class="ov-card"><div class="i">👁️</div><h4>The great observer</h4><p>Reported paper money, coal and vast cities — much of it disbelieved, then confirmed.</p></div>
  <div class="ov-card"><div class="i">📖</div><h4>The book that endured</h4><p>His Travels shaped Europe’s picture of Asia for centuries.</p></div>
  <div class="ov-card"><div class="i">⛵</div><h4>Sparked exploration</h4><p>Columbus carried his book west, chasing Cathay and finding a new world.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Venice</b><small> 1254–1269</small><p>A merchant’s son, and the Khan’s invitation.</p></div>
  <div><b>2 · The Journey</b><small> 1271–1275</small><p>The Silk Road to Kublai Khan.</p></div>
  <div><b>3 · Serving the Khan</b><small> 1275–1291</small><p>Seventeen years, and wonders Europe doubted.</p></div>
  <div><b>4 · The Return</b><small> 1291–1298</small><p>The long voyage home, and a Genoese prison.</p></div>
  <div><b>5 · The Book</b><small> 1298–1324</small><p>The Travels, and the East opened to Europe.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references.</p>
"""

WHO = [
    {'name': 'Kublai Khan', 'role': 'the Great Khan', 'color': '#a16207',
     'bio': 'The Mongol emperor and ruler of China who welcomed the Polos, took the young Marco into his service for seventeen years, and whose empire Marco described to Europe.',
     'rel': 'The emperor who opened his empire to Marco.'},
    {'name': 'Niccolò Polo', 'role': 'father', 'color': '#b45309',
     'bio': 'Marco’s father, a Venetian merchant whose first journey east reached Kublai Khan and set the stage for the family’s epic return with Marco.',
     'rel': 'The father whose trade first opened the road east.'},
    {'name': 'Maffeo Polo', 'role': 'uncle', 'color': '#166534',
     'bio': 'Marco’s uncle and Niccolò’s brother, his companion on both journeys to the court of the Great Khan.',
     'rel': 'The uncle who travelled the whole journey with him.'},
    {'name': 'Rustichello of Pisa', 'role': 'co-author', 'color': '#78350f',
     'bio': 'A writer of chivalric romances imprisoned with Marco in Genoa, who wrote down Marco’s dictated account as The Description of the World.',
     'rel': 'The cellmate who turned Marco’s memories into a book.'},
    {'name': 'Christopher Columbus', 'role': 'later reader', 'color': '#3730a3',
     'bio': 'The explorer who owned a heavily annotated copy of Marco’s Travels and sailed west seeking the Cathay it described, instead reaching the Americas.',
     'rel': 'The explorer his book helped send across the ocean.'},
]

KEY_EVENTS = [
    ('c.1254', 'Marco Polo born', 'In the trading republic of Venice.'),
    ('1271', 'Sets out east at 17', 'With his father and uncle.'),
    ('1271–75', 'Crosses the Silk Road', 'Persia, the Pamirs, the Gobi.'),
    ('c.1275', 'Reaches Kublai Khan', 'Welcomed at Shangdu (Xanadu).'),
    ('1275–91', 'Serves the Great Khan', 'Missions across the empire.'),
    ('1295', 'Returns to Venice', 'After 24 years away.'),
    ('1298', 'Captured by Genoa', 'Imprisoned after Curzola.'),
    ('c.1298–1300', 'Dictates his Travels', 'To Rustichello of Pisa.'),
    ('1324', 'Death of Marco Polo', 'His book opens the East to Europe.'),
]

MASTER = [
    {'year': 'c.1254', 'age': 'born', 'phase': 'Venice', 'title': 'Born in Venice', 'desc': 'A merchant’s son.'},
    {'year': '1271', 'age': 'age 17', 'phase': 'The Journey', 'title': 'Sets out east', 'desc': 'The great journey begins.'},
    {'year': '1275', 'age': 'age 21', 'phase': 'Serving the Khan', 'title': 'Reaches Kublai', 'desc': 'Enters his service.'},
    {'year': '1295', 'age': 'age 41', 'phase': 'The Return', 'title': 'Home to Venice', 'desc': '24 years away.'},
    {'year': '1298', 'age': 'age 44', 'phase': 'The Book', 'title': 'Prison in Genoa', 'desc': 'Dictates his Travels.'},
    {'year': '1324', 'age': 'age ~70', 'phase': 'The Book', 'title': 'Death', 'desc': 'His book endures.'},
]

SOURCES = [
    ('Britannica — Marco Polo', 'https://www.britannica.com/biography/Marco-Polo'),
    ('World History Encyclopedia — Marco Polo', 'https://www.worldhistory.org/Marco_Polo/'),
    ('Britannica — The Travels of Marco Polo', 'https://www.britannica.com/topic/The-Travels-of-Marco-Polo'),
    ('World History Encyclopedia — Kublai Khan', 'https://www.worldhistory.org/Kublai_Khan/'),
    ('Wikipedia — Marco Polo', 'https://en.wikipedia.org/wiki/Marco_Polo'),
]

def build_meta():
    return {
        'pid': 'gm-marcopolo.html', 'kind': 'man', 'emoji': '🧭', 'accent': AC,
        'name': 'Marco Polo', 'years': 'c. 1254–1324', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The Venetian merchant whose 24-year journey to Kublai Khan’s China gave Europe its first picture of the East — and whose book inspired the Age of Exploration.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'rise', 'label': '1 · Venice', 'type': 'timeline',
             'intro': 'A merchant’s son of Venice grows up at the crossroads of European trade while his father and uncle journey east — and return as envoys of Kublai Khan, with an invitation that will draw the whole family back.', 'events': PHASE_RISE},
            {'id': 'journey', 'label': '2 · The Journey', 'type': 'timeline',
             'intro': 'At seventeen Marco sets out on one of history’s longest journeys — years across Persia, the Pamir mountains and the Gobi desert — to reach the court of the Great Khan.', 'events': PHASE_JOURNEY},
            {'id': 'service', 'label': '3 · Serving the Khan', 'type': 'timeline',
             'intro': 'Kublai takes the young Venetian into his service for seventeen years, sending him across the empire — where Marco witnesses wonders, from paper money to vast cities, that Europe would refuse to believe.', 'events': PHASE_SERVICE},
            {'id': 'return', 'label': '4 · The Return', 'type': 'timeline',
             'intro': 'After 24 years the Polos win their leave and make the perilous voyage home to Venice — where Marco is soon captured in Venice’s war with Genoa and thrown into a prison that will make his name.', 'events': PHASE_RETURN},
            {'id': 'book', 'label': '5 · The Book', 'type': 'timeline',
             'intro': 'In prison Marco dictates his travels to a fellow captive, and the resulting book gives Europe its first picture of the East — inspiring, generations later, the explorers who would sail to find it.', 'events': PHASE_BOOK,
             'sources': SOURCES, 'srcnote': 'Historians debate how much Marco saw first-hand and how much his book owes to Rustichello and to hearsay; its enormous influence, however, is undisputed.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
