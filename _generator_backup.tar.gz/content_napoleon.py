# -*- coding: utf-8 -*-
"""Full, EXHAUSTIVE birth-to-death guide content for Napoleon Bonaparte.
Every major battle, campaign and pivotal decision from Corsica to St Helena."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#4338ca'  # imperial indigo

def _tk(b, W, H, text, accent=AC):
    ty = H - 30
    return b + (f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{accent}"/>'
                f'<text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(text)}</text>')

def svg_central():
    """The 'central position' — his signature method in 1796 and after."""
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">his signature move · when outnumbered, get BETWEEN the enemy armies</text>'
    b += '<rect x="40" y="70" width="150" height="52" rx="10" fill="#fdecec" stroke="#dc2626" stroke-width="1.6"/>'
    b += '<text x="115" y="92" font-size="10.5" font-weight="800" fill="#dc2626" text-anchor="middle">Enemy army A</text>'
    b += '<text x="115" y="108" font-size="9" fill="#6b7280" text-anchor="middle">(bigger, but split)</text>'
    b += '<rect x="530" y="70" width="150" height="52" rx="10" fill="#fdecec" stroke="#dc2626" stroke-width="1.6"/>'
    b += '<text x="605" y="92" font-size="10.5" font-weight="800" fill="#dc2626" text-anchor="middle">Enemy army B</text>'
    b += '<text x="605" y="108" font-size="9" fill="#6b7280" text-anchor="middle">(bigger, but split)</text>'
    b += '<rect x="290" y="66" width="140" height="60" rx="12" fill="#eef0fb" stroke="#4338ca" stroke-width="1.9"/>'
    b += '<text x="360" y="90" font-size="10.5" font-weight="800" fill="#4338ca" text-anchor="middle">Napoleon</text>'
    b += '<text x="360" y="106" font-size="9" fill="#5b6472" text-anchor="middle">between them</text>'
    b += '<line x1="290" y1="96" x2="192" y2="96" stroke="#4338ca" stroke-width="2.2" marker-end="url(#ah)"/>'
    b += '<line x1="430" y1="96" x2="528" y2="96" stroke="#4338ca" stroke-width="2.2" marker-end="url(#ah)"/>'
    b += '<text x="360" y="150" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">Hold one off with a small force; mass everything on the other and destroy it — then turn.</text>'
    b += '<text x="360" y="168" font-size="10" fill="#4338ca" font-weight="700" text-anchor="middle">Beat a bigger enemy by never letting the halves fight you together.</text>'
    return _wrap(W, H, 'The central position — divide and destroy in detail', _tk(b, W, H, 'Speed lets a smaller army be the bigger one at the point of contact.'), '', AC)

def svg_ulm():
    """The manoeuvre of Ulm — win by marching, not fighting."""
    W, H = 720, 236
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">OCT 1805 · an army captured almost without a battle</text>'
    boxes=[(40,'#4338ca','March 200,000 men fast and wide','the whole army swings around behind the Austrians'),
           (270,'#b45309','Cut Mack off from Vienna','his line of retreat & supply is severed'),
           (500,'#16a34a','Ulm surrenders (~23,000)','trapped, he capitulates almost without a fight')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="180" height="80" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,32); b+=ss
    b += '<line x1="220" y1="100" x2="268" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="100" x2="498" y2="100" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#334155" font-weight="700" text-anchor="middle">“I have destroyed the enemy merely by marches.” Legs and logistics beat swords.</text>'
    return _wrap(W, H, 'The Manoeuvre of Ulm — winning by marching', _tk(b, W, H, 'The best battle is the one you win before it starts — by manoeuvre, speed and cutting supply.'), '', AC)

def svg_austerlitz():
    W, H = 720, 300
    b = ''
    b += '<text x="20" y="46" font-size="11" fill="#94a3b8" font-weight="700">MORAVIA · 2 DEC 1805 · the Pratzen Heights (centre)</text>'
    b += '<rect x="20" y="60" width="150" height="150" rx="10" fill="#eef0fb" stroke="#4338ca" stroke-width="1.6"/>'
    b += '<text x="30" y="80" font-size="11.5" font-weight="800" fill="#4338ca">FRENCH (73k)</text>'
    b += '<text x="30" y="98" font-size="10" fill="#5b6472">Napoleon hides Soult</text><text x="30" y="112" font-size="10" fill="#5b6472">behind the centre; leaves</text><text x="30" y="126" font-size="10" fill="#5b6472">his right flank looking weak</text>'
    b += '<rect x="30" y="150" width="130" height="22" rx="6" fill="#4338ca"/><text x="40" y="165" font-size="10" fill="#fff" font-weight="700">1 · bait: weak flank</text>'
    b += '<rect x="30" y="178" width="130" height="22" rx="6" fill="#2563eb"/><text x="40" y="193" font-size="10" fill="#fff" font-weight="700">2 · Soult hidden in fog</text>'
    b += '<rect x="550" y="60" width="150" height="150" rx="10" fill="#fdecec" stroke="#dc2626" stroke-width="1.6"/>'
    b += '<text x="560" y="80" font-size="11.5" font-weight="800" fill="#dc2626">ALLIES (85k)</text>'
    b += '<text x="560" y="98" font-size="10" fill="#5b6472">Tsar Alexander I &amp;</text><text x="560" y="112" font-size="10" fill="#5b6472">Emperor Francis II push</text><text x="560" y="126" font-size="10" fill="#5b6472">south to cut Napoleon</text><text x="560" y="140" font-size="10" fill="#5b6472">from Vienna...</text>'
    b += '<rect x="560" y="150" width="130" height="22" rx="6" fill="#dc2626"/><text x="570" y="165" font-size="10" fill="#fff" font-weight="700">3 · they take the bait</text>'
    b += '<rect x="560" y="178" width="130" height="22" rx="6" fill="#b45309"/><text x="570" y="193" font-size="10" fill="#fff" font-weight="700">4 · they quit the Heights</text>'
    b += '<line x1="540" y1="120" x2="360" y2="150" stroke="#dc2626" stroke-width="2" stroke-dasharray="5 4" marker-end="url(#ah)"/>'
    b += '<text x="360" y="172" font-size="10" fill="#dc2626" font-weight="700">allied army slides south →</text>'
    b += '<rect x="300" y="95" width="130" height="34" rx="9" fill="#2563eb"/><text x="365" y="110" font-size="10.5" fill="#fff" font-weight="800" text-anchor="middle">5 · 9am: Soult</text><text x="365" y="123" font-size="10.5" fill="#fff" font-weight="800" text-anchor="middle">storms the centre</text>'
    b += '<line x1="180" y1="130" x2="298" y2="112" stroke="#2563eb" stroke-width="2.4" marker-end="url(#ah)"/>'
    b += '<line x1="365" y1="129" x2="365" y2="205" stroke="#2563eb" stroke-width="2.4" marker-end="url(#ah)"/>'
    b += '<text x="230" y="240" font-size="10.5" fill="#334155" font-weight="700">6 · the allied army is cut in two and rolled up; thousands drown on the frozen ponds fleeing.</text>'
    tk = 'Lose ground on purpose to make the enemy move — then hit the gap the move opens.'
    ty = H-30
    b += f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{AC}"/><text x="30" y="{ty+19}" font-size="12.5" font-weight="800" fill="#fff">★ {esc(tk)}</text>'
    return _wrap(W, H, 'How Austerlitz was won — the deliberate weak flank', b, '', AC)

def svg_continental():
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">BERLIN DECREE 1806 · close every European port to British trade</text>'
    nodes = [
        (60, 60, '#4338ca', 'Ban British goods', 'starve UK of markets → force peace'),
        (300, 60, '#dc2626', 'Britain adapts', 'smuggling, new markets, blockades France back'),
        (540, 60, '#b45309', 'Europe suffers', 'shortages, smashed economies, resentment'),
    ]
    for i, (x, y, c, t, s) in enumerate(nodes):
        b += f'<rect x="{x}" y="{y}" width="140" height="70" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="{y+26}" font-size="11.5" font-weight="800" fill="{c}">{i+1} · {t}</text>'
        sub, _ = _tspans(x+12, y+44, s, 9.6, '#5b6472', 500, 11, 22)
        b += sub
    b += '<line x1="200" y1="95" x2="298" y2="95" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="440" y1="95" x2="538" y2="95" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<path d="M610,130 C610,180 200,185 130,132" fill="none" stroke="#dc2626" stroke-width="1.8" stroke-dasharray="6 4" marker-end="url(#ah)"/>'
    b += '<text x="330" y="185" font-size="10" fill="#dc2626" font-weight="800" text-anchor="middle">to enforce it he must occupy the whole coast → Spain (1808) &amp; Russia (1812)</text>'
    tk = 'An economic weapon that punished his own allies more than his enemy — and forced the wars that ruined him.'
    ty = H-30
    b += f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{AC}"/><text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(tk)}</text>'
    return _wrap(W, H, 'The Continental System — the blockade that boomeranged', b, '', AC)

def svg_russia_graph():
    W, H = 720, 300
    b = '<text x="20" y="46" font-size="11" fill="#94a3b8" font-weight="700">GRANDE ARMÉE · men remaining vs. the road to Moscow and back</text>'
    b += '<line x1="60" y1="70" x2="60" y2="230" stroke="#cbd2dc" stroke-width="1.5"/>'
    b += '<line x1="60" y1="230" x2="690" y2="230" stroke="#cbd2dc" stroke-width="1.5"/>'
    b += '<text x="20" y="150" font-size="10" fill="#6b7280" transform="rotate(-90 20 150)" text-anchor="middle">men (thousands)</text>'
    b += '<path d="M60,74 C180,86 300,120 430,150" fill="none" stroke="#2563eb" stroke-width="8" stroke-linecap="round" opacity=".85"/>'
    b += '<text x="120" y="70" font-size="10" fill="#2563eb" font-weight="800">June: ~450–600k cross the Niemen</text>'
    b += '<circle cx="430" cy="150" r="6" fill="#7c3aed"/><text x="405" y="140" font-size="10" fill="#7c3aed" font-weight="800">Borodino (Sep 7): ~70k casualties</text>'
    b += '<circle cx="470" cy="162" r="6" fill="#b45309"/><text x="452" y="182" font-size="10" fill="#b45309" font-weight="800">Moscow burns — no surrender comes</text>'
    b += '<path d="M470,162 C560,196 620,214 690,224" fill="none" stroke="#dc2626" stroke-width="4" stroke-dasharray="7 4"/>'
    b += '<text x="520" y="210" font-size="10" fill="#dc2626" font-weight="800">retreat: cold, hunger, Cossacks, Berezina</text>'
    b += '<circle cx="690" cy="224" r="6" fill="#111827"/><text x="686" y="245" font-size="10.5" fill="#111827" font-weight="800" text-anchor="end">Dec: ~25,000 stumble out</text>'
    tk = 'He was never beaten in a battle — he was beaten by distance, winter, and an enemy who refused to fight for terms.'
    ty = H-30
    b += f'<rect x="16" y="{ty}" width="{W-32}" height="30" rx="8" fill="{AC}"/><text x="30" y="{ty+19}" font-size="12" font-weight="800" fill="#fff">★ {esc(tk)}</text>'
    return _wrap(W, H, 'The 1812 collapse — an army destroyed without a decisive defeat', b, '', AC)

def svg_waterloo():
    W, H = 720, 250
    b = '<text x="20" y="44" font-size="11" fill="#94a3b8" font-weight="700">18 JUN 1815 · beat the two armies separately — or lose to both together</text>'
    boxes=[(40,'#4338ca','The plan','crush Wellington before the Prussians can return'),
           (250,'#b45309','Grouchy loses the Prussians','33,000 men sent to pin Blücher — and fail'),
           (460,'#dc2626','Prussians hit the flank','evening: Blücher arrives; the Guard is repulsed')]
    for x,c,t,s in boxes:
        b += f'<rect x="{x}" y="60" width="200" height="78" rx="12" fill="#fff" stroke="{c}" stroke-width="1.8"/>'
        b += f'<text x="{x+12}" y="80" font-size="10.5" font-weight="800" fill="{c}">{t}</text>'
        ss,_=_tspans(x+12,98,s,9.3,'#5b6472',500,11,36); b+=ss
    b += '<line x1="240" y1="99" x2="248" y2="99" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<line x1="450" y1="99" x2="458" y2="99" stroke="#94a3b8" stroke-width="1.6" marker-end="url(#ah)"/>'
    b += '<text x="360" y="176" font-size="10.5" fill="#111827" font-weight="800" text-anchor="middle">“La Garde recule!” — the Guard falls back, and the army dissolves.</text>'
    return _wrap(W, H, 'Why Waterloo was lost — one broken hinge', _tk(b, W, H, 'His whole plan hung on keeping two armies apart; one failed detachment let them combine — and that was that.'), '', AC)


def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — ORIGINS
PHASE_ORIGINS = [
    E('corsica', '1769', 'Born a Corsican outsider', ['RISE'],
      'A boy of minor Italian-speaking nobility, born on an island France had annexed one year earlier — an outsider to the nation he would one day rule.',
      svg_stack('Why the outsider origin mattered', [
          {'n': 1, 'label': 'Corsica sold to France, 1768', 'sub': 'Genoa cedes the island; France annexes it just before his birth', 'color': '#64748b'},
          {'n': 2, 'label': 'Born Napoleone di Buonaparte', 'sub': 'minor Corsican nobility — Italian-speaking, not French', 'color': '#4338ca'},
          {'n': 3, 'label': 'Mocked at French schools', 'sub': 'accent, poverty, provincial name → he over-achieves to belong', 'color': '#16a34a'},
      ], takeaway='The outsider has to earn by merit what insiders inherit — and Revolution rewards exactly that.', accent=AC),
      bg='France annexed Corsica from Genoa in 1768; Napoleone was born in Ajaccio on 15 August 1769. His family, the Buonapartes, were minor nobility of Italian descent — respectable but not rich.',
      people='<b>Carlo Buonaparte</b> (father), who won French noble status and a scholarship for his son; <b>Letizia Ramolino</b> (mother), tough and frugal, whom he credited for his character.',
      what='Sent to France aged 9: military school at <b>Brienne</b>, then the <b>École Militaire</b> in Paris; commissioned a <b>second lieutenant of artillery in 1785</b> at 16.',
      crux='He chose <b>artillery</b> — the one branch open to talent over birth, demanding mathematics rather than aristocratic connections.',
      conseq='He grew up an outsider with a chip on his shoulder and a ferocious work ethic, fluent in the maths of gunnery just as France was about to need gunners.',
      matters='Greatness often starts at the margins: being an outsider forces merit, and merit was the one currency the coming Revolution would pay in.'),

    E('brienne', '1779–1785', 'Brienne and the École Militaire — the making of a gunner', ['RISE'],
      'Nine years old and shipped to a French military school where he speaks barely a word of French, the mocked Corsican boy buries himself in mathematics and history — and comes out a commissioned artillery officer at sixteen.',
      svg_stack('From mocked schoolboy to artillery officer', [
          {'n': 1, 'label': 'Brienne-le-Château, 1779', 'sub': 'a scholarship boy among aristocrats; teased for his accent and poverty — retreats into study', 'color': '#64748b'},
          {'n': 2, 'label': 'École Militaire, Paris, 1784', 'sub': 'the elite academy; races through the artillery course in a single year', 'color': '#4338ca'},
          {'n': 3, 'label': 'Second lieutenant, 1785', 'sub': 'commissioned into the La Fère regiment at 16 — mathematics, not birth, got him there', 'color': '#16a34a'},
      ], takeaway='He turned exclusion into obsessive competence — mastering the one science-based arm that birth could not monopolise.', accent=AC),
      bg='Sent to France at nine on a royal scholarship, Napoleone spent five austere years at Brienne, an isolated provincial military school, before a final year at Paris’s elite academy.',
      people='<b>Father Carlo</b>, who secured the scholarship; the instructors who marked him a cold, reserved boy gifted at maths and geography; classmates who mocked the poor Corsican.',
      what='He endured Brienne, then compressed the two-year course at the <b>École Militaire</b> into one, and was commissioned a <b>second lieutenant of artillery in 1785</b>, aged 16 — just as his father died and left the family poor.',
      crux='Artillery demanded <b>trigonometry and ballistics</b>, not a pedigree — the perfect ladder for a brilliant, penniless outsider.',
      conseq='He entered the army a trained professional gunner, reading voraciously through the lean garrison years — stockpiling knowledge for a war not yet declared.',
      matters='Elite skills acquired before anyone is watching are the capital you spend when opportunity finally arrives.'),

    E('revolution', '1789–1793', 'The Revolution opens the door', ['POLITICS', 'TURNING POINT'],
      'The Revolution guillotines the old promotion-by-birth army — and a low-born artillery officer can suddenly leap ranks that used to take a lifetime.',
      svg_row('How the Revolution rebuilt the ladder he would climb', [
          {'n': 1, 'label': 'Old regime army', 'sub': 'top ranks reserved for aristocrats by birth', 'color': '#475569'},
          {'n': 2, 'label': '1789 Revolution', 'sub': 'nobles emigrate; officer corps hollows out', 'color': '#dc2626'},
          {'n': 3, 'label': 'Careers open to talent', 'sub': 'vacancies + war = fast promotion by merit', 'color': '#16a34a'},
      ], edge_labels=['guts', 'creates'], takeaway='Revolutions destroy old ladders and build new ones — he stood at the bottom of the new one.', accent=AC),
      bg='The Revolution of 1789 abolished aristocratic privilege. As émigré nobles fled, the royal officer corps collapsed just as France went to war with half of Europe (1792).',
      people='<b>Pasquale Paoli</b>, the Corsican independence hero Napoleon first idolised then broke with in 1793, forcing his family to flee to France; the Jacobins whose patronage he courted.',
      what='Napoleon backed the Revolution and, after the split with Paoli, threw his lot fully in with France — a trained artillerist in a nation suddenly short of officers.',
      crux='The bottleneck that had capped men like him — <b>birth</b> — was gone. Talent plus a war meant promotion in months, not decades.',
      conseq='By 1793 he was a committed republican officer, family exiled from Corsica, everything staked on France — needing one chance to prove himself.',
      matters='Timing beats talent alone: he had the skills before the Revolution, but only the Revolution made them a fast track to power.'),
]

# ==================================================================  PHASE 2 — THE RISE
PHASE_RISE = [
    E('toulon', 'Dec 1793', 'The Siege of Toulon — one hill, one general', ['RISE', 'BATTLE', 'TURNING POINT'],
      'A 24-year-old captain sees what the generals miss: capture one promontory and the British fleet must leave. He does — and is made a general on the spot.',
      svg_row('Toulon: the single decisive insight', [
          {'n': 1, 'label': 'Royalists hand Toulon to Britain', 'sub': "France's main Med naval base, held by the Royal Navy", 'color': '#475569'},
          {'n': 2, 'label': 'Bonaparte spots the key point', 'sub': 'take Fort Mulgrave → guns command the harbour', 'color': '#4338ca'},
          {'n': 3, 'label': 'British fleet must evacuate', 'sub': 'ships driven out → the city falls', 'color': '#16a34a'},
      ], edge_labels=['problem', 'forces'], takeaway='Find the one point that controls everything, then throw all your force at it.', accent=AC),
      bg='In 1793 royalists and a British fleet seized <b>Toulon</b>, France’s great Mediterranean naval base. The Republic’s siege was going nowhere under conventional commanders.',
      people='<b>Paul Barras</b> and the représentants, who noticed him; <b>General Dugommier</b>, who backed his plan. The Barras connection would pay off again two years later.',
      what='As artillery commander, Napoleon argued the harbour, not the city, was everything: take the promontory fort (“Little Gibraltar” / Fort Mulgrave) and its batteries would make the anchorage untenable, forcing the British fleet out. It worked; Toulon fell.',
      crux='He redefined the objective. Everyone else attacked the city; he attacked the <b>geometry of the harbour</b> — the position whose capture made the enemy’s whole hold collapse.',
      conseq='Promoted <b>brigadier general at 24</b>. A nobody became a general in a single stroke, and gained powerful patrons.',
      matters='Leverage over effort: the decisive move is usually a position, not a frontal push. Change the objective and a hard problem becomes easy.'),

    E('thermidor', '1794–1795', 'Prison, poverty, and a lucky break', ['POLITICS'],
      'When his Jacobin patrons fall, he is briefly arrested and left jobless and broke — a reminder that in a revolution, yesterday’s patron is today’s liability. He survives, waiting for a chance.',
      svg_row('The precarious years between triumphs', [
          {'n': 1, 'label': 'Robespierre falls (Thermidor 1794)', 'sub': 'Napoleon’s Jacobin links make him suspect', 'color': '#dc2626'},
          {'n': 2, 'label': 'Arrested, then jobless & poor', 'sub': 'refuses a posting; scrapes by in Paris', 'color': '#64748b'},
          {'n': 3, 'label': 'Waits, connected, ready', 'sub': 'keeps close to Barras for the next opening', 'color': '#4338ca'},
      ], edge_labels=['then', 'so'], takeaway='In volatile times, survival means outlasting your fallen patrons and staying near the next source of power.', accent=AC),
      bg='After the fall of Robespierre (the Thermidorian Reaction, July 1794), association with the Jacobins became dangerous. Napoleon’s ties to Augustin Robespierre put him under suspicion.',
      people='<b>Paul Barras</b>, the rising Thermidorian power broker Napoleon stayed close to; the shifting factions of the new <b>Directory</b>.',
      what='Napoleon was briefly <b>arrested</b>, released, then left without a suitable command — refusing a posting to the Vendée and living in near-poverty in Paris, cultivating contacts and biding his time.',
      crux='Revolutionary politics was a game of survival: patrons rose and were guillotined in months. He learned to <b>outlast</b> the turnover and keep a line to whoever held power next.',
      conseq='His patience and proximity to Barras positioned him perfectly when the Directory suddenly, desperately needed a reliable soldier in Paris.',
      matters='Careers have lean years. Surviving them — staying connected and ready — is what lets you seize the next opening when it comes.'),

    E('vendemiaire', '5 Oct 1795', '13 Vendémiaire — the whiff of grapeshot', ['RISE', 'POLITICS', 'BATTLE'],
      'When a royalist mob marches on the government, Barras hands Napoleon the guns. He rakes the Paris streets with cannon-fire, saves the Republic, and becomes its sword.',
      svg_row('Vendémiaire: from soldier to power-broker', [
          {'n': 1, 'label': 'Royalist rising in Paris', 'sub': '~25,000 march on the Convention', 'color': '#dc2626'},
          {'n': 2, 'label': 'Barras gives Napoleon command', 'sub': 'Murat races to fetch the cannon', 'color': '#4338ca'},
          {'n': 3, 'label': 'Grapeshot clears the streets', 'sub': 'the rising is crushed in hours', 'color': '#7c3aed'},
      ], edge_labels=['crisis', 'answer'], takeaway='Be the decisive man in the room when the powerful are terrified — and they will owe you.', accent=AC),
      bg='By 1795 the Republic’s government was hated from the right. A royalist insurrection of tens of thousands prepared to storm the Convention.',
      people='<b>Paul Barras</b>, who remembered Toulon and gave Napoleon tactical command; <b>Joachim Murat</b>, who galloped to seize the artillery first. Days later Napoleon met <b>Joséphine de Beauharnais</b>.',
      what='Napoleon placed cannon to sweep the approaches to the Tuileries and met the columns with <b>grapeshot</b>. The rising collapsed within hours. (“A whiff of grapeshot” is Carlyle’s later phrase.)',
      crux='He used overwhelming, decisive force without hesitation while politicians dithered. Ruthless competence at the moment of maximum fear made him indispensable.',
      conseq='Fame, command of the Army of the Interior, marriage to Joséphine (March 1796), and — the real prize — command of the <b>Army of Italy</b>.',
      matters='Power flows to whoever ends the crisis. Reliability under pressure, more than talent, is what people reward with authority.'),
]

# ==================================================================  PHASE 3 — THE FIRST ITALIAN CAMPAIGN
PHASE_ITALY = [
    E('josephine', 'Mar 1796', 'Joséphine — the marriage that came with an army', ['LOVE', 'POLITICS'],
      'Days before leaving to take command in Italy, the awkward young general marries Joséphine de Beauharnais — a well-connected widow of the Revolution — in a match that is half infatuation, half the making of his career.',
      svg_row('A marriage that was also a career move', [
          {'n': 1, 'label': 'Joséphine de Beauharnais', 'sub': 'widow of a guillotined general; moves in Directory circles', 'color': '#7c3aed'},
          {'n': 2, 'label': 'Marriage, 9 Mar 1796', 'sub': 'he is besotted; she is pragmatic and older', 'color': '#4338ca'},
          {'n': 3, 'label': 'Italy command follows', 'sub': 'Barras’ patronage; two days later he leaves for the front', 'color': '#16a34a'},
      ], edge_labels=['opens', 'confirms'], takeaway='Love and advancement were braided together — her connections and his talent each needed the other.', accent=AC),
      bg='<b>Joséphine</b> de Beauharnais had survived the Terror that guillotined her first husband; she moved in the highest Directory circles, close to <b>Paul Barras</b>, Napoleon’s patron.',
      people='<b>Joséphine</b>, six years his senior, elegant and deep in debt; <b>Barras</b>, who blessed the match — and whose favour came bundled with the command of the Army of Italy.',
      what='They married in a civil ceremony on <b>9 March 1796</b>; two days later he left to command in Italy. His letters were feverish; she was cooler, and unfaithful early on.',
      crux='The marriage tied him to the Republic’s inner establishment exactly when he needed a command — <b>connection and talent reinforcing each other</b>.',
      conseq='Joséphine became Empress in 1804; her failure to bear him an heir would force the painful divorce of 1809–10. But in 1796 she was his door into power.',
      matters='Early careers turn on who vouches for you as much as what you can do — and the two are often bound up in one relationship.'),

    E('montenotte', 'Apr 1796', 'Taking command — and knocking out Piedmont', ['BATTLE', 'RISE'],
      'Handed a ragged, unpaid army, the 26-year-old immediately splits the enemy coalition — driving between the Austrians and Piedmontese and beating the Piedmontese out of the war in two weeks.',
      svg_central(),
      bg='Given the neglected <b>Army of Italy</b> in 1796 — hungry, unpaid, written off — Napoleon faced larger allied Austrian and Piedmontese forces in the mountains of northern Italy.',
      people='Future marshals emerging here — <b>Masséna</b>, <b>Augereau</b>, <b>Berthier</b> (his indispensable chief of staff); the aging allied generals he outpaced.',
      what='In a whirlwind opening (<b>Montenotte, Dego, Mondovì</b>, April 1796) he drove between the two allied armies, beat each separately, and forced <b>Piedmont-Sardinia out of the war</b> within a fortnight (Armistice of Cherasco).',
      crux='The <b>central position</b>: place your army between separated enemies and defeat each before they unite. Speed let his smaller force be the larger one at each point of contact.',
      conseq='Piedmont was knocked out; northern Italy lay open to him; and a written-off army suddenly believed in its young general.',
      matters='Against a bigger but divided enemy, get between the halves and beat them one at a time. Concentration and speed beat mere numbers.'),

    E('lodi', '10 May 1796', 'The Bridge of Lodi — “a higher destiny”', ['BATTLE', 'RISE'],
      'He storms a bridge under heavy fire at Lodi; the reckless courage electrifies his troops, who nickname him "the Little Corporal" — and he begins to believe he is a man of destiny.',
      svg_row('Where the legend (and the self-belief) began', [
          {'n': 1, 'label': 'Austrians hold the far bank', 'sub': 'a defended bridge over the Adda at Lodi', 'color': '#dc2626'},
          {'n': 2, 'label': 'He storms it head-on', 'sub': 'leads the charge under artillery fire', 'color': '#4338ca'},
          {'n': 3, 'label': '“Le petit caporal”', 'sub': 'the soldiers adopt him; his myth begins', 'color': '#7c3aed'},
      ], edge_labels=['then', 'so'], takeaway='Shared, visible courage forges a bond with soldiers that no order ever could — and can intoxicate the leader too.', accent=AC),
      bg='Pursuing the Austrians across the plains of Lombardy, Napoleon met a rearguard defending the bridge at <b>Lodi</b>.',
      people='His grenadiers, who stormed the bridge; the troops who affectionately dubbed him <b>“le petit caporal.”</b>',
      what='Napoleon massed his guns and personally led a charge across the fire-swept <b>bridge of Lodi</b>, taking it. Tactically minor, it was a huge boost to morale — and to his sense of himself. He later said it was at Lodi he first felt he might be “a superior man.”',
      crux='The value was <b>psychological</b>: personal bravery at the front bound the army to him and seeded his belief in his own destiny — a belief that would drive both his triumphs and his overreach.',
      conseq='He entered Milan in triumph days later. The Lodi legend became a cornerstone of the Napoleonic myth he actively cultivated.',
      matters='Morale and belief are force multipliers. But the same self-belief that inspires an army can, unchecked, curdle into the conviction that you cannot fail.'),

    E('arcole', 'Nov 1796', 'Arcole — holding on against the odds', ['BATTLE', 'TRIUMPH'],
      'Austria pours in relief armies to save its trapped fortress at Mantua; Napoleon beats them off one after another, winning a desperate three-day fight at Arcole to keep the siege — and the campaign — alive.',
      svg_row('Beating relief army after relief army', [
          {'n': 1, 'label': 'Mantua under siege', 'sub': 'the key Austrian fortress; Austria must relieve it', 'color': '#64748b'},
          {'n': 2, 'label': 'Wave after wave of relief', 'sub': 'four separate Austrian armies sent to break the siege', 'color': '#dc2626'},
          {'n': 3, 'label': 'Arcole (Nov 1796)', 'sub': 'a grim 3-day fight over marsh causeways — he wins', 'color': '#16a34a'},
      ], edge_labels=['so', 'then'], takeaway='Fix the enemy to something they must defend, then destroy each rescue attempt in turn.', accent=AC),
      bg='The whole 1796–97 campaign pivoted on the great fortress of <b>Mantua</b>. Napoleon besieged it; Austria repeatedly sent fresh armies to relieve it, each of which he had to defeat.',
      people='Austrian commanders <b>Wurmser</b> and <b>Alvinczi</b>, who led successive relief attempts; Napoleon’s marshals holding the line.',
      what='At the <b>Battle of Arcole (15–17 Nov 1796)</b>, over flooded ground and narrow causeways, Napoleon defeated Alvinczi’s relief army in a hard three-day struggle (famously grabbing a flag on the bridge), keeping Mantua sealed.',
      crux='By besieging something Austria <b>could not abandon</b>, he forced them to attack him on his terms — and beat their armies <b>in detail</b>, one relief at a time.',
      conseq='Mantua’s fall (Feb 1797) was now only a matter of time; each defeated relief army further exhausted Austria’s ability to fight in Italy.',
      matters='Make the enemy dance to your tune: threaten what they must protect, and you choose when and where the battles happen.'),

    E('rivoli', 'Jan 1797', 'Rivoli — the masterpiece that ends the campaign', ['BATTLE', 'TRIUMPH'],
      'In the last great Austrian bid to save Mantua, Napoleon concentrates faster than the enemy can, destroys their converging columns at Rivoli, and effectively wins the war in Italy.',
      svg_row('Concentrating faster than the enemy', [
          {'n': 1, 'label': 'Austria attacks in columns', 'sub': 'Alvinczi advances on Rivoli in separate prongs', 'color': '#dc2626'},
          {'n': 2, 'label': 'Napoleon force-marches to unite', 'sub': 'arrives first; masses at the decisive point', 'color': '#4338ca'},
          {'n': 3, 'label': 'The columns crushed', 'sub': 'beaten before they can combine; Mantua falls', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='Arrive first with more at the one place that matters — even when you have fewer men overall.', accent=AC),
      bg='In January 1797, <b>Alvinczi</b> made Austria’s final attempt to relieve Mantua, advancing on the plateau of <b>Rivoli</b> in several separated columns.',
      people='Austrian commander <b>Alvinczi</b>; Napoleon’s hard-marching divisions under Masséna and others.',
      what='Reading the threat, Napoleon <b>concentrated his forces at Rivoli</b> faster than the Austrians could unite theirs, and destroyed the columns as they arrived piecemeal. <b>Mantua surrendered</b> weeks later.',
      crux='Again the essence of his art: <b>speed and concentration</b> at the decisive point. He turned the enemy’s dispersed advance into a series of unequal fights he was bound to win.',
      conseq='Austria was beaten in Italy. Napoleon advanced toward Vienna, forcing terms.',
      matters='Local superiority beats global superiority. Being strongest where it counts, at the moment it counts, is worth more than being bigger everywhere.'),

    E('artplunder', '1796–1797', 'Looting the masterpieces — victory as propaganda', ['POLITICS', 'REFORM'],
      'As he conquers Italy, Napoleon systematically strips its churches and palaces of their greatest paintings and statues and ships them to Paris — turning military triumph into public spectacle and a new kind of soft power.',
      svg_stack('Conquest turned into cultural spectacle', [
          {'n': 1, 'label': 'Extract art by treaty', 'sub': 'peace terms force Italian states to hand over named masterpieces', 'color': '#4338ca'},
          {'n': 2, 'label': 'Parade it through Paris', 'sub': 'the loot enters in triumphal processions — the Republic made visible', 'color': '#b45309'},
          {'n': 3, 'label': 'Fill the Louvre', 'sub': 'the new Musée Central becomes Europe’s greatest gallery', 'color': '#16a34a'},
      ], takeaway='He understood that a victory the public can see and celebrate is worth as much as the battle that won it.', accent=AC),
      bg='Renaissance Italy held the most coveted art in Europe. Napoleon’s peace treaties with Parma, Modena and the Papacy included clauses <b>surrendering specific paintings and antiquities</b>.',
      people='French commissioners and savants who chose the works; the <b>Pope</b>, forced by the Armistice of Bologna to yield a hundred treasures; the Paris crowds who cheered the convoys.',
      what='Hundreds of works — antique statues and paintings by the masters — were crated to Paris and shown in triumphal entries and in the <b>Louvre</b>. Much (not all) was returned after 1815.',
      crux='He converted battlefield success into <b>visible civic glory</b> at home — culture as an instrument of propaganda and legitimacy.',
      conseq='It built his image as more than a general — a bringer of glory to France — and made the Louvre a symbol of national grandeur that outlived the plunder itself.',
      matters='Power is partly theatre: those who stage their victories for the public shape how they are remembered.'),

    E('campoformio', 'Oct 1797', 'Campo Formio — the soldier becomes a statesman', ['POLITICS', 'TRIUMPH'],
      'At 28 he negotiates his own peace treaty with Austria — redrawing the map of Europe on his own authority — and returns to France its most famous man, already more powerful than the government he serves.',
      svg_row('From general to independent power', [
          {'n': 1, 'label': 'Beats Austria in Italy', 'sub': 'threatens Vienna itself', 'color': '#4338ca'},
          {'n': 2, 'label': 'Negotiates Campo Formio', 'sub': 'dictates terms; annexes lands; keeps Belgium', 'color': '#7c3aed'},
          {'n': 3, 'label': 'A political force', 'sub': 'his bulletins make him France’s idol', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He learned early to control the story of his victories — and to act as a power in his own right.', accent=AC),
      bg='With Austria beaten in Italy and his army near Vienna, Napoleon — not the Paris government — held the initiative in peacemaking.',
      people='The <b>Directory</b> in Paris, increasingly unable to control its famous general; Austrian negotiators forced to terms.',
      what='Napoleon negotiated the <b>Treaty of Campo Formio (Oct 1797)</b> largely on his own authority, redrawing borders in France’s favour. Throughout, his <b>army bulletins and newspapers</b> made him a household name — “the story of my victories” as propaganda.',
      crux='Two lessons cemented here: <b>control the narrative</b> (his bulletins built the legend) and <b>act as an independent power</b>, not just a servant of the government.',
      conseq='He returned to France its most celebrated figure — a political force the weak Directory both needed and feared, setting up the coup to come.',
      matters='Build the myth as you build the record. Controlling how your victories are told is as powerful as the victories themselves.'),
]

# ==================================================================  PHASE 4 — EGYPT
PHASE_EGYPT = [
    E('pyramids', 'Jul 1798', 'Egypt and the Battle of the Pyramids', ['BATTLE', 'TRIUMPH'],
      'He sails to Egypt to threaten Britain’s road to India and dazzle France, smashing the Mamluk cavalry in the shadow of the Pyramids and bringing an army of scholars who launch the science of Egyptology.',
      svg_row('The grand eastern gamble begins', [
          {'n': 1, 'label': 'Sail to Egypt (1798)', 'sub': 'take Malta en route; evade Nelson', 'color': '#4338ca'},
          {'n': 2, 'label': 'Battle of the Pyramids', 'sub': 'squares shred the Mamluk cavalry charges', 'color': '#16a34a'},
          {'n': 3, 'label': 'Scholars & the Rosetta Stone', 'sub': 'savants found modern Egyptology', 'color': '#7c3aed'},
      ], edge_labels=['then', 'then'], takeaway='He fused conquest with propaganda and science — the campaign was a bid for glory as much as strategy.', accent=AC),
      bg='To strike at Britain indirectly (its route to <b>India</b>) and to keep an over-mighty general usefully far from Paris, the Directory approved an invasion of <b>Egypt</b> in 1798.',
      people='The <b>Mamluk</b> warrior caste who ruled Egypt; the <b>savants</b> (scientists and scholars) Napoleon brought, whose work — and the <b>Rosetta Stone</b> — founded Egyptology.',
      what='After taking <b>Malta</b>, Napoleon landed in Egypt, seized Alexandria, and at the <b>Battle of the Pyramids (21 Jul 1798)</b> used infantry squares to destroy the charging Mamluk cavalry, taking Cairo.',
      crux='On land he was dominant, and he wrapped the whole venture in <b>glory and learning</b> — casting himself as a conqueror-scholar in the mould of Alexander.',
      conseq='He controlled Egypt on land — but everything depended on the sea behind him, which was about to be cut.',
      matters='Land power without sea power is a trap. A brilliant army can become a prisoner of geography if it loses control of its lifeline.'),

    E('nile', '1 Aug 1798', 'The Battle of the Nile — stranded by Nelson', ['BATTLE', 'DEFEAT'],
      'Ten days after the Pyramids, Nelson finds and annihilates the French fleet at anchor in Aboukir Bay — marooning Napoleon’s army in Egypt with no way home and no reinforcement.',
      svg_compare('The sea undoes the land', {
          'head': 'Napoleon on land', 'color': '#16a34a',
          'items': ['Master of Egypt', 'Wins every land battle', 'Army intact and victorious']},
          {'head': 'Nelson at sea', 'color': '#dc2626',
           'items': ['Destroys the French fleet at anchor', 'Cuts the army off from France', 'No escape, no supply, no reinforcement']},
          verdict='He rules the sand; Britain rules the water — and the water is the lifeline.',
          takeaway='A strength that can’t reach home isn’t enough — control of the connecting sea decided everything.', accent=AC),
      bg='Napoleon’s fleet had carried his army to Egypt and anchored in <b>Aboukir Bay</b>. Britain’s Mediterranean squadron under Nelson had been hunting it for weeks.',
      people='Admiral <b>Horatio Nelson</b>, who attacked with daring aggression, destroying the anchored French fleet under <b>Brueys</b> (killed when his flagship exploded).',
      what='On <b>1 August 1798</b>, Nelson attacked at the <b>Battle of the Nile (Aboukir Bay)</b>, destroying almost the entire French fleet. Napoleon’s army was now <b>trapped in Egypt</b>.',
      crux='Without naval control, his brilliant army was a <b>prisoner of geography</b> — unable to be resupplied, reinforced or evacuated. The land victories were now strategically worthless.',
      conseq='The Egyptian expedition was doomed; but news travelled slowly, and in France Napoleon was still the hero of the Pyramids, not the general who lost a fleet.',
      matters='Secure your lifeline before you extend yourself. The most brilliant advance is undone if the enemy cuts what connects you to home.'),

    E('savants', '1798–1801', 'The savants — conquering Egypt for science', ['REFORM', 'POLITICS'],
      'Napoleon brings 160 scholars to Egypt alongside his army; while the campaign fails militarily, they found the Institut d’Égypte, unearth the Rosetta Stone and produce the vast Description de l’Égypte — birthing modern Egyptology.',
      svg_stack('A military failure that was a scientific landmark', [
          {'n': 1, 'label': '160 savants sail with the army', 'sub': 'mathematicians, engineers, artists, naturalists', 'color': '#4338ca'},
          {'n': 2, 'label': 'Institut d’Égypte, Aug 1798', 'sub': 'a learned academy in Cairo directs the survey', 'color': '#b45309'},
          {'n': 3, 'label': 'Rosetta Stone, 1799', 'sub': 'the key that will unlock hieroglyphs (deciphered 1822)', 'color': '#16a34a'},
          {'n': 4, 'label': 'Description de l’Égypte', 'sub': 'a 23-volume survey — the birth of Egyptology', 'color': '#0891b2'},
      ], takeaway='He grasped that conquest could be intellectual as well as military — and the science outlasted the defeat.', accent=AC),
      bg='The Egyptian expedition of 1798 aimed to threaten Britain’s route to India. Napoleon, himself a member of the Institut de France, attached a <b>Commission of Sciences and Arts</b> to his army.',
      people='Mathematician <b>Gaspard Monge</b>, chemist <b>Berthollet</b>, and scores of young scholars; the artist-engineer <b>Vivant Denon</b>, whose drawings later dazzled Europe.',
      what='They founded the <b>Institut d’Égypte</b>, surveyed monuments up the Nile, recovered the <b>Rosetta Stone</b> (1799), and compiled the monumental <b>Description de l’Égypte</b> over two decades.',
      crux='Even a doomed campaign produced <b>enduring knowledge</b> — Napoleon annexed Egypt for European scholarship if not for France.',
      conseq='The Rosetta Stone (surrendered to Britain in 1801, now in the British Museum) let Champollion decipher hieroglyphs in 1822, unlocking 3,000 years of history.',
      matters='The by-products of ambition can outlast its declared goals: the army left, but a whole science stayed.'),

    E('acre', '1799', 'Syria and the Siege of Acre — the limit reached', ['BATTLE', 'DEFEAT', 'TRAGEDY'],
      'He marches into Syria to break out of his trap, but is stopped at the walls of Acre by a stubborn defence, British sea power and the plague — his first real failure, which he masks with propaganda before abandoning the army.',
      svg_stack('The point where the eastern dream dies', [
          {'n': 1, 'label': 'March into Syria (1799)', 'sub': 'to pre-empt Ottoman attack & escape the trap', 'color': '#4338ca'},
          {'n': 2, 'label': 'Stopped at Acre', 'sub': 'a two-month siege fails; British ships resupply the defenders', 'color': '#dc2626'},
          {'n': 3, 'label': 'Plague & retreat', 'sub': 'a grim march back to Egypt; he hides the failure', 'color': '#b45309'},
          {'n': 4, 'label': 'Abandons the army (Aug 1799)', 'sub': 'slips back to France, legend intact', 'color': '#7c3aed'},
      ], takeaway='He masked a strategic dead-end with narrative — and escaped before the bill came due.', accent=AC),
      bg='Trapped in Egypt after the Nile, Napoleon invaded <b>Ottoman Syria</b> in 1799 to forestall an attack and find a way forward.',
      people='<b>Djezzar Pasha</b> and the British commodore <b>Sidney Smith</b>, who together held <b>Acre</b>; the plague that ravaged the French army; <b>Kléber</b>, left in command in Egypt.',
      what='The <b>Siege of Acre</b> failed after two months — the defenders resupplied by sea, and plague spreading in his ranks. Napoleon retreated to Egypt, spun the campaign as a victory, then <b>abandoned his army</b> and sailed for France in August 1799.',
      crux='Once again the <b>sea</b> beat him (British ships kept Acre supplied), and disease did the rest. It was his first clear failure — which he survived by <b>controlling the story</b> and leaving before the reckoning.',
      conseq='The army he left behind eventually surrendered; but Napoleon arrived home a celebrity, at the exact moment the Directory looked weak and ripe for overthrow.',
      matters='Timing and narrative can outweigh outcomes. He failed strategically, yet returned at the perfect moment with his legend intact to make his boldest move.'),
]

# ==================================================================  PHASE 5 — SEIZING POWER
PHASE_POWER = [
    E('brumaire', '9–10 Nov 1799', 'The Coup of 18 Brumaire — seizing the state', ['POLITICS', 'TURNING POINT'],
      'Conspiring with tired politicians who think they can use him, Napoleon overthrows the Directory in a two-day coup — and ends up not their tool but their master.',
      svg_stack('How a plot to use him made him ruler', [
          {'n': 1, 'label': 'Directory is weak & despised', 'sub': 'corrupt, bankrupt, unstable', 'color': '#475569'},
          {'n': 2, 'label': "Sieyès plots a 'revision'", 'sub': 'needs a general’s sword; picks Napoleon', 'color': '#4338ca'},
          {'n': 3, 'label': 'Coup of 18–19 Brumaire', 'sub': 'troops clear the councils; Lucien saves the day', 'color': '#dc2626'},
          {'n': 4, 'label': 'Consulate — First Consul', 'sub': 'the "junior" partner takes real power', 'color': '#7c3aed'},
      ], takeaway='Whoever controls the force controls the outcome — the planners needed his soldiers more than he needed their plan.', accent=AC),
      bg='The <b>Directory</b> (1795–1799) was broke and hated. Insiders wanted to “revise” the constitution and thought a popular general could provide muscle while they kept control.',
      people='<b>Emmanuel Sieyès</b> and <b>Roger Ducos</b> (fellow plotters); crucially <b>Lucien Bonaparte</b>, president of the Council of Five Hundred, who used the guard to rescue the coup when it faltered. <b>Talleyrand</b> and <b>Fouché</b> lent cover.',
      what='On <b>18–19 Brumaire (9–10 Nov 1799)</b>, the councils were moved to Saint-Cloud; when deputies resisted, troops cleared the chamber. A new <b>Consulate</b> was declared with Napoleon as <b>First Consul</b> holding real authority.',
      crux='The plotters imagined Napoleon as their sword; but power sat with whoever commanded the bayonets. Once soldiers, not deputies, decided the day, the general outranked the politicians.',
      conseq='At 30 he was effectively ruler of France. The Revolution’s decade of instability ended — and his personal rule began.',
      matters='Never mistake the instrument for the servant. Control of hard power converts a supporting role into the leading one.'),

    E('marengo', '14 Jun 1800', 'Marengo — a near-defeat that secures his throne', ['BATTLE', 'TURNING POINT'],
      'Barely a First Consul, he crosses the Alps to surprise the Austrians in Italy — and is nearly beaten at Marengo until a subordinate’s counterattack turns rout into victory, cementing his fragile new rule.',
      svg_row('The victory his regime needed', [
          {'n': 1, 'label': 'Cross the Alps by surprise', 'sub': 'appears behind the Austrians in Italy', 'color': '#4338ca'},
          {'n': 2, 'label': 'Nearly loses at Marengo', 'sub': 'caught off guard; the army is being driven back', 'color': '#dc2626'},
          {'n': 3, 'label': 'Desaix saves the day', 'sub': 'a late counterattack turns defeat into victory', 'color': '#16a34a'},
      ], edge_labels=['then', 'but'], takeaway='A new regime needs a victory to survive — he got one, narrowly, and made sure the story hid how close he came to disaster.', accent=AC),
      bg='A coup is fragile. To convert seizure into legitimacy, Napoleon needed a <b>victory</b> fast. He crossed the Alps to strike the Austrians in Italy in 1800.',
      people='General <b>Desaix</b>, whose arrival and counterattack rescued the battle (he was killed in the act); the Austrian army caught by the Alpine crossing.',
      what='At <b>Marengo (14 Jun 1800)</b> Napoleon was surprised and nearly defeated; a timely counterattack by <b>Desaix</b> (and Kellermann’s cavalry charge) reversed the day into a decisive French win. Napoleon later rewrote the official account to look more masterful.',
      crux='It was a <b>close-run, lucky victory</b> that he presented as planned genius. Militarily narrow, it was <b>politically decisive</b>: it secured his grip on France.',
      conseq='Combined with Moreau’s win at Hohenlinden, it forced Austria to peace (Lunéville, 1801). Napoleon’s rule was now stable enough to reform France.',
      matters='Sometimes you only need to survive the near-disaster and win the story afterward. A shaky new regime is legitimised by results, however narrowly achieved.'),

    E('amiens', '1802', 'The Peace of Amiens and Consul for Life', ['POLITICS', 'TRIUMPH'],
      'For one brief year all Europe is at peace with France, and a grateful nation votes Napoleon First Consul for life — a plebiscite that makes him monarch in all but name, two years before the crown.',
      svg_row('From general to monarch-in-waiting', [
          {'n': 1, 'label': 'Peace of Amiens, Mar 1802', 'sub': 'even Britain makes peace — France exhausted, glory secured', 'color': '#16a34a'},
          {'n': 2, 'label': 'Plebiscite, Aug 1802', 'sub': 'millions vote him Consul for Life', 'color': '#4338ca'},
          {'n': 3, 'label': 'Monarch in all but name', 'sub': 'gains the right to name a successor — the throne prefigured', 'color': '#7c3aed'},
      ], edge_labels=['enables', 'becomes'], takeaway='He used a rare moment of peace to convert popularity into permanent, quasi-royal power.', accent=AC),
      bg='After Marengo and Hohenlinden forced Austria to terms at Lunéville (1801), only Britain remained at war. War-weariness on both sides produced the <b>Peace of Amiens</b> in March 1802.',
      people='<b>Joseph Bonaparte</b>, who negotiated the treaty; British ministers eager for a pause; a French public longing for stability after a decade of upheaval.',
      what='The peace — the only full Franco-British peace of these years — let Napoleon hold a <b>plebiscite making him First Consul for Life</b> with the right to name his heir. It lasted barely a year before war resumed in 1803.',
      crux='Peace, not war, was the moment he seized to <b>entrench himself</b> — popularity is most easily converted into power when people feel safe.',
      conseq='The Life Consulate was the dress rehearsal for the Empire of 1804; when war returned he already held near-monarchical authority.',
      matters='Autocrats are often crowned in the calm after victory, not the heat of crisis — security lowers a people’s guard.'),

    E('code', '1801–1804', 'The Concordat and the Code — building the state', ['POLITICS', 'REFORM', 'TRIUMPH'],
      'He makes his rule permanent not by battles but by rebuilding France: peace with the Church, peace (briefly) with Britain, and a rational legal code — the Code Napoléon — that outlives every one of his conquests.',
      svg_stack('From winning power to making it permanent', [
          {'n': 1, 'label': 'Concordat (1801)', 'sub': 'peace with the Pope ends religious civil war', 'color': '#0891b2'},
          {'n': 2, 'label': 'Peace of Amiens (1802)', 'sub': 'a brief, popular peace even with Britain', 'color': '#16a34a'},
          {'n': 3, 'label': 'Napoleonic Code (1804)', 'sub': 'one clear civil law: equality before it, property, merit', 'color': '#4338ca'},
          {'n': 4, 'label': 'Consul for life (1802)', 'sub': 'plebiscites ratify one-man rule', 'color': '#7c3aed'},
      ], takeaway='Battles win power; institutions keep it. His Code outlived every one of his conquests.', accent=AC),
      bg='To convert seizure into durable legitimacy, Napoleon delivered what France craved after a decade of chaos: <b>order and reconciliation</b>.',
      people='<b>Pope Pius VII</b>, who signed the Concordat; the jurists who, under Napoleon’s driving chairmanship, drafted the <b>Code civil</b>.',
      what='He healed the breach with the Catholic Church (<b>Concordat, 1801</b>), made a popular peace with Britain (<b>Amiens, 1802</b>), and promulgated the <b>Napoleonic Code (1804)</b> — codifying equality before the law, secure property, and careers open to talent. Plebiscites made him <b>Consul for life</b>.',
      crux='He <b>institutionalised the Revolution’s gains</b> (merit, legal equality, secular property) while ending its chaos. That fusion — <b>order plus opportunity</b> — made his regime broadly popular and durable.',
      conseq='France got its most stable government in years and a legal system exported across Europe — the <b>Napoleonic Code still underpins the law of dozens of countries today</b>.',
      matters='Systems outlast individuals. His most permanent conquest wasn’t territory — it was a code of law and a professional state.'),
]

# ==================================================================  PHASE 6 — EMPEROR & ZENITH
PHASE_ZENITH = [
    E('coronation', '2 Dec 1804', 'Emperor of the French — he crowns himself', ['POLITICS', 'TRIUMPH'],
      'At Notre-Dame, with the Pope present, Napoleon takes the crown and places it on his own head — declaring that his authority comes from his deeds and the nation, not from God or Rome.',
      svg_row('The meaning of the self-coronation', [
          {'n': 1, 'label': 'Pope Pius VII attends', 'sub': 'traditional blessing expected', 'color': '#64748b'},
          {'n': 2, 'label': 'Napoleon crowns himself', 'sub': 'takes the crown, does not receive it', 'color': '#4338ca'},
          {'n': 3, 'label': 'A new kind of monarch', 'sub': 'power from merit + plebiscite, not divine right', 'color': '#7c3aed'},
      ], edge_labels=['then', 'means'], takeaway='Symbols are arguments. Crowning himself said: I owe this throne to no one but myself and the people.', accent=AC),
      bg='After a royalist assassination plot, making the regime <b>hereditary</b> was sold as the way to secure it — kill Napoleon and nothing changes if there’s an heir and an institution.',
      people='<b>Pope Pius VII</b>, who came to Paris to consecrate the ceremony; <b>Joséphine</b>, crowned Empress; the painter <b>Jacques-Louis David</b>, who immortalised it.',
      what='At <b>Notre-Dame on 2 December 1804</b>, Napoleon took the crown and placed it on his own head, then crowned Joséphine. (The image of “snatching” it from the Pope is dramatised; the deliberate self-coronation is real.)',
      crux='He <b>fused Revolution and monarchy</b>: keeping the Revolution’s principle — sovereignty from the nation and merit — while adopting a crown’s permanence. The gesture encoded his whole ideology.',
      conseq='France was an Empire; his family became royalty; monarchical Europe was both awed and appalled at a self-made emperor who broke every rule of legitimacy.',
      matters='How you take power defines what your power means. He staged legitimacy on his own terms rather than borrowing it from the old order.'),

    E('marshals', '1802–1804', 'The Marshals and the Légion d’honneur — a new elite', ['REFORM', 'POLITICS'],
      'Napoleon binds his best soldiers and citizens to him by inventing a new aristocracy of merit — eighteen Marshals of the Empire and the Légion d’honneur — rewarding talent and loyalty with honours the old regime reserved for birth.',
      svg_stack('Building a loyal elite of merit', [
          {'n': 1, 'label': 'Légion d’honneur, 1802', 'sub': 'a decoration open to any citizen — soldier or civilian — for service', 'color': '#b45309'},
          {'n': 2, 'label': '18 Marshals of the Empire, 1804', 'sub': 'Davout, Ney, Murat, Masséna… his captains ennobled', 'color': '#4338ca'},
          {'n': 3, 'label': 'Loyalty bought with glory', 'sub': 'titles, estates and pensions tie the ablest men to his person', 'color': '#16a34a'},
      ], takeaway='He replaced an aristocracy of birth with one of achievement — and made himself the fountain of all honour.', accent=AC),
      bg='The Revolution had abolished titles; Napoleon, needing an elite to run an empire, rebuilt one on a new principle — <b>reward for service</b>, not inheritance.',
      people='The <b>Marshalate</b> of 1804 — <b>Davout</b> (his ablest), <b>Ney</b> (“bravest of the brave”), <b>Murat</b>, <b>Masséna</b>, <b>Lannes</b> — and the countless soldiers who would earn the Légion.',
      what='He created the <b>Légion d’honneur</b> in 1802 and named the first <b>eighteen Marshals</b> in 1804, later adding an imperial nobility with titles and endowments — all keyed to service to the state.',
      crux='By making himself the sole source of a <b>merit-based honour system</b>, he tied the ambition of the talented directly to his own survival.',
      conseq='The Légion d’honneur endures as France’s highest distinction today; the Marshals gave him the command talent that won Austerlitz and Jena — though some later abandoned him.',
      matters='Loyalty is cheapest to buy with status: give able people a ladder only you control, and their ambition serves you.'),

    E('trafalgar', '21 Oct 1805', 'Trafalgar — the sea is lost forever', ['BATTLE', 'DEFEAT'],
      'Nelson destroys the Franco-Spanish fleet off Spain. Napoleon can never invade Britain now — so he turns his back on the Channel and marches east, to fight on land where he is unbeatable.',
      svg_compare('Two different wars: land vs sea', {
          'head': 'On land — Napoleon supreme', 'color': '#16a34a',
          'items': ['Fast, massed armies', 'Genius for manoeuvre', 'Wins nearly every campaign', 'Dominates the Continent']},
          {'head': 'At sea — Britain supreme', 'color': '#dc2626',
           'items': ['Royal Navy far superior', 'Nelson destroys the fleet', 'Invasion of Britain impossible', 'Britain funds coalition after coalition']},
          verdict='He rules the land; Britain rules the water — and never stops paying his enemies.',
          takeaway='A strength that can’t reach the enemy isn’t enough — he could win every battle and still not win the war.', accent=AC),
      bg='Napoleon massed an army at Boulogne to invade England, needing only brief control of the Channel — which depended on his fleet evading and beating the Royal Navy.',
      people='Admiral <b>Horatio Nelson</b> (killed in his moment of victory) shattered the combined fleet under <b>Villeneuve</b>. Britain’s naval supremacy would last a century.',
      what='On <b>21 October 1805</b>, off Cape Trafalgar, Nelson’s fleet destroyed the Franco-Spanish fleet. British command of the sea became unchallengeable for the rest of the wars.',
      crux='The war split into two theatres he could not connect. Master of the land, he had no answer to the sea — so Britain stayed safe, solvent, and able to <b>bankroll coalition after coalition</b>.',
      conseq='The invasion was abandoned; the same army wheeled east and won Ulm and Austerlitz within weeks. But Britain — his most implacable enemy — was now permanently out of reach.',
      matters='Unbeatable in your domain can still mean unable to win the whole contest. The enemy you cannot reach is the one who beats you slowly.'),

    E('ulm', 'Oct 1805', 'The Manoeuvre of Ulm — an army captured by marching', ['BATTLE', 'TRIUMPH'],
      'Wheeling his whole army from the Channel to the Danube, he encircles an entire Austrian army at Ulm and forces it to surrender almost without a battle — the purest demonstration of his art of movement.',
      svg_ulm(),
      bg='When the Third Coalition (Austria, Russia, Britain) formed in 1805, Napoleon abandoned the invasion of Britain and marched the <b>Grande Armée</b> east at astonishing speed.',
      people='The hapless Austrian general <b>Mack</b>, who advanced to Ulm expecting to meet the French head-on; Napoleon’s corps commanders executing a vast encircling march.',
      what='Instead of attacking frontally, Napoleon swung his corps in a huge arc <b>around and behind</b> Mack’s army at <b>Ulm</b>, cutting it off from Vienna and supply. Trapped, Mack <b>surrendered ~23,000 men in October 1805</b> with barely a fight.',
      crux='“I have destroyed the enemy merely by marches.” It was victory by <b>manoeuvre and logistics</b> — the corps system moving faster than the enemy could react, so the battle was decided before it began.',
      conseq='An entire army was eliminated at almost no cost, opening the road to Vienna and setting up Austerlitz six weeks later.',
      matters='The highest form of war is winning before the fighting: superior speed, organisation and positioning can make an enemy’s defeat inevitable without a battle.'),

    E('austerlitz', '2 Dec 1805', 'Austerlitz — the masterpiece', ['BATTLE', 'TRIUMPH', 'TURNING POINT'],
      'On his coronation’s first anniversary, Napoleon gives up the high ground on purpose, lures the Austro-Russian army into attacking his “weak” flank, then splits their centre and destroys them. His greatest victory.',
      svg_austerlitz(),
      bg='After Ulm, Napoleon faced the main Austro-Russian army in Moravia. He deliberately looked weak — abandoning the commanding <b>Pratzen Heights</b> and thinning his right — to invite an attack.',
      people='<b>Tsar Alexander I of Russia</b> and <b>Emperor Francis II of Austria</b> commanded against him (“the Battle of the Three Emperors”). Marshal <b>Soult</b> delivered the decisive blow up the Heights.',
      what='Napoleon <b>baited the allies</b> to shift south to cut him from Vienna; when they stripped their centre to do it, <b>Soult’s hidden corps stormed the Pratzen Heights</b>, split the allied army in two, and rolled it up. Thousands drowned fleeing across frozen ponds.',
      crux='He <b>weaponised the enemy’s own plan</b>: by offering an irresistible target he chose where they would commit, then struck the gap that commitment created. Control the enemy’s decisions, not just your own.',
      conseq='A shattering victory. Austria signed the <b>Treaty of Pressburg</b>; the Third Coalition collapsed; the Holy Roman Empire was dissolved in 1806. Napoleon stood at the height of his reputation.',
      matters='The deepest strategy is making the opponent want to do the thing that destroys them. Shape their choices and the battle is won before it’s fought.'),

    E('jena', '14 Oct 1806', 'Jena–Auerstedt & the Continental System', ['BATTLE', 'POLITICS', 'TRIUMPH'],
      'He annihilates Prussia in a single day, occupies Berlin, and there launches his great economic weapon: shut all of Europe’s ports to British trade. It will slowly poison his own empire.',
      svg_continental(),
      bg='Prussia, humiliatingly late, mobilised against France in 1806. Meanwhile, unable to beat Britain at sea, Napoleon reached for an economic weapon: deny Britain its European markets.',
      people='The Prussian army — living on the fading reputation of <b>Frederick the Great</b> — was smashed; Marshal <b>Davout</b> won the harder fight at Auerstedt against double his numbers.',
      what='On <b>14 October 1806</b> Napoleon crushed Prussia at <b>Jena</b> while Davout destroyed the main Prussian army at <b>Auerstedt</b> the same day. Occupying Berlin, he issued the <b>Berlin Decree</b>, founding the <b>Continental System</b> — a Europe-wide embargo on British goods.',
      crux='The System tried to beat sea-power with economics, but required policing <b>every coastline in Europe</b>. Enforcement became the trap: to close the ports he had to control the countries — dragging him into Spain and Russia.',
      conseq='Prussia was knocked out; but the embargo hurt French-allied economies, bred smuggling and resentment, and set up the two catastrophes to come.',
      matters='Beware the policy that can only work if you control everything. A weapon that forces endless enforcement becomes a cage.'),

    E('confederation', '1806', 'The Confederation of the Rhine — ending a thousand-year empire', ['POLITICS', 'REFORM', 'TRIUMPH'],
      'After crushing Austria, Napoleon reorganises Germany into a bloc of client states under his protection — and forces the abdication of the last Holy Roman Emperor, ending an institution that had lasted a thousand years.',
      svg_row('Redrawing the map of Germany', [
          {'n': 1, 'label': 'Confederation of the Rhine, Jul 1806', 'sub': '16 German states leave the old Empire and ally to France', 'color': '#4338ca'},
          {'n': 2, 'label': 'Holy Roman Empire ends, Aug 1806', 'sub': 'Francis II abdicates the thousand-year crown', 'color': '#dc2626'},
          {'n': 3, 'label': 'A French-run Germany', 'sub': 'satellite states supply troops and buffer France', 'color': '#16a34a'},
      ], edge_labels=['forces', 'yields'], takeaway='He didn’t just beat states — he abolished and rebuilt the political architecture of Central Europe.', accent=AC),
      bg='Since the Middle Ages the <b>Holy Roman Empire</b> had loosely bound the German lands. After Austerlitz shattered Austrian power in 1805, Napoleon reordered Germany to his advantage.',
      people='<b>Francis II</b>, who had pre-emptively taken the title Emperor of Austria in 1804 and now surrendered the older crown; the German princes who traded old allegiance for enlarged, sovereign states.',
      what='In July 1806 sixteen states formed the <b>Confederation of the Rhine</b> under Napoleon’s protection; in August, <b>Francis II abdicated</b> and the Holy Roman Empire dissolved after ~1,000 years. The Confederation owed him troops.',
      crux='He converted military victory into <b>permanent structural power</b> — a tier of dependent states feeding his armies and shielding France’s frontier.',
      conseq='It provoked Prussia into the war he would win at Jena that October, and it began a reorganisation of Germany that, ironically, helped seed later German unification.',
      matters='The greatest conquerors don’t just win wars — they redraw the institutions, so victory keeps paying long after the battle.'),

    E('eylau', 'Feb 1807', 'Eylau — the first great bloodbath without victory', ['BATTLE', 'DEFEAT', 'TRAGEDY'],
      'In a snowstorm against the Russians, he fights the most horrific battle of his career to a bloody standstill — the first time the aura of easy invincibility cracks.',
      svg_row('The limit of the knockout blow appears', [
          {'n': 1, 'label': 'Winter war in Poland', 'sub': 'chases the Russians into a brutal campaign', 'color': '#64748b'},
          {'n': 2, 'label': 'Eylau in a blizzard', 'sub': 'a corps nearly destroyed; a huge cavalry charge saves him', 'color': '#dc2626'},
          {'n': 3, 'label': 'A ghastly draw', 'sub': '~40,000 casualties; no decisive result', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='Some enemies (Russia) can’t be knocked out in one blow — the first warning of what 1812 would bring.', accent=AC),
      bg='After Jena, Napoleon pursued the <b>Russians</b> into wintry Poland and East Prussia in early 1807 — a harsh new theatre against an enemy who would not break.',
      people='Russian commander <b>Bennigsen</b>; Marshal <b>Augereau</b>, whose corps was shattered in the snow; Murat’s massed cavalry charge that averted disaster.',
      what='At <b>Eylau (7–8 Feb 1807)</b>, fought in a blizzard, Napoleon narrowly avoided defeat (saved by a huge cavalry charge) in a battle so bloody — perhaps 40,000 casualties — that it ended as a horrifying <b>draw</b>.',
      crux='Against the vast, stubborn <b>Russians</b>, his war-winning <b>decisive battle</b> didn’t decide. It was the first crack in the myth of effortless invincibility — and a preview of 1812.',
      conseq='He recovered to win decisively months later, but Eylau showed the cost of fighting an enemy with endless space and manpower who refused to collapse.',
      matters='The method that works on most enemies can fail against one built differently. Eylau was the early warning Napoleon did not fully heed.'),

    E('tilsit', 'Jun–Jul 1807', 'Friedland & Tilsit — the zenith', ['BATTLE', 'TRIUMPH', 'POLITICS'],
      'He redeems Eylau by crushing the Russians at Friedland, then meets Tsar Alexander on a raft in the middle of a river and charms him into alliance. At 37 he dominates Europe from Spain to Poland.',
      svg_row('The peak of the empire', [
          {'n': 1, 'label': 'Friedland (Jun 1807)', 'sub': 'decisive defeat of Russia', 'color': '#4338ca'},
          {'n': 2, 'label': 'The raft at Tilsit', 'sub': 'Napoleon & Alexander I make peace, in person', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Master of the Continent', 'sub': 'allies, satellites & family thrones everywhere', 'color': '#16a34a'},
      ], edge_labels=['leads to', 'means'], takeaway='This is as high as it goes. From here, every remaining war is one he chose — and didn’t have to.', accent=AC),
      bg='After the bloody stalemate of Eylau, Napoleon beat the Russians decisively at <b>Friedland (14 Jun 1807)</b>, forcing Tsar Alexander to terms.',
      people='<b>Tsar Alexander I</b>, flattered and courted on the raft, who became — briefly — an ally and admirer; Napoleon’s brothers and marshals, installed as kings across Europe.',
      what='At <b>Tilsit (July 1807)</b>, on a raft moored in the Niemen, Napoleon and Alexander divided Europe into spheres and allied against Britain. Napoleon now dominated most of the Continent.',
      crux='He had reached the natural <b>limit of dominance</b> — everyone left was beaten or allied. The rational move was to consolidate; instead the logic of the Continental System and his own restlessness pushed him onward.',
      conseq='The zenith of the empire. Every later chapter is decline — because the remaining enemies (Britain’s money, Spanish resistance, Russian distance) couldn’t be beaten in a single battle.',
      matters='The most dangerous moment is the summit. Knowing when to stop is harder than knowing how to win — and it’s the skill he lacked.'),
]

# ==================================================================  PHASE 7 — OVERREACH
PHASE_OVERREACH = [
    E('familythrones', '1806–1810', 'A family of kings — the Bonaparte thrones', ['POLITICS'],
      'Napoleon parcels out the crowns of Europe to his brothers and marshals, turning conquered kingdoms into a family firm — a dynastic empire meant to bind the Continent to his blood.',
      svg_stack('Europe run as a family business', [
          {'n': 1, 'label': 'Joseph → Naples, then Spain', 'sub': 'the eldest brother made a king twice over', 'color': '#4338ca'},
          {'n': 2, 'label': 'Louis → Holland', 'sub': 'younger brother crowned in the Netherlands (abdicates 1810)', 'color': '#b45309'},
          {'n': 3, 'label': 'Jérôme → Westphalia', 'sub': 'youngest brother rules a new German kingdom', 'color': '#7c3aed'},
          {'n': 4, 'label': 'Marshals and kin elsewhere', 'sub': 'Murat to Naples; sisters married into ruling houses', 'color': '#16a34a'},
      ], takeaway='He tried to hold Europe together with family loyalty — but brothers proved unreliable viceroys.', accent=AC),
      bg='Rather than annex every conquest directly, Napoleon created <b>satellite kingdoms</b> ruled by relatives — a dynastic system meant to make his empire hereditary and stable.',
      people='Brothers <b>Joseph</b> (Naples 1806, Spain 1808), <b>Louis</b> (Holland 1806), <b>Jérôme</b> (Westphalia 1807); brother-in-law <b>Murat</b> (Berg, then Naples 1808); sisters married into power.',
      what='Between 1806 and 1810 he placed his siblings on thrones across Europe. But <b>Louis put Dutch interests first</b> and was deposed, and <b>Joseph’s move to Spain</b> in 1808 lit a ruinous war.',
      crux='He confused <b>family with reliability</b> — kinship gave legitimacy but not competence or obedience, and several brothers governed for their subjects, not for him.',
      conseq='The Spanish throne handed to Joseph triggered the Peninsular War — the “Spanish ulcer” that bled the empire for six years.',
      matters='Delegating power to relatives secures the loyalty of blood but not of judgement — a dynasty is only as strong as its weakest heir.'),

    E('spain', '1808', 'The Spanish ulcer — a war that never ends', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'To seal the Continental System he grabs Spain and makes his brother king. Instead of a conquest he gets a national uprising, a humiliating surrender at Bailén, and a guerrilla war that bleeds his army for six years.',
      svg_stack('How a “simple” takeover became a running wound', [
          {'n': 1, 'label': 'Depose the Spanish Bourbons (1808)', 'sub': 'lures the royals to Bayonne; installs brother Joseph', 'color': '#4338ca'},
          {'n': 2, 'label': 'The people rise — Dos de Mayo', 'sub': 'not an army to beat, but a whole nation', 'color': '#dc2626'},
          {'n': 3, 'label': 'Bailén: an army surrenders', 'sub': 'a French corps capitulates — the myth cracks', 'color': '#b45309'},
          {'n': 4, 'label': '~300,000 French tied down', 'sub': 'guerrillas + Wellington drain the empire for years', 'color': '#475569'},
      ], takeaway='You can defeat an army in a day; you cannot defeat a people who simply refuse to stop.', accent=AC),
      bg='Portugal defied the embargo, so Napoleon sent armies through Spain — then decided to take Spain itself, tricking the royal family into abdicating at <b>Bayonne</b> and placing his brother <b>Joseph</b> on the throne.',
      people='<b>Joseph Bonaparte</b>, the unwanted king; the Spanish people, who rose spontaneously; <b>Arthur Wellesley (the future Duke of Wellington)</b>, who turned Iberia into Britain’s foothold.',
      what='The Madrid rising of <b>Dos de Mayo (2 May 1808)</b> triggered a national insurrection; a French army even surrendered at <b>Bailén</b>. What followed was years of brutal <b>guerrilla</b> warfare (the word is Spanish) plus a British army under Wellington in the <b>Peninsular War</b>.',
      crux='He mistook the <b>state</b> for the <b>nation</b>. Removing the king didn’t remove the country’s will to resist — and against dispersed guerrillas his war-winning tool, the decisive battle, had no target.',
      conseq='The Peninsular War tied down hundreds of thousands of troops, inspired resistance across Europe, and shredded the myth of French invincibility — a constant drain while he gambled elsewhere.',
      matters='Overreach hides inside easy wins. Taking Spain looked cheap and proved ruinous — the first big crack in the empire.'),

    E('aspern', 'May 1809', 'Aspern-Essling — his first personal defeat', ['BATTLE', 'DEFEAT'],
      'When Austria rearms and attacks, Napoleon rushes to cross the Danube and is thrown back in a two-day battle — the first time he is personally beaten in the field, a shock felt across Europe.',
      svg_row('The aura of invincibility is broken', [
          {'n': 1, 'label': 'Austria attacks again (1809)', 'sub': 'while Napoleon is bogged in Spain', 'color': '#64748b'},
          {'n': 2, 'label': 'A rushed Danube crossing', 'sub': 'the bridge breaks; his army is caught half-across', 'color': '#dc2626'},
          {'n': 3, 'label': 'Beaten at Aspern-Essling', 'sub': 'forced back; Marshal Lannes killed', 'color': '#b45309'},
      ], edge_labels=['then', 'so'], takeaway='Even he could be beaten — haste and a broken bridge cost him his first defeat and a dear friend.', accent=AC),
      bg='In 1809 Austria, sensing France overstretched in Spain, launched a new war. Napoleon took Vienna but had to cross the <b>Danube</b> to destroy the Austrian army under <b>Archduke Charles</b>.',
      people='<b>Archduke Charles</b>, the ablest Austrian commander, who inflicted the defeat; Marshal <b>Lannes</b>, one of Napoleon’s closest friends, mortally wounded here.',
      what='At <b>Aspern-Essling (21–22 May 1809)</b>, Napoleon pushed across the Danube on fragile bridges that broke under floods and Austrian attacks, stranding his army. Archduke Charles drove him back — Napoleon’s <b>first personal defeat</b>.',
      crux='<b>Haste</b> and a <b>vulnerable crossing</b> undid him: he attacked before he was ready and the river cut his army in two. The loss shattered the myth that he could not be beaten.',
      conseq='He withdrew, regrouped, prepared meticulously — and returned six weeks later to force the decisive battle of Wagram.',
      matters='Even genius pays for haste. And the aura of invincibility, once broken, emboldens every enemy — a psychological loss as much as a military one.'),

    E('wagram', 'Jul 1809', 'Wagram — victory by brute mass', ['BATTLE', 'TRIUMPH'],
      'Six weeks later he crosses the Danube again, properly this time, and wins a huge, grinding battle at Wagram — but it takes overwhelming numbers and a giant battery, a sign his enemies are catching up.',
      svg_row('Winning, but the wars are getting harder', [
          {'n': 1, 'label': 'Cross the Danube again', 'sub': 'this time massive, careful preparation', 'color': '#4338ca'},
          {'n': 2, 'label': 'A colossal two-day battle', 'sub': '~300,000 men; a 100-gun grand battery', 'color': '#b45309'},
          {'n': 3, 'label': 'Costly victory', 'sub': 'Austria beaten — but by mass, not finesse', 'color': '#16a34a'},
      ], edge_labels=['then', 'so'], takeaway='He still won — but by weight of numbers and guns, not the old lightning brilliance. The edge was narrowing.', accent=AC),
      bg='After Aspern-Essling, Napoleon reinforced heavily and prepared a proper crossing of the Danube to destroy Archduke Charles’s army.',
      people='<b>Archduke Charles</b>, again the opponent; Napoleon’s vast concentrated <b>artillery</b>, increasingly his war-winning tool.',
      what='At <b>Wagram (5–6 July 1809)</b>, one of the largest battles yet fought, Napoleon won a hard, bloody victory — leaning on overwhelming numbers and a massed <b>grand battery</b> of guns rather than manoeuvre. Austria sued for peace.',
      crux='Victory now took <b>brute mass and firepower</b>, not the elegant manoeuvres of Austerlitz. His enemies had learned; the margin of his superiority was shrinking.',
      conseq='Austria was beaten a fourth time and forced into alliance — sealed by Napoleon’s marriage to a Habsburg princess. But the era of cheap, brilliant victories was ending.',
      matters='Watch the trend, not just the result. Still winning, but by ever-greater cost and mass, is a warning that your edge is eroding.'),

    E('marielouise', '1809–1811', 'A Habsburg bride and an heir', ['POLITICS', 'LOVE'],
      'He divorces Joséphine, the wife he loves, because she gave him no heir — and marries the daughter of the Austrian emperor, finally getting the son who will inherit an empire he is about to lose.',
      svg_row('Securing the dynasty', [
          {'n': 1, 'label': 'Divorce Joséphine (1809–10)', 'sub': 'no heir → dynastic necessity over love', 'color': '#db2777'},
          {'n': 2, 'label': 'Marry Marie Louise', 'sub': 'a Habsburg bride ties him to old royalty', 'color': '#7c3aed'},
          {'n': 3, 'label': 'Son born, 1811', 'sub': 'the “King of Rome” — an heir at last', 'color': '#16a34a'},
      ], edge_labels=['then', 'then'], takeaway='He got everything an emperor is supposed to want — right before the fall that made it worthless.', accent=AC),
      bg='With no child by Joséphine, the succession threatened everything Napoleon had built. A dynastic marriage into old royalty would also, he hoped, bind Austria to him.',
      people='<b>Joséphine</b>, divorced but never stopped loved; <b>Archduchess Marie Louise of Austria</b>, daughter of his old enemy Francis; their son, styled <b>King of Rome</b>.',
      what='Napoleon <b>annulled his marriage to Joséphine</b> and married <b>Marie Louise</b> (1810) — the ultimate insider match for the outsider emperor. In <b>1811</b> his heir was born.',
      crux='Dynasty demanded a bloodline; sentiment gave way. The Habsburg match was also strategy — binding Austria by family — though it would not survive the coming disaster.',
      conseq='He had an heir and a royal marriage, the trappings of a permanent dynasty — but the Continental System and the standoff with Russia were about to undo all of it.',
      matters='Achieving the checklist of “success” means nothing if the foundation is cracking. He secured the succession just as he forfeited the throne.'),

    E('russia', '1812', 'The Russian catastrophe', ['BATTLE', 'DEFEAT', 'TRAGEDY', 'TURNING POINT'],
      'He invades Russia with the largest army Europe has ever seen to force the Tsar back into the embargo. The Russians retreat, burn everything, refuse to surrender — and winter destroys his army almost to the man.',
      svg_russia_graph(),
      bg='Tsar Alexander quit the ruinous <b>Continental System</b>. To force him back, Napoleon assembled a multinational <b>Grande Armée</b> of roughly half a million men and invaded in June 1812.',
      people='<b>Alexander I</b>, who refused every overture; Russian commander <b>Kutuzov</b>, who traded Moscow for time and space; “General Winter” and General Distance, the enemies no genius could out-manoeuvre.',
      what='The Russians retreated, applying <b>scorched earth</b>. The bloodbath at <b>Borodino (7 Sep 1812)</b> opened the road to Moscow, but the city was <b>burned</b> and no surrender came. After five weeks in the ashes, Napoleon retreated into the winter; cold, starvation, Cossacks and the horror at the <b>Berezina</b> reduced ~half a million men to perhaps <b>25,000</b>.',
      crux='His whole system needed a <b>decisive battle</b> to dictate peace. Russia denied him one — trading endless space and its own cities for time, so his army destroyed itself by simply being there. He won the battles and lost the campaign.',
      conseq='The Grande Armée — and the aura of invincibility — was gone. All of Europe smelled blood; Prussia and Austria would turn on him. It was the beginning of the end.',
      matters='The greatest strength has a matching weakness. A method built on the knockout blow fails utterly against an enemy who refuses to be knocked out.'),
]

# ==================================================================  PHASE 8 — THE FALL
PHASE_FALL = [
    E('berezina', 'Nov 1812', 'The Berezina — escape from annihilation', ['BATTLE', 'TRAGEDY'],
      'The frozen remnant of the Grande Armée reaches a half-melted river with the Russians closing on three sides; Napoleon’s engineers build two bridges in the ice and save the army from total destruction — at a catastrophic human cost.',
      svg_stack('Snatching survival from catastrophe', [
          {'n': 1, 'label': 'Trapped at the Berezina', 'sub': 'the retreat hits an unfrozen river; three Russian armies converge', 'color': '#dc2626'},
          {'n': 2, 'label': 'Pontonniers build two bridges', 'sub': 'Éblé’s engineers work in the freezing water — most die of it', 'color': '#4338ca'},
          {'n': 3, 'label': 'A feint splits the Russians', 'sub': 'Napoleon deceives them as to the crossing point', 'color': '#b45309'},
          {'n': 4, 'label': 'The army escapes — stragglers do not', 'sub': 'tens of thousands of camp-followers left on the far bank', 'color': '#7c3aed'},
      ], takeaway='A masterpiece of desperate engineering and deception — turning certain annihilation into a merely disastrous escape.', accent=AC),
      bg='By late November 1812 the retreat from Moscow had already destroyed most of the Grande Armée. At the <b>Berezina</b>, thawed and impassable, three Russian armies aimed to trap and finish it.',
      people='General <b>Éblé</b> and his <b>pontonniers</b>, who built and held the bridges at the cost of their lives; Marshals <b>Oudinot</b> and <b>Ney</b> holding the perimeter; the doomed mass of stragglers.',
      what='Napoleon feinted a crossing to the south, then threw <b>two trestle bridges</b> across the river to the north (26–29 Nov). The fighting core escaped; when the bridges were fired, <b>tens of thousands of stragglers</b> were abandoned or drowned.',
      crux='Even in ruin his <b>command machinery and engineering held</b> — deception plus disciplined sacrifice bought the army’s survival.',
      conseq='“Bérézina” entered French as a word for utter disaster — yet the army’s cadres survived to fight in 1813. Napoleon left days later for Paris to raise fresh armies.',
      matters='Leadership is tested most in catastrophe: the measure of a commander is not only how he wins but how much he saves when everything has gone wrong.'),

    E('germany1813', '1813', 'The German campaign — winning battles, losing the war', ['BATTLE', 'DEFEAT'],
      'He rebuilds an army from boys, wins fresh victories at Lützen and Bautzen and a huge one at Dresden — but with his cavalry gone and all Europe uniting, each win only delays the reckoning.',
      svg_row('Tactical wins that can’t reverse the strategy', [
          {'n': 1, 'label': 'A new army of conscripts', 'sub': 'raised fast; short of veteran cavalry', 'color': '#4338ca'},
          {'n': 2, 'label': 'Wins: Lützen, Bautzen, Dresden', 'sub': 'still beats the coalition in the field', 'color': '#16a34a'},
          {'n': 3, 'label': 'But allies avoid HIM', 'sub': 'the Trachenberg plan: beat his marshals, dodge him', 'color': '#dc2626'},
      ], edge_labels=['then', 'yet'], takeaway='He could still win battles — but the enemy learned to refuse him and beat his lieutenants instead.', accent=AC),
      bg='After Russia, Prussia rose and Austria wavered; a vast <b>Sixth Coalition</b> formed in 1813. Napoleon raised a fresh army — young, and critically short of the cavalry lost in Russia.',
      people='The allied monarchs and marshals — <b>Blücher, Schwarzenberg, Bernadotte</b> (his ex-marshal, now Sweden’s prince) — coordinating under the <b>Trachenberg Plan</b> to avoid Napoleon himself.',
      what='Napoleon won at <b>Lützen</b> and <b>Bautzen</b> (May 1813) and a big defensive victory at <b>Dresden</b> (August) — but couldn’t turn wins into decision without cavalry to pursue, while the allies beat his subordinates (Kulm, Katzbach, Dennewitz) and closed in.',
      crux='The coalition finally solved him: <b>don’t fight Napoleon directly; overwhelm his lieutenants and never let him concentrate</b>. His tactical genius couldn’t overcome the strategic arithmetic.',
      conseq='His forces shrank and were surrounded; the campaign converged on the decisive clash at Leipzig.',
      matters='Winning engagements isn’t winning the war. When the enemy adapts to avoid your strength, tactical brilliance only postpones defeat.'),

    E('leipzig', '16–19 Oct 1813', 'Leipzig — the Battle of the Nations', ['BATTLE', 'DEFEAT'],
      'Almost all of Europe converges on him at once in the largest battle in history before the World Wars. Outnumbered nearly two to one, with German allies defecting mid-battle, he is beaten and driven out of Germany.',
      svg_compare('Why 1813 was unwinnable', {
          'head': 'Napoleon in 1813', 'color': '#4338ca',
          'items': ['Army of raw conscripts', 'Cavalry never replaced after Russia', 'Fighting on every front', 'Allies deserting him']},
          {'head': 'The Sixth Coalition', 'color': '#dc2626',
           'items': ['Russia + Prussia + Austria + Sweden', 'British gold funding all of them', 'Learned his methods', 'Nearly 2:1 in numbers']},
          verdict='Everyone united; he stood almost alone — genius can’t close that gap.',
          takeaway='When the whole world allies against you, tactical brilliance only delays the arithmetic.', accent=AC),
      bg='By October 1813 the coalition armies converged on Napoleon around <b>Leipzig</b>, with numbers he could not match.',
      people='The allied commanders <b>Schwarzenberg, Blücher, Bernadotte</b>; the Saxon and other German troops who <b>defected mid-battle</b>.',
      what='At <b>Leipzig (16–19 Oct 1813)</b>, some 600,000 men fought the largest battle in European history to that point. Outnumbered and with allies changing sides during the fight, Napoleon was defeated and forced back across the Rhine (a blown bridge trapping his rearguard).',
      crux='Numbers, unity and British money beat manoeuvre. The coalition refused to give his genius a single target and simply overwhelmed him.',
      conseq='France lost Germany; the empire east of the Rhine collapsed; the war moved onto French soil.',
      matters='No individual, however gifted, beats a united world indefinitely. Coalitions win by refusing to give genius a single point to strike.'),

    E('sixdays', 'Feb 1814', 'The Six Days’ Campaign — brilliance in defeat', ['BATTLE', 'TRIUMPH'],
      'Outnumbered many times over on French soil, Napoleon fights perhaps his finest campaign — striking the converging Allied armies one by one and winning four battles in six days — a dazzling display that only delays the inevitable.',
      svg_row('Genius that could not change the arithmetic', [
          {'n': 1, 'label': 'Allies pour into France', 'sub': 'hundreds of thousands of men; Napoleon has a fraction', 'color': '#dc2626'},
          {'n': 2, 'label': 'Strike them separately', 'sub': 'Champaubert, Montmirail, Château-Thierry, Vauchamps', 'color': '#4338ca'},
          {'n': 3, 'label': 'Four wins in six days', 'sub': 'a textbook of the central position — but too few men', 'color': '#16a34a'},
      ], edge_labels=['answered by', 'and yet'], takeaway='His tactical genius was undimmed to the end — but no brilliance beats an enemy with ten times the reserves.', accent=AC),
      bg='By February 1814 the Allied armies of Blücher and Schwarzenberg had invaded France itself and were marching on Paris, vastly outnumbering Napoleon’s scraped-together forces of conscripts and veterans.',
      people='<b>Blücher</b>, whose over-extended Army of Silesia was the target; the boy conscripts (the “<b>Marie-Louises</b>”) who fought their hearts out; Marshals <b>Marmont</b> and <b>Mortier</b>.',
      what='In the <b>Six Days’ Campaign</b> (10–15 Feb 1814) Napoleon fell on Blücher’s strung-out columns and won at <b>Champaubert, Montmirail, Château-Thierry and Vauchamps</b> — mauling the Army of Silesia. But the other Allied army kept coming.',
      crux='He used the <b>central position</b> perfectly — interior lines to beat a divided enemy in detail — but had <b>too few troops</b> to exploit any victory decisively.',
      conseq='It is studied as one of the finest defensive campaigns in history — and it changed nothing: Paris fell in March, and he abdicated in April.',
      matters='Skill can win battles it cannot win wars — when the resource gap is wide enough, even genius only postpones the end.'),

    E('abdicate', '1814', 'The defence of France and the first abdication', ['BATTLE', 'DEFEAT', 'EXILE'],
      'Cornered in France, he fights one of his most brilliant campaigns against huge odds — but his marshals have had enough, Paris falls, and he abdicates. They exile him to Elba, a tiny island he is allowed to “rule.”',
      svg_stack('Brilliance, then the end of the road', [
          {'n': 1, 'label': 'The Six Days Campaign (Feb 1814)', 'sub': 'dazzling wins against the odds on home soil', 'color': '#4338ca'},
          {'n': 2, 'label': 'But the numbers never stop', 'sub': 'the allies march around him to Paris', 'color': '#dc2626'},
          {'n': 3, 'label': 'Paris falls; marshals refuse', 'sub': 'Ney & co. will not fight on', 'color': '#475569'},
          {'n': 4, 'label': 'Abdication → exile to Elba', 'sub': 'keeps the title “Emperor” of a tiny island', 'color': '#57534e'},
      ], takeaway='You can out-fight everyone and still lose when the people around you decide the war is over.', accent=AC),
      bg='In early 1814 allied armies poured into France. Napoleon, with a fraction of their numbers, defended the approaches to Paris.',
      people='Marshals <b>Ney, Marmont</b> and others — exhausted, unwilling to destroy France for him; <b>Talleyrand</b>, now working against him to restore the Bourbons.',
      what='His <b>1814 campaign</b> (the “Six Days”) produced a string of tactical masterpieces, but the allies ignored him and marched on <b>Paris, which fell on 31 March 1814</b>. With his marshals refusing to continue, Napoleon <b>abdicated (6/11 April 1814)</b>; the Treaty of Fontainebleau exiled him to <b>Elba</b> as its sovereign.',
      crux='Tactical genius couldn’t overcome <b>strategic exhaustion</b> — of France, his army, and the men who had followed him for twenty years. When your own side stops believing, the war is lost.',
      conseq='The empire ended; the Bourbons (Louis XVIII) returned. But leaving him a sovereign island 20 miles off Italy was a spectacular miscalculation.',
      matters='Wars end when will ends, not when options do. He still had moves; his people had run out of reasons.'),
]

# ==================================================================  PHASE 9 — THE END
PHASE_END = [
    E('hundreddays', 'Mar 1815', 'The flight of the eagle — return from Elba', ['RISE', 'POLITICS', 'TURNING POINT'],
      'He escapes Elba, lands in France, and walks toward Paris. The soldiers sent to arrest him defect to him instead. Without firing a shot, he is Emperor again — for one hundred days.',
      svg_row('Retaking a throne with charisma alone', [
          {'n': 1, 'label': 'Escapes Elba (Mar 1815)', 'sub': 'lands near Cannes with ~1,000 men', 'color': '#4338ca'},
          {'n': 2, 'label': '“Fire on your Emperor!”', 'sub': 'the 5th Regiment defects at Grenoble', 'color': '#16a34a'},
          {'n': 3, 'label': 'Louis XVIII flees; Paris falls', 'sub': 'no shot fired — the army is his again', 'color': '#7c3aed'},
      ], edge_labels=['then', 'so'], takeaway='Loyalty can be personal, not institutional — they came to arrest a fugitive and found their Emperor.', accent=AC),
      bg='The restored Bourbon king <b>Louis XVIII</b> was unpopular, and the army in particular missed Napoleon. Sensing his opening, Napoleon slipped his island guard and landed in southern France.',
      people='The soldiers sent to stop him — most famously at <b>Grenoble</b>; Marshal <b>Ney</b>, who promised to bring Napoleon back “in an iron cage” and then joined him.',
      what='Landing on <b>1 March 1815</b> with about a thousand men, Napoleon marched north. At Grenoble he walked up to the troops barring his way, opened his coat, and dared them to fire. They cheered and joined him. He entered <b>Paris on 20 March</b> as Louis XVIII fled — a bloodless reconquest, the <b>Hundred Days</b>.',
      crux='Two decades of shared glory had bound French soldiers to him <b>personally</b>. Institutions can be restored by treaty; loyalty like that cannot be legislated away. His legend was itself a weapon.',
      conseq='Europe declared him an outlaw and mobilised. He had power again but no time — he had to strike the nearest allied armies (British and Prussian) in Belgium before the rest arrived.',
      matters='A powerful enough story can move armies on its own. But charisma bought him a throne, not the numbers to keep it.'),

    E('ligny', '16 Jun 1815', 'Ligny and Quatre Bras — the last winning day', ['BATTLE'],
      'Opening the Waterloo campaign, he beats the Prussians at Ligny while Ney fights the British at Quatre Bras — his final battlefield victory, but he fails to finish the Prussians, and that failure is fatal.',
      svg_row('The flaw that seeds the disaster', [
          {'n': 1, 'label': 'Split the enemies', 'sub': 'strike between Wellington & Blücher in Belgium', 'color': '#4338ca'},
          {'n': 2, 'label': 'Beats Blücher at Ligny', 'sub': 'his last victory — but the Prussians retreat intact', 'color': '#16a34a'},
          {'n': 3, 'label': 'Fails to destroy or track them', 'sub': 'Blücher slips away to rejoin Wellington later', 'color': '#dc2626'},
      ], edge_labels=['then', 'but'], takeaway='A win that doesn’t finish the enemy isn’t enough — the un-destroyed Prussians would decide Waterloo.', accent=AC),
      bg='Facing British-led and Prussian armies in Belgium, Napoleon used his old formula: get between them and beat each separately. On <b>16 June 1815</b> he attacked the Prussians while Ney engaged the British.',
      people='<b>Blücher</b>, beaten but not broken at Ligny; Marshal <b>Ney</b>, who fought Wellington’s forces to a draw at <b>Quatre Bras</b>; Marshal <b>Grouchy</b>, soon sent to chase the Prussians.',
      what='Napoleon <b>beat the Prussians at Ligny</b> (his last victory) but they retreated in good order; Ney held the British at <b>Quatre Bras</b>. Crucially, the Prussians were <b>not destroyed and not effectively pursued</b>.',
      crux='The plan depended on <b>keeping the two armies apart and finishing one</b>. He won the battle but not the objective — the Prussians escaped intact to intervene two days later.',
      conseq='Grouchy was sent with 33,000 men to pin Blücher — and failed to. That undestroyed Prussian army would arrive on Napoleon’s flank at Waterloo.',
      matters='A victory that leaves the enemy able to fight again can be worse than none — it lulls you while the danger regroups.'),

    E('waterloo', '18 Jun 1815', 'Waterloo — the final defeat', ['BATTLE', 'DEFEAT', 'TURNING POINT'],
      'He nearly breaks Wellington’s army in Belgium — until the Prussians he failed to finish arrive on his flank at evening. The Guard breaks, the army routs, and "Waterloo" becomes a word for final ruin.',
      svg_waterloo(),
      bg='Facing <b>Wellington</b>’s British-led army on a ridge at Waterloo, Napoleon’s only hope was to smash it before <b>Blücher</b>’s Prussians — beaten at Ligny two days earlier — could arrive.',
      people='<b>The Duke of Wellington</b>, who held the ridge all day; <b>Blücher</b>, who marched his recovering army to the guns; Marshal <b>Grouchy</b>, who never stopped the Prussians; Marshal <b>Ney</b>, whose unsupported cavalry charges wore out.',
      what='On <b>18 June 1815</b>, Napoleon battered Wellington’s line all day but couldn’t break it. Grouchy never blocked the Prussians, who arrived on the French right in the evening. A last attack by the <b>Imperial Guard</b> was repulsed — and when the Guard fell back (“La Garde recule!”), the whole army routed.',
      crux='His method needed the enemies <b>divided</b>; Grouchy’s failure (rooted in Ligny) let Blücher return. The margin between near-win and total ruin was a few hours and one missing corps — and the strategy had no slack left.',
      conseq='The army was destroyed; the Hundred Days ended. Napoleon abdicated a second time (22 June 1815) and surrendered to the British.',
      matters='Great plans hang on one or two hinges. Identify the hinge and protect it — because when it fails, brilliance elsewhere won’t save you.'),

    E('sthelena', '1815–1821', 'St Helena — exile, memoir, and death', ['EXILE', 'DEATH', 'TRAGEDY'],
      'This time they take no chances: a speck of rock in the South Atlantic, 1,900 km from anywhere. There he spends six years dictating his memoirs — losing the wars but winning the legend — and dies at 51.',
      svg_stack('Losing the throne, winning the myth', [
          {'n': 1, 'label': 'Exiled to St Helena (1815)', 'sub': 'remote Atlantic island, closely guarded', 'color': '#57534e'},
          {'n': 2, 'label': 'Dictates his memoirs', 'sub': 'recasts himself as heir of the Revolution & of Europe', 'color': '#4338ca'},
          {'n': 3, 'label': 'Dies 5 May 1821, age 51', 'sub': 'stomach cancer (poisoning theories disputed)', 'color': '#111827'},
          {'n': 4, 'label': 'The legend outlives the empire', 'sub': 'return of his ashes (1840); the myth endures', 'color': '#7c3aed'},
      ], takeaway='He lost every throne but authored the story — and the story is what survived.', accent=AC),
      bg='After Waterloo, Europe would not risk a third act. Napoleon was exiled to <b>St Helena</b>, one of the most isolated islands on earth, under a strict British governor (<b>Hudson Lowe</b>).',
      people='<b>Hudson Lowe</b>, the resented jailer; the small loyal retinue (Las Cases, Montholon, Bertrand, Gourgaud) who transcribed his words into the <b>Mémorial de Sainte-Hélène</b>.',
      what='For six years he dictated his version of events, reframing his wars as the defence of the Revolution and a united Europe against reactionary kings. He <b>died on 5 May 1821, aged 51</b> — the medical consensus is <b>stomach cancer</b> (later arsenic theories are widely disputed and unproven). In <b>1840</b> his remains were returned to Paris to a hero’s tomb at Les Invalides.',
      crux='Denied any further action, he turned to <b>narrative</b> — and won there. The Mémorial made him a romantic, quasi-revolutionary hero rather than a defeated tyrant, seeding the “Napoleonic legend” that helped his nephew become emperor decades later.',
      conseq='Politically finished, he became culturally immortal: the archetype of the self-made man who reshaped the world by will alone — admired and warned against ever since.',
      matters='When you can no longer control events, control the story of them. He lost the empire and, from a prison rock, still authored how history would remember him.'),
]

OVERVIEW_HTML = """
<p class="ov-lead">In just over twenty years, an outsider from a recently-conquered island rose from junior artillery officer to <b>Emperor of the French</b>, fought more than fifty battles, redrew the map of Europe, wrote a legal code still used across the world — and then lost it all, twice, ending on a rock in the South Atlantic. This guide follows the whole arc in detail: not just Austerlitz and Waterloo, but the Italian campaign that made him, the sieges and manoeuvres, the reforms, and every turning point of the rise and the fall. It is the definitive study in <b>the rise, overreach, and fall of a single extraordinary will.</b></p>
<div class="ov-quote">“Ability is nothing without opportunity.”<span>— attributed to Napoleon; whatever its source, it reads like the thesis of his life</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Corsican outsider → the decisive man in a crisis (Toulon, Vendémiaire) → conquering general &amp; myth-maker (Italy: Lodi, Arcole, Rivoli; Egypt) → seizes the state (Brumaire) → rebuilds it (Marengo, the Code) → Emperor at his zenith (Ulm, Austerlitz, Jena, Friedland, Tilsit) → overreaches (Spain, the bloody wins at Aspern &amp; Wagram, Russia 1812) → is overwhelmed by a united Europe (Leipzig, the 1814 defence, Waterloo) → loses the throne but wins the legend (St Helena).</p>
<div class="ov-lbl">Why he still matters</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">⚖️</div><h4>The Napoleonic Code</h4><p>His civil code — equality before the law, secure property, careers open to talent — still underpins the legal systems of dozens of countries.</p></div>
  <div class="ov-card"><div class="i">♟️</div><h4>The art of the decisive</h4><p>The central position, speed, concentration, and shaping the enemy’s choices — studied in every war college since.</p></div>
  <div class="ov-card"><div class="i">🧗</div><h4>Merit over birth</h4><p>The archetype of the self-made man: proof that talent + timing + relentless will could topple an old order built on blood.</p></div>
  <div class="ov-card"><div class="i">⚠️</div><h4>The anatomy of overreach</h4><p>The clearest lesson in history on knowing when to stop — and what happens to those who can’t.</p></div>
</div>
<div class="ov-lbl">The nine chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Origins</b><small> 1769–93</small><p>Outsider boy, artillery officer, the door the Revolution opens.</p></div>
  <div><b>2 · The Rise</b><small> 1793–95</small><p>Toulon, the lean years, and Vendémiaire.</p></div>
  <div><b>3 · Italy</b><small> 1796–97</small><p>Montenotte, Lodi, Arcole, Rivoli, Campo Formio.</p></div>
  <div><b>4 · Egypt</b><small> 1798–99</small><p>The Pyramids, the Nile, Acre — glory and disaster.</p></div>
  <div><b>5 · Power</b><small> 1799–1804</small><p>Brumaire, Marengo, the Concordat, the Code.</p></div>
  <div><b>6 · Zenith</b><small> 1804–07</small><p>Crown, Trafalgar, Ulm, Austerlitz, Jena, Tilsit.</p></div>
  <div><b>7 · Overreach</b><small> 1808–12</small><p>Spain, Aspern, Wagram, the marriage, Russia.</p></div>
  <div><b>8 · The Fall</b><small> 1813–14</small><p>The German campaign, Leipzig, and Elba.</p></div>
  <div><b>9 · The End</b><small> 1815–21</small><p>The Hundred Days, Ligny, Waterloo, St Helena.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the mechanism, then six branches (background, key people, what happened, the crux, consequences, why it matters). Read the takeaway strip first, then quiz yourself. Use <b>Key Events</b> for dates, <b>Who’s Who</b> for the cast, and <b>Master Timeline</b> to see the whole life in one scroll.</p>
"""

WHO = [
    {'name': 'Joséphine de Beauharnais', 'role': 'first wife', 'color': '#db2777',
     'bio': 'A widow of the Revolution, older and worldly; the great love of his life. Married 1796, made Empress, divorced 1809–10 when she bore no heir.',
     'rel': 'His emotional anchor; the divorce for dynastic reasons is one of his life’s tragedies.'},
    {'name': 'Marie Louise of Austria', 'role': 'second wife', 'color': '#7c3aed',
     'bio': 'A Habsburg archduchess, daughter of Emperor Francis II — Napoleon’s former enemy. Married 1810; mother of his heir. She did not follow him into exile.',
     'rel': 'The royal marriage that gave him a son and, briefly, tied Austria to him.'},
    {'name': 'The King of Rome', 'role': 'son & heir', 'color': '#16a34a',
     'bio': 'Napoleon II, born 1811. Named King of Rome; never ruled. Raised in Austria after the fall, he died young (1832).',
     'rel': 'The heir he reshaped his marriage to produce — and could not pass an empire to.'},
    {'name': 'Talleyrand', 'role': 'foreign minister / survivor', 'color': '#475569',
     'bio': 'The supreme diplomat and turncoat: served the monarchy, the Revolution, Napoleon, then the restored Bourbons — betraying each when it suited France (and himself).',
     'rel': 'His most cunning minister, who eventually worked to bring him down.'},
    {'name': 'Joseph Fouché', 'role': 'minister of police', 'color': '#334155',
     'bio': 'The ruthless spymaster who ran Napoleon’s surveillance state — and, like Talleyrand, hedged his bets against the day his master fell.',
     'rel': 'The eyes and ears of the regime; loyal only as long as it lasted.'},
    {'name': 'Marshal Berthier', 'role': 'chief of staff', 'color': '#0891b2',
     'bio': 'The indispensable organiser who turned Napoleon’s ideas into marching orders for hundreds of thousands of men. His staff work made the speed possible.',
     'rel': 'The quiet engine behind every lightning campaign.'},
    {'name': 'Marshal Davout', 'role': 'best marshal', 'color': '#4338ca',
     'bio': 'The “Iron Marshal,” never defeated. Won the harder half of Jena–Auerstedt against double his numbers. The most reliably brilliant of his commanders.',
     'rel': 'His finest subordinate — proof of the talent his system promoted.'},
    {'name': 'Marshal Ney', 'role': '“bravest of the brave”', 'color': '#dc2626',
     'bio': 'Fearless and headstrong; commanded the rearguard out of Russia, defected to Napoleon in 1815, and led the doomed cavalry charges at Waterloo. Shot by the Bourbons after.',
     'rel': 'The embodiment of the personal loyalty Napoleon inspired — and its cost.'},
    {'name': 'Marshal Murat', 'role': 'cavalry / brother-in-law', 'color': '#b45309',
     'bio': 'His flamboyant cavalry commander and brother-in-law, made King of Naples. Peerless in a charge (Eylau), less so as a king; his defection in 1814 hurt.',
     'rel': 'His dashing cavalryman — and a king who abandoned him at the end.'},
    {'name': 'Duke of Wellington', 'role': 'nemesis (Britain)', 'color': '#166534',
     'bio': 'Arthur Wellesley: bled the French in Spain for years, then held the ridge at Waterloo until the Prussians came. The general who finally beat him.',
     'rel': 'The one opponent who beat him in the field — patiently, defensively.'},
    {'name': 'Horatio Nelson', 'role': 'nemesis (sea)', 'color': '#1d4ed8',
     'bio': 'Britain’s admiral: destroyed the French fleet at the Nile (1798), stranding the Egyptian army, and again at Trafalgar (1805), ending any invasion of Britain.',
     'rel': 'Denied him the sea — and thus the ability ever to finish Britain.'},
    {'name': 'Tsar Alexander I', 'role': 'Russia', 'color': '#7c3aed',
     'bio': 'Ally at Tilsit (1807), then enemy. His refusal to negotiate in 1812 — trading Moscow for the winter — destroyed the Grande Armée.',
     'rel': 'The friend-turned-enemy whose patience broke Napoleon in Russia.'},
    {'name': 'Blücher', 'role': 'Prussia', 'color': '#b91c1c',
     'bio': 'The relentless old Prussian field marshal. Beaten repeatedly but never quit — his march to Waterloo after being defeated days earlier sealed Napoleon’s fall.',
     'rel': 'The stubborn enemy whose arrival decided Waterloo.'},
    {'name': 'Archduke Charles', 'role': 'Austria’s best', 'color': '#57534e',
     'bio': 'The most capable Austrian commander, who inflicted Napoleon’s first personal defeat at Aspern-Essling (1809) before losing the bloody battle of Wagram.',
     'rel': 'The general who first proved Napoleon beatable in the field.'},
    {'name': 'Metternich', 'role': 'Austria’s architect', 'color': '#64748b',
     'bio': 'Austria’s foreign minister who arranged the Marie Louise marriage, then engineered Austria’s switch to the coalition and designed the post-Napoleon order at Vienna.',
     'rel': 'Bound Austria to him by marriage, then led it against him.'},
]

KEY_EVENTS = [
    ('15 Aug 1769', 'Born in Ajaccio, Corsica', 'A French subject by one year — the outsider’s origin.'),
    ('1785', 'Commissioned artillery officer', 'Chose the one arm open to talent over birth.'),
    ('Dec 1793', 'Siege of Toulon', 'His plan takes the port; promoted general at 24.'),
    ('5 Oct 1795', '13 Vendémiaire', '“Whiff of grapeshot” saves the Republic; national fame.'),
    ('Apr 1796', 'Montenotte / Mondovì', 'Splits the coalition; knocks Piedmont out in two weeks.'),
    ('10 May 1796', 'Bridge of Lodi', 'Reckless courage; “le petit caporal”; his myth begins.'),
    ('Nov 1796', 'Arcole', 'Beats off Austrian relief armies to keep the siege of Mantua.'),
    ('Jan 1797', 'Rivoli', 'Masterpiece of concentration; Mantua soon falls.'),
    ('Oct 1797', 'Treaty of Campo Formio', 'He dictates his own peace; becomes a political force.'),
    ('Jul 1798', 'Battle of the Pyramids', 'Smashes the Mamluks; brings scholars to Egypt.'),
    ('1 Aug 1798', 'Battle of the Nile', 'Nelson strands the army by destroying the fleet.'),
    ('1799', 'Siege of Acre fails', 'His first failure; he abandons the army and sails home.'),
    ('9–10 Nov 1799', 'Coup of 18 Brumaire', 'Overthrows the Directory; becomes First Consul.'),
    ('14 Jun 1800', 'Battle of Marengo', 'A near-defeat turned victory secures his rule.'),
    ('1801 / 1804', 'Concordat / Napoleonic Code', 'Peace with the Church; a legal code for the ages.'),
    ('2 Dec 1804', 'Coronation as Emperor', 'Crowns himself at Notre-Dame.'),
    ('Oct 1805', 'Ulm', 'Captures an Austrian army almost without a battle.'),
    ('21 Oct 1805', 'Trafalgar', 'Nelson wins the sea; invasion of Britain impossible.'),
    ('2 Dec 1805', 'Austerlitz', 'His masterpiece; the Third Coalition collapses.'),
    ('14 Oct 1806', 'Jena–Auerstedt; Berlin Decree', 'Prussia crushed; the Continental System begins.'),
    ('Feb 1807', 'Eylau', 'A ghastly, bloody draw against the Russians in the snow.'),
    ('Jun–Jul 1807', 'Friedland & Tilsit', 'Beats Russia; peace with Alexander — the zenith.'),
    ('1808', 'Spain / Peninsular War', 'The “Spanish ulcer”; Bailén cracks the myth.'),
    ('May 1809', 'Aspern-Essling', 'His first personal defeat in the field.'),
    ('Jul 1809', 'Wagram', 'Beats Austria a fourth time — by mass and firepower.'),
    ('1810–11', 'Marries Marie Louise; heir born', 'Secures a dynasty just before losing the throne.'),
    ('Jun–Dec 1812', 'Russian campaign', '~half a million men reduced to ~25,000.'),
    ('1813', 'Lützen, Bautzen, Dresden, Leipzig', 'Wins battles, then is overwhelmed at Leipzig.'),
    ('6/11 Apr 1814', 'First abdication → Elba', 'Brilliant last campaign; exile to a tiny island.'),
    ('1 Mar 1815', 'Return from Elba (Hundred Days)', 'The army defects to him; retakes power without a shot.'),
    ('16 Jun 1815', 'Ligny & Quatre Bras', 'His last victory — but the Prussians escape intact.'),
    ('18 Jun 1815', 'Waterloo', 'The Prussians arrive; the Guard breaks; final defeat.'),
    ('5 May 1821', 'Dies on St Helena, aged 51', 'Stomach cancer; the legend outlives the empire.'),
]

MASTER = [
    {'year': '1769', 'age': 'born', 'phase': 'Origins', 'title': 'Born in Corsica', 'desc': 'An outsider to the France he would rule.'},
    {'year': '1793', 'age': 'age 24', 'phase': 'The Rise', 'title': 'Toulon', 'desc': 'One insight makes him a general.'},
    {'year': '1795', 'age': 'age 26', 'phase': 'The Rise', 'title': '13 Vendémiaire', 'desc': 'Saves the Republic; meets Joséphine.'},
    {'year': '1796', 'age': 'age 26', 'phase': 'Italy', 'title': 'Army of Italy', 'desc': 'Lodi, Arcole, Rivoli — beats bigger armies by speed.'},
    {'year': '1798', 'age': 'age 28', 'phase': 'Egypt', 'title': 'Egypt & the Nile', 'desc': 'Land victory, naval disaster; escapes home.'},
    {'year': '1799', 'age': 'age 30', 'phase': 'Power', 'title': '18 Brumaire', 'desc': 'Seizes the state; First Consul.'},
    {'year': '1800', 'age': 'age 30', 'phase': 'Power', 'title': 'Marengo', 'desc': 'A narrow win secures his rule.'},
    {'year': '1804', 'age': 'age 34', 'phase': 'Power', 'title': 'The Code & the Crown', 'desc': 'Napoleonic Code; crowns himself Emperor.'},
    {'year': '1805', 'age': 'age 36', 'phase': 'Zenith', 'title': 'Ulm, Trafalgar & Austerlitz', 'desc': 'Loses the sea, then wins his masterpiece.'},
    {'year': '1806', 'age': 'age 37', 'phase': 'Zenith', 'title': 'Jena; Continental System', 'desc': 'Prussia crushed; the fateful embargo.'},
    {'year': '1807', 'age': 'age 37', 'phase': 'Zenith', 'title': 'Eylau, Friedland & Tilsit', 'desc': 'A bloody draw, then peace at the empire’s peak.'},
    {'year': '1808', 'age': 'age 38', 'phase': 'Overreach', 'title': 'Spain', 'desc': 'The guerrilla war that never heals.'},
    {'year': '1809', 'age': 'age 39', 'phase': 'Overreach', 'title': 'Aspern & Wagram', 'desc': 'His first defeat, then a costly win.'},
    {'year': '1810', 'age': 'age 40', 'phase': 'Overreach', 'title': 'Habsburg marriage', 'desc': 'Divorces Joséphine; weds Marie Louise; heir in 1811.'},
    {'year': '1812', 'age': 'age 42', 'phase': 'Overreach', 'title': 'Russia', 'desc': 'The Grande Armée destroyed by space and winter.'},
    {'year': '1813', 'age': 'age 44', 'phase': 'The Fall', 'title': 'Leipzig', 'desc': 'A united Europe drives him from Germany.'},
    {'year': '1814', 'age': 'age 44', 'phase': 'The Fall', 'title': 'Abdication → Elba', 'desc': 'Brilliant last campaign; exile to a tiny island.'},
    {'year': '1815', 'age': 'age 45', 'phase': 'The End', 'title': 'Hundred Days → Waterloo', 'desc': 'Returns, reigns 100 days, falls for good.'},
    {'year': '1821', 'age': 'age 51', 'phase': 'The End', 'title': 'Death on St Helena', 'desc': 'Loses the wars; wins the legend.'},
]

SOURCES = [
    ('Britannica — Napoleon I', 'https://www.britannica.com/biography/Napoleon-I'),
    ('World History Encyclopedia — Napoleon', 'https://www.worldhistory.org/Napoleon_Bonaparte/'),
    ('napoleon.org (Fondation Napoléon)', 'https://www.napoleon.org/en/'),
    ('McGill Napoleon Collection — Timeline', 'https://digital.library.mcgill.ca/napoleon/english/timeline-full.htm'),
    ('Britannica — Battle of Austerlitz', 'https://www.britannica.com/event/Battle-of-Austerlitz'),
    ('Britannica — Battle of Waterloo', 'https://www.britannica.com/event/Battle-of-Waterloo'),
    ('Wikipedia — Napoleon', 'https://en.wikipedia.org/wiki/Napoleon'),
]

def build_meta():
    return {
        'pid': 'gm-napoleon.html', 'kind': 'man', 'emoji': '🇫🇷', 'accent': AC,
        'name': 'Napoleon Bonaparte', 'years': '1769–1821', 'group': 'European Greats',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'From a Corsican outsider to Emperor of the French — and back to a rock in the Atlantic. Every major battle and turning point, from Toulon to Waterloo, in depth.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'origins', 'label': '1 · Origins', 'type': 'timeline',
             'intro': 'An outsider from a just-conquered island, trained in the one arm open to talent — as the Revolution tears down the old ladder of birth.', 'events': PHASE_ORIGINS},
            {'id': 'rise', 'label': '2 · The Rise', 'type': 'timeline',
             'intro': 'Toulon makes him a general; lean, dangerous years follow; then the guns of Vendémiaire make him the Republic’s indispensable sword.', 'events': PHASE_RISE},
            {'id': 'italy', 'label': '3 · Italy', 'type': 'timeline',
             'intro': 'Handed a ragged army, he splits the enemy coalition and wins a lightning campaign — Lodi, Arcole, Rivoli — that makes his legend and his fortune.', 'events': PHASE_ITALY},
            {'id': 'egypt', 'label': '4 · Egypt', 'type': 'timeline',
             'intro': 'He gambles on Egypt to strike at Britain and dazzle France — wins on land, loses his fleet to Nelson, stalls at Acre, and escapes home just in time.', 'events': PHASE_EGYPT},
            {'id': 'power', 'label': '5 · Power', 'type': 'timeline',
             'intro': 'A two-day coup makes him ruler; a near-disaster at Marengo secures him; then he rebuilds France itself — the Concordat and the Code that outlived his empire.', 'events': PHASE_POWER},
            {'id': 'zenith', 'label': '6 · Zenith', 'type': 'timeline',
             'intro': 'Emperor. He loses the sea at Trafalgar but captures an army at Ulm, wins his masterpiece at Austerlitz, crushes Prussia, and stands astride the Continent at Tilsit.', 'events': PHASE_ZENITH},
            {'id': 'overreach', 'label': '7 · Overreach', 'type': 'timeline',
             'intro': 'From the summit, every war is one he chose. Spain becomes an ulcer; Austria bloodies him at Aspern before Wagram; a Habsburg marriage secures an heir; and the road leads to Moscow.', 'events': PHASE_OVERREACH},
            {'id': 'fall', 'label': '8 · The Fall', 'type': 'timeline',
             'intro': 'A united Europe closes in. He still wins battles in Germany but is overwhelmed at Leipzig; a brilliant last stand in France ends in abdication and exile to Elba.', 'events': PHASE_FALL},
            {'id': 'end', 'label': '9 · The End', 'type': 'timeline',
             'intro': 'He escapes, reigns a hundred days, wins one last time at Ligny — then stakes everything on Waterloo. Defeat ends the empire; St Helena begins the legend.', 'events': PHASE_END,
             'sources': SOURCES, 'srcnote': 'Where accounts are dramatised (the self-coronation, the “whiff of grapeshot”, Marengo’s rewritten dispatch) or disputed (the arsenic-poisoning theory), this guide flags the documented version.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
