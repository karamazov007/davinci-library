# -*- coding: utf-8 -*-
"""Full, DEEP guide content for Guru Gobind Singh, the tenth Sikh Guru.
The warrior-saint and poet who founded the Khalsa and sealed the scripture as the eternal Guru.
Presented reverently and neutrally, following the Sikh tradition’s account and the historical record."""
from engine import svg_row, svg_stack, svg_compare, _wrap, _tspans, esc

AC = '#1e40af'  # Khalsa blue

def E(id, time, title, tags, summary, svg, bg, people, what, crux, conseq, matters, toc=None):
    return {'id': id, 'time': time, 'title': title, 'tags': tags, 'summary': summary, 'svg': svg,
            'toc': toc or title,
            'branches': {'bg': bg, 'people': people, 'what': what, 'crux': crux, 'conseq': conseq, 'matters': matters}}

# ==================================================================  PHASE 1 — BIRTH AND GURUSHIP
PHASE_EARLY = [
    E('patna', '1666', 'Born in Patna — a child of the Guru line', ['ORIGINS', 'BIRTH'],
      'Gobind Das is born in Patna in 1666, the only son of the ninth Sikh Guru, Guru Tegh Bahadur, into the sacred lineage begun by Guru Nanak — a childhood steeped in devotion, languages and the martial arts that would mark the whole of his life.',
      svg_row('A son of the Guru lineage', [
          {'n': 1, 'label': 'Born at Patna, 1666', 'sub': 'named Gobind Das, later Gobind Rai', 'color': '#1e40af'},
          {'n': 2, 'label': 'Son of Guru Tegh Bahadur', 'sub': 'ninth in the line of Guru Nanak', 'color': '#166534'},
          {'n': 3, 'label': 'Raised in devotion and arms', 'sub': 'scripture, languages and martial skill', 'color': '#a16207'},
      ], edge_labels=['heir to', 'trained in'], takeaway='Born into the sacred line of Guru Nanak, the child was raised alike in faith and in the arts of the warrior.', accent=AC),
      bg='<b>Guru Gobind Singh</b> was born Gobind Das (later Gobind Rai) at Patna in 1666, into the house of the Sikh Gurus that descended from Guru Nanak.',
      people='his father <b>Guru Tegh Bahadur</b>, the ninth Guru; his mother <b>Mata Gujri</b>; the community of Sikhs (the Panth).',
      what='The future tenth Guru spent his early years at Patna and then Anandpur, schooled in <b>Gurmukhi, Persian and Sanskrit</b> and in <b>horsemanship, archery and swordsmanship</b> alongside the study of scripture.',
      crux='From the first he was formed by a <b>double inheritance</b> — the spiritual devotion of the Guru line and a training for the field of battle.',
      conseq='This upbringing prepared him to lead the Sikhs through the ordeal that was about to fall upon his family.',
      matters='The warrior-saint was shaped early — faith and arms held together in one life from childhood.'),

    E('teghbahadur', '1675', 'The martyrdom of his father — a stand for religious freedom', ['ORIGINS', 'TRAGEDY', 'TURNING POINT'],
      'When Kashmiri Hindus appeal for protection against forced conversion, Guru Tegh Bahadur travels to Delhi and is executed on the orders of the Mughal emperor Aurangzeb for defending the freedom of others to worship — a martyrdom that the Sikh tradition remembers as a sacrifice for the conscience of all.',
      svg_stack('A martyrdom for the freedom to worship', [
          {'n': 1, 'label': 'An appeal for protection', 'sub': 'Kashmiri Hindus face forced conversion', 'color': '#a16207'},
          {'n': 2, 'label': 'Guru Tegh Bahadur stands firm', 'sub': 'he goes to Delhi to defend their faith', 'color': '#166534'},
          {'n': 3, 'label': 'Executed on Aurangzeb’s order, 1675', 'sub': 'martyred for the right to worship freely', 'color': '#b91c1c'},
      ], takeaway='His father gave his life so that others might worship as they chose — a sacrifice remembered for the conscience of all.', accent=AC),
      bg='Under the emperor <b>Aurangzeb</b>, pressure to convert to Islam fell heavily on non-Muslims. A delegation of Kashmiri Pandits sought the ninth Guru’s help.',
      people='<b>Guru Tegh Bahadur</b>, the martyred father; the emperor <b>Aurangzeb</b>; the Kashmiri Hindus who appealed for aid.',
      what='In <b>1675</b> Guru Tegh Bahadur was <b>executed at Delhi on Aurangzeb’s order</b> for refusing to convert and for defending the right of others to their own faith — a death the Sikh tradition honours as a martyrdom for religious freedom.',
      crux='It set the theme of the son’s whole life — the defence of <b>freedom of conscience</b>, held dearer than life itself.',
      conseq='The nine-year-old Gobind was left to succeed his father as Guru in a time of mortal danger.',
      matters='A martyrdom for the freedom of others became the seed of the son’s mission — to arm the faithful to defend that freedom.'),

    E('guruatnine', '1676', 'Guru at nine — succeeding to a perilous throne', ['ORIGINS', 'TURNING POINT'],
      'At just nine years of age, Gobind Rai is installed as the tenth Sikh Guru, inheriting the spiritual leadership of a community grieving its martyred master and facing the hostility of the Mughal state — and he begins, patiently, to prepare the Sikhs in both spirit and arms.',
      svg_row('The boy who became the tenth Guru', [
          {'n': 1, 'label': 'Installed Guru at nine', 'sub': 'succeeds his martyred father, 1676', 'color': '#1e40af'},
          {'n': 2, 'label': 'A community in danger', 'sub': 'the Sikhs mourn and stand exposed', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Prepares spirit and arms', 'sub': 'writes, teaches and builds strength at Anandpur', 'color': '#166534'},
      ], edge_labels=['amid', 'so'], takeaway='A child inherited the leadership of a threatened people — and set about strengthening them in both devotion and defence.', accent=AC),
      bg='After his father’s martyrdom, the young Gobind Rai became the <b>tenth Guru in 1676</b>, leading from Anandpur in the Shivalik hills.',
      people='the young <b>Guru Gobind</b> himself; his mother <b>Mata Gujri</b>; the Sikh community he now led; the surrounding hill rajas.',
      what='Installed as Guru at the age of <b>nine</b>, Gobind Rai grew into his leadership at Anandpur, composing devotional and heroic poetry and <b>preparing the Sikhs to defend themselves</b> against gathering hostility.',
      crux='He understood that faith alone would not survive without the strength to protect it — <b>devotion and readiness</b> must go together.',
      conseq='This long preparation would culminate, in 1699, in the founding of the Khalsa.',
      matters='Leadership fell to him as a child — and he answered it by forging a community able to stand for its beliefs.'),
]

# ==================================================================  PHASE 2 — THE BIRTH OF THE KHALSA
PHASE_KHALSA = [
    E('vaisakhi', '1699', 'Vaisakhi 1699 — the call at Anandpur', ['KHALSA', 'TURNING POINT', 'TRIUMPH'],
      'On the festival of Vaisakhi in 1699, before a great gathering at Anandpur, Guru Gobind Singh issues a startling call — drawing his sword and asking who among the Sikhs will give his head for his faith — a test of devotion that becomes the founding moment of the Khalsa.',
      svg_stack('The founding call of the Khalsa', [
          {'n': 1, 'label': 'A great gathering, Vaisakhi 1699', 'sub': 'Sikhs assemble at Anandpur', 'color': '#1e40af'},
          {'n': 2, 'label': 'The Guru asks for a head', 'sub': 'who will give his life for his faith?', 'color': '#b91c1c'},
          {'n': 3, 'label': 'The birth of the Khalsa', 'sub': 'a pure order of the committed faithful', 'color': '#166534'},
      ], takeaway='With a single searching demand, the Guru called forth those willing to give everything — and founded the Khalsa.', accent=AC),
      bg='By <b>1699</b> Guru Gobind Singh had gathered the Sikhs at <b>Anandpur</b>. On <b>Vaisakhi</b>, the spring festival, he summoned a vast assembly.',
      people='<b>Guru Gobind Singh</b>; the assembled Sikh congregation; the five who would answer his call.',
      what='At the gathering the Guru drew his sword and <b>asked who would offer his head</b> for the faith. The dramatic test of commitment became the <b>founding of the Khalsa</b> — the community of the initiated pure.',
      crux='He sought not numbers but <b>total devotion</b> — a core of Sikhs ready to give their lives for their faith and for the defenceless.',
      conseq='Five men rose to answer — and became the Panj Pyare, the first of the Khalsa.',
      matters='The Khalsa was born from a demand for complete commitment — faith proven by the willingness to sacrifice all.'),

    E('panjpyare', '1699', 'The Panj Pyare and the amrit — the five beloved ones', ['KHALSA', 'REFORM'],
      'Five Sikhs step forward one by one to offer their lives, and the Guru initiates them as the Panj Pyare, the five beloved ones — administering amrit, sweetened water stirred with a double-edged sword, in the first Khalsa initiation, and then, remarkably, receiving the same initiation from them in turn.',
      svg_row('The first initiation of the Khalsa', [
          {'n': 1, 'label': 'Five step forward', 'sub': 'the Panj Pyare offer their lives', 'color': '#166534'},
          {'n': 2, 'label': 'The amrit ceremony', 'sub': 'sweet water stirred with a double-edged sword', 'color': '#1e40af'},
          {'n': 3, 'label': 'The Guru is initiated too', 'sub': 'he receives amrit from the five in turn', 'color': '#a16207'},
      ], edge_labels=['through', 'and'], takeaway='The five beloved ones were made the first of the Khalsa — and the Guru knelt to be initiated by them, a master made one with his disciples.', accent=AC),
      bg='Five Sikhs answered the Guru’s call at Anandpur, offering their heads. He initiated them as the <b>Panj Pyare</b> — the five beloved ones.',
      people='the <b>Panj Pyare</b> — Daya Singh, Dharam Singh, Himmat Singh, Mohkam Singh and Sahib Singh; <b>Guru Gobind Singh</b> himself.',
      what='The Guru administered <b>amrit</b> — water and sugar stirred with a <b>double-edged sword (khanda)</b> — in the first Khalsa initiation, then had the five initiate <b>him</b> in the same rite, binding Guru and disciple as one.',
      crux='He made the Khalsa a <b>brotherhood of equals</b>, dissolving distinctions of caste and even the distance between Guru and follower.',
      conseq='The initiated were given a new identity, a code of conduct, and the outward form of the Khalsa.',
      matters='The initiation forged a community of equals bound by shared vows — and a leader who counted himself one of them.'),

    E('fiveks', '1699', 'The Five Ks and the names Singh and Kaur', ['KHALSA', 'REFORM'],
      'The Guru gives the Khalsa its lasting form — the five articles of faith known as the Five Ks, worn as a visible commitment, and new shared names: Singh, meaning lion, for the men, and Kaur, meaning princess, for the women — a single family sworn to faith, equality and courage.',
      svg_row('A visible identity for the faithful', [
          {'n': 1, 'label': 'The Five Ks', 'sub': 'kesh, kangha, kara, kirpan, kachera', 'color': '#1e40af'},
          {'n': 2, 'label': 'Singh and Kaur', 'sub': '“lion” for men, “princess” for women', 'color': '#166534'},
          {'n': 3, 'label': 'One equal family', 'sub': 'caste dissolved; men and women dignified', 'color': '#a16207'},
      ], edge_labels=['and', 'making'], takeaway='Uniform in dress and name, the Khalsa became one visible family — equal, dignified, and unmistakable in its faith.', accent=AC),
      bg='Having created the Khalsa, the Guru gave it an <b>enduring form and discipline</b> that every initiated Sikh would carry.',
      people='the initiated men and women of the <b>Khalsa</b>; <b>Guru Gobind Singh</b>, its founder and lawgiver.',
      what='He ordained the <b>Five Ks</b> — <b>kesh</b> (uncut hair), <b>kangha</b> (a comb), <b>kara</b> (a steel bracelet), <b>kirpan</b> (a sword) and <b>kachera</b> (breeches) — and gave men the name <b>Singh</b> (“lion”) and women <b>Kaur</b> (“princess”).',
      crux='He clothed the faith in a <b>visible, shared identity</b> — abolishing caste names and raising the dignity of women along with men.',
      conseq='The Khalsa identity endures to this day as the defining outward form of the initiated Sikh.',
      matters='A shared name and dress turned a movement into a lasting people — equal, recognisable, and proud.'),
]

# ==================================================================  PHASE 3 — THE WARS AND THE SACRIFICE
PHASE_WARS = [
    E('anandpur', '1700–1704', 'The battles of Anandpur — the hills close in', ['BATTLE', 'TRAGEDY'],
      'The rising strength of the Khalsa alarms the neighbouring hill rajas, who, joined by Mughal forces, besiege Anandpur repeatedly — until, worn down by a long blockade and false promises of safe passage, the Guru is at last forced to abandon the city.',
      svg_stack('The long siege of Anandpur', [
          {'n': 1, 'label': 'The hill rajas take alarm', 'sub': 'they fear the growing Khalsa', 'color': '#a16207'},
          {'n': 2, 'label': 'Joined by Mughal forces', 'sub': 'repeated sieges of Anandpur', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Forced to leave, 1704', 'sub': 'a blockade and broken promises of safe passage', 'color': '#78350f'},
      ], takeaway='Besieged by hill kings and Mughal armies alike, the Guru held Anandpur through long sieges before a broken truce forced him out.', accent=AC),
      bg='The growth of the Khalsa alarmed the <b>Rajas of the Shivalik hills</b>, who allied with the <b>Mughal authorities</b> against Anandpur.',
      people='the <b>hill rajas</b>; the <b>Mughal commanders</b> of the Punjab; the defenders of the Khalsa; <b>Guru Gobind Singh</b>.',
      what='Through the early 1700s Anandpur was <b>besieged repeatedly</b>. In <b>1704</b>, after a prolonged blockade and <b>promises of safe passage that were not kept</b>, the Guru evacuated the city under attack.',
      crux='The Guru’s enemies could not defeat the Khalsa in open battle, and so turned to <b>siege, attrition and broken oaths</b>.',
      conseq='The retreat from Anandpur led directly to the disasters at the Sirsa river, Chamkaur and Sirhind.',
      matters='A cause that could not be beaten in the field was pressed instead by siege and treachery — and the heaviest losses followed the retreat.'),

    E('chamkaur', '1704', 'Chamkaur — the elder sons fall', ['BATTLE', 'TRAGEDY', 'DEATH'],
      'Pursued after the evacuation and separated from much of his family at the flooded Sirsa river, the Guru makes a stand at Chamkaur with a mere handful of Sikhs against a great host — and there his two elder sons, Ajit Singh and Jujhar Singh, fall in battle, giving their lives before their father’s eyes.',
      svg_stack('The stand at Chamkaur', [
          {'n': 1, 'label': 'Scattered at the Sirsa river', 'sub': 'the family is separated in the retreat', 'color': '#78350f'},
          {'n': 2, 'label': 'A last stand at Chamkaur', 'sub': 'a handful of Sikhs against a great army', 'color': '#1e40af'},
          {'n': 3, 'label': 'The elder sons fall, 1704', 'sub': 'Ajit Singh and Jujhar Singh martyred', 'color': '#b91c1c'},
      ], takeaway='At Chamkaur a few faced thousands — and the Guru’s two elder sons gave their lives before his eyes.', accent=AC),
      bg='After leaving Anandpur, the Guru’s party was scattered crossing the flooded <b>Sirsa river</b> and pursued to the mud fortress of <b>Chamkaur</b>.',
      people='the elder sons <b>Ajit Singh</b> and <b>Jujhar Singh</b>; the small band of defenders; the pursuing army; <b>Guru Gobind Singh</b>.',
      what='At <b>Chamkaur in December 1704</b>, a tiny band of Sikhs held out against overwhelming numbers. The Guru’s <b>two elder sons, Ajit Singh and Jujhar Singh, were killed in the fighting</b>.',
      crux='Even in a hopeless stand, the Khalsa fought on — and the Guru’s own sons died as ordinary soldiers of the faith.',
      conseq='The Guru escaped Chamkaur at his followers’ insistence, but worse news awaited from Sirhind.',
      matters='The founder of the Khalsa asked no exemption for his own family — his elder sons fell as martyrs like any other Sikh.'),

    E('sirhind', '1704', 'Sirhind — the younger sons bricked alive', ['TRAGEDY', 'DEATH'],
      'The Guru’s two youngest sons, Zorawar Singh and Fateh Singh, children of seven and five, are captured with their grandmother Mata Gujri and brought before the governor of Sirhind — and when they refuse to abandon their faith, they are bricked alive, a martyrdom the Sikh tradition remembers with deepest sorrow and reverence.',
      svg_stack('The martyrdom of the youngest sons', [
          {'n': 1, 'label': 'Captured with Mata Gujri', 'sub': 'the youngest sons taken to Sirhind', 'color': '#78350f'},
          {'n': 2, 'label': 'Ordered to convert', 'sub': 'the children refuse to abandon their faith', 'color': '#a16207'},
          {'n': 3, 'label': 'Bricked alive, 1704', 'sub': 'Zorawar Singh and Fateh Singh martyred', 'color': '#b91c1c'},
      ], takeaway='Two small children chose their faith over their lives — a martyrdom the Khalsa holds among its most sacred memories.', accent=AC),
      bg='In the same retreat the Guru’s <b>two youngest sons</b> and his mother, <b>Mata Gujri</b>, were captured and taken to the governor at <b>Sirhind</b>.',
      people='the younger sons <b>Zorawar Singh</b> and <b>Fateh Singh</b>; their grandmother <b>Mata Gujri</b>; <b>Wazir Khan</b>, the governor of Sirhind.',
      what='The two boys, aged about <b>seven and five</b>, were pressed to convert to Islam. When they refused, they were <b>bricked alive at Sirhind (December 1704)</b>; Mata Gujri died soon after.',
      crux='The youngest of the Guru’s family met death rather than renounce their faith — the tradition’s supreme example of steadfastness.',
      conseq='Within days the Guru had lost all four of his sons, yet he did not waver in his mission.',
      matters='The martyrdom of two small children became an enduring emblem of faith held firm in the face of death.'),
]

# ==================================================================  PHASE 4 — THE VICTORY LETTER AND THE SCRIPTURE
PHASE_LETTER = [
    E('muktsar', '1705', 'Muktsar — the forty liberated ones', ['BATTLE', 'TRIUMPH'],
      'At Muktsar the Guru fights his last great battle, where a band of Sikhs who had earlier deserted him return to die in his defence — and the Guru, honouring their sacrifice, blesses them as the Chali Mukte, the forty liberated ones, tearing up the note in which they had renounced him.',
      svg_stack('The last great battle and the forty freed', [
          {'n': 1, 'label': 'Deserters return, 1705', 'sub': 'forty who had left come back to fight', 'color': '#a16207'},
          {'n': 2, 'label': 'The battle of Muktsar', 'sub': 'they die defending the Guru', 'color': '#1e40af'},
          {'n': 3, 'label': 'The Chali Mukte', 'sub': 'blessed as the forty liberated ones', 'color': '#166534'},
      ], takeaway='Forty who had abandoned the Guru returned to die for him — and he blessed them as the forty liberated ones.', accent=AC),
      bg='In <b>1705</b> the Guru fought at <b>Khidrana</b>, later called <b>Muktsar</b> — his final major battle against pursuing Mughal forces.',
      people='the <b>forty Sikhs</b> who had deserted and returned; their leader <b>Mai Bhago</b>, who rallied them; <b>Guru Gobind Singh</b>.',
      what='A band of Sikhs who had earlier deserted the Guru returned and <b>fell fighting in his defence at Muktsar</b>. The Guru honoured them as the <b>Chali Mukte</b> — the “forty liberated ones” — and tore up their letter of disavowal.',
      crux='He met repentance with <b>grace</b>, granting the returning deserters redemption through their sacrifice.',
      conseq='After Muktsar the Guru withdrew south to rest and to set down his affairs, including his letter to Aurangzeb.',
      matters='Even those who had faltered found redemption in the Khalsa — devotion proven in the end was honoured, not condemned.'),

    E('zafarnama', '1705', 'The Zafarnama — a letter of victory to Aurangzeb', ['POLITICS', 'REFORM'],
      'From the Deccan the Guru composes the Zafarnama, the "epistle of victory" — a fearless Persian verse letter to the emperor Aurangzeb that rebukes him for the broken oaths of his commanders, asserts the justice of the Guru’s cause, and declares that a righteous struggle is not defeated by the loss of battles.',
      svg_row('The fearless letter to the emperor', [
          {'n': 1, 'label': 'Written to Aurangzeb', 'sub': 'a Persian verse letter from the Deccan', 'color': '#1e40af'},
          {'n': 2, 'label': 'Rebukes broken oaths', 'sub': 'condemns the treachery at Anandpur', 'color': '#b91c1c'},
          {'n': 3, 'label': 'Asserts a righteous cause', 'sub': 'the “epistle of victory” of the just', 'color': '#166534'},
      ], edge_labels=['that', 'and'], takeaway='In fearless verse the Guru told the emperor that treachery, not the sword, had been used against him — and that a just cause is never truly defeated.', accent=AC),
      bg='After the losses of 1704–05, the Guru wrote to the emperor <b>Aurangzeb</b> a defiant letter in Persian verse, the <b>Zafarnama</b>.',
      people='the emperor <b>Aurangzeb</b>, its recipient; <b>Guru Gobind Singh</b>, its author; the commanders whose broken oaths it condemned.',
      what='The <b>Zafarnama</b> (“epistle of victory”) <b>rebuked Aurangzeb</b> for the broken promises of his officers, upheld the <b>justice of the Guru’s cause</b>, and declared that the loss of battles had not defeated a righteous struggle.',
      crux='He answered military defeat with a <b>moral victory</b> — asserting that right, not force, would stand in the end.',
      conseq='The letter is said to have moved Aurangzeb; the Guru later travelled south during the succession that followed the emperor’s death.',
      matters='A defeated army can still hold the moral high ground — the Zafarnama turned the language of victory against the victor.'),

    E('scripture', '1705–1706', 'Sealing the scripture at Damdama Sahib', ['REFORM', 'SCRIPTURE'],
      'At Damdama Sahib the Guru turns to the sacred word, preparing a definitive recension of the Adi Granth — the Sikh scripture — adding the hymns of his martyred father, Guru Tegh Bahadur, in a labour that fixes the text the Sikhs would revere as the living voice of the Gurus.',
      svg_stack('Fixing the sacred word', [
          {'n': 1, 'label': 'Rest at Damdama Sahib', 'sub': 'a place of study after the wars', 'color': '#166534'},
          {'n': 2, 'label': 'A definitive recension', 'sub': 'the Adi Granth prepared anew', 'color': '#1e40af'},
          {'n': 3, 'label': 'His father’s hymns added', 'sub': 'the compositions of Guru Tegh Bahadur', 'color': '#a16207'},
      ], takeaway='At Damdama Sahib the Guru fixed the sacred text, weaving in his martyred father’s hymns — the scripture that would become the eternal Guru.', accent=AC),
      bg='At <b>Damdama Sahib</b> (Talwandi Sabo), a place of rest and study, the Guru devoted himself to the <b>Sikh scripture</b>.',
      people='<b>Guru Gobind Singh</b>; the scribe <b>Bhai Mani Singh</b> by tradition; the words of <b>Guru Tegh Bahadur</b> and the earlier Gurus.',
      what='The Guru prepared a <b>definitive recension of the Adi Granth</b>, incorporating the <b>hymns of his father Guru Tegh Bahadur</b> — establishing the text that Sikhs revere. His own compositions form the separate <b>Dasam Granth</b>.',
      crux='He set the scripture in <b>final, authoritative form</b> — a treasury of the Gurus’ word that could stand in place of a living Guru.',
      conseq='This finalised scripture would, in 1708, be declared the eternal Guru of the Sikhs.',
      matters='By fixing the sacred word, he prepared for a faith guided forever by scripture rather than by any one man.'),
]

# ==================================================================  PHASE 5 — THE ETERNAL GURU
PHASE_ETERNAL = [
    E('nanded', '1707–1708', 'To the Deccan — the road to Nanded', ['POLITICS', 'JOURNEY'],
      'After Aurangzeb’s death the Guru travels south to Nanded on the Godavari, meeting the new emperor Bahadur Shah amid the Mughal succession — and there, far from the Punjab, he gathers his community and prepares the Sikhs for a future without a human Guru.',
      svg_row('The last journey south', [
          {'n': 1, 'label': 'Aurangzeb dies, 1707', 'sub': 'a Mughal succession opens', 'color': '#a16207'},
          {'n': 2, 'label': 'Meets Bahadur Shah', 'sub': 'the Guru travels with the new emperor', 'color': '#1e40af'},
          {'n': 3, 'label': 'Arrives at Nanded', 'sub': 'on the Godavari, in the Deccan', 'color': '#166534'},
      ], edge_labels=['then', 'to'], takeaway='The Guru’s last road led far south to Nanded, where he would prepare the Sikhs to stand without a living Guru.', accent=AC),
      bg='The emperor <b>Aurangzeb died in 1707</b>. In the succession that followed, the Guru travelled to the Deccan, meeting the new emperor <b>Bahadur Shah</b>.',
      people='the emperor <b>Bahadur Shah I</b>; the community of Sikhs; <b>Guru Gobind Singh</b> on his final journey.',
      what='The Guru journeyed south to <b>Nanded</b> on the river Godavari, where, far from the Punjab, he continued to <b>guide the Khalsa</b> and prepare it for the time when there would be no human Guru to lead it.',
      crux='He looked beyond his own life, turning his community toward a future in which <b>authority would rest in scripture and the Panth</b>.',
      conseq='At Nanded, wounded by an assassin, the Guru would make his final and greatest declaration.',
      matters='He led his people to the threshold of a new age — one in which the Guru would live on in the word, not the man.'),

    E('eternalguru', '1708', 'The Guru Granth Sahib — the eternal Guru', ['REFORM', 'TURNING POINT', 'TRIUMPH'],
      'Before his death at Nanded in 1708, Guru Gobind Singh makes his final declaration — that after him there will be no further human Guru, and that the sacred scripture, the Guru Granth Sahib, is to be revered as the living and eternal Guru of the Sikhs for all time.',
      svg_stack('The scripture made the eternal Guru', [
          {'n': 1, 'label': 'No more human Gurus', 'sub': 'the line of ten Gurus is completed', 'color': '#78350f'},
          {'n': 1, 'label': 'The scripture as Guru', 'sub': 'the Guru Granth Sahib enthroned', 'color': '#1e40af'},
          {'n': 1, 'label': 'The eternal Guru', 'sub': 'to guide the Sikhs for all time', 'color': '#166534'},
      ], takeaway='The Guru declared that the sacred word itself would lead the Sikhs forever — the scripture enthroned as the living, eternal Guru.', accent=AC),
      bg='At <b>Nanded in 1708</b>, mortally wounded, the tenth Guru made the most consequential decision in Sikh history about the future of the Guruship.',
      people='the <b>Guru Granth Sahib</b>, the scripture; the <b>Khalsa Panth</b>; <b>Guru Gobind Singh</b>, the last human Guru.',
      what='The Guru declared that there would be <b>no further human Guru</b> after him, and that the <b>Guru Granth Sahib</b> — the sacred scripture — was thereafter to be revered as the <b>eternal, living Guru</b> of the Sikhs.',
      crux='He vested the Guruship permanently in the <b>revealed word and the community</b>, ending the succession of persons.',
      conseq='Since 1708 the Guru Granth Sahib has been the eternal Guru of the Sikhs, central to all worship and life.',
      matters='It settled how a faith would be led forever — by the timeless word rather than any single mortal leader.'),

    E('legacy', '1708', 'The warrior-saint and poet — an enduring legacy', ['LEGACY', 'DEATH'],
      'Guru Gobind Singh dies at Nanded in 1708, having reshaped his faith for all time — remembered as a warrior-saint who united devotion and courage, a poet of great power, the founder of the Khalsa, and the Guru who gave the Sikhs their scripture as their eternal guide.',
      svg_row('The measure of the tenth Guru', [
          {'n': 1, 'label': 'Warrior and saint', 'sub': 'devotion joined to courage', 'color': '#1e40af'},
          {'n': 2, 'label': 'Poet and founder', 'sub': 'the Khalsa and a body of sacred verse', 'color': '#a16207'},
          {'n': 3, 'label': 'The eternal guide bestowed', 'sub': 'the Guru Granth Sahib for all time', 'color': '#166534'},
      ], edge_labels=['and', 'leaving'], takeaway='Warrior, saint and poet, he gave the Sikhs their form, their courage and their eternal Guru — a legacy carried by millions.', accent=AC),
      bg='Guru Gobind Singh <b>died at Nanded in 1708</b>, ending the line of ten human Gurus that had begun with Guru Nanak.',
      people='the <b>Khalsa Panth</b> he founded; the millions of Sikhs who revere him; <b>Guru Gobind Singh</b>, warrior-saint and poet.',
      what='He is remembered as a <b>warrior-saint and poet</b> who founded the Khalsa, gave the Sikhs their distinctive identity, wrote works of enduring devotional and heroic power, and <b>bestowed the Guru Granth Sahib as the eternal Guru</b>.',
      crux='His life fused <b>the sword and the spirit</b> — the defence of freedom and conscience with the deepest devotion.',
      conseq='His legacy shapes the Sikh faith to this day, in its scripture, its identity and its ideal of the saint-soldier.',
      matters='He stands as the model of faith and courage united — and the Guru who gave his people a guide to last for all time.'),
]

# ==================================================================  OVERVIEW
OVERVIEW_HTML = """
<p class="ov-lead">Guru Gobind Singh, the tenth Guru of the Sikhs, was a warrior-saint and poet who gave his faith its enduring form. Born in Patna in 1666, he became Guru at the age of nine after his father, Guru Tegh Bahadur, was executed by the Mughal emperor Aurangzeb for defending religious freedom. In 1699 he founded the Khalsa at Anandpur, gave the Sikhs the Five Ks and the names Singh and Kaur, and led them through years of war in which he lost all four of his sons. Before his death in 1708 he declared the Guru Granth Sahib to be the eternal Guru of the Sikhs. He is revered for uniting <b>devotion and courage, faith and the defence of freedom, and for entrusting his people forever to the sacred word.</b></p>
<div class="ov-quote">“When all other means have failed, it is righteous to draw the sword.”<span>— from the Zafarnama, attributed to Guru Gobind Singh</span></div>
<div class="ov-lbl">The whole arc in one line</div>
<p class="ov-lead" style="font-size:15.5px">Born in Patna into the Guru lineage → becomes the tenth Guru at nine after his father is martyred for religious freedom → founds the Khalsa at Anandpur on Vaisakhi 1699 with the Panj Pyare, the Five Ks and the names Singh and Kaur → is besieged at Anandpur and loses all four sons at Chamkaur and Sirhind → wins moral victory in the Zafarnama and seals the scripture at Damdama Sahib → and, before his death at Nanded in 1708, declares the Guru Granth Sahib the eternal Guru.</p>
<div class="ov-lbl">Why he is revered</div>
<div class="ov-grid">
  <div class="ov-card"><div class="i">🪯</div><h4>Founder of the Khalsa</h4><p>Created the community of the initiated, with its identity, code and equality.</p></div>
  <div class="ov-card"><div class="i">⚔️</div><h4>The warrior-saint</h4><p>United deep devotion with the courage to defend faith and freedom.</p></div>
  <div class="ov-card"><div class="i">📖</div><h4>The eternal Guru</h4><p>Enshrined the Guru Granth Sahib as the everlasting guide of the Sikhs.</p></div>
  <div class="ov-card"><div class="i">🕊️</div><h4>Faith and sacrifice</h4><p>Gave his father and four sons, yet never wavered in his mission.</p></div>
</div>
<div class="ov-lbl">The five chapters (use the tabs above)</div>
<div class="ov-arc">
  <div><b>1 · Birth &amp; Guruship</b><small> 1666–1676</small><p>Born in Patna; Guru at nine after his father’s martyrdom.</p></div>
  <div><b>2 · The Khalsa</b><small> 1699</small><p>The Panj Pyare, the amrit, the Five Ks, Singh and Kaur.</p></div>
  <div><b>3 · Wars &amp; Sacrifice</b><small> 1700–1704</small><p>Anandpur, Chamkaur and Sirhind; the loss of his four sons.</p></div>
  <div><b>4 · Letter &amp; Scripture</b><small> 1705–1706</small><p>Muktsar, the Zafarnama, and sealing the sacred word.</p></div>
  <div><b>5 · The Eternal Guru</b><small> 1707–1708</small><p>Nanded, and the Guru Granth Sahib made the eternal Guru.</p></div>
</div>
<div class="ov-lbl">How to use this guide</div>
<p class="ov-lead" style="font-size:15px">Each narrative tab is a <b>colour-tagged timeline</b>. <b>Click any event</b> to expand its concept map: a diagram of the moment, then six branches (background, key people, what happened, the crux, consequences, why it matters). Use <b>Key Events</b>, <b>Who’s Who</b> and the <b>Master Timeline</b> as references. This guide presents the Sikh tradition’s account and the historical record with reverence.</p>
"""

WHO = [
    {'name': 'Guru Tegh Bahadur', 'role': 'his father, the ninth Guru', 'color': '#166534',
     'bio': 'The ninth Sikh Guru, executed at Delhi in 1675 on Aurangzeb’s order for defending the religious freedom of others — a martyrdom revered by Sikhs.',
     'rel': 'The father whose sacrifice set the theme of his son’s life.'},
    {'name': 'Mata Gujri', 'role': 'his mother', 'color': '#a16207',
     'bio': 'The Guru’s mother, who cared for his youngest sons in the retreat from Anandpur and died at Sirhind after their martyrdom.',
     'rel': 'His mother, herself a martyr of the family’s ordeal.'},
    {'name': 'The Panj Pyare', 'role': 'the five beloved ones', 'color': '#1e40af',
     'bio': 'The five Sikhs — Daya Singh, Dharam Singh, Himmat Singh, Mohkam Singh and Sahib Singh — who offered their lives and became the first initiates of the Khalsa in 1699.',
     'rel': 'The first of the Khalsa, whom the Guru also let initiate him.'},
    {'name': 'Aurangzeb', 'role': 'Mughal emperor', 'color': '#b91c1c',
     'bio': 'The Mughal emperor whose policies pressed upon non-Muslims, who ordered the execution of Guru Tegh Bahadur, and to whom the Guru addressed the Zafarnama.',
     'rel': 'The emperor whose intolerance the Guru resisted his whole life.'},
    {'name': 'The four Sahibzade', 'role': 'his four sons', 'color': '#78350f',
     'bio': 'The Guru’s four sons: Ajit Singh and Jujhar Singh, killed at Chamkaur; and Zorawar Singh and Fateh Singh, bricked alive at Sirhind — all martyred in 1704.',
     'rel': 'His sons, all four martyred for the faith in a single winter.'},
]

KEY_EVENTS = [
    ('1666', 'Born in Patna', 'A son of Guru Tegh Bahadur, in the Guru line.'),
    ('1675', 'Guru Tegh Bahadur martyred', 'His father executed by Aurangzeb for religious freedom.'),
    ('1676', 'Becomes Guru at nine', 'The tenth Guru of the Sikhs.'),
    ('1699', 'Founding of the Khalsa', 'Vaisakhi at Anandpur; the Panj Pyare and the Five Ks.'),
    ('1704', 'Chamkaur', 'His two elder sons fall in battle.'),
    ('1704', 'Sirhind', 'His two youngest sons bricked alive.'),
    ('1705', 'Muktsar & the Zafarnama', 'His last great battle; the letter to Aurangzeb.'),
    ('1706', 'Scripture sealed', 'The Adi Granth finalised at Damdama Sahib.'),
    ('1708', 'The eternal Guru', 'Declares the Guru Granth Sahib the eternal Guru; dies at Nanded.'),
]

MASTER = [
    {'year': '1666', 'age': 'born', 'phase': 'Birth & Guruship', 'title': 'Born in Patna', 'desc': 'Into the line of the Sikh Gurus.'},
    {'year': '1676', 'age': 'age 9', 'phase': 'Birth & Guruship', 'title': 'Becomes tenth Guru', 'desc': 'After his father’s martyrdom.'},
    {'year': '1699', 'age': 'age 32', 'phase': 'The Khalsa', 'title': 'Founds the Khalsa', 'desc': 'Vaisakhi at Anandpur.'},
    {'year': '1704', 'age': 'age 37', 'phase': 'Wars & Sacrifice', 'title': 'Loses his four sons', 'desc': 'Chamkaur and Sirhind.'},
    {'year': '1705', 'age': 'age 38', 'phase': 'Letter & Scripture', 'title': 'The Zafarnama', 'desc': 'The victory letter to Aurangzeb.'},
    {'year': '1708', 'age': 'age 41', 'phase': 'The Eternal Guru', 'title': 'The eternal Guru', 'desc': 'The scripture enthroned; death at Nanded.'},
]

SOURCES = [
    ('Britannica — Guru Gobind Singh', 'https://www.britannica.com/biography/Gobind-Singh'),
    ('Wikipedia — Guru Gobind Singh', 'https://en.wikipedia.org/wiki/Guru_Gobind_Singh'),
    ('Britannica — Khalsa', 'https://www.britannica.com/topic/Khalsa'),
    ('SikhiWiki — Birth of the Khalsa', 'https://www.sikhiwiki.org/index.php/Birth_of_the_Khalsa'),
    ('World History Encyclopedia — Sikhism', 'https://www.worldhistory.org/Sikhism/'),
]

def build_meta():
    return {
        'pid': 'gm-gurugobindsingh.html', 'kind': 'man', 'emoji': '🪯', 'accent': AC,
        'name': 'Guru Gobind Singh', 'years': '1666–1708', 'group': 'Religious Founders',
        'back': ('great-men.html', 'Great Men'),
        'epithet': 'The tenth Sikh Guru — warrior-saint and poet who founded the Khalsa, gave his father and four sons for the faith, and enshrined the Guru Granth Sahib as the eternal Guru of the Sikhs.',
        'tabs': [
            {'id': 'overview', 'label': 'Overview', 'type': 'html', 'html': OVERVIEW_HTML},
            {'id': 'early', 'label': '1 · Birth & Guruship', 'type': 'timeline',
             'intro': 'Born in Patna in 1666 into the line of the Sikh Gurus, he becomes the tenth Guru at the age of nine after his father, Guru Tegh Bahadur, is martyred for defending religious freedom.', 'events': PHASE_EARLY},
            {'id': 'khalsa', 'label': '2 · The Khalsa', 'type': 'timeline',
             'intro': 'On Vaisakhi 1699 at Anandpur he founds the Khalsa — calling forth the Panj Pyare, administering the amrit, and giving the Sikhs the Five Ks and the names Singh and Kaur.', 'events': PHASE_KHALSA},
            {'id': 'wars', 'label': '3 · Wars & Sacrifice', 'type': 'timeline',
             'intro': 'Besieged at Anandpur by hill rajas and Mughal forces, he is forced into a retreat in which all four of his sons are martyred — two at Chamkaur, two bricked alive at Sirhind.', 'events': PHASE_WARS},
            {'id': 'letter', 'label': '4 · Letter & Scripture', 'type': 'timeline',
             'intro': 'He fights his last great battle at Muktsar, writes the fearless Zafarnama to Aurangzeb, and seals the definitive recension of the Sikh scripture at Damdama Sahib.', 'events': PHASE_LETTER},
            {'id': 'eternal', 'label': '5 · The Eternal Guru', 'type': 'timeline',
             'intro': 'Travelling south to Nanded, and before his death in 1708, he makes his final declaration — that the Guru Granth Sahib shall be the eternal Guru of the Sikhs thereafter.', 'events': PHASE_ETERNAL,
             'sources': SOURCES, 'srcnote': 'Drawn from standard encyclopaedic and Sikh sources; this guide presents the Sikh tradition’s account and the historical record reverently and neutrally.'},
            {'id': 'events', 'label': 'Key Events', 'type': 'events', 'rows': KEY_EVENTS},
            {'id': 'who', 'label': "Who's Who", 'type': 'who', 'people': WHO},
            {'id': 'timeline', 'label': 'Master Timeline', 'type': 'master', 'rows': MASTER},
        ],
    }
